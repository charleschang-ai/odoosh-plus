"""AI 租户隔离回归测试:严格保证非超管用户只能用 AI 排查/操作自己有权限的实例,绝不碰其他实例。

这条是硬红线(用户明确强调),此测试锁死它——任何改动破坏隔离,pytest 立刻报警。
运行:cd backend && python3 -m pytest -q tests/test_ai_isolation.py

覆盖:
1. assist 工具集不含任何 SQL / 容器 exec / 平台级工具;
2. _authorize:跨组织实例 → 拒;同组织但无该实例权限(非拥有者、未在授权名单)→ 拒;有权 → 放行;
3. 修复动作按实例类型细分(ACL 可操作成员不能对生产实例执行 deploy);
4. list_envs 只返回该用户有权访问的实例,且不含其他组织。
"""

import pytest

from app.db import Base, SessionLocal, engine
from app.models import Environment, EnvironmentAcl, Membership, Tenant, User
from app.services.ai import guards
from app.services.ai.tools import instance as I
from app.services.ai.tools import registry
from app.services.ai.tools.registry import ToolCtx, ToolError

# 高位 id,避免与其他 e2e 测试的数据冲突
TA, TB = 9001, 9002              # 组织 A / 组织 B
U_OWN, U_OUT, U_OP = 9001, 9002, 9003  # A 的实例拥有者 / B 的用户 / A 里仅对某生产实例有 operate ACL 的用户
E_A_OWN, E_A_OTHER, E_A_PROD, E_B = 9001, 9002, 9003, 9004


@pytest.fixture(scope="module", autouse=True)
def seed():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        for mid in (E_A_OWN, E_A_OTHER, E_A_PROD, E_B):
            e = db.get(Environment, mid)
            if e:
                db.delete(e)
        db.execute(EnvironmentAcl.__table__.delete().where(EnvironmentAcl.environment_id.in_([E_A_OWN, E_A_OTHER, E_A_PROD, E_B])))
        db.execute(Membership.__table__.delete().where(Membership.user_id.in_([U_OWN, U_OUT, U_OP])))
        for cid in (TA, TB):
            if not db.get(Tenant, cid):
                db.add(Tenant(id=cid, slug=f"iso{cid}", name=f"组织{cid}"))
        for uid, name in ((U_OWN, "iso_owner"), (U_OUT, "iso_out"), (U_OP, "iso_op")):
            if not db.get(User, uid):
                db.add(User(id=uid, username=name, password_hash="x", role="member"))
        db.commit()
        db.add(Membership(user_id=U_OWN, tenant_id=TA, role="developer"))
        db.add(Membership(user_id=U_OP, tenant_id=TA, role="developer"))
        db.add(Membership(user_id=U_OUT, tenant_id=TB, role="owner"))
        # 组织 A:U_OWN 拥有 E_A_OWN(dev);E_A_OTHER 由别人拥有、U_OWN 无 ACL;E_A_PROD 生产,U_OP 有 operate ACL
        db.add(Environment(id=E_A_OWN, tenant_id=TA, name="a_own", kind="dev", owner_user_id=U_OWN, container_name="c_a_own"))
        db.add(Environment(id=E_A_OTHER, tenant_id=TA, name="a_other", kind="dev", owner_user_id=99999, container_name="c_a_other"))
        db.add(Environment(id=E_A_PROD, tenant_id=TA, name="a_prod", kind="production", owner_user_id=99999, container_name="c_a_prod"))
        db.add(Environment(id=E_B, tenant_id=TB, name="b_env", kind="dev", owner_user_id=U_OUT, container_name="c_b"))
        db.add(EnvironmentAcl(environment_id=E_A_PROD, user_id=U_OP, level="operate"))
        db.commit()
    yield


def ctx(uid, tid):
    return ToolCtx(user_id=uid, username=f"u{uid}", is_superadmin=False, conv_id=0,
                   spill_dir=guards.spill_dir_for(0), tenant_id=tid)


def _authorize(uid, tid, env_id, action):
    with SessionLocal() as db:
        env = db.get(Environment, env_id)
        I._authorize(ctx(uid, tid), db, env, action)


# ---------------- 1. 工具集不含危险工具 ----------------

def test_assist_toolset_excludes_dangerous():
    assist = set(registry.available_tools(False, "assist"))
    banned = {"env_sql", "env_sql_write", "container_exec", "nginx_reload",
              "platform_overview", "platform_service_logs", "docker_ps", "docker_events",
              "host_resources", "nginx_status", "platform_service_restart", "prune_resources"}
    assert not (assist & banned), f"assist 泄露危险工具: {assist & banned}"
    assert {"env_info", "env_logs", "env_restart"} <= assist
    assert registry.available_tools(False, "help") == []


# ---------------- 2/3. _authorize 隔离 ----------------

def test_cross_company_rejected():
    # 组织 B 的用户(会话钉在 B),对组织 A 的实例做任何动作 → 拒
    for action in ("view", "logs", "stats", "restart", "deploy", "start", "stop"):
        with pytest.raises(ToolError) as ei:
            _authorize(U_OUT, TB, E_A_OWN, action)
        assert "REJECTED" in str(ei.value)


def test_same_company_no_access_rejected():
    # 组织 A 的用户,对同组织但非自己拥有、且不在授权名单的实例 → 拒
    for action in ("view", "logs", "restart"):
        with pytest.raises(ToolError):
            _authorize(U_OWN, TA, E_A_OTHER, action)


def test_owner_allowed():
    # 拥有者对自己的实例 → 放行(不抛异常)
    _authorize(U_OWN, TA, E_A_OWN, "view")
    _authorize(U_OWN, TA, E_A_OWN, "restart")


def test_repair_gated_by_kind():
    # ACL「可操作」成员:对生产实例可 restart(operator restart ALL),但不可 deploy(operator deploy 仅 NONPROD)
    _authorize(U_OP, TA, E_A_PROD, "restart")
    with pytest.raises(ToolError):
        _authorize(U_OP, TA, E_A_PROD, "deploy")


def test_tenant_none_rejected():
    # 防御:非超管但会话无组织作用域(tenant_id=None)→ 一律拒
    with SessionLocal() as db:
        env = db.get(Environment, E_A_OWN)
        with pytest.raises(ToolError):
            I._authorize(ctx(U_OWN, None), db, env, "view")


# ---------------- 4. list_envs 过滤 ----------------

def test_list_envs_only_accessible():
    import re

    out = I.list_envs(ctx(U_OWN, TA), {})
    ids = set(map(int, re.findall(r"#(\d+)", out)))
    assert E_A_OWN in ids                 # 拥有的可见
    assert E_A_OTHER not in ids           # 同组织无权的不可见
    assert E_B not in ids                 # 其他组织的不可见

    out_b = I.list_envs(ctx(U_OUT, TB), {})
    ids_b = set(map(int, re.findall(r"#(\d+)", out_b)))
    assert not (ids_b & {E_A_OWN, E_A_OTHER, E_A_PROD})  # B 用户看不到任何 A 的实例
