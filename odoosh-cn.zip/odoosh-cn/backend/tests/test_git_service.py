"""services/git.py 的单元测试(纯函数部分离线;ls_remote 需联网,可用 -m 'not network' 跳过)。

运行:cd backend && python3 -m pytest -q tests/test_git_service.py
"""

import base64
import hashlib
import hmac
import importlib.util
import json
import pathlib
import sys

import pytest

# 直接按文件加载,避免 import app.services 触发 docker 等依赖
_p = pathlib.Path(__file__).resolve().parents[1] / "app" / "services" / "git.py"
_spec = importlib.util.spec_from_file_location("gitsvc", _p)
gitsvc = importlib.util.module_from_spec(_spec)
sys.modules["gitsvc"] = gitsvc
_spec.loader.exec_module(gitsvc)


# ---------------------------------------------------------------- URL 解析
@pytest.mark.parametrize(
    "url,provider,owner,repo,https",
    [
        ("https://github.com/odoo/odoo", "github", "odoo", "odoo", "https://github.com/odoo/odoo.git"),
        ("https://github.com/odoo/odoo.git/", "github", "odoo", "odoo", "https://github.com/odoo/odoo.git"),
        ("git@gitee.com:mirrors/odoo.git", "gitee", "mirrors", "odoo", "https://gitee.com/mirrors/odoo.git"),
        ("ssh://git@gitlab.example.com/grp/sub/proj.git", "gitlab", "grp/sub", "proj", "https://gitlab.example.com/grp/sub/proj.git"),
        ("http://192.168.1.10:3000/team/app.git", "generic", "team", "app", "http://192.168.1.10:3000/team/app.git"),
        ("gitee.com/foo/bar", "gitee", "foo", "bar", "https://gitee.com/foo/bar.git"),
    ],
)
def test_parse_repo_url(url, provider, owner, repo, https):
    info = gitsvc.parse_repo_url(url)
    assert (info["provider"], info["owner"], info["repo"], info["https_url"]) == (provider, owner, repo, https)


@pytest.mark.parametrize("bad", ["", "https://github.com", "https://github.com/onlyowner", "not a url"])
def test_parse_repo_url_invalid(bad):
    with pytest.raises(ValueError):
        gitsvc.parse_repo_url(bad)


def test_normalize_repo_url_equivalence():
    a = gitsvc.normalize_repo_url("https://Gitee.com/Mirrors/Odoo.git")
    b = gitsvc.normalize_repo_url("git@gitee.com:mirrors/odoo")
    assert a == b == "gitee.com/mirrors/odoo"
    assert gitsvc.normalize_repo_url(None) == ""


# ---------------------------------------------------------------- pkt-line 解析
def _pkt(s: bytes) -> bytes:
    return f"{len(s) + 4:04x}".encode() + s


def test_pkt_lines_roundtrip():
    data = _pkt(b"# service=git-upload-pack\n") + b"0000" + _pkt(b"abc refs/heads/main\0symref=HEAD:refs/heads/main\n") + b"0000"
    parts = list(gitsvc._pkt_lines(data))
    assert parts[0].startswith(b"# service")
    assert parts[1] is None
    assert parts[2].startswith(b"abc refs/heads/main")
    assert parts[3] is None


class _Resp:
    """模拟 requests 的流式响应(ls_remote 用 with http().get(..., stream=True) as r + iter_content)。"""

    def __init__(self, status, body):
        self.status_code, self._body, self.headers, self.is_redirect = status, body, {}, False

    def iter_content(self, n):
        for i in range(0, len(self._body), n):
            yield self._body[i:i + n]

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def _mock_http(monkeypatch, status, body):
    class S:
        def get(self, *a, **k):
            return _Resp(status, body)

    monkeypatch.setattr(gitsvc, "http", lambda: S())
    gitsvc._safe_hosts.clear()


def test_ls_remote_parses_mocked_response(monkeypatch):
    body = (
        _pkt(b"# service=git-upload-pack\n")
        + b"0000"
        + _pkt(b"1111111111111111111111111111111111111111 HEAD\0multi_ack symref=HEAD:refs/heads/develop agent=git/2.x\n")
        + _pkt(b"1111111111111111111111111111111111111111 refs/heads/develop\n")
        + _pkt(b"2222222222222222222222222222222222222222 refs/heads/main\n")
        + _pkt(b"3333333333333333333333333333333333333333 refs/tags/v1.0\n")
        + _pkt(b"4444444444444444444444444444444444444444 refs/tags/v1.0^{}\n")
        + b"0000"
    )

    _mock_http(monkeypatch, 200, body)
    refs, default = gitsvc.ls_remote("https://example.com/o/r.git")
    assert refs == {"develop": "1" * 40, "main": "2" * 40}
    assert default == "develop"


def test_ls_remote_auth_error(monkeypatch):
    _mock_http(monkeypatch, 401, b"")
    with pytest.raises(RuntimeError, match="认证失败"):
        gitsvc.ls_remote("https://example.com/o/r.git", token="bad")


# ---------------------------------------------------------------- Webhook 校验
SECRET = "s3cret"
BODY = json.dumps({"ref": "refs/heads/main"}).encode()


def test_verify_github_ok_and_bad():
    sig = "sha256=" + hmac.new(SECRET.encode(), BODY, hashlib.sha256).hexdigest()
    assert gitsvc.verify_webhook({"X-Hub-Signature-256": sig}, BODY, SECRET) == "github"
    with pytest.raises(PermissionError):
        gitsvc.verify_webhook({"X-Hub-Signature-256": "sha256=00"}, BODY, SECRET)


def test_verify_gitee_password_and_signature():
    assert gitsvc.verify_webhook({"X-Gitee-Token": SECRET}, BODY, SECRET) == "gitee"
    ts = "1700000000000"
    sign = base64.b64encode(hmac.new(SECRET.encode(), f"{ts}\n{SECRET}".encode(), hashlib.sha256).digest()).decode()
    assert gitsvc.verify_webhook({"X-Gitee-Token": sign, "X-Gitee-Timestamp": ts}, BODY, SECRET) == "gitee"
    with pytest.raises(PermissionError):
        gitsvc.verify_webhook({"X-Gitee-Token": "nope", "X-Gitee-Timestamp": ts}, BODY, SECRET)


def test_verify_gitlab_and_generic():
    assert gitsvc.verify_webhook({"X-Gitlab-Token": SECRET}, BODY, SECRET) == "gitlab"
    assert gitsvc.verify_webhook({"X-Webhook-Token": SECRET}, BODY, SECRET) == "generic"
    assert gitsvc.verify_webhook({}, BODY, SECRET, query_token=SECRET) == "generic"
    with pytest.raises(PermissionError):
        gitsvc.verify_webhook({}, BODY, SECRET)


# ---------------------------------------------------------------- payload 解析
def test_parse_push_github():
    payload = {
        "ref": "refs/heads/feature-x",
        "after": "abc123",
        "deleted": False,
        "head_commit": {"id": "abc123", "message": "fix: bug\n\ndetails", "author": {"name": "Alice"}},
        "pusher": {"name": "alice"},
    }
    info = gitsvc.parse_push_payload("github", {"X-GitHub-Event": "push"}, payload)
    assert info == {"branch": "feature-x", "sha": "abc123", "message": "fix: bug", "author": "Alice", "pusher": "alice", "deleted": False}


def test_parse_push_ignores_ping_and_tags():
    assert gitsvc.parse_push_payload("github", {"X-GitHub-Event": "ping"}, {"zen": "x"}) is None
    assert gitsvc.parse_push_payload("gitee", {"X-Gitee-Event": "Push Hook"}, {"ref": "refs/tags/v1"}) is None


def test_parse_push_gitlab_delete():
    payload = {"ref": "refs/heads/old", "after": "0" * 40, "checkout_sha": None, "commits": [], "user_name": "bob"}
    info = gitsvc.parse_push_payload("gitlab", {"X-Gitlab-Event": "Push Hook"}, payload)
    assert info["deleted"] is True and info["sha"] is None and info["pusher"] == "bob"


# ---------------------------------------------------------------- hooks
def test_push_hooks_registry():
    calls = []
    gitsvc._push_hooks.clear()
    assert not gitsvc.has_push_hooks()
    gitsvc.register_push_hook(lambda rid, ids, info: calls.append((rid, ids)))
    gitsvc.register_push_hook(lambda rid, ids, info: 1 / 0)  # 失败的回调不影响其他
    gitsvc.run_push_hooks(1, [2, 3], {})
    assert calls == [(1, [2, 3])]
    gitsvc._push_hooks.clear()


# ---------------------------------------------------------------- 联网
@pytest.mark.network
def test_ls_remote_real_gitee():
    refs, default = gitsvc.ls_remote("https://gitee.com/mirrors/odoo.git")
    assert default in refs and len(refs) > 5
