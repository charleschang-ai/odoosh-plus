"""services/gitoauth.py 单元测试(全部离线,requests 被 mock)。

需要 fastapi 环境中的依赖(jose / sqlalchemy),在 api 容器里跑:
  docker run --rm -e ODOOSH_DATABASE_URL=sqlite:////tmp/t.db -v .../backend:/app -w /app odoosh/api:dev python -m pytest -q tests/test_gitoauth.py
"""

import json

import pytest

from app.services import gitoauth
from app.services.gitoauth import Client, OAuthError


class FakeResp:
    def __init__(self, status=200, body=None, text=""):
        self.status_code = status
        self._body = body
        self.text = text or (json.dumps(body) if body is not None else "")
        self.content = self.text.encode()

    def json(self):
        if self._body is None:
            raise ValueError("no json")
        return self._body


def test_state_roundtrip():
    s = gitoauth.make_state(7, "gitee", "https://x/cb")
    assert gitoauth.parse_state(s) == {"user_id": 7, "provider": "gitee", "redirect_uri": "https://x/cb"}
    with pytest.raises(OAuthError):
        gitoauth.parse_state(s + "x")


def test_token_fields_expiry():
    f = gitoauth._token_fields({"access_token": "a", "refresh_token": "r", "expires_in": 86400, "scope": "user_info"})
    assert f["access_token"] == "a" and f["refresh_token"] == "r" and f["expires_at"] is not None
    assert gitoauth._token_fields({"access_token": "a"})["expires_at"] is None


def test_client_github_calls(monkeypatch):
    calls = []

    def fake_request(method, url, headers=None, params=None, timeout=None, **kw):
        calls.append((method, url, headers, params, kw))
        if url.endswith("/user"):
            return FakeResp(200, {"login": "alice", "name": "Alice", "avatar_url": "http://a"})
        if url.endswith("/user/repos") and method == "GET":
            return FakeResp(200, [{"full_name": "alice/x", "name": "x", "owner": {"login": "alice"}, "private": True, "clone_url": "https://github.com/alice/x.git", "html_url": "h", "default_branch": "main"}])
        if url.endswith("/git/ref/heads/main"):
            return FakeResp(200, {"object": {"sha": "abc"}})
        if url.endswith("/git/refs") and method == "POST":
            return FakeResp(201, {"object": {"sha": "abc"}})
        if url.endswith("/hooks") and method == "GET":
            return FakeResp(200, [])
        if url.endswith("/hooks") and method == "POST":
            return FakeResp(201, {"id": 42})
        return FakeResp(404, {"message": "Not Found"})

    monkeypatch.setattr(gitoauth.requests, "request", fake_request)
    c = Client("github", "tok")
    assert c.me()["login"] == "alice"
    assert calls[-1][2]["Authorization"] == "Bearer tok"
    repos = c.list_all_repos()
    assert repos[0]["full_name"] == "alice/x" and repos[0]["private"] is True
    assert c.create_branch("alice", "x", "feat", "main") == {"name": "feat", "sha": "abc"}
    assert calls[-1][4]["json"] == {"ref": "refs/heads/feat", "sha": "abc"}
    assert c.create_webhook("alice", "x", "https://p/api/webhooks/git/1", "sec") == "42"
    assert calls[-1][4]["json"]["config"]["secret"] == "sec"
    with pytest.raises(OAuthError, match="404"):
        c.branch_sha("alice", "x", "nope")


def test_client_gitee_calls(monkeypatch):
    calls = []

    def fake_request(method, url, headers=None, params=None, timeout=None, **kw):
        calls.append((method, url, params, kw))
        if url.endswith("/branches") and method == "POST":
            return FakeResp(201, {"name": "feat", "commit": {"sha": "def"}})
        if url.endswith("/hooks") and method == "GET":
            return FakeResp(200, [{"id": 9, "url": "https://p/api/webhooks/git/1"}])
        return FakeResp(401, {"message": "bad"})

    monkeypatch.setattr(gitoauth.requests, "request", fake_request)
    c = Client("gitee", "tok")
    assert c.create_branch("o", "r", "feat", "master") == {"name": "feat", "sha": "def"}
    assert calls[-1][2]["access_token"] == "tok"  # Gitee 用 query 参数带令牌
    assert calls[-1][3]["data"] == {"refs": "master", "branch_name": "feat"}
    # 已存在同 URL 的 hook 则复用
    assert c.create_webhook("o", "r", "https://p/api/webhooks/git/1", "s") == "9"
    with pytest.raises(OAuthError, match="令牌无效"):
        c.me()
    with pytest.raises(OAuthError, match="Gitee 暂不支持"):
        c.delete_branch("o", "r", "x")


def test_exchange_code_and_authorize_url(monkeypatch):
    from app.db import Base, SessionLocal, engine

    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        with pytest.raises(OAuthError, match="尚未配置"):
            gitoauth.authorize_url(db, "github", 1, "https://x/cb")
        gitoauth.set_oauth_app(db, "github", "cid", "csec")
        gitoauth.set_oauth_app(db, "github", "cid2", None)  # 只改 id,不改 secret
        apps = gitoauth.get_oauth_apps(db)
        assert apps["github"] == {"client_id": "cid2", "client_secret": "csec", "configured": True}
        assert apps["gitee"]["configured"] is False
        url = gitoauth.authorize_url(db, "github", 1, "https://x/cb")
        assert url.startswith("https://github.com/login/oauth/authorize?") and "client_id=cid2" in url and "state=" in url

        posted = {}

        def fake_post(url, data=None, headers=None, timeout=None):
            posted.update(data)
            return FakeResp(200, {"access_token": "gho_x", "scope": "repo", "token_type": "bearer"})

        monkeypatch.setattr(gitoauth.requests, "post", fake_post)
        tok = gitoauth.exchange_code(db, "github", "thecode", "https://x/cb")
        assert tok["access_token"] == "gho_x" and posted["client_secret"] == "csec" and posted["code"] == "thecode"

        monkeypatch.setattr(gitoauth.requests, "post", lambda *a, **k: FakeResp(400, {"error": "bad_verification_code", "error_description": "The code passed is incorrect"}))
        with pytest.raises(OAuthError, match="incorrect"):
            gitoauth.exchange_code(db, "github", "bad", "https://x/cb")


def test_refresh_if_needed(monkeypatch):
    from datetime import datetime, timedelta, timezone

    from app.db import Base, SessionLocal, engine
    from app.models_git import GitAccount

    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        acc = GitAccount(user_id=1, provider="gitee", login="u", access_token="old", refresh_token="rt",
                         expires_at=datetime.now(timezone.utc) + timedelta(minutes=1))
        db.add(acc)
        db.commit()
        # SQLite 不保存时区,读回后补上 UTC
        acc.expires_at = acc.expires_at.replace(tzinfo=timezone.utc)
        monkeypatch.setattr(gitoauth.requests, "post", lambda *a, **k: FakeResp(200, {"access_token": "new", "refresh_token": "rt2", "expires_in": 86400}))
        gitoauth.refresh_if_needed(db, acc)
        assert acc.access_token == "new" and acc.refresh_token == "rt2"
        # GitHub 不刷新
        gh = GitAccount(user_id=1, provider="github", login="g", access_token="keep")
        assert gitoauth.refresh_if_needed(db, gh).access_token == "keep"
