import os
os.environ.setdefault("ODOOSH_DATABASE_URL", "sqlite:////tmp/x.db")
os.environ.setdefault("ODOOSH_SECRET_KEY", "test-secret-key-not-for-production")
from fastapi.testclient import TestClient
from app.main import app
from app.db import SessionLocal
from app.models import Environment, Tenant, Membership
from app.models_git import Repository
c = TestClient(app)
with c:
    r = c.post("/api/auth/login", json={"username": "admin", "password": "admin"})
    print("login", r.status_code)
    h = {"Authorization": "Bearer " + r.json()["access_token"]}
    with SessionLocal() as db:
        t = Tenant(slug="acme", name="Acme"); db.add(t); db.commit(); db.refresh(t)
        repo = Repository(tenant_id=t.id, name="xxx", url="https://gitee.com/acme/xxx.git", provider="gitee", owner="acme", repo="xxx", webhook_secret="s", default_branch="main",
                          branches_json='{"branches":[{"name":"main","sha":"abc","message":"m"},{"name":"feature-x","sha":"def","message":"f"}]}')
        db.add(repo); db.commit(); db.refresh(repo)
        e = Environment(tenant_id=t.id, name="main", kind="production", repo_url="https://gitee.com/acme/xxx", branch="main", status="running", container_name="c", db_name="d")
        db.add(e); db.commit(); db.refresh(e)
        rid, eid, tid = repo.id, e.id, t.id
    print("list", c.get("/api/projects", headers=h).json())
    d = c.get(f"/api/projects/{rid}", headers=h).json()
    print("detail envs", [x["branch"] for x in d["environments"]], "unassigned", [b["name"] for b in d["unassigned"]], "err", d["mirror_error"], d["has_production"], d["role"])
    # second production must be rejected
    r = c.post(f"/api/projects/{rid}/environments", json={"branch": "feature-x", "kind": "production"}, headers=h)
    print("dup prod", r.status_code, r.json())
    r = c.post(f"/api/projects/{rid}/environments/{eid}/kind", json={"kind": "staging"}, headers=h)
    print("downgrade w/o confirm", r.status_code, r.json())
    r = c.put(f"/api/environments/{eid}", json={"mem_mb": 2048, "cpus": 0}, headers=h)
    print("limits", r.status_code, r.json().get("mem_mb"), r.json().get("cpus"))
    # create env via env router with kind production on same repo -> 409
    r = c.post("/api/environments", json={"tenant_id": tid, "name": "other", "kind": "production", "repo_url": "https://gitee.com/acme/xxx.git", "branch": "feature-x"}, headers=h)
    print("env router dup prod", r.status_code, r.json())
    r = c.get(f"/api/projects/{rid}/environments/{eid}/upgrade", headers=h)
    print("upgrade info", r.status_code, r.json())
