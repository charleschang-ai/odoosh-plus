"""services/databases.routing 的 dbfilter 正确性回归测试。

背景:一个实例(容器 + db_user)带 1 个主库 + N 个附加库,全靠 odoo.conf 的 dbfilter(一个正则)
按请求域名首段(%d)把请求路由到正确的库,且主库/附加库两支必须**互斥**(否则 Odoo 弹数据库选择页)。

这套逻辑很微妙,还隐含依赖「Odoo 的 db_filter() 在替换 %d 前会先 re.escape(首段)」——
正是这个转义让 fuzzy 模式里 `[%d_]` 这种把首段塞进字符类的写法,遇到含 `-` 的扁平域名
首段(如 dev-acme)也不会因非法区间(v-a)而报错。本测试用忠实复刻的 Odoo db_filter
把这些不变量固定住:换了域名方案 / 动了 routing 正则 / Odoo 改了转义行为,都会在这里报出来。
"""

import re
from types import SimpleNamespace

import pytest

from app.services import databases as dbsvc
from app.services import nginx


@pytest.fixture(autouse=True)
def _domain_mode(monkeypatch):
    """全部用「域名分流」访问模式(routing 会据此选 dbfilter 写法);避免测试去读数据库设置。"""
    monkeypatch.setattr(nginx, "access_mode", lambda: "domain")


def _odoo_db_filter(dbfilter: str, host: str, candidate_dbs: list[str]) -> list[str]:
    """忠实复刻 Odoo 的 db_filter():取 HTTP Host 首段,re.escape 后替换 %d,再 re.match 每个候选库。

    与 Odoo 各版本(12~19)一致:`d = re.escape(host.partition('.')[0])`,`r = dbfilter.replace('%d', d)`。
    返回匹配到的库名列表(正常应恰好 1 个)。若正则非法会直接抛 re.error(即被测出的「实例 500」)。
    """
    first = host.partition(":")[0].partition(".")[0]
    d = re.escape(first)
    r = dbfilter.replace("%d", d)
    return [db for db in candidate_dbs if re.match(r, db)]


def _env(name: str, slug: str, domain: str | None = None):
    """构造 routing() 需要的最小对象。db_name 复刻 orchestrator.db_identifier:'{slug}_{name}'(- → _)。"""
    db_name = f"{slug}_{name}".replace("-", "_")
    t = SimpleNamespace(slug=slug)
    e = SimpleNamespace(name=name, db_name=db_name, domain=domain, tenant=t)
    return e, t, db_name


def _fuzzy_confusable(suffix: str, extra: str) -> bool:
    """复刻 validate_name 的 fuzzy 防混淆判据:附加名包含主库后缀的全部字符 → 会与主库路由混淆,创建时被拒。"""
    need = set(suffix) - {"_"}
    return bool(need) and need <= set(extra)


def _assert_routes(name: str, slug: str, extras: list[str]):
    """扁平域名(<实例>-<组织>.<base>)下:主库与各附加库都能被各自域名唯一路由到,且两两互斥。

    只用**能通过 validate_name 的合法附加名**(过滤掉与主库混淆的名字)——这正是真实创建路径的约束;
    路由正确性依赖这条防混淆检查,test_confusable_extra_collides 单独证明「不过滤就会冲突」。
    """
    base = "example.com"
    domain = f"{name}-{slug}.{base}"           # nginx.env_domain 的扁平格式
    e, t, primary = _env(name, slug, domain)
    suffix = primary[len(f"{slug}_".replace("-", "_")):]
    dbfilter = dbsvc.dbfilter_for(e, t)

    legal = [x for x in extras if not _fuzzy_confusable(suffix, x) and x != name]
    assert legal, f"用例没有可用的合法附加名 name={name} slug={slug} suffix={suffix}"
    extra_dbs = [f"{primary}_{x}" for x in legal]
    all_dbs = [primary] + extra_dbs

    # 1) 主库请求:Host = <实例>-<组织>.<base> → 只命中主库
    assert _odoo_db_filter(dbfilter, domain, all_dbs) == [primary], (
        f"主库路由错误 name={name} slug={slug} dbfilter={dbfilter}")

    # 2) 每个合法附加库请求:Host = <库名>.<实例域名> → 只命中该附加库
    for x, xdb in zip(legal, extra_dbs):
        host = f"{x}.{domain}"
        assert _odoo_db_filter(dbfilter, host, all_dbs) == [xdb], (
            f"附加库路由错误 name={name} slug={slug} extra={x} dbfilter={dbfilter}")


# 覆盖:简单名、含 - 的实例名 / 组织名(扁平域名首段会出现多个 -,最易触发字符类区间问题)、数字、单字符
@pytest.mark.parametrize("name,slug", [
    ("dev", "acme"),
    ("prod", "acme"),
    ("staging", "acme"),
    ("test", "zoo"),
    ("web1", "corp"),
    ("a", "b"),
    ("feature-x", "acme"),   # 实例名含 -
    ("dev", "my-org"),       # 组织名含 -
    ("my-shop", "my-org"),   # 两者都含 -(首段 my-shop-my-org)
    ("z", "a"),              # 首段 z-a:未转义时 [z-a_] 会是非法区间 → 验证依赖 Odoo 的转义
])
def test_flat_domain_routing(name, slug):
    _assert_routes(name, slug, extras=["shop", "store", "hr", "live"])


def test_dbfilter_regex_is_always_valid():
    """无论实例 / 组织名如何,生成的 dbfilter 经 Odoo 的转义替换后都必须是合法正则(否则实例所有请求 500)。"""
    base = "example.com"
    for name in ("dev", "z", "x9", "feature-x", "a-b"):
        for slug in ("acme", "a", "my-org", "zoo"):
            domain = f"{name}-{slug}.{base}"
            e, t, primary = _env(name, slug, domain)
            dbfilter = dbsvc.dbfilter_for(e, t)
            # 主库首段(含 -)与一个普通附加库首段都要能编译
            for host in (domain, f"shop.{domain}"):
                first = re.escape(host.partition(".")[0])
                re.compile(dbfilter.replace("%d", first))  # 抛 re.error 即失败


def test_old_two_level_domain_still_routes():
    """历史两级域名(<实例>.<组织>.<base>)走 exact 模式,应继续正确路由(基础域名迁移期间新旧并存)。"""
    name, slug = "dev", "acme"
    domain = f"{name}.{slug}.example.com"      # 旧格式:首段 = 实例名
    e, t, primary = _env(name, slug, domain)
    dbfilter = dbsvc.dbfilter_for(e, t)
    extra_dbs = [f"{primary}_shop", f"{primary}_hr"]
    all_dbs = [primary] + extra_dbs
    assert _odoo_db_filter(dbfilter, domain, all_dbs) == [primary]
    assert _odoo_db_filter(dbfilter, f"shop.{domain}", all_dbs) == [f"{primary}_shop"]
    assert _odoo_db_filter(dbfilter, f"hr.{domain}", all_dbs) == [f"{primary}_hr"]


def test_custom_domain_falls_back_to_exact_primary():
    """超管自定义域名(首段与库名对不上)→ none 模式,dbfilter 精确匹配主库、不支持附加库。"""
    e, t, primary = _env("dev", "acme", domain="shop.example.com")
    rt = dbsvc.routing(e, t)
    assert rt["mode"] == "none"
    dbfilter = rt["dbfilter"]
    # 主库能路由;此模式下不保证附加库(设计如此),只断言主库精确、不误配主库以外
    assert _odoo_db_filter(dbfilter, "shop.example.com", [primary]) == [primary]
    assert _odoo_db_filter(dbfilter, "shop.example.com", [f"{primary}_x"]) == []


def test_confusable_extra_collides_hence_must_be_rejected():
    """证明 validate_name 防混淆检查的必要性:fuzzy 模式下,若附加名包含主库后缀的全部字符,
    该附加库请求会**同时命中主库和自己**(冲突,Odoo 弹选择页)。因此 validate_name 必须拒绝这类名字。"""
    name, slug = "test", "zoo"                 # 后缀 'test'(字符集 {t,e,s})
    domain = f"{name}-{slug}.example.com"
    e, t, primary = _env(name, slug, domain)   # primary = 'zoo_test'
    rt = dbsvc.routing(e, t)
    assert rt["mode"] == "fuzzy"

    confusable = "store"                        # {s,t,o,r,e} ⊇ {t,e,s} → 混淆
    assert _fuzzy_confusable(rt["suffix"], confusable)   # validate_name 会据此拒绝

    dbfilter = rt["dbfilter"]
    xdb = f"{primary}_{confusable}"
    all_dbs = [primary, xdb]
    hit = _odoo_db_filter(dbfilter, f"{confusable}.{domain}", all_dbs)
    # 若未被 validate_name 拦下而建了这个库:请求会命中两个库 → 证明检查不可或缺
    assert primary in hit and xdb in hit, f"预期冲突未复现 dbfilter={dbfilter} hit={hit}"
