"""端到端冒烟(需 fastapi 环境;用 SQLite 免起 PG):
ODOOSH_DATABASE_URL=sqlite:////tmp/e2e.db python -m tests.e2e_repos
"""

import os

os.environ.setdefault("ODOOSH_SECRET_KEY", "test-secret-key-not-for-production")
os.environ.setdefault("ODOOSH_DATABASE_URL", "sqlite:////tmp/e2e.db")

import base64
import hashlib
import hmac
import json

from fastapi.testclient import TestClient

from app.main import app

with TestClient(app) as c:
    tok = c.post("/api/auth/login", json={"username": "admin", "password": "admin"}).json()["access_token"]
    H = {"Authorization": f"Bearer {tok}"}

    t = c.post("/api/tenants", json={"slug": "acme", "name": "Acme"}, headers=H).json()
    print("tenant", t["id"])

    r = c.post("/api/repos/test", json={"tenant_id": t["id"], "name": "x", "url": "git@gitee.com:mirrors/odoo.git"}, headers=H).json()
    print("test:", r)
    assert r["ok"]

    repo = c.post("/api/repos", json={"tenant_id": t["id"], "name": "odoo", "url": "git@gitee.com:mirrors/odoo.git"}, headers=H).json()
    print("repo:", repo["provider"], repo["owner"], repo["repo"], repo["url"])
    assert repo["provider"] == "gitee" and repo["url"] == "https://gitee.com/mirrors/odoo.git"

    dup = c.post("/api/repos", json={"tenant_id": t["id"], "name": "odoo2", "url": "https://gitee.com/mirrors/odoo"}, headers=H)
    assert dup.status_code == 409, dup.text

    br = c.get(f"/api/repos/{repo['id']}/branches", headers=H).json()
    print("branches:", len(br["branches"]), "default:", br["default_branch"], "first:", br["branches"][0])
    assert br["default_branch"] in {b["name"] for b in br["branches"]}
    branch = br["default_branch"]

    env = c.post(
        "/api/environments",
        json={"tenant_id": t["id"], "name": "prod", "kind": "production", "repo_url": "https://gitee.com/Mirrors/Odoo", "branch": branch},
        headers=H,
    ).json()
    print("env:", env["id"], env["status"])

    br = c.get(f"/api/repos/{repo['id']}/branches", headers=H).json()
    bound = next(b for b in br["branches"] if b["name"] == branch)
    assert [e["name"] for e in bound["environments"]] == ["prod"], bound

    wh = c.get(f"/api/repos/{repo['id']}/webhook", headers=H).json()
    print("webhook:", wh["url"])
    secret = wh["secret"]

    # 1) 未授权
    bad = c.post(f"/api/webhooks/git/{repo['id']}", content=b"{}")
    assert bad.status_code == 401, bad.text
    # 2) Gitee 密码模式 push
    payload = {
        "ref": f"refs/heads/{branch}",
        "after": "deadbeef" * 5,
        "head_commit": {"id": "deadbeef" * 5, "message": "feat: hello\n\nbody", "author": {"name": "张三"}},
        "pusher": {"name": "zhangsan"},
    }
    ok = c.post(
        f"/api/webhooks/git/{repo['id']}",
        content=json.dumps(payload).encode(),
        headers={"X-Gitee-Token": secret, "X-Gitee-Event": "Push Hook", "Content-Type": "application/json"},
    )
    print("push:", ok.status_code, ok.json())
    assert ok.status_code == 200 and ok.json()["environments"] == [env["id"]]
    # 3) Gitee 签名模式,非绑定分支
    ts = "1700000000000"
    sign = base64.b64encode(hmac.new(secret.encode(), f"{ts}\n{secret}".encode(), hashlib.sha256).digest()).decode()
    payload["ref"] = "refs/heads/some-other-branch"
    ok2 = c.post(
        f"/api/webhooks/git/{repo['id']}",
        content=json.dumps(payload).encode(),
        headers={"X-Gitee-Token": sign, "X-Gitee-Timestamp": ts, "X-Gitee-Event": "Push Hook"},
    )
    assert ok2.status_code == 200 and ok2.json()["environments"] == [], ok2.text
    # 4) GitHub HMAC + ping 忽略
    body = json.dumps({"zen": "x"}).encode()
    sig = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    ping = c.post(f"/api/webhooks/git/{repo['id']}", content=body, headers={"X-Hub-Signature-256": sig, "X-GitHub-Event": "ping"})
    assert ping.json().get("ignored") is True, ping.text

    evs = c.get(f"/api/repos/{repo['id']}/events", headers=H).json()
    print("events:")
    for e in evs:
        print("  ", e["branch"], e["commit_sha"][:7], e["commit_message"], e["author"], "|", e["result"])
    assert len(evs) == 2
    # 编排模块已注册部署回调时显示"已触发 N 个环境重新部署",否则"已记录;自动部署尚未接入"
    assert evs[1]["result"].startswith(("已触发 1 个环境重新部署", "已记录;自动部署尚未接入")), evs[1]["result"]

    # 分支快照被 webhook 更新
    br = c.get(f"/api/repos/{repo['id']}/branches", headers=H).json()
    assert next(b for b in br["branches"] if b["name"] == branch)["sha"] == "deadbeef" * 5
    assert any(b["name"] == "some-other-branch" for b in br["branches"])

    # 令牌与更新
    up = c.put(f"/api/repos/{repo['id']}", json={"token": "abc", "regenerate_secret": True}, headers=H).json()
    assert up["has_token"] and up["webhook_secret"] != secret
    up = c.put(f"/api/repos/{repo['id']}", json={"token": ""}, headers=H).json()
    assert not up["has_token"]

    # 权限:非成员 403;测试者不可见 Git(列表为空、详情 403);开发者可见
    u = c.post("/api/users", json={"username": "bob", "password": "bobbob", "role": "member", "memberships": []}, headers=H)
    assert u.status_code == 201, u.text
    tok2 = c.post("/api/auth/login", json={"username": "bob", "password": "bobbob"}).json()["access_token"]
    H2 = {"Authorization": f"Bearer {tok2}"}
    assert c.get(f"/api/repos/{repo['id']}", headers=H2).status_code == 403
    assert c.get("/api/repos", headers=H2).json() == []
    u2 = c.post("/api/users", json={"username": "tess", "password": "tesstess", "role": "member", "memberships": [{"tenant_id": t["id"], "role": "tester"}]}, headers=H)
    assert u2.status_code == 201, u2.text
    H3 = {"Authorization": f"Bearer {c.post('/api/auth/login', json={'username': 'tess', 'password': 'tesstess'}).json()['access_token']}"}
    assert c.get("/api/repos", headers=H3).json() == []
    assert c.get(f"/api/repos/{repo['id']}", headers=H3).status_code == 403
    u3 = c.post("/api/users", json={"username": "dev", "password": "devdev", "role": "member", "memberships": [{"tenant_id": t["id"], "role": "developer"}]}, headers=H)
    assert u3.status_code == 201, u3.text
    H4 = {"Authorization": f"Bearer {c.post('/api/auth/login', json={'username': 'dev', 'password': 'devdev'}).json()['access_token']}"}
    # 仓库属于接入者本人:开发者看不到管理员接入的仓库
    assert c.get("/api/repos", headers=H4).json() == []
    assert c.get(f"/api/repos/{repo['id']}", headers=H4).status_code == 403
    assert c.get(f"/api/repos/{repo['id']}/branches", headers=H4).status_code == 403
    # 开发者可以接入自己的仓库(同一地址,互不可见、互不冲突)
    mine = c.post("/api/repos", json={"tenant_id": t["id"], "name": "dev-odoo", "url": "https://gitee.com/mirrors/odoo.git"}, headers=H4)
    assert mine.status_code == 201, mine.text
    mine = mine.json()
    assert mine["created_by_name"] == "dev" and mine["can_manage"] is True
    assert [r["id"] for r in c.get("/api/repos", headers=H4).json()] == [mine["id"]]
    assert c.get(f"/api/repos/{mine['id']}/branches", headers=H4).status_code == 200
    # 同一地址本人不能重复接入
    dup2 = c.post("/api/repos", json={"tenant_id": t["id"], "name": "ent", "url": "https://gitee.com/mirrors/odoo.git", "is_enterprise": True}, headers=H4)
    assert dup2.status_code == 409, dup2.text
    # 企业版仓库可见性:超管接入平台共享企业版仓库(用 odoo 镜像充当,含 17.0/18.0/19.0 分支)→ 开发者看不到,但 platform-status 告知存在
    plat = c.post("/api/repos", json={"scope": "platform", "name": "plat-ent", "url": "https://gitee.com/mirrors/odoo.git", "is_enterprise": True}, headers=H)
    assert plat.status_code == 201, plat.text
    plat = plat.json()
    assert plat["id"] not in [r["id"] for r in c.get("/api/repos", headers=H4).json()]
    assert c.get(f"/api/repos/{plat['id']}", headers=H4).status_code == 403
    ps = c.get("/api/enterprise/platform-status", headers=H4).json()
    assert ps == {"exists": True, "provider": "gitee", "name": None}  # 非超管拿不到名称/地址
    assert c.get("/api/enterprise/platform-status", headers=H).json()["name"] == "plat-ent"
    # 企业版来源解析:开发者没有自己的 → 用平台的,且地址被隐藏;version=19 探测通过
    src = c.get("/api/enterprise/source", params={"tenant_id": t["id"], "probe": True, "version": "19"}, headers=H4).json()
    print("ent source (dev):", src["source"], src["repo"], [ (x["source"], x["ok"]) for x in src["tried"] ])
    assert src["source"] == "platform" and src["repo"]["url"] is None and src["platform_available"] and src["versions"].get("19")
    # 版本不存在 → 无可用仓库,tried 给出原因
    src = c.get("/api/enterprise/source", params={"tenant_id": t["id"], "probe": True, "version": "99"}, headers=H4).json()
    assert src["repo"] is None and "没有 99.0 分支" in src["error"], src
    # 开发者接入自己的企业版仓库(另一个地址)→ 优先于平台的
    own_ent = c.post("/api/repos", json={"tenant_id": t["id"], "name": "my-ent", "url": "https://gitee.com/mirrors/odoo", "is_enterprise": True}, headers=H4)
    assert own_ent.status_code == 409  # 与 dev-odoo 同地址
    up = c.put(f"/api/repos/{mine['id']}", json={"is_enterprise": True}, headers=H4)
    if up.status_code == 200:
        src = c.get("/api/enterprise/source", params={"tenant_id": t["id"], "probe": True, "version": "19"}, headers=H4).json()
        assert src["source"] == "own" and src["repo"]["url"], src
        assert [x["source"] for x in src["tried"]] == ["own"]  # 自己的可用即停止,不再探测平台
    assert c.delete(f"/api/repos/{plat['id']}", headers=H).status_code == 204
    # 超管能看到全部(含开发者的),且 can_manage
    all_ids = {r["id"]: r for r in c.get("/api/repos", headers=H).json()}
    assert repo["id"] in all_ids and mine["id"] in all_ids and all_ids[mine["id"]]["can_manage"] is True
    # 管理员接入的仓库对超管 can_manage;对开发者不可见 → 由 dev 自己删自己的
    assert c.delete(f"/api/repos/{repo['id']}", headers=H4).status_code == 403
    assert c.delete(f"/api/repos/{mine['id']}", headers=H4).status_code == 204
    print("perms OK: non-member 403 / tester hidden / developer sees only own / superadmin all")

    assert c.delete(f"/api/repos/{repo['id']}", headers=H).status_code == 204

    # ---------------- OAuth 应用 / 账号
    apps = c.get("/api/git/oauth/apps", headers=H).json()
    assert {a["provider"] for a in apps} == {"github", "gitee"} and not any(a["configured"] for a in apps)
    assert apps[0]["callback_url"].endswith("/api/git/oauth/github/callback")
    # 未配置时不能发起授权
    assert c.get("/api/git/oauth/gitee/authorize", headers=H).status_code == 400
    # 非管理员不能配置
    assert c.put("/api/git/oauth/apps/gitee", json={"client_id": "x", "client_secret": "y"}, headers={"Authorization": f"Bearer {tok2}"}).status_code == 403
    apps = c.put("/api/git/oauth/apps/gitee", json={"client_id": "cid", "client_secret": "sec"}, headers=H).json()
    assert next(a for a in apps if a["provider"] == "gitee")["configured"]
    # 非管理员看不到 client_id
    apps2 = c.get("/api/git/oauth/apps", headers={"Authorization": f"Bearer {tok2}"}).json()
    assert next(a for a in apps2 if a["provider"] == "gitee") ["client_id"] == "" and next(a for a in apps2 if a["provider"] == "gitee")["configured"]
    auth = c.get("/api/git/oauth/gitee/authorize", headers=H).json()
    print("authorize:", auth["url"][:80])
    assert auth["url"].startswith("https://gitee.com/oauth/authorize?client_id=cid")
    # 回调:坏 state → 跳回前端带错误
    cb = c.get("/api/git/oauth/gitee/callback", params={"code": "x", "state": "bad"}, follow_redirects=False)
    assert cb.status_code == 302 and "git_error=" in cb.headers["location"], cb.headers
    cb = c.get("/api/git/oauth/gitee/callback", params={"error": "access_denied"}, follow_redirects=False)
    assert "git_error=access_denied" in cb.headers["location"]

    # 轮询:状态 / 设置(仅超管)/ 单仓库立即检查(远端无变化 → 0 事件)
    st = c.get("/api/git/poll", headers=H).json()
    assert st["minutes"] == 5 and st["running"] is False
    assert c.put("/api/git/poll", json={"minutes": 10}, headers={"Authorization": f"Bearer {tok2}"}).status_code == 403
    assert c.put("/api/git/poll", json={"minutes": 10}, headers=H).json()["minutes"] == 10
    assert c.put("/api/git/poll", json={"minutes": -1}, headers=H).status_code == 400
    # 重新接入镜像仓库以便测试轮询(前面已删)
    repo3 = c.post("/api/repos", json={"tenant_id": t["id"], "name": "odoo3", "url": "https://gitee.com/mirrors/odoo.git"}, headers=H).json()
    c.get(f"/api/repos/{repo3['id']}/branches", headers=H)  # 建立快照
    pr = c.post(f"/api/repos/{repo3['id']}/poll", headers=H).json()
    print("poll repo:", pr)
    assert pr["count"] == 0
    assert c.post("/api/git/poll/run", headers=H).json()["started"] is True
    assert c.delete(f"/api/repos/{repo3['id']}", headers=H).status_code == 204

    # 用令牌连接账号:无效令牌 → 400;非法 provider → 422
    bad = c.post("/api/git/accounts/token", json={"provider": "gitee", "token": "invalid-token-xyz"}, headers=H)
    print("link by bad token:", bad.status_code, bad.json()["detail"])
    assert bad.status_code == 400
    assert c.post("/api/git/accounts/token", json={"provider": "gitlab", "token": "invalid-token-xyz"}, headers=H).status_code == 422

    # 直接塞一个假账号,验证账号相关的仓库流程(令牌无效 → 远端操作应优雅失败)
    from app.db import SessionLocal
    from app.models_git import GitAccount

    with SessionLocal() as s:
        acc = GitAccount(user_id=1, provider="gitee", login="fake", access_token="invalid-token")
        s.add(acc)
        s.commit()
        acc_id = acc.id
    accs = c.get("/api/git/accounts", headers=H).json()
    assert [a["login"] for a in accs] == ["fake"] and "access_token" not in accs[0]
    assert c.get("/api/git/accounts", headers={"Authorization": f"Bearer {tok2}"}).json() == []
    assert c.get(f"/api/git/accounts/{acc_id}", headers={"Authorization": f"Bearer {tok2}"}).status_code in (404, 405)
    r = c.get(f"/api/git/accounts/{acc_id}/repos", headers=H)
    print("remote repos with bad token:", r.status_code, r.json())
    assert r.status_code == 502
    # 账号与仓库平台不匹配
    bad = c.post("/api/repos", json={"tenant_id": t["id"], "name": "gh", "url": "https://github.com/odoo/odoo", "account_id": acc_id}, headers=H)
    assert bad.status_code == 400, bad.text
    # 用账号接入公开仓库:分支能读(smart-HTTP 带无效令牌会 401 → 这是预期:令牌无效)
    repo2 = c.post("/api/repos", json={"tenant_id": t["id"], "name": "odoo2", "url": "https://gitee.com/mirrors/odoo", "account_id": acc_id, "auto_webhook": True}, headers=H).json()
    print("repo via account:", repo2["account_login"], "webhook_id:", repo2["webhook_id"], "| last_error:", repo2["last_error"])
    assert repo2["account_login"] == "fake" and repo2["has_token"] and repo2["webhook_id"] is None and "Webhook" in (repo2["last_error"] or "")
    nb = c.post(f"/api/repos/{repo2['id']}/branches", json={"name": "feat-x", "from_branch": "19.0"}, headers=H)
    assert nb.status_code == 502, nb.text
    # 断开账号 → 仓库保留、凭据清空
    assert c.delete(f"/api/git/accounts/{acc_id}", headers=H).status_code == 204
    repo2 = c.get(f"/api/repos/{repo2['id']}", headers=H).json()
    assert repo2["account_id"] is None and not repo2["has_token"]
    nb = c.post(f"/api/repos/{repo2['id']}/branches", json={"name": "feat-x", "from_branch": "19.0"}, headers=H)
    assert nb.status_code == 400, nb.text
    print("E2E OK")
