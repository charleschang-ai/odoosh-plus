"""services/gitpoll.py:轮询比对逻辑(ls_remote 被 mock,SQLite)。在 api 容器里运行。"""

import json

import pytest

from app.db import Base, SessionLocal, engine
from app import models, models_git  # noqa: F401
from app.models import Tenant, Environment
from app.models_git import PushEvent, Repository
from app.services import git as gitsvc
from app.services import gitpoll


@pytest.fixture()
def repo():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        t = Tenant(slug="poll-t", name="Poll")
        db.add(t)
        db.flush()
        r = Repository(tenant_id=t.id, name="r", url="https://gitee.com/o/r.git", provider="gitee", owner="o", repo="r", webhook_secret="s")
        db.add(r)
        db.flush()
        e = Environment(tenant_id=t.id, name="stag", kind="staging", repo_url="https://gitee.com/O/R", branch="main")
        db.add(e)
        db.commit()
        yield r.id, e.id
        for ev in db.scalars(db.query(PushEvent).where(PushEvent.repository_id == r.id).statement).all():
            db.delete(ev)
        db.delete(db.get(Environment, e.id)); db.delete(db.get(Repository, r.id)); db.delete(db.get(Tenant, t.id))
        db.commit()


def test_poll_first_time_only_snapshots(monkeypatch, repo):
    rid, _ = repo
    monkeypatch.setattr(gitsvc, "ls_remote", lambda url, token=None: ({"main": "a" * 40, "dev": "b" * 40}, "main"))
    monkeypatch.setattr(gitsvc, "fetch_commit", lambda *a, **k: None)
    assert gitpoll.poll_repo(rid) == []
    with SessionLocal() as db:
        r = db.get(Repository, rid)
        snap = json.loads(r.branches_json)
        assert {b["name"] for b in snap["branches"]} == {"main", "dev"} and r.default_branch == "main"
        assert db.scalar(db.query(PushEvent).where(PushEvent.repository_id == rid).statement) is None


def test_poll_detects_change_new_and_removed(monkeypatch, repo):
    rid, env_id = repo
    monkeypatch.setattr(gitsvc, "ls_remote", lambda url, token=None: ({"main": "a" * 40, "dev": "b" * 40}, "main"))
    monkeypatch.setattr(gitsvc, "fetch_commit", lambda *a, **k: None)
    gitpoll.poll_repo(rid)  # 建立基线

    hooks = []
    gitsvc._push_hooks.clear()
    gitsvc.register_push_hook(lambda repo_id, env_ids, info: hooks.append((repo_id, env_ids, info["branch"], info["sha"])))
    monkeypatch.setattr(gitsvc, "ls_remote", lambda url, token=None: ({"main": "c" * 40, "feat": "d" * 40}, "main"))
    monkeypatch.setattr(gitsvc, "fetch_commit", lambda info, sha, token: {"message": "fix: x\nmore", "author": "Ann", "date": "2026-01-01T00:00:00Z"})
    found = gitpoll.poll_repo(rid)
    gitsvc._push_hooks.clear()

    by_branch = {f["branch"]: f for f in found}
    assert set(by_branch) == {"main", "feat", "dev"}
    assert by_branch["main"]["environments"] == [env_id]  # main 绑定了 stag 实例
    assert by_branch["feat"]["environments"] == []
    assert by_branch["dev"].get("deleted") is True
    assert hooks == [(rid, [env_id], "main", "c" * 40)]  # 只有绑定实例的分支触发部署回调

    with SessionLocal() as db:
        evs = db.scalars(db.query(PushEvent).where(PushEvent.repository_id == rid).order_by(PushEvent.id).statement).all()
        assert [(e.branch, e.deleted, e.pusher) for e in evs] == [("main", False, "轮询"), ("feat", False, "轮询"), ("dev", True, "轮询")]
        assert evs[0].commit_message == "fix: x" and evs[0].author == "Ann"
        assert evs[0].result == "已触发 1 个环境重新部署"
        assert evs[1].result == "已记录;无绑定环境"
        snap = json.loads(db.get(Repository, rid).branches_json)
        assert {b["name"]: b["sha"] for b in snap["branches"]} == {"main": "c" * 40, "feat": "d" * 40}

    # 再轮询一次:无变化 → 无事件
    assert gitpoll.poll_repo(rid) == []


def test_poll_error_recorded(monkeypatch, repo):
    rid, _ = repo

    def boom(url, token=None):
        raise RuntimeError("认证失败")

    monkeypatch.setattr(gitsvc, "ls_remote", boom)
    assert gitpoll.poll_repo(rid) == []
    with SessionLocal() as db:
        assert "轮询失败:认证失败" in db.get(Repository, rid).last_error


def test_interval_setting():
    with SessionLocal() as db:
        assert gitpoll.get_interval(db) == gitpoll.POLL_DEFAULT
        gitpoll.set_interval(db, 0)
        assert gitpoll.get_interval(db) == 0
        gitpoll.set_interval(db, 15)
        assert gitpoll.get_interval(db) == 15
