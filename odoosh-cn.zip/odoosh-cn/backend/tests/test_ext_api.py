"""/api/ext/* 的 HTTP 层集成测试:走完整的路由 → 认证 → 服务层 → 错误码 路径。

与 test_ext_sync.py 的分工:那边测服务层逻辑,这里测 HTTP 契约 ——
Bearer 认证、scope 校验、错误响应里的 code 字段、幂等语义。接入方按这些契约写重试逻辑。

运行:cd backend && python3 -m pytest -q tests/test_ext_api.py
(需要 httpx;没有时整个文件跳过,不影响其余测试)
"""

import pytest

pytest.importorskip("httpx", reason="需要 httpx 才能用 FastAPI TestClient")

from fastapi.testclient import TestClient  # noqa: E402

from app.db import Base, SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Environment, Membership, Tenant, User  # noqa: E402
from app.models_token import ApiToken  # noqa: E402
from app.services import apitokens as toksvc  # noqa: E402

T = 9401
U_ADMIN = 9401
SRC = "httptest-src"


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def _cleanup(db):
    """清掉本模块造的数据。成员关系必须显式删:SQLite 默认不启用外键,
    ondelete=CASCADE 不生效,残留的成员关系会被后续复用同一自增 ID 的新用户认领。"""
    from sqlalchemy import select

    uids = [u for (u,) in db.execute(select(User.id).where(User.external_source == SRC)).all()]
    db.execute(Environment.__table__.delete().where(Environment.tenant_id == T))
    db.execute(Membership.__table__.delete().where(Membership.tenant_id == T))
    if uids:
        db.execute(Membership.__table__.delete().where(Membership.user_id.in_(uids)))
    db.execute(User.__table__.delete().where(User.external_source == SRC))
    db.commit()


@pytest.fixture(scope="module", autouse=True)
def seed():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        _cleanup(db)
        db.execute(ApiToken.__table__.delete().where(ApiToken.user_id == U_ADMIN))
        if not db.get(Tenant, T):
            db.add(Tenant(id=T, slug="httpext", name="接口测试组织"))
        if not db.get(User, U_ADMIN):
            db.add(User(id=U_ADMIN, username="http_admin", password_hash="x", role="admin"))
        db.commit()
    yield
    with SessionLocal() as db:
        _cleanup(db)


def _make_token(**kw):
    plain, digest, prefix = toksvc.generate()
    with SessionLocal() as db:
        kw.setdefault("scopes", "handoff,users:write,envs:read,envs:write")
        tok = ApiToken(user_id=U_ADMIN, tenant_id=T, name="http", prefix=prefix, token_hash=digest,
                       source=SRC, max_envs_per_user=0, **kw)  # 0 = 不自动开实例,测试不碰 docker
        db.add(tok)
        db.commit()
    return plain


def _h(token):
    return {"Authorization": "Bearer %s" % token}


def test_auth_required(client):
    r = client.post("/api/ext/users", json={"external_id": "1", "username": "x1"})
    assert r.status_code == 401
    r = client.post("/api/ext/users", json={"external_id": "1", "username": "x1"},
                    headers={"Authorization": "Bearer osh_wrong"})
    assert r.status_code == 401
    assert r.json()["code"] == "token_invalid"          # 稳定错误码,接入方据此判断不重试


def test_scope_enforced(client):
    token = _make_token(scopes="handoff")               # 只有免登权限
    r = client.post("/api/ext/users", json={"external_id": "2", "username": "http_x2"}, headers=_h(token))
    assert r.status_code == 403 and r.json()["code"] == "scope_denied"


def test_upsert_idempotent_over_http(client):
    token = _make_token()
    body = {"external_id": "100", "username": "http_s100", "display_name": "张三",
            "tenant_role": "developer", "menus": {"repos": False, "ai": True},
            "quota": {"max_envs": 1}}
    r1 = client.post("/api/ext/users", json=body, headers=_h(token))
    assert r1.status_code == 200, r1.text
    d1 = r1.json()
    assert d1["created"] is True and d1["tenant_id"] == T

    r2 = client.post("/api/ext/users", json=body, headers=_h(token))
    assert r2.status_code == 200
    d2 = r2.json()
    assert d2["created"] is False and d2["user_id"] == d1["user_id"]   # 幂等:同一账号

    with SessionLocal() as db:
        u = db.get(User, d1["user_id"])
        assert u.role == "member" and u.menu_repos is False and u.menu_ai is True
        assert db.query(Membership).filter(Membership.user_id == u.id).one().tenant_id == T


def test_validation_error_codes(client):
    token = _make_token()
    r = client.post("/api/ext/users", json={"external_id": "101", "username": "bad name"}, headers=_h(token))
    assert r.status_code == 400 and r.json()["code"] == "invalid_username"

    client.post("/api/ext/users", json={"external_id": "102", "username": "http_s102"}, headers=_h(token))
    r = client.post("/api/ext/users", json={"external_id": "103", "username": "http_s102"}, headers=_h(token))
    assert r.status_code == 409 and r.json()["code"] == "username_taken"

    tok_low = _make_token(max_grant_role="developer")
    r = client.post("/api/ext/users", json={"external_id": "104", "username": "http_s104", "tenant_role": "owner"},
                    headers=_h(tok_low))
    assert r.status_code == 403 and r.json()["code"] == "exceeds_token_limit"


def test_envs_and_handoff(client):
    token = _make_token()
    r = client.post("/api/ext/users", json={"external_id": "200", "username": "http_s200"}, headers=_h(token))
    uid = r.json()["user_id"]

    # 没有实例时:envs 返回空列表,console 免登仍可用(落在实例列表页)
    r = client.get("/api/ext/envs", params={"uid": "200"}, headers=_h(token))
    assert r.status_code == 200 and r.json()["envs"] == []

    r = client.post("/api/ext/handoff", json={"uid": "200"}, headers=_h(token))
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["target"] == "console" and "/auth/callback?code=" in d["url"] and d["env_id"] is None

    # target=odoo 需要实例,没有则 404
    r = client.post("/api/ext/handoff", json={"uid": "200", "target": "odoo"}, headers=_h(token))
    assert r.status_code == 404 and r.json()["code"] == "not_found"

    # 用户名与 external_id 两种标识都能解析
    r = client.post("/api/ext/handoff", json={"uid": "http_s200"}, headers=_h(token))
    assert r.status_code == 200 and r.json()["user_id"] == uid

    # 有实例后 envs 能查到
    with SessionLocal() as db:
        db.add(Environment(tenant_id=T, name="http-env", kind="dev", owner_user_id=uid, status="running"))
        db.commit()
    r = client.get("/api/ext/envs", params={"uid": "200"}, headers=_h(token))
    envs = r.json()["envs"]
    assert len(envs) == 1 and envs[0]["name"] == "http-env" and envs[0]["status"] == "running"


def test_deactivate_and_reconcile(client):
    token = _make_token()
    for i in range(3):
        client.post("/api/ext/users", json={"external_id": "30%s" % i, "username": "http_r%s" % i}, headers=_h(token))

    r = client.post("/api/ext/users/deactivate", json={"external_id": "300", "stop_envs": False}, headers=_h(token))
    assert r.status_code == 200 and r.json()["was_active"] is True

    r = client.post("/api/ext/users/deactivate", json={"external_id": "nope"}, headers=_h(token))
    assert r.status_code == 404 and r.json()["code"] == "user_not_found"

    # 空名单会停用整个来源 → 必须显式确认
    r = client.post("/api/ext/users/reconcile", json={"external_ids": [], "stop_envs": False}, headers=_h(token))
    assert r.status_code == 400 and r.json()["code"] == "empty_list"

    # 名单只留 2 人,其余在册账号都要停用 → 超过 30% 保护阈值,被拦下
    r = client.post("/api/ext/users/reconcile",
                    json={"external_ids": ["301", "302"], "stop_envs": False}, headers=_h(token))
    assert r.status_code == 409 and r.json()["code"] == "too_many_deactivations"

    # 确认后放行
    r = client.post("/api/ext/users/reconcile",
                    json={"external_ids": ["301", "302"], "stop_envs": False, "confirm": True}, headers=_h(token))
    assert r.status_code == 200 and r.json()["deactivated"] >= 1

    with SessionLocal() as db:
        kept = db.query(User).filter(User.external_source == SRC, User.external_id.in_(["301", "302"])).all()
        assert all(u.is_active for u in kept)  # 名单内的账号不受影响


def test_provision_limit_over_http(client):
    token = _make_token()      # max_envs_per_user=0
    client.post("/api/ext/users", json={"external_id": "400", "username": "http_s400"}, headers=_h(token))
    r = client.post("/api/ext/envs", json={"uid": "400", "name": "http-new"}, headers=_h(token))
    assert r.status_code == 403 and r.json()["code"] == "provision_not_allowed"


def test_full_parameter_set_over_http(client):
    """接入方可传的全部用户参数一次走通:平台角色、组织、组织角色、配额、菜单、Shell、企业版。"""
    token = _make_token(max_grant_role="owner")
    body = {"external_id": "500", "username": "http_s500", "display_name": "全参数",
            "role": "member", "tenant_role": "owner", "shell_enabled": False, "can_use_enterprise": True,
            "quota": {"max_envs": 2, "max_dbs": 3},
            "menus": {"dashboard": True, "repos": False, "ai": True, "backups": False}}
    r = client.post("/api/ext/users", json=body, headers=_h(token))
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["role"] == "member" and d["tenant_role"] == "owner" and d["tenant_slug"] == "httpext"
    with SessionLocal() as db:
        u = db.get(User, d["user_id"])
        assert (u.max_envs, u.max_dbs, u.shell_enabled, u.can_use_enterprise) == (2, 3, False, True)
        assert (u.menu_dashboard, u.menu_repos, u.menu_ai, u.menu_backups) == (True, False, True, False)

    # 只传变化的部分:未提及的字段保持原值
    r = client.post("/api/ext/users", json={"external_id": "500", "username": "http_s500",
                                            "tenant_role": "owner", "display_name": "改名"}, headers=_h(token))
    assert r.status_code == 200
    with SessionLocal() as db:
        u = db.get(User, d["user_id"])
        assert u.display_name == "改名" and u.max_envs == 2 and u.shell_enabled is False

    # 平台管理员角色与跨组织默认都被令牌拒绝
    r = client.post("/api/ext/users", json={"external_id": "501", "username": "http_s501", "role": "admin"},
                    headers=_h(token))
    assert r.status_code == 403 and r.json()["code"] == "exceeds_token_limit"
    r = client.post("/api/ext/users", json={"external_id": "502", "username": "http_s502", "tenant": "somewhere"},
                    headers=_h(token))
    assert r.status_code == 403 and r.json()["code"] == "exceeds_token_limit"


def test_ping(client):
    """探测接口:只验令牌,不要求 scope,不依赖已同步用户;回显组织、权限范围与上限。"""
    r = client.get("/api/ext/ping")
    assert r.status_code == 401
    r = client.get("/api/ext/ping", headers={"Authorization": "Bearer osh_wrong"})
    assert r.status_code == 401 and r.json()["code"] == "token_invalid"

    token = _make_token(scopes="handoff", allow_any_tenant=True)   # 最小权限也能 ping
    r = client.get("/api/ext/ping", headers=_h(token))
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["ok"] is True and d["tenant_id"] == T and d["tenant_slug"] == "httpext"
    assert d["scopes"] == ["handoff"] and d["source"] == SRC
    assert d["limits"]["allow_any_tenant"] is True and d["limits"]["allow_admin_role"] is False
    assert d["version"] and d["server_time"]


def test_token_update_endpoint(client):
    """超管编辑已有令牌的权限范围与上限:令牌明文不变,改动对下一次请求立即生效。"""
    from app.auth import create_token, hash_password

    with SessionLocal() as db:
        admin = db.get(User, U_ADMIN)
        admin.password_hash = hash_password("pw-for-test")  # 身份确认凭据要核对密码
        db.commit()
        jwt = {"Authorization": "Bearer " + create_token(admin)}  # 登录页有验证码,直接签发登录令牌

    token = _make_token(scopes="handoff")                    # 只有免登
    r = client.get("/api/ext/ping", headers=_h(token))
    assert r.json()["scopes"] == ["handoff"]
    tok_id = next(t["id"] for t in client.get("/api/tokens", headers=jwt).json() if t["scopes"] == "handoff")

    grant = client.post("/api/tokens/verify-identity", json={"password": "pw-for-test"}, headers=jwt).json()["grant"]
    r = client.put("/api/tokens/%s" % tok_id, headers=jwt, json={
        "grant": grant, "scopes": ["handoff", "users:write", "envs:read", "envs:write"],
        "max_grant_role": "owner", "allow_any_tenant": True})
    assert r.status_code == 200, r.text
    assert r.json()["scopes"] == "handoff,users:write,envs:read,envs:write"

    # 同一个令牌明文,权限已变;之前被拒的写接口现在放行
    r = client.get("/api/ext/ping", headers=_h(token))
    assert set(r.json()["scopes"]) == {"handoff", "users:write", "envs:read", "envs:write"}
    assert r.json()["limits"]["allow_any_tenant"] is True and r.json()["limits"]["max_grant_role"] == "owner"
    r = client.post("/api/ext/users", json={"external_id": "600", "username": "http_s600"}, headers=_h(token))
    assert r.status_code == 200

    # 没有身份确认凭据 → 403;吊销后不能再编辑 → 409
    r = client.put("/api/tokens/%s" % tok_id, headers=jwt, json={"grant": "bad", "scopes": ["handoff"]})
    assert r.status_code == 403
    client.delete("/api/tokens/%s" % tok_id, headers=jwt)
    grant = client.post("/api/tokens/verify-identity", json={"password": "pw-for-test"}, headers=jwt).json()["grant"]
    r = client.put("/api/tokens/%s" % tok_id, headers=jwt, json={"grant": grant, "scopes": ["handoff"]})
    assert r.status_code == 409


def test_delete_endpoint(client):
    """HTTP 层:删除接口的权限门控与成功路径,以及 ping 回显删除开关。"""
    token = _make_token()                       # allow_delete_user 默认关
    client.post("/api/ext/users", json={"external_id": "700", "username": "http_s700"}, headers=_h(token))
    r = client.get("/api/ext/ping", headers=_h(token))
    assert r.json()["limits"]["allow_delete_user"] is False

    r = client.post("/api/ext/users/delete", json={"external_id": "700"}, headers=_h(token))
    assert r.status_code == 403 and r.json()["code"] == "delete_not_allowed"

    tok_del = _make_token(allow_delete_user=True)
    r = client.get("/api/ext/ping", headers=_h(tok_del))
    assert r.json()["limits"]["allow_delete_user"] is True
    r = client.post("/api/ext/users/delete", json={"external_id": "700"}, headers=_h(tok_del))
    assert r.status_code == 200, r.text
    assert r.json()["deleted"] is True and r.json()["username"] == "http_s700"

    # 删过之后再删 → 404;删除需要 users:write 权限
    r = client.post("/api/ext/users/delete", json={"external_id": "700"}, headers=_h(tok_del))
    assert r.status_code == 404 and r.json()["code"] == "user_not_found"
    tok_ro = _make_token(scopes="handoff", allow_delete_user=True)
    r = client.post("/api/ext/users/delete", json={"external_id": "701"}, headers=_h(tok_ro))
    assert r.status_code == 403 and r.json()["code"] == "scope_denied"
