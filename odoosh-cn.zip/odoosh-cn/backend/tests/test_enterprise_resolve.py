"""services/enterprise.resolve_repo:候选顺序 own → tenant → platform,逐个探测(连通 + 含版本分支)。probe 被 mock。"""

import os
import subprocess

import pytest

from app.db import Base, SessionLocal, engine
from app import models, models_git  # noqa: F401
from app.models import Tenant, User
from app.models_git import Repository
from app.services import enterprise as ent


@pytest.fixture()
def setup():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        t = Tenant(slug="ent-t", name="Ent")
        u1 = User(username="ent-u1", password_hash="x")
        u2 = User(username="ent-u2", password_hash="x")
        db.add_all([t, u1, u2])
        db.flush()

        def mk(name, **kw):
            r = Repository(name=name, url=f"https://gitee.com/o/{name}.git", provider="gitee", owner="o", repo=name, webhook_secret="s", is_enterprise=True, **kw)
            db.add(r)
            db.flush()
            return r.id

        ids = {
            "own_old": mk("own_old", tenant_id=t.id, created_by=u1.id),
            "own_new": mk("own_new", tenant_id=t.id, created_by=u1.id),
            "other": mk("other", tenant_id=t.id, created_by=u2.id),
            "legacy": mk("legacy", tenant_id=t.id, created_by=None),
            "plat": mk("plat", tenant_id=None, scope="platform"),
        }
        db.commit()
        yield db, t.id, u1.id, ids
        for rid in ids.values():
            db.delete(db.get(Repository, rid))
        db.delete(db.get(User, u1.id)); db.delete(db.get(User, u2.id)); db.delete(db.get(Tenant, t.id))
        db.commit()


def test_candidate_order(setup):
    db, tid, uid, ids = setup
    order = [(r.name, s) for r, s in ent.candidate_repos(db, tid, uid)]
    assert order == [("own_new", "own"), ("own_old", "own"), ("legacy", "tenant"), ("plat", "platform")]  # 别人的不在候选里
    assert [(r.name, s) for r, s in ent.candidate_repos(db, tid, None)] == [("legacy", "tenant"), ("plat", "platform")]


def test_resolve_picks_first_reachable_with_version(monkeypatch, setup):
    db, tid, uid, ids = setup
    calls = []

    def fake_probe(url, token):
        calls.append(url)
        if "own_new" in url:
            raise RuntimeError("认证失败")
        if "own_old" in url:
            return {"versions": {"17": "a" * 40}, "default_branch": "17.0", "branch_count": 1}
        return {"versions": {"18": "b" * 40, "19": "c" * 40}, "default_branch": "19.0", "branch_count": 2}

    monkeypatch.setattr(ent, "probe", fake_probe)
    repo, src, tried = ent.resolve_repo(db, tid, uid, "19")
    assert (repo.name, src) == ("legacy", "tenant")
    assert [(t["source"], t["ok"]) for t in tried] == [("own", False), ("own", False), ("tenant", True)]
    assert "认证失败" in tried[0]["reason"] and "没有 19.0 分支" in tried[1]["reason"]
    assert len(calls) == 3  # 找到即停止,不再探测平台仓库

    # 版本 17 → own_old 满足
    repo, src, tried = ent.resolve_repo(db, tid, uid, "17")
    assert (repo.name, src) == ("own_old", "own")

    # 全部失败 → None + 每个候选的原因
    monkeypatch.setattr(ent, "probe", lambda url, token: (_ for _ in ()).throw(RuntimeError("超时")))
    repo, src, tried = ent.resolve_repo(db, tid, uid, "19")
    assert repo is None and src == "" and len(tried) == 4 and all(not t["ok"] for t in tried)
    msg = ent.describe_failure(tried)
    assert "所有企业版仓库均不可用" in msg and "平台共享企业版仓库「plat」" in msg


def test_resolve_local_first(monkeypatch, tmp_path, setup):
    """本地优先:已有完整拉取的版本目录 → 直接采用,完全不联网(probe 不被调用)。"""
    db, tid, uid, ids = setup
    monkeypatch.setattr(ent.settings, "data_dir", str(tmp_path))
    d = tmp_path / "enterprise" / str(ids["own_new"]) / ("19.0@" + "a" * 12)
    d.mkdir(parents=True)
    (d / ".odoosh-commit").write_text("a" * 40 + "\n")
    d2 = tmp_path / "enterprise" / str(ids["own_old"]) / ("19.0@" + "b" * 12)  # 无完成标记 → 不算
    d2.mkdir(parents=True)
    calls = []
    monkeypatch.setattr(ent, "probe", lambda url, token: calls.append(url) or (_ for _ in ()).throw(RuntimeError("超时")))

    repo, src, tried = ent.resolve_repo(db, tid, uid, "19")
    assert repo is not None and repo.id == ids["own_new"] and src == "own"
    assert tried[-1]["ok"] is True and "本地已有" in tried[-1]["reason"]
    assert calls == []  # 本地命中即不联网

    path, sha = ent.local_fallback(repo, "19")
    assert sha == "a" * 40 and path.endswith("19.0@" + "a" * 12)
    assert ent.local_fallback(db.get(Repository, ids["own_old"]), "19") is None  # 未完成的目录不作降级

    repo2, _, _ = ent.resolve_repo(db, tid, uid, "18")  # 该版本无本地代码 → 仍然失败
    assert repo2 is None


def test_resolve_falls_back_to_mirror_import(monkeypatch, tmp_path, setup):
    """从未在线拉取过,但管理员手动把版本分支 fetch 进了 mirror.git → 探测失败时同样降级采用。"""
    db, tid, uid, ids = setup
    monkeypatch.setattr(ent.settings, "data_dir", str(tmp_path))
    r = db.get(Repository, ids["own_new"])
    md = ent.mirror_dir(r)
    subprocess.run(["git", "init", "--bare", "-q", md], check=True)
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t.t",
           "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t.t"}
    tree = subprocess.run(["git", "--git-dir", md, "mktree"], input="", capture_output=True, text=True, check=True).stdout.strip()
    sha = subprocess.run(["git", "--git-dir", md, "commit-tree", tree, "-m", "x"], capture_output=True, text=True, check=True, env=env).stdout.strip()
    subprocess.run(["git", "--git-dir", md, "update-ref", "refs/heads/19.0", sha], check=True)

    assert ent.mirror_branch_head(r, "19") == sha
    assert ent.mirror_branch_head(r, "18") is None

    monkeypatch.setattr(ent, "probe", lambda url, token: (_ for _ in ()).throw(RuntimeError("超时")))
    repo, src, tried = ent.resolve_repo(db, tid, uid, "19")
    assert repo is not None and repo.id == ids["own_new"] and src == "own"
    assert tried[-1]["ok"] is True and sha[:12] in tried[-1]["reason"]

    repo2, _, tried2 = ent.resolve_repo(db, tid, uid, "18")  # 该版本无本地代码且远端全挂 → 失败,提示附导入命令
    assert repo2 is None
    assert "手动导入" in ent.describe_failure(tried2)


def test_resolve_without_probe(setup):
    db, tid, uid, ids = setup
    repo, src, tried = ent.resolve_repo(db, tid, uid, None, probe_remote=False)
    assert (repo.name, src) == ("own_new", "own") and tried[0]["ok"] is True
    assert "未配置企业版仓库" in ent.describe_failure([])
