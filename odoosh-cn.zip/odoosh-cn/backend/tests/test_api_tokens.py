"""接入令牌(services.apitokens)回归测试。
运行:cd backend && python3 -m pytest -q tests/test_api_tokens.py

覆盖:
1. 明文 / 哈希 / 前缀;lookup 按哈希找到令牌,错误明文拒绝;
2. 失效条件:吊销、过期、创建者非超管或停用、组织停用;
3. resolve:用户名 = uid;不在组织 → PermissionError;无实例 → LookupError;根实例优先;env 指定;
4. 身份确认凭据与入口票据:正确用户通过;token_version 变化后失效;入口票据绑定实例归属。
"""

from datetime import datetime, timedelta, timezone

import pytest

from app.db import Base, SessionLocal, engine
from app.models import Environment, Membership, Tenant, User
from app.models_token import ApiToken
from app.services import apitokens as svc

T_OK, T_OFF = 9201, 9202
U_ADMIN, U_MEMBER, U_STUDENT, U_OUTSIDER, U_NOENV = 9201, 9202, 9203, 9204, 9205
E_ROOT, E_CHILD, E_OTHER = 9201, 9202, 9203


@pytest.fixture(scope="module", autouse=True)
def seed():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        db.execute(ApiToken.__table__.delete().where(ApiToken.user_id.in_([U_ADMIN, U_MEMBER])))
        db.execute(Environment.__table__.delete().where(Environment.id.in_([E_ROOT, E_CHILD, E_OTHER])))
        db.execute(Membership.__table__.delete().where(Membership.user_id.in_([U_STUDENT, U_OUTSIDER, U_NOENV, U_MEMBER])))
        for tid, active in ((T_OK, True), (T_OFF, False)):
            if not db.get(Tenant, tid):
                db.add(Tenant(id=tid, slug=f"tok{tid}", name=f"组织{tid}", is_active=active))
        for uid, name, role in ((U_ADMIN, "tok_admin", "admin"), (U_MEMBER, "tok_member", "member"),
                                (U_STUDENT, "2024010233", "member"), (U_OUTSIDER, "tok_outsider", "member"),
                                (U_NOENV, "tok_noenv", "member")):
            if not db.get(User, uid):
                db.add(User(id=uid, username=name, password_hash="x", role=role))
        db.commit()
        db.add(Membership(user_id=U_STUDENT, tenant_id=T_OK, role="developer"))
        db.add(Membership(user_id=U_NOENV, tenant_id=T_OK, role="developer"))
        db.add(Membership(user_id=U_OUTSIDER, tenant_id=T_OFF, role="developer"))
        # 学生在 T_OK 下:一个派生实例(id 小)+ 一个根实例 → 应取根实例;另一个实例属于别人
        db.add(Environment(id=E_CHILD, tenant_id=T_OK, name="feature", kind="dev", owner_user_id=U_STUDENT, project_id=E_ROOT))
        db.add(Environment(id=E_ROOT, tenant_id=T_OK, name="main", kind="dev", owner_user_id=U_STUDENT, status="running", url="http://x"))
        db.add(Environment(id=E_OTHER, tenant_id=T_OK, name="other", kind="dev", owner_user_id=99999))
        db.commit()
    yield


def _token(db, user_id=U_ADMIN, tenant_id=T_OK, **kw):
    plain, digest, prefix = svc.generate()
    tok = ApiToken(user_id=user_id, tenant_id=tenant_id, name="t", prefix=prefix, token_hash=digest, **kw)
    db.add(tok)
    db.commit()
    db.refresh(tok)
    return plain, tok


def test_generate_and_lookup():
    plain, digest, prefix = svc.generate()
    assert plain.startswith(svc.PREFIX) and len(plain) > 30
    assert digest == svc.hash_token(plain) and len(digest) == 64
    assert prefix == plain[:12]
    with SessionLocal() as db:
        plain, tok = _token(db)
        assert svc.lookup(db, plain).id == tok.id
        assert svc.lookup(db, f"  {plain}  ").id == tok.id  # 容忍首尾空白
        for bad in (None, "", "abc", plain[:-1] + "x", "osh_" + "a" * 43):
            with pytest.raises(ValueError):
                svc.lookup(db, bad)


def test_invalid_conditions():
    with SessionLocal() as db:
        p1, t1 = _token(db, revoked_at=datetime.now(timezone.utc))
        p2, t2 = _token(db, expires_at=datetime.now(timezone.utc) - timedelta(seconds=1))
        p3, t3 = _token(db, user_id=U_MEMBER)          # 创建者不是超管
        p4, t4 = _token(db, tenant_id=T_OFF)           # 组织停用
        p5, t5 = _token(db, expires_at=datetime.now(timezone.utc) + timedelta(days=1))
        for p, msg in ((p1, "吊销"), (p2, "过期"), (p3, "超级管理员"), (p4, "组织")):
            with pytest.raises(ValueError) as ei:
                svc.lookup(db, p)
            assert msg in str(ei.value)
        assert svc.lookup(db, p5).id == t5.id
        assert svc.status_of(t1) == "revoked" and svc.status_of(t2) == "expired" and svc.status_of(t5) == "active"


def test_resolve():
    with SessionLocal() as db:
        _, tok = _token(db)
        user, env = svc.resolve(db, tok, "2024010233")
        assert user.id == U_STUDENT and env.id == E_ROOT  # 根实例优先于派生实例
        _, env2 = svc.resolve(db, tok, "2024010233", "feature")
        assert env2.id == E_CHILD
        with pytest.raises(LookupError):
            svc.resolve(db, tok, "2024010233", "nope")
        with pytest.raises(LookupError):
            svc.resolve(db, tok, "no_such_user")
        with pytest.raises(LookupError):
            svc.resolve(db, tok, "tok_noenv")  # 成员但没有实例
        with pytest.raises(PermissionError):
            svc.resolve(db, tok, "tok_outsider")  # 不在令牌组织
        with pytest.raises(ValueError):
            svc.resolve(db, tok, "   ")


def test_resolve_user_without_env_and_login_code():
    """target=console:成员即可,不要求有实例;code 一次性、绑定令牌与用户。"""
    with SessionLocal() as db:
        _, tok = _token(db)
        noenv = svc.resolve_user(db, tok, "tok_noenv")  # 没实例也能登控制台
        assert noenv.id == U_NOENV
        with pytest.raises(LookupError):
            svc.resolve_env(db, tok, noenv)
        with pytest.raises(PermissionError):
            svc.resolve_user(db, tok, "tok_outsider")
        code = svc.make_login_code(tok, noenv)
        tok2, user2 = svc.redeem_login_code(db, code)
        assert (tok2.id, user2.id) == (tok.id, U_NOENV)
        with pytest.raises(ValueError) as ei:
            svc.redeem_login_code(db, code)  # 一次性
        assert "使用过" in str(ei.value)
        with pytest.raises(ValueError):
            svc.redeem_login_code(db, "garbage")
        # 入口票据(ext-open)不能当 code 用,反之亦然
        student, env = svc.resolve(db, tok, "2024010233")
        with pytest.raises(ValueError):
            svc.redeem_login_code(db, svc.make_open_ticket(tok, student, env))
        with pytest.raises(ValueError):
            svc.read_open_ticket(db, svc.make_login_code(tok, student))
        # 令牌吊销后 code 失效
        code2 = svc.make_login_code(tok, student)
        tok.revoked_at = datetime.now(timezone.utc)
        db.commit()
        with pytest.raises(ValueError):
            svc.redeem_login_code(db, code2)
        tok.revoked_at = None
        db.commit()


def test_identity_grant_and_open_ticket():
    with SessionLocal() as db:
        admin = db.get(User, U_ADMIN)
        other = db.get(User, U_MEMBER)
        grant = svc.issue_identity_grant(admin)
        svc.check_identity_grant(grant, admin)
        with pytest.raises(ValueError):
            svc.check_identity_grant(grant, other)  # 凭据绑定用户
        with pytest.raises(ValueError):
            svc.check_identity_grant("garbage", admin)

        _, tok = _token(db)
        student, env = svc.resolve(db, tok, "2024010233")
        t = svc.make_open_ticket(tok, student, env)
        tok2, user2, env2 = svc.read_open_ticket(db, t)
        assert (tok2.id, user2.id, env2.id) == (tok.id, U_STUDENT, E_ROOT)
        tok2, user2, env2 = svc.read_open_ticket(db, t)  # 可重复使用(等待页刷新)
        assert env2.id == E_ROOT
        # 令牌吊销后入口票据随之失效
        tok.revoked_at = datetime.now(timezone.utc)
        db.commit()
        with pytest.raises(ValueError):
            svc.read_open_ticket(db, t)
        tok.revoked_at = None
        db.commit()
        # 用户改密(token_version +1)后失效
        student.token_version = int(student.token_version or 0) + 1
        db.commit()
        with pytest.raises(ValueError):
            svc.read_open_ticket(db, t)
        with pytest.raises(ValueError):
            svc.read_open_ticket(db, "not-a-jwt")
