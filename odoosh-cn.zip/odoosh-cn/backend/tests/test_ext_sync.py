"""第三方身份同步(services/extsync.py)回归测试。
运行:cd backend && python3 -m pytest -q tests/test_ext_sync.py

覆盖:
1. upsert 幂等:同一 external_id 反复调用只有一个账号,第二次起 created=False;
2. 平台边界:恒落在令牌组织、恒为 member 角色、随机密码;
3. 令牌上限:角色不得超过 max_grant_role、不允许建号时拒绝、每人实例数上限;
4. 用户名冲突、非法用户名的错误码;实例名的规范化(接入方的下划线 / 点 / 大写不该报错);
5. 停用:置 is_active=False 并 bump token_version(使已发令牌失效),不删除;
6. 对账:名单外停用;名单为空 / 停用比例过高时拒绝,confirm 后放行;
7. 权限范围 check_scope。
"""

import pytest
from sqlalchemy import select

from app.db import Base, SessionLocal, engine
from app.models import Environment, Membership, Tenant, User
from app.models_token import ApiToken
from app.services import apitokens as toksvc
from app.services import extsync

T_MAIN, T_OTHER = 9301, 9302
U_ADMIN = 9301
SRC = "unittest-src"


@pytest.fixture(scope="module", autouse=True)
def seed():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        db.execute(Environment.__table__.delete().where(Environment.tenant_id.in_([T_MAIN, T_OTHER])))
        db.execute(Membership.__table__.delete().where(Membership.tenant_id.in_([T_MAIN, T_OTHER])))
        db.execute(User.__table__.delete().where(User.external_source == SRC))
        db.execute(ApiToken.__table__.delete().where(ApiToken.user_id == U_ADMIN))
        for tid in (T_MAIN, T_OTHER):
            if not db.get(Tenant, tid):
                db.add(Tenant(id=tid, slug=f"ext{tid}", name=f"组织{tid}"))
        if not db.get(User, U_ADMIN):
            db.add(User(id=U_ADMIN, username="ext_admin", password_hash="x", role="admin"))
        db.commit()
    yield
    with SessionLocal() as db:  # 不给后续测试留脏数据
        # 成员关系必须显式删:SQLite 默认不启用外键,残留的成员关系会被复用同一自增 ID 的新用户认领
        uids = [u for (u,) in db.execute(select(User.id).where(User.external_source == SRC)).all()]
        db.execute(Environment.__table__.delete().where(Environment.tenant_id.in_([T_MAIN, T_OTHER])))
        db.execute(Membership.__table__.delete().where(Membership.tenant_id.in_([T_MAIN, T_OTHER])))
        if uids:
            db.execute(Membership.__table__.delete().where(Membership.user_id.in_(uids)))
        db.execute(User.__table__.delete().where(User.external_source == SRC))
        db.commit()


def _tok(db, **kw):
    plain, digest, prefix = toksvc.generate()
    kw.setdefault("scopes", "handoff,users:write,envs:read,envs:write")
    kw.setdefault("source", SRC)
    tok = ApiToken(user_id=U_ADMIN, tenant_id=kw.pop("tenant_id", T_MAIN), name="t", prefix=prefix,
                   token_hash=digest, **kw)
    db.add(tok)
    db.commit()
    db.refresh(tok)
    return tok


def _payload(ext_id, username, **kw):
    base = {"external_id": ext_id, "username": username, "display_name": "张三",
            "tenant_role": "developer", "active": True, "quota": None, "menus": None, "provision": None}
    base.update(kw)
    return base


def test_upsert_is_idempotent():
    with SessionLocal() as db:
        tok = _tok(db)
        a = extsync.upsert_user(db, tok, _payload("1001", "ext_s1001"))
        db.commit()
        assert a["created"] is True and a["tenant_id"] == T_MAIN and a["tenant_role"] == "developer"
        b = extsync.upsert_user(db, tok, _payload("1001", "ext_s1001"))
        db.commit()
        assert b["created"] is False and b["user_id"] == a["user_id"]
        # 只建了一个账号
        n = len(db.query(User).filter(User.external_source == SRC, User.external_id == "1001").all())
        assert n == 1
        u = db.get(User, a["user_id"])
        assert u.role == "member"                 # 平台角色恒为普通成员
        assert u.external_source == SRC
        assert len(u.password_hash) > 20          # 随机密码已哈希
        # 成员关系落在令牌组织,且只有一条
        ms = db.query(Membership).filter(Membership.user_id == u.id).all()
        assert len(ms) == 1 and ms[0].tenant_id == T_MAIN


def test_upsert_updates_fields_and_role():
    with SessionLocal() as db:
        tok = _tok(db, max_grant_role="owner")
        r = extsync.upsert_user(db, tok, _payload("1002", "ext_s1002"))
        db.commit()
        uid = r["user_id"]
        extsync.upsert_user(db, tok, _payload("1002", "ext_s1002b", display_name="李四",
                                              tenant_role="owner", shell_enabled=True,
                                              quota={"max_envs": 3}, menus={"repos": False, "ai": True}))
        db.commit()
        u = db.get(User, uid)
        assert u.username == "ext_s1002b" and u.display_name == "李四"
        assert u.shell_enabled is True and u.max_envs == 3
        assert u.menu_repos is False and u.menu_ai is True
        m = db.query(Membership).filter(Membership.user_id == uid).one()
        assert m.role == "owner"


def test_token_limits():
    with SessionLocal() as db:
        # 上限 developer:不能授予 owner
        tok = _tok(db, max_grant_role="developer")
        with pytest.raises(extsync.SyncError) as ei:
            extsync.upsert_user(db, tok, _payload("1003", "ext_s1003", tenant_role="owner"))
        assert ei.value.code == "exceeds_token_limit" and ei.value.status == 403
        db.rollback()
        # 不允许建号
        tok2 = _tok(db, allow_create_user=False)
        with pytest.raises(extsync.SyncError) as ei:
            extsync.upsert_user(db, tok2, _payload("1004", "ext_s1004"))
        assert ei.value.code == "create_not_allowed"
        db.rollback()
        # 但可以更新已存在的
        extsync.upsert_user(db, tok, _payload("1004", "ext_s1004"))
        db.commit()
        out = extsync.upsert_user(db, tok2, _payload("1004", "ext_s1004", display_name="改名"))
        db.commit()
        assert out["created"] is False


def test_username_validation():
    with SessionLocal() as db:
        tok = _tok(db)
        with pytest.raises(extsync.SyncError) as ei:
            extsync.upsert_user(db, tok, _payload("1005", "bad name@x"))
        assert ei.value.code == "invalid_username"
        db.rollback()
        extsync.upsert_user(db, tok, _payload("1006", "ext_s1006"))
        db.commit()
        with pytest.raises(extsync.SyncError) as ei:  # 另一个外部身份想占同一个用户名
            extsync.upsert_user(db, tok, _payload("1007", "ext_s1006"))
        assert ei.value.code == "username_taken" and ei.value.status == 409
        db.rollback()


def test_deactivate_keeps_data():
    with SessionLocal() as db:
        tok = _tok(db)
        r = extsync.upsert_user(db, tok, _payload("1008", "ext_s1008"))
        db.commit()
        u = db.get(User, r["user_id"])
        tv_before = int(u.token_version or 0)
        out = extsync.deactivate_user(db, tok, "1008", stop_envs=False)
        db.commit()
        u = db.get(User, r["user_id"])
        assert out["was_active"] is True
        assert u.is_active is False
        assert int(u.token_version) == tv_before + 1     # 已签发的登录令牌失效
        assert db.get(User, r["user_id"]) is not None    # 账号仍在,不删除
        with pytest.raises(extsync.SyncError) as ei:
            extsync.deactivate_user(db, tok, "no-such-id")
        assert ei.value.code == "user_not_found" and ei.value.status == 404


def test_reconcile_guards():
    with SessionLocal() as db:
        tok = _tok(db)
        for i in range(4):
            extsync.upsert_user(db, tok, _payload(f"20{i}", f"ext_r{i}"))
        db.commit()
        # 名单为空 → 拒绝
        with pytest.raises(extsync.SyncError) as ei:
            extsync.reconcile(db, tok, [], stop_envs=False)
        assert ei.value.code == "empty_list"
        db.rollback()
        # 停用比例过高 → 拒绝(4 个里只留 1 个 = 75% > 30%)
        with pytest.raises(extsync.SyncError) as ei:
            extsync.reconcile(db, tok, ["200"], stop_envs=False)
        assert ei.value.code == "too_many_deactivations" and ei.value.status == 409
        db.rollback()
        # confirm 后放行
        out = extsync.reconcile(db, tok, ["200"], stop_envs=False, confirm=True)
        db.commit()
        assert out["deactivated"] >= 3
        assert db.query(User).filter(User.external_source == SRC, User.external_id == "200").one().is_active is True


def test_scopes():
    with SessionLocal() as db:
        tok = _tok(db, scopes="handoff")
        assert toksvc.has_scope(tok, "handoff") is True
        assert toksvc.has_scope(tok, "users:write") is False
        toksvc.check_scope(tok, "handoff")
        with pytest.raises(PermissionError):
            toksvc.check_scope(tok, "users:write")


def test_provision_limits_without_docker():
    """开通实例的前置校验(不触发真正的容器编排:上限为 0 时在校验阶段就被拒)。"""
    with SessionLocal() as db:
        tok = _tok(db, max_envs_per_user=0)
        r = extsync.upsert_user(db, tok, _payload("1009", "ext_s1009"))
        db.commit()
        u = db.get(User, r["user_id"])
        with pytest.raises(extsync.SyncError) as ei:
            extsync.create_env(db, tok, u, {"name": "e1"})
        assert ei.value.code == "provision_not_allowed" and ei.value.status == 403
        db.rollback()
        # 已有实例达到上限 → 拒绝
        tok2 = _tok(db, max_envs_per_user=1)
        db.add(Environment(tenant_id=T_MAIN, name="ext-existing", kind="dev", owner_user_id=u.id))
        db.commit()
        with pytest.raises(extsync.SyncError) as ei:
            extsync.create_env(db, tok2, u, {"name": "e2"})
        assert ei.value.code == "exceeds_token_limit"
        db.rollback()
        # ensure_env 命中已有实例时不新建、不触发编排
        env, created = extsync.ensure_env(db, tok2, u, {})
        assert created is False and env.name == "ext-existing"
        # 名称非法 / 重名
        tok3 = _tok(db, max_envs_per_user=5)
        with pytest.raises(extsync.SyncError) as ei:
            extsync.create_env(db, tok3, u, {"name": "Bad_Name"})
        assert ei.value.code == "invalid_env_name"
        db.rollback()
        with pytest.raises(extsync.SyncError) as ei:
            extsync.create_env(db, tok3, u, {"name": "ext-existing"})
        assert ei.value.code == "env_name_taken" and ei.value.status == 409
        db.rollback()


def test_list_envs():
    with SessionLocal() as db:
        tok = _tok(db)
        r = extsync.upsert_user(db, tok, _payload("1010", "ext_s1010"))
        db.commit()
        u = db.get(User, r["user_id"])
        db.add(Environment(tenant_id=T_MAIN, name="ext-mine", kind="dev", owner_user_id=u.id, status="running"))
        db.add(Environment(tenant_id=T_OTHER, name="ext-elsewhere", kind="dev", owner_user_id=u.id))
        db.commit()
        envs = extsync.list_envs(db, tok, u)
        assert [e["name"] for e in envs] == ["ext-mine"]  # 只看令牌组织内的
        assert envs[0]["status"] == "running"


def test_platform_role_enterprise_and_tenant():
    """平台角色受 allow_admin_role 门控;企业版开关直通;跨组织受 allow_any_tenant 门控。"""
    with SessionLocal() as db:
        tok = _tok(db)  # 默认:不允许 admin、不允许跨组织
        with pytest.raises(extsync.SyncError) as ei:
            extsync.upsert_user(db, tok, _payload("3001", "ext_s3001", role="admin"))
        assert ei.value.code == "exceeds_token_limit"
        db.rollback()
        with pytest.raises(extsync.SyncError) as ei:
            extsync.upsert_user(db, tok, _payload("3002", "ext_s3002", tenant=str(T_OTHER)))
        assert ei.value.code == "exceeds_token_limit"
        db.rollback()
        # 不能跨组织的令牌:传不存在的 slug 也是 403 而非 404,避免靠状态码枚举平台上有哪些组织
        with pytest.raises(extsync.SyncError) as ei:
            extsync.upsert_user(db, tok, _payload("3002", "ext_s3002", tenant="no-such-slug"))
        assert ei.value.code == "exceeds_token_limit" and ei.value.status == 403
        db.rollback()
        # 显式传绑定组织自己的 slug 是允许的
        r0 = extsync.upsert_user(db, tok, _payload("3006", "ext_s3006", tenant=db.get(Tenant, T_MAIN).slug))
        db.commit()
        assert r0["tenant_id"] == T_MAIN
        r = extsync.upsert_user(db, tok, _payload("3003", "ext_s3003", can_use_enterprise=False, shell_enabled=True))
        db.commit()
        u = db.get(User, r["user_id"])
        assert u.role == "member" and u.can_use_enterprise is False and u.shell_enabled is True
        assert r["tenant_id"] == T_MAIN

        # 放开两个门后:可设超管、可按 slug 落到别的组织
        tok2 = _tok(db, allow_admin_role=True, allow_any_tenant=True, max_grant_role="owner")
        other = db.get(Tenant, T_OTHER)
        r2 = extsync.upsert_user(db, tok2, _payload("3004", "ext_s3004", role="admin", tenant=other.slug,
                                                    tenant_role="owner", can_use_enterprise=True))
        db.commit()
        u2 = db.get(User, r2["user_id"])
        assert u2.role == "admin" and r2["tenant_id"] == T_OTHER and r2["tenant_slug"] == other.slug
        m = db.query(Membership).filter(Membership.user_id == u2.id, Membership.tenant_id == T_OTHER).one()
        assert m.role == "owner"

        # 未知组织 → 404
        with pytest.raises(extsync.SyncError) as ei:
            extsync.upsert_user(db, tok2, _payload("3005", "ext_s3005", tenant="no-such-slug"))
        assert ei.value.code == "tenant_not_found" and ei.value.status == 404
        db.rollback()

        # 已是平台管理员的账号,普通令牌无权改
        with pytest.raises(extsync.SyncError) as ei:
            extsync.upsert_user(db, tok, _payload("3004", "ext_s3004"))
        assert ei.value.code == "target_is_admin" and ei.value.status == 403
        db.rollback()


def test_delete_user_requires_flag():
    """删除是破坏性操作:令牌未开 allow_delete_user 时拒绝;开了才真删,且平台管理员不可删。"""
    with SessionLocal() as db:
        tok = _tok(db)  # 默认不允许删除
        r = extsync.upsert_user(db, tok, _payload("4001", "ext_d4001"))
        db.commit()
        uid = r["user_id"]
        with pytest.raises(extsync.SyncError) as ei:
            extsync.delete_user(db, tok, "4001")
        assert ei.value.code == "delete_not_allowed" and ei.value.status == 403
        db.rollback()
        assert db.get(User, uid) is not None          # 账号仍在

        # 开了开关:账号真删,成员关系一并消失
        tok2 = _tok(db, allow_delete_user=True)
        out = extsync.delete_user(db, tok2, "4001")
        db.commit()
        assert out["deleted"] is True and out["username"] == "ext_d4001"
        assert db.get(User, uid) is None
        assert db.query(Membership).filter(Membership.user_id == uid).count() == 0

        # 不存在的外部身份 → 404
        with pytest.raises(extsync.SyncError) as ei:
            extsync.delete_user(db, tok2, "no-such-id")
        assert ei.value.code == "user_not_found" and ei.value.status == 404
        db.rollback()

        # 平台管理员账号一律拒绝删除
        tok3 = _tok(db, allow_delete_user=True, allow_admin_role=True)
        r = extsync.upsert_user(db, tok3, _payload("4002", "ext_d4002", role="admin"))
        db.commit()
        with pytest.raises(extsync.SyncError) as ei:
            extsync.delete_user(db, tok3, "4002")
        assert ei.value.code == "target_is_admin" and ei.value.status == 403
        db.rollback()
        assert db.get(User, r["user_id"]) is not None


def test_env_name_is_normalized_not_rejected():
    """实例名要能容忍接入方的写法。

    teacher_wang 在接入方那边是个完全正常的用户名,但实例名会变成主机名的一段
    (<实例>-<组织>.<基础域名>),主机名不认下划线。以前这里直接报 invalid_env_name,要求接入方
    自己转 —— 接入模块发到各个学校之后就改不动了,所以改成平台转。

    关键是幂等:查找(resolve_env / ensure_env)和创建走同一个函数,接入方仍然拿 teacher_wang
    就能查到当初建出来的 teacher-wang,不会每次同步都以为「这人还没实例」而重复创建。"""
    from app.services.apitokens import ENV_NAME_RE, normalize_env_name

    for raw, want in [("teacher_wang", "teacher-wang"), ("Teacher.Wang", "teacher-wang"),
                      ("teacher__wang", "teacher-wang"), ("-x-", "x"),
                      ("2024_class_a", "2024-class-a"), ("a" * 80, "a" * 63)]:
        got = normalize_env_name(raw, fallback="u1")
        assert got == want, (raw, got)
        assert ENV_NAME_RE.match(got), got
        assert normalize_env_name(got, fallback="u1") == got, got   # 幂等,否则查找会漏

    assert normalize_env_name("王老师", fallback="u7") == "u7"   # 一个合法字符都不剩时退回兜底
    assert normalize_env_name("") == ""     # 空名 = 「任意实例」,不能被兜底值污染


def test_env_name_candidates_always_legal():
    """首选名被占时的备选名也必须是合法实例名,而且不能超 63 位。

    回收站里的实例仍然占着名字,所以「删掉用户再同步回来」一定会走到备选名这条路 —— 它要是
    生成了非法名字,接入方就从 env_name_taken 换成 invalid_env_name,一样建不出实例。"""
    from app.services.apitokens import ENV_NAME_RE, env_name_candidates, normalize_env_name

    assert env_name_candidates("teacher-wang", 12)[:3] == [
        "teacher-wang", "teacher-wang-12", "teacher-wang-12-2"]

    for raw, uid in [("teacher_wang", 12), ("a" * 63, 999999), ("x", 1), ("a" * 80, 1234567)]:
        name = normalize_env_name(raw, fallback=f"u{uid}")
        cands = env_name_candidates(name, uid)
        assert cands[0] == name                    # 没被占时行为跟以前完全一样
        assert len(set(cands)) == len(cands)       # 备选名之间不能互相撞
        for c in cands:
            assert ENV_NAME_RE.match(c), c
            assert len(c) <= 63, (c, len(c))       # DNS 单段上限
