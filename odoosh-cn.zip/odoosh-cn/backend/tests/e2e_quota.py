"""端到端:用户实例配额(User.max_envs,按拥有者计数)。临时 SQLite,不碰 Docker(编排函数打桩)。
运行:cd backend && python tests/e2e_quota.py
"""
import os
import tempfile

os.environ["ODOOSH_DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.gettempdir(), "odoosh-quota-test.db")
os.environ.setdefault("ODOOSH_SECRET_KEY", "test-secret-key-not-for-production")
dbfile = os.environ["ODOOSH_DATABASE_URL"].replace("sqlite:///", "")
if os.path.exists(dbfile):
    os.remove(dbfile)

from datetime import datetime, timezone  # noqa: E402

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402
from app.db import SessionLocal  # noqa: E402
from app.models import Environment  # noqa: E402
from app.services import orchestrator  # noqa: E402


def _fake_trash(env_id, backup_id=None):
    orchestrator._set_status(env_id, "deleted", "在回收站中", progress=100, deleted_at=datetime.now(timezone.utc))
def _fake_untrash(env_id):
    orchestrator._update_env(env_id, deleted_at=None)
    orchestrator._set_status(env_id, "running", None, progress=100)
def _fake_destroy(env_id, keep_data=False):
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if e:
            db.delete(e); db.commit()
orchestrator.trash = _fake_trash
orchestrator.untrash = _fake_untrash
orchestrator.destroy = _fake_destroy
orchestrator.container_states = lambda: {}
orchestrator.sync_status = lambda e, states=None: e.status

fails = 0
def check(cond, msg):
    global fails
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        fails += 1

c = TestClient(app)
with c:
    def login(u, p):
        r = c.post("/api/auth/login", json={"username": u, "password": p}); assert r.status_code == 200, r.text
        return {"Authorization": "Bearer " + r.json()["access_token"]}
    admin = login("admin", "admin")
    tid = c.post("/api/tenants", json={"slug": "acme", "name": "Acme"}, headers=admin).json()["id"]
    for name in ("dev1", "dev2", "zero"):
        c.post("/api/users", json={"username": name, "password": "pass1234", "display_name": name, "role": "member",
                                   "memberships": [{"tenant_id": tid, "role": "developer"}]}, headers=admin)
    ids = {u["username"]: u["id"] for u in c.get("/api/users", headers=admin).json()}
    dev1, dev2, zero = login("dev1", "pass1234"), login("dev2", "pass1234"), login("zero", "pass1234")

    # 默认不限
    me = c.get("/api/auth/me", headers=dev1).json()
    check(me.get("max_envs") is None and me.get("env_count") == 0, "默认 max_envs=None(不限),env_count=0")
    for i in range(3):
        check(c.post("/api/environments", json={"tenant_id": tid, "name": f"free{i}", "kind": "dev"}, headers=dev1).status_code == 201, f"不限配额:创建 free{i}")

    # 配额 0:不能创建
    r = c.put(f"/api/users/{ids['zero']}", json={"max_envs": 0}, headers=admin)
    check(r.status_code == 200 and r.json()["max_envs"] == 0, "超管把 zero 的配额设为 0")
    r = c.post("/api/environments", json={"tenant_id": tid, "name": "z1", "kind": "dev"}, headers=zero)
    check(r.status_code == 403 and "配额为 0" in r.text, f"配额 0 → 403:{r.json().get('detail')}")

    # 配额 2:按拥有者计数
    c.put(f"/api/users/{ids['dev2']}", json={"max_envs": 2}, headers=admin)
    a = c.post("/api/environments", json={"tenant_id": tid, "name": "d2a", "kind": "dev"}, headers=dev2)
    b = c.post("/api/environments", json={"tenant_id": tid, "name": "d2b", "kind": "dev"}, headers=dev2)
    check(a.status_code == 201 and b.status_code == 201, "配额 2:前两个创建成功")
    r = c.post("/api/environments", json={"tenant_id": tid, "name": "d2c", "kind": "dev"}, headers=dev2)
    check(r.status_code == 403 and "2/2" in r.text, f"第 3 个 → 403:{r.json().get('detail')}")
    u = next(x for x in c.get("/api/users", headers=admin).json() if x["username"] == "dev2")
    check(u["env_count"] == 2 and u["max_envs"] == 2, "用户列表返回 env_count=2 / max_envs=2")

    # 有权访问别人的实例不计入:dev1 把 free0 授权给 dev2 可管理 → dev2 仍是 2/2,不变
    fid = c.get("/api/environments", headers=dev1).json()[0]["id"]
    c.put(f"/api/environments/{fid}/acl", json=[{"user_id": ids["dev2"], "level": "manage"}], headers=dev1)
    check(len(c.get("/api/environments", headers=dev2).json()) == 3, "dev2 能看到 3 个实例(2 个自己的 + 1 个被授权的)")
    check(c.get("/api/auth/me", headers=dev2).json()["env_count"] == 2, "但配额只按拥有者计:env_count 仍为 2")

    # 进回收站后释放名额;恢复时重新校验
    aid = a.json()["id"]
    with SessionLocal() as db:  # 从未编排过的实例删除时直接删记录;模拟已创建过 → 进回收站
        e = db.get(Environment, aid); e.container_name = "odoo-acme-d2a"; e.status = "running"; db.commit()
    check(c.delete(f"/api/environments/{aid}", headers=dev2).status_code in (200, 202, 204), "dev2 把 d2a 移入回收站")
    check(c.get("/api/auth/me", headers=dev2).json()["env_count"] == 1, "回收站里的不占配额:env_count=1")
    r = c.post("/api/environments", json={"tenant_id": tid, "name": "d2c", "kind": "dev"}, headers=dev2)
    check(r.status_code == 201, "腾出名额后可再创建 d2c")
    r = c.post(f"/api/environments/{aid}/restore", headers=dev2)
    check(r.status_code == 403 and "2/2" in r.text, f"名额已满时从回收站恢复 → 403:{r.json().get('detail')}")

    # 转让给配额已满的用户 → 拒绝;超管不受限
    r = c.put(f"/api/environments/{fid}/owner", json={"user_id": ids["dev2"]}, headers=dev1)
    check(r.status_code == 403, "转让给已满配额的 dev2 → 403")
    for i in range(3):
        check(c.post("/api/environments", json={"tenant_id": tid, "name": f"adm{i}", "kind": "dev"}, headers=admin).status_code == 201, f"超管不受配额限制 adm{i}")

    # 改回不限(传 null)
    r = c.put(f"/api/users/{ids['dev2']}", json={"max_envs": None}, headers=admin)
    check(r.json()["max_envs"] is None, "传 null 恢复不限")
    check(c.post(f"/api/environments/{aid}/restore", headers=dev2).status_code == 200, "不限后可以恢复")

print("\nFAILS:", fails)
raise SystemExit(1 if fails else 0)
