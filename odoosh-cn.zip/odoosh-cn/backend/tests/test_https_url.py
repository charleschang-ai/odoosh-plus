"""实例 URL 的 http/https 选择(services/nginx.env_url + https_ready)。

核心不变量:证书**过期**时,平台生成的实例地址必须自动退回 http://
—— 一张泛证书服务所有实例,若继续把用户往 https 送,就是所有实例同时弹证书告警;
而 80 一直在监听(且刻意没做 80→443 跳转),退回 http 用户就能无感继续用。

同时锁住:tls_ready(配置层)与 https_ready(链接层)的分工——证书过期后 nginx **仍**监听 443
(否则 443 变「连接被拒」,比证书告警更糟),只是不再从控制台往那儿送人。
"""

import os
from datetime import datetime, timedelta, timezone

import pytest

from app.config import settings
from app.services import nginx


def _write_cert(dirpath: str, *, days_valid: int, cn: str = "*.example.com", name: str | None = None) -> None:
    """在 dirpath 生成自签的 <name>.crt/.key(默认 wildcard);days_valid 为负 = 已过期证书。"""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])  # 别叫 name:与文件名参数冲突
    now = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        # 过期证书:有效期整体落在过去
        .not_valid_before(now - timedelta(days=abs(days_valid) + 1))
        .not_valid_after(now + timedelta(days=days_valid))
        .add_extension(x509.SubjectAlternativeName([x509.DNSName(cn)]), critical=False)
        .sign(key, hashes.SHA256())
    )
    os.makedirs(dirpath, exist_ok=True)
    name = name or nginx.CERT_NAME
    with open(os.path.join(dirpath, f"{name}.crt"), "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    with open(os.path.join(dirpath, f"{name}.key"), "wb") as f:
        f.write(key.private_bytes(serialization.Encoding.PEM,
                                  serialization.PrivateFormat.TraditionalOpenSSL,
                                  serialization.NoEncryption()))


@pytest.fixture()
def certs(tmp_path, monkeypatch):
    """把 data_dir 指到临时目录(cert_files 从这里取证书),并让 platform.tls_enabled 默认为开。"""
    monkeypatch.setattr(settings, "data_dir", str(tmp_path))
    monkeypatch.setattr(settings, "http_port", 80)
    monkeypatch.setattr(settings, "https_port", 443)

    import app.routers.settings as settings_router

    monkeypatch.setattr(settings_router, "get_setting", lambda db, k, *a, **kw: "1" if k == "platform.tls_enabled" else None)

    monkeypatch.setattr(nginx, "access_mode", lambda: "domain")  # 默认域名模式,端口模式用例自行覆盖

    def _make(days_valid: int | None, *, name: str | None = None, cn: str = "*.example.com"):
        nginx._pem_cache.clear()  # 清缓存,避免用例间串味
        if days_valid is not None:
            _write_cert(os.path.join(str(tmp_path), "certs"), days_valid=days_valid, cn=cn, name=name)
    return _make


DOMAIN = "dev-acme.example.com"


def test_valid_cert_gives_https(certs):
    """证书有效 → 实例地址用 https,443 端口省略。"""
    certs(60)
    assert nginx.https_ready() is True
    assert nginx.env_url(DOMAIN) == f"https://{DOMAIN}"


def test_expired_cert_falls_back_to_http(certs):
    """证书已过期 → 链接自动退回 http(用户仍能从 80 进);但 nginx 仍保持监听 443。"""
    certs(-1)
    assert nginx.https_ready() is False, "过期证书不得再往 https 送人"
    assert nginx.env_url(DOMAIN) == f"http://{DOMAIN}"
    # 配置层仍认为可以监听 443:过期证书对 nginx 是合法配置,撤掉会变成「连接被拒」
    assert nginx.tls_ready() is True


def test_no_cert_gives_http(certs):
    """从没签发过证书 → http。"""
    certs(None)
    assert nginx.https_ready() is False
    assert nginx.tls_ready() is False
    assert nginx.env_url(DOMAIN) == f"http://{DOMAIN}"


def test_tls_switch_off_gives_http(certs, monkeypatch):
    """证书有效但总开关 platform.tls_enabled=0 → 退回 http。"""
    certs(60)
    import app.routers.settings as settings_router

    monkeypatch.setattr(settings_router, "get_setting", lambda db, k, *a, **kw: "0" if k == "platform.tls_enabled" else None)
    assert nginx.https_ready() is False
    assert nginx.env_url(DOMAIN) == f"http://{DOMAIN}"


def test_non_standard_https_port_is_appended(certs, monkeypatch):
    """HTTPS 端口不是 443 时要拼进 URL(原实现只认 http_port,对 https 是错的)。"""
    certs(60)
    monkeypatch.setattr(settings, "https_port", 8443)
    assert nginx.env_url(DOMAIN) == f"https://{DOMAIN}:8443"


def test_port_mode_without_ip_cert_is_http(certs, monkeypatch):
    """端口直连模式:只有泛域名证书、没有 IP 证书 → 恒 http(泛证书的 SAN 是域名,盖不住 IP)。"""
    certs(60)  # 只写 wildcard
    monkeypatch.setattr(nginx, "access_mode", lambda: "port")
    monkeypatch.setattr(nginx, "access_host", lambda: "117.72.198.131")
    assert nginx.ip_tls_ready() is False
    assert nginx.env_url(DOMAIN, public_port=10001) == "http://117.72.198.131:10001"


# ---- 端口直连 + 公网 IP 证书(deploy/ssl-ip.sh):无域名也能拿到浏览器信任的 HTTPS ----
IP = "117.72.198.131"


@pytest.fixture()
def ip_mode(certs, monkeypatch):
    """端口直连模式 + access_host 为公网 IP。"""
    monkeypatch.setattr(nginx, "access_mode", lambda: "port")
    monkeypatch.setattr(nginx, "access_host", lambda: IP)
    return certs


def test_port_mode_with_valid_ip_cert_gives_https(ip_mode):
    """IP 证书有效 → 实例地址 https://<IP>:<端口>,且 nginx 该端口配置转 SSL。"""
    ip_mode(6, name=nginx.IP_CERT_NAME, cn=IP)
    assert nginx.ip_tls_ready() is True
    assert nginx.https_ready() is True
    assert nginx.env_url("ignored", public_port=10001) == f"https://{IP}:10001"
    block = nginx._port_listen_block(10001)
    assert "listen 10001 ssl;" in block
    assert f"{nginx.IP_CERT_NAME}.crt" in block
    assert "error_page 497" in block          # 明文打 SSL 端口时跳 https,而不是回乱码
    assert "listen 10001;" not in block       # 同端口不能既明文又 SSL


def test_port_mode_expired_ip_cert_falls_back(ip_mode):
    """IP 证书过期(6.6 天短证书续期失败)→ URL 退回 http,且配置改回明文监听。"""
    ip_mode(-1, name=nginx.IP_CERT_NAME, cn=IP)
    assert nginx.https_ready() is False
    assert nginx.env_url("ignored", public_port=10001) == f"http://{IP}:10001"
    block = nginx._port_listen_block(10001)
    assert block.strip() == "listen 10001;", f"过期后应回明文,实际 {block!r}"


def test_port_mode_non_ip_host_stays_http(ip_mode, monkeypatch):
    """access_host 被配成主机名(非 IP)时,IP 证书对不上 → 必须留在 http,别把用户送去撞证书告警。"""
    ip_mode(6, name=nginx.IP_CERT_NAME, cn=IP)
    monkeypatch.setattr(nginx, "access_host", lambda: "odoo.intranet")
    assert nginx.env_url("ignored", public_port=10001) == "http://odoo.intranet:10001"


def test_secure_false_forces_http(certs):
    """secure=False 显式强制 http —— 附加数据库用它(见下个用例)。"""
    certs(60)
    assert nginx.env_url(DOMAIN, secure=False) == f"http://{DOMAIN}"


def test_extra_database_url_is_always_http(certs, monkeypatch):
    """附加库域名 <库>.<实例>-<组织>.<基础域名> 比实例深一级,泛证书 *.<基础域名> 只匹配一级,
    走 https 必定撞证书域名不匹配 → url_of 必须恒 http,即使证书完全有效。"""
    certs(60)
    from app.services import databases as dbsvc

    monkeypatch.setattr(dbsvc, "access_mode", lambda: "domain", raising=False)
    monkeypatch.setattr(nginx, "access_mode", lambda: "domain")

    e = type("E", (), {"domain": DOMAIN})()
    row = type("R", (), {"name": "shop"})()
    url = dbsvc.url_of(e, row)
    assert url == f"http://shop.{DOMAIN}", f"附加库不能给 https 链接,实际 {url}"
