import os

# 测试用密钥(config 在 secret_key 为默认值时拒绝启动)
os.environ.setdefault("ODOOSH_SECRET_KEY", "test-secret-key-not-for-production")
os.environ.setdefault("ODOOSH_DATABASE_URL", "sqlite:////tmp/odoosh-test.db")
