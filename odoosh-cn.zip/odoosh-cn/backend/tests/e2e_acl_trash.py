"""端到端:实例级访问控制(创建者 / 授权名单)+ 回收站删除流程。临时 SQLite,不碰 Docker(编排函数打桩)。
运行:cd backend && python tests/e2e_acl_trash.py
"""
import os
import tempfile

os.environ["ODOOSH_DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.gettempdir(), "odoosh-acl-test.db")
os.environ.setdefault("ODOOSH_SECRET_KEY", "test-secret-key-not-for-production")
dbfile = os.environ["ODOOSH_DATABASE_URL"].replace("sqlite:///", "")
if os.path.exists(dbfile):
    os.remove(dbfile)

from datetime import datetime, timezone  # noqa: E402

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402
from app.db import SessionLocal  # noqa: E402
from app.models import Environment  # noqa: E402
from app.services import orchestrator  # noqa: E402

# 打桩:不真的操作 Docker
def _fake_trash(env_id, backup_id=None):
    orchestrator._set_status(env_id, "deleted", "在回收站中", progress=100, deleted_at=datetime.now(timezone.utc))
def _fake_untrash(env_id):
    orchestrator._update_env(env_id, deleted_at=None)
    orchestrator._set_status(env_id, "running", None, progress=100)
def _fake_destroy(env_id, keep_data=False):
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if e:
            db.delete(e); db.commit()
orchestrator.trash = _fake_trash
orchestrator.untrash = _fake_untrash
orchestrator.destroy = _fake_destroy
orchestrator.container_states = lambda: {}
orchestrator.sync_status = lambda e, states=None: e.status

fails = 0
def check(cond, msg):
    global fails
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        fails += 1

c = TestClient(app)
with c:
    def login(u, p):
        r = c.post("/api/auth/login", json={"username": u, "password": p}); assert r.status_code == 200, r.text
        return {"Authorization": "Bearer " + r.json()["access_token"]}
    admin = login("admin", "admin")
    t = c.post("/api/tenants", json={"slug": "acme", "name": "Acme"}, headers=admin).json()
    tid = t["id"]
    for name in ("dev1", "dev2", "tester1", "owner1"):
        role = "tester" if name.startswith("tester") else "owner" if name.startswith("owner") else "developer"
        c.post("/api/users", json={"username": name, "password": "pass1234", "display_name": name, "role": "member",
                                   "memberships": [{"tenant_id": tid, "role": role}]}, headers=admin)
    ids = {u["username"]: u["id"] for u in c.get("/api/users", headers=admin).json()}
    dev1, dev2, tester1, owner1 = login("dev1", "pass1234"), login("dev2", "pass1234"), login("tester1", "pass1234"), login("owner1", "pass1234")

    # 0. 超管创建的实例:组织管理员 owner1 也看不到(只有超管 + 名单)
    r = c.post("/api/environments", json={"tenant_id": tid, "name": "adminenv", "kind": "dev"}, headers=admin)
    aid = r.json()["id"]
    check(c.get("/api/environments", headers=owner1).json() == [], "组织管理员看不到超管创建的实例")
    check(c.get(f"/api/environments/{aid}", headers=owner1).status_code == 403, "组织管理员直接访问超管实例 → 403")
    with SessionLocal() as db:
        from app.models_backup import Backup
        db.add(Backup(tenant_id=tid, environment_id=aid, tenant_slug="acme", env_name="adminenv", kind="manual", status="done", size_bytes=1)); db.commit()
    check(c.get("/api/backups", headers=owner1).json() == [], "组织管理员看不到超管实例的备份")
    check(len(c.get("/api/backups", headers=admin).json()) == 1, "超管能看到备份")
    # 旧数据(无拥有者)按现在的规则:名单外无人可见;启动时会回填给内置管理员
    with SessionLocal() as db:
        db.get(Environment, aid).owner_user_id = None; db.commit()
    check(c.get("/api/environments", headers=owner1).json() == [], "无拥有者的实例组织管理员也看不到")
    c.delete(f"/api/environments/{aid}", headers=admin)

    # 1. dev1 创建实例 → 只有 dev1 和超管可见
    r = c.post("/api/environments", json={"tenant_id": tid, "name": "demo", "kind": "dev"}, headers=dev1)
    check(r.status_code == 201 and r.json()["my_role"] == "owner" and r.json()["owner_user_id"] == ids["dev1"], "dev1 创建实例,拥有者=dev1")
    eid = r.json()["id"]
    check([e["id"] for e in c.get("/api/environments", headers=dev1).json()] == [eid], "dev1 列表看到自己的实例")
    check(c.get("/api/environments", headers=dev2).json() == [], "dev2 看不到别人的实例")
    check(c.get("/api/environments", headers=owner1).json() == [], "组织管理员也看不到 dev1 的实例")
    check(all(e["my_role"] == "owner" for e in c.get("/api/environments", headers=admin).json()), "超管看到全部且为 owner")
    check(c.get(f"/api/environments/{eid}", headers=dev2).status_code == 403, "dev2 直接访问详情 → 403")

    # 2. 授权名单:view → 可看不可操作;operate → 可操作;manage → 可改名单
    r = c.put(f"/api/environments/{eid}/acl", json=[{"user_id": ids["dev2"], "level": "view"}], headers=dev1)
    check(r.status_code == 200 and [e["username"] for e in r.json()["entries"]] == ["dev2"], "dev1 把 dev2 加为「可访问」")
    lst = c.get("/api/environments", headers=dev2).json()
    check(len(lst) == 1 and lst[0]["my_role"] == "viewer", "dev2 现在可见,角色=viewer")
    check(c.post(f"/api/environments/{eid}/stop", headers=dev2).status_code == 403, "「可访问」不能停止实例")
    check(c.put(f"/api/environments/{eid}/acl", json=[], headers=dev2).status_code == 403, "「可访问」不能改名单")
    c.put(f"/api/environments/{eid}/acl", json=[{"user_id": ids["dev2"], "level": "operate"}], headers=dev1)
    check(c.get("/api/environments", headers=dev2).json()[0]["my_role"] == "operator", "升为「可操作」后角色=operator")
    check(c.post(f"/api/environments/{eid}/restart", headers=dev2).status_code != 403, "「可操作」可以重启")
    check(c.put(f"/api/environments/{eid}", json={"sleep_idle_hours": 1}, headers=dev2).status_code == 403, "「可操作」不能编辑设置")
    check(c.delete(f"/api/environments/{eid}", headers=dev2).status_code == 403, "「可操作」不能删除")
    check(c.put(f"/api/environments/{eid}/acl", json=[], headers=dev2).status_code == 403, "「可操作」不能改名单")
    m = c.get("/api/environments/permissions", headers=dev2).json()["_matrix"]
    check(m["operator"]["production"]["stop"] is False and m["operator"]["production"]["restart"] is True and m["viewer"]["dev"]["start"] is False and m["operator"]["dev"]["secrets"] is False and m["operator"]["dev"]["edit"] is False, "矩阵:可操作对生产不能停、可重启、看不到凭据、不能编辑;可访问不能启动")
    check(c.get(f"/api/environments/{eid}", headers=dev2).json().get("admin_password") is None, "「可操作」详情里不返回 Odoo 口令")
    r = c.put(f"/api/environments/{eid}/acl", json=[{"user_id": ids["dev2"], "level": "manage"}, {"user_id": ids["tester1"], "level": "view"}], headers=dev1)
    check(c.get("/api/environments", headers=dev2).json()[0]["my_role"] == "owner", "「可管理」角色=owner")
    r = c.put(f"/api/environments/{eid}/acl", json=[{"user_id": ids["dev2"], "level": "manage"}], headers=dev2)
    check(r.status_code == 403, "「可管理」不能改名单(只有拥有者 / 超管)")
    check(c.delete(f"/api/environments/{eid}", headers=dev2).status_code == 403, "「可管理」不能删除实例(只有拥有者 / 超管)")
    check(c.put(f"/api/environments/{eid}", json={"sleep_idle_hours": 2}, headers=dev2).status_code == 200, "「可管理」可以编辑设置")
    r = c.put(f"/api/environments/{eid}/acl", json=[{"user_id": ids["dev2"], "level": "manage"}], headers=dev1)
    check(r.status_code == 200 and [e["username"] for e in r.json()["entries"]] == ["dev2"], "拥有者可以改名单(移除 tester1)")
    check(c.get("/api/environments", headers=tester1).json() == [], "tester1 被移出后不可见")
    r = c.put(f"/api/environments/{eid}/acl", json=[{"user_id": 9999, "level": "view"}], headers=dev1)
    check(r.status_code == 400, "非组织成员不能加入名单")
    st = c.get(f"/api/environments/{eid}/acl", headers=dev1).json()
    check(st["owner_username"] == "dev1" and any(x["username"] == "tester1" for x in st["candidates"]), "名单接口返回拥有者与候选成员")

    # 2b. 详情页(项目)权限:可访问可打开(只读),可操作不能按分支建环境 / 改档
    with SessionLocal() as db:
        e = db.get(Environment, eid); e.repo_url = "https://gitee.com/acme/xxx"; e.branch = "main"; db.commit()
    c.put(f"/api/environments/{eid}/acl", json=[{"user_id": ids["dev2"], "level": "operate"}, {"user_id": ids["tester1"], "level": "view"}], headers=dev1)
    r = c.post(f"/api/projects/{eid}/environments", json={"branch": "feature-x", "kind": "dev"}, headers=dev2)
    check(r.status_code == 403, "「可操作」不能在项目里按分支建环境")
    r = c.post(f"/api/projects/{eid}/environments/{eid}/kind", json={"kind": "staging"}, headers=dev2)
    check(r.status_code == 403, "「可操作」不能改环境档位")
    r = c.get(f"/api/projects/{eid}", headers=tester1)
    check(r.status_code == 200 and r.json()["role"] == "viewer" and r.json()["permissions"]["dev"]["deploy"] is False and r.json()["environments"][0]["my_role"] == "viewer", "「可访问」可打开详情页,权限表全为只读")
    r = c.get(f"/api/projects/{eid}", headers=dev2)
    check(r.status_code == 200 and r.json()["permissions"]["dev"]["create"] is False and r.json()["permissions"]["dev"]["deploy"] is True and r.json()["permissions"]["dev"]["edit"] is False, "「可操作」详情页:可部署、不可建环境 / 编辑")
    check(c.get(f"/api/projects/{eid}", headers=owner1).status_code == 403, "名单外的组织管理员打不开详情页")
    c.put(f"/api/environments/{eid}/acl", json=[{"user_id": ids["dev2"], "level": "manage"}], headers=dev1)

    # 3. 转让拥有者
    r = c.put(f"/api/environments/{eid}/owner", json={"user_id": ids["dev2"]}, headers=dev2)
    check(r.status_code == 403, "非拥有者不能转让")
    r = c.put(f"/api/environments/{eid}/owner", json={"user_id": ids["dev2"]}, headers=dev1)
    check(r.status_code == 200 and r.json()["owner_username"] == "dev2" and any(x["username"] == "dev1" and x["level"] == "manage" for x in r.json()["entries"]), "转让后 dev2 为拥有者,dev1 进名单为可管理")
    check(c.delete(f"/api/environments/{eid}", headers=dev1).status_code == 403, "转让后原拥有者(可管理)不能删除")
    r = c.put(f"/api/environments/{eid}/owner", json={"user_id": ids["dev1"]}, headers=dev2)
    check(r.status_code == 200 and r.json()["owner_username"] == "dev1", "转回 dev1")

    # 4. 回收站:先让实例“像编排过”(有容器名/库名),再删除 → deleted;列表默认不显示;trash=1 显示;恢复;彻底删除
    with SessionLocal() as db:
        e = db.get(Environment, eid); e.container_name = "c"; e.db_name = "d"; e.status = "running"; db.commit()
    r = c.delete(f"/api/environments/{eid}", params={"backup": 0}, headers=dev1)
    check(r.status_code == 202 and r.json()["purged"] is False, "删除 → 移入回收站(202)")
    check(c.get("/api/environments", headers=admin).json() == [], "普通列表不再显示")
    tr = c.get("/api/environments", params={"trash": 1}, headers=dev1).json()
    check(len(tr) == 1 and tr[0]["status"] == "deleted" and tr[0]["deleted_at"], "回收站列表显示,状态 deleted")
    check(c.delete(f"/api/environments/{eid}", headers=dev1).status_code == 409, "回收站里的实例不能再次「删除」")
    r = c.post(f"/api/environments/{eid}/restore", headers=dev1)
    check(r.status_code == 200 and c.get("/api/environments", headers=dev1).json()[0]["status"] == "running", "恢复成功,回到列表")
    check(c.delete(f"/api/environments/{eid}/purge", headers=dev1).status_code == 409, "未在回收站不能彻底删除")
    c.delete(f"/api/environments/{eid}", headers=dev1)
    r = c.delete(f"/api/environments/{eid}/purge", headers=dev1)
    check(r.status_code == 202 and c.get("/api/environments", params={"trash": 1}, headers=admin).json() == [], "彻底删除后记录消失")

    # 5. 从未编排过的实例:删除即彻底删除
    r = c.post("/api/environments", json={"tenant_id": tid, "name": "empty", "kind": "dev"}, headers=dev1)
    r2 = c.delete(f"/api/environments/{r.json()['id']}", headers=dev1)
    check(r2.json().get("purged") is True and c.get("/api/environments", headers=dev1).json() == [], "未编排实例直接删除")

    # 6. 内置超管保护
    check(c.delete(f"/api/users/{ids['admin']}", headers=admin).status_code == 400, "内置超管不能删除")

print("\nFAILURES:", fails)
raise SystemExit(1 if fails else 0)
