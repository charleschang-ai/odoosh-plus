"""批量作业的请求 / 响应模型。"""

from datetime import datetime

from pydantic import BaseModel, Field

from .schemas import ORM, EnvAclIn


# ---- 批量创建实例:计划 ----
class EnvBatchBase(BaseModel):
    """整批共享的实例配置(每个实例只有名字不同)。"""

    odoo_version: str = "18"
    edition: str = "community"  # v1 仅 community(enterprise 留 v2)
    lang: str | None = "zh_CN"
    mem_mb: int | None = None
    cpus: float | None = None
    sleep_idle_hours: float | None = None
    expire_days: int | None = None  # 仅超管可设
    acl: list[EnvAclIn] = []  # 初始授权名单(可选)


class EnvBatchPlan(BaseModel):
    tenant_id: int
    kind: str = "dev"  # dev | staging(不允许 production)
    owner_user_id: int | None = None  # 统一拥有者;None = 操作者本人
    # 命名:二选一——名称清单,或前缀 + 编号序列
    names: list[str] = []
    prefix: str | None = None
    start: int = 1
    count: int = 0
    pad: int = 2
    provision: bool = True  # 建完立即创建并启动
    base: EnvBatchBase = EnvBatchBase()


class EnvBatchIn(BaseModel):
    plan: EnvBatchPlan
    idempotency_key: str | None = Field(default=None, max_length=64)


# ---- 预检 ----
class EnvBatchItemCheck(BaseModel):
    name: str
    ok: bool
    reason: str | None = None


class EnvBatchQuota(BaseModel):
    owner: str
    used: int
    limit: int | None  # None = 不限
    adding: int
    ok: bool
    reason: str | None = None


class EnvBatchEnterprise(BaseModel):
    required: bool = False  # 是否选了企业版
    available: bool = True  # 企业版代码是否可用(可创建)
    reason: str | None = None  # 不可用原因
    source: str | None = None  # 采用的企业版仓库来源(可用时)


class EnvBatchPreflightOut(BaseModel):
    items: list[EnvBatchItemCheck]
    ok_count: int
    quota: EnvBatchQuota
    est_mem_mb: int  # N × 每实例内存,提示是否可能超宿主机
    kind: str
    owner_user_id: int
    enterprise: EnvBatchEnterprise = EnvBatchEnterprise()
    warnings: list[str] = []


# ---- 批量操作(已存在实例:start/stop/restart/trash) ----
class EnvOpsIn(BaseModel):
    kind: str  # env.start|stop|restart|trash|purge|restore|sleep|wake|backup|edit|transfer, acl.grant|revoke
    target_ids: list[int]
    payload: dict | None = None  # edit(fields) / transfer(new_owner_user_id) / acl.grant(entries) / acl.revoke(user_ids)
    idempotency_key: str | None = Field(default=None, max_length=64)


class EnvOpsItemCheck(BaseModel):
    env_id: int
    label: str
    ok: bool
    reason: str | None = None


class EnvOpsPreflightOut(BaseModel):
    kind: str
    verb: str
    items: list[EnvOpsItemCheck]
    ok_count: int


# ---- 作业 ----
class BulkJobItemOut(ORM):
    id: int
    target_id: int | None = None
    label: str
    status: str
    message: str | None = None


class BulkJobOut(ORM):
    id: int
    kind: str
    scope: str
    tenant_id: int | None = None
    status: str
    total: int
    succeeded: int
    failed: int
    skipped: int
    created_by: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    finished_at: datetime | None = None
    items: list[BulkJobItemOut] = []
