"""Git 仓库对接相关 schema(与 schemas.py 分离,避免与并行开发冲突)。"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class RepositoryOut(ORM):
    id: int
    tenant_id: int | None
    scope: str = "tenant"
    is_enterprise: bool = False
    name: str
    url: str
    provider: str
    owner: str | None
    repo: str | None
    has_token: bool = False
    account_id: int | None = None
    account_login: str | None = None
    webhook_secret: str | None = None  # 仅 GET /repos/{id}/webhook 返回;列表接口置空(避免密钥随列表广播)
    webhook_id: str | None = None
    default_branch: str | None
    auto_deploy: bool
    branches_synced_at: datetime | None
    last_error: str | None
    created_at: datetime
    created_by: int | None = None
    created_by_name: str | None = None
    can_manage: bool = False  # 当前用户是否可编辑/移除/写远端(前端据此显示按钮;后端仍校验)


class RepositoryCreate(BaseModel):
    tenant_id: int | None = None  # scope=platform 时为空
    scope: str = "tenant"  # tenant | platform(仅超管)
    is_enterprise: bool = False
    name: str = Field(min_length=1, max_length=128)
    url: str = Field(min_length=8, max_length=256)
    token: str | None = None
    auto_deploy: bool = True
    account_id: int | None = None  # 通过已连接的 GitHub/Gitee 账号接入(令牌取自账号)
    auto_webhook: bool = True  # 有账号时自动在 Git 平台创建 webhook


# ---- OAuth 账号 ----
class GitAccountOut(ORM):
    id: int
    provider: str
    login: str
    display_name: str | None
    avatar_url: str | None
    expires_at: datetime | None
    scopes: str | None
    created_at: datetime


class GitAccountTokenIn(BaseModel):
    """用个人访问令牌连接账号(无需 OAuth 回调地址)。"""

    provider: str = Field(pattern=r"^(github|gitee)$")
    token: str = Field(min_length=8, max_length=512)


class OAuthAppOut(BaseModel):
    provider: str
    client_id: str
    configured: bool
    callback_url: str


class OAuthAppIn(BaseModel):
    client_id: str | None = None
    client_secret: str | None = None  # None/缺省 = 不修改


class RemoteRepoOut(BaseModel):
    full_name: str
    name: str | None = None
    owner: str | None = None
    private: bool = False
    clone_url: str
    html_url: str | None = None
    default_branch: str | None = None
    description: str | None = None
    updated_at: str | None = None


class RemoteRepoCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100, pattern=r"^[A-Za-z0-9_.-]+$")
    private: bool = True
    description: str | None = None


class BranchCreate(BaseModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9][A-Za-z0-9._/-]*$")
    from_branch: str = Field(min_length=1)


class RepositoryUpdate(BaseModel):
    name: str | None = None
    url: str | None = None
    token: str | None = None  # 传空字符串表示清除
    auto_deploy: bool | None = None
    regenerate_secret: bool = False
    is_enterprise: bool | None = None


class BranchEnv(BaseModel):
    id: int
    name: str
    kind: str
    status: str
    url: str | None = None


class BranchOut(BaseModel):
    name: str
    sha: str | None = None
    message: str | None = None
    author: str | None = None
    date: str | None = None
    is_default: bool = False
    environments: list[BranchEnv] = []


class BranchesOut(BaseModel):
    synced_at: datetime | None
    default_branch: str | None
    branches: list[BranchOut]


class ConnectionTestOut(BaseModel):
    ok: bool
    message: str
    default_branch: str | None = None
    branch_count: int | None = None


class PushEventOut(ORM):
    id: int
    repository_id: int
    branch: str
    commit_sha: str | None
    commit_message: str | None
    author: str | None
    pusher: str | None
    deleted: bool
    matched_env_ids: str | None
    result: str | None
    received_at: datetime


class WebhookInfoOut(BaseModel):
    url: str
    secret: str
    provider: str
    instructions: str
