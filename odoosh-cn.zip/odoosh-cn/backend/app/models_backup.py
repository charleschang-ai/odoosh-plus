"""备份/恢复相关模型。

单独成文件是为了与 models.py(环境编排部分正在并行开发)解耦。
main.py 只要 import 了本模块,create_all 就会建表。
"""

from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


class Backup(Base):
    """一次环境备份(Odoo 官方 zip 格式:dump.sql + filestore/ + manifest.json)。

    环境被删除后备份记录仍保留(environment_id 置空),便于日后恢复到新环境。
    """

    __tablename__ = "backups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    environment_id: Mapped[int | None] = mapped_column(
        ForeignKey("environments.id", ondelete="SET NULL"), nullable=True, index=True
    )
    # 快照信息(环境删除后仍可读)
    tenant_slug: Mapped[str] = mapped_column(String(64))
    env_name: Mapped[str] = mapped_column(String(64))
    odoo_version: Mapped[str | None] = mapped_column(String(8))
    db_name: Mapped[str | None] = mapped_column(String(64))
    # 附加库备份:指向 environment_databases.id;None = 实例主库
    database_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)

    kind: Mapped[str] = mapped_column(String(16), default="manual")  # manual | auto | pre_restore | upload
    # running → done | failed
    status: Mapped[str] = mapped_column(String(16), default="running")
    message: Mapped[str | None] = mapped_column(String(512))
    note: Mapped[str | None] = mapped_column(String(256))
    filename: Mapped[str | None] = mapped_column(String(256))  # 相对 backups 根目录的路径
    size_bytes: Mapped[int] = mapped_column(BigInteger, default=0)
    include_filestore: Mapped[bool] = mapped_column(Boolean, default=True)
    created_by: Mapped[str | None] = mapped_column(String(64))
    # 该备份要推送到哪些用户远程目标:None=沿用实例配置(自动备份走这条);"[]"=仅本地不推;"[1,2]"=指定目标(手动「远程备份」)
    push_target_ids: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # 异地副本(S3 兼容对象存储,见 services/replica.py):备份完成后异步推送;本地文件丢失时恢复可从副本拉回
    sha256: Mapped[str | None] = mapped_column(String(64))            # 推送时单次流式计算的整文件校验和
    replica_status: Mapped[str | None] = mapped_column(String(16))    # None=未启用 | pending | done | failed
    replica_key: Mapped[str | None] = mapped_column(String(512))      # 对象存储里的 key
    replica_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    replica_error: Mapped[str | None] = mapped_column(String(512))


class TenantBackupPolicy(Base):
    """组织级自动备份策略(组织管理员可在「组织设置」中配置)。

    mode = inherit:沿用平台默认(系统设置 backup.*);custom:使用本行字段。
    """

    __tablename__ = "tenant_backup_policies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), unique=True, index=True)
    mode: Mapped[str] = mapped_column(String(16), default="inherit")  # inherit | custom
    auto_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    auto_hour: Mapped[int] = mapped_column(Integer, default=3)  # 0-23,服务器本地时间
    auto_kinds: Mapped[str] = mapped_column(String(64), default="production")  # 逗号分隔
    keep_days: Mapped[int] = mapped_column(Integer, default=7)  # 自动/恢复前备份保留天数
    include_filestore: Mapped[bool] = mapped_column(Boolean, default=True)
    include_extra_dbs: Mapped[bool] = mapped_column(Boolean, default=False)  # 自动备份是否也备份附加库
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_by: Mapped[str | None] = mapped_column(String(64))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )


class RestoreJob(Base):
    """一次恢复操作的记录。"""

    __tablename__ = "restore_jobs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    backup_id: Mapped[int | None] = mapped_column(ForeignKey("backups.id", ondelete="SET NULL"), nullable=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    environment_id: Mapped[int | None] = mapped_column(
        ForeignKey("environments.id", ondelete="SET NULL"), nullable=True, index=True
    )
    env_name: Mapped[str] = mapped_column(String(64))
    database_id: Mapped[int | None] = mapped_column(Integer, nullable=True)  # 恢复到附加库时指向它;None = 主库
    db_name: Mapped[str | None] = mapped_column(String(96))
    neutralize: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(16), default="running")  # running | done | failed
    message: Mapped[str | None] = mapped_column(String(512))
    log: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


# ---------------------------------------------------------------- 远程备份目标(用户自有:S3 / SFTP / WebDAV)
class BackupTarget(Base):
    """用户自己的远程备份目标(自己的服务器 / NAS / 对象存储)。只有创建者本人与超管可见可改。

    config(JSON)按类型存连接参数;密钥字段(secret_key / password / private_key)以 Fernet 加密后存入。
      s3:     endpoint, bucket, region, access_key, secret_key, path_style(bool)
      sftp:   host, port, username, password | private_key(PEM 文本), base_path
      webdav: url(目录 URL), username, password
    """

    __tablename__ = "backup_targets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), index=True)
    owner_user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(64))
    kind: Mapped[str] = mapped_column(String(16))  # s3 | sftp | webdav
    config: Mapped[str] = mapped_column(Text, default="{}")
    prefix: Mapped[str | None] = mapped_column(String(256))  # 远端子目录 / 对象前缀;空 = 根
    keep_days: Mapped[int] = mapped_column(Integer, default=0)  # 远端保留天数;0 = 不自动清理
    delete_with_local: Mapped[bool] = mapped_column(Boolean, default=False)  # 本地删除备份时是否同步删远端
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_test_ok: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    last_test_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_error: Mapped[str | None] = mapped_column(String(512))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class EnvironmentBackupConfig(Base):
    """实例级备份配置:推送到哪些远程目标 + 自动备份覆盖(inherit 沿用组织策略 / custom 自定义 / off 关闭)。"""

    __tablename__ = "environment_backup_configs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    environment_id: Mapped[int] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), unique=True, index=True)
    target_ids: Mapped[str] = mapped_column(Text, default="[]")  # JSON list[int]
    auto_mode: Mapped[str] = mapped_column(String(16), default="inherit")  # inherit | custom | off
    auto_hour: Mapped[int] = mapped_column(Integer, default=3)
    include_filestore: Mapped[bool] = mapped_column(Boolean, default=True)
    include_extra_dbs: Mapped[bool] = mapped_column(Boolean, default=False)
    keep_days: Mapped[int] = mapped_column(Integer, default=7)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_by: Mapped[str | None] = mapped_column(String(64))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class BackupReplica(Base):
    """某个备份在某个远程目标上的副本状态。"""

    __tablename__ = "backup_replicas"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    backup_id: Mapped[int] = mapped_column(ForeignKey("backups.id", ondelete="CASCADE"), index=True)
    target_id: Mapped[int] = mapped_column(ForeignKey("backup_targets.id", ondelete="CASCADE"), index=True)
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending | done | failed | expired | deleted
    remote_key: Mapped[str | None] = mapped_column(String(512))
    sha256: Mapped[str | None] = mapped_column(String(64))
    size_bytes: Mapped[int] = mapped_column(BigInteger, default=0)
    error: Mapped[str | None] = mapped_column(String(512))
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    pushed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
