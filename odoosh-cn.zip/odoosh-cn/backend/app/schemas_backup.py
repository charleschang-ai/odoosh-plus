"""备份/恢复相关 schema(与 schemas.py 分离,避免与并行开发冲突)。"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class BackupOut(ORM):
    id: int
    tenant_id: int
    environment_id: int | None
    tenant_slug: str
    env_name: str
    odoo_version: str | None
    db_name: str | None
    database_id: int | None = None  # 附加库备份时指向 environment_databases.id;None = 主库
    kind: str
    status: str
    message: str | None
    note: str | None
    filename: str | None
    size_bytes: int
    include_filestore: bool
    created_by: str | None
    created_at: datetime
    finished_at: datetime | None
    sha256: str | None = None
    replica_status: str | None = None  # None=未启用异地副本 | pending | done | failed
    replica_at: datetime | None = None
    replica_error: str | None = None
    replicas: list["ReplicaBrief"] = []  # 用户自有远程目标的副本状态


class BackupCreate(BaseModel):
    environment_id: int
    database_id: int | None = None  # 备份该实例的附加库;None = 主库
    note: str | None = Field(default=None, max_length=256)
    include_filestore: bool = True
    location: str = Field(default="local", pattern=r"^(local|remote)$")  # local=仅本地;remote=本地+推送到 target_ids
    target_ids: list[int] = []  # location=remote 时要推送到的远程目标(须属于本人);留空=用实例已配置的目标


class RestoreIn(BaseModel):
    """把某个备份恢复到 environment_id 指定的环境(可与备份来源环境不同)。"""

    environment_id: int
    database_id: int | None = None  # 恢复到该实例的附加库;None = 主库
    neutralize: bool = False  # 停用定时任务/外发邮件等(恢复到测试/开发环境时建议勾选)
    backup_before: bool = True  # 恢复前先给目标环境做一次备份
    force: bool = False  # 备份与目标实例 Odoo 大版本不一致时,需显式确认才放行


class RestoreJobOut(ORM):
    id: int
    backup_id: int | None
    tenant_id: int
    environment_id: int | None
    env_name: str
    database_id: int | None = None
    db_name: str | None = None
    neutralize: bool
    status: str
    message: str | None
    created_by: str | None
    created_at: datetime
    finished_at: datetime | None


class RestoreJobDetail(RestoreJobOut):
    log: str | None = None


class BackupStatsOut(BaseModel):
    total: int
    total_bytes: int
    running: int
    # 当前组织(tenant_id 过滤时)或平台默认的自动备份状态
    scheduler_enabled: bool
    next_run: str | None = None
    last_run: str | None = None
    policy_mode: str | None = None  # inherit | custom;平台视角为 None


class BackupPolicyOut(BaseModel):
    tenant_id: int
    tenant_slug: str
    mode: str  # inherit | custom
    # 本行为组织自定义值(mode=custom 时生效)
    auto_enabled: bool
    auto_hour: int
    auto_kinds: list[str]
    keep_days: int
    include_filestore: bool
    include_extra_dbs: bool = False  # 自动备份是否也备份附加库
    # 实际生效值(合并平台默认后)
    effective: dict
    platform_defaults: dict
    storage_dir: str  # 该组织备份所在目录(只读展示)
    last_run_at: datetime | None
    next_run: str | None
    updated_by: str | None
    updated_at: datetime | None


class BackupPolicyIn(BaseModel):
    mode: str = Field(pattern=r"^(inherit|custom)$")
    auto_enabled: bool = False
    auto_hour: int = Field(default=3, ge=0, le=23)
    auto_kinds: list[str] = ["production"]
    keep_days: int = Field(default=7, ge=0, le=3650)
    include_filestore: bool = True
    include_extra_dbs: bool = False


# ---------------------------------------------------------------- 远程备份目标(用户自有)/ 实例备份配置
class ReplicaBrief(BaseModel):
    id: int
    target_id: int
    target_name: str
    kind: str | None = None
    status: str
    error: str | None = None
    pushed_at: datetime | None = None
    sha256: str | None = None
    attempts: int = 0


class BackupTargetOut(BaseModel):
    id: int
    tenant_id: int
    owner_user_id: int
    owner_name: str | None = None
    name: str
    kind: str
    config: dict  # 密钥字段已掩码
    describe: str
    prefix: str | None = None
    keep_days: int = 0
    delete_with_local: bool = False
    enabled: bool = True
    last_test_ok: bool | None = None
    last_test_at: datetime | None = None
    last_error: str | None = None
    in_use: int = 0  # 被多少个实例引用
    created_at: datetime
    updated_at: datetime | None = None


class BackupTargetIn(BaseModel):
    tenant_id: int | None = None  # 新建时必填(超管可指定任意组织;普通用户须是该组织成员)
    name: str = Field(min_length=1, max_length=64)
    kind: str = Field(pattern=r"^(s3|sftp|webdav)$")
    config: dict = {}
    prefix: str | None = Field(default=None, max_length=256)
    keep_days: int = Field(default=0, ge=0, le=3650)
    delete_with_local: bool = False
    enabled: bool = True


class EnvBackupConfigOut(BaseModel):
    environment_id: int
    target_ids: list[int]
    targets: list[dict]  # 当前可选目标(自己的 + 已选中的)[{id,name,kind,describe,enabled,mine}]
    auto_mode: str  # inherit | custom | off
    auto_hour: int
    include_filestore: bool
    include_extra_dbs: bool
    keep_days: int
    tenant_effective: dict  # 组织生效策略(inherit 时实际用它)
    effective: dict  # 本实例实际生效
    next_run: str | None = None
    last_run_at: datetime | None = None
    updated_by: str | None = None
    updated_at: datetime | None = None


class EnvBackupConfigIn(BaseModel):
    target_ids: list[int] = []
    auto_mode: str = Field(default="inherit", pattern=r"^(inherit|custom|off)$")
    auto_hour: int = Field(default=3, ge=0, le=23)
    include_filestore: bool = True
    include_extra_dbs: bool = False
    keep_days: int = Field(default=7, ge=0, le=3650)


BackupOut.model_rebuild()
