"""Git 仓库对接相关模型。

单独成文件是为了与 models.py(环境编排部分正在并行开发)解耦;
后续稳定后可合并回 models.py。main.py 只要 import 了本模块,create_all 就会建表。
"""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, func, inspect, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .crypto import EncryptedText
from .db import Base


class GitAccount(Base):
    """用户通过 OAuth 连接的 GitHub / Gitee 账号(令牌属于用户,不属于租户)。"""

    __tablename__ = "git_accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    provider: Mapped[str] = mapped_column(String(16))  # github | gitee
    login: Mapped[str] = mapped_column(String(128))
    display_name: Mapped[str | None] = mapped_column(String(128))
    avatar_url: Mapped[str | None] = mapped_column(String(512))
    access_token: Mapped[str] = mapped_column(EncryptedText())  # 加密存储
    refresh_token: Mapped[str | None] = mapped_column(EncryptedText())
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))  # Gitee 令牌 1 天过期,需刷新
    scopes: Mapped[str | None] = mapped_column(String(256))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    repositories: Mapped[list["Repository"]] = relationship(back_populates="account")


class Repository(Base):
    """一个 Git 仓库(属于某个租户)。环境通过 repo_url + branch 与之关联。"""

    __tablename__ = "repositories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    # scope=platform(平台共享,仅超管可建,tenant_id 为空)| tenant(属于某组织)
    tenant_id: Mapped[int | None] = mapped_column(ForeignKey("tenants.id"), index=True, nullable=True)
    scope: Mapped[str] = mapped_column(String(16), default="tenant")
    # 标记为 Odoo 企业版代码仓库:分支按版本命名(17.0/18.0/19.0),不用于业务代码,创建企业版实例时按需拉取并只读挂载
    is_enterprise: Mapped[bool] = mapped_column(Boolean, default=False)
    # 接入者:组织仓库只有接入者本人(与超管)可见/可管;为空的旧记录由组织管理员接管
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(128))
    url: Mapped[str] = mapped_column(String(256))  # HTTPS clone 地址
    provider: Mapped[str] = mapped_column(String(16), default="generic")  # github | gitee | gitlab | generic
    owner: Mapped[str | None] = mapped_column(String(128))  # 从 URL 解析:组织/用户
    repo: Mapped[str | None] = mapped_column(String(128))  # 从 URL 解析:仓库名
    token: Mapped[str | None] = mapped_column(EncryptedText())  # 手动填写的访问令牌(私有仓库 / API),加密存储
    account_id: Mapped[int | None] = mapped_column(ForeignKey("git_accounts.id"), nullable=True)  # 通过 OAuth 账号接入
    webhook_secret: Mapped[str] = mapped_column(EncryptedText())  # 加密存储
    webhook_id: Mapped[str | None] = mapped_column(String(64))  # 平台自动创建的 webhook 在 Git 平台上的 id
    default_branch: Mapped[str | None] = mapped_column(String(128))
    auto_deploy: Mapped[bool] = mapped_column(Boolean, default=True)  # 收到 push 后是否触发环境重新部署
    branches_json: Mapped[str | None] = mapped_column(Text)  # 最近一次同步到的分支快照(JSON)
    branches_synced_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_error: Mapped[str | None] = mapped_column(String(512))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    account: Mapped[GitAccount | None] = relationship(back_populates="repositories")
    events: Mapped[list["PushEvent"]] = relationship(back_populates="repository", cascade="all, delete-orphan")


class PushEvent(Base):
    """Webhook 收到的一次推送。"""

    __tablename__ = "push_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    repository_id: Mapped[int] = mapped_column(ForeignKey("repositories.id"), index=True)
    branch: Mapped[str] = mapped_column(String(128))
    commit_sha: Mapped[str | None] = mapped_column(String(64))
    commit_message: Mapped[str | None] = mapped_column(String(512))
    author: Mapped[str | None] = mapped_column(String(128))
    pusher: Mapped[str | None] = mapped_column(String(128))
    deleted: Mapped[bool] = mapped_column(Boolean, default=False)  # 分支被删除
    matched_env_ids: Mapped[str | None] = mapped_column(String(256))  # 逗号分隔的环境 id
    result: Mapped[str | None] = mapped_column(String(256))  # 处理结果描述
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    repository: Mapped[Repository] = relationship(back_populates="events")


# 在引入 Alembic 之前的轻量迁移:给已存在的表补新增列(create_all 不会改已有表)
_ADDED_COLUMNS = {
    "repositories": {
        "account_id": "INTEGER REFERENCES git_accounts(id)",
        "webhook_id": "VARCHAR(64)",
        "scope": "VARCHAR(16) DEFAULT 'tenant'",
        "is_enterprise": "BOOLEAN DEFAULT FALSE",
        "created_by": "INTEGER REFERENCES users(id)",
    },
}
# 需要放宽的约束
_RELAX = [("repositories", "tenant_id")]


def ensure_schema(engine) -> None:
    insp = inspect(engine)
    with engine.begin() as conn:
        for table, cols in _ADDED_COLUMNS.items():
            if not insp.has_table(table):
                continue
            existing = {c["name"] for c in insp.get_columns(table)}
            for col, ddl in cols.items():
                if col not in existing:
                    conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}"))
        for table, col in _RELAX:
            if insp.has_table(table):
                try:
                    conn.execute(text(f"ALTER TABLE {table} ALTER COLUMN {col} DROP NOT NULL"))
                except Exception:  # noqa: BLE001
                    pass
