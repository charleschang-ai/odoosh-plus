"""接入令牌(仅超级管理员签发)。

用途:第三方系统在服务端持令牌调用 /api/ext/* —— 同步用户、开通实例、换取免登地址。

设计原则(见 docs/work-2026-09-04-odoo-integration-design.md 第 0 节):
**OdooshCN 提供机制,接入方提供策略。** 令牌上只放与业务无关的安全上限,不放「学生模板 / 老师模板」
这类接入方语义;角色、配额、菜单开关、实例规格由调用方逐次传入,平台只校验不越界。

- 明文只在创建时回显一次;库里只存 SHA-256 哈希,prefix(前 12 位)仅供列表辨认。
- 绑定一个组织:所有读写只能落在这一个组织,调用方无法指定别的组织。
- 创建者被停用 / 不再是超管、组织停用、到期、吊销 → 令牌立即失效(每次使用都重新校验)。
- scopes 决定能调哪些接口;上限字段决定能授予到什么程度。二者都不可被请求体覆盖。
"""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base

# 权限范围:handoff = 换免登地址;users:write = 建 / 改 / 停用用户;envs:read = 查实例;envs:write = 开通实例
SCOPES = ("handoff", "users:write", "envs:read", "envs:write")
SCOPE_LABEL = {"handoff": "免登入口", "users:write": "同步用户", "envs:read": "查询实例", "envs:write": "开通实例"}


class ApiToken(Base):
    __tablename__ = "api_tokens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)      # 创建者(超管)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), index=True)  # 绑定组织
    name: Mapped[str] = mapped_column(String(64))
    prefix: Mapped[str] = mapped_column(String(16))
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    scopes: Mapped[str] = mapped_column(String(128), default="handoff", server_default="handoff")  # 逗号分隔
    # 外部来源标识:同步进来的用户记在 users.external_source,用于区分多个接入系统
    source: Mapped[str] = mapped_column(String(64), default="external", server_default="external")
    # ---- 安全上限(与业务无关,调用方无法覆盖)----
    max_grant_role: Mapped[str] = mapped_column(String(16), default="developer", server_default="developer")  # 最多能授予的组织角色
    max_envs_per_user: Mapped[int] = mapped_column(Integer, default=1, server_default="1")  # 单个用户最多几个实例;0 = 不允许开通
    allow_create_user: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")  # 关 = 只能更新已存在的用户
    # 是否允许把用户设为平台管理员(超管)。默认关:超管能看所有组织,令牌泄露后果最重,须显式打开
    allow_admin_role: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    # 是否允许请求里指定别的组织(按 id 或 slug)。默认关:只能落在绑定组织;开了以后可接多个班级 / 部门
    allow_any_tenant: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    # 是否允许删除用户(不可恢复)。默认关:停用足以应付退课,真删只在接入方明确要求「删除即删除」时才开
    allow_delete_user: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    # ---- 界面默认值(非安全项)----
    # 免登进入控制台时默认隐藏左侧菜单:嵌入 iframe 的接入方自带导航,不需要两套。
    # handoff 的 menu 参数可按次覆盖(false=隐藏,true=显示,不传=用这里的默认)
    hide_nav: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_used_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
