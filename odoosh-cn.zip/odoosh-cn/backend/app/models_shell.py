"""实例 Shell(Web 终端)会话审计。"""

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


class ShellSession(Base):
    __tablename__ = "shell_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    environment_id: Mapped[int | None] = mapped_column(ForeignKey("environments.id", ondelete="SET NULL"), nullable=True, index=True)
    tenant_id: Mapped[int] = mapped_column(Integer, index=True)
    env_name: Mapped[str] = mapped_column(String(64))
    env_kind: Mapped[str] = mapped_column(String(16))
    user_id: Mapped[int | None] = mapped_column(Integer)
    username: Mapped[str | None] = mapped_column(String(64))
    client_ip: Mapped[str | None] = mapped_column(String(64))
    container_user: Mapped[str | None] = mapped_column(String(32))  # odoo / root
    status: Mapped[str] = mapped_column(String(16), default="open")  # open | closed | failed
    message: Mapped[str | None] = mapped_column(String(256))
    bytes_in: Mapped[int] = mapped_column(BigInteger, default=0)
    bytes_out: Mapped[int] = mapped_column(BigInteger, default=0)
    # 生产环境默认录制键盘输入(命令审计),最多保留 200KB
    input_log: Mapped[str | None] = mapped_column(Text)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
