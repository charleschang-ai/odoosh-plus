"""附加数据库(一个实例多个库)。

一个实例(容器 + 一份代码)= 1 个主库(Environment.db_name)+ N 个附加库(本表)。
附加库与主库共用容器、代码、db_user、filestore 目录(filestore/filestore/<db_name>),
只是多一个 PostgreSQL 数据库和一个子域名 <name>.<实例域名>;Odoo 靠 dbfilter(%d)按域名选库。

本表只存附加库,主库仍以 Environment.db_name 为准(避免两处真相)。域名不落库,按实例当前域名动态拼接。
"""

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, ForeignKey, Integer, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column

from .crypto import EncryptedText
from .db import Base


class EnvironmentDatabase(Base):
    __tablename__ = "environment_databases"
    __table_args__ = (UniqueConstraint("environment_id", "name", name="uq_env_db_name"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    environment_id: Mapped[int] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), index=True)
    tenant_id: Mapped[int] = mapped_column(Integer, index=True)
    name: Mapped[str] = mapped_column(String(32))  # 用户可见短名(a-z0-9),同实例内唯一;也是子域名第一段
    db_name: Mapped[str] = mapped_column(String(96), index=True)  # <主库>_<name>
    # creating → ready | failed;dropping
    status: Mapped[str] = mapped_column(String(16), default="creating", index=True)
    status_message: Mapped[str | None] = mapped_column(String(256))
    progress: Mapped[int] = mapped_column(Integer, default=0)
    source: Mapped[str | None] = mapped_column(String(16))  # empty | template | clone | backup
    source_ref: Mapped[str | None] = mapped_column(String(128))  # clone 源库名 / 备份 id
    options: Mapped[str | None] = mapped_column(String(256))  # 创建选项 JSON,如 {"neutralize": true}
    admin_login: Mapped[str | None] = mapped_column(String(128))  # 该库管理员登录名(原生建库时填的邮箱;None = admin)
    admin_password: Mapped[str | None] = mapped_column(EncryptedText())  # 该库 Odoo 管理员密码(加密)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)  # None = 跟随实例
    size_bytes: Mapped[int | None] = mapped_column(BigInteger, nullable=True)  # 由 metrics 采集刷新
    created_by: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
