"""AI 功能相关表:用户级 LLM 配置(BYOK)、会话、消息、工具调用审计、token 用量。

- api_key 每用户一份,加密存储,读取只回尾 4 位(见 routers/ai.py);超管也看不到别人的 key。
- ai_messages 逐条即时落库:恢复会话 = 从 DB 按 seq 重放(loop._load_history 会修复中止产生的孤儿 tool_call)。
- content_full:上下文压缩只影响「喂给模型的视图」,原文存档在这里,前端展示与追溯用。
"""

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, deferred, mapped_column

from .crypto import EncryptedText
from .db import Base


class AiUserConfig(Base):
    """每个用户自己的 LLM 接入配置(BYOK:自带 API key)。"""

    __tablename__ = "ai_user_configs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), unique=True, index=True)
    provider: Mapped[str] = mapped_column(String(32), default="deepseek")  # deepseek|qwen|zhipu|moonshot|custom(前端预设填 base_url/model)
    base_url: Mapped[str | None] = mapped_column(String(256))  # OpenAI 兼容端点,如 https://api.deepseek.com/v1
    model: Mapped[str | None] = mapped_column(String(128))
    api_key: Mapped[str | None] = mapped_column(EncryptedText())
    # 每日 token 用量上限(prompt+completion,按自然日);None = 用平台默认 ai.daily_token_limit_default;0 = 不限
    max_daily_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class AiConversation(Base):
    __tablename__ = "ai_conversations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    mode: Mapped[str] = mapped_column(String(16), default="help")  # ops = 超管运维;assist = 租户组织级助手;help = 纯问答
    # assist 模式钉死的组织:AI 只在这家组织内找实例,再逐个 check_env;super 的 ops 为空(全域)
    tenant_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    title: Mapped[str | None] = mapped_column(String(160))
    # idle | running:发消息时单条原子 UPDATE 抢占(routers/ai._claim_run),避免同会话并发跑两个 agent;
    # api 重启后 lifespan 把遗留 running 复位为 idle
    state: Mapped[str] = mapped_column(String(16), default="idle")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class AiMessage(Base):
    __tablename__ = "ai_messages"
    __table_args__ = (UniqueConstraint("conversation_id", "seq", name="uq_ai_msg_conv_seq"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    conversation_id: Mapped[int] = mapped_column(ForeignKey("ai_conversations.id", ondelete="CASCADE"), index=True)
    seq: Mapped[int] = mapped_column(Integer)
    role: Mapped[str] = mapped_column(String(16))  # user | assistant | tool | system(运行时注入的通知)
    content: Mapped[str | None] = mapped_column(Text)
    # 压缩/截断前的原文存档(仅在被压缩时写入;None = content 即原文)
    content_full: Mapped[str | None] = deferred(mapped_column(Text, nullable=True))
    tool_calls: Mapped[str | None] = mapped_column(Text)  # assistant 消息的工具调用,JSON 数组
    tool_call_id: Mapped[str | None] = mapped_column(String(64))  # tool 消息回应的调用 id
    name: Mapped[str | None] = mapped_column(String(64))  # tool 消息的工具名
    meta: Mapped[str | None] = mapped_column(Text)  # JSON:{aborted, usage, status, ...}
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class AiToolRun(Base):
    """工具调用审计:谁在哪个会话里跑了什么、批准渠道、结果。"""

    __tablename__ = "ai_tool_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    conversation_id: Mapped[int] = mapped_column(Integer, index=True)
    user_id: Mapped[int] = mapped_column(Integer, index=True)
    tool: Mapped[str] = mapped_column(String(64))
    args_summary: Mapped[str | None] = mapped_column(String(512))
    status: Mapped[str] = mapped_column(String(16))  # ok | rejected | denied | error | timeout
    approval: Mapped[str | None] = mapped_column(String(24))  # auto(只读) | user_confirm | denied | timeout_denied | mcp
    duration_ms: Mapped[int | None] = mapped_column(Integer)
    detail: Mapped[str | None] = mapped_column(Text)  # 失败原因 / 结果摘要
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class AiTokenUsage(Base):
    """每次 LLM 调用的 token 用量(预算检查按 user_id + 当日求和)。"""

    __tablename__ = "ai_token_usage"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(Integer, index=True)
    conversation_id: Mapped[int | None] = mapped_column(Integer)
    provider: Mapped[str | None] = mapped_column(String(32))
    model: Mapped[str | None] = mapped_column(String(128))
    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)
