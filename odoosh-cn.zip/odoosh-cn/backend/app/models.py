from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .crypto import EncryptedText
from .db import Base


class Tenant(Base):
    """租户 = 隔离边界(一个客户/组织)。"""

    __tablename__ = "tenants"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    slug: Mapped[str] = mapped_column(String(64), unique=True, index=True)  # 用于容器/网络命名
    name: Mapped[str] = mapped_column(String(128))
    description: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    pg_password: Mapped[str | None] = mapped_column(EncryptedText())  # 租户 PG 容器的超级用户口令(加密存储)
    # 本组织开发实例的默认闲置休眠小时数(None = 用平台全局 sleep.idle_hours;0 = 不休眠);每实例还可再覆盖
    sleep_idle_hours: Mapped[float | None] = mapped_column(Float, nullable=True)
    # 附加数据库配额(社区版实例):每实例最多几个附加库(None = 平台默认 db.max_extra_per_env);组织总量(None = 不限)
    max_dbs_per_env: Mapped[int | None] = mapped_column(Integer, nullable=True)
    max_dbs_total: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    users: Mapped[list["User"]] = relationship(back_populates="tenant")
    environments: Mapped[list["Environment"]] = relationship(back_populates="tenant")


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(128))
    display_name: Mapped[str | None] = mapped_column(String(128))
    # 平台级角色:admin = 超级管理员;member = 普通用户(租户内角色见 memberships)
    role: Mapped[str] = mapped_column(String(32), default="member")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # 是否允许使用实例 Shell(Web 终端);仅超级管理员可设置,超管自身始终允许。未开启的用户看不到 Shell Tab
    shell_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    # 实例配额:该用户作为「拥有者」(Environment.owner_user_id)最多可有多少个实例(不含回收站里的)。
    # None = 不限;0 = 不能创建。仅超级管理员可设,超管自身不受限。按拥有者计数,不按有权访问的实例计数
    max_envs: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # 附加数据库配额:该用户最多可创建多少个附加库(按 environment_databases.created_by 计数,跨实例)。None = 不限;0 = 不能创建。仅超管可设,超管不受限
    max_dbs: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # 是否允许创建企业版实例(默认允许)。关闭后该用户在创建实例时看不到「企业版」选项。仅超管可设,超管自身始终允许
    can_use_enterprise: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    # 菜单可见性开关(默认全开;关 = 该用户看不到对应菜单,直接访问其地址也会跳回实例列表)。仅超管可设,超管自身不受限
    menu_dashboard: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")  # 总览
    menu_repos: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")      # Git 仓库
    menu_ai: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")         # AI 助手
    menu_backups: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")    # 备份与恢复
    # 实例详情页 Tab 开关(与上面四个侧栏菜单不同,默认关:教学等受限场景按人打开;超管不受限)
    menu_settings: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")  # 「设置」Tab
    menu_upgrade: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")   # 「升级」Tab
    menu_databases: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")  # 「数据库」Tab
    # 令牌版本:改密 / 停用时 +1,使已签发的 JWT 全部失效
    token_version: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    # 外部身份(第三方系统同步而来;见 models_token.ApiToken 与 services/extsync.py)。
    # 两列都为空 = 平台内建的账号,永远不会被同步逻辑匹配到。(external_source, external_id) 联合唯一。
    external_source: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)  # 来源标识,取自令牌
    external_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)     # 该来源里的稳定主键
    # 旧字段(一人一租户时代),已由 memberships 取代;保留仅为兼容迁移
    tenant_id: Mapped[int | None] = mapped_column(ForeignKey("tenants.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    tenant: Mapped[Tenant | None] = relationship(back_populates="users")
    memberships: Mapped[list["Membership"]] = relationship(back_populates="user", cascade="all, delete-orphan")

    @property
    def is_superadmin(self) -> bool:
        return self.role == "admin"


class Membership(Base):
    """用户在某租户内的角色(仿 odoo.sh 项目协作者):owner | developer | tester。"""

    __tablename__ = "memberships"
    __table_args__ = (UniqueConstraint("user_id", "tenant_id", name="uq_membership_user_tenant"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(16), default="developer")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    user: Mapped[User] = relationship(back_populates="memberships")
    tenant: Mapped[Tenant] = relationship()


class Environment(Base):
    """一个 Odoo 环境(对应一个分支)。此阶段只是元数据,还不驱动容器。"""

    __tablename__ = "environments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    name: Mapped[str] = mapped_column(String(64))  # 例如 production / staging / feature-x
    kind: Mapped[str] = mapped_column(String(16), default="dev")  # production | staging | dev
    odoo_version: Mapped[str] = mapped_column(String(8), default="18")
    base_mode: Mapped[str] = mapped_column(String(16), default="official")  # official=官方镜像 | custom=源码自建
    edition: Mapped[str] = mapped_column(String(16), default="community")  # community | enterprise
    # 主库初始语言(创建实例时选;空库初始化后加载该语言并设为管理员 / 新用户默认语言);克隆 / 恢复来的库不适用
    lang: Mapped[str | None] = mapped_column(String(16), default="zh_CN")
    # 企业版:实际挂载的代码目录与 commit(来自被标记为企业版的 Git 仓库,按需拉取、复用)
    enterprise_path: Mapped[str | None] = mapped_column(String(512))
    enterprise_commit: Mapped[str | None] = mapped_column(String(64))
    enterprise_repo_id: Mapped[int | None] = mapped_column(Integer)
    # 自定义代码(来自 repo_url + branch):当前挂载的检出目录与 commit
    code_path: Mapped[str | None] = mapped_column(String(512))
    code_commit: Mapped[str | None] = mapped_column(String(64))
    # 仓库 requirements.txt 的内容摘要:与上次成功安装一致则本次部署跳过 pip(依赖装在持久的 ~/.local)
    requirements_sha: Mapped[str | None] = mapped_column(String(64), nullable=True)
    # 部署默认动作:restart | update(指定模块)| update_all;update 的模块列表
    deploy_action: Mapped[str] = mapped_column(String(16), default="update_all")
    deploy_modules: Mapped[str | None] = mapped_column(String(512))
    auto_deploy: Mapped[bool] = mapped_column(Boolean, default=True)  # push 到该分支后自动部署(生产实例忽略)
    branch: Mapped[str | None] = mapped_column(String(128))
    repo_url: Mapped[str | None] = mapped_column(String(256))
    domain: Mapped[str | None] = mapped_column(String(256))
    # 端口直连模式(platform.access_mode=port)分配的宿主机端口;域名模式下不用但保留,便于两种模式来回切换
    public_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # created → provisioning → running ⇄ stopped → destroying;failed 可重试
    # 过渡态:provisioning / starting / stopping / restarting / destroying
    status: Mapped[str] = mapped_column(String(16), default="created", index=True)
    status_message: Mapped[str | None] = mapped_column(String(256))
    progress: Mapped[int] = mapped_column(Integer, default=0)  # 过渡态操作的进度 0-100
    # 过期自动删除:None = 永不
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    # 项目分组:从某实例的详情页按分支创建的环境,project_id = 该根实例 id;根实例本身为 None(项目 id = 自身 id)
    project_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    # 访问控制(仿 odoo.sh):创建者 = 实例拥有者,拥有全部权限;其他人须在授权名单(EnvironmentAcl)里才可见/可操作;超管恒可见。
    # None = 旧数据/未指定拥有者 → 退化为按组织角色矩阵判定
    owner_user_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    # 回收站:软删除时间;None = 正常。进回收站的实例容器停止、域名摘除,数据保留 env.trash_keep_days 天后彻底清理
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    # 闲置休眠(仅开发档):最后一次访问时间(nginx 访问 → 平台 API 记录);sleep_idle_hours None = 全局默认,0 = 不休眠
    last_active_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    sleep_idle_hours: Mapped[float | None] = mapped_column(Float, nullable=True)
    # 每实例资源上限(None = 使用全局设置 limits.*)
    mem_mb: Mapped[int | None] = mapped_column(Integer, nullable=True)
    cpus: Mapped[float | None] = mapped_column(Float, nullable=True)
    # Odoo 日志等级(写进 odoo.conf 的 log_level;None = 全局设置 odoo.log_level;重启后生效)。容器日志由 Docker 轮转(20MB×3),等级越低滚得越快
    log_level: Mapped[str | None] = mapped_column(String(16), nullable=True)
    # 附加数据库上限(None = 组织 / 平台默认);见 models_db.EnvironmentDatabase
    max_dbs: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # odoo.conf 附加项(白名单内的 key=value 文本 + 自定义 section;见 services/odooconf.py);平台全局附加项在设置 odoo.extra_conf;重启后生效
    extra_conf: Mapped[str | None] = mapped_column(Text, nullable=True)
    # 运行时坐标(编排器填写)
    image_tag: Mapped[str | None] = mapped_column(String(128))
    container_name: Mapped[str | None] = mapped_column(String(128))
    network_name: Mapped[str | None] = mapped_column(String(128))
    db_name: Mapped[str | None] = mapped_column(String(64))
    db_user: Mapped[str | None] = mapped_column(String(64))
    db_password: Mapped[str | None] = mapped_column(EncryptedText())  # 加密存储
    admin_password: Mapped[str | None] = mapped_column(EncryptedText())  # Odoo master password(加密存储)
    url: Mapped[str | None] = mapped_column(String(256))
    log: Mapped[str | None] = mapped_column(Text, deferred=True)  # 最近一次编排操作日志(延迟加载:列表接口不拉)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    tenant: Mapped[Tenant] = relationship(back_populates="environments")


class EnvironmentAcl(Base):
    """实例授权名单(项目级:挂在项目根实例上,项目内所有环境共享)。

    level: view(可访问:打开 Odoo / 看日志监控)| operate(可操作:启停部署备份 Shell)| manage(可管理:含编辑 / 删除 / 改名单)
    """

    __tablename__ = "environment_acl"
    __table_args__ = (UniqueConstraint("environment_id", "user_id", name="uq_env_acl"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    environment_id: Mapped[int] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    level: Mapped[str] = mapped_column(String(16), default="view")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Setting(Base):
    """平台级 key-value 设置。"""

    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str | None] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
