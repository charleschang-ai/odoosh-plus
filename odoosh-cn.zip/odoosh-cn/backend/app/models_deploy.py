"""部署记录(每次把某个 commit 部署到某个环境)。"""

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


class Deployment(Base):
    __tablename__ = "deployments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    environment_id: Mapped[int] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), index=True)
    tenant_id: Mapped[int] = mapped_column(Integer, index=True)
    repo_url: Mapped[str | None] = mapped_column(String(256))
    branch: Mapped[str | None] = mapped_column(String(128))
    commit_sha: Mapped[str | None] = mapped_column(String(64), index=True)
    commit_message: Mapped[str | None] = mapped_column(String(512))
    author: Mapped[str | None] = mapped_column(String(128))
    committed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    trigger: Mapped[str] = mapped_column(String(16), default="manual")  # create | manual | push | rollback
    action: Mapped[str] = mapped_column(String(16), default="restart")  # restart | update | update_all
    modules: Mapped[str | None] = mapped_column(String(512))  # action=update 时的模块列表(逗号分隔)
    databases: Mapped[str | None] = mapped_column(String(1024))  # 本次 -u 作用的库(逗号分隔库名);None = 全部
    db_results: Mapped[str | None] = mapped_column(Text)  # JSON {库名: "success"|"failed"|"skipped"}
    status: Mapped[str] = mapped_column(String(16), default="queued")  # queued | running | success | failed
    message: Mapped[str | None] = mapped_column(String(512))
    log: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[str | None] = mapped_column(String(64))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    @property
    def duration(self) -> float | None:
        if self.started_at and self.finished_at:
            return (self.finished_at - self.started_at).total_seconds()
        return None
