"""备份与恢复接口。

权限(基于 authz,仿 odoo.sh):
  查看列表/下载/上传      组织 developer 及以上
  发起备份                实例动作矩阵 backup(developer 对全部类型、tester 无)
  恢复                    实例动作矩阵 restore(developer 仅非生产,owner 全部);跨组织恢复仅超管
  删除备份                owner 任意;developer 仅限非生产实例的备份(来源实例已删除的备份视同生产)
  自动备份策略/立即执行    组织 owner;平台默认由超管在系统设置维护
"""

import os
import re
import shutil
from datetime import datetime, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import authz
from .. import schemas_backup as S
from ..auth import get_current_user
from ..db import SessionLocal, get_db
from ..models import Environment, Tenant, User
from ..models_backup import Backup, BackupTarget, RestoreJob, TenantBackupPolicy
from ..services import backup as svc
from ..services import jobs, orchestrator

router = APIRouter(prefix="/api/backups", tags=["backups"])

ENV_BUSY = orchestrator.BUSY_STATES  # 过渡态一律不接受备份 / 恢复


# ---------------------------------------------------------------- 权限辅助
def _get_env(env_id: int, db: Session, user: User, action: str = "view") -> Environment:
    env = db.get(Environment, env_id)
    if not env:
        raise HTTPException(404, "实例不存在")
    authz.check_env(db, user, env, action)
    return env


def _get_backup(bid: int, db: Session, user: User, minimum: str = "developer") -> Backup:
    b = db.get(Backup, bid)
    if not b:
        raise HTTPException(404, "备份不存在")
    env = db.get(Environment, b.environment_id) if b.environment_id else None
    if not authz.can_see_env_data(db, user, env, b.tenant_id, minimum=minimum):
        raise HTTPException(403, "无权访问该备份(不在其实例的授权名单内)" if minimum == "developer" else "下载备份需要该实例的「可管理」权限或组织管理员(备份里含密码哈希、邮件 / API 凭据)")
    return b


def _filter_visible(db: Session, user: User, rows: list) -> list:
    """备份 / 恢复记录列表:只保留用户在其实例上有「可操作」及以上权限的记录(孤儿记录仅组织管理员 / 超管)。"""
    if authz.is_superadmin(user):
        return rows
    env_ids = {r.environment_id for r in rows if r.environment_id}
    envs = {e.id: e for e in db.scalars(select(Environment).where(Environment.id.in_(env_ids or {-1}))).all()}
    roles = authz.env_roles_bulk(db, user, list(envs.values()))
    tenant_roles = authz.role_map(db, user)  # 一次查询(以前每条孤儿记录一次 SELECT)
    out = []
    for r in rows:
        if r.environment_id and r.environment_id in envs:
            if authz.ROLE_RANK.get(roles.get(r.environment_id) or "", 0) >= authz.ROLE_RANK["developer"]:
                out.append(r)
        elif tenant_roles.get(r.tenant_id) == "owner":
            out.append(r)
    return out


def _can_delete_backup(db: Session, user: User, b: Backup) -> bool:
    role = authz.tenant_role(db, user, b.tenant_id)
    if role == "owner":
        return True
    if role != "developer":
        return False
    env = db.get(Environment, b.environment_id) if b.environment_id else None
    # 来源实例已不存在或为生产:开发者不可删
    return bool(env) and env.kind != "production"


def _scope_tenant(q, col, db: Session, user: User, tenant_id: int | None):
    ids = authz.accessible_tenant_ids(db, user)
    if ids is not None:
        q = q.where(col.in_(ids or [-1]))
    if tenant_id is not None:
        q = q.where(col == tenant_id)
    return q


# ---------------------------------------------------------------- 列表 / 统计
@router.get("", response_model=list[S.BackupOut])
def list_backups(
    tenant_id: int | None = None,
    environment_id: int | None = None,
    database_id: int | None = None,  # 0 = 只看主库备份;>0 = 只看该附加库;不传 = 全部
    limit: int = 500,
    offset: int = 0,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    q = _scope_tenant(select(Backup).order_by(Backup.id.desc()), Backup.tenant_id, db, user, tenant_id)
    if environment_id is not None:
        q = q.where(Backup.environment_id == environment_id)
    if database_id is not None:
        q = q.where(Backup.database_id == database_id) if database_id else q.where(Backup.database_id.is_(None))
    rows = db.scalars(q.offset(max(0, offset)).limit(max(1, min(limit, 2000)))).all()  # 以前无上限,全量物化
    rows = _filter_visible(db, user, rows)
    from ..services import remote

    reps = remote.replicas_for(db, [r.id for r in rows])
    out = []
    for r in rows:
        o = S.BackupOut.model_validate(r)
        o.replicas = [S.ReplicaBrief(**x) for x in reps.get(r.id, [])]
        out.append(o)
    return out


@router.get("/stats", response_model=S.BackupStatsOut)
def stats(tenant_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = _scope_tenant(
        select(func.count(Backup.id), func.coalesce(func.sum(Backup.size_bytes), 0)), Backup.tenant_id, db, user, tenant_id
    )
    qr = _scope_tenant(select(func.count(Backup.id)).where(Backup.status == "running"), Backup.tenant_id, db, user, tenant_id)
    total, total_bytes = db.execute(q).one()
    running = db.scalar(qr)
    if tenant_id is not None:
        authz.require_tenant_role(db, user, tenant_id, "developer")
        st = svc.policy_status(db, tenant_id)
    else:
        st = svc.scheduler_status()
    return S.BackupStatsOut(total=total, total_bytes=int(total_bytes), running=running, **st)


# ---------------------------------------------------------------- 创建备份
@router.post("", response_model=S.BackupOut, status_code=202)
def create_backup(
    body: S.BackupCreate,
    bg: BackgroundTasks,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    from ..services import databases as dbsvc

    env = _get_env(body.environment_id, db, user, "backup")
    if env.status in ENV_BUSY:
        raise HTTPException(409, f"实例正在 {env.status},请稍候")
    if not env.db_name:
        raise HTTPException(400, "实例尚未创建数据库,无法备份")
    try:
        target = dbsvc.view(db, env, body.database_id)  # 附加库视图:同实例、不同库名 / filestore
    except ValueError as ex:
        raise HTTPException(404, str(ex))
    if target.row is not None and target.row.status != "ready":
        raise HTTPException(409, "该附加数据库尚未就绪")
    # 备份位置:local=仅本地;remote=本地 + 推送到指定远程目标(默认用实例已配置的目标,可在弹窗里改)
    import json as _json

    from ..services import remote as remotesvc

    push_ids: str | None = "[]"
    if body.location == "remote":
        want = body.target_ids or remotesvc.env_target_ids(remotesvc.env_config(db, env.id))
        if not want:
            raise HTTPException(400, "选择了远程备份,但没有可用的远程目标;请先在实例备份设置里添加或勾选目标")
        mine = {x.id for x in db.scalars(select(BackupTarget).where(BackupTarget.owner_user_id == user.id)).all()} if not authz.is_superadmin(user) else None
        clean = []
        for i in want:
            tt = db.get(BackupTarget, i)
            if not tt or tt.tenant_id != env.tenant_id or not tt.enabled:
                raise HTTPException(400, f"远程目标 #{i} 不存在或已停用")
            if mine is not None and i not in mine:
                raise HTTPException(403, f"远程目标 #{i} 不属于你")
            clean.append(i)
        push_ids = _json.dumps(clean)
    if not svc.try_lock(env.id):
        raise HTTPException(409, "该实例正在备份或恢复中")
    try:
        t = db.get(Tenant, env.tenant_id)
        b = svc.new_backup_record(db, target, t, "manual", body.note, body.include_filestore, user.username, push_target_ids=push_ids)
        bg.add_task(jobs.spawn, svc.run_backup, b.id, env.id)
    except Exception:
        svc.unlock(env.id)  # 记录/派发失败时释放锁,否则该实例直到重启都不能再备份/恢复
        raise
    return b


# ---------------------------------------------------------------- 上传外部备份
_SAFE = re.compile(r"[^A-Za-z0-9._-]+")


async def _upload_common(request: Request, db: Session, user: User, tenant_id: int, environment_id: int | None,
                         note: str | None, filename: str | None, reader) -> Backup:
    """两种上传入口共用:预检(权限 / 上限 / 配额 / 空间)→ 流式落盘 → 校验 zip → 建记录。
    reader(dest_path) 在线程池里同步把请求体写到 dest_path,返回写入字节数;超限抛 ValueError。"""
    authz.require_tenant_role(db, user, tenant_id, "developer")
    t = db.get(Tenant, tenant_id)
    if not t:
        raise HTTPException(404, "组织不存在")
    env = None
    if environment_id is not None:
        env = _get_env(environment_id, db, user, "view")
        if env.tenant_id != tenant_id:
            raise HTTPException(400, "实例不属于该组织")
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    base = _SAFE.sub("_", os.path.splitext(filename or "upload")[0])[:80] or "upload"
    rel = os.path.join(t.slug, "_uploads", f"{base}-{stamp}.zip")
    dest = os.path.join(svc.backups_root(), rel)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    # 先按 Content-Length 做体积上限 / 配额 / 剩余空间预检(以前要把 4GB 全写完才发现超限或没空间)
    try:
        declared = int(request.headers.get("content-length") or 0)
    except ValueError:
        declared = 0
    if declared:
        if declared > svc.upload_limit_bytes():
            raise HTTPException(413, f"文件超过上传上限 {svc.upload_limit_bytes() // (1024 * 1024)} MB(可在系统设置 backup.upload_max_mb 调整)")
        try:
            svc.check_quota_or_raise(db, t.id, declared)
            svc.check_free_space(svc.backups_root(), declared + (256 << 20))
        except RuntimeError as e:
            raise HTTPException(413, str(e))
    from starlette.concurrency import run_in_threadpool

    try:
        await reader(dest)
        manifest = await run_in_threadpool(svc.inspect_zip, dest)
    except ValueError as e:
        if os.path.exists(dest):
            os.remove(dest)
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001
        if os.path.exists(dest):
            os.remove(dest)
        raise HTTPException(500, f"保存失败: {e}")
    try:
        svc.check_quota_or_raise(db, t.id, os.path.getsize(dest))
    except RuntimeError as e:
        os.remove(dest)
        raise HTTPException(413, str(e))
    ver = str(manifest.get("major_version") or manifest.get("version") or "")
    b = Backup(
        tenant_id=t.id,
        environment_id=env.id if env else None,
        tenant_slug=t.slug,
        env_name=env.name if env else "(上传)",
        odoo_version=ver.split(".")[0] if ver else None,
        db_name=manifest.get("db_name"),
        kind="upload",
        status="done",
        note=note or f"上传:{filename}",
        filename=rel.replace(os.sep, "/"),
        size_bytes=os.path.getsize(dest),
        include_filestore=bool(manifest.get("_has_filestore")),  # 按 zip 实际内容;纯 SQL 备份恢复时不动目标 filestore
        created_by=user.username,
        finished_at=datetime.now(timezone.utc),
    )
    db.add(b)
    db.commit()
    db.refresh(b)
    return b


@router.put("/upload-stream", response_model=S.BackupOut, status_code=201)
async def upload_backup_stream(
    request: Request,
    tenant_id: int,
    environment_id: int | None = None,
    note: str | None = None,
    filename: str | None = None,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """上传备份(推荐入口):请求体就是 zip 本身(application/zip),按块直接写到备份目录 ——
    不经 multipart 解析,不再先在 api 容器 /tmp 缓存一份(4GB 上传以前要写两遍、还要求容器层有 4GB 空闲)。
    元数据走 query:tenant_id / environment_id / note / filename。"""
    limit = svc.upload_limit_bytes()

    async def reader(dest: str) -> int:
        total = 0
        # 直接在事件循环里异步读请求体、写文件:每块 1~4MB,写盘走系统页缓存,不会长时间阻塞
        with open(dest, "wb") as f:
            async for chunk in request.stream():
                if not chunk:
                    continue
                total += len(chunk)
                if total > limit:
                    raise ValueError(f"文件超过上传上限 {limit // (1024 * 1024)} MB(可在系统设置 backup.upload_max_mb 调整)")
                f.write(chunk)
        return total

    return await _upload_common(request, db, user, tenant_id, environment_id, note, filename, reader)


@router.post("/upload", response_model=S.BackupOut, status_code=201)
async def upload_backup(
    request: Request,
    tenant_id: int = Form(...),
    environment_id: int | None = Form(None),
    note: str | None = Form(None),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """上传 Odoo 数据库管理器导出的 zip(multipart 入口,兼容旧客户端 / 脚本;新前端用 PUT /upload-stream)。"""
    from starlette.concurrency import run_in_threadpool

    limit = svc.upload_limit_bytes()

    def _save(dest: str) -> int:
        total = 0
        with open(dest, "wb") as f:
            while True:
                chunk = file.file.read(4 * 1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit:
                    raise ValueError(f"文件超过上传上限 {limit // (1024 * 1024)} MB(可在系统设置 backup.upload_max_mb 调整)")
                f.write(chunk)
        return total

    async def reader(dest: str) -> int:
        return await run_in_threadpool(_save, dest)

    return await _upload_common(request, db, user, tenant_id, environment_id, note, file.filename, reader)


# ---------------------------------------------------------------- 恢复记录(需放在 /{bid} 之前)
@router.get("/restores/list", response_model=list[S.RestoreJobOut])
def list_restores(
    tenant_id: int | None = None,
    environment_id: int | None = None,
    limit: int = 50,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    q = _scope_tenant(select(RestoreJob).order_by(RestoreJob.id.desc()), RestoreJob.tenant_id, db, user, tenant_id)
    if environment_id is not None:
        q = q.where(RestoreJob.environment_id == environment_id)
    rows = db.scalars(q.limit(min(limit, 200))).all()
    rows = _filter_visible(db, user, rows)
    return rows


def _check_restore_visible(db: Session, user: User, j: RestoreJob) -> None:
    """恢复记录的可见性与备份列表一致:要求对目标实例有 developer 及以上的实例角色(孤儿记录看组织角色)。
    原来只校验组织级 developer,会让不在实例名单里的人读到他人生产环境的恢复日志。"""
    env = db.get(Environment, j.environment_id) if j.environment_id else None
    if not authz.can_see_env_data(db, user, env, j.tenant_id, minimum="developer"):
        raise HTTPException(403, "无权查看该恢复记录")


@router.get("/restores/{job_id}", response_model=S.RestoreJobDetail)
def get_restore(job_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    j = db.get(RestoreJob, job_id)
    if not j:
        raise HTTPException(404, "恢复任务不存在")
    _check_restore_visible(db, user, j)
    return j


@router.get("/restores/{job_id}/log/stream")
def restore_log_stream(job_id: int, token: str, db: Session = Depends(get_db)):
    """SSE:恢复任务日志(orch 事件),结束后发 end;前端不必再 2 秒轮询整段日志。"""
    import threading

    from fastapi.responses import StreamingResponse

    from ..auth import user_from_token
    from ..services import logstream

    user = user_from_token(token, db)
    j = db.get(RestoreJob, job_id)
    if not j:
        raise HTTPException(404, "恢复任务不存在")
    _check_restore_visible(db, user, j)
    q = logstream.subscribe(f"restore:{job_id}")
    stop = threading.Event()
    initial = (j.log or "").splitlines()
    finished = j.status in ("done", "failed")

    def is_done():
        from ..db import SessionLocal

        with SessionLocal() as s_:
            row = s_.get(RestoreJob, job_id)
            return not row or row.status in ("done", "failed")

    def gen():
        try:
            yield logstream.sse("reset", "")
            for ln in initial:
                yield logstream.sse("orch", ln)
            if finished:
                yield logstream.sse("end", "")
                return
            yield from logstream.stream(q, stop, is_done=is_done)
        finally:
            stop.set()
            logstream.unsubscribe(f"restore:{job_id}", q)

    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ---------------------------------------------------------------- 组织自动备份策略(组织管理员)
def _policy_out(db: Session, p: TenantBackupPolicy, t: Tenant) -> S.BackupPolicyOut:
    eff = svc.effective_policy(p)
    return S.BackupPolicyOut(
        tenant_id=t.id,
        tenant_slug=t.slug,
        mode=p.mode,
        auto_enabled=bool(p.auto_enabled),
        auto_hour=int(p.auto_hour or 0),
        auto_kinds=svc._split_kinds(p.auto_kinds) or ["production"],
        keep_days=int(p.keep_days or 0),
        include_filestore=bool(p.include_filestore),
        include_extra_dbs=bool(p.include_extra_dbs),
        effective=eff,
        platform_defaults=svc.platform_defaults(),
        storage_dir=svc.tenant_storage_dir(t.slug),
        last_run_at=p.last_run_at,
        next_run=svc.next_run_str(eff, p.last_run_at),
        updated_by=p.updated_by,
        updated_at=p.updated_at,
    )


@router.get("/policy/{tenant_id}", response_model=S.BackupPolicyOut)
def get_policy(tenant_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    authz.require_tenant_role(db, user, tenant_id, "developer")  # 开发者可看,owner 可改
    t = db.get(Tenant, tenant_id)
    if not t:
        raise HTTPException(404, "组织不存在")
    p = svc.get_policy(db, tenant_id, create=True)
    return _policy_out(db, p, t)


@router.put("/policy/{tenant_id}", response_model=S.BackupPolicyOut)
def put_policy(
    tenant_id: int, body: S.BackupPolicyIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    authz.require_tenant_role(db, user, tenant_id, "owner")
    t = db.get(Tenant, tenant_id)
    if not t:
        raise HTTPException(404, "组织不存在")
    kinds = [k for k in body.auto_kinds if k in ("production", "staging", "dev")]
    if body.mode == "custom" and body.auto_enabled and not kinds:
        raise HTTPException(400, "请至少选择一种实例类型")
    p = svc.get_policy(db, tenant_id, create=True)
    p.mode = body.mode
    p.auto_enabled = body.auto_enabled
    p.auto_hour = body.auto_hour
    p.auto_kinds = ",".join(kinds) or "production"
    p.keep_days = body.keep_days
    p.include_filestore = body.include_filestore
    p.include_extra_dbs = body.include_extra_dbs
    p.updated_by = user.username
    db.commit()
    db.refresh(p)
    return _policy_out(db, p, t)


@router.post("/policy/{tenant_id}/run-now")
def run_now_tenant(tenant_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """按该组织生效策略立即备份一轮(不受开关/时刻限制),并清理过期备份。"""
    authz.require_tenant_role(db, user, tenant_id, "owner")
    n = svc.run_auto_backups(tenant_id, who=user.username)
    return {"started": n}


# ---------------------------------------------------------------- 异地副本(超管)
@router.post("/replica/test")
def replica_test(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """系统设置页「测试连接」:用当前保存的 backup.replica_* 设置写读删一个小对象。"""
    authz.require_superadmin(user)
    from ..services import replica

    return replica.test_connection()


@router.post("/{bid}/replica/push")
def replica_push(bid: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """手动(重新)推送某个备份的异地副本。"""
    authz.require_superadmin(user)
    from ..services import replica

    b = _get_backup(bid, db, user)
    if b.status != "done":
        raise HTTPException(400, "备份尚未完成")
    if not replica.enabled():
        raise HTTPException(400, "未启用异地副本(系统设置 → 备份 → 异地副本)")
    replica.push_async(b.id)
    return {"ok": True}


# ---------------------------------------------------------------- 定时任务(超管:全部组织)
@router.post("/scheduler/run-now")
def run_now(bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    authz.require_superadmin(user)
    ids = list(db.scalars(select(Tenant.id).where(Tenant.is_active.is_(True))).all())
    n = svc.run_auto_backups(who=user.username, tenant_ids=ids)  # 一次处理(以前 O(租户²):每个租户各扫一遍全部租户)
    return {"started": n}


# ---------------------------------------------------------------- 单个备份
@router.get("/{bid}", response_model=S.BackupOut)
def get_backup(bid: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return _get_backup(bid, db, user)


# ---- 下载:两步走
#   1) POST /{bid}/download-ticket(带 Bearer)→ 5 分钟一次性票据
#   2) GET  /{bid}/download?t=<票据>  浏览器用 <a href> 直接下载(原来前端 axios responseType=blob 把几 GB 整个读进标签页内存)
#   支持 Range(断点续传 / 下载器多线程),FastAPI 0.115 的 FileResponse 还不会处理 Range,这里自己流。
DOWNLOAD_TICKET_TTL = 300


def _download_ticket(b: Backup, user: User) -> str:
    import time

    from jose import jwt

    from ..config import settings

    return jwt.encode({"sub": "bkdl", "bid": b.id, "uid": user.id, "tv": int(user.token_version or 0),
                       "exp": int(time.time()) + DOWNLOAD_TICKET_TTL}, settings.secret_key, algorithm="HS256")


@router.post("/{bid}/download-ticket")
def download_ticket(bid: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    # 下载 = 拿走整份数据库(res_users 密码哈希、SMTP / API 凭据都在里面):要求实例「可管理」或组织管理员,
    # 与查看实例 admin 口令的 secrets 权限对齐;「可操作」/ 开发者仍可在平台内恢复,但不能下载
    b = _get_backup(bid, db, user, minimum="owner")
    p = svc.backup_path(b)
    if b.status != "done" or not p or not os.path.isfile(p):
        raise HTTPException(404, "备份文件不存在或尚未完成")
    return {"ticket": _download_ticket(b, user), "ttl": DOWNLOAD_TICKET_TTL, "filename": os.path.basename(p), "size": os.path.getsize(p)}


def _ranged_file_response(path: str, request: Request, filename: str):
    """支持 Range 的流式文件响应(单段 bytes=a-b);无 Range 时整文件流式。"""
    from fastapi.responses import StreamingResponse

    size = os.path.getsize(path)
    rng = request.headers.get("range")
    start, end = 0, size - 1
    status = 200
    if rng and rng.startswith("bytes="):
        try:
            a, _, b_ = rng[6:].partition("-")
            if a:
                start = int(a)
                end = int(b_) if b_ else size - 1
            else:  # bytes=-N(最后 N 字节)
                start = max(0, size - int(b_))
            if start > end or start >= size:
                raise ValueError
            end = min(end, size - 1)
            status = 206
        except ValueError:
            from fastapi.responses import Response

            return Response(status_code=416, headers={"Content-Range": f"bytes */{size}"})
    length = end - start + 1

    def gen():
        with open(path, "rb") as f:
            f.seek(start)
            left = length
            while left > 0:
                chunk = f.read(min(1 << 20, left))
                if not chunk:
                    break
                left -= len(chunk)
                yield chunk

    from urllib.parse import quote

    headers = {
        "Accept-Ranges": "bytes",
        "Content-Length": str(length),
        "Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename)}",
        "Cache-Control": "no-store",
    }
    if status == 206:
        headers["Content-Range"] = f"bytes {start}-{end}/{size}"
    return StreamingResponse(gen(), status_code=status, media_type="application/zip", headers=headers)


@router.get("/{bid}/download")
def download(bid: int, request: Request, t: str | None = None, db: Session = Depends(get_db)):
    """t=票据(见 download-ticket);为兼容旧调用也接受 Authorization Bearer。"""
    user = None
    if t:
        from jose import JWTError, jwt

        from ..config import settings

        try:
            p = jwt.decode(t, settings.secret_key, algorithms=["HS256"])
            if p.get("sub") != "bkdl" or int(p.get("bid", -1)) != bid:
                raise JWTError("bad ticket")
            user = db.get(User, int(p.get("uid", 0)))
            if "tv" not in p:
                raise JWTError("bad ticket")
        except (JWTError, ValueError):
            raise HTTPException(401, "下载票据无效或已过期,请重新点击下载")
        if not user or not user.is_active or int(p["tv"]) != int(user.token_version or 0):
            raise HTTPException(401, "下载票据已失效(账号凭据已变更)")  # 改密 / 停用后旧票据立即作废
    else:
        from ..auth import user_from_token

        auth = request.headers.get("authorization", "")
        if not auth.lower().startswith("bearer "):
            raise HTTPException(401, "缺少下载票据")
        user = user_from_token(auth[7:], db)
    b = _get_backup(bid, db, user, minimum="owner")
    p = svc.backup_path(b)
    if b.status != "done" or not p or not os.path.isfile(p):
        raise HTTPException(404, "备份文件不存在或尚未完成")
    return _ranged_file_response(p, request, os.path.basename(p))


@router.post("/bulk-delete")
def bulk_delete_backups(body: dict, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """批量删除备份记录(部分成功)。逐条复用单删的权限与占用检查;返回逐项结果。"""
    ids = body.get("backup_ids") or []
    if not ids:
        raise HTTPException(400, "没有选择备份")
    in_use = svc.in_use_backup_ids(db)
    results = []
    ok = 0
    for bid in dict.fromkeys(ids):
        b = db.get(Backup, bid)
        # 不可见 / 不存在统一措辞,避免枚举
        env = db.get(Environment, b.environment_id) if (b and b.environment_id) else None
        if not b or not authz.can_see_env_data(db, user, env, b.tenant_id, minimum="developer"):
            results.append({"backup_id": bid, "status": "skipped", "message": "无权访问或不存在"})
            continue
        if b.status == "running":
            results.append({"backup_id": bid, "status": "skipped", "message": "备份进行中"})
            continue
        if b.id in in_use:
            results.append({"backup_id": bid, "status": "skipped", "message": "正被恢复任务使用"})
            continue
        if not _can_delete_backup(db, user, b):
            results.append({"backup_id": bid, "status": "skipped", "message": "开发者不可删生产备份"})
            continue
        try:
            svc.delete_backup_file(b)
            db.delete(b)
            db.commit()
            ok += 1
            results.append({"backup_id": bid, "status": "success", "message": None})
        except OSError as e:
            db.rollback()
            results.append({"backup_id": bid, "status": "failed", "message": f"删除文件失败: {e}"})
    return {"results": results, "succeeded": ok, "failed": sum(1 for r in results if r["status"] == "failed"), "skipped": sum(1 for r in results if r["status"] == "skipped")}


@router.delete("/{bid}")
def delete_backup(bid: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    b = _get_backup(bid, db, user)
    if b.status == "running":
        raise HTTPException(409, "备份进行中,无法删除")
    if b.id in svc.in_use_backup_ids(db):
        raise HTTPException(409, "该备份正在被恢复任务使用,请等恢复结束后再删除")
    if not _can_delete_backup(db, user, b):
        raise HTTPException(403, "开发者仅能删除非生产实例的备份;生产备份请联系组织管理员")
    try:
        svc.delete_backup_file(b)
    except OSError as e:
        raise HTTPException(500, f"删除文件失败: {e}")
    db.delete(b)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- 恢复
@router.post("/{bid}/restore", response_model=S.RestoreJobOut, status_code=202)
def restore(
    bid: int,
    body: S.RestoreIn,
    bg: BackgroundTasks,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    from ..services import databases as dbsvc

    b = _get_backup(bid, db, user)
    if b.status != "done":
        raise HTTPException(400, "备份尚未完成或已失败")
    env = _get_env(body.environment_id, db, user, "restore")
    if env.tenant_id != b.tenant_id and not authz.is_superadmin(user):
        raise HTTPException(403, "只能恢复到同一组织的实例")
    if env.status in ENV_BUSY:
        raise HTTPException(409, f"实例正在 {env.status},请稍候")
    if not env.db_name or not env.container_name:
        raise HTTPException(400, "目标实例尚未创建完成,请先「创建并启动」")
    try:
        target = dbsvc.view(db, env, body.database_id)
    except ValueError as ex:
        raise HTTPException(404, str(ex))
    if target.row is not None and target.row.status not in ("ready", "failed"):  # failed(上次恢复失败)允许再恢复覆盖
        raise HTTPException(409, f"该附加数据库正在 {target.row.status},请稍候")
    # 大版本不一致默认拒绝(恢复后 Odoo 通常起不来 / 需要升级);前端确认后带 force=true 放行
    if b.odoo_version and str(b.odoo_version) != str(env.odoo_version) and not body.force:
        raise HTTPException(409, f"备份来自 Odoo {b.odoo_version},目标实例是 Odoo {env.odoo_version};版本不一致的恢复需要显式确认(force)")
    if not svc.try_lock(env.id):
        raise HTTPException(409, "该实例正在备份或恢复中")
    prior_status = env.status
    to_extra = target.row is not None
    # 恢复主库:实例置为 restoring(BUSY),部署 / 启停 / 休眠 / 唤醒都会被挡住;结束后按容器真实状态归位。
    # 恢复附加库:不停容器、不改实例状态,只把该库标为 restoring。
    if not to_extra and not orchestrator.try_claim(db, env, "restoring", f"恢复备份 #{b.id}"):
        svc.unlock(env.id)
        raise HTTPException(409, f"实例正在 {env.status},请稍候")
    try:
        job = RestoreJob(
            backup_id=b.id,
            tenant_id=env.tenant_id,
            environment_id=env.id,
            env_name=env.name,
            database_id=target.database_id,
            db_name=target.db_name,
            neutralize=body.neutralize,
            status="running",
            message="已排队",
            created_by=user.username,
        )
        db.add(job)
        db.commit()
        db.refresh(job)
        if to_extra:
            bg.add_task(jobs.spawn, _restore_extra_db, job.id, b.id, env.id, target.database_id, body.neutralize, body.backup_before)
        else:
            bg.add_task(jobs.spawn, svc.run_restore, job.id, b.id, env.id, body.neutralize, body.backup_before)
    except Exception:
        svc.unlock(env.id)
        if not to_extra:
            orchestrator._set_status(env.id, prior_status, None, progress=0)
        raise
    return job


def _restore_extra_db(job_id: int, backup_id: int, env_id: int, database_id: int, neutralize: bool, backup_before: bool) -> None:
    """恢复到附加库:库状态 restoring → run_restore(不停容器、不动实例状态)→ ready / failed。"""
    from ..services import databases as dbsvc

    dbsvc._set_status(database_id, "restoring", f"恢复备份 #{backup_id}", 5)
    try:
        svc.run_restore(job_id, backup_id, env_id, neutralize, backup_before, database_id=database_id, manage_env_status=False)
    finally:
        with SessionLocal() as db:
            job = db.get(RestoreJob, job_id)
            ok = bool(job and job.status == "done")
        dbsvc._set_status(database_id, "ready" if ok else "failed", None if ok else "恢复失败,见恢复记录", 100 if ok else 0)
