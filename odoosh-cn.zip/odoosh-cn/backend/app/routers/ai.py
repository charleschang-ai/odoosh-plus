"""AI 助手接口:用户级接入配置(BYOK)、会话、发消息、SSE 流、确认卡、中止。

- 每个用户只能看到/操作自己的配置与会话;api_key 读取只回尾 4 位。
- ops 模式(超管运维 agent)与 help 模式(功能问答)共用同一套会话/流式管线;
  能力差异由 services/ai/loop.py 按 mode + is_superadmin 决定(help 零工具)。
- SSE 走查询串 JWT(EventSource 带不了头);nginx 对应 location 关 access_log(见 frontend/nginx.conf)。
"""

from __future__ import annotations

import json
import queue
import threading
import time

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from fastapi import Request

from ..auth import get_current_user, require_admin, user_from_token
from ..db import get_db
from ..models import User
from ..models_ai import AiConversation, AiMessage, AiUserConfig
from ..services import jobs
from ..services.ai import loop as ai_loop
from ..services.ai import mcp as ai_mcp
from ..services.ai.config import presets_public

router = APIRouter(prefix="/api/ai", tags=["ai"])

MASK_TAIL = 4


# ---------------- 接入配置(每用户) ----------------

class ConfigIn(BaseModel):
    provider: str | None = None
    base_url: str | None = None
    model: str | None = None
    api_key: str | None = None  # 传 None/省略 = 不改;传空串 = 清空
    max_daily_tokens: int | None = None


def _config_out(cfg: AiUserConfig | None) -> dict:
    if not cfg:
        return {"provider": "deepseek", "base_url": None, "model": None, "key_set": False,
                "key_tail": None, "max_daily_tokens": None}
    key = cfg.api_key or ""
    return {"provider": cfg.provider, "base_url": cfg.base_url, "model": cfg.model,
            "key_set": bool(key), "key_tail": key[-MASK_TAIL:] if len(key) >= MASK_TAIL else None,
            "max_daily_tokens": cfg.max_daily_tokens}


@router.get("/providers")
def providers(user: User = Depends(get_current_user)):
    return {"presets": presets_public()}


def _ai_enabled(db: Session) -> bool:
    from .settings import get_setting

    return (get_setting(db, "ai.enabled") or "1") == "1"


def _require_enabled(db: Session) -> None:
    if not _ai_enabled(db):
        raise HTTPException(403, "平台已关闭 AI 功能")


@router.get("/config")
def get_config(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    cfg = db.scalar(select(AiUserConfig).where(AiUserConfig.user_id == user.id))
    out = _config_out(cfg)
    out["enabled"] = _ai_enabled(db)
    out["default_mode"] = _default_mode(user)
    return out


@router.put("/config")
def put_config(body: ConfigIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    cfg = db.scalar(select(AiUserConfig).where(AiUserConfig.user_id == user.id))
    if not cfg:
        cfg = AiUserConfig(user_id=user.id)
        db.add(cfg)
    if body.provider is not None:
        cfg.provider = body.provider
    if body.base_url is not None:
        cfg.base_url = body.base_url.strip() or None
    if body.model is not None:
        cfg.model = body.model.strip() or None
    if body.api_key is not None:  # 只有显式传了才改(前端不回传原 key)
        cfg.api_key = body.api_key.strip() or None
    if body.max_daily_tokens is not None:
        cfg.max_daily_tokens = max(0, int(body.max_daily_tokens)) or None
    db.commit()
    db.refresh(cfg)
    return _config_out(cfg)


# ---------------- 会话 ----------------

def _default_mode(user: User) -> str:
    return "ops" if user.is_superadmin else "assist"


def _get_conv(db: Session, user: User, conv_id: int) -> AiConversation:
    conv = db.get(AiConversation, conv_id)
    if not conv or conv.user_id != user.id:
        raise HTTPException(404, "会话不存在")
    return conv


def _conv_out(c: AiConversation) -> dict:
    return {"id": c.id, "mode": c.mode, "tenant_id": c.tenant_id, "title": c.title, "state": c.state,
            "created_at": c.created_at, "updated_at": c.updated_at}


@router.get("/conversations")
def list_conversations(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.scalars(select(AiConversation).where(AiConversation.user_id == user.id)
                      .order_by(AiConversation.updated_at.desc()).limit(100)).all()
    return [_conv_out(c) for c in rows]


class NewConv(BaseModel):
    mode: str | None = None
    tenant_id: int | None = None  # assist 模式必填:钉死的组织


@router.post("/conversations")
def create_conversation(body: NewConv, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    mode = body.mode or _default_mode(user)
    if mode == "ops" and not user.is_superadmin:
        mode = "assist"  # 非超管不允许开 ops 会话
    tenant_id = None
    if mode == "assist":
        if user.is_superadmin:
            mode = "ops"  # 超管不需要 assist,直接给 ops
        else:
            from .. import authz

            tenant_id = body.tenant_id
            if tenant_id is None:
                # 未指定组织:若只属于一家组织,自动用它;否则要求前端指定
                tids = authz.accessible_tenant_ids(db, user) or []
                if len(tids) == 1:
                    tenant_id = tids[0]
                else:
                    raise HTTPException(400, "请指定组织(tenant_id)")
            # 校验用户确属该组织(否则降级为纯问答,绝不给跨组织作用域)
            if not authz.tenant_role(db, user, tenant_id):
                raise HTTPException(403, "你不属于该组织")
    c = AiConversation(user_id=user.id, mode=mode, tenant_id=tenant_id)
    db.add(c)
    db.commit()
    db.refresh(c)
    return _conv_out(c)


@router.delete("/conversations/{conv_id}")
def delete_conversation(conv_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    conv = _get_conv(db, user, conv_id)
    if conv.state == "running":
        raise HTTPException(409, "会话正在运行,请先中止")
    db.delete(conv)
    db.commit()
    return {"ok": True}


def _msg_out(m: AiMessage) -> dict:
    return {"id": m.id, "seq": m.seq, "role": m.role, "content": m.content,
            "tool_calls": json.loads(m.tool_calls) if m.tool_calls else None,
            "tool_call_id": m.tool_call_id, "name": m.name,
            "meta": json.loads(m.meta) if m.meta else None, "created_at": m.created_at}


@router.get("/conversations/{conv_id}/messages")
def list_messages(conv_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    _get_conv(db, user, conv_id)
    rows = db.scalars(select(AiMessage).where(AiMessage.conversation_id == conv_id).order_by(AiMessage.seq)).all()
    return {"messages": [_msg_out(m) for m in rows], "running": bool(_running(conv_id))}


# ---------------- 发消息 / 流 / 确认 / 中止 ----------------

class SendIn(BaseModel):
    content: str


def _running(conv_id: int):
    run = ai_loop.manager.get(conv_id)
    return run if run and not run.ended else None


@router.post("/conversations/{conv_id}/send")
def send(conv_id: int, body: SendIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    conv = _get_conv(db, user, conv_id)
    _require_enabled(db)
    text = (body.content or "").strip()
    if not text:
        raise HTTPException(400, "消息不能为空")
    # 原子抢占:idle → running,避免同会话并发跑两个 agent(无 check-then-act 窗口)
    from sqlalchemy import update

    res = db.execute(update(AiConversation).where(AiConversation.id == conv_id, AiConversation.state == "idle")
                     .values(state="running"))
    db.commit()
    if res.rowcount != 1:
        raise HTTPException(409, "会话正在运行中,请稍候")
    ai_loop._persist(db, conv_id, "user", text)
    ai_loop.manager.create(conv_id)  # 先建 Run,避免 SSE 早于后台线程连上时误判「无运行」
    jobs.spawn(ai_loop.run_message, conv_id, user.id)
    return {"ok": True}


@router.get("/conversations/{conv_id}/stream")
def stream(conv_id: int, token: str, db: Session = Depends(get_db)):
    user = user_from_token(token, db)
    _get_conv(db, user, conv_id)
    run = ai_loop.manager.get(conv_id)  # 可能已结束:其 history 里含 end,订阅即可回放完整轨迹

    def gen():
        if not run:
            # 完全没有运行记录:告知客户端直接刷新消息列表即可
            yield _sse("idle", {})
            yield _sse("end", {"status": "idle"})
            return
        q = run.subscribe()
        try:
            last = time.time()
            while True:
                try:
                    ev = q.get(timeout=2.0)
                except queue.Empty:
                    if run.ended:
                        yield _sse("end", {"status": "done"})
                        return
                    if time.time() - last > 15:
                        yield ": ping\n\n"
                        last = time.time()
                    continue
                last = time.time()
                yield _sse(ev.get("type", "message"), ev)
                if ev.get("type") == "end":
                    return
        finally:
            run.unsubscribe(q)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


def _sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


class ConfirmIn(BaseModel):
    call_id: str
    approved: bool


@router.post("/conversations/{conv_id}/confirm")
def confirm(conv_id: int, body: ConfirmIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    _get_conv(db, user, conv_id)
    run = _running(conv_id)
    if not run:
        raise HTTPException(409, "没有正在等待确认的操作")
    ok = run.resolve_confirm(body.call_id, body.approved)
    if not ok:
        raise HTTPException(409, "该确认已失效或不存在")
    return {"ok": True}


@router.post("/conversations/{conv_id}/abort")
def abort(conv_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    _get_conv(db, user, conv_id)
    run = _running(conv_id)
    if run:
        run.aborted.set()
        # 解开可能正在等待的确认卡(否则要等满超时)
        pc = getattr(run, "_pending_confirm", None)
        if pc:
            run.resolve_confirm(pc["id"], False)
    from sqlalchemy import update

    db.execute(update(AiConversation).where(AiConversation.id == conv_id).values(state="idle"))
    db.commit()
    return {"ok": True}


# ---------------- MCP 端点(仅超管;供 Claude Code 等 MCP 客户端连接) ----------------

@router.post("/mcp")
async def mcp_endpoint(request: Request, user: User = Depends(require_admin)):
    """MCP JSON-RPC over HTTP(无状态)。用超管 Bearer JWT 鉴权。
    在 MCP 客户端里配置:URL = <平台地址>/api/ai/mcp,Authorization: Bearer <超管登录令牌>。"""
    from fastapi.responses import JSONResponse, Response
    from starlette.concurrency import run_in_threadpool

    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return JSONResponse({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}, status_code=400)
    # 工具调用是阻塞的 Docker/DB 操作:丢到线程池,别卡事件循环
    if isinstance(body, list):  # 批量
        results = [await run_in_threadpool(ai_mcp.handle, b, user) for b in body]
        return JSONResponse([r for r in results if r is not None])
    resp = await run_in_threadpool(ai_mcp.handle, body, user)
    if resp is None:
        return Response(status_code=202)
    return JSONResponse(resp)
