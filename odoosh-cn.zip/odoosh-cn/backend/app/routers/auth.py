from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import authz, schemas
from ..auth import create_token, get_current_user, hash_password, revoke_tokens, verify_password
from ..db import get_db
from ..models import Membership, Tenant, User

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.get("/config")
def login_config(db: Session = Depends(get_db)):
    """登录页需要的公开配置:是否启用图形验证码,以及品牌名 / 备案号(未登录时也要显示,故走公开接口)。"""
    from ..routers.settings import get_setting
    from ..services import loginguard

    return {
        "captcha": loginguard.captcha_enabled(db),
        "brand": {
            "name": get_setting(db, "platform.brand_name") or "",
            "badge": get_setting(db, "platform.brand_badge") or "",
            "tagline": get_setting(db, "platform.brand_tagline") or "",
            # 备案号跟品牌走同一条链路(公开、部署方定制、前端本地缓存),侧栏底部据此替代版本号
            "icp": get_setting(db, "platform.icp_number") or "",
        },
    }


@router.get("/captcha")
def captcha(db: Session = Depends(get_db)):
    """签发一张图形验证码(一次性,5 分钟有效)。"""
    from ..services import loginguard

    if not loginguard.captcha_enabled(db):
        return {"id": None, "image": None}
    cid, img = loginguard.new_captcha()
    return {"id": cid, "image": img}


@router.post("/login", response_model=schemas.TokenOut)
def login(body: schemas.LoginIn, request: Request, db: Session = Depends(get_db)):
    """登录。防护:nginx limit_req → 验证码(可在设置关闭)→ 用户名 / IP 失败锁定 → bcrypt(用户不存在也跑一次,耗时一致)。"""
    from ..services import loginguard

    ip = request.client.host if request.client else None
    username = (body.username or "").strip()
    left = loginguard.locked_seconds(username, ip)
    if left:
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, f"失败次数过多,请 {max(1, left // 60)} 分钟后再试")
    if loginguard.captcha_enabled(db) and not loginguard.check_captcha(body.captcha_id, body.captcha_code):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "验证码错误或已过期")
    user = db.scalar(select(User).where(User.username == username))
    ok = bool(user) and user.is_active and verify_password(body.password, user.password_hash)
    if not user:
        loginguard.dummy_verify(body.password)
    if not ok:
        locked = loginguard.record_failure(username, ip, loginguard.max_failures(db))
        if locked:
            raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, f"失败次数过多,账号已临时锁定 {locked // 60} 分钟")
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "用户名或密码错误")
    loginguard.record_success(username, ip)
    return schemas.TokenOut(access_token=create_token(user))


@router.get("/me", response_model=schemas.MeOut)
def me(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """当前用户 + 平台角色 + 各租户成员角色(前端据此渲染菜单与按钮)。"""
    rows = db.execute(
        select(Membership, Tenant).join(Tenant, Tenant.id == Membership.tenant_id).where(Membership.user_id == user.id)
    ).all()
    memberships = [
        schemas.MembershipOut(tenant_id=t.id, tenant_slug=t.slug, tenant_name=t.name, role=m.role) for m, t in rows
    ]
    if authz.is_superadmin(user):
        # 超管在所有租户视为 owner
        memberships = [
            schemas.MembershipOut(tenant_id=t.id, tenant_slug=t.slug, tenant_name=t.name, role="owner")
            for t in db.scalars(select(Tenant).order_by(Tenant.id)).all()
        ]
    base = schemas.UserOut.model_validate(user).model_dump()
    base.pop("memberships", None)
    base["env_count"] = authz.owned_env_count(db, user.id)  # 配额提示用(max_envs 已在 UserOut 里)
    base["db_count"] = authz.owned_db_count(db, user)
    return schemas.MeOut(**base, is_superadmin=authz.is_superadmin(user), memberships=memberships)


class PasswordChangeIn(BaseModel):
    old_password: str
    new_password: str = Field(min_length=6, max_length=128)


@router.post("/password", status_code=status.HTTP_204_NO_CONTENT)
def change_password(body: PasswordChangeIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """当前用户修改自己的密码(头部用户菜单)。"""
    if not verify_password(body.old_password, user.password_hash):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "当前密码不正确")
    user.password_hash = hash_password(body.new_password)
    revoke_tokens(user)  # 旧令牌全部失效
    db.commit()
    return  # 前端收到 204 后需用新密码重新登录
