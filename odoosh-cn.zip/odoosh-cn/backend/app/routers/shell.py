"""实例 Shell(Web 终端)。

  POST /api/environments/{id}/shell-ticket        签发 60 秒票据(需 authz.shell_allowed)
  WS   /api/environments/{id}/shell?t=票据&cols=&rows=   终端会话:客户端发 {"t":"i","d":"..."} 输入 / {"t":"r","cols":..,"rows":..} 调整大小;服务端发文本帧(终端输出)
  GET  /api/shell-sessions?tenant_id=              审计列表(组织管理员看本组织,超管看全部)
"""

import asyncio
import json
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, WebSocket, WebSocketDisconnect
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import authz
from ..auth import get_current_user
from ..db import SessionLocal, get_db
from ..models import Environment, User
from ..models_shell import ShellSession
from ..services import orchestrator
from ..services import shell as svc

log = logging.getLogger("odoosh.shell")

router = APIRouter(prefix="/api", tags=["shell"])


@router.post("/environments/{env_id}/shell-ticket")
def shell_ticket(env_id: int, request: Request, database_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """database_id:附加库 id → 会话内 odoo shell / psql / odoo-update 都指向该库;不传 = 主库。"""
    e = db.get(Environment, env_id)
    if not e:
        raise HTTPException(404, "环境不存在")
    if not authz.shell_allowed(db, user, e):
        raise HTTPException(403, "无 Shell 权限(需平台管理员为你开启,且对该类型实例有权限)")
    if e.status != "running" or not e.container_name:
        raise HTTPException(409, "实例未在运行")
    if database_id:
        from ..services import databases as dbsvc

        try:
            dbsvc.view(db, e, database_id)
        except ValueError as ex:
            raise HTTPException(404, str(ex))
    return {"ticket": svc.make_ticket(e.id, user, database_id), "ttl": svc.TICKET_TTL, "user": "odoo"}


@router.get("/shell-sessions")
def list_sessions(tenant_id: int | None = None, environment_id: int | None = None, limit: int = 100,
                  db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = select(ShellSession).order_by(ShellSession.id.desc()).limit(max(1, min(limit, 500)))
    if environment_id is not None:
        q = q.where(ShellSession.environment_id == environment_id)
    if tenant_id is not None:
        authz.require_tenant_role(db, user, tenant_id, "owner")
        q = q.where(ShellSession.tenant_id == tenant_id)
    elif not authz.is_superadmin(user):
        ids = [t for t, r in authz.role_map(db, user).items() if r == "owner"]
        q = q.where(ShellSession.tenant_id.in_(ids or [-1]))
    rows = db.scalars(q).all()
    return [{"id": s.id, "environment_id": s.environment_id, "env_name": s.env_name, "env_kind": s.env_kind, "username": s.username,
             "client_ip": s.client_ip, "container_user": s.container_user, "status": s.status, "message": s.message,
             "bytes_in": s.bytes_in, "bytes_out": s.bytes_out, "started_at": s.started_at, "ended_at": s.ended_at,
             "input_log": s.input_log if authz.is_superadmin(user) else None} for s in rows]


_SECRET_RE = None


def _redact_input(text: str | None) -> str | None:
    """审计录入的键盘输入里,尽量抹掉口令 / 令牌(启发式:password=xxx、-p xxx、Bearer xxx、PGPASSWORD=...)。"""
    global _SECRET_RE
    if not text:
        return text
    import re

    if _SECRET_RE is None:
        _SECRET_RE = re.compile(
            r"((?i:pass(?:word|wd|phrase)?|pwd|secret|token|api[_-]?key|PGPASSWORD|admin_passwd)\s*[=:]\s*)(['\"]?)[^\s'\"]+\2"
            r"|((?:^|\s)(?:-p|--password(?:=|\s+))\s*)['\"]?[^\s'\"]+"
            r"|((?i:bearer|basic)\s+)[A-Za-z0-9._~+/=-]{8,}",
        )

    def _sub(m):
        return (m.group(1) or m.group(3) or m.group(4) or "") + "***"

    return _SECRET_RE.sub(_sub, text)


def _finish(sid: int, status: str, message: str | None, bin_: int, bout: int, input_log: str | None) -> None:
    with SessionLocal() as db:
        s = db.get(ShellSession, sid)
        if s:
            s.status, s.message, s.bytes_in, s.bytes_out = status, (message or "")[:256] or None, bin_, bout
            s.input_log = _redact_input(input_log)
            s.ended_at = datetime.now(timezone.utc)
            db.commit()


@router.websocket("/environments/{env_id}/shell")
async def shell_ws(ws: WebSocket, env_id: int, t: str = "", cols: int = 120, rows: int = 32):
    await ws.accept()

    async def bye(msg: str, code: int = 4000):
        try:
            await ws.send_text(f"\r\n\x1b[31m{msg}\x1b[0m\r\n")
            await ws.close(code=code)
        except Exception:  # noqa: BLE001
            pass

    # 1. 票据(一次性) + 权限
    with SessionLocal() as db:
        try:
            p, user = svc.read_ticket(t, db)
        except ValueError as ex:
            return await bye(str(ex))
        if int(p["env"]) != env_id:
            return await bye("票据与实例不匹配")
        e = db.get(Environment, env_id)
        if not user or not user.is_active or not e or not authz.shell_allowed(db, user, e):
            return await bye("无 Shell 权限")
        try:
            container = svc.container_for(e)
        except RuntimeError as ex:
            return await bye(str(ex))
        uid = orchestrator.env_odoo_uid(e)
        db_name = e.db_name
        if p.get("db"):
            from ..services import databases as dbsvc

            try:
                db_name = dbsvc.view(db, e, int(p["db"])).db_name
            except ValueError as ex:
                return await bye(str(ex))
        record = e.kind == "production"
        sess = ShellSession(environment_id=e.id, tenant_id=e.tenant_id, env_name=e.name, env_kind=e.kind, user_id=user.id, username=user.username,
                            client_ip=((ws.headers.get("x-forwarded-for") or "").split(",")[0].strip() or (ws.client.host if ws.client else None)), container_user="odoo", status="open")
        db.add(sess)
        db.commit()
        sid = sess.id
        env_name, username = e.name, user.username
    if not svc.acquire(env_id):
        _finish(sid, "failed", "会话数超限", 0, 0, None)
        return await bye(f"该实例同时最多 {svc.MAX_SESSIONS_PER_ENV} 个 Shell 会话")

    log.info("shell 打开: %s → 实例 %s (#%s)", username, env_name, sid)
    loop = asyncio.get_running_loop()
    bin_ = bout = 0
    input_buf: list[str] = []
    input_len = 0
    exec_id = raw = None
    status, message = "closed", None
    try:
        # 2. 写入辅助命令并打开 exec
        await loop.run_in_executor(None, svc.prepare, container, uid, db_name)
        exec_id, raw = await loop.run_in_executor(None, svc.open_exec, container, uid, cols, rows, False, db_name)
        raw.setblocking(True)
        await ws.send_text(f"\x1b[2m已连接到实例 {env_name}(数据库 {db_name};容器内用户 odoo;空闲 {svc.IDLE_TIMEOUT // 60} 分钟自动断开)\x1b[0m\r\n")

        # 3. 容器 → 浏览器
        async def pump_out():
            nonlocal bout
            while True:
                data = await loop.run_in_executor(None, raw.recv, 65536)
                if not data:
                    break
                bout += len(data)
                await ws.send_bytes(data)

        out_task = asyncio.create_task(pump_out())
        # 4. 浏览器 → 容器(带空闲超时)
        while True:
            if out_task.done():
                break
            try:
                msg = await asyncio.wait_for(ws.receive_text(), timeout=svc.IDLE_TIMEOUT)
            except asyncio.TimeoutError:
                status, message = "closed", "空闲超时"
                await bye("空闲超时,已断开", 4001)
                break
            try:
                m = json.loads(msg)
            except ValueError:
                continue
            if m.get("t") == "i":
                d = m.get("d") or ""
                b = d.encode()
                bin_ += len(b)
                if record and input_len < 200_000:
                    input_buf.append(d)
                    input_len += len(d)
                await loop.run_in_executor(None, raw.sendall, b)
            elif m.get("t") == "r":
                svc.resize(exec_id, int(m.get("cols") or cols), int(m.get("rows") or rows))
        if not out_task.done():
            out_task.cancel()
    except WebSocketDisconnect:
        status = "closed"
    except Exception as ex:  # noqa: BLE001
        log.exception("shell 会话异常")
        status, message = "failed", str(ex)
        await bye(f"会话异常:{ex}")
    finally:
        try:
            if raw:
                raw.close()
        except Exception:  # noqa: BLE001
            pass
        svc.release(env_id)
        _finish(sid, status, message, bin_, bout, "".join(input_buf) if record else None)
        log.info("shell 关闭: %s → 实例 %s (#%s, %s)", username, env_name, sid, status)
