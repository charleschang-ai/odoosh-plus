"""批量作业接口(通用)。v1 只有「批量创建实例」(env.create)。

权限:批量创建实例仅超管 / 组织 owner(在 service 里判定);作业的查看 / 重试 / 取消限发起者或超管。
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import authz, schemas_bulk
from ..auth import get_current_user
from ..db import get_db
from ..models import User
from ..models_bulk import BulkJob, BulkJobItem
from ..services import bulk_env

router = APIRouter(prefix="/api/bulk", tags=["bulk"])


def _job_out(db: Session, job: BulkJob) -> schemas_bulk.BulkJobOut:
    out = schemas_bulk.BulkJobOut.model_validate(job)
    items = db.scalars(select(BulkJobItem).where(BulkJobItem.job_id == job.id).order_by(BulkJobItem.id)).all()
    out.items = [schemas_bulk.BulkJobItemOut.model_validate(it) for it in items]
    return out


def _get_job(job_id: int, db: Session, user: User) -> BulkJob:
    job = db.get(BulkJob, job_id)
    if not job:
        raise HTTPException(404, "作业不存在")
    if not (authz.is_superadmin(user) or job.created_by_id == user.id):
        raise HTTPException(403, "无权访问该批量作业")
    return job


@router.post("/env-create/preflight", response_model=schemas_bulk.EnvBatchPreflightOut)
def env_create_preflight(body: schemas_bulk.EnvBatchIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return bulk_env.preflight(db, user, body.plan)


@router.post("/env-create", response_model=schemas_bulk.BulkJobOut, status_code=201)
def env_create(body: schemas_bulk.EnvBatchIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    job = bulk_env.submit(db, user, body.plan, body.idempotency_key)
    return _job_out(db, job)


@router.post("/env-ops/preflight", response_model=schemas_bulk.EnvOpsPreflightOut)
def env_ops_preflight(body: schemas_bulk.EnvOpsIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return bulk_env.preflight_ops(db, user, body.kind, body.target_ids)


@router.post("/env-ops", response_model=schemas_bulk.BulkJobOut, status_code=201)
def env_ops(body: schemas_bulk.EnvOpsIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    job = bulk_env.submit_ops(db, user, body.kind, body.target_ids, body.payload, body.idempotency_key)
    return _job_out(db, job)


@router.get("", response_model=list[schemas_bulk.BulkJobOut])
def list_jobs(mine: int = 1, limit: int = 20, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = select(BulkJob).order_by(BulkJob.id.desc()).limit(min(limit, 100))
    if mine or not authz.is_superadmin(user):
        q = q.where(BulkJob.created_by_id == user.id)
    jobs = db.scalars(q).all()
    return [_job_out(db, j) for j in jobs]


@router.get("/{job_id}", response_model=schemas_bulk.BulkJobOut)
def get_job(job_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return _job_out(db, _get_job(job_id, db, user))


@router.post("/{job_id}/retry", response_model=schemas_bulk.BulkJobOut)
def retry_job(job_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    job = _get_job(job_id, db, user)
    return _job_out(db, bulk_env.retry(db, user, job))


@router.post("/{job_id}/cancel", response_model=schemas_bulk.BulkJobOut)
def cancel_job(job_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    job = _get_job(job_id, db, user)
    return _job_out(db, bulk_env.cancel(db, job))
