from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import schemas
from ..auth import require_admin
from ..db import get_db
from ..models import Setting

router = APIRouter(prefix="/api/settings", tags=["settings"], dependencies=[Depends(require_admin)])

# 平台设置的默认值(第一版只是保存,后续功能会真正读取它们)
DEFAULTS: dict[str, str] = {
    # 品牌:平台按部署方定制名称(企业 / 学校 / 工厂都用同一套代码),由 /api/auth/config 公开下发给登录页
    "platform.brand_name": "OdooSh",              # 侧栏左上角主名与浏览器标题;留空前端回落到内置默认
    "platform.brand_badge": "中国版",              # 主名后的小胶囊,留空则不显示
    "platform.brand_tagline": "Odoo 环境托管平台",  # 登录页左侧大标题
    "platform.icp_number": "",                    # ICP 备案号(如 京ICP备12345678号-1);填了则侧栏底部用它替代版本号,并链到工信部备案系统
    "platform.base_domain": "",           # 留空 = 跟随 .env 的 ODOOSH_BASE_DOMAIN;可填 auto / 域名(需 *.域名 泛解析)/ localhost
    "platform.data_dir": "/var/lib/odoosh",
    "docker.registry_mirror": "https://docker.xuanyuan.me",
    "odoo.versions": "19,18,17,16,15,14,13,12",  # 最新在前。Docker Hub 官方 library/odoo 有 12~19 的标签(≤16 已停止更新);源码自建按版本选 Python
    "odoo.default_version": "18",
    "odoo.enterprise_dir": "/var/lib/odoosh/offline/enterprise",  # 统一的企业版代码目录:<该目录>/<版本>/ 放 addons;超管上传或手动放,新实例按版本共享一套
    "git.github_token": "",
    "git.gitee_token": "",
    "git.github_proxy": "",  # gh-proxy 类加速前缀,逗号分隔按顺序尝试,最后回退直连;只对 github.com 生效

    "backup.dir": "/var/lib/odoosh/backups",
    "backup.keep_days": "7",
    "backup.auto_enabled": "0",       # 1 = 开启每日自动备份
    "backup.auto_hour": "3",          # 每天几点(服务器本地时间,0-23)
    "backup.auto_kinds": "production",  # 自动备份哪些类型的环境,逗号分隔
    "backup.upload_max_mb": "4096",     # 上传备份文件体积上限(MB)
    "backup.keep_days_manual": "0",     # 手动/上传备份保留天数(0 = 永久保留)
    "backup.quota_mb": "0",             # 每组织备份总量上限(MB,0 = 不限):超出先删最旧的自动/恢复前备份,再删最旧的手动/上传
    "backup.max_concurrent": "2",       # 同时最多跑几个备份任务(手动 + 自动一起算);其余排队等待
    "backup.restore_jobs": "0",         # 恢复时 pg_restore -j 并行度;0 = 自动(CPU 数一半,1~4)
    "backup.remote_concurrency": "3",   # 用户远程目标推送并发线程数(工作池大小)
    "backup.replica_enabled": "0",      # 1 = 备份完成后异步推送到 S3 兼容对象存储(异地副本);本地文件丢失时恢复可自动拉回
    "backup.replica_endpoint": "",      # S3 endpoint,如 https://oss-cn-hangzhou.aliyuncs.com / https://cos.ap-guangzhou.myqcloud.com / http://minio:9000;AWS 可留空
    "backup.replica_bucket": "",
    "backup.replica_region": "",        # 部分服务需要(如 AWS us-east-1、COS ap-guangzhou);MinIO 可留空
    "backup.replica_access_key": "",
    "backup.replica_secret": "",        # 掩码字段
    "backup.replica_prefix": "odoosh/",  # 对象 key 前缀
    "deploy.install_requirements": "1",  # 1 = 部署时自动安装仓库根目录 requirements.txt(装到实例 ~/.local,持久)
    "limits.env_memory_mb": "1024",
    "limits.env_cpus": "1",
    "limits.env_pids": "512",   # 每个实例容器最多进程数(防 Shell fork 炸弹拖垮宿主机);0/空 = 用默认 512
    "limits.tenant_pg_memory_mb": "1024",  # 每个组织共享的 PostgreSQL 容器内存上限(shared_buffers 等按此推导);新建 PG 容器时生效
    "env.expire_days_default": "3",       # 新实例默认过期天数(0 = 永不);生产实例不受默认影响,始终需手动设置
    "env.expire_apply_production": "0",  # 1 = 默认过期也应用于生产实例
    "env.use_template_db": "1",          # 1 = 新实例空库从「黄金模板库」秒级创建(首次同组合会先建模板)
    "env.trash_keep_days": "7",          # 删除的实例在回收站保留天数(测试/开发),到期彻底清理;0 = 永久保留直到手动彻底删除
    "env.trash_keep_days_production": "30",  # 生产实例回收站保留天数
    "odoo.log_level": "info",            # 实例 Odoo 日志等级默认值(debug/info/warn/error);每实例可覆盖;重启实例生效
    "odoo.extra_conf": "",               # 平台全局 odoo.conf 附加项(key = value 每行一条,可含自定义 [section]);对所有实例生效,实例级可覆盖;重启实例生效
    "odoo.extra_conf_env_enabled": "1",  # 1 = 允许在实例设置里填附加项(仍受白名单约束);0 = 只有平台全局附加项生效
    "odoo.extra_conf_extra_keys": "",    # 超管额外放行给普通用户的 odoo.conf 键(逗号分隔;黑名单键无效)
    "history.keep_days": "90",          # 部署 / 恢复记录保留天数(已结束的);先清日志正文,再删记录。0 = 永久
    "history.keep_per_env": "50",        # 每个实例至少保留最近多少条部署记录(回滚 / 追溯用)
    "history.shell_keep_days": "180",    # 实例 Shell 会话审计(含生产实例的键盘输入记录)保留天数;0 = 永久
    "history.push_keep_days": "90",      # Git 推送事件保留天数;0 = 永久
    "sleep.idle_hours": "4",             # 开发实例无访问多少小时后自动休眠(0 = 关闭);每实例可覆盖
    "sleep.max_running_per_project": "2",  # 每个项目最多同时在线的开发分支环境数(0 = 不限);超出时自动休眠最久未访问的
    "platform.public_url": "",           # 平台对外地址(https://sh.example.com);用于 webhook 回调 / OAuth 回调,留空则按请求头推断
    "platform.access_mode": "domain",    # 实例访问模式:domain=域名分流(默认)| port=每实例一个端口(未备案云服务器/纯内网;不支持附加库)
    "platform.tls_enabled": "1",         # 1 = 泛域名证书就绪时实例同时监听 443(证书不在则自动降级为纯 80);0 = 强制只用 80
    "git.allow_private_hosts": "0",      # 1 = 允许接入内网/自建 Git 服务(默认拒绝,防 SSRF)
    "platform.git_enabled": "1",         # 0 = 全系统不用 Git:创建实例不选仓库/分支,隐藏实例的 Git 操作与详情里 Git 内容(不影响「Git 仓库」页本身)
    # ---- 登录安全(services/loginguard.py)----
    "auth.captcha": "1",                 # 1 = 登录需图形验证码
    "auth.max_failures": "5",            # 同一用户名连续失败几次锁定 3 分钟(同 IP 阈值 ×4)
    # ---- 附加数据库(一个社区版实例多个库,见 services/databases.py)----
    "db.max_extra_per_env": "3",         # 每个实例最多几个附加库(默认值;组织 / 实例可覆盖);0 = 关闭附加库功能
    "db.allow_plain_env": "0",           # 1 = 未绑定 Git 仓库的普通实例也可建附加库(默认只有分支环境可以)
    "db.extra_expire_days": "0",         # 新附加库默认过期天数(0 = 跟随实例,不单独过期)
    "db.backup_before_drop": "1",        # 1 = 删除附加库前强制自动备份一份
    "backup.auto_extra_dbs": "0",        # 1 = 每日自动备份也包含附加库(组织策略可覆盖)
    # ---- 在线代码编辑(无 Git 实例的「定制代码」Tab;0 = 不限)----
    # 教学场景一台机带一个班,存储没有上限的话一个学生就能把全班拖下去。
    "code.max_bytes": "209715200",       # 每实例 addons 目录总字节(200MB)
    "code.max_files": "3000",            # 每实例 addons 目录文件数
    "code.max_upload_bytes": "209715200",  # 单次 zip 上传字节(接收阶段掐断,200MB)
    "code.history_keep": "10",           # 每个文件保留几个历史版本(误覆盖可回滚)
    "code.read_role": "view",            # 谁能读代码:view = 能看到实例的人都能读(默认);deploy = 只有能改代码的人能读(防考试抄袭)
    "code.dev_reload": "1",              # 1 = 开发档位实例带 --dev=reload,xml(改 XML 免重启、改 Python 自动重载)
    # ---- AI 助手(services/ai;API key 每用户自持,不在此)----
    "ai.enabled": "1",                   # 0 = 全平台关闭 AI 功能入口
    "ai.daily_token_limit_default": "0",  # 每用户每日 token 用量默认上限(0 = 不限);用户可在配置里单独设更严的值
    "ai.mcp_allow_write": "0",           # 1 = MCP 端点(超管用 Claude Code 连接)也暴露变更类工具(MCP 无确认卡,谨慎)
}

# 密钥类设置:读取时掩码,写入时若为掩码值则保持原值
SECRET_KEYS = ("git.github_token", "git.gitee_token")
MASK = "••••••••"


def is_secret_key(key: str) -> bool:
    return key in SECRET_KEYS or key.endswith("_secret") or key.endswith("_token") or key.endswith(".password")


_cache: dict[str, tuple[float, str | None]] = {}
_CACHE_TTL = 30.0


def get_setting(db: Session, key: str) -> str | None:
    """供其他模块读取单个设置(含默认值)。进程内缓存 30s(编排/调度线程高频读取)。"""
    import time

    hit = _cache.get(key)
    if hit and time.time() - hit[0] < _CACHE_TTL:
        return hit[1]
    row = db.get(Setting, key)
    val = row.value if row is not None else DEFAULTS.get(key)
    if val and is_secret_key(key):
        from ..crypto import decrypt

        val = decrypt(val)  # 密钥项静态加密存库(历史明文原样返回)
    _cache[key] = (time.time(), val)
    return val


def invalidate_cache() -> None:
    _cache.clear()


@router.get("", response_model=schemas.SettingsOut)
def get_settings(db: Session = Depends(get_db)):
    values = dict(DEFAULTS)
    for s in db.scalars(select(Setting)).all():
        values[s.key] = s.value
    # 密钥不回传明文,只告诉前端「已设置」
    for k, v in list(values.items()):
        if is_secret_key(k) and v:
            values[k] = MASK
    return schemas.SettingsOut(values=values)


@router.put("", response_model=schemas.SettingsOut)
def put_settings(body: schemas.SettingsIn, db: Session = Depends(get_db)):
    if "odoo.extra_conf" in body.values:
        from ..services import odooconf

        errs = odooconf.validate(body.values["odoo.extra_conf"], superadmin=True)
        if errs:
            raise HTTPException(422, "odoo.conf 附加项有误:" + ";".join(errs))
    from ..crypto import encrypt

    for k, v in body.values.items():
        if is_secret_key(k) and v == MASK:
            continue  # 前端原样回传掩码 → 不改
        if is_secret_key(k) and v:
            v = encrypt(v)  # 密钥项静态加密(Fernet,密钥由 ODOOSH_SECRET_KEY 派生)
        row = db.get(Setting, k)
        if row:
            row.value = v
        else:
            db.add(Setting(key=k, value=v))
    db.commit()
    invalidate_cache()
    try:
        from ..services import backup as _backup

        _backup.invalidate_settings_cache()
    except Exception:  # noqa: BLE001
        pass
    if {"platform.base_domain", "platform.access_mode"} & body.values.keys():
        from ..services import hostip

        hostip.apply(sync=True)  # 基础域名 / 访问模式改了:立即重算并同步所有实例域名、URL、nginx
    return get_settings(db)
