"""Git 仓库管理 + OAuth 账号 + Webhook 接收。

/api/repos/...                    需登录:仓库 CRUD、分支、事件
/api/git/accounts, /api/git/oauth 需登录:GitHub/Gitee 账号连接、OAuth 应用配置(管理员)
/api/git/oauth/{p}/callback       公开:OAuth 回调
/api/webhooks/git/{id}            公开(用签名/令牌校验),由 Git 平台回调
"""

import json
import time
import threading
import logging
from datetime import datetime
from urllib.parse import quote

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import schemas_git as schemas
from .. import authz
from ..auth import get_current_user, require_admin
from ..db import SessionLocal, get_db
from ..models import Environment, Tenant, User
from ..models_git import GitAccount, PushEvent, Repository
from ..services import git as gitsvc
from ..services import jobs
from ..services import gitoauth, gitpoll
from ..services.gitoauth import OAuthError

log = logging.getLogger("odoosh.repos")

router = APIRouter(prefix="/api/repos", tags=["repos"])
git_router = APIRouter(prefix="/api/git", tags=["git-accounts"])
webhook_router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])


# ---------------------------------------------------------------- helpers
def _check_tenant_access(user: User, tenant_id: int, minimum: str = "developer"):
    """组织级鉴权:默认要求开发者及以上(测试者不可见 Git)。"""
    authz.check_tenant_access(user, tenant_id, minimum)


def _base_url(request: Request) -> str:
    """平台对外地址:优先系统设置 platform.public_url(可信),否则用反代转发头 / Host。"""
    from .settings import get_setting

    with SessionLocal() as db:
        pub = (get_setting(db, "platform.public_url") or "").strip().rstrip("/")
    if pub:
        return pub
    proto = request.headers.get("x-forwarded-proto") or request.url.scheme
    host = request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.netloc
    return f"{proto}://{host}"


def _get_account(account_id: int, db: Session, user: User) -> GitAccount:
    acc = db.get(GitAccount, account_id)
    if not acc or (acc.user_id != user.id and not authz.is_superadmin(user)):
        raise HTTPException(404, "Git 账号不存在或不属于当前用户")
    return acc


def _repo_token(db: Session, r: Repository) -> str | None:
    """仓库可用的令牌:手填令牌优先,否则取 OAuth 账号令牌(自动续期)。"""
    if r.token:
        return r.token
    if r.account:
        try:
            return gitoauth.refresh_if_needed(db, r.account).access_token
        except OAuthError as e:
            r.last_error = str(e)[:512]
            db.commit()
            raise HTTPException(502, str(e))
    return None


def _client_for_repo(db: Session, r: Repository) -> gitoauth.Client:
    if r.provider not in gitoauth.PROVIDERS:
        raise HTTPException(400, f"{r.provider} 仓库不支持此操作(仅 GitHub / Gitee)")
    tok = _repo_token(db, r)
    if not tok:
        raise HTTPException(400, "该仓库没有可用令牌:请连接 GitHub/Gitee 账号后重新接入,或填写访问令牌")
    return gitoauth.Client(r.provider, tok)


def _repo_access(db: Session, user: User, r: Repository) -> str | None:
    """当前用户对该仓库的权限:'manage' | 'view' | None。

    规则(仓库属于接入者本人,企业版仓库亦然):
    - 超级管理员:一切仓库 manage。
    - 平台共享仓库(scope=platform,超管接入的企业版代码):仅超管可见;其他人只能通过
      /api/enterprise/platform-status 得知"平台已提供",不能看到地址。
    - 组织仓库:接入者本人(仍是该组织开发者及以上)manage;其他人不可见。
      created_by 为空的旧记录:该组织管理员 manage(接管)。
    """
    if authz.is_superadmin(user):
        return "manage"
    if r.scope == "platform" or r.tenant_id is None:
        return None
    role = authz.tenant_role(db, user, r.tenant_id)
    if not role or authz.ROLE_RANK[role] < authz.ROLE_RANK["developer"]:
        return None
    if r.created_by == user.id:
        return "manage"
    if r.created_by is None and role == "owner":
        return "manage"
    return None


def _get_repo(repo_id: int, db: Session, user: User, write: bool = False) -> Repository:
    r = db.get(Repository, repo_id)
    if not r:
        raise HTTPException(404, "仓库不存在")
    acc = _repo_access(db, user, r)
    if acc is None:
        raise HTTPException(403, "无权访问该仓库(仓库仅接入者本人与超级管理员可见)")
    if write and acc != "manage":
        raise HTTPException(403, "无权修改该仓库")
    return r


def _validate_enterprise_repo(db: Session, r: Repository) -> dict:
    """标记为企业版前校验:仓库必须含版本分支(17.0/18.0/19.0…)。返回探测结果。"""
    from ..services import enterprise as entsvc

    try:
        info = entsvc.probe(r.url, _repo_token(db, r))
    except (RuntimeError, ValueError) as e:
        raise HTTPException(400, f"无法作为企业版仓库:{e}")
    if not info["versions"]:
        raise HTTPException(400, "该仓库没有 17.0 / 18.0 / 19.0 这类版本分支,不像 Odoo 企业版仓库")
    return info


def _ensure_single_enterprise(db: Session, r: Repository) -> None:
    """同一作用域内只保留一个企业版仓库:平台级一个;组织内每个接入者一个。标记新的时自动取消旧的。"""
    q = select(Repository).where(Repository.is_enterprise.is_(True), Repository.id != r.id)
    if r.scope == "platform":
        q = q.where(Repository.scope == "platform")
    else:
        q = q.where(Repository.tenant_id == r.tenant_id, Repository.created_by == r.created_by)
    for old in db.scalars(q).all():
        old.is_enterprise = False


def _out(r: Repository, db: Session | None = None, user: User | None = None) -> schemas.RepositoryOut:
    o = schemas.RepositoryOut.model_validate(r)
    o.has_token = bool(r.token) or bool(r.account_id)
    o.account_login = r.account.login if r.account else None
    if db is not None:
        if r.created_by:
            u = db.get(User, r.created_by)
            o.created_by_name = (u.display_name or u.username) if u else None
        if user is not None:
            o.can_manage = _repo_access(db, user, r) == "manage"
    return o


def _apply_url(r: Repository, url: str) -> None:
    try:
        info = gitsvc.parse_repo_url(url)
    except ValueError as e:
        raise HTTPException(400, str(e))
    r.url = info["https_url"]
    r.provider = info["provider"]
    r.owner = info["owner"]
    r.repo = info["repo"]


def _envs_for_repo(db: Session, r: Repository) -> list[Environment]:
    if r.tenant_id is None:
        return []
    key = gitsvc.normalize_repo_url(r.url)
    envs = db.scalars(select(Environment).where(Environment.tenant_id == r.tenant_id)).all()
    return [e for e in envs if gitsvc.normalize_repo_url(e.repo_url) == key]


def _do_sync(r: Repository, db: Session) -> dict:
    try:
        snap = gitsvc.sync_branches(r.url, _repo_token(db, r))
    except (RuntimeError, ValueError) as e:
        r.last_error = str(e)[:512]
        db.commit()
        raise HTTPException(502, f"同步分支失败:{e}")
    r.branches_json = gitsvc.dumps(snap)
    r.branches_synced_at = datetime.fromisoformat(snap["synced_at"])
    r.default_branch = snap.get("default_branch")
    r.last_error = None
    db.commit()
    return snap


def _webhook_url(request: Request, repo_id: int) -> str:
    # 优先系统设置 platform.public_url;否则经 nginx 反代时用转发头,保证给出的是外网可访问地址
    return f"{_base_url(request)}/api/webhooks/git/{repo_id}"


# ---------------------------------------------------------------- CRUD
@router.get("", response_model=list[schemas.RepositoryOut])
def list_repos(tenant_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """列出当前用户可见的仓库:超管全部;其他人只看自己接入的(+ 平台共享)。"""
    from sqlalchemy import or_

    q = select(Repository).order_by(Repository.id)
    if tenant_id is not None:
        q = q.where(or_(Repository.tenant_id == tenant_id, Repository.scope == "platform"))
    return [_out(r, db, user) for r in db.scalars(q).all() if _repo_access(db, user, r) is not None]


@router.post("", response_model=schemas.RepositoryOut, status_code=201)
def create_repo(
    body: schemas.RepositoryCreate, request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    if body.scope == "platform":
        authz.require_superadmin(user)
        body.tenant_id = None
    else:
        if not body.tenant_id:
            raise HTTPException(400, "缺少组织")
        # 仓库属于接入者本人:组织内开发者及以上都可以接入自己的仓库
        _check_tenant_access(user, body.tenant_id, "developer")
        if not db.get(Tenant, body.tenant_id):
            raise HTTPException(404, "组织不存在")
        # 企业版仓库同样属于接入者本人:只用于本人创建的企业版实例(优先于平台共享仓库),开发者即可接入
    r = Repository(
        tenant_id=body.tenant_id,
        scope=body.scope,
        is_enterprise=bool(body.is_enterprise),
        created_by=user.id,
        name=body.name,
        token=body.token or None,
        auto_deploy=body.auto_deploy and not body.is_enterprise,
        webhook_secret=gitsvc.new_secret(),
    )
    _apply_url(r, body.url)
    if body.account_id:
        acc = _get_account(body.account_id, db, user)
        if acc.provider != r.provider:
            raise HTTPException(400, f"所选账号是 {acc.provider},与仓库地址({r.provider})不匹配")
        r.account_id = acc.id
    dq = select(Repository).where(Repository.tenant_id == r.tenant_id, Repository.scope == r.scope, Repository.url == r.url)
    if r.scope != "platform":
        dq = dq.where(Repository.created_by == user.id)  # 同一仓库不同的人可各自接入(互不可见)
    dup = db.scalar(dq)
    if dup:
        raise HTTPException(409, f"您已接入过同一仓库:{dup.name}")
    if r.is_enterprise:
        _validate_enterprise_repo(db, r)
    db.add(r)
    db.flush()
    if r.is_enterprise:
        _ensure_single_enterprise(db, r)
    db.commit()
    db.refresh(r)
    if body.account_id and body.auto_webhook and not r.is_enterprise:
        _ensure_remote_webhook(r, db, _base_url(request))
    return _out(r, db, user)


def _ensure_remote_webhook(r: Repository, db: Session, base_url: str) -> str | None:
    """用账号令牌在 GitHub/Gitee 上创建 push webhook;失败只记 last_error,不抛错。"""
    try:
        c = _client_for_repo(db, r)
        r.webhook_id = c.create_webhook(r.owner, r.repo, f"{base_url}/api/webhooks/git/{r.id}", r.webhook_secret)
        r.last_error = None
    except (OAuthError, HTTPException) as e:
        r.last_error = f"自动创建 Webhook 失败:{getattr(e, 'detail', e)}"[:512]
    db.commit()
    return r.webhook_id


@router.get("/{repo_id}", response_model=schemas.RepositoryOut)
def get_repo(repo_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return _out(_get_repo(repo_id, db, user), db, user)


@router.put("/{repo_id}", response_model=schemas.RepositoryOut)
def update_repo(
    repo_id: int, body: schemas.RepositoryUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    r = _get_repo(repo_id, db, user, write=True)
    data = body.model_dump(exclude_unset=True)
    if "is_enterprise" in data and data["is_enterprise"] is not None:
        if data["is_enterprise"] and not r.is_enterprise:
            if "url" in data and data["url"]:
                _apply_url(r, data["url"])
            if "token" in data:
                r.token = data["token"] or None
            _validate_enterprise_repo(db, r)
            _ensure_single_enterprise(db, r)
        r.is_enterprise = data["is_enterprise"]
    if "url" in data and data["url"]:
        _apply_url(r, data["url"])
        r.branches_json = None
        r.branches_synced_at = None
    if "name" in data and data["name"]:
        r.name = data["name"]
    if "token" in data:
        r.token = data["token"] or None
    if "auto_deploy" in data and data["auto_deploy"] is not None:
        r.auto_deploy = data["auto_deploy"]
    if data.get("regenerate_secret"):
        r.webhook_secret = gitsvc.new_secret()
    db.commit()
    db.refresh(r)
    return _out(r, db, user)


@router.delete("/{repo_id}", status_code=204)
def delete_repo(repo_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    r = _get_repo(repo_id, db, user, write=True)
    if r.webhook_id and r.provider in gitoauth.PROVIDERS:
        try:
            _client_for_repo(db, r).delete_webhook(r.owner, r.repo, r.webhook_id)
        except (OAuthError, HTTPException) as e:
            log.warning("删除远端 webhook 失败(忽略): %s", e)
    db.delete(r)
    db.commit()


# ---------------------------------------------------------------- 连接测试 / 分支
@router.post("/test", response_model=schemas.ConnectionTestOut)
def test_connection(body: schemas.RepositoryCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """保存前测试(不落库)。"""
    try:
        info = gitsvc.parse_repo_url(body.url)
        token = body.token or None
        if not token and body.account_id:
            token = gitoauth.refresh_if_needed(db, _get_account(body.account_id, db, user)).access_token
        refs, default = gitsvc.ls_remote(info["https_url"], token)
    except OAuthError as e:
        return schemas.ConnectionTestOut(ok=False, message=str(e))
    except (RuntimeError, ValueError) as e:
        return schemas.ConnectionTestOut(ok=False, message=str(e))
    return schemas.ConnectionTestOut(
        ok=True, message=f"连接成功,共 {len(refs)} 个分支", default_branch=default, branch_count=len(refs)
    )


@router.post("/{repo_id}/test", response_model=schemas.ConnectionTestOut)
def test_repo(repo_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    r = _get_repo(repo_id, db, user)
    try:
        refs, default = gitsvc.ls_remote(r.url, _repo_token(db, r))
    except (RuntimeError, ValueError) as e:
        r.last_error = str(e)[:512]
        db.commit()
        return schemas.ConnectionTestOut(ok=False, message=str(e))
    r.last_error = None
    db.commit()
    return schemas.ConnectionTestOut(
        ok=True, message=f"连接成功,共 {len(refs)} 个分支", default_branch=default, branch_count=len(refs)
    )


@router.post("/{repo_id}/sync", response_model=schemas.BranchesOut)
def sync_repo(repo_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    r = _get_repo(repo_id, db, user)
    _do_sync(r, db)
    return get_branches(repo_id, db, user)


@router.get("/{repo_id}/branches", response_model=schemas.BranchesOut)
def get_branches(repo_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """返回缓存的分支快照(首次自动同步),并附上绑定到各分支的环境。"""
    r = _get_repo(repo_id, db, user)
    if not r.branches_json:
        _do_sync(r, db)
    snap = json.loads(r.branches_json or "{}")
    envs = _envs_for_repo(db, r)
    by_branch: dict[str, list] = {}
    for e in envs:
        by_branch.setdefault(e.branch or "", []).append(
            schemas.BranchEnv(id=e.id, name=e.name, kind=e.kind, status=e.status, url=e.url)
        )
    out = []
    for b in snap.get("branches", []):
        out.append(
            schemas.BranchOut(
                **b,
                is_default=(b["name"] == snap.get("default_branch")),
                environments=by_branch.get(b["name"], []),
            )
        )
    return schemas.BranchesOut(
        synced_at=r.branches_synced_at, default_branch=snap.get("default_branch"), branches=out
    )


@router.post("/{repo_id}/branches", response_model=schemas.BranchesOut, status_code=201)
def create_branch(
    repo_id: int, body: schemas.BranchCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    """在 GitHub / Gitee 上从 from_branch 新建分支(需账号或有写权限的令牌)。"""
    r = _get_repo(repo_id, db, user, write=True)
    c = _client_for_repo(db, r)
    try:
        c.create_branch(r.owner, r.repo, body.name, body.from_branch)
    except OAuthError as e:
        raise HTTPException(502, str(e))
    _do_sync(r, db)
    return get_branches(repo_id, db, user)


@router.delete("/{repo_id}/branches/{branch:path}", response_model=schemas.BranchesOut)
def delete_branch(repo_id: int, branch: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    r = _get_repo(repo_id, db, user, write=True)
    if branch == r.default_branch:
        raise HTTPException(400, "不能删除默认分支")
    if any((e.branch or "") == branch for e in _envs_for_repo(db, r)):
        raise HTTPException(409, "该分支仍有环境绑定,请先删除或改绑环境")
    c = _client_for_repo(db, r)
    try:
        c.delete_branch(r.owner, r.repo, branch)
    except OAuthError as e:
        raise HTTPException(502, str(e))
    _do_sync(r, db)
    return get_branches(repo_id, db, user)


@router.post("/{repo_id}/webhook/auto", response_model=schemas.RepositoryOut)
def auto_webhook(repo_id: int, request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """用账号令牌在 Git 平台上(重新)创建 webhook。"""
    r = _get_repo(repo_id, db, user, write=True)
    _ensure_remote_webhook(r, db, _base_url(request))
    if r.last_error and "Webhook" in r.last_error:
        raise HTTPException(502, r.last_error)
    return _out(r, db, user)


# ---------------------------------------------------------------- Git 账号(OAuth)
@git_router.get("/oauth/apps", response_model=list[schemas.OAuthAppOut])
def oauth_apps(request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """所有登录用户可看是否已配置(以决定是否显示「连接」按钮);client_id 仅管理员可见。"""
    base = _base_url(request)
    out = []
    for p, a in gitoauth.get_oauth_apps(db).items():
        out.append(
            schemas.OAuthAppOut(
                provider=p,
                client_id=a["client_id"] if authz.is_superadmin(user) else "",
                configured=a["configured"],
                callback_url=f"{base}/api/git/oauth/{p}/callback",
            )
        )
    return out


@git_router.put("/oauth/apps/{provider}", response_model=list[schemas.OAuthAppOut], dependencies=[Depends(require_admin)])
def set_oauth_app(
    provider: str, body: schemas.OAuthAppIn, request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    if provider not in gitoauth.PROVIDERS:
        raise HTTPException(400, "仅支持 github / gitee")
    gitoauth.set_oauth_app(db, provider, body.client_id, body.client_secret)
    return oauth_apps(request, db, user)


@git_router.get("/oauth/{provider}/authorize")
def oauth_authorize(provider: str, request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """返回跳转地址,前端 window.location 到该地址完成授权。"""
    if provider not in gitoauth.PROVIDERS:
        raise HTTPException(400, "仅支持 github / gitee")
    redirect_uri = f"{_base_url(request)}/api/git/oauth/{provider}/callback"
    try:
        return {"url": gitoauth.authorize_url(db, provider, user.id, redirect_uri)}
    except OAuthError as e:
        raise HTTPException(400, str(e))


@git_router.get("/oauth/{provider}/callback")
def oauth_callback(provider: str, request: Request, code: str | None = None, state: str | None = None, error: str | None = None):
    """Git 平台回调(公开)。成功后跳回前端 /repos。"""

    def back(**q):
        return RedirectResponse("/repos?" + "&".join(f"{k}={quote(str(v))}" for k, v in q.items()), status_code=302)

    if error or not code or not state:
        return back(git_error=error or "授权被取消")
    with SessionLocal() as db:
        try:
            st = gitoauth.parse_state(state)
            if st["provider"] != provider:
                raise OAuthError("授权平台不匹配")
            tok = gitoauth.exchange_code(db, provider, code, st["redirect_uri"])
            me = gitoauth.Client(provider, tok["access_token"]).me()
        except OAuthError as e:
            return back(git_error=str(e))
        acc = db.scalar(
            select(GitAccount).where(GitAccount.user_id == st["user_id"], GitAccount.provider == provider, GitAccount.login == me["login"])
        )
        if not acc:
            acc = GitAccount(user_id=st["user_id"], provider=provider, login=me["login"])
            db.add(acc)
        acc.display_name = me.get("name")
        acc.avatar_url = me.get("avatar_url")
        acc.access_token = tok["access_token"]
        acc.refresh_token = tok["refresh_token"]
        acc.expires_at = tok["expires_at"]
        acc.scopes = tok["scopes"]
        db.commit()
    return back(git_linked=provider, login=me["login"])


@git_router.get("/accounts", response_model=list[schemas.GitAccountOut])
def list_accounts(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.scalars(select(GitAccount).where(GitAccount.user_id == user.id).order_by(GitAccount.id)).all()


@git_router.post("/accounts/token", response_model=schemas.GitAccountOut, status_code=201)
def link_account_by_token(body: schemas.GitAccountTokenIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """用个人访问令牌连接 GitHub / Gitee 账号(不需要 OAuth 应用与回调地址)。
    GitHub PAT 需 repo + admin:repo_hook;Gitee 私人令牌需 user_info / projects / hook。
    """
    try:
        me = gitoauth.Client(body.provider, body.token).me()
    except OAuthError as e:
        raise HTTPException(400, f"令牌校验失败:{e}")
    acc = db.scalar(
        select(GitAccount).where(GitAccount.user_id == user.id, GitAccount.provider == body.provider, GitAccount.login == me["login"])
    )
    if not acc:
        acc = GitAccount(user_id=user.id, provider=body.provider, login=me["login"])
        db.add(acc)
    acc.display_name = me.get("name")
    acc.avatar_url = me.get("avatar_url")
    acc.access_token = body.token
    acc.refresh_token = None
    acc.expires_at = None  # 个人令牌由用户自行管理有效期
    acc.scopes = "pat"
    db.commit()
    db.refresh(acc)
    return acc


@git_router.delete("/accounts/{account_id}", status_code=204)
def unlink_account(account_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    acc = _get_account(account_id, db, user)
    for r in acc.repositories:
        r.account_id = None  # 仓库保留,变为"无令牌"
    db.delete(acc)
    db.commit()


@git_router.get("/accounts/{account_id}/repos", response_model=list[schemas.RemoteRepoOut])
def remote_repos(account_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    acc = gitoauth.refresh_if_needed(db, _get_account(account_id, db, user))
    try:
        return gitoauth.Client(acc.provider, acc.access_token).list_all_repos()
    except OAuthError as e:
        raise HTTPException(502, str(e))


@git_router.post("/accounts/{account_id}/repos", response_model=schemas.RemoteRepoOut, status_code=201)
def remote_create_repo(
    account_id: int, body: schemas.RemoteRepoCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    acc = gitoauth.refresh_if_needed(db, _get_account(account_id, db, user))
    try:
        j = gitoauth.Client(acc.provider, acc.access_token).create_repo(body.name, body.private, body.description)
    except OAuthError as e:
        raise HTTPException(502, str(e))
    return schemas.RemoteRepoOut(full_name=j["full_name"], clone_url=j["clone_url"], html_url=j["html_url"], default_branch=j["default_branch"], private=body.private)


# ---------------------------------------------------------------- 事件 / Webhook 信息
@router.get("/{repo_id}/events", response_model=list[schemas.PushEventOut])
def list_events(repo_id: int, limit: int = 50, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    _get_repo(repo_id, db, user)
    q = (
        select(PushEvent)
        .where(PushEvent.repository_id == repo_id)
        .order_by(PushEvent.id.desc())
        .limit(max(1, min(limit, 500)))
    )
    return db.scalars(q).all()


@router.get("/{repo_id}/webhook", response_model=schemas.WebhookInfoOut)
def webhook_info(repo_id: int, request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    r = _get_repo(repo_id, db, user, write=True)
    url = _webhook_url(request, r.id)
    tips = {
        "github": "仓库 Settings → Webhooks → Add webhook:Payload URL 填上方地址,Content type 选 application/json,Secret 填密钥,事件选 Just the push event。",
        "gitee": "仓库 管理 → WebHooks → 添加:URL 填上方地址,「WebHook 密码」或「签名密钥」均填此密钥,勾选 Push。",
        "gitlab": "项目 Settings → Webhooks:URL 填上方地址,Secret token 填密钥,Trigger 勾选 Push events。",
        "generic": "自建平台请在 push 时 POST JSON 到上方地址,并在请求头 X-Webhook-Token 携带密钥(不支持放在 URL 查询参数里)。",
    }
    return schemas.WebhookInfoOut(url=url, secret=r.webhook_secret, provider=r.provider, instructions=tips[r.provider])


# ---------------------------------------------------------------- 定时轮询(Webhook 收不到时的兜底)
@router.post("/{repo_id}/poll")
def poll_repo_now(repo_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """立即检查该仓库远端是否有新提交;有则按 push 处理。返回本次发现的变化。"""
    _get_repo(repo_id, db, user)
    events = gitpoll.poll_repo(repo_id)
    return {"events": events, "count": len(events)}


@git_router.get("/poll")
def poll_status(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return {"minutes": gitpoll.get_interval(db), **{k: v for k, v in gitpoll.state.items() if k != "thread_started"}}


@git_router.put("/poll", dependencies=[Depends(require_admin)])
def poll_set(body: dict, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    try:
        minutes = int(body.get("minutes", gitpoll.POLL_DEFAULT))
    except (TypeError, ValueError):
        raise HTTPException(400, "minutes 须为整数")
    if minutes < 0 or minutes > 1440:
        raise HTTPException(400, "minutes 范围 0(关闭)~1440")
    gitpoll.set_interval(db, minutes)
    return poll_status(db, user)


@git_router.post("/poll/run", dependencies=[Depends(require_admin)])
def poll_run_now(bg: BackgroundTasks):
    """立即对全部仓库轮询一次(后台)。"""
    if gitpoll.state["running"]:
        return {"started": False, "reason": "正在轮询中"}
    bg.add_task(jobs.spawn, gitpoll.poll_all)
    return {"started": True}


# ---------------------------------------------------------------- Webhook 接收(公开)
@webhook_router.post("/git/{repo_id}")
async def receive_git_webhook(repo_id: int, request: Request, bg: BackgroundTasks, token: str | None = None):
    body = await request.body()
    form_payload = None
    if "application/x-www-form-urlencoded" in (request.headers.get("content-type") or ""):
        # 兼容 form 编码(GitHub 选了 x-www-form-urlencoded 时 payload 字段是 JSON 字符串)
        form = await request.form()
        form_payload = form.get("payload")
    headers = dict(request.headers)
    # DB 与验签是同步阻塞操作,放到线程池,避免阻塞事件循环
    from starlette.concurrency import run_in_threadpool

    return await run_in_threadpool(_handle_git_webhook, repo_id, headers, body, form_payload, token, bg)


_seen_deliveries: dict[str, float] = {}  # 投递 id -> 过期时间(防同一 webhook 被重放触发多次部署)
_seen_lock = threading.Lock()


def _replayed(headers: dict, repo_id: int) -> bool:
    h = {k.lower(): v for k, v in headers.items()}
    did = h.get("x-github-delivery") or h.get("x-gitlab-event-uuid") or h.get("x-gitee-delivery") or h.get("x-webhook-delivery")
    if not did:
        return False
    key = f"{repo_id}:{did}"
    now = time.time()
    with _seen_lock:
        for k in [k for k, exp in _seen_deliveries.items() if exp < now]:
            _seen_deliveries.pop(k, None)
        if key in _seen_deliveries:
            return True
        _seen_deliveries[key] = now + 600
    return False


def _handle_git_webhook(repo_id: int, headers: dict, body: bytes, form_payload: str | None, token: str | None, bg: BackgroundTasks):
    with SessionLocal() as db:
        r = db.get(Repository, repo_id)
        if not r:
            # 不泄露仓库 id 是否存在:与验签失败同样返回 401
            raise HTTPException(401, "签名校验失败或仓库不存在")
        try:
            source = gitsvc.verify_webhook(headers, body, r.webhook_secret, token)
        except PermissionError as e:
            raise HTTPException(401, str(e))
        if _replayed(headers, r.id):
            return {"ok": True, "ignored": True, "reason": "重复投递"}
        try:
            payload = json.loads(form_payload if form_payload is not None else (body or b"{}"))
        except ValueError:
            raise HTTPException(400, "无法解析请求体")
        info = gitsvc.parse_push_payload(source, headers, payload)
        if info is None:
            return {"ok": True, "ignored": True, "reason": "非分支推送事件"}

        ev, env_ids, deploy = gitpoll.record_push(db, r, info)
        if deploy:
            bg.add_task(jobs.spawn, gitpoll.dispatch_push, r.id, ev.id, env_ids, info)
        return {"ok": True, "event_id": ev.id, "branch": info["branch"], "environments": env_ids}
