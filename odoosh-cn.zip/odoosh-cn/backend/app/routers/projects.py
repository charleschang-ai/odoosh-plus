"""实例详情页(仿 odoo.sh 项目页):每个实例就是一个独立项目。

项目 = 根实例(创建时选的仓库 + 分支)+ 从它详情页按分支创建的兄弟环境(project_id 指向根实例)。
不同实例即使绑定同一仓库/分支也互不合并、互不影响。

  GET  /api/projects/{env_id}?refresh=1                项目信息(根实例)+ 环境(按档位)+ 未分配分支(镜像 for-each-ref)+ 权限
  POST /api/projects/{env_id}/environments             {branch, kind, expire_days?, provision=true} 按分支建环境(归入本项目)
  POST /api/projects/{env_id}/environments/{id}/kind   {kind, expire_days?, confirm?} 改档位(拖拽的后端)
  POST /api/projects/{env_id}/environments/{id}/refresh-from-production
  GET  /api/projects/{env_id}/branches/{branch}/commits   分支提交流(未分配分支用;已建环境用 /environments/{id}/commits)
  GET  /api/projects/{env_id}/environments/{id}/upgrade   企业版升级信息
  POST /api/projects/{env_id}/environments/{id}/upgrade   执行企业版升级
{env_id} 可以是项目内任一环境的 id,后端自动定位根实例。
"""

import logging
from dataclasses import dataclass

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import authz
from ..auth import get_current_user
from ..db import get_db
from ..models import Environment, User
from ..models_git import Repository
from ..services import deploy as deploysvc
from ..services import jobs
from ..services import git as gitsvc
from ..services import orchestrator
from ..services import project as svc

log = logging.getLogger("odoosh.projects")

router = APIRouter(prefix="/api/projects", tags=["projects"])

BUSY = orchestrator.BUSY_STATES


# ---------------------------------------------------------------- schemas
class BranchEnvCreate(BaseModel):
    branch: str
    kind: str = "dev"
    expire_days: int | None = None  # None = 全局默认(生产永不)
    provision: bool = True
    odoo_version: str | None = None  # 缺省:同项目根实例的版本
    edition: str | None = None
    base_mode: str | None = None
    clone_db: bool | None = None  # 新建预发环境:True/None = 从生产克隆;False = 空库
    neutralize: bool = True  # 克隆后是否中和(odoo neutralize:停 cron / 邮件 / 支付,界面显示红色横幅)


class KindChange(BaseModel):
    kind: str
    expire_days: int | None = None
    confirm: str | None = None  # 生产降级 / 删除时要求输入分支名
    # 拖到预发(staging)时前端弹窗的选择:True = 从生产克隆最新数据并中和(推荐);False = 保留当前数据库;
    # None = 旧行为(开发→预发且有生产库时克隆)
    clone_db: bool | None = None
    neutralize: bool = True  # 改为测试时是否中和(克隆后 / 或对保留的当前库执行 odoo neutralize)
    # 升为生产时:True = 丢弃当前库与 filestore,换成全新空库(只装 base);False/None = 保留当前库(测试库直接成为生产库)
    fresh_db: bool = False


class UpgradeIn(BaseModel):
    action: str = "update_all"  # restart | update | update_all


@dataclass
class Project:
    root: Environment
    repo: Repository | None

    @property
    def id(self) -> int:
        return self.root.id

    @property
    def tenant_id(self) -> int:
        return self.root.tenant_id

    @property
    def url(self) -> str:
        return self.root.repo_url or ""


class _NoRepo(Exception):
    """无仓库实例:跳过 git 镜像同步的内部信号。"""


# ---------------------------------------------------------------- helpers
def _get_project(env_id: int, db: Session, user: User) -> Project:
    e = db.get(Environment, env_id)
    if not e:
        raise HTTPException(404, "实例不存在")
    root = svc.project_root(db, e)
    authz.check_env(db, user, root, "view")  # 名单里的「可访问」也能打开详情页(只读:历史 / 日志 / 监控),动作按矩阵逐项判定
    # 无仓库实例也有详情页(单实例视图:无分支栏/历史,只有日志/监控/备份/数据库/Shell/设置 + 定制代码)
    repo = svc.find_repo_for_env(db, root) if root.repo_url else None
    return Project(root=root, repo=repo)


def _get_env(p: Project, env_id: int, db: Session, user: User, action: str = "view") -> Environment:
    e = db.get(Environment, env_id)
    if not e or e.tenant_id != p.tenant_id or e.deleted_at is not None or (e.id != p.root.id and e.project_id != p.root.id):
        raise HTTPException(404, "该环境不属于此项目")  # 直接判归属,不再把整个项目查一遍
    authz.check_env(db, user, e, action)
    return e


def _env_out(e: Environment) -> dict:
    return {
        "id": e.id, "name": e.name, "kind": e.kind, "branch": e.branch, "status": e.status, "status_message": e.status_message,
        "progress": e.progress, "url": e.url, "domain": e.domain, "odoo_version": e.odoo_version, "edition": e.edition, "base_mode": e.base_mode,
        "sleep_idle_hours": e.sleep_idle_hours, "last_active_at": e.last_active_at.isoformat() if e.last_active_at else None,
        "code_commit": e.code_commit, "enterprise_commit": e.enterprise_commit, "container_name": e.container_name, "db_name": e.db_name,
        "extra_db_count": getattr(e, "_extra_db_count", 0), "max_dbs": e.max_dbs,
        "deploy_action": e.deploy_action, "deploy_modules": e.deploy_modules, "auto_deploy": e.auto_deploy,
        "expires_at": e.expires_at, "created_at": e.created_at, "mem_mb": e.mem_mb, "cpus": e.cpus, "log_level": e.log_level, "tenant_id": e.tenant_id,
        "project_id": e.project_id, "is_root": not e.project_id,
    }


def _project_out(p: Project) -> dict:
    r = p.repo
    url = p.url
    web = url[:-4] if url.endswith(".git") else url
    try:
        info = gitsvc.parse_repo_url(url)
        owner, repo, provider = info.get("owner"), info.get("repo"), info.get("provider")
    except Exception:  # noqa: BLE001
        owner = repo = provider = None
    return {
        "id": p.id, "name": p.root.name, "url": url, "web_url": web, "tenant_id": p.tenant_id, "branch": p.root.branch,
        "repo_id": r.id if r else None, "repo_name": r.name if r else (repo or url), "provider": (r.provider if r else provider) or "generic",
        "owner": r.owner if r else owner, "repo": r.repo if r else repo, "default_branch": r.default_branch if r else None,
        "auto_deploy": r.auto_deploy if r else True, "registered": bool(r),
    }


# ---------------------------------------------------------------- 项目详情
@router.get("/{env_id}")
def get_project(env_id: int, refresh: bool = False, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    p = _get_project(env_id, db, user)
    envs = svc.project_envs(db, p.root)
    changed = False
    states = orchestrator.container_states()  # 一次 docker list(以前每个环境一次 inspect,前端 2.5s 轮询)
    for e in envs:
        real = orchestrator.sync_status(e, states)
        if real != e.status:
            e.status = real
            changed = True
    if changed:
        db.commit()
    bound = {e.branch for e in envs if e.branch}
    branches, err = [], None
    try:
        if not p.url:  # 无仓库实例:没有分支概念,跳过 git 镜像同步
            raise _NoRepo()
        md, _ = deploysvc.ensure_mirror(db, p.tenant_id, p.url, force=refresh, fetch_timeout=60, background=not refresh)
        branches = deploysvc.list_branches(md)
    except _NoRepo:
        pass
    except Exception as ex:  # noqa: BLE001
        err = str(ex)
        if p.repo and p.repo.branches_json:  # 退化:用分支快照
            import json

            try:
                snap = json.loads(p.repo.branches_json)
                branches = [{"name": b["name"], "sha": b.get("sha"), "committed_at": b.get("date"), "message": b.get("message")} for b in snap.get("branches", [])]
            except ValueError:
                pass
    by_name = {b["name"]: b for b in branches}
    role = authz.env_role(db, user, p.root)  # 项目内环境共享根实例的名单,角色一致
    default_branch = p.repo.default_branch if p.repo else None
    from ..services import databases as dbsvc

    counts = dbsvc.counts_bulk(db, [e.id for e in envs])
    for e in envs:
        e._extra_db_count = counts.get(e.id, 0)
    return {
        "repo": _project_out(p),
        "root_id": p.id,
        "environments": [{**_env_out(e), "my_role": role, "owner_user_id": e.owner_user_id, "head": by_name.get(e.branch or "")} for e in envs],
        "unassigned": [{**b, "is_default": b["name"] == default_branch} for b in branches if b["name"] not in bound],
        "has_production": any(e.kind == "production" for e in envs),
        "mirror_error": err,
        "role": role,
        "permissions": {k: authz.env_permissions(role, k) for k in svc.KINDS},
    }


# ---------------------------------------------------------------- 按分支建环境(归入本项目)
@router.post("/{env_id}/environments", status_code=201)
def create_from_branch(env_id: int, body: BranchEnvCreate, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    p = _get_project(env_id, db, user)
    if body.kind not in svc.KINDS:
        raise HTTPException(400, "无效的环境类型")
    authz.check_project_create(db, user, p.root, body.kind)
    # 派生环境的拥有者 = 项目拥有者,配额按项目拥有者名下的实例数校验(协作者创建也计入拥有者)
    authz.check_env_quota(db, db.get(User, p.root.owner_user_id) if p.root.owner_user_id else None)
    branch = body.branch.strip()
    if not branch:
        raise HTTPException(400, "缺少分支")
    envs = svc.project_envs(db, p.root)
    if any((e.branch or "") == branch for e in envs):
        raise HTTPException(409, f"分支「{branch}」在本项目里已有环境")
    prod = next((e for e in envs if e.kind == "production"), None)
    if body.kind == "production" and prod:
        raise HTTPException(409, f"本项目已有生产环境「{prod.name}」(分支 {prod.branch}),请先把现有生产分支拖走")
    try:
        md, _ = deploysvc.ensure_mirror(db, p.tenant_id, p.url, fetch_timeout=120)
        deploysvc.resolve_commit(md, branch)
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(400, str(ex))
    ref = p.root
    env = Environment(
        tenant_id=p.tenant_id,
        name=svc.env_name_for_branch(db, p.tenant_id, branch),
        kind=body.kind,
        odoo_version=body.odoo_version or ref.odoo_version,
        base_mode=body.base_mode or ref.base_mode,
        edition=body.edition or ref.edition,
        repo_url=p.url,
        branch=branch,
        project_id=p.id,
        deploy_action=ref.deploy_action,
        deploy_modules=ref.deploy_modules,
        auto_deploy=body.kind != "production",
        owner_user_id=ref.owner_user_id,  # 派生环境沿用项目拥有者;名单挂在根实例上自动共享
    )
    env.expires_at = None if env.kind == "production" else orchestrator.compute_expires_at(body.expire_days, env.kind)
    db.add(env)
    db.commit()
    db.refresh(env)
    clone_from = prod.id if (body.kind == "staging" and prod and prod.db_name and body.clone_db is not False) else None
    if clone_from:
        svc.set_pending_neutralize(env.id, body.neutralize)
    if body.provision:
        env.status, env.status_message, env.progress, env.log = "provisioning", "已排队", 0, None
        db.commit()
        bg.add_task(jobs.spawn, orchestrator.provision, env.id, None, None, clone_from)
    return {**_env_out(env), "clone_from": clone_from}


# ---------------------------------------------------------------- 改档位(拖拽)
@router.post("/{env_id}/environments/{target_id}/kind")
def change_kind(env_id: int, target_id: int, body: KindChange, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    p = _get_project(env_id, db, user)
    e = _get_env(p, target_id, db, user, "edit")
    new_kind = body.kind
    if new_kind not in svc.KINDS:
        raise HTTPException(400, "无效的环境类型")
    if new_kind == e.kind:
        return _env_out(e)
    if e.status in BUSY:
        raise HTTPException(409, f"环境正在 {e.status},请稍候")
    authz.check_project_create(db, user, p.root, new_kind)
    if e.kind == "production":
        authz.check_env(db, user, e, "delete")
        if (body.confirm or "") != (e.branch or e.name):
            raise HTTPException(400, f"生产环境降级需输入分支名「{e.branch or e.name}」确认")
    prod = svc.production_env(db, p.root, exclude_id=e.id)
    if new_kind == "production" and prod:
        raise HTTPException(409, f"本项目已有生产环境「{prod.name}」(分支 {prod.branch}),请先把它拖走")
    clone_from = None
    if new_kind == "staging" and prod and prod.db_name and e.container_name:
        if body.clone_db is True or (body.clone_db is None and e.kind == "dev"):
            clone_from = prod.id  # → 预发:库从生产重建并中和(前端弹窗选择;默认开发→预发克隆)
    fresh_db = bool(body.fresh_db and new_kind == "production" and e.db_name)
    if not orchestrator.try_claim(db, e, "cloning" if (clone_from or fresh_db) else "restarting"):
        raise HTTPException(409, f"环境正在 {e.status},请稍候")
    # 档位立即切换(前端拖完即刻落到新分组);后台任务失败时会回退到原档位
    old_kind = e.kind
    e.kind = new_kind
    if new_kind == "production":
        e.expires_at = None
        e.auto_deploy = False
    db.commit()
    bg.add_task(jobs.spawn, svc.change_kind, e.id, new_kind, clone_from, body.expire_days, body.neutralize and new_kind == "staging", old_kind, fresh_db)
    return {**_env_out(e), "clone_from": clone_from, "fresh_db": fresh_db}


@router.post("/{env_id}/environments/{target_id}/refresh-from-production")
def refresh_from_production(env_id: int, target_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    p = _get_project(env_id, db, user)
    e = _get_env(p, target_id, db, user, "restore")
    if e.kind == "production":
        raise HTTPException(400, "生产环境不能从自己刷新")
    prod = svc.production_env(db, p.root)
    if not prod or not prod.db_name:
        raise HTTPException(400, "本项目没有(已创建的)生产环境")
    if e.status in BUSY:
        raise HTTPException(409, f"环境正在 {e.status},请稍候")
    if not e.db_name:
        raise HTTPException(400, "目标环境尚未创建")
    if not orchestrator.try_claim(db, e, "cloning"):
        raise HTTPException(409, f"环境正在 {e.status},请稍候")
    bg.add_task(jobs.spawn, svc.refresh_from, e.id, prod.id)
    return _env_out(e)


# ---------------------------------------------------------------- 分支提交流(未分配分支)
@router.get("/{env_id}/branches/{branch:path}/commits")
def branch_commits(env_id: int, branch: str, limit: int = 30, skip: int = 0, refresh: bool = False, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    p = _get_project(env_id, db, user)
    try:
        md, _ = deploysvc.ensure_mirror(db, p.tenant_id, p.url, force=refresh, fetch_timeout=60, background=not refresh)
        items = deploysvc.list_commits(md, branch, limit, skip)
    except Exception as ex:  # noqa: BLE001
        return {"items": [], "error": str(ex)}
    return {"items": items, "error": None}


# ---------------------------------------------------------------- 企业版升级
@router.get("/{env_id}/environments/{target_id}/upgrade")
def upgrade_info(env_id: int, target_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    p = _get_project(env_id, db, user)
    e = _get_env(p, target_id, db, user, "view")
    return svc.enterprise_upgrade_info(db, e)


@router.post("/{env_id}/environments/{target_id}/upgrade")
def do_upgrade(env_id: int, target_id: int, body: UpgradeIn, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    p = _get_project(env_id, db, user)
    e = _get_env(p, target_id, db, user, "deploy")
    if e.edition != "enterprise":
        raise HTTPException(400, "不是企业版实例")
    if e.status in BUSY:
        raise HTTPException(409, f"环境正在 {e.status},请稍候")
    if not e.container_name:
        raise HTTPException(400, "实例尚未创建")
    if body.action not in ("restart", "update", "update_all"):
        raise HTTPException(400, "无效的动作")
    if not orchestrator.try_claim(db, e, "deploying", "已排队(企业版升级)"):
        raise HTTPException(409, f"环境正在 {e.status},请稍候")
    bg.add_task(jobs.spawn, svc.enterprise_upgrade, e.id, body.action, user.username)
    return _env_out(e)
