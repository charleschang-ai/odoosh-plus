"""附加数据库 API(一个实例多个库)。

  GET    /api/environments/{id}/databases                 列表(主库 + 附加库)+ 能力 / 配额
  POST   /api/environments/{id}/databases                 新建附加库(后台任务)
  PUT    /api/environments/{id}/databases/{db_id}         改过期
  DELETE /api/environments/{id}/databases/{db_id}         删除(输库名确认;默认先自动备份)
  POST   /api/environments/{id}/databases/{db_id}/retry   失败的附加库重试创建
  POST   /api/environments/{id}/databases/{db_id}/neutralize
  POST   /api/environments/{id}/databases/{db_id}/reset-admin
  GET/PUT /api/environments/{id}/databases/license?database_id=  企业版到期时间(读 / 改 database.expiration_date)
  GET    /api/environments/{id}/databases/{db_id}/secrets 该库 Odoo admin 密码(需 secrets 权限)

权限沿用实例动作矩阵:看列表 = view;新建 = clone;删除 / 中性化 / 重置密码 = restore;看密码 = secrets。
"""

import json
import logging
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import authz
from .. import schemas_db as S
from ..auth import get_current_user
from ..db import get_db
from ..models import Environment, Tenant, User
from ..models_db import EnvironmentDatabase
from ..services import databases as svc
from ..services import dockerx, jobs, orchestrator

log = logging.getLogger("odoosh.databases")

router = APIRouter(prefix="/api/environments/{env_id}/databases", tags=["databases"])


def _env(env_id: int, db: Session, user: User, action: str = "view") -> Environment:
    e = db.get(Environment, env_id)
    if not e or e.deleted_at is not None:
        raise HTTPException(404, "环境不存在")
    authz.check_env(db, user, e, action)
    return e


def _row(db: Session, e: Environment, db_id: int) -> EnvironmentDatabase:
    r = db.get(EnvironmentDatabase, db_id)
    if not r or r.environment_id != e.id:
        raise HTTPException(404, "附加数据库不存在")
    return r


def _sizes(t: Tenant, names: list[str]) -> dict[str, int]:
    """一次 psql 拿到多个库的大小(PG 未运行时返回空)。"""
    out: dict[str, int] = {}
    if not names:
        return out
    try:
        pg = dockerx.get_container(orchestrator.pg_container_name(t))
        if not pg or pg.status != "running":
            return out
        lst = ",".join(f"'{n}'" for n in names)
        code, text = orchestrator._psql(pg, f"SELECT datname || '|' || pg_database_size(datname) FROM pg_database WHERE datname IN ({lst})")
        if code == 0:
            for ln in text.splitlines():
                n, _, sz = ln.strip().partition("|")
                if sz.strip().isdigit():
                    out[n.strip()] = int(sz)
    except Exception:  # noqa: BLE001
        pass
    return out


def _out_row(e: Environment, r: EnvironmentDatabase, size: int | None = None) -> S.DatabaseOut:
    return S.DatabaseOut(
        id=r.id, environment_id=e.id, is_primary=False, name=r.name, db_name=r.db_name, admin_login=r.admin_login or "admin",
        domain=svc.domain_of(e, r), url=svc.url_of(e, r), status=r.status, status_message=r.status_message, progress=r.progress or 0,
        source=r.source, source_ref=r.source_ref, expires_at=r.expires_at, size_bytes=size if size is not None else r.size_bytes,
        created_by=r.created_by, created_at=r.created_at,
    )


def _out_primary(e: Environment, size: int | None) -> S.DatabaseOut:
    return S.DatabaseOut(id=None, environment_id=e.id, is_primary=True, name="主库", db_name=e.db_name or "", domain=e.domain, url=e.url,
                         status="ready" if e.db_name else "creating", size_bytes=size, created_at=e.created_at)


@router.get("", response_model=S.DatabaseListOut)
def list_databases(env_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    e = _env(env_id, db, user, "view")
    t = db.get(Tenant, e.tenant_id)
    rows = svc.rows_of(db, e)
    sizes = _sizes(t, ([e.db_name] if e.db_name else []) + [r.db_name for r in rows if r.status == "ready"])
    items = ([_out_primary(e, sizes.get(e.db_name or ""))] if e.db_name else []) + [_out_row(e, r, sizes.get(r.db_name)) for r in rows]
    st = svc.feature_state(db, e, t)
    uq = authz.db_quota_state(db, user)  # 用户级配额(User.max_dbs)叠加在实例 / 组织配额之上
    st.update({"user_limit": uq["limit"], "user_used": uq["used"]})
    if st["allowed_now"] and not uq["allowed"]:
        st["allowed_now"] = False
        st["reason"] = uq["reason"]
    if e.repo_url and e.branch:
        code = f"{e.branch} @ {(e.code_commit or '')[:8] or '未部署'}"
    else:
        code = f"官方镜像 Odoo {e.odoo_version}{'(企业版)' if e.edition == 'enterprise' else ''}"
    return S.DatabaseListOut(items=items, code_summary=code, **st)


@router.get("/options")
def options(env_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """原生建库表单的语言 / 国家列表(来自实例里跑着的 Odoo)。"""
    e = _env(env_id, db, user, "view")
    return svc.native_options(e)


# ---------------------------------------------------------------- 企业版到期时间(本地测试库临时续期)
_LIC_KEYS = ("database.expiration_date", "database.expiration_reason", "database.enterprise_code", "database.create_date", "database.uuid")


def _lic_view(db: Session, e: Environment, database_id: int | None):
    if e.edition != "enterprise":
        raise HTTPException(400, "只有企业版实例才有到期时间")
    try:
        v = svc.view(db, e, database_id)
    except ValueError as ex:
        raise HTTPException(404, str(ex))
    if v.row is not None and v.row.status != "ready":
        raise HTTPException(409, "该数据库尚未就绪")
    if not v.db_name:
        raise HTTPException(409, "主库尚未创建")
    t = db.get(Tenant, e.tenant_id)
    pg = dockerx.get_container(orchestrator.pg_container_name(t))
    if not pg or pg.status != "running":
        raise HTTPException(409, "实例数据库未在运行")
    return v, pg


def _lic_read(pg, db_name: str) -> dict:
    keys = ",".join(f"'{k}'" for k in _LIC_KEYS)
    code, text = orchestrator._psql(pg, f"SELECT key || '|' || COALESCE(value,'') FROM ir_config_parameter WHERE key IN ({keys})", db_name)
    if code != 0:
        raise HTTPException(500, f"读取失败:{text[-200:]}")
    out = {k.split(".", 1)[1]: None for k in _LIC_KEYS}
    for ln in text.splitlines():
        k, sep, val = ln.strip().partition("|")
        if sep and k.strip().startswith("database."):
            out[k.strip().split(".", 1)[1]] = val.strip() or None
    return out


@router.get("/license")
def get_license(env_id: int, database_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """读该库 Odoo 的企业版到期参数(ir_config_parameter: database.expiration_date 等)。"""
    e = _env(env_id, db, user, "view")
    v, pg = _lic_view(db, e, database_id)
    info = _lic_read(pg, v.db_name)
    return {"db_name": v.db_name, **info, **_lic_state(info)}


# 让运行中的 Odoo 丢弃 ir.config_parameter 的 ormcache(无需重启):
#   Odoo 19+: orm_signaling_<cache> 表(取 max(id);ir.config_parameter 在 'stable' 缓存);17/18: base_cache_signaling_<cache> 序列;<=16: base_cache_signaling 序列。
#   为省事把存在的 default / stable 两个缓存都通知一遍。
_CACHE_BUMP_SQL = (
    "DO $$ DECLARE n text; BEGIN "
    "FOREACH n IN ARRAY ARRAY['orm_signaling_default','orm_signaling_stable'] LOOP "
    "  IF to_regclass(n) IS NOT NULL THEN EXECUTE format('INSERT INTO %I DEFAULT VALUES', n); END IF; END LOOP; "
    "FOREACH n IN ARRAY ARRAY['base_cache_signaling_default','base_cache_signaling'] LOOP "
    "  IF to_regclass(n) IS NOT NULL THEN PERFORM nextval(n); END IF; END LOOP; "
    "END $$;"
)


def _lic_state(info: dict) -> dict:
    """由 ir_config_parameter 的值推断:是否已过期 / 是否为绑定真实订阅码的库。"""
    exp = info.get("expiration_date")
    expired = None
    if exp:
        try:
            expired = datetime.strptime(exp[:19], "%Y-%m-%d %H:%M:%S") < datetime.utcnow()
        except ValueError:
            expired = None
    reason = (info.get("expiration_reason") or "").lower()
    real = bool(info.get("enterprise_code")) and reason not in ("", "trial", "demo")
    return {"expired": expired, "real_subscription": real}


@router.put("/license")
def set_license(env_id: int, body: S.LicenseUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """本地测试库临时续期:已绑定真实订阅码的库拒绝改动;否则把
    database.create_date=今天、database.expiration_date=所选日期、database.secret / database.uuid 重新生成。
    写完通知 Odoo 的缓存信号(见 _CACHE_BUMP_SQL)让运行中的进程丢弃 ir.config_parameter 缓存,无需重启。"""
    import uuid

    e = _env(env_id, db, user, "restore")
    try:
        d = datetime.strptime(body.expiration_date.strip()[:10], "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(400, "日期格式应为 YYYY-MM-DD")
    v, pg = _lic_view(db, e, body.database_id)
    before = _lic_read(pg, v.db_name)
    st = _lic_state(before)
    if st["real_subscription"]:
        raise HTTPException(409, f"该库已绑定订阅码({before.get('enterprise_code')},{before.get('expiration_reason')}),属于真实续费数据库,不做修改;请在 Odoo 设置里续费。")
    now = datetime.utcnow()
    values = {
        "database.create_date": now.strftime("%Y-%m-%d %H:%M:%S"),
        "database.expiration_date": f"{d.isoformat()} 23:59:59",
        "database.expiration_reason": "trial",
        "database.secret": str(uuid.uuid4()),
        "database.uuid": str(uuid.uuid4()),
    }
    rows = ", ".join(f"('{k}', '{val}', 1, 1, now(), now())" for k, val in values.items())
    sql = (
        f"INSERT INTO ir_config_parameter (key, value, create_uid, write_uid, create_date, write_date) VALUES {rows} "
        "ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, write_date = now(); "
        + _CACHE_BUMP_SQL
    )
    code, text = orchestrator._psql(pg, sql, v.db_name)
    if code != 0:
        raise HTTPException(500, f"写入失败:{text[-200:]}")
    log.info("license: env#%s %s renewed -> %s (was %s, expired=%s) by %s", e.id, v.db_name, values["database.expiration_date"],
             before.get("expiration_date"), st["expired"], user.username)
    after = _lic_read(pg, v.db_name)
    return {"db_name": v.db_name, **after, **_lic_state(after), "was_expired": st["expired"]}


@router.post("", response_model=S.DatabaseOut, status_code=202)
def create_database(env_id: int, body: S.DatabaseCreate, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    e = _env(env_id, db, user, "clone")
    t = db.get(Tenant, e.tenant_id)
    if e.status in orchestrator.BUSY_STATES:
        raise HTTPException(409, f"实例正在 {e.status},请稍候")
    try:
        svc.check_can_create(db, e, t)
        name = svc.validate_name(db, e, body.name)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    authz.check_db_quota(db, user)  # 用户级配额:能不能建、最多几个(超管不限)
    source_ref = (body.source_ref or "").strip() or None
    if body.source == "clone":
        try:
            src = svc.view_by_name(db, e, source_ref)
        except ValueError as ex:
            raise HTTPException(400, str(ex))
        if src.row is not None and src.row.status != "ready":
            raise HTTPException(409, "克隆源数据库尚未就绪")
        source_ref = src.db_name
    elif body.source == "backup":
        from ..models_backup import Backup

        b = db.get(Backup, int(source_ref)) if source_ref and source_ref.isdigit() else None
        if not b or b.status != "done":
            raise HTTPException(400, "备份不存在或未完成")
        if b.tenant_id != e.tenant_id and not authz.is_superadmin(user):
            raise HTTPException(403, "只能从同一组织的备份创建")
        # 还必须对「备份的来源实例」有权限,否则同组织内可把他人(如生产)备份还原成自己实例的附加库,
        # 绕过实例级授权名单读走全部数据。与 backups._get_backup 的判定保持一致。
        src_env = db.get(Environment, b.environment_id) if b.environment_id else None
        if not authz.can_see_env_data(db, user, src_env, b.tenant_id, minimum="developer"):
            raise HTTPException(403, "无权使用该备份(不在其来源实例的授权名单内)")
        if b.odoo_version and str(b.odoo_version) != str(e.odoo_version):
            raise HTTPException(409, f"备份来自 Odoo {b.odoo_version},本实例是 Odoo {e.odoo_version},不能直接恢复")
        source_ref = str(b.id)
    if body.expire_days is None:
        expires_at = svc.default_expires_at(db)
    else:
        expires_at = datetime.now(timezone.utc) + timedelta(days=body.expire_days) if body.expire_days > 0 else None
    opts = {"neutralize": bool(body.neutralize)}
    if body.source == "empty":
        opts.update({"login": (body.login or "admin").strip(), "password": body.password or None, "phone": body.phone or None,
                     "lang": body.lang or "zh_CN", "country_code": body.country_code or None, "demo": bool(body.demo)})
    row = EnvironmentDatabase(
        environment_id=e.id, tenant_id=e.tenant_id, name=name, db_name=svc.extra_db_name(e, name), status="creating", status_message="已排队",
        source=body.source, source_ref=source_ref, options=json.dumps(opts), expires_at=expires_at, created_by=user.username,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    bg.add_task(jobs.spawn, svc.create, row.id)
    return _out_row(e, row)


@router.post("/{db_id}/retry", response_model=S.DatabaseOut, status_code=202)
def retry_database(env_id: int, db_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    e = _env(env_id, db, user, "clone")
    r = _row(db, e, db_id)
    if r.status != "failed":
        raise HTTPException(409, "只有失败的附加库可以重试")
    r.status, r.status_message, r.progress = "creating", "已排队(重试)", 0
    db.commit()
    bg.add_task(jobs.spawn, svc.create, r.id)
    return _out_row(e, r)


@router.put("/{db_id}", response_model=S.DatabaseOut)
def update_database(env_id: int, db_id: int, body: S.DatabaseUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    e = _env(env_id, db, user, "restore")
    r = _row(db, e, db_id)
    if body.expire_days is not None:
        r.expires_at = datetime.now(timezone.utc) + timedelta(days=body.expire_days) if body.expire_days > 0 else None
    db.commit()
    db.refresh(r)
    return _out_row(e, r)


@router.delete("/{db_id}", status_code=202)
def delete_database(env_id: int, db_id: int, body: S.DatabaseDeleteIn, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    from ..routers.settings import get_setting
    from ..services import backup as backupsvc

    e = _env(env_id, db, user, "restore")
    r = _row(db, e, db_id)
    if body.confirm_name.strip().lower() not in (r.name, r.db_name):
        raise HTTPException(400, f"请输入数据库名「{r.name}」确认删除")
    if r.status in ("creating", "dropping", "restoring"):
        raise HTTPException(409, f"该数据库正在 {r.status},请稍候")
    if backupsvc.is_locked(e.id):
        raise HTTPException(409, "该实例正在备份或恢复中,请稍候再删除")
    want_backup = body.backup if body.backup is not None else (get_setting(db, "db.backup_before_drop") or "1") == "1"
    backup_id = None
    if want_backup and r.status == "ready":
        if not backupsvc.try_lock(e.id):
            raise HTTPException(409, "该实例正在备份或恢复中,请稍候再删除")
        t = db.get(Tenant, e.tenant_id)
        b = backupsvc.new_backup_record(db, svc.EnvDb(e, r), t, "manual", f"删除附加库 {r.name} 前自动备份", True, user.username)
        backup_id = b.id
    r.status, r.status_message, r.progress = "dropping", "已排队", 0
    db.commit()
    bg.add_task(jobs.spawn, svc.drop, r.id, backup_id)
    return {"ok": True, "backup_id": backup_id}


@router.post("/{db_id}/neutralize", status_code=202)
def neutralize_database(env_id: int, db_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    e = _env(env_id, db, user, "restore")
    r = _row(db, e, db_id)
    if r.status != "ready":
        raise HTTPException(409, "该数据库尚未就绪")

    def _job(row_id: int, env_id_: int):
        from ..services import project as projectsvc

        with svc.SessionLocal() as db2:
            row = db2.get(EnvironmentDatabase, row_id)
            e2 = db2.get(Environment, env_id_)
            t2 = db2.get(Tenant, e2.tenant_id)
            say = svc.DbLogger(e2.id, row.id, row.name)
            pg = dockerx.get_container(orchestrator.pg_container_name(t2))
            try:
                svc._set_status(row.id, "restoring", "中性化", 30)
                projectsvc.neutralize_db(pg, svc.EnvDb(e2, row), say, t2)
                say("中性化完成")
                svc._set_status(row.id, "ready", None, 100)
            except Exception as ex:  # noqa: BLE001
                say(f"中性化失败: {ex}")
                svc._set_status(row.id, "ready", f"中性化失败:{str(ex)[:200]}", 100)

    svc._set_status(r.id, "restoring", "已排队(中性化)", 0)
    bg.add_task(jobs.spawn, _job, r.id, e.id)
    return {"ok": True}


@router.post("/{db_id}/reset-admin")
def reset_admin(env_id: int, db_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """重置该库 Odoo admin 密码为一个新的随机值(写入 res_users),返回新密码。"""
    from ..services import sso as ssosvc

    e = _env(env_id, db, user, "restore")
    authz.check_env(db, user, e, "secrets")
    r = _row(db, e, db_id)
    if r.status != "ready":
        raise HTTPException(409, "该数据库尚未就绪")
    t = db.get(Tenant, e.tenant_id)
    c = dockerx.get_container(e.container_name or "")
    pg = dockerx.get_container(orchestrator.pg_container_name(t))
    if not c or c.status != "running" or not pg:
        raise HTTPException(409, "实例未在运行")
    pw = dockerx.rand_password(16)
    try:
        ssosvc.reset_admin_password(c, pg, svc.EnvDb(e, r), pw)
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(500, f"重置失败:{ex}")
    r.admin_password = pw
    db.commit()
    return {"login": r.admin_login or ssosvc.ADMIN_LOGIN, "password": pw}


@router.get("/{db_id}/secrets")
def secrets(env_id: int, db_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    from ..services import sso as ssosvc

    e = _env(env_id, db, user, "secrets")
    r = _row(db, e, db_id)
    return {"login": r.admin_login or ssosvc.ADMIN_LOGIN, "password": r.admin_password or e.admin_password, "db_name": r.db_name}
