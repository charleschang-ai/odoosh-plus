"""远程备份目标(用户自有 S3 / SFTP / WebDAV)+ 实例级备份配置。

  GET    /api/backup-targets?tenant_id=            我的目标(超管:全部,可按组织过滤)
  POST   /api/backup-targets                       新建
  PUT    /api/backup-targets/{id}                  修改(密钥字段留空 / '******' = 不改)
  DELETE /api/backup-targets/{id}                  删除(被实例引用时拒绝,除非 force=1;只删记录,远端文件不动)
  POST   /api/backup-targets/{id}/test             测试连接(写读删一个小文件)
  GET    /api/environments/{id}/backup-config      实例备份配置(远程目标 + 自动备份覆盖)
  PUT    /api/environments/{id}/backup-config
  POST   /api/environments/{id}/backup-config/run-now   按本实例生效策略立即备份一轮
  POST   /api/backups/{bid}/replicas/{target_id}/push   手动(重新)推送到某目标

可见性:目标只有创建者本人与超管可见可改;实例配置里只能选自己的目标(已被他人选中的目标仍会展示为只读)。
"""

import json
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import authz
from .. import schemas_backup as S
from ..auth import get_current_user
from ..db import get_db
from ..models import Environment, Tenant, User
from ..models_backup import Backup, BackupReplica, BackupTarget, EnvironmentBackupConfig
from ..services import backup as backupsvc
from ..services import remote

log = logging.getLogger("odoosh.backup_targets")

router = APIRouter(prefix="/api/backup-targets", tags=["backup-targets"])
env_router = APIRouter(prefix="/api/environments/{env_id}/backup-config", tags=["backup-targets"])
bk_router = APIRouter(prefix="/api/backups/{bid}/replicas", tags=["backup-targets"])


# ---------------------------------------------------------------- helpers
def _visible_q(db: Session, user: User, tenant_id: int | None):
    q = select(BackupTarget).order_by(BackupTarget.id.desc())
    if not authz.is_superadmin(user):
        q = q.where(BackupTarget.owner_user_id == user.id)
    if tenant_id is not None:
        q = q.where(BackupTarget.tenant_id == tenant_id)
    return q


def _get_target(tid: int, db: Session, user: User) -> BackupTarget:
    t = db.get(BackupTarget, tid)
    if not t or (not authz.is_superadmin(user) and t.owner_user_id != user.id):
        raise HTTPException(404, "备份目标不存在或不属于你")
    return t


def _usage_counts(db: Session, ids: list[int]) -> dict[int, int]:
    """各目标被多少实例引用(target_ids 是 JSON 文本,量小,直接在 Python 里数)。"""
    out = {i: 0 for i in ids}
    if not ids:
        return out
    for c in db.scalars(select(EnvironmentBackupConfig)).all():
        for i in remote.env_target_ids(c):
            if i in out:
                out[i] += 1
    return out


def _out(db: Session, t: BackupTarget, users: dict[int, User] | None = None, usage: dict[int, int] | None = None) -> S.BackupTargetOut:
    u = (users or {}).get(t.owner_user_id) or db.get(User, t.owner_user_id)
    return S.BackupTargetOut(
        id=t.id, tenant_id=t.tenant_id, owner_user_id=t.owner_user_id, owner_name=(u.display_name or u.username) if u else None,
        name=t.name, kind=t.kind, config=remote.load_config(t), describe=remote.describe(t), prefix=t.prefix, keep_days=int(t.keep_days or 0),
        delete_with_local=bool(t.delete_with_local), enabled=bool(t.enabled), last_test_ok=t.last_test_ok, last_test_at=t.last_test_at,
        last_error=t.last_error, in_use=(usage or {}).get(t.id, 0), created_at=t.created_at, updated_at=t.updated_at,
    )


def _validate_config(kind: str, c: dict, is_new: bool) -> None:
    need = {"s3": ("bucket", "access_key"), "sftp": ("host", "username"), "webdav": ("url",)}[kind]
    for k in need:
        if not str(c.get(k) or "").strip():
            raise HTTPException(400, f"缺少必填项:{k}")
    if is_new:
        if kind == "s3" and not c.get("secret_key"):
            raise HTTPException(400, "缺少 Secret Key")
        if kind == "sftp" and not (c.get("password") or c.get("private_key")):
            raise HTTPException(400, "SFTP 需要密码或私钥")
    if kind == "webdav" and not str(c.get("url")).lower().startswith(("http://", "https://")):
        raise HTTPException(400, "WebDAV 地址需以 http:// 或 https:// 开头")


# ---------------------------------------------------------------- 目标 CRUD
@router.get("", response_model=list[S.BackupTargetOut])
def list_targets(tenant_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.scalars(_visible_q(db, user, tenant_id)).all()
    users = {u.id: u for u in db.scalars(select(User).where(User.id.in_({r.owner_user_id for r in rows} or {-1}))).all()}
    usage = _usage_counts(db, [r.id for r in rows])
    return [_out(db, r, users, usage) for r in rows]


@router.post("", response_model=S.BackupTargetOut, status_code=201)
def create_target(body: S.BackupTargetIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if body.tenant_id is None:
        raise HTTPException(400, "请指定组织")
    if not authz.is_superadmin(user):
        authz.require_tenant_role(db, user, body.tenant_id, "developer")
    if not db.get(Tenant, body.tenant_id):
        raise HTTPException(404, "组织不存在")
    _validate_config(body.kind, body.config, is_new=True)
    t = BackupTarget(tenant_id=body.tenant_id, owner_user_id=user.id, name=body.name.strip(), kind=body.kind, prefix=(body.prefix or "").strip() or None,
                     keep_days=body.keep_days, delete_with_local=body.delete_with_local, enabled=body.enabled)
    remote.store_config(t, body.config)
    db.add(t)
    db.commit()
    db.refresh(t)
    return _out(db, t)


@router.put("/{tid}", response_model=S.BackupTargetOut)
def update_target(tid: int, body: S.BackupTargetIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    t = _get_target(tid, db, user)
    if body.kind != t.kind:
        raise HTTPException(400, "不能修改目标类型,请新建一个")
    _validate_config(body.kind, body.config, is_new=False)
    t.name = body.name.strip()
    t.prefix = (body.prefix or "").strip() or None
    t.keep_days = body.keep_days
    t.delete_with_local = body.delete_with_local
    t.enabled = body.enabled
    remote.store_config(t, body.config)
    t.last_test_ok = None  # 改过配置,测试结果作废
    db.commit()
    db.refresh(t)
    return _out(db, t, usage=_usage_counts(db, [t.id]))


@router.delete("/{tid}")
def delete_target(tid: int, force: bool = False, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    t = _get_target(tid, db, user)
    n = _usage_counts(db, [t.id]).get(t.id, 0)
    if n and not force:
        raise HTTPException(409, f"该目标正被 {n} 个实例使用,请先在实例备份设置里取消,或强制删除")
    if n:  # 强制删除:从各实例配置里摘掉
        for c in db.scalars(select(EnvironmentBackupConfig)).all():
            ids = remote.env_target_ids(c)
            if t.id in ids:
                c.target_ids = json.dumps([i for i in ids if i != t.id])
    db.delete(t)  # backup_replicas 级联删除;远端文件不动
    db.commit()
    return {"ok": True, "detached": n}


@router.post("/{tid}/test")
def test_target(tid: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    t = _get_target(tid, db, user)
    r = remote.test_target(t)
    t.last_test_ok = bool(r["ok"])
    t.last_test_at = datetime.now(timezone.utc)
    t.last_error = None if r["ok"] else r.get("error")
    db.commit()
    return r


@router.post("/test")
def test_unsaved(body: S.BackupTargetIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """新建对话框里「测试连接」(尚未保存):用提交的参数直接测。"""
    if body.tenant_id is None:
        raise HTTPException(400, "请指定组织")
    if not authz.is_superadmin(user):
        authz.require_tenant_role(db, user, body.tenant_id, "developer")  # 否则任意登录用户可拿它当内网扫描器
    _validate_config(body.kind, body.config, is_new=True)
    tmp = BackupTarget(tenant_id=body.tenant_id or 0, owner_user_id=user.id, name=body.name or "tmp", kind=body.kind, prefix=body.prefix)
    remote.store_config(tmp, body.config)
    return remote.test_target(tmp)


# ---------------------------------------------------------------- 实例备份配置
def _env(env_id: int, db: Session, user: User, action: str) -> Environment:
    e = db.get(Environment, env_id)
    if not e or e.deleted_at is not None:
        raise HTTPException(404, "实例不存在")
    authz.check_env(db, user, e, action)
    return e


def _cfg_out(db: Session, e: Environment, c: EnvironmentBackupConfig, user: User) -> S.EnvBackupConfigOut:
    ids = remote.env_target_ids(c)
    mine = db.scalars(_visible_q(db, user, e.tenant_id)).all()
    mine_ids = {t.id for t in mine}
    others = db.scalars(select(BackupTarget).where(BackupTarget.id.in_([i for i in ids if i not in mine_ids] or [-1]))).all()
    opts = [{"id": t.id, "name": t.name, "kind": t.kind, "describe": remote.describe(t), "enabled": bool(t.enabled), "mine": t.id in mine_ids,
             "last_test_ok": t.last_test_ok} for t in list(mine) + list(others)]
    t = db.get(Tenant, e.tenant_id)
    teff = backupsvc.effective_policy(backupsvc.get_policy(db, e.tenant_id))
    eff = backupsvc.env_effective_policy(c, teff)
    if eff["source"] == "tenant" and e.kind not in eff["auto_kinds"]:
        eff = dict(eff, auto_enabled=False)
    return S.EnvBackupConfigOut(
        environment_id=e.id, target_ids=ids, targets=opts, auto_mode=c.auto_mode, auto_hour=int(c.auto_hour or 0),
        include_filestore=bool(c.include_filestore), include_extra_dbs=bool(c.include_extra_dbs), keep_days=int(c.keep_days or 0),
        tenant_effective=teff, effective=eff, next_run=backupsvc.next_run_str(eff, c.last_run_at if eff["source"] == "env" else (backupsvc.get_policy(db, e.tenant_id).last_run_at if t else None)),
        last_run_at=c.last_run_at, updated_by=c.updated_by, updated_at=c.updated_at,
    )


@env_router.get("", response_model=S.EnvBackupConfigOut)
def get_env_config(env_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    e = _env(env_id, db, user, "backup")
    c = remote.env_config(db, e.id, create=True)
    return _cfg_out(db, e, c, user)


@env_router.put("", response_model=S.EnvBackupConfigOut)
def put_env_config(env_id: int, body: S.EnvBackupConfigIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    e = _env(env_id, db, user, "edit")
    c = remote.env_config(db, e.id, create=True)
    old_ids = remote.env_target_ids(c)
    mine = {t.id for t in db.scalars(_visible_q(db, user, e.tenant_id)).all()}
    new_ids = []
    for i in body.target_ids:
        if i in mine or i in old_ids:  # 只能加自己的;别人加的已有项可保留
            if i not in new_ids:
                new_ids.append(i)
        else:
            raise HTTPException(403, f"目标 #{i} 不属于你")
    c.target_ids = json.dumps(new_ids)
    c.auto_mode = body.auto_mode
    c.auto_hour = body.auto_hour
    c.include_filestore = body.include_filestore
    c.include_extra_dbs = body.include_extra_dbs
    c.keep_days = body.keep_days
    c.updated_by = user.username
    db.commit()
    db.refresh(c)
    return _cfg_out(db, e, c, user)


@env_router.post("/run-now")
def run_now_env(env_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    e = _env(env_id, db, user, "backup")
    n = backupsvc.run_auto_backups(env_id=e.id, who=user.username)
    return {"started": n}


# ---------------------------------------------------------------- 副本重推
@bk_router.post("/{target_id}/push")
def push_replica(bid: int, target_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    b = db.get(Backup, bid)
    if not b:
        raise HTTPException(404, "备份不存在")
    env = db.get(Environment, b.environment_id) if b.environment_id else None
    if not authz.can_see_env_data(db, user, env, b.tenant_id, minimum="developer"):
        raise HTTPException(403, "无权访问该备份")
    if b.status != "done":
        raise HTTPException(400, "备份尚未完成")
    t = _get_target(target_id, db, user)
    r = db.scalar(select(BackupReplica).where(BackupReplica.backup_id == b.id, BackupReplica.target_id == t.id))
    if r is None:
        r = BackupReplica(backup_id=b.id, target_id=t.id, status="pending", remote_key=remote.remote_key(t, b))
        db.add(r)
        db.commit()
        db.refresh(r)
    else:
        r.status, r.attempts, r.error = "pending", 0, None
        db.commit()
    remote.push_async(r.id)
    return {"ok": True, "replica_id": r.id}
