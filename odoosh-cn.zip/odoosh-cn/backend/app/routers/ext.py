"""第三方接入(公开路由,凭接入令牌)。完整规范见 docs/work-2026-09-04-odoo-integration-design.md。

连通性探测(任意有效令牌,不要求 scope)
    GET  /api/ext/ping               回显令牌的来源、绑定组织、权限范围与上限;接入方「测试连接」用,无副作用

身份同步(scope: users:write)
    POST /api/ext/users              按 (来源, external_id) 幂等建 / 改用户,可选一并开通实例
    POST /api/ext/users/deactivate   停用账号(保留数据),可选同时停机
    POST /api/ext/users/delete       彻底删除账号(需令牌开启「允许删除用户」);实例先进回收站
    POST /api/ext/users/reconcile    全量对账:名单外的账号停用(有误停保护)

实例(scope: envs:read / envs:write)
    GET  /api/ext/envs?uid=...       查该用户的实例(供接入方渲染自己的看板)
    POST /api/ext/envs               为该用户开通实例

免登入口(scope: handoff)
    POST /api/ext/handoff            {"uid": ..., "target": "console"|"odoo", "env": ...} → {"url": ...}
        接入方服务器调用后把用户浏览器 302 到 url 即可。令牌只能在服务端用,绝不能放进网页链接。
    POST /api/ext/exchange           前端 /auth/callback 用一次性 code 换平台登录令牌
    GET  /api/ext/open?t=...         target=odoo 的落地页:唤醒实例并进入已登录的 Odoo

错误响应统一为 {"detail": "<人话>", "code": "<稳定错误码>"};接入方的重试队列按 code 与 HTTP 状态判断:
4xx 是调用方的问题不必重试,429 / 5xx 值得退避重试。
"""

import html
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..db import get_db
from ..models_token import ApiToken
from ..services import apitokens as svc
from ..services import extsync
from ..services import sleep as sleepsvc
from ..services import sso as ssosvc

log = logging.getLogger("odoosh.ext")

router = APIRouter(prefix="/api/ext", tags=["ext"])


# ---------------------------------------------------------------- 请求模型
class EnvSpec(BaseModel):
    """实例规格:全部由接入方决定,平台只校验是否超出令牌上限与平台配额。"""

    tenant: str | None = Field(default=None, max_length=64)  # 组织 id 或 slug;省略 = 令牌绑定组织
    name: str | None = Field(default=None, max_length=64)   # 省略则用用户名
    kind: str = Field(default="dev", pattern="^(dev|staging)$")  # 接入令牌不能开生产实例
    odoo_version: str | None = Field(default=None, max_length=8)
    edition: str = Field(default="community", pattern="^(community|enterprise)$")
    lang: str | None = Field(default="zh_CN", max_length=16)
    mem_mb: int | None = Field(default=None, ge=256, le=65536)
    cpus: float | None = Field(default=None, gt=0, le=64)
    sleep_idle_hours: float | None = Field(default=None, ge=0)  # 0 = 不休眠
    expire_days: int | None = Field(default=None, ge=0)         # 0 = 永不过期


class UserQuota(BaseModel):
    max_envs: int | None = Field(default=None, ge=0)  # None = 不限
    max_dbs: int | None = Field(default=None, ge=0)


class UserMenus(BaseModel):
    dashboard: bool | None = None
    repos: bool | None = None
    ai: bool | None = None
    backups: bool | None = None
    # 实例详情页 Tab(默认关):建号时没传就是关;更新时没传保持原值 —— 平台里手动打开的不会被之后的同步关回去
    settings: bool | None = None
    upgrade: bool | None = None
    databases: bool | None = None


class UserUpsertIn(BaseModel):
    """用户属性全集。未传的可选字段保持原值不变,接入方可以只传变化的部分。"""

    external_id: str = Field(min_length=1, max_length=128)   # 接入方的稳定主键
    username: str = Field(min_length=2, max_length=64)       # 平台用户名,由接入方决定
    display_name: str | None = Field(default=None, max_length=128)
    # 平台角色:member = 普通用户;admin = 平台管理员(能看所有组织),须令牌 allow_admin_role
    role: str = Field(default="member", pattern="^(member|admin)$")
    # 组织:id 或 slug。省略 = 令牌绑定组织;指定别的组织须令牌 allow_any_tenant
    tenant: str | None = Field(default=None, max_length=64)
    # 组织内角色:测试者 / 开发者(默认)/ 组织管理员,不得超过令牌 max_grant_role
    tenant_role: str = Field(default="developer", pattern="^(tester|developer|owner)$")
    active: bool = True
    shell_enabled: bool | None = None        # Web Shell 开关
    can_use_enterprise: bool | None = None   # 企业版实例开关
    quota: UserQuota | None = None           # 实例与附加数据库配额
    menus: UserMenus | None = None           # 菜单可见性
    provision: EnvSpec | None = None         # 传了且该用户尚无实例时,一并排队开通


class DeactivateIn(BaseModel):
    external_id: str = Field(min_length=1, max_length=128)
    stop_envs: bool = True  # 是否同时停机(实例与数据一律保留)


class DeleteIn(BaseModel):
    external_id: str = Field(min_length=1, max_length=128)
    purge_envs: bool = False  # False = 实例进回收站(可恢复);True = 连同数据立即销毁


class ReconcileIn(BaseModel):
    external_ids: list[str] = Field(default_factory=list, max_length=100000)
    stop_envs: bool = True
    confirm: bool = False  # 名单为空 / 停用比例过高时必须显式确认


class EnvCreateIn(EnvSpec):
    uid: str = Field(min_length=1, max_length=128)  # external_id 或平台用户名


class HandoffIn(BaseModel):
    uid: str = Field(min_length=1, max_length=128)  # external_id 或平台用户名
    target: str = Field(default="console", pattern="^(console|odoo)$")  # console = 控制台;odoo = 直接进实例的 Odoo
    env: str | None = Field(default=None, max_length=64)  # 可选:指定实例名(console 下落到该实例详情页)
    # 控制台左侧菜单(仅 target=console):false=本次隐藏(嵌入 iframe 时用),true=本次显示,
    # 不传=用令牌上的「免登默认隐藏左侧菜单」开关。纯展示层设置,只作用于本次打开的标签页
    menu: bool | None = None


class ExchangeIn(BaseModel):
    code: str = Field(min_length=1, max_length=2048)


_bearer_scheme = HTTPBearer(auto_error=False, scheme_name="接入令牌",
                            description="超级管理员在右上角用户菜单「接入令牌」里创建;请求头 Authorization: Bearer <令牌>")


def _bearer(cred: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme)) -> str:
    if not cred or cred.scheme.lower() != "bearer" or not cred.credentials.strip():
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "缺少接入令牌(Authorization: Bearer <token>)")
    return cred.credentials.strip()


def _client_ip(request: Request) -> str | None:
    fwd = (request.headers.get("x-forwarded-for") or "").split(",")[0].strip()
    return fwd or (request.client.host if request.client else None)


class ApiError(HTTPException):
    """带稳定错误码的错误响应:{"detail": "...", "code": "..."}。"""

    def __init__(self, status_code: int, code: str, detail: str):
        super().__init__(status_code, detail)
        self.code = code


def _auth(request: Request, db: Session, token: str, scope: str) -> ApiToken:
    """校验令牌 + 权限范围,并记录本次使用。所有写接口的统一入口。"""
    try:
        tok = svc.lookup(db, token)
    except ValueError as ex:
        raise ApiError(status.HTTP_401_UNAUTHORIZED, "token_invalid", str(ex))
    try:
        svc.check_scope(tok, scope)
    except PermissionError as ex:
        raise ApiError(status.HTTP_403_FORBIDDEN, "scope_denied", str(ex))
    tok.last_used_at = datetime.now(timezone.utc)
    tok.last_used_ip = _client_ip(request)
    return tok


def _sync_error(ex: extsync.SyncError) -> ApiError:
    return ApiError(ex.status, ex.code, ex.message)


def _resolve(db: Session, tok: ApiToken, uid: str, need_env: bool = False, env_name: str | None = None):
    """uid → (用户, 实例或 None)。把服务层的异常翻成带错误码的响应。"""
    try:
        user = svc.resolve_user(db, tok, uid)
        env = svc.resolve_env(db, tok, user, env_name) if (need_env or env_name) else None
        return user, env
    except LookupError as ex:
        raise ApiError(status.HTTP_404_NOT_FOUND, "not_found", str(ex))
    except PermissionError as ex:
        raise ApiError(status.HTTP_403_FORBIDDEN, "not_in_tenant", str(ex))
    except ValueError as ex:
        raise ApiError(status.HTTP_400_BAD_REQUEST, "invalid_request", str(ex))


# ---------------------------------------------------------------- 连通性探测
@router.get("/ping")
def ping(request: Request, token: str = Depends(_bearer), db: Session = Depends(get_db)):
    """接入方「测试连接」用:只验证令牌有效,不要求任何 scope,不依赖任何已同步的用户,无副作用。

    回显令牌的来源、绑定组织、权限范围与上限,接入方据此在设置页提示「缺少同步用户权限」之类的问题。"""
    from ..config import settings as cfg
    from ..models import Tenant

    try:
        tok = svc.lookup(db, token)
    except ValueError as ex:
        raise ApiError(status.HTTP_401_UNAUTHORIZED, "token_invalid", str(ex))
    tenant = db.get(Tenant, tok.tenant_id)
    tok.last_used_at = datetime.now(timezone.utc)
    tok.last_used_ip = _client_ip(request)
    db.commit()
    return {
        "ok": True,
        "token_name": tok.name,
        "source": tok.source,
        "tenant_id": tok.tenant_id,
        "tenant_slug": tenant.slug if tenant else None,
        "tenant_name": tenant.name if tenant else None,
        "scopes": sorted(svc.scopes_of(tok)),
        "limits": {
            "max_grant_role": tok.max_grant_role,
            "max_envs_per_user": tok.max_envs_per_user,
            "allow_create_user": tok.allow_create_user,
            "allow_admin_role": tok.allow_admin_role,
            "allow_any_tenant": tok.allow_any_tenant,
            "allow_delete_user": tok.allow_delete_user,
        },
        "expires_at": tok.expires_at.isoformat() if tok.expires_at else None,
        "server_time": datetime.now(timezone.utc).isoformat(),
        "version": cfg.version,
    }


# ---------------------------------------------------------------- 身份同步
@router.post("/users")
def upsert_user(body: UserUpsertIn, request: Request, token: str = Depends(_bearer), db: Session = Depends(get_db)):
    """按 (来源, external_id) 幂等创建或更新用户。重复调用不会建出第二个账号。

    平台角色、组织、组织内角色、配额、菜单、Shell 与企业版开关、实例规格全部由接入方决定,
    平台只校验不超出令牌上限(见 ApiToken:最高可授予角色、每人实例数、能否建号、能否设超管、能否跨组织)。
    密码随机生成且不返回 —— 同步来的账号只能走免登入口。"""
    tok = _auth(request, db, token, "users:write")
    data = body.model_dump(exclude_none=False)
    for k in ("quota", "menus", "provision"):  # 子模型转普通字典,未传的键不参与覆盖
        v = getattr(body, k)
        data[k] = v.model_dump(exclude_none=True) if v is not None else None
    try:
        out = extsync.upsert_user(db, tok, data)
    except extsync.SyncError as ex:
        db.rollback()
        raise _sync_error(ex)
    db.commit()
    log.info("ext users.upsert token#%s external=%s → user#%s created=%s", tok.id, body.external_id,
             out["user_id"], out["created"])
    return out


@router.post("/users/deactivate")
def deactivate_user(body: DeactivateIn, request: Request, token: str = Depends(_bearer), db: Session = Depends(get_db)):
    """停用账号并使其已签发的登录令牌失效。永不删除用户、实例或代码。"""
    tok = _auth(request, db, token, "users:write")
    try:
        out = extsync.deactivate_user(db, tok, body.external_id, body.stop_envs)
    except extsync.SyncError as ex:
        db.rollback()
        raise _sync_error(ex)
    db.commit()
    return out


@router.post("/users/delete")
def delete_user(body: DeleteIn, request: Request, token: str = Depends(_bearer), db: Session = Depends(get_db)):
    """彻底删除账号,不可恢复。需要令牌开启「允许删除用户」。

    该用户的实例默认进回收站(数据保留、可恢复);purge_envs=true 才连同数据立即销毁。
    平台管理员账号一律拒绝删除。"""
    tok = _auth(request, db, token, "users:write")
    try:
        out = extsync.delete_user(db, tok, body.external_id, body.purge_envs)
    except extsync.SyncError as ex:
        db.rollback()
        raise _sync_error(ex)
    db.commit()
    log.info("ext users.delete token#%s external=%s", tok.id, body.external_id)
    return out


@router.post("/users/reconcile")
def reconcile_users(body: ReconcileIn, request: Request, token: str = Depends(_bearer), db: Session = Depends(get_db)):
    """全量对账:传当前有效名单,平台把该来源下不在名单里的账号停用。

    名单为空、或将停用的比例超过 30% 时拒绝并要求 confirm=true —— 接入方一次查询失败
    就把整个组织停掉的事故必须挡在这里。"""
    tok = _auth(request, db, token, "users:write")
    try:
        out = extsync.reconcile(db, tok, body.external_ids, body.stop_envs, body.confirm)
    except extsync.SyncError as ex:
        db.rollback()
        raise _sync_error(ex)
    db.commit()
    return out


# ---------------------------------------------------------------- 实例
@router.get("/envs")
def list_envs(uid: str, request: Request, token: str = Depends(_bearer), db: Session = Depends(get_db)):
    """查询该用户在令牌组织下拥有的实例,供接入方渲染自己的看板。"""
    tok = _auth(request, db, token, "envs:read")
    user, _ = _resolve(db, tok, uid)
    envs = extsync.list_envs(db, tok, user)
    db.commit()
    return {"user_id": user.id, "username": user.username, "envs": envs}


@router.post("/envs", status_code=201)
def create_env(body: EnvCreateIn, request: Request, token: str = Depends(_bearer), db: Session = Depends(get_db)):
    """为指定用户开通一个实例(异步创建并启动)。已有同名实例时直接返回,不重复创建。"""
    tok = _auth(request, db, token, "envs:write")
    user, _ = _resolve(db, tok, body.uid)
    spec = body.model_dump(exclude={"uid"}, exclude_none=True)
    try:
        env, created = extsync.ensure_env(db, tok, user, spec)
    except extsync.SyncError as ex:
        db.rollback()
        raise _sync_error(ex)
    db.commit()
    return {"env_id": env.id, "name": env.name, "status": env.status, "url": env.url,
            "created": created, "user_id": user.id}


@router.post("/handoff")
def handoff(body: HandoffIn, request: Request, token: str = Depends(_bearer), db: Session = Depends(get_db)):
    from .repos import _base_url

    tok = _auth(request, db, token, "handoff")
    # console 不要求有实例(落在列表页);指定了 env 或 target=odoo 才需要找实例
    user, env = _resolve(db, tok, body.uid, need_env=(body.target == "odoo"), env_name=body.env)
    db.commit()
    base = _base_url(request)
    if body.target == "odoo":
        url, ttl = f"{base}/api/ext/open?t={svc.make_open_ticket(tok, user, env)}", svc.OPEN_TTL
    else:
        url, ttl = f"{base}/auth/callback?code={svc.make_login_code(tok, user)}", svc.CODE_TTL
        if env:
            url += f"&next=/environments/{env.id}"
        # 左侧菜单:请求参数 > 令牌默认。前端把它记在本标签页(sessionStorage),不影响该用户正常登录
        if body.menu is False or (body.menu is None and tok.hide_nav):
            url += "&menu=0"
    log.info("ext handoff token#%s uid=%s target=%s env#%s ip=%s", tok.id, body.uid, body.target, env.id if env else None, tok.last_used_ip)
    return {"url": url, "expires_in": ttl, "target": body.target, "user_id": user.id, "tenant_id": tok.tenant_id,
            "env_id": env.id if env else None, "env_name": env.name if env else None, "status": env.status if env else None}


@router.post("/exchange")
def exchange(body: ExchangeIn, db: Session = Depends(get_db)):
    """前端 /auth/callback:一次性 code → 平台登录令牌(与密码登录得到的完全相同)。
    失败用 400 而非 401:前端拦截器遇 401 会直接跳登录页,这里要把原因显示出来。"""
    from ..auth import create_token

    try:
        tok, user = svc.redeem_login_code(db, body.code)
    except ValueError as ex:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(ex))
    log.info("ext exchange token#%s user#%s", tok.id, user.id)
    return {"access_token": create_token(user), "token_type": "bearer", "tenant_id": tok.tenant_id}


_PAGE = """<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">{refresh}
<title>{title}</title></head>
<body style="font-family:-apple-system,Segoe UI,PingFang SC,Microsoft YaHei,sans-serif;padding:48px;color:#0f172a;background:#f8fafc">
<div style="max-width:560px;margin:10vh auto;background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:32px 36px;box-shadow:0 1px 3px rgba(0,0,0,.05)">
<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
<div style="width:14px;height:14px;border-radius:50%;background:{color};box-shadow:0 0 0 4px {color}33"></div>
<h2 style="margin:0;font-size:20px">{title}</h2></div>
<p style="color:#475569;line-height:1.7;margin:0 0 8px">{body}</p>
<p style="color:#94a3b8;font-size:12px;margin:0">{foot}</p>
</div></body></html>"""


def _page(code: int, title: str, body: str, color: str, refresh: int | None, env_label: str = "") -> HTMLResponse:
    meta = f'<meta http-equiv="refresh" content="{refresh}">' if refresh else ""
    foot = (f"实例 {html.escape(env_label)} · 页面每 {refresh} 秒自动刷新,就绪后将直接进入 Odoo。" if refresh and env_label
            else "请返回课程系统重新进入。")
    return HTMLResponse(_PAGE.format(refresh=meta, title=html.escape(title), body=html.escape(body), color=color, foot=foot),
                        status_code=code, headers={"Cache-Control": "no-store"})


@router.get("/open")
def open_instance(t: str, db: Session = Depends(get_db)):
    from ..services import databases as dbsvc

    try:
        tok, user, env = svc.read_open_ticket(db, t)
    except ValueError as ex:
        return _page(400, "无法进入实例", str(ex), "#ef4444", None)
    label = f"{env.tenant.slug}/{env.name}" if env.tenant else env.name
    st = env.status
    if st == "running" and env.url:
        try:
            url = ssosvc.sso_url(dbsvc.view(db, env, None), ssosvc.make_ticket(env.id, user))
        except Exception as ex:  # noqa: BLE001
            log.warning("ext open env#%s 签发 SSO 失败: %s", env.id, ex)
            return _page(500, "无法进入实例", str(ex), "#ef4444", None)
        log.info("ext open token#%s user#%s env#%s", tok.id, user.id, env.id)
        return RedirectResponse(url, status_code=302, headers={"Cache-Control": "no-store"})
    if st == "sleeping":
        sleepsvc.request_wake(env, db, f"接入免登({user.username})")
        st = "waking"
    if st == "waking":
        return _page(503, "实例正在唤醒…", "你的实例因闲置已休眠,正在为你启动(通常需要 10~30 秒),请稍候。", "#f59e0b", 4, label)
    if st in ("starting", "restarting", "deploying", "provisioning", "cloning", "restoring", "running"):
        return _page(503, "实例正在启动…", f"实例当前状态:{st}({env.status_message or ''}),完成后自动进入。", "#3b82f6", 5, label)
    return _page(503, "实例未就绪", f"实例已停止或尚未创建成功(状态:{st})。请联系老师在 OdooshCN 控制台启动后再试。",
                 "#ef4444", 30, label)
