import os

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..auth import require_admin
from ..db import get_db
from ..services import images, joblog, offline_images
from ..services import jobs

router = APIRouter(prefix="/api/images", tags=["images"], dependencies=[Depends(require_admin)])


def supported_versions(db: Session) -> list[str]:
    """可用版本来自系统设置 odoo.versions(最新在前),不再写死。"""
    from .settings import get_setting

    raw = get_setting(db, "odoo.versions") or "19,18,17,16,15,14,13,12"
    return [v.strip() for v in raw.split(",") if v.strip()]


def _job_states(versions: list[str]) -> dict:
    """{job_id: {running, done, ok}}:前端据此显示「进行中 / 失败 → 重试」。"""
    out = {}
    for v in versions:
        for jid in (f"pull-{v}", images.job_id(v)):
            j = joblog.get(jid)
            if j:
                out[jid] = {"running": not j["done"], "done": j["done"], "ok": j["ok"]}
    return out


@router.get("/base")
def list_base(db: Session = Depends(get_db)):
    vs = supported_versions(db)
    return {"supported": vs, "items": images.list_base_images(), "jobs": _job_states(vs)}


@router.post("/official/{version}/pull")
def pull_official(version: str, bg: BackgroundTasks, db: Session = Depends(get_db)):
    """拉取/更新官方镜像 odoo:<版本>(失败后再次点击即重试)。"""
    if version not in supported_versions(db):
        raise HTTPException(400, f"不支持的版本 {version}(请先在系统设置「可用版本」中加入)")
    jid = f"pull-{version}"
    if joblog.running(jid):
        raise HTTPException(409, "正在拉取中")
    bg.add_task(jobs.spawn, images.pull_official, version)
    return {"job": jid}


@router.post("/base/{version}/build")
def build_base(version: str, bg: BackgroundTasks, db: Session = Depends(get_db)):
    """从源码构建自建镜像 odoosh-base:<版本>(失败后再次点击即重试)。"""
    if version not in supported_versions(db):
        raise HTTPException(400, f"不支持的版本 {version}(请先在系统设置「可用版本」中加入)")
    jid = images.job_id(version)
    if joblog.running(jid):
        raise HTTPException(409, "该版本正在构建中")
    bg.add_task(jobs.spawn, images.build_base_image, version)
    return {"job": jid}


@router.get("/jobs/{job_id}/log")
def job_log(job_id: str, offset: int = 0):
    job = joblog.get(job_id)
    if not job:
        return {"exists": False, "lines": [], "done": True, "ok": None, "offset": 0}
    lines = job["lines"][offset:]
    return {"exists": True, "lines": lines, "done": job["done"], "ok": job["ok"], "offset": offset + len(lines)}


# 兼容旧路径
@router.get("/base/{version}/log")
def build_log(version: str, offset: int = 0):
    return job_log(images.job_id(version), offset)


# ---------------------------------------------------------------- 离线镜像包(内网/断网:预下载 tar → docker load)
class OfflineImportIn(BaseModel):
    name: str


@router.get("/offline")
def list_offline():
    """扫描离线镜像目录:返回宿主机拷贝路径 + 各 tar 包的镜像 tag / 体积 / 是否已导入。"""
    files = offline_images.scan()
    jobs_state = {}
    for f in files:
        j = joblog.get(offline_images.job_id(f["name"]))
        if j:
            jobs_state[f["name"]] = {"running": not j["done"], "done": j["done"], "ok": j["ok"]}
    return {"host_dir": offline_images.host_images_dir(), "files": files, "jobs": jobs_state}


@router.post("/offline/import")
def import_offline(body: OfflineImportIn, bg: BackgroundTasks):
    """导入指定离线镜像包(docker load,后台执行;失败再次点击即重试)。"""
    jid = offline_images.job_id(body.name)
    if joblog.running(jid):
        raise HTTPException(409, "该镜像包正在导入中")
    bg.add_task(jobs.spawn, offline_images.import_tar, body.name)
    return {"job": jid}


@router.put("/offline/upload")
async def upload_offline(request: Request, filename: str):
    """网页上传镜像包:请求体就是 tar 本身,按块直接写进离线目录(与「直接拷进目录」殊途同归,进来后共用同一份扫描/导入)。
    大包(GB 级)建议仍用 scp / U 盘拷贝更稳;此入口方便小包与无 shell 权限的管理员。"""
    try:
        final, part = offline_images.upload_dest(filename)
    except ValueError as e:
        raise HTTPException(400, str(e))
    # 镜像包动辄几 GB,且导入时 docker load 还要再吃一份空间:先按 Content-Length 预检,别把数据盘写满
    try:
        declared = int(request.headers.get("content-length") or 0)
    except ValueError:
        declared = 0
    if declared:
        from ..services.backup import check_free_space

        try:
            check_free_space(os.path.dirname(part), declared * 2 + (512 << 20), "离线镜像目录")
        except RuntimeError as e:
            raise HTTPException(413, str(e))
    total = 0
    try:
        with open(part, "wb") as f:
            async for chunk in request.stream():
                if chunk:
                    total += len(chunk)
                    f.write(chunk)
        if total == 0:
            raise ValueError("空文件")
        os.replace(part, final)  # 原子替换成最终名,扫描才会看到
    except Exception as e:  # noqa: BLE001
        try:
            os.remove(part)
        except OSError:
            pass
        raise HTTPException(400, f"上传失败:{e}")
    return {"name": os.path.basename(final), "size": total}


@router.delete("/offline/{name}")
def delete_offline(name: str):
    """删除离线镜像包文件(通常导入成功后清理,释放磁盘)。"""
    try:
        ok = offline_images.delete_tar(name)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not ok:
        raise HTTPException(404, "文件不存在")
    return {"deleted": True}
