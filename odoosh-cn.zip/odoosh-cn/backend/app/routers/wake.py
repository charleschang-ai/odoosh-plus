"""实例休眠/唤醒接口。

- GET  /api/wake/{tenant_slug}/{env_name}(公开;由实例域名 nginx 的 @down 反代到此):
  上游不可达时的落地页——若实例在休眠则触发唤醒并返回「唤醒中」自动刷新页;否则返回「实例未就绪」页。
- POST /api/environments/{id}/wake(需登录 + start 权限):控制台按钮。
- POST /api/environments/{id}/sleep(需登录 + stop 权限):手动休眠(仅开发实例)。
"""

import logging

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import authz
from ..auth import get_current_user
from ..db import get_db
from ..models import Environment, Tenant, User
from ..services import orchestrator, sleep as sleepsvc
from ..services import jobs

log = logging.getLogger("odoosh.wake")

router = APIRouter(prefix="/api", tags=["wake"])


def _page(status_code: int, title: str, body: str, tenant: str, env: str, color: str, refresh: int) -> HTMLResponse:
    html = sleepsvc.WAKE_PAGE.format(title=title, body=body, tenant=tenant, env=env, color=color, refresh=refresh)
    return HTMLResponse(html, status_code=status_code, headers={"Cache-Control": "no-store"})


@router.get("/wake/{tenant_slug}/{env_name}", response_class=HTMLResponse)
def wake_landing(tenant_slug: str, env_name: str, db: Session = Depends(get_db)):
    row = db.execute(
        select(Environment, Tenant).join(Tenant, Tenant.id == Environment.tenant_id)
        .where(Tenant.slug == tenant_slug, Environment.name == env_name, Environment.deleted_at.is_(None))
        .order_by(Environment.id.desc())  # 同名实例删除重建后回收站有重名记录:取最新的在册实例
    ).first()
    if not row:
        return _page(404, "实例不存在", "找不到对应的实例,请检查地址。", tenant_slug, env_name, "#94a3b8", 30)
    e, t = row
    st = e.status
    if st == "sleeping":
        sleepsvc.request_wake(e, db, "访问触发")
        st = "waking"
    if st == "waking":
        return _page(503, "实例正在唤醒…", "该开发实例因闲置已休眠,正在为你启动(通常需要 10~30 秒),请稍候。",
                     tenant_slug, env_name, "#f59e0b", 4)
    if st in ("starting", "restarting", "deploying", "provisioning", "cloning", "restoring"):
        return _page(503, "实例正在启动 / 部署…", f"实例当前状态:{st}({e.status_message or ''}),完成后自动进入。",
                     tenant_slug, env_name, "#3b82f6", 5)
    if st == "running":
        return _page(503, "实例暂时无响应", "实例容器在运行但 Odoo 尚未响应(可能刚重启)。稍后自动重试。",
                     tenant_slug, env_name, "#3b82f6", 5)
    return _page(503, "实例未就绪", f"实例已停止或创建失败(状态:{st})。请在 OdooshCN 控制台启动后刷新。",
                 tenant_slug, env_name, "#ef4444", 30)


@router.post("/environments/{env_id}/wake")
def wake_env(env_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    env = db.get(Environment, env_id)
    if not env:
        raise HTTPException(404, "环境不存在")
    authz.check_env(db, user, env, "open")  # 能打开就能唤醒(odoo.sh 语义:访问即唤醒)
    if env.status == "waking":
        return {"ok": True, "status": "waking"}
    if env.status != "sleeping":
        raise HTTPException(409, f"实例当前不在休眠状态({env.status})")
    sleepsvc.request_wake(env, db, user.username)
    return {"ok": True, "status": "waking"}


@router.post("/environments/{env_id}/sleep")
def sleep_env(env_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    env = db.get(Environment, env_id)
    if not env:
        raise HTTPException(404, "环境不存在")
    authz.check_env(db, user, env, "stop")
    if env.kind != "dev":
        raise HTTPException(400, "只有开发实例支持休眠")
    if env.status != "running":
        raise HTTPException(409, f"实例当前不在运行状态({env.status})")
    bg.add_task(jobs.spawn, sleepsvc.put_to_sleep, env_id, f"{user.username} 手动")
    return {"ok": True}
