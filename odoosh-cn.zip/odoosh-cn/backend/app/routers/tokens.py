"""接入令牌管理(仅超级管理员):列表 / 身份确认 / 创建 / 吊销。

创建分两步:先 POST /verify-identity 输当前密码拿身份确认凭据(5 分钟),再 POST 创建时带上它。
明文令牌只在创建响应里回显一次。免登接口本身在 routers/ext.py。
"""

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import require_admin, verify_password
from ..db import get_db
from ..models import Tenant, User
from ..models_token import SCOPES, ApiToken
from ..schemas import ORM
from ..services import apitokens as svc

router = APIRouter(prefix="/api/tokens", tags=["tokens"], dependencies=[Depends(require_admin)])


class TokenOut(ORM):
    id: int
    name: str
    prefix: str
    tenant_id: int
    tenant_name: str = ""
    created_by: str = ""
    scopes: str = "handoff"
    source: str = "external"
    max_grant_role: str = "developer"
    max_envs_per_user: int = 1
    allow_create_user: bool = True
    allow_admin_role: bool = False
    allow_any_tenant: bool = False
    allow_delete_user: bool = False
    hide_nav: bool = False
    expires_at: datetime | None = None
    last_used_at: datetime | None = None
    last_used_ip: str | None = None
    revoked_at: datetime | None = None
    created_at: datetime | None = None
    status: str = "active"  # active | expired | revoked


class TokenCreatedOut(TokenOut):
    token: str  # 明文,仅此一次


class VerifyIn(BaseModel):
    password: str


class VerifyOut(BaseModel):
    grant: str
    expires_in: int = svc.IDENTITY_TTL


class TokenCreateIn(BaseModel):
    grant: str
    name: str = Field(min_length=1, max_length=64)
    tenant_id: int
    expires_days: int = Field(ge=1, le=svc.MAX_DAYS)
    # 权限范围:决定能调哪些 /api/ext/* 接口
    scopes: list[str] = Field(default_factory=lambda: ["handoff"])
    # 来源标识:同步进来的用户记在 users.external_source,用于区分多个接入系统
    source: str = Field(default="external", min_length=1, max_length=64, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")
    # 安全上限:调用方无法在请求里覆盖
    max_grant_role: str = Field(default="developer", pattern="^(tester|developer|owner)$")
    max_envs_per_user: int = Field(default=1, ge=0, le=50)
    allow_create_user: bool = True
    allow_admin_role: bool = False   # 允许把用户设为平台管理员(默认关,后果最重)
    allow_any_tenant: bool = False   # 允许请求里指定别的组织(默认关,只能落在绑定组织)
    allow_delete_user: bool = False  # 允许删除用户(默认关,不可恢复)
    hide_nav: bool = False           # 免登进入控制台时默认隐藏左侧菜单(handoff 的 menu 参数可按次覆盖)

    @field_validator("scopes")
    @classmethod
    def _v_scopes(cls, v):
        bad = [s for s in v if s not in SCOPES]
        if bad:
            raise ValueError(f"未知的权限范围:{'、'.join(bad)}")
        if not v:
            raise ValueError("至少要选择一项权限范围")
        return [s for s in SCOPES if s in v]  # 去重并按固定顺序存


def _out(tok: ApiToken, tenant_name: str = "", created_by: str = "") -> TokenOut:
    o = TokenOut.model_validate(tok)
    o.tenant_name, o.created_by, o.status = tenant_name, created_by, svc.status_of(tok)
    return o


@router.get("", response_model=list[TokenOut])
def list_tokens(db: Session = Depends(get_db)):
    rows = db.execute(
        select(ApiToken, Tenant.name, User.username)
        .outerjoin(Tenant, Tenant.id == ApiToken.tenant_id)
        .outerjoin(User, User.id == ApiToken.user_id)
        .order_by(ApiToken.id.desc())
    ).all()
    return [_out(t, tn or "", un or "") for t, tn, un in rows]


@router.post("/verify-identity", response_model=VerifyOut)
def verify_identity(body: VerifyIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_admin)):
    """创建令牌前的身份确认:输当前密码。走登录同款失败锁定,防止拿这里试密码。"""
    from ..services import loginguard

    ip = request.client.host if request.client else None
    left = loginguard.locked_seconds(user.username, ip)
    if left:
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, f"失败次数过多,请 {max(1, left // 60)} 分钟后再试")
    if not verify_password(body.password, user.password_hash):
        locked = loginguard.record_failure(user.username, ip, loginguard.max_failures(db))
        if locked:
            raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, f"失败次数过多,账号已临时锁定 {locked // 60} 分钟")
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "密码错误")
    loginguard.record_success(user.username, ip)
    return VerifyOut(grant=svc.issue_identity_grant(user))


@router.post("", response_model=TokenCreatedOut, status_code=201)
def create_token(body: TokenCreateIn, db: Session = Depends(get_db), user: User = Depends(require_admin)):
    try:
        svc.check_identity_grant(body.grant, user)
    except ValueError as ex:
        raise HTTPException(status.HTTP_403_FORBIDDEN, str(ex))
    tenant = db.get(Tenant, body.tenant_id)
    if not tenant or not tenant.is_active:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "组织不存在或已停用")
    plain, digest, prefix = svc.generate()
    tok = ApiToken(user_id=user.id, tenant_id=tenant.id, name=body.name.strip(), prefix=prefix, token_hash=digest,
                   scopes=",".join(body.scopes), source=body.source,
                   max_grant_role=body.max_grant_role, max_envs_per_user=body.max_envs_per_user,
                   allow_create_user=body.allow_create_user, allow_admin_role=body.allow_admin_role,
                   allow_any_tenant=body.allow_any_tenant, allow_delete_user=body.allow_delete_user,
                   hide_nav=body.hide_nav,
                   expires_at=datetime.now(timezone.utc) + timedelta(days=body.expires_days))
    db.add(tok)
    db.commit()
    db.refresh(tok)
    out = TokenCreatedOut(**_out(tok, tenant.name, user.username).model_dump(), token=plain)
    return out


class TokenUpdateIn(BaseModel):
    """编辑已有令牌的权限范围与上限。令牌明文不变,接入方不用重新粘贴;改动对下一次请求立即生效。
    来源标识与绑定组织不可改(同步进来的用户已经记在原来源 / 原组织下,改了会失联)。"""

    grant: str
    name: str | None = Field(default=None, min_length=1, max_length=64)
    scopes: list[str] | None = None
    max_grant_role: str | None = Field(default=None, pattern="^(tester|developer|owner)$")
    max_envs_per_user: int | None = Field(default=None, ge=0, le=50)
    allow_create_user: bool | None = None
    allow_admin_role: bool | None = None
    allow_any_tenant: bool | None = None
    allow_delete_user: bool | None = None
    hide_nav: bool | None = None
    expires_days: int | None = Field(default=None, ge=1, le=svc.MAX_DAYS)  # 从现在起重新计算

    @field_validator("scopes")
    @classmethod
    def _v_scopes(cls, v):
        if v is None:
            return v
        bad = [s for s in v if s not in SCOPES]
        if bad:
            raise ValueError(f"未知的权限范围:{'、'.join(bad)}")
        if not v:
            raise ValueError("至少要选择一项权限范围")
        return [s for s in SCOPES if s in v]


@router.put("/{token_id}", response_model=TokenOut)
def update_token(token_id: int, body: TokenUpdateIn, db: Session = Depends(get_db), user: User = Depends(require_admin)):
    """改权限范围 / 上限 / 名称 / 有效期。与创建一样先过身份确认(提权操作)。已吊销的令牌不可编辑。"""
    try:
        svc.check_identity_grant(body.grant, user)
    except ValueError as ex:
        raise HTTPException(status.HTTP_403_FORBIDDEN, str(ex))
    tok = db.get(ApiToken, token_id)
    if not tok:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "令牌不存在")
    if tok.revoked_at:
        raise HTTPException(status.HTTP_409_CONFLICT, "令牌已吊销,不能再编辑,请新建")
    if body.name is not None:
        tok.name = body.name.strip()
    if body.scopes is not None:
        tok.scopes = ",".join(body.scopes)
    for f in ("max_grant_role", "max_envs_per_user", "allow_create_user", "allow_admin_role",
              "allow_any_tenant", "allow_delete_user", "hide_nav"):
        v = getattr(body, f)
        if v is not None:
            setattr(tok, f, v)
    if body.expires_days is not None:
        tok.expires_at = datetime.now(timezone.utc) + timedelta(days=body.expires_days)
    db.commit()
    db.refresh(tok)
    tenant = db.get(Tenant, tok.tenant_id)
    creator = db.get(User, tok.user_id)
    return _out(tok, tenant.name if tenant else "", creator.username if creator else "")


@router.delete("/{token_id}", response_model=TokenOut)
def revoke_token(token_id: int, db: Session = Depends(get_db)):
    """吊销:令牌立即失效,但记录留着 —— 「谁在什么时候用它做了什么」事后还查得到。"""
    tok = db.get(ApiToken, token_id)
    if not tok:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "令牌不存在")
    if not tok.revoked_at:
        tok.revoked_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(tok)
    tenant = db.get(Tenant, tok.tenant_id)
    creator = db.get(User, tok.user_id)
    return _out(tok, tenant.name if tenant else "", creator.username if creator else "")


@router.delete("/{token_id}/purge", status_code=status.HTTP_204_NO_CONTENT)
def delete_token(token_id: int, db: Session = Depends(get_db)):
    """彻底删除令牌记录,不可恢复。

    跟吊销的区别只在留不留痕:吊销留记录、便于事后追查,是正常运维该用的;这个是用来清掉
    调试期间建的一堆废令牌,免得列表越滚越长。对还有效的令牌同样生效 —— 删掉即失效。
    令牌本身不被任何表外键引用(同步来的用户只记 external_source/external_id,不指向令牌),
    所以直接删行不会留下悬空引用。"""
    tok = db.get(ApiToken, token_id)
    if not tok:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "令牌不存在")
    db.delete(tok)
    db.commit()
