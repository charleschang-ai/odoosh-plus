"""一键登录实例:签发票据(需登录)+ 兑换票据(公开,由实例域名的 nginx 反代到此)。"""

import html
import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from .. import authz
from ..auth import get_current_user
from ..db import get_db
from ..models import Environment, Tenant, User
from ..services import sso as ssosvc

log = logging.getLogger("odoosh.sso")

router = APIRouter(prefix="/api", tags=["sso"])


@router.post("/environments/{env_id}/sso-url")
def sso_url(env_id: int, database_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """给当前用户签发 90 秒有效的一次性登录地址。database_id = 附加库 id(登录该库);不传 = 主库。
    一键登录拿到的是 Odoo admin 会话,等同于知道 admin 口令,因此要求 secrets 权限(拥有者 / 可管理 / 组织管理员;
    开发者仅非生产实例)。其他角色请在 Odoo 登录页用自己的 Odoo 账号登录(前端会直接打开实例地址)。"""
    from ..services import databases as dbsvc

    e = db.get(Environment, env_id)
    if not e:
        raise HTTPException(404, "环境不存在")
    authz.check_env(db, user, e, "open")
    if not authz.can_env(db, user, e, "secrets"):
        raise HTTPException(403, "一键登录(admin)仅实例管理者可用,请用你的 Odoo 账号登录")
    if e.status != "running" or not e.url:
        raise HTTPException(409, "实例未在运行")
    try:
        v = dbsvc.view(db, e, database_id)
    except ValueError as ex:
        raise HTTPException(404, str(ex))
    if v.row is not None and v.row.status != "ready":
        raise HTTPException(409, "该数据库尚未就绪")
    if not v.url:
        raise HTTPException(409, "端口直连访问模式下附加库无法按域名访问;切回「域名分流」访问模式后恢复")
    return {"url": ssosvc.sso_url(v, ssosvc.make_ticket(e.id, user, database_id)), "login": ssosvc.ADMIN_LOGIN}


def _fail(msg: str, e: Environment | None = None) -> HTMLResponse:
    back = f'<p><a href="/web/login">前往登录页</a></p>' if e else ""
    return HTMLResponse(
        f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>一键登录失败</title></head>'
        f'<body style="font-family:-apple-system,Segoe UI,PingFang SC,Microsoft YaHei,sans-serif;padding:48px;color:#0f172a">'
        f'<h2 style="margin:0 0 8px">一键登录失败</h2><p style="color:#475569">{html.escape(msg)}</p>{back}</body></html>', status_code=400)


@router.get("/sso/open")
def sso_open(t: str, request: Request, db: Session = Depends(get_db)):
    """兑换票据 → 在实例容器内认证 → 302 /web 并种下 session_id(响应经实例域名的 nginx 返回,cookie 落在实例域名)。"""
    try:
        p, user = ssosvc.read_ticket(t, db)  # 一次性;同时确认用户仍有效
    except ValueError as ex:
        return _fail(str(ex))
    e = db.get(Environment, int(p["env"]))
    if not e:
        return _fail("环境不存在")
    if not authz.can_env(db, user, e, "secrets"):  # 签发后权限可能已被撤销
        return _fail("无权一键登录该实例")
    tenant = db.get(Tenant, e.tenant_id)
    if p.get("db"):
        from ..services import databases as dbsvc

        try:
            e = dbsvc.view(db, e, int(p["db"]))
        except ValueError as ex:
            return _fail(str(ex))
    try:
        sid = ssosvc.login_session(tenant, e)
    except Exception as ex:  # noqa: BLE001
        log.warning("sso env#%s 失败: %s", e.id, ex)
        return _fail(str(ex), e)
    resp = RedirectResponse("/web", status_code=302)
    secure = (request.headers.get("x-forwarded-proto") or request.url.scheme) == "https"
    resp.set_cookie("session_id", sid, path="/", httponly=True, samesite="lax", secure=secure, max_age=60 * 60 * 24 * 7)
    return resp
