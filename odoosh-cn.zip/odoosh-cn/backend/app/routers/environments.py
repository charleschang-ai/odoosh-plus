from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from fastapi.responses import FileResponse, StreamingResponse
from starlette.background import BackgroundTask
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import authz, schemas
from ..auth import get_current_user, user_from_token
from ..config import settings as _settings
from ..db import get_db
from ..models import Environment, EnvironmentAcl, Membership, Tenant, User
from ..services import orchestrator
from ..services import jobs

router = APIRouter(prefix="/api/environments", tags=["environments"])

BUSY = orchestrator.BUSY_STATES


def _scope(q, db: Session, user: User, tenant_id: int | None):
    """按用户可见组织过滤查询。"""
    ids = authz.accessible_tenant_ids(db, user)
    if ids is not None:
        q = q.where(Environment.tenant_id.in_(ids or [-1]))
    if tenant_id is not None:
        q = q.where(Environment.tenant_id == tenant_id)
    return q


def _get_env(env_id: int, db: Session, user: User, action: str = "view") -> Environment:
    env = db.get(Environment, env_id)
    if not env:
        raise HTTPException(404, "环境不存在")
    authz.check_env(db, user, env, action)
    return env


def _not_busy(env: Environment):
    if env.status in BUSY:
        raise HTTPException(409, f"环境正在 {env.status},请稍候")


def _claim(db: Session, env: Environment, new_status: str, message: str = "已排队", forbid: tuple = ()) -> None:
    """原子抢占:非忙碌 → new_status;失败抛 409(防并发重复派发)。"""
    if not orchestrator.try_claim(db, env, new_status, message, forbid):
        raise HTTPException(409, f"环境正在 {env.status},请稍候")


def _find_repo_root(db: Session, tenant_id: int, repo_url: str | None) -> Environment | None:
    """同组织里绑定同一仓库的项目根实例(未删除):有则返回,用于把新环境归入该项目。"""
    if not repo_url:
        return None
    from ..services import git as gitsvc

    key = gitsvc.normalize_repo_url(repo_url)
    for e in db.scalars(select(Environment).where(Environment.tenant_id == tenant_id, Environment.project_id.is_(None), Environment.deleted_at.is_(None), Environment.repo_url.is_not(None)).order_by(Environment.id)).all():
        if gitsvc.normalize_repo_url(e.repo_url) == key:
            return e
    return None


def _check_repo_binding(db: Session, env: Environment | None, kind: str, repo_url: str | None, branch: str | None, tenant_id: int | None = None) -> None:
    """项目内约束(每个实例是独立项目,只在同一项目组内检查):一个生产环境;同一分支只一个环境。
    新建的实例是新的根项目,不与其他实例冲突。"""
    if env is None or not repo_url:
        return
    from ..services import git as gitsvc
    from ..services import project as projectsvc

    root = projectsvc.project_root(db, env)
    key = gitsvc.normalize_repo_url(repo_url)
    for other in projectsvc.project_envs(db, root):
        if other.id == env.id or gitsvc.normalize_repo_url(other.repo_url) != key:
            continue
        if branch and (other.branch or "") == branch:
            raise HTTPException(409, f"分支「{branch}」在本项目里已有环境「{other.name}」;一个分支只对应一个环境")
        if kind == "production" and other.kind == "production":
            raise HTTPException(409, f"本项目已有生产环境「{other.name}」(分支 {other.branch});一个项目只能有一个生产环境")


@router.get("", response_model=list[schemas.EnvironmentOut])
def list_envs(
    tenant_id: int | None = None,
    trash: bool = False,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    q = _scope(select(Environment).order_by(Environment.id), db, user, tenant_id)
    q = q.where(Environment.deleted_at.is_not(None)) if trash else q.where(Environment.deleted_at.is_(None))
    envs = db.scalars(q).all()
    # 实例级可见性:超管全部;其他人只看自己创建的 + 授权名单里的(旧数据无拥有者 → 按组织角色)
    roles = authz.env_roles_bulk(db, user, envs)
    envs = [e for e in envs if roles.get(e.id)]
    # 一次 docker list 校正所有实例状态(原先每实例一次 inspect,N+1)
    states = orchestrator.container_states()
    changed = False
    for e in envs:
        real = orchestrator.sync_status(e, states)
        if real != e.status:
            e.status = real
            changed = True
    if changed:
        db.commit()
    from ..services import databases as dbsvc

    counts = dbsvc.counts_bulk(db, [e.id for e in envs])
    out = []
    for e in envs:
        o = schemas.EnvironmentOut.model_validate(e)
        o.my_role = roles.get(e.id)
        o.extra_db_count = counts.get(e.id, 0)
        if not authz.env_allowed(o.my_role, "edit", e.kind):
            o.extra_conf = None  # 附加配置可能含 smtp 口令等,只给能编辑的人看
        out.append(o)
    return out


@router.get("/permissions")
def permissions(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """前端用:{tenant_id: {role, by_kind: {kind: {action: bool}}}}。"""
    ids = authz.accessible_tenant_ids(db, user)
    if ids is None:
        ids = list(db.scalars(select(Tenant.id)).all())
    out = {}
    roles = authz.role_map(db, user)  # 一次查询(以前每个组织一次 SELECT)
    for tid in ids:
        role = roles.get(tid)
        out[str(tid)] = {"role": role, "by_kind": {k: authz.env_permissions(role, k) for k in ("production", "staging", "dev")}}
    # 实例级角色矩阵:前端用 env.my_role × kind 查表(创建者 / 授权名单决定 my_role)
    out["_matrix"] = {r: {k: authz.env_permissions(r, k) for k in ("production", "staging", "dev")} for r in authz.ENV_MATRIX}
    return out


@router.get("/defaults")
def defaults(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """新建实例表单需要的全局默认值(所有登录用户可读)。"""
    from .settings import get_setting

    return {
        "expire_days_default": int(get_setting(db, "env.expire_days_default") or 0),
        "sleep_idle_hours": float(get_setting(db, "sleep.idle_hours") or 0),
        "expire_apply_production": (get_setting(db, "env.expire_apply_production") or "0") == "1",
        "trash_keep_days": int(get_setting(db, "env.trash_keep_days") or 7),
        "env_memory_mb": int(get_setting(db, "limits.env_memory_mb") or 1024),   # 实例设置页「资源上限」显示默认值用
        "env_cpus": float(get_setting(db, "limits.env_cpus") or 1),
        "trash_keep_days_production": int(get_setting(db, "env.trash_keep_days_production") or 30),
        "odoo_versions": [v.strip() for v in (get_setting(db, "odoo.versions") or "19,18,17,16,15,14,13,12").split(",") if v.strip()],
        "odoo_default_version": get_setting(db, "odoo.default_version") or "18",
        "base_domain": _settings.base_domain,  # 生效值(auto 时已解析为 <IP>.nip.io)
        "base_domain_raw": _settings.base_domain_raw,
        "enterprise_dir": get_setting(db, "odoo.enterprise_dir") or "/var/lib/odoosh/offline/enterprise",
        "git_enabled": (get_setting(db, "platform.git_enabled") or "1") == "1",   # 0 = 全系统不用 Git
        "can_use_enterprise": authz.is_superadmin(user) or bool(getattr(user, "can_use_enterprise", True)),
    }


@router.get("/conf-keys")
def conf_keys(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """odoo.conf 附加项的规则(实例设置页提示用):白名单 + 说明、超管扩充键、黑名单、是否允许实例级。"""
    from ..services import odooconf

    return {
        "env_enabled": odooconf.env_overrides_enabled(db),
        "superadmin": authz.is_superadmin(user),
        "whitelist": odooconf.WHITELIST,
        "extra_allowed": sorted(odooconf.extra_allowed_keys(db)),
        "blacklist": sorted(odooconf.BLACKLIST),
    }


@router.get("/stats")
def stats(
    tenant_id: int | None = None,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """所有可见且运行中的环境的资源占用,{env_id: {...}}。来自后台采集缓存(每 10s 刷新),接口本身不阻塞。"""
    from ..services import metrics

    q = _scope(select(Environment).where(Environment.status == "running"), db, user, tenant_id)
    envs = db.scalars(q).all()
    roles = authz.env_roles_bulk(db, user, envs)
    ids = [e.id for e in envs if authz.env_allowed(roles.get(e.id), "stats", e.kind)]
    return metrics.get_latest(ids)


@router.post("", response_model=schemas.EnvironmentOut, status_code=201)
def create_env(
    body: schemas.EnvironmentCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not db.get(Tenant, body.tenant_id):
        raise HTTPException(404, "组织不存在")
    authz.check_env_create(db, user, body.tenant_id, body.kind)
    authz.check_env_quota(db, user)  # 创建者即拥有者:按其名下实例数校验配额
    if body.edition == "enterprise" and not authz.is_superadmin(user) and not getattr(user, "can_use_enterprise", True):
        raise HTTPException(403, "你没有创建企业版实例的权限,请联系管理员开通")
    dup = db.scalar(
        select(Environment).where(Environment.tenant_id == body.tenant_id, Environment.name == body.name)
    )
    if dup:
        raise HTTPException(409, "该组织下已有同名环境")
    data = body.model_dump()
    expire_days = data.pop("expire_days", None)
    acl = data.pop("acl", None) or []
    from .settings import get_setting

    if (get_setting(db, "platform.git_enabled") or "1") != "1":
        # 全系统关 Git:服务端兜底——忽略传入的仓库/分支(创建后无法检出必失败),并强制官方镜像(源码自建需 git clone)
        data["repo_url"] = None
        data["branch"] = None
        data["base_mode"] = "official"
    if not authz.is_superadmin(user):
        # 域名 / 过期仅超级管理员可指定;其他人走自动域名 + 全局默认过期
        data["domain"] = None
        expire_days = None
    env = Environment(**data)
    env.owner_user_id = user.id  # 创建者 = 拥有者(仿 odoo.sh:默认只有自己可见)
    env.expires_at = orchestrator.compute_expires_at(expire_days, env.kind)
    # 一个仓库 = 一个实例(项目),不同分支 = 项目内不同环境:同组织里已有该仓库的项目 → 自动归入
    root = _find_repo_root(db, body.tenant_id, env.repo_url)
    if root is not None:
        from ..services import project as projectsvc

        # 归入已有项目 = 在别人的项目里建环境:必须对该项目根有权限,
        # 否则任何人填上他人仓库地址即可把自己写进该项目的授权名单(提权),或清空其名单。
        authz.check_project_create(db, user, root, env.kind)
        siblings = projectsvc.project_envs(db, root)
        if env.branch and any((o.branch or "") == env.branch for o in siblings):
            raise HTTPException(409, f"仓库「{root.name}」项目里分支「{env.branch}」已有环境;一个分支只对应一个环境")
        if env.kind == "production" and any(o.kind == "production" for o in siblings):
            raise HTTPException(409, f"仓库「{root.name}」项目已有生产环境;一个项目只能有一个生产环境")
        env.project_id = root.id
    db.add(env)
    db.flush()
    _apply_acl(db, env, acl, user)
    db.commit()
    db.refresh(env)
    out = schemas.EnvironmentOut.model_validate(env)
    out.my_role = "owner"
    return out


@router.get("/{env_id}", response_model=schemas.EnvironmentDetail)
def get_env(env_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    env = _get_env(env_id, db, user)
    out = schemas.EnvironmentDetail.model_validate(env)
    out.my_role = authz.env_role(db, user, env)
    from ..services import databases as dbsvc

    out.extra_db_count = dbsvc.counts_bulk(db, [env.id]).get(env.id, 0)
    # 凭据与编排日志按动作权限裁剪:tester 只有 view,不应看到 Odoo admin 口令 / 日志
    if not authz.can_env(db, user, env, "secrets"):
        out.admin_password = None
    if not authz.can_env(db, user, env, "logs"):
        out.log = None
    if not authz.can_env(db, user, env, "edit"):
        out.extra_conf = None
    return out


@router.put("/{env_id}", response_model=schemas.EnvironmentOut)
def update_env(
    env_id: int,
    body: schemas.EnvironmentUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    env = _get_env(env_id, db, user, "edit")
    data = body.model_dump(exclude_unset=True)
    data.pop("status", None)  # 状态由编排器维护,不接受外部改写(domain 已在 schema 层校验)
    if not authz.is_superadmin(user):
        # 域名 / 过期删除仅超级管理员可改(前端对其他角色不显示这两项)
        if ("domain" in data and (data["domain"] or None) != env.domain) or ("expire_days" in data and data["expire_days"] is not None):
            raise HTTPException(403, "域名与过期删除仅平台管理员可设置")
        data.pop("domain", None); data.pop("expire_days", None)
    if data.get("kind") and data["kind"] != env.kind:
        authz.check_env_create(db, user, env.tenant_id, data["kind"])  # 改类型等同于按新类型创建
    _check_repo_binding(db, env, data.get("kind", env.kind), data.get("repo_url", env.repo_url), data.get("branch", env.branch))
    for k in ("mem_mb", "cpus", "log_level"):
        if k in data and not data[k]:
            data[k] = None
    if not authz.is_superadmin(user) and (data.get("mem_mb") or data.get("cpus")):
        # 资源上限属于配额:非超管只能在平台默认值(limits.*)以内调整,不能自抬上限把宿主机吃光
        from .settings import get_setting

        cap_mem = int(get_setting(db, "limits.env_memory_mb") or 1024)
        cap_cpu = float(get_setting(db, "limits.env_cpus") or 1)
        if data.get("mem_mb") and int(data["mem_mb"]) > cap_mem:
            raise HTTPException(403, f"内存上限不能超过平台默认值 {cap_mem} MB(需更高请联系平台管理员)")
        if data.get("cpus") and float(data["cpus"]) > cap_cpu:
            raise HTTPException(403, f"CPU 上限不能超过平台默认值 {cap_cpu} 核(需更高请联系平台管理员)")
    if "max_dbs" in data:
        # 附加库上限属于配额:超管或组织管理员可改;其他角色即使能编辑实例也不能自抬上限
        if not (authz.is_superadmin(user) or authz.has_tenant_role(db, user, env.tenant_id, "owner")):
            raise HTTPException(403, "附加数据库上限仅平台管理员 / 组织管理员可设置")
        if data["max_dbs"] is not None and data["max_dbs"] < 0:
            data["max_dbs"] = None
    if "extra_conf" in data:
        from ..services import odooconf

        txt = (data["extra_conf"] or "").strip() or None
        if txt != (env.extra_conf or None):
            if not odooconf.env_overrides_enabled(db) and not authz.is_superadmin(user):
                raise HTTPException(403, "平台已关闭实例级 odoo.conf 附加项")
            errs = odooconf.validate(txt, superadmin=authz.is_superadmin(user), extra_allowed=odooconf.extra_allowed_keys(db))
            if errs:
                raise HTTPException(422, "odoo.conf 附加项有误:" + ";".join(errs))
        data["extra_conf"] = txt
    if data.get("log_level") and data["log_level"] not in orchestrator.LOG_LEVELS:
        raise HTTPException(422, f"日志等级须为 {'/'.join(orchestrator.LOG_LEVELS)}")
    if "expire_days" in data:
        days = data.pop("expire_days")
        env.expires_at = orchestrator.compute_expires_at(days if days is not None else 0, env.kind) if days else None
    for k, v in data.items():
        setattr(env, k, v)
    db.commit()
    db.refresh(env)
    return env


# ---------------- 编排动作(均为后台任务,前端轮询状态) ----------------
@router.post("/{env_id}/provision", response_model=schemas.EnvironmentOut)
def provision(
    env_id: int,
    bg: BackgroundTasks,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """创建并启动:构建/拉取镜像 → 组织 PG → 网络 → 数据库 → 初始化 → 容器 → 域名。"""
    env = _get_env(env_id, db, user, "create")
    if env.status == "running":
        raise HTTPException(409, "环境已在运行")
    _claim(db, env, "provisioning", forbid=("running",))
    env.log = None
    db.commit()
    bg.add_task(jobs.spawn, orchestrator.provision, env_id)
    return env


@router.post("/{env_id}/start", response_model=schemas.EnvironmentOut)
def start(env_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    env = _get_env(env_id, db, user, "start")
    if not env.container_name:
        raise HTTPException(400, "环境尚未创建,请先「创建并启动」")
    if env.status == "sleeping":
        from ..services import sleep as sleepsvc

        sleepsvc.request_wake(env, db, user.username)  # 休眠 → 唤醒
        return env
    _claim(db, env, "starting")
    bg.add_task(jobs.spawn, orchestrator.start, env_id)
    return env


@router.post("/{env_id}/stop", response_model=schemas.EnvironmentOut)
def stop(env_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    env = _get_env(env_id, db, user, "stop")
    _claim(db, env, "stopping")
    bg.add_task(jobs.spawn, orchestrator.stop, env_id)
    return env


@router.post("/{env_id}/restart", response_model=schemas.EnvironmentOut)
def restart(env_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    env = _get_env(env_id, db, user, "restart")
    _claim(db, env, "restarting")
    bg.add_task(jobs.spawn, orchestrator.restart, env_id)
    return env


@router.delete("/{env_id}", status_code=202)
def delete_env(
    env_id: int,
    bg: BackgroundTasks,
    backup: bool = False,
    purge: bool = False,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """删除 = 进回收站(停容器、摘域名,保留数据库与文件 env.trash_keep_days 天,可一键恢复);
    从未编排过的实例直接删记录。backup=1 时先做一次「删除前备份」再进回收站。彻底删除见 /purge。"""
    from ..services import backup as backupsvc

    env = _get_env(env_id, db, user, "delete")
    authz.check_env_owner(db, user, env, "删除 / 恢复实例")
    if env.deleted_at is not None:
        raise HTTPException(409, "实例已在回收站,请用「彻底删除」或「恢复」")
    if env.status == "provisioning":
        raise HTTPException(409, "环境正在创建中,请稍候")
    if backupsvc.is_locked(env.id):
        raise HTTPException(409, "该实例正在备份或恢复中,请稍候再删除")
    _detach_children(db, env)
    if not env.container_name and not env.db_name:
        db.delete(env)  # 从未编排过,直接删记录
        db.commit()
        return {"ok": True, "purged": True}
    backup_id = None
    if backup and env.db_name:
        if not backupsvc.try_lock(env.id):
            raise HTTPException(409, "该实例正在备份或恢复中,请稍候再删除")
        t = db.get(Tenant, env.tenant_id)
        b = backupsvc.new_backup_record(db, env, t, "manual", "删除前自动备份", True, user.username)
        backup_id = b.id
    # 允许打断 failed/stopped/running/sleeping,但不允许与其他过渡态并发
    if purge:
        # 直接彻底删除(不进回收站):含生产环境的实例(自身是生产,或项目里有生产分支)不允许,只能进回收站
        has_prod = env.kind == "production" or bool(db.scalar(select(Environment.id).where(Environment.project_id == env.id, Environment.kind == "production", Environment.deleted_at.is_(None))))
        if has_prod:
            raise HTTPException(400, "含生产环境的实例只能移入回收站,不能直接彻底删除;如确需删除,请先把生产分支降级")
        _claim(db, env, "destroying", "彻底删除")
        bg.add_task(jobs.spawn, _backup_then_destroy, env_id, backup_id)
        return {"ok": True, "purged": True, "backup_id": backup_id}
    _claim(db, env, "destroying", "移入回收站")
    bg.add_task(jobs.spawn, orchestrator.trash, env_id, backup_id)
    return {"ok": True, "purged": False, "backup_id": backup_id}


def _backup_then_destroy(env_id: int, backup_id: int | None) -> None:
    from ..services import backup as backupsvc

    if backup_id:
        orchestrator._set_status(env_id, "destroying", "删除前备份中", progress=10)
        backupsvc.run_backup(backup_id, env_id)
    orchestrator.destroy(env_id, False)


@router.post("/{env_id}/restore", response_model=schemas.EnvironmentOut)
def restore_from_trash(env_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """从回收站恢复:重新启动容器并接回域名。"""
    env = _get_env(env_id, db, user, "delete")
    authz.check_env_owner(db, user, env, "删除 / 恢复实例")
    if env.deleted_at is None:
        raise HTTPException(409, "实例不在回收站")
    # 回收站里的实例不占配额,恢复相当于重新占一个名额
    authz.check_env_quota(db, db.get(User, env.owner_user_id) if env.owner_user_id else None)
    dup = db.scalar(select(Environment).where(Environment.tenant_id == env.tenant_id, Environment.name == env.name, Environment.id != env.id, Environment.deleted_at.is_(None)))
    if dup:
        raise HTTPException(409, f"该组织下已有同名实例「{env.name}」,请先处理后再恢复")
    if env.project_id and env.branch:
        from ..services import project as projectsvc

        root = db.get(Environment, env.project_id)
        if root and any((o.branch or "") == env.branch and o.id != env.id for o in projectsvc.project_envs(db, root)):
            raise HTTPException(409, f"项目里分支「{env.branch}」已有新的环境,无法恢复到同一分支;可先删除那个环境")
    _claim(db, env, "starting", "从回收站恢复")
    bg.add_task(jobs.spawn, orchestrator.untrash, env_id)
    out = schemas.EnvironmentOut.model_validate(env)
    out.my_role = authz.env_role(db, user, env)
    return out


@router.delete("/{env_id}/purge", status_code=202)
def purge_env(env_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """彻底删除(仅回收站里的实例):删容器、网络、数据库与文件,不可恢复。"""
    env = _get_env(env_id, db, user, "delete")
    authz.check_env_owner(db, user, env, "删除 / 恢复实例")
    if env.deleted_at is None:
        raise HTTPException(409, "只能彻底删除回收站里的实例;请先「删除」进回收站")
    _detach_children(db, env)
    _claim(db, env, "destroying", "彻底删除")
    bg.add_task(jobs.spawn, orchestrator.destroy, env_id, False)
    return {"ok": True}


def _detach_children(db: Session, env: Environment) -> None:
    """删除项目根实例:把从它派生的环境转给剩下的第一个环境作为新根(否则它们会变成孤儿);名单一并搬过去。"""
    children = db.scalars(select(Environment).where(Environment.project_id == env.id).order_by(Environment.id)).all()
    if not children:
        return
    new_root = children[0]
    new_root.project_id = None
    if new_root.owner_user_id is None:
        new_root.owner_user_id = env.owner_user_id
    for c in children[1:]:
        c.project_id = new_root.id
    for a in db.scalars(select(EnvironmentAcl).where(EnvironmentAcl.environment_id == env.id)).all():
        db.add(EnvironmentAcl(environment_id=new_root.id, user_id=a.user_id, level=a.level))
        db.delete(a)
    db.commit()


# ---------------- 授权名单(谁能访问 / 操作) ----------------
def _apply_acl(db: Session, env: Environment, entries: list, actor: User) -> None:
    """整体替换名单(挂在项目根上)。拥有者与超管不需要在名单里;名单成员须是该组织成员。

    名单是「整体替换」语义,因此只允许改自己作为拥有者的项目根:新建实例归入他人项目时,
    既不能借此把自己写进对方名单(提权),也不能把对方名单清空。
    """
    root_id = authz.acl_root_id(env)
    if root_id != env.id:
        root = db.get(Environment, root_id)
        if root is not None and not authz.is_env_owner(db, actor, root):
            if entries:
                raise HTTPException(403, "无权修改该项目的授权名单(仅项目拥有者可改)")
            return  # 未指定名单:保持项目原有名单不动
    member_ids = set(db.scalars(select(Membership.user_id).where(Membership.tenant_id == env.tenant_id)).all())
    admin_ids = set(db.scalars(select(User.id).where(User.role == "admin")).all())
    owner_id = authz.env_owner_id(db, env)
    wanted = {}
    for it in entries:
        uid = it.user_id if hasattr(it, "user_id") else it["user_id"]
        lv = it.level if hasattr(it, "level") else it.get("level", "view")
        if uid == owner_id or uid in admin_ids:
            continue
        if uid not in member_ids:
            raise HTTPException(400, f"用户 #{uid} 不是该组织成员,请先在组织设置中添加")
        if lv not in authz.ACL_LEVELS:
            raise HTTPException(400, "无效的授权级别")
        wanted[uid] = lv
    existing = {a.user_id: a for a in db.scalars(select(EnvironmentAcl).where(EnvironmentAcl.environment_id == root_id)).all()}
    for uid, a in existing.items():
        if uid not in wanted:
            db.delete(a)
        elif a.level != wanted[uid]:
            a.level = wanted[uid]
    for uid, lv in wanted.items():
        if uid not in existing:
            db.add(EnvironmentAcl(environment_id=root_id, user_id=uid, level=lv))


def _acl_state(db: Session, env: Environment) -> schemas.EnvAclState:
    root_id = authz.acl_root_id(env)
    owner_id = authz.env_owner_id(db, env)
    owner = db.get(User, owner_id) if owner_id else None
    levels = dict(db.execute(select(EnvironmentAcl.user_id, EnvironmentAcl.level).where(EnvironmentAcl.environment_id == root_id)).all())
    rows = db.execute(
        select(User).join(Membership, Membership.user_id == User.id).where(Membership.tenant_id == env.tenant_id, User.is_active.is_(True)).order_by(User.id)
    ).scalars().all()

    def out(u: User, lv: str, is_owner=False):
        return schemas.EnvAclOut(user_id=u.id, username=u.username, display_name=u.display_name, level=lv, is_owner=is_owner)

    entries = [out(u, levels[u.id]) for u in rows if u.id in levels]
    candidates = [out(u, levels.get(u.id, "")) for u in rows if u.role != "admin" and u.id != owner_id]
    return schemas.EnvAclState(owner_user_id=owner_id, owner_username=owner.username if owner else None, entries=entries, candidates=candidates)


@router.get("/{env_id}/acl", response_model=schemas.EnvAclState)
def get_acl(env_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    env = _get_env(env_id, db, user, "view")
    return _acl_state(db, env)


@router.put("/{env_id}/acl", response_model=schemas.EnvAclState)
def put_acl(env_id: int, body: list[schemas.EnvAclIn], db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """整体替换授权名单;需要「可管理」(edit)权限。"""
    env = _get_env(env_id, db, user, "edit")
    authz.check_env_owner(db, user, env, "修改授权名单")
    _apply_acl(db, env, body, user)
    db.commit()
    return _acl_state(db, env)


@router.put("/{env_id}/owner", response_model=schemas.EnvAclState)
def set_owner(env_id: int, body: dict, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """转让拥有者(拥有者本人或超管):新拥有者须为该组织成员;原拥有者自动进入名单为「可管理」。"""
    env = _get_env(env_id, db, user, "edit")
    authz.check_env_owner(db, user, env, "转让拥有者")
    new_id = int(body.get("user_id") or 0)
    nu = db.get(User, new_id)
    if not nu or not nu.is_active:
        raise HTTPException(404, "用户不存在")
    if nu.role != "admin" and not db.scalar(select(Membership).where(Membership.tenant_id == env.tenant_id, Membership.user_id == new_id)):
        raise HTTPException(400, "新拥有者须是该组织成员")
    root = db.get(Environment, authz.acl_root_id(env)) or env
    old_id = root.owner_user_id
    children = db.scalars(select(Environment).where(Environment.project_id == root.id)).all()
    if new_id != old_id:  # 转让也占新拥有者的配额(根实例 + 分支环境,不含回收站里的)
        authz.check_env_quota(db, nu, adding=1 + sum(1 for c in children if c.deleted_at is None) if root.deleted_at is None else sum(1 for c in children if c.deleted_at is None))
    root.owner_user_id = new_id
    for c in children:
        c.owner_user_id = new_id
    db.flush()
    db.execute(EnvironmentAcl.__table__.delete().where(EnvironmentAcl.environment_id == root.id, EnvironmentAcl.user_id == new_id))
    old_user = db.get(User, old_id) if old_id else None
    if old_user and old_id != new_id and old_user.role != "admin":
        db.add(EnvironmentAcl(environment_id=root.id, user_id=old_id, level="manage"))
    db.commit()
    return _acl_state(db, env)


# ---------------- 代码部署 ----------------
@router.post("/{env_id}/deploy", response_model=schemas.DeploymentOut)
def deploy_env(
    env_id: int, body: schemas.DeployIn, bg: BackgroundTasks,
    db: Session = Depends(get_db), user: User = Depends(get_current_user),
):
    """部署分支最新或指定 commit:拉代码 → 换挂载重建容器 → 重启 / -u 模块 / -u all → 健康检查,失败回退。"""
    from ..services import deploy as deploysvc

    env = _get_env(env_id, db, user, "deploy")
    _not_busy(env)
    if not env.repo_url or not env.branch:
        raise HTTPException(400, "实例未绑定仓库/分支,请先在「编辑」中绑定")
    if not env.container_name:
        raise HTTPException(400, "实例尚未创建,请先「创建并启动」(创建时会自动部署分支最新代码)")
    action = body.action or env.deploy_action or "update_all"
    if action not in ("restart", "update", "update_all"):
        raise HTTPException(400, "无效的部署动作")
    modules = body.modules if body.modules is not None else env.deploy_modules
    if action == "update" and not (modules or "").strip():
        raise HTTPException(400, "动作为「升级指定模块」时需填写模块列表")
    # 只允许部署分支最新提交(不支持回退到历史提交:要回退请在 Git 里 revert/reset 后再推送)
    if body.commit:
        try:
            md, _ = deploysvc.ensure_mirror(db, env.tenant_id, env.repo_url, fetch_timeout=120)
            head = deploysvc.resolve_commit(md, env.branch)
        except Exception as ex:  # noqa: BLE001
            raise HTTPException(400, f"无法读取分支最新提交:{ex}")
        if not head.startswith(body.commit) and not body.commit.startswith(head):
            raise HTTPException(400, f"只能部署分支「{env.branch}」的最新提交({head[:7]});如需回退,请在 Git 中 revert / reset 后推送")
    databases = None
    if body.databases is not None:
        from ..services import databases as dbsvc

        known = set(dbsvc.all_db_names(db, env))
        databases = [x for x in body.databases if x in known]
        if not databases:
            raise HTTPException(400, "请至少选择一个要升级的数据库")
    _claim(db, env, "deploying")
    d = deploysvc.create_record(db, env, "manual", action, modules, user.username, sha=body.commit, databases=databases)
    bg.add_task(jobs.spawn, deploysvc.deploy, d.id)
    return d


# ---------------- 定制代码(上传/放目录/在线编辑 → 挂载 → 扫描) ----------------
# 每个实例都有自己的定制 addons 目录(见 custom_code.addons_dir);Git 实例上它与只读的仓库检出并存,
# 是实例里唯一可写的代码目录(AI 编程模块的产出也放这里),同名模块以仓库代码优先。
def _plain_env(env_id: int, db: Session, user: User, level: str) -> tuple[Environment, Tenant]:
    env = _get_env(env_id, db, user, level)
    t = db.get(Tenant, env.tenant_id)
    return env, t


@router.get("/{env_id}/custom-code")
def custom_code_info(env_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """当前实例定制 addons 目录里的模块列表 + 宿主机路径(方式 A:直接往该路径拷代码)+ 容器内路径。
    git=true 表示实例还绑定了仓库:定制目录排在仓库代码之后,同名模块以仓库代码优先。"""
    env = _get_env(env_id, db, user, "view")
    from ..services import custom_code

    t = db.get(Tenant, env.tenant_id)
    return {"git": bool(env.repo_url), "host_dir": custom_code.host_addons_dir(t, env),
            "mount": orchestrator.CUSTOM_ADDONS_MOUNT, "modules": custom_code.list_modules(t, env)}


@router.put("/{env_id}/custom-code/upload")
async def custom_code_upload(env_id: int, request: Request, bg: BackgroundTasks, mode: str = "replace",
                             restart: bool = True,
                             db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """上传 zip → 解压按模块合并进 addons → (可选)重启使 Odoo 认到模块。请求体即 zip 本身。

    mode:同名模块的策略。replace=整目录替换(默认);merge=只覆盖包里有的文件,保留自己在模块里新加的文件。
    restart:false 则只落盘不重启(在线编辑时连传几个包,最后再统一重启)。"""
    import os as _os
    from uuid import uuid4

    from starlette.concurrency import run_in_threadpool

    if mode not in ("replace", "merge"):
        raise HTTPException(400, "mode 只能是 replace 或 merge")
    env, t = _plain_env(env_id, db, user, "deploy")
    _not_busy(env)
    from ..services import custom_code

    # 随机后缀:同一实例被并发上传时各写各的临时文件,不会互相覆盖
    tmp_zip = _os.path.join(orchestrator.env_dir(t, env), f".upload-{uuid4().hex[:8]}.zip")
    _os.makedirs(_os.path.dirname(tmp_zip), exist_ok=True)

    def _cleanup() -> None:
        try:
            _os.remove(tmp_zip)
        except OSError:
            pass

    # nginx 对这条路径是 client_max_body_size 0(不限),所以上限必须在这里掐 ——
    # 否则学生传个几十 GB 的包就能把宿主盘写满,把全班拖下水
    max_upload = custom_code.limits(db)["max_upload"]
    total = 0
    try:
        with open(tmp_zip, "wb") as f:
            async for chunk in request.stream():
                if chunk:
                    total += len(chunk)
                    if max_upload and total > max_upload:
                        raise ValueError(f"压缩包超过 {max_upload // 1024 // 1024}MB 上限")
                    f.write(chunk)
    except ValueError as ex:
        _cleanup()
        raise HTTPException(413, str(ex))
    except Exception as ex:  # noqa: BLE001  客户端中途断开 / 磁盘写满:别把半截文件留在磁盘上
        _cleanup()
        raise HTTPException(400, f"接收上传数据失败:{ex}")
    if total == 0:
        _cleanup()
        raise HTTPException(400, "空文件")
    # merge_zip 在别的线程里读 t / env 的列属性。先在本线程碰一遍:万一对象已过期(前面有 commit),
    # 刷新查询就发生在这里,而不是在工作线程里用同一个非线程安全的 Session 去查库。
    _ = (t.slug, env.name, env.id, env.image_tag, env.odoo_version, env.base_mode)
    try:
        # 解压 + 逐模块落盘是同步重活,放线程池,别占住事件循环拖垮全平台请求
        summary = await run_in_threadpool(custom_code.merge_zip, t, env, tmp_zip, mode, db)  # 内部会删 tmp_zip
    except custom_code.QuotaError as ex:
        _cleanup()
        raise HTTPException(413, str(ex))
    except ValueError as ex:
        _cleanup()
        raise HTTPException(400, str(ex))
    except Exception as ex:  # noqa: BLE001
        _cleanup()
        raise HTTPException(500, f"导入自定义代码失败:{ex}")
    custom_code.audit(db, env, user, "upload_zip",
                      detail=f"{mode}:新增 {len(summary['new'])} 更新 {len(summary['updated'])}", size=total)
    out = {"new": summary["new"], "updated": summary["updated"], "mode": mode, "restarted": False}
    if not restart:
        return out
    # 放好代码后重启,让 Odoo 认到新模块(安装/升级由用户在 Odoo「应用」里做)
    _claim(db, env, "restarting")
    bg.add_task(jobs.spawn, orchestrator.restart, env_id)
    out["restarted"] = True
    return out


@router.post("/{env_id}/custom-code/reload", response_model=schemas.EnvironmentOut)
def custom_code_reload(env_id: int, bg: BackgroundTasks, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """方式 A:代码已放进目录后,重启实例使 Odoo 认到模块(等同于「重启使生效」)。"""
    env, _t = _plain_env(env_id, db, user, "deploy")
    _claim(db, env, "restarting")
    bg.add_task(jobs.spawn, orchestrator.restart, env_id)
    return env


@router.delete("/{env_id}/custom-code/{name}")
def custom_code_delete(env_id: int, name: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """删除 addons 目录里某个模块的代码文件(卸载请先在 Odoo 里做)。"""
    env, t = _plain_env(env_id, db, user, "deploy")
    from ..services import custom_code

    try:
        ok = custom_code.delete_module(t, env, name)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not ok:
        raise HTTPException(404, "模块不存在")
    return {"deleted": True}


@router.get("/{env_id}/custom-code/download")
def custom_code_download(env_id: int, module: str | None = None,
                         db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """把 addons 目录打包下载(拿走 / 提交作业)。module 给了就只下那一个模块。"""
    import os as _os
    from uuid import uuid4

    env = _get_env(env_id, db, user, "view")
    from ..services import custom_code

    t = db.get(Tenant, env.tenant_id)
    # 随机后缀:同一实例被并发下载时不会互相覆盖临时 zip
    out = _os.path.join(orchestrator.env_dir(t, env), f".download-{env_id}-{uuid4().hex[:8]}.zip")
    try:
        custom_code.build_download_zip(t, env, out, module)
    except ValueError as ex:
        _os.path.exists(out) and _os.remove(out)
        raise HTTPException(400, str(ex))
    fname = f"{module}.zip" if module else f"{env.name}-addons.zip"
    return FileResponse(out, filename=fname, media_type="application/zip",
                        background=BackgroundTask(lambda: _os.path.exists(out) and _os.remove(out)))


# ---------------------------------------------------------------- 定制代码:在线编辑
# 路径都放在 /custom-code/fs/… 下(两段),不会和上面的 /custom-code/{name} 单段通配撞车。
# 读 = 设置项 code.read_role(默认 view;考试场景可调成 deploy,让只能看实例的人读不到源码);
# 任何写 = deploy 权限(与上传 zip 同级)。写操作不要求实例在运行:停着也能改代码。
def _code_env(env_id: int, db: Session, user: User, level: str):
    from ..services import custom_code

    if level == "read":
        from .settings import get_setting

        level = (get_setting(db, "code.read_role") or "view").strip() or "view"
        if level not in authz.ENV_ACTIONS:
            level = "view"
    env, t = _plain_env(env_id, db, user, level)
    return env, t, custom_code


def _code_err(ex: Exception, cc, what: str):
    """把服务层异常映射成合适的 HTTP 状态:配额 413、并发冲突 409、其余参数错 400。"""
    if isinstance(ex, cc.QuotaError):
        return HTTPException(413, str(ex))
    if isinstance(ex, cc.ConflictError):
        return HTTPException(409, str(ex))
    if isinstance(ex, ValueError):
        return HTTPException(400, str(ex))
    return HTTPException(500, f"{what}:{ex}")


@router.get("/{env_id}/custom-code/fs/tree")
def code_tree(env_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """addons 目录的完整文件树(嵌套)+ 配额占用。顶层含 __manifest__.py 的目录 module=true。"""
    env, t, cc = _code_env(env_id, db, user, "read")
    out = cc.list_tree(t, env)
    out["usage"] = cc.usage(t, env)
    out["limits"] = cc.limits(db)
    return out


@router.get("/{env_id}/custom-code/fs/file")
def code_read(env_id: int, path: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """读文件。二进制 / 超大 / 非 UTF-8 时 editable=false + reason,不算错误。
    返回带 mtime(保存时带回来做并发校验)与 lint(语法预检)。"""
    env, t, cc = _code_env(env_id, db, user, "read")
    try:
        return cc.read_file(t, env, path)
    except Exception as ex:
        raise _code_err(ex, cc, "读取失败")


@router.put("/{env_id}/custom-code/fs/file")
def code_write(env_id: int, path: str, payload: schemas.CodeWriteIn,
               db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """保存文件(原子写)。父目录不存在会自动建。
    payload.mtime 给了就做乐观并发校验:文件被别处改过则 409,避免静默覆盖。
    返回的 lint 是语法预检结果,**不阻止保存**,由前端提示。"""
    env, t, cc = _code_env(env_id, db, user, "deploy")
    try:
        out = cc.write_file(t, env, path, payload.content, db=db, expect_mtime=payload.mtime)
    except Exception as ex:
        raise _code_err(ex, cc, "写入失败")
    cc.audit(db, env, user, "write", path, size=out["size"])
    return out


@router.post("/{env_id}/custom-code/fs/entry")
def code_create(env_id: int, payload: schemas.CodeEntryIn,
                db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """新建空文件或目录。新建 .py 会自动往同目录 __init__.py 补 `from . import <名>`,
    结果放在 init_updated 里(null = 没改)。"""
    env, t, cc = _code_env(env_id, db, user, "deploy")
    try:
        out = cc.create_entry(t, env, payload.path, payload.kind, db=db)
    except Exception as ex:
        raise _code_err(ex, cc, "创建失败")
    cc.audit(db, env, user, "create", payload.path, detail=payload.kind)
    return out


@router.delete("/{env_id}/custom-code/fs/entry")
def code_delete(env_id: int, path: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """删除文件或目录(目录递归删)。"""
    env, t, cc = _code_env(env_id, db, user, "deploy")
    try:
        out = cc.delete_entry(t, env, path)
    except Exception as ex:
        raise _code_err(ex, cc, "删除失败")
    cc.audit(db, env, user, "delete", path, detail="目录" if out["dir"] else "文件")
    return out


@router.post("/{env_id}/custom-code/fs/rename")
def code_rename(env_id: int, payload: schemas.CodeRenameIn,
                db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """重命名 / 移动(两端都必须在 addons 目录内)。"""
    env, t, cc = _code_env(env_id, db, user, "deploy")
    try:
        out = cc.rename_entry(t, env, payload.path, payload.new_path)
    except Exception as ex:
        raise _code_err(ex, cc, "重命名失败")
    cc.audit(db, env, user, "rename", payload.path, detail=f"→ {payload.new_path}")
    return out


@router.post("/{env_id}/custom-code/fs/scaffold")
def code_scaffold(env_id: int, payload: schemas.CodeScaffoldIn,
                  db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """新建模块骨架:一个能直接安装的最小模块(模型 + 列表/表单视图 + 菜单 + 权限)。"""
    env, t, cc = _code_env(env_id, db, user, "deploy")
    try:
        cc.check_quota(db, t, env, add_files=7)
        out = cc.scaffold_module(t, env, payload.name, payload.label, payload.author or user.username)
    except Exception as ex:
        raise _code_err(ex, cc, "生成失败")
    cc.audit(db, env, user, "scaffold", out["module"], detail=payload.label or None)
    return out


@router.post("/{env_id}/custom-code/fs/update-modules", response_model=schemas.EnvironmentOut)
def code_update_modules(env_id: int, bg: BackgroundTasks, modules: str = "",
                        db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """对主库 + 附加库执行 odoo -u <modules>(逗号分隔;留空 = all)。
    改了模型字段 / 视图 / 权限后必须走这条 —— 「重启使生效」不会重读 XML,也不会改表结构。"""
    env, t, cc = _code_env(env_id, db, user, "deploy")
    mods = ",".join(m.strip() for m in (modules or "").split(",") if m.strip())
    if mods and mods != "all":
        known = {m["name"] for m in cc.list_modules(t, env)}
        missing = [m for m in mods.split(",") if m not in known]
        if missing:
            raise HTTPException(400, f"模块不存在:{', '.join(missing)}")
    cc.audit(db, env, user, "update_modules", detail=mods or "all")
    cc.drop_schema_cache(env_id)  # 升级后模型 / 字段会变,补全下次要拿新的
    _claim(db, env, "deploying")
    bg.add_task(jobs.spawn, cc.update_modules, env_id, mods or "all")
    return env


@router.get("/{env_id}/custom-code/fs/completions")
def code_completions(env_id: int, refresh: bool = False,
                     db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """编辑器补全用的库内元数据:本实例数据库里真实存在的模型与字段。

    让 `self.env['…']`、`comodel_name='…'`、`<field name="…">` 补出来的是**这个库里真有的**东西,
    包括学生自己刚建的模型。实例没起来时返回空列表 + reason,不报错(补全少点提示而已)。"""
    env, t, cc = _code_env(env_id, db, user, "read")
    return cc.schema_for(t, env, refresh=refresh)


@router.get("/{env_id}/custom-code/fs/last-error")
def code_last_error(env_id: int, lines: int = 40, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """最近一次升级 / 重启的日志尾部。学生点了「升级模块」失败后,不用切到「日志」Tab 就能看到原因 ——
    这是他们最常卡住的第一现场。"""
    env, _t, cc = _code_env(env_id, db, user, "read")
    return cc.last_job_error(env, max(5, min(200, lines)))


# ---- 历史版本(误覆盖能回滚)----
@router.get("/{env_id}/custom-code/fs/history")
def code_history(env_id: int, path: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """某文件的历史版本列表,新的在前。"""
    env, t, cc = _code_env(env_id, db, user, "read")
    return {"path": path, "versions": cc.list_history(t, env, path)}


@router.get("/{env_id}/custom-code/fs/history/content")
def code_history_content(env_id: int, path: str, version: str,
                         db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """读某个历史版本的内容(前端用来对比 / 预览)。"""
    env, t, cc = _code_env(env_id, db, user, "read")
    try:
        return {"path": path, "version": version, "content": cc.read_history(t, env, path, version)}
    except Exception as ex:
        raise _code_err(ex, cc, "读取历史失败")


@router.post("/{env_id}/custom-code/fs/history/restore")
def code_history_restore(env_id: int, path: str, version: str,
                         db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """把文件恢复成某个历史版本(恢复动作本身也会先存一份当前内容,可以再撤回)。"""
    env, t, cc = _code_env(env_id, db, user, "deploy")
    try:
        content = cc.read_history(t, env, path, version)
        out = cc.write_file(t, env, path, content, db=db)
    except Exception as ex:
        raise _code_err(ex, cc, "恢复失败")
    cc.audit(db, env, user, "restore", path, detail=version, size=out["size"])
    return out


@router.get("/{env_id}/custom-code/fs/audit")
def code_audit(env_id: int, limit: int = 100, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """本实例的代码改动记录(谁、什么时候、改了哪个文件)。判分 / 查抄袭 / 追责用。
    需要 deploy 权限 —— 能改代码的人才看得到改动史。"""
    env, _t, cc = _code_env(env_id, db, user, "deploy")
    from ..models_code import CodeEdit

    rows = db.scalars(
        select(CodeEdit).where(CodeEdit.environment_id == env.id)
        .order_by(CodeEdit.id.desc()).limit(max(1, min(500, limit)))
    ).all()
    return [{"id": r.id, "username": r.username, "action": r.action, "path": r.path,
             "detail": r.detail, "size": r.size, "at": r.at} for r in rows]


@router.put("/{env_id}/custom-code/fs/upload-file")
async def code_upload_file(env_id: int, request: Request, name: str, dir: str = "",
                           db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """往某个目录上传单个文件(图标、图片、xlsx 等 zip 之外的零散文件)。请求体即文件本身。"""
    env, t, cc = _code_env(env_id, db, user, "deploy")
    limit = cc.MAX_EDIT_BYTES * 5  # 单个二进制文件放宽到 10MB(图片 / 字体够用)
    buf = bytearray()
    async for chunk in request.stream():
        buf.extend(chunk)
        if len(buf) > limit:
            raise HTTPException(413, f"文件超过 {limit // 1024 // 1024}MB 上限,请用「上传代码包(zip)」")
    try:
        out = cc.save_upload_file(t, env, dir, name, bytes(buf), db=db)
    except Exception as ex:
        raise _code_err(ex, cc, "上传失败")
    cc.audit(db, env, user, "upload_file", out["path"], size=out["size"])
    return out


@router.get("/{env_id}/deployments", response_model=list[schemas.DeploymentOut])
def list_deployments(env_id: int, limit: int = 30, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    from ..models_deploy import Deployment

    _get_env(env_id, db, user, "view")
    return db.scalars(select(Deployment).where(Deployment.environment_id == env_id).order_by(Deployment.id.desc()).limit(limit)).all()


@router.get("/{env_id}/deployments/{dep_id}", response_model=schemas.DeploymentDetail)
def get_deployment(env_id: int, dep_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    from ..models_deploy import Deployment

    _get_env(env_id, db, user, "logs")
    d = db.get(Deployment, dep_id)
    if not d or d.environment_id != env_id:
        raise HTTPException(404, "部署记录不存在")
    return d


@router.get("/{env_id}/commits")
def list_commits(env_id: int, limit: int = 30, skip: int = 0, refresh: bool = False,
                 db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """分支的提交历史(来自平台维护的仓库镜像),标注已部署/当前。"""
    from ..models_deploy import Deployment
    from ..services import deploy as deploysvc

    env = _get_env(env_id, db, user, "view")
    if not env.repo_url or not env.branch:
        return {"items": [], "current": None, "error": "未绑定仓库/分支"}
    try:
        md, _repo = deploysvc.ensure_mirror(db, env.tenant_id, env.repo_url, force=refresh, fetch_timeout=60, background=not refresh)
        items = deploysvc.list_commits(md, env.branch, limit, skip)
    except Exception as e:  # noqa: BLE001
        return {"items": [], "current": env.code_commit, "error": str(e)}
    deps = db.scalars(select(Deployment).where(Deployment.environment_id == env_id, Deployment.commit_sha.is_not(None)).order_by(Deployment.id.desc())).all()
    by_sha: dict[str, dict] = {}
    for d in deps:
        by_sha.setdefault(d.commit_sha, {"id": d.id, "status": d.status, "trigger": d.trigger, "action": d.action, "finished_at": d.finished_at, "duration": d.duration})
    for it in items:
        it["deployment"] = by_sha.get(it["sha"])
        it["is_current"] = it["sha"] == env.code_commit
    return {"items": items, "current": env.code_commit, "error": None}


@router.get("/{env_id}/logs")
def logs(env_id: int, tail: int = 300, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    env = _get_env(env_id, db, user, "logs")
    return {"orchestration": env.log or "", "container": orchestrator.container_logs(env, max(1, min(tail, 5000)))}


@router.get("/{env_id}/logs/stream")
def logs_stream(env_id: int, token: str, tail: int = 300, db: Session = Depends(get_db)):
    """SSE:先回放编排日志(orch)+ 容器日志尾部(container),然后实时跟随。事件 data 为 JSON 字符串。"""
    import threading

    tail = max(1, min(tail, 5000))  # 未限幅时 ?tail=1e8 会把整份容器日志读进内存

    from ..services import logstream
    from ..services import dockerx

    user = user_from_token(token, db)
    env = _get_env(env_id, db, user, "logs")
    q = logstream.subscribe(f"env:{env_id}")
    stop = threading.Event()
    orch_lines = (env.log or "").splitlines()
    c = dockerx.get_container(env.container_name or "")
    cname = env.container_name

    def gen():
        try:
            yield logstream.sse("reset", "")
            for ln in orch_lines[-400:]:
                yield logstream.sse("orch", ln)
            if c:
                try:
                    for ln in c.logs(tail=tail, timestamps=False).decode(errors="ignore").splitlines():
                        yield logstream.sse("container", ln)
                except Exception as ex:  # noqa: BLE001
                    yield logstream.sse("container", f"[读取容器日志失败: {ex}]")
                closer = logstream.follow_container(c, q, stop, since=int(__import__("time").time()))
            else:
                closer = None
                yield logstream.sse("container", "(容器不存在)")
            # 容器被重建(部署)时关掉旧 follow 再跟随新容器;每 2s 空闲检查一次
            state = {"c": c, "close": closer}

            def is_done():
                nc = dockerx.get_container(cname or "")
                if nc and (state["c"] is None or nc.id != state["c"].id):
                    if state["close"]:
                        state["close"]()
                    state["c"] = nc
                    state["close"] = logstream.follow_container(nc, q, stop, since=int(__import__("time").time()))
                return False

            yield from logstream.stream(q, stop, is_done=is_done)
        finally:
            stop.set()
            logstream.unsubscribe(f"env:{env_id}", q)

    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@router.get("/{env_id}/deployments/{dep_id}/log/stream")
def deployment_log_stream(env_id: int, dep_id: int, token: str, db: Session = Depends(get_db)):
    """SSE:部署日志(orch 事件),部署结束后发 end。"""
    import threading

    from ..models_deploy import Deployment
    from ..services import logstream

    user = user_from_token(token, db)
    _get_env(env_id, db, user, "logs")
    d = db.get(Deployment, dep_id)
    if not d or d.environment_id != env_id:
        raise HTTPException(404, "部署记录不存在")
    q = logstream.subscribe(f"dep:{dep_id}")
    stop = threading.Event()
    initial = (d.log or "").splitlines()
    finished = d.status in ("success", "failed")

    def is_done():
        from ..db import SessionLocal

        with SessionLocal() as s:
            row = s.get(Deployment, dep_id)
            return not row or row.status in ("success", "failed")

    def gen():
        try:
            yield logstream.sse("reset", "")
            for ln in initial:
                yield logstream.sse("orch", ln)
            if finished:
                yield logstream.sse("end", "")
                return
            yield from logstream.stream(q, stop, is_done=is_done)
        finally:
            stop.set()
            logstream.unsubscribe(f"dep:{dep_id}", q)

    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@router.get("/{env_id}/metrics")
def env_metrics(env_id: int, range: str = "1h", db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Monitor Tab:CPU / 内存 / 网络 / 磁盘 IO 曲线 + filestore / 数据库大小(range = 1h | 6h | 24h | 7d)。"""
    from ..services import metrics

    _get_env(env_id, db, user, "stats")
    out = metrics.series(env_id, range)
    out["latest"] = metrics.get_latest([env_id]).get(str(env_id))
    return out
