"""主机指标 + Docker 状态(只读)。"""

import platform
import time

import psutil
from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..auth import get_current_user, require_admin
from ..config import settings
from ..db import get_db
from ..models import Environment, Tenant, User

router = APIRouter(prefix="/api/system", tags=["system"], dependencies=[Depends(get_current_user)])


def _docker_client():
    from ..services import dockerx

    return dockerx.client()  # 复用全局客户端(原先每次请求新建连接)


@router.get("/overview")
def overview(db: Session = Depends(get_db)):
    vm = psutil.virtual_memory()
    # 量数据目录所在盘(实例 filestore / PG / 备份 / 仓库都在这里),而不是 api 容器自己的根文件系统
    try:
        disk = psutil.disk_usage(settings.data_dir)
    except OSError:
        disk = psutil.disk_usage("/")
    docker_ok, docker_version, containers_running, containers_total, images_total = False, None, 0, 0, 0
    try:
        client = _docker_client()
        ver = client.version()
        docker_version = ver.get("Version")
        info = client.info()
        containers_running = info.get("ContainersRunning", 0)
        containers_total = info.get("Containers", 0)
        images_total = info.get("Images", 0)
        docker_ok = True
    except Exception:
        pass
    return {
        "app": {"name": settings.app_name, "version": settings.version},
        "counts": {
            "tenants": db.scalar(select(func.count(Tenant.id))),
            "environments": db.scalar(select(func.count(Environment.id))),
            "users": db.scalar(select(func.count(User.id))),
        },
        "host": {
            "hostname": platform.node(),
            "os": f"{platform.system()} {platform.release()}",
            "cpu_count": psutil.cpu_count(),
            "cpu_percent": psutil.cpu_percent(interval=None),
            "mem_total": vm.total,
            "mem_used": vm.used,
            "mem_percent": vm.percent,
            "disk_total": disk.total,
            "disk_used": disk.used,
            "disk_percent": disk.percent,
            "uptime_seconds": int(time.time() - psutil.boot_time()),
        },
        "docker": {
            "ok": docker_ok,
            "version": docker_version,
            "containers_running": containers_running,
            "containers_total": containers_total,
            "images_total": images_total,
        },
        "cert": _cert_status(),
    }


def _cert_status() -> dict:
    """实例 HTTPS 用的泛域名证书状态;读证书失败不影响总览接口。"""
    try:
        from ..services import nginx as nginxsvc

        return nginxsvc.cert_status()
    except Exception:  # noqa: BLE001
        return {"enabled": False, "present": False, "days_left": None, "warn": False}


# ---------------- 平台自更新(超级管理员) ----------------
@router.get("/platform/update")
def platform_update_status(since: float | None = None, user: User = Depends(get_current_user)):
    from .. import authz
    from ..services import platform_update

    authz.require_superadmin(user)
    st = platform_update.status(since)
    st["modes"] = platform_update.MODES
    st["src_dir"] = settings.host_src_dir
    st["api_started_at"] = settings.started_at
    return st


@router.post("/platform/update")
def platform_update_start(body: dict, user: User = Depends(get_current_user)):
    from .. import authz
    from ..services import platform_update

    authz.require_superadmin(user)
    mode = (body or {}).get("mode", "restart")
    try:
        return platform_update.start(mode)
    except (ValueError, RuntimeError) as e:
        from fastapi import HTTPException

        raise HTTPException(400, str(e))


@router.get("/docker/containers", dependencies=[Depends(require_admin)])
def docker_containers():
    try:
        client = _docker_client()
    except Exception as e:  # docker 不可用
        return {"ok": False, "error": str(e), "items": []}
    items = []
    for c in client.containers.list(all=True):
        items.append(
            {
                "id": c.short_id,
                "name": c.name,
                "image": c.attrs.get("Config", {}).get("Image") or c.image.short_id,  # 不再逐容器 inspect 镜像
                "status": c.status,
                "created": c.attrs.get("Created"),
                "labels": {k: v for k, v in c.labels.items() if k.startswith("odoosh.")},
            }
        )
    return {"ok": True, "items": items}


@router.get("/docker/images", dependencies=[Depends(require_admin)])
def docker_images():
    try:
        client = _docker_client()
    except Exception as e:
        return {"ok": False, "error": str(e), "items": []}
    items = []
    for img in client.images.list():
        items.append(
            {
                "id": img.short_id,
                "tags": img.tags,
                "size": img.attrs.get("Size", 0),
                "created": img.attrs.get("Created"),
            }
        )
    return {"ok": True, "items": items}


# ---------------- 最近活动(总览页) ----------------
@router.get("/activity")
def activity(limit: int = 12, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """聚合最近的部署 / 备份 / 恢复 / 推送 / 实例创建,按时间倒序;非超管只看有成员关系的组织。

    每类各取 limit 条(带索引的小查询),在内存里合并排序,开销可忽略;不做分页,总览页只展示最近若干条。
    """
    from .. import authz
    from ..models_backup import Backup, RestoreJob
    from ..models_deploy import Deployment
    from ..models_git import PushEvent, Repository

    limit = max(1, min(int(limit or 12), 50))
    tids = authz.accessible_tenant_ids(db, user)  # None = 全部
    if tids is not None and not tids:
        return []
    tenant_names = dict(db.execute(select(Tenant.id, Tenant.name)).all())

    def scope(stmt, col):
        return stmt if tids is None else stmt.where(col.in_(tids))

    deps = db.scalars(scope(select(Deployment), Deployment.tenant_id).order_by(Deployment.created_at.desc()).limit(limit)).all()
    bks = db.scalars(scope(select(Backup), Backup.tenant_id).order_by(Backup.created_at.desc()).limit(limit)).all()
    rjs = db.scalars(scope(select(RestoreJob), RestoreJob.tenant_id).order_by(RestoreJob.created_at.desc()).limit(limit)).all()
    # 只查这批记录引用到的实例(以前每 30s 轮询一次都全表取 environments)
    env_ids = {x.environment_id for x in [*deps, *bks, *rjs] if getattr(x, "environment_id", None)}
    env_rows = db.execute(select(Environment.id, Environment.name, Environment.tenant_id, Environment.kind).where(Environment.id.in_(env_ids or {-1}))).all()
    env_map = {r.id: r for r in env_rows}

    items: list[dict] = []
    for d in deps:
        e = env_map.get(d.environment_id)
        items.append({
            "type": "deploy", "at": d.created_at, "status": d.status, "tenant": tenant_names.get(d.tenant_id),
            "env_id": d.environment_id, "env": e.name if e else None, "kind": e.kind if e else None,
            "title": f"部署 {d.branch or ''}@{(d.commit_sha or '')[:7]}".strip(), "detail": d.commit_message or d.message, "by": d.created_by,
        })
    for b in bks:
        items.append({
            "type": "backup", "at": b.created_at, "status": b.status, "tenant": tenant_names.get(b.tenant_id),
            "env_id": b.environment_id, "env": b.env_name, "kind": (env_map.get(b.environment_id).kind if env_map.get(b.environment_id) else None),
            "title": {"manual": "手动备份", "auto": "自动备份", "pre_restore": "恢复前备份", "upload": "上传备份"}.get(b.kind, "备份"),
            "detail": b.note or b.message, "by": b.created_by,
        })
    for r in rjs:
        e = env_map.get(getattr(r, "environment_id", None))
        items.append({
            "type": "restore", "at": r.created_at, "status": getattr(r, "status", None), "tenant": tenant_names.get(r.tenant_id),
            "env_id": getattr(r, "environment_id", None), "env": e.name if e else getattr(r, "env_name", None), "kind": e.kind if e else None,
            "title": "恢复备份", "detail": getattr(r, "message", None), "by": getattr(r, "created_by", None),
        })
    push_stmt = select(PushEvent, Repository.name, Repository.tenant_id).join(Repository, Repository.id == PushEvent.repository_id)
    if tids is not None:
        # 仓库仅接入者本人可见(+ 平台共享;无接入者的旧记录归组织管理员)
        owner_tids = [t for t in tids if authz.has_tenant_role(db, user, t, "owner")]
        push_stmt = push_stmt.where(
            (Repository.scope == "platform")
            | ((Repository.tenant_id.in_(tids or [-1])) & (Repository.created_by == user.id))
            | ((Repository.tenant_id.in_(owner_tids or [-1])) & (Repository.created_by.is_(None)))
        )
    for ev, repo_name, r_tid in db.execute(push_stmt.order_by(PushEvent.received_at.desc()).limit(limit)).all():
        items.append({
            "type": "push", "at": ev.received_at, "status": "deleted" if ev.deleted else "ok", "tenant": tenant_names.get(r_tid),
            "env_id": None, "env": None, "kind": None,
            "title": f"推送 {repo_name} · {ev.branch}", "detail": ev.commit_message or ev.result, "by": ev.author or ev.pusher,
        })
    for e in db.scalars(scope(select(Environment), Environment.tenant_id).order_by(Environment.created_at.desc()).limit(limit)):
        items.append({
            "type": "env", "at": e.created_at, "status": e.status, "tenant": tenant_names.get(e.tenant_id),
            "env_id": e.id, "env": e.name, "kind": e.kind, "title": "创建实例", "detail": f"Odoo {e.odoo_version} · {e.branch or '无分支'}", "by": None,
        })
    items = [i for i in items if i["at"] is not None]
    items.sort(key=lambda i: i["at"], reverse=True)
    return items[:limit]
