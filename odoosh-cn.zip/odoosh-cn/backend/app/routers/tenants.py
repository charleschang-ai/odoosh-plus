from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import authz, schemas
from ..auth import get_current_user, hash_password, require_admin
from ..db import get_db
import logging

from ..models import Membership, Tenant, User

log = logging.getLogger("odoosh.tenants")

router = APIRouter(prefix="/api/tenants", tags=["tenants"])


@router.get("", response_model=list[schemas.TenantOut])
def list_tenants(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = select(Tenant).order_by(Tenant.id)
    ids = authz.accessible_tenant_ids(db, user)
    if ids is not None:
        q = q.where(Tenant.id.in_(ids or [-1]))
    return db.scalars(q).all()


@router.post("", response_model=schemas.TenantOut, status_code=201, dependencies=[Depends(require_admin)])
def create_tenant(body: schemas.TenantCreate, db: Session = Depends(get_db)):
    if db.scalar(select(Tenant).where(Tenant.slug == body.slug)):
        raise HTTPException(409, "组织标识已存在")
    data = body.model_dump()
    owner_username = data.pop("owner_username", None)
    owner_password = data.pop("owner_password", None)
    owner_display_name = data.pop("owner_display_name", None)
    t = Tenant(**data)
    db.add(t)
    db.flush()
    if owner_username:
        u = db.scalar(select(User).where(User.username == owner_username))
        if not u:
            if not owner_password:
                raise HTTPException(400, "首任管理员用户不存在,请提供初始密码以创建")
            u = User(username=owner_username, password_hash=hash_password(owner_password), display_name=owner_display_name, role="member")
            db.add(u)
            db.flush()
        if not authz.is_superadmin(u):
            db.add(Membership(user_id=u.id, tenant_id=t.id, role="owner"))
    db.commit()
    db.refresh(t)
    return t


@router.put("/{tenant_id}", response_model=schemas.TenantOut)
def update_tenant(
    tenant_id: int, body: schemas.TenantUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    t = db.get(Tenant, tenant_id)
    if not t:
        raise HTTPException(404, "组织不存在")
    data = body.model_dump(exclude_unset=True)
    if "is_active" in data or "max_dbs_per_env" in data or "max_dbs_total" in data:
        authz.require_superadmin(user)  # 停用/启用组织、附加库配额仅超管
    else:
        authz.require_tenant_role(db, user, tenant_id, "owner")
    for k, v in data.items():
        setattr(t, k, v)
    db.commit()
    db.refresh(t)
    return t


@router.delete("/{tenant_id}", status_code=204, dependencies=[Depends(require_admin)])
def delete_tenant(tenant_id: int, db: Session = Depends(get_db)):
    t = db.get(Tenant, tenant_id)
    if not t:
        raise HTTPException(404, "组织不存在")
    if t.environments:
        raise HTTPException(400, "组织下仍有环境,请先删除环境")
    # 备份 / 恢复记录:backups.tenant_id 外键无级联,以前只要该组织有过备份这里就会 IntegrityError 500。
    # 组织都删了,它的备份文件与记录一并清掉(正在跑的备份 / 恢复先拒绝)
    from ..models_backup import Backup, RestoreJob
    from ..services import backup as backupsvc

    if db.scalar(select(Backup.id).where(Backup.tenant_id == tenant_id, Backup.status == "running")) or db.scalar(
        select(RestoreJob.id).where(RestoreJob.tenant_id == tenant_id, RestoreJob.status == "running")
    ):
        raise HTTPException(409, "该组织有正在进行的备份 / 恢复任务,请等其结束后再删除")
    backups = db.scalars(select(Backup).where(Backup.tenant_id == tenant_id)).all()
    for b in backups:
        db.expunge(b)  # 脱离会话:提交后还要读 filename / replica_key 去删文件,行已被批量删除不能再 refresh
    # 先删引用行(恢复记录 → 备份),再删 tenant;文件在事务提交成功后再删(以前先删文件、事务失败 → 文件没了记录还在)
    db.query(RestoreJob).filter(RestoreJob.tenant_id == tenant_id).delete(synchronize_session=False)
    db.query(Backup).filter(Backup.tenant_id == tenant_id).delete(synchronize_session=False)
    db.flush()
    slug = t.slug
    for u in t.users:
        u.tenant_id = None
    db.query(Membership).filter(Membership.tenant_id == tenant_id).delete()
    db.delete(t)
    db.commit()
    import shutil

    for b in backups:
        try:
            backupsvc.delete_backup_file(b)  # 本地文件 + 远端副本(best effort)
        except OSError:
            pass
    shutil.rmtree(backupsvc.tenant_storage_dir(slug), ignore_errors=True)  # 该组织备份目录(含 _uploads)


# ---------------- 成员管理(组织管理员及以上) ----------------
def _member_out(m: Membership) -> schemas.MemberOut:
    return schemas.MemberOut(
        id=m.id, user_id=m.user_id, username=m.user.username, display_name=m.user.display_name,
        role=m.role, is_active=m.user.is_active, created_at=m.created_at,
    )


@router.get("/{tenant_id}/members", response_model=list[schemas.MemberOut])
def list_members(tenant_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    authz.require_tenant_role(db, user, tenant_id, "developer")  # 开发者可看成员列表(只读)
    ms = db.scalars(select(Membership).where(Membership.tenant_id == tenant_id).order_by(Membership.id)).all()
    return [_member_out(m) for m in ms]


@router.post("/{tenant_id}/members", response_model=schemas.MemberOut, status_code=201)
def add_member(
    tenant_id: int, body: schemas.MemberAdd, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    authz.require_tenant_role(db, user, tenant_id, "owner")
    if not db.get(Tenant, tenant_id):
        raise HTTPException(404, "组织不存在")
    if body.role not in authz.ROLES:
        raise HTTPException(400, "无效角色")
    u = db.scalar(select(User).where(User.username == body.username))
    if not u:
        # 建号是超管专属(routers/users.py 全 router require_admin):组织管理员只能添加已存在的用户,
        # 否则可造影子账号规避审计,并借响应差异枚举平台用户名。
        raise HTTPException(404, "用户不存在,请联系平台管理员先创建该账号")
    if authz.is_superadmin(u):
        raise HTTPException(400, "该用户无需添加")  # 不回显「是超级管理员」,避免枚举出超管账号
    if db.scalar(select(Membership).where(Membership.user_id == u.id, Membership.tenant_id == tenant_id)):
        raise HTTPException(409, "该用户已是成员")
    m = Membership(user_id=u.id, tenant_id=tenant_id, role=body.role)
    db.add(m)
    db.commit()
    db.refresh(m)
    return _member_out(m)


@router.put("/{tenant_id}/members/{member_id}", response_model=schemas.MemberOut)
def update_member(
    tenant_id: int, member_id: int, body: schemas.MemberUpdate,
    db: Session = Depends(get_db), user: User = Depends(get_current_user),
):
    authz.require_tenant_role(db, user, tenant_id, "owner")
    m = db.get(Membership, member_id)
    if not m or m.tenant_id != tenant_id:
        raise HTTPException(404, "成员不存在")
    if body.role not in authz.ROLES:
        raise HTTPException(400, "无效角色")
    if m.user_id == user.id and body.role != "owner" and not authz.is_superadmin(user):
        raise HTTPException(400, "不能降低自己的角色")
    m.role = body.role
    db.commit()
    db.refresh(m)
    return _member_out(m)


@router.delete("/{tenant_id}/members/{member_id}", status_code=204)
def remove_member(tenant_id: int, member_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    authz.require_tenant_role(db, user, tenant_id, "owner")
    m = db.get(Membership, member_id)
    if not m or m.tenant_id != tenant_id:
        raise HTTPException(404, "成员不存在")
    if m.user_id == user.id and not authz.is_superadmin(user):
        raise HTTPException(400, "不能移除自己")
    n = authz.purge_env_acl(db, m.user_id, tenant_id)  # 一并清掉实例授权,否则移出后仍能按 id 访问该组织实例
    db.delete(m)
    db.commit()
    if n:
        log.info("移除成员 user#%s(组织 %s):同时清理 %s 条实例授权", m.user_id, tenant_id, n)
