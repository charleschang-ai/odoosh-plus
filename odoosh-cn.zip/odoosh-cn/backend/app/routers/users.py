from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import authz, schemas
from ..auth import hash_password, require_admin, revoke_tokens
from ..config import settings
from ..db import get_db
from ..models import Membership, Tenant, User
from ..services import accounts

router = APIRouter(prefix="/api/users", tags=["users"], dependencies=[Depends(require_admin)])


def is_root(user: User) -> bool:
    """内置超级管理员(ODOOSH_ADMIN_USER):平台的最后一道保险,任何人(含自己)都不能删除 / 停用 / 降级。"""
    return user.username == settings.admin_user


def _with_memberships(db: Session, users: list[User]) -> list[schemas.UserOut]:
    ids = [u.id for u in users]
    rows = db.execute(
        select(Membership, Tenant).join(Tenant, Tenant.id == Membership.tenant_id).where(Membership.user_id.in_(ids or [-1]))
    ).all()  # 只取本次要渲染的用户(以前全量 memberships × tenants)
    by_user: dict[int, list[schemas.MembershipOut]] = {}
    for m, t in rows:
        by_user.setdefault(m.user_id, []).append(
            schemas.MembershipOut(tenant_id=t.id, tenant_slug=t.slug, tenant_name=t.name, role=m.role)
        )
    # 名下实例数(按拥有者计,不含回收站):配额显示用
    from sqlalchemy import func

    from ..models import Environment

    counts = dict(db.execute(
        select(Environment.owner_user_id, func.count(Environment.id)).where(Environment.owner_user_id.in_(ids or [-1]), Environment.deleted_at.is_(None)).group_by(Environment.owner_user_id)
    ).all())
    from ..models_db import EnvironmentDatabase

    db_counts = dict(db.execute(
        select(EnvironmentDatabase.created_by, func.count(EnvironmentDatabase.id)).where(EnvironmentDatabase.status != "dropping").group_by(EnvironmentDatabase.created_by)
    ).all())
    out = []
    for u in users:
        d = schemas.UserOut.model_validate(u)
        d.memberships = by_user.get(u.id, [])
        d.is_root = is_root(u)
        d.env_count = int(counts.get(u.id, 0))
        d.db_count = int(db_counts.get(u.username, 0))
        out.append(d)
    return out


def _sync_memberships(db: Session, user: User, items: list[schemas.MembershipIn]) -> None:
    """整体替换用户的组织角色(同一组织只保留一条)。逻辑已收敛到 services/accounts,单条 / 批量共用。"""
    accounts.sync_memberships(db, user, items)


@router.get("", response_model=list[schemas.UserOut])
def list_users(db: Session = Depends(get_db)):
    return _with_memberships(db, db.scalars(select(User).order_by(User.id)).all())


@router.post("", response_model=schemas.UserOut, status_code=201)
def create_user(body: schemas.UserCreate, db: Session = Depends(get_db)):
    if db.scalar(select(User).where(User.username == body.username)):
        raise HTTPException(409, "用户名已存在")
    role = "admin" if body.role == "admin" else "member"
    user = User(
        username=body.username,
        password_hash=hash_password(body.password),
        display_name=body.display_name,
        role=role,
        shell_enabled=bool(body.shell_enabled),
        can_use_enterprise=bool(body.can_use_enterprise),
        menu_dashboard=bool(body.menu_dashboard),
        menu_repos=bool(body.menu_repos),
        menu_ai=bool(body.menu_ai),
        menu_backups=bool(body.menu_backups),
        menu_settings=bool(body.menu_settings),
        menu_upgrade=bool(body.menu_upgrade),
        menu_databases=bool(body.menu_databases),
        max_envs=body.max_envs if body.max_envs is None or body.max_envs >= 0 else None,
        max_dbs=body.max_dbs if body.max_dbs is None or body.max_dbs >= 0 else None,
    )
    db.add(user)
    db.flush()
    items = list(body.memberships or [])
    if body.tenant_id and role == "member" and not items:  # 兼容旧表单
        items = [schemas.MembershipIn(tenant_id=body.tenant_id, role="owner" if body.role == "tenant_admin" else "developer")]
    _sync_memberships(db, user, items)
    db.commit()
    db.refresh(user)
    return _with_memberships(db, [user])[0]


@router.put("/{user_id}", response_model=schemas.UserOut)
def update_user(user_id: int, body: schemas.UserUpdate, db: Session = Depends(get_db), me: User = Depends(require_admin)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(404, "用户不存在")
    data = body.model_dump(exclude_unset=True)
    if "password" in data:
        pw = data.pop("password")
        if pw and is_root(user) and user.id != me.id:
            raise HTTPException(400, "内置超级管理员的密码只能由本人在「修改密码」中更改")
        if pw:
            user.password_hash = hash_password(pw)
            revoke_tokens(user)
    if data.get("is_active") is False:
        if is_root(user):
            raise HTTPException(400, "内置超级管理员账号受保护,不能停用")
        revoke_tokens(user)
    memberships = data.pop("memberships", None)
    data.pop("tenant_id", None)
    if "role" in data:
        data["role"] = "admin" if data["role"] == "admin" else "member"
        if user.id == me.id and data["role"] != "admin":
            raise HTTPException(400, "不能取消自己的超级管理员身份")
        if is_root(user) and data["role"] != "admin":
            raise HTTPException(400, "内置超级管理员账号受保护,不能降级")
    if "max_envs" in data and data["max_envs"] is not None and data["max_envs"] < 0:
        data["max_envs"] = None  # 负数视为不限
    if "max_dbs" in data and data["max_dbs"] is not None and data["max_dbs"] < 0:
        data["max_dbs"] = None
    for k, v in data.items():
        setattr(user, k, v)
    db.flush()
    if memberships is not None or user.role == "admin":
        _sync_memberships(db, user, [schemas.MembershipIn(**m) for m in (memberships or [])])
    db.commit()
    db.refresh(user)
    return _with_memberships(db, [user])[0]


@router.delete("/{user_id}", status_code=204)
def delete_user(user_id: int, purge_envs: bool = False, db: Session = Depends(get_db), me: User = Depends(require_admin)):
    """删除用户。名下实例默认进回收站(数据按保留天数可恢复),purge_envs=true 才连数据一并销毁。"""
    if user_id == me.id:
        raise HTTPException(400, "不能删除自己")
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(404, "用户不存在")
    if is_root(user):
        raise HTTPException(400, "内置超级管理员账号受保护,任何人都不能删除")
    accounts.delete_with_envs(db, user, purge_envs=purge_envs)
    db.commit()


# ---------------- 批量用户(超级管理员;router 已 require_admin) ----------------
def _tenant_maps(db: Session) -> tuple[dict[str, Tenant], dict[int, Tenant]]:
    ts = db.scalars(select(Tenant)).all()
    return {t.slug: t for t in ts}, {t.id: t for t in ts}


def _mem_labels(items, by_id: dict[int, Tenant]) -> list[str]:
    out = []
    for m in items or []:
        t = by_id.get(m.tenant_id)
        out.append(f"{t.name if t else m.tenant_id}·{accounts.MEMBERSHIP_LABEL.get(m.role, m.role)}")
    return out


def _parse_memberships(cell: str, by_slug: dict[str, Tenant], errors: list[str]) -> list[schemas.MembershipIn]:
    """组织格式:slug:role;slug2:role2(role 缺省 developer;组织用 slug)。"""
    items: list[schemas.MembershipIn] = []
    seen: set[int] = set()
    for part in (cell or "").replace("，", ",").replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        slug, _, role = part.partition(":")
        slug = slug.strip()
        role = role.strip() or "developer"
        t = by_slug.get(slug)
        if not t:
            errors.append(f"组织「{slug}」不存在")
            continue
        if role not in authz.ROLES:
            errors.append(f"角色「{role}」无效(owner/developer/tester)")
            continue
        if t.id in seen:
            continue
        seen.add(t.id)
        items.append(schemas.MembershipIn(tenant_id=t.id, role=role))
    return items


_TRUE = {"1", "true", "yes", "y", "是", "开", "on"}


def _parse_int(cell: str, label: str, errors: list[str]) -> int | None:
    cell = (cell or "").strip()
    if not cell:
        return None  # 空 = 不限
    try:
        n = int(cell)
    except ValueError:
        errors.append(f"{label}「{cell}」不是整数")
        return None
    if n < 0:
        errors.append(f"{label}不能为负")
        return None
    return n


@router.post("/bulk-parse", response_model=schemas.BulkParseOut)
def bulk_parse(body: schemas.BulkParseIn, db: Session = Depends(get_db)):
    """解析粘贴的文本 / CSV 为逐行预览(不写库)。列:用户名,显示名,密码,角色,Shell,实例配额,附加库配额,组织。"""
    by_slug, by_id = _tenant_maps(db)
    existing = {u for (u,) in db.execute(select(User.username)).all()}
    rows: list[schemas.BulkRowPreview] = []
    seen_names: set[str] = set()
    for raw in (body.text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        low = line.lower()
        if low.startswith("username") or line.startswith("用户名"):
            continue  # 表头
        parts = [p.strip().strip('"') for p in line.split(",", 7)]
        parts += [""] * (8 - len(parts))
        username, display_name, password, role, shell, max_envs_s, max_dbs_s, mem_s = parts[:8]
        errors: list[str] = []
        if not accounts.USERNAME_RE.match(username or ""):
            errors.append("用户名不合法(字母/数字开头,可含 . _ -,2~64 位)")
        elif username in seen_names:
            errors.append("本批内用户名重复")
        elif username in existing:
            errors.append("用户名已存在")
        seen_names.add(username)
        role_norm = "admin" if (role or "").lower() in ("admin", "超级管理员", "超管") else "member"
        max_envs = _parse_int(max_envs_s, "实例配额", errors)
        max_dbs = _parse_int(max_dbs_s, "附加库配额", errors)
        memberships = _parse_memberships(mem_s, by_slug, errors) if role_norm == "member" else []
        will_gen = not (password or "").strip()
        row = schemas.BulkUserRowIn(
            username=username or "?", display_name=display_name or None, password=(password or None),
            role=role_norm, shell_enabled=(shell or "").lower() in _TRUE, max_envs=max_envs, max_dbs=max_dbs, memberships=memberships,
        )
        rows.append(schemas.BulkRowPreview(row=row, membership_labels=_mem_labels(memberships, by_id), will_generate_password=will_gen, errors=errors))
    ok = sum(1 for r in rows if not r.errors)
    return schemas.BulkParseOut(rows=rows, ok_count=ok, error_count=len(rows) - ok)


@router.post("/bulk-create", response_model=schemas.BulkCreateOut, status_code=201)
def bulk_create(body: schemas.BulkCreateIn, db: Session = Depends(get_db)):
    """批量创建用户:全或无。任一行不合法则整批回滚。明文密码仅本次响应回显一次。"""
    if not body.rows:
        raise HTTPException(400, "没有要创建的用户")
    _, by_id = _tenant_maps(db)
    seen: set[str] = set()
    for r in body.rows:
        if r.username in seen:
            raise HTTPException(409, f"本批内用户名「{r.username}」重复")
        seen.add(r.username)
    created: list[schemas.BulkCreatedUser] = []
    try:
        for r in body.rows:
            user, plain = accounts.create_one(db, r)
            created.append(schemas.BulkCreatedUser(
                id=0, username=user.username, display_name=user.display_name, role=user.role,
                password=plain, membership_labels=_mem_labels(r.memberships, by_id),
            ))
        db.flush()
        ids = {u.username: u.id for u in db.scalars(select(User).where(User.username.in_(list(seen)))).all()}
        for c in created:
            c.id = ids.get(c.username, 0)
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    except Exception as ex:  # noqa: BLE001
        db.rollback()
        raise HTTPException(400, f"批量创建失败:{ex}")
    return schemas.BulkCreateOut(created=created)


@router.post("/bulk-update", response_model=schemas.BulkUpdateOut)
def bulk_update(body: schemas.BulkUpdateIn, db: Session = Depends(get_db), me: User = Depends(require_admin)):
    """批量更新用户:逐条应用同一组变更,部分成功。受保护 / 无变化的条目标为跳过。"""
    if not body.user_ids:
        raise HTTPException(400, "没有选择用户")
    if body.role is not None and body.role not in ("admin", "member"):
        raise HTTPException(400, "角色须为 admin / member")
    if body.membership_mode is not None and body.membership_mode not in ("add", "remove", "replace"):
        raise HTTPException(400, "赋权模式须为 add / remove / replace")
    results: list[schemas.BulkResultRow] = []
    for uid in dict.fromkeys(body.user_ids):  # 去重保序
        user = db.get(User, uid)
        if not user:
            results.append(schemas.BulkResultRow(user_id=uid, username=str(uid), status="skipped", message="用户不存在"))
            continue
        notes: list[str] = []
        try:
            changed = False
            if body.role is not None:
                target = "admin" if body.role == "admin" else "member"
                if user.role != target:
                    if is_root(user):
                        notes.append("受保护:未改角色")
                    elif user.id == me.id and target != "admin":
                        raise ValueError("不能取消自己的超级管理员身份")
                    else:
                        user.role = target
                        changed = True
                        if target == "admin":
                            accounts.sync_memberships(db, user, [])
            if body.is_active is not None and user.is_active != body.is_active:
                if body.is_active is False and is_root(user):
                    notes.append("受保护:未停用")
                elif body.is_active is False and user.id == me.id:
                    raise ValueError("不能停用自己")
                else:
                    user.is_active = body.is_active
                    if body.is_active is False:
                        revoke_tokens(user)
                    changed = True
            if body.shell_enabled is not None and user.shell_enabled != body.shell_enabled:
                user.shell_enabled = body.shell_enabled
                changed = True
            for mf in ("menu_dashboard", "menu_repos", "menu_ai", "menu_backups", "menu_settings", "menu_upgrade", "menu_databases"):
                v = getattr(body, mf)
                if v is not None and getattr(user, mf) != v:
                    setattr(user, mf, v)
                    changed = True
            if body.set_max_envs:
                v = body.max_envs if (body.max_envs is None or body.max_envs >= 0) else None
                if user.max_envs != v:
                    user.max_envs = v
                    changed = True
            if body.set_max_dbs:
                v = body.max_dbs if (body.max_dbs is None or body.max_dbs >= 0) else None
                if user.max_dbs != v:
                    user.max_dbs = v
                    changed = True
            if body.membership_mode is not None:
                if user.role == "admin":
                    notes.append("超管无需组织角色")
                else:
                    summary = accounts.apply_membership_op(db, user, body.membership_mode, list(body.memberships), list(body.remove_tenant_ids))
                    if summary:
                        notes.append(summary)
                        changed = True
            if not changed:
                db.rollback()
                results.append(schemas.BulkResultRow(user_id=uid, username=user.username, status="skipped", message="、".join(notes) or "无变化"))
                continue
            db.commit()
            results.append(schemas.BulkResultRow(user_id=uid, username=user.username, status="success", message="、".join(notes) or None))
        except HTTPException as ex:
            db.rollback()
            results.append(schemas.BulkResultRow(user_id=uid, username=user.username, status="failed", message=str(ex.detail)))
        except Exception as ex:  # noqa: BLE001
            db.rollback()
            results.append(schemas.BulkResultRow(user_id=uid, username=user.username, status="failed", message=str(ex)))
    succeeded = sum(1 for r in results if r.status == "success")
    failed = sum(1 for r in results if r.status == "failed")
    skipped = sum(1 for r in results if r.status == "skipped")
    return schemas.BulkUpdateOut(results=results, succeeded=succeeded, failed=failed, skipped=skipped)


@router.post("/bulk-delete", response_model=schemas.BulkUpdateOut)
def bulk_delete(body: schemas.BulkDeleteIn, db: Session = Depends(get_db), me: User = Depends(require_admin)):
    """批量删除用户:部分成功。不能删自己;内置超管受保护。

    名下实例跟着走:默认进回收站(数据按保留天数可恢复),purge_envs=true 才连数据一并销毁。
    以前这里遇到「还有实例」的用户是直接跳过的 —— 结果是同步来的学生几乎人人有实例,整批删不动;
    而单条删除又不做这个检查,同一件事两条路径行为相反。现在两边都走 accounts.delete_with_envs。"""
    if not body.user_ids:
        raise HTTPException(400, "没有选择用户")
    results: list[schemas.BulkResultRow] = []
    for uid in dict.fromkeys(body.user_ids):
        user = db.get(User, uid)
        if not user:
            results.append(schemas.BulkResultRow(user_id=uid, username=str(uid), status="skipped", message="用户不存在"))
            continue
        if uid == me.id:
            results.append(schemas.BulkResultRow(user_id=uid, username=user.username, status="failed", message="不能删除自己"))
            continue
        if is_root(user):
            results.append(schemas.BulkResultRow(user_id=uid, username=user.username, status="skipped", message="内置超级管理员受保护,未删除"))
            continue
        try:
            envs = accounts.delete_with_envs(db, user, purge_envs=body.purge_envs)
            db.commit()
            note = None
            if envs:
                note = "%s 个实例已%s" % (len(envs), "销毁" if body.purge_envs else "移入回收站")
            results.append(schemas.BulkResultRow(user_id=uid, username=user.username, status="success", message=note))
        except Exception as ex:  # noqa: BLE001
            db.rollback()
            results.append(schemas.BulkResultRow(user_id=uid, username=user.username, status="failed", message=str(ex)))
    succeeded = sum(1 for r in results if r.status == "success")
    failed = sum(1 for r in results if r.status == "failed")
    skipped = sum(1 for r in results if r.status == "skipped")
    return schemas.BulkUpdateOut(results=results, succeeded=succeeded, failed=failed, skipped=skipped)
