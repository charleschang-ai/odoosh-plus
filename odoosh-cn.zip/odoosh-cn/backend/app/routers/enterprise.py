"""企业版代码来源查询 / 探测(供创建实例对话框与设置页使用)。"""

import os
import re
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from .. import authz
from ..auth import get_current_user
from ..db import get_db
from ..models import User
from ..models_git import Repository
from ..services import enterprise as entsvc

router = APIRouter(prefix="/api/enterprise", tags=["enterprise"])


def _repo_brief(r: Repository | None, user: User) -> dict | None:
    """仓库摘要。企业版仓库仅接入者/超管可见地址;其他人只给名称与平台。"""
    if not r:
        return None
    visible = authz.is_superadmin(user) or (r.scope != "platform" and r.created_by == user.id)
    return {"id": r.id, "name": r.name, "url": r.url if visible else None, "provider": r.provider, "scope": r.scope, "tenant_id": r.tenant_id}


@router.get("/platform-status")
def platform_status(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """超级管理员是否已提供平台共享企业版仓库(供接入企业版仓库时提醒;不泄露地址)。"""
    plat = entsvc.platform_repo(db)
    return {"exists": bool(plat), "provider": plat.provider if plat else None, "name": plat.name if (plat and authz.is_superadmin(user)) else None}


@router.get("/source")
def source(tenant_id: int, probe: bool = False, version: str | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """创建企业版实例时,该版本代码是否就绪。

    新实例统一走离线企业版目录 offline/enterprise/<版本>/(超管上传/放置,全平台按版本共享一套)。
    返回 {offline, error}:offline=该版本代码已就绪。
    """
    authz.require_tenant_role(db, user, tenant_id, "tester")
    from ..services import offline_enterprise

    # 就绪 = 统一目录已有该版本,或旧 git 检出里有(创建时会自动复制进统一目录,不会失败)
    offline_ok = bool(version) and (
        offline_enterprise.resolve_for(str(version)) is not None or offline_enterprise.seedable(str(version))
    )
    return {
        "source": "offline" if offline_ok else "", "repo": None, "platform_available": False,
        "versions": None, "local": [], "tried": [], "offline": offline_ok,
        "error": None if offline_ok else f"未找到 {version} 版本的企业版代码。请超级管理员在「离线企业版代码」里上传该版本后再创建。",
    }


@router.post("/repos/{repo_id}/probe")
def probe_repo(repo_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """探测某仓库的版本分支(用于「测试连接」展示可建哪些版本)。"""
    from .repos import _get_repo

    r = _get_repo(repo_id, db, user)  # 与仓库页同一可见性规则:接入者本人 / 超管;平台共享对开发者可见
    try:
        info = entsvc.probe(r.url, entsvc.repo_token(db, r))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, str(e))
    return {"versions": {v: sha[:12] for v, sha in info["versions"].items()}, "branch_count": info["branch_count"],
            "local": [{"version": x["version"], "commit": x["commit"][:12]} for x in entsvc.local_versions(r)]}


@router.get("/repos/{repo_id}/import-info")
def import_info(repo_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """手动导入企业版代码的说明:镜像路径、已导入版本、可复制的命令。涉及宿主机路径与服务器操作,仅超管。"""
    authz.require_superadmin(user)
    from .repos import _get_repo

    r = _get_repo(repo_id, db, user)
    if not r.is_enterprise:
        raise HTTPException(400, "该仓库未标记为企业版")
    from ..services import git as gitsvc

    md = entsvc.to_host_path(entsvc.mirror_dir(r))
    exists = os.path.isdir(entsvc.mirror_dir(r))
    url = gitsvc.parse_repo_url(r.url)["https_url"]
    proxies = gitsvc.github_proxies()
    fetch_url = f"{proxies[0]}/{url}" if proxies and "github.com" in url else url
    auth_url = fetch_url.replace("https://github.com/", "https://x-access-token:<令牌>@github.com/")
    cmds = []
    if not exists:
        cmds.append({"title": "1. 初始化镜像(首次)", "cmd": f"git init --bare {md}"})
    cmds.append({"title": "方式 A:在服务器上直接拉取(走加速代理;私有仓库把 <令牌> 换成访问令牌)",
                 "cmd": f"git --git-dir {md} fetch --depth 1 --progress '{auth_url}' '+refs/heads/<版本>.0:refs/heads/<版本>.0'"})
    cmds.append({"title": "方式 B:在能访问 GitHub 的电脑上浅克隆,拷到服务器后本地导入",
                 "cmd": (f"git clone --depth 1 -b <版本>.0 {url} ent-code\n"
                         f"scp -r ent-code <服务器>:/tmp/\n"
                         f"git --git-dir {md} fetch /tmp/ent-code '+refs/heads/<版本>.0:refs/heads/<版本>.0'")})
    return {
        "mirror_path": md, "exists": exists,
        "mirror_versions": {v: sha[:12] for v, sha in entsvc.mirror_versions(r).items()},
        "local": [{"version": x["version"], "commit": x["commit"][:12]} for x in entsvc.local_versions(r)],
        "commands": cmds,
    }


@router.post("/repos/{repo_id}/pull")
def pull_latest(repo_id: int, version: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """在线更新:探测远端 <version>.0 最新 commit 并后台拉取(创建实例默认本地优先,不追最新;由此手动更新)。仅超管。"""
    import logging
    import re
    import threading

    authz.require_superadmin(user)
    from .repos import _get_repo

    r = _get_repo(repo_id, db, user)
    if not r.is_enterprise:
        raise HTTPException(400, "该仓库未标记为企业版")
    if not re.fullmatch(r"\d{2}", str(version)):
        raise HTTPException(400, "版本号应形如 19")
    log2 = logging.getLogger("odoosh.enterprise")

    def _run():
        from ..db import SessionLocal

        with SessionLocal() as db2:
            r2 = db2.get(Repository, repo_id)
            try:
                path, sha = entsvc.ensure_code(db2, r2, str(version), say=log2.info, prefer_local=False)
                log2.info("在线更新完成:%s → %s", path, sha[:12])
            except Exception:  # noqa: BLE001
                log2.exception("在线更新企业版代码失败(仓库 %s,版本 %s)", repo_id, version)

    threading.Thread(target=_run, daemon=True, name=f"ent-pull-{repo_id}").start()
    return {"started": True, "message": "已开始后台拉取,完成后可在「测试连接」或本对话框中查看"}


@router.post("/gc")
def gc(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    authz.require_superadmin(user)
    return {"removed": entsvc.gc_unreferenced(db)}


# ---------------------------------------------------------------- 平台离线企业版代码(内网:放目录即用)
@router.get("/offline")
def list_offline(user: User = Depends(get_current_user)):
    """扫描平台离线企业版目录:宿主机拷贝路径 + 各版本是否合法、模块数。仅超管。"""
    authz.require_superadmin(user)
    from ..services import offline_enterprise

    return {
        "host_dir": offline_enterprise.host_base_dir(),
        "items": offline_enterprise.scan(),
        # 旧 git 检出里有、统一目录还没有的版本:创建时会自动导入,也可在卡片上手动导入
        "pending": [{"version": v, "commit": c} for v, c in sorted(offline_enterprise.seedable_versions().items(), reverse=True)],
    }


@router.post("/offline/seed")
def seed_offline(version: str, user: User = Depends(get_current_user)):
    """手动把旧 git 检出里的某版本复制进统一目录(与创建时的自动导入同一逻辑)。仅超管。"""
    authz.require_superadmin(user)
    from ..services import offline_enterprise

    got = offline_enterprise.seed_from_legacy(str(version))
    if not got:
        raise HTTPException(400, "没有可导入的已有代码,或目标版本目录已有内容(请先清理)")
    return {"path": got}


@router.put("/offline/upload")
async def upload_offline(request: Request, version: str, user: User = Depends(get_current_user)):
    """超管上传企业版 addons zip → 解压合并进 offline/enterprise/<版本>/(按模块新增/更新)。请求体即 zip。"""
    authz.require_superadmin(user)
    if not re.fullmatch(r"\d{2}(?:\.0)?", str(version)):
        raise HTTPException(400, "版本号应形如 19 或 19.0")
    from starlette.concurrency import run_in_threadpool

    from ..config import settings
    from ..services import offline_enterprise
    from ..services.backup import check_free_space

    tmp_dir = os.path.join(settings.data_dir, "offline")
    os.makedirs(tmp_dir, exist_ok=True)
    # 临时文件名带随机后缀:同版本被并发上传时各写各的,不会互相覆盖
    tmp_zip = os.path.join(tmp_dir, f".ent-upload-{re.sub(r'[^0-9.]', '', version)}-{uuid4().hex[:8]}.zip")
    # 先按 Content-Length 预检空间:解压要再占一份,zip 本身 + 解压产物约 2 倍
    try:
        declared = int(request.headers.get("content-length") or 0)
    except ValueError:
        declared = 0
    if declared:
        try:
            check_free_space(tmp_dir, declared * 2 + (256 << 20), "企业版代码目录")
        except RuntimeError as ex:
            raise HTTPException(413, str(ex))

    def _cleanup() -> None:
        try:
            os.remove(tmp_zip)
        except OSError:
            pass

    total = 0
    try:
        with open(tmp_zip, "wb") as f:
            async for chunk in request.stream():
                if chunk:
                    total += len(chunk)
                    f.write(chunk)
    except Exception as ex:  # noqa: BLE001  客户端中途断开 / 磁盘写满:别把半截文件留在磁盘上
        _cleanup()
        raise HTTPException(400, f"接收上传数据失败:{ex}")
    if total == 0:
        _cleanup()
        raise HTTPException(400, "空文件")
    try:
        # 解压 + 逐模块落盘是纯同步的重活(GB 级 zip 要几十秒到几分钟)。放线程池,
        # 否则整个事件循环被占住,期间所有人的所有请求都卡死。
        summary = await run_in_threadpool(offline_enterprise.upload_zip, version, tmp_zip)  # 内部会删 tmp_zip
    except ValueError as ex:
        _cleanup()
        raise HTTPException(400, str(ex))
    except Exception as ex:  # noqa: BLE001
        _cleanup()
        raise HTTPException(500, f"导入企业版代码失败:{ex}")
    # in_use:覆盖了同名模块、且有实例正挂载该版本 → 前端提示这些实例需重启并升级模块
    return {"version": version, "new": summary["new"], "updated": summary["updated"],
            "in_use": summary.get("in_use") or []}


@router.delete("/offline/{name}")
def delete_offline(name: str, force: bool = False, user: User = Depends(get_current_user)):
    """删除某版本离线企业版代码目录(整棵树)。仅超管。
    有实例正挂载该目录时默认拒绝(删了这些实例立刻读不到代码);确认后可 force=true 强删。"""
    authz.require_superadmin(user)
    from ..services import offline_enterprise

    try:
        ok = offline_enterprise.delete_version(name, force=force)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not ok:
        raise HTTPException(404, "目录不存在")
    return {"deleted": True}
