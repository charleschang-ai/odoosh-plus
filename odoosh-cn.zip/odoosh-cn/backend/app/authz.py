"""统一鉴权(仿 odoo.sh):

平台级:超级管理员(users.role == "admin")可做一切。
组织级:memberships.role ∈ owner(组织管理员)> developer(开发者)> tester(测试者)。
实例动作按「角色 × 实例类型(production/staging/dev)」矩阵判定,见 ENV_MATRIX。
"""

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import Environment, EnvironmentAcl, Membership, Tenant, User

ROLES = ("owner", "developer", "tester")
# 实例上的有效角色除组织角色外,还有授权名单的三档:viewer(可访问)< operator(可操作)< owner(可管理 = 拥有者同权)
ROLE_RANK = {"tester": 1, "viewer": 1, "developer": 2, "operator": 2, "owner": 3}
ROLE_LABEL = {"owner": "组织管理员", "developer": "开发者", "tester": "测试者", "viewer": "可访问成员", "operator": "可操作成员"}

# 实例动作
ENV_ACTIONS = (
    "view", "open", "logs", "stats",
    "create", "edit", "start", "stop", "restart", "delete",
    "deploy", "backup", "restore", "clone", "shell",
    "secrets",  # 查看实例凭据(Odoo admin 口令等)
)

# 矩阵:role -> {action: allowed_kinds},allowed_kinds 为 "*"(全部类型)或 kinds 集合;缺省即不允许
NONPROD = frozenset({"staging", "dev"})
ALL = "*"
ENV_MATRIX: dict[str, dict[str, object]] = {
    "owner": {a: ALL for a in ENV_ACTIONS},
    "developer": {
        "view": ALL, "open": ALL, "logs": ALL, "stats": ALL,
        "create": NONPROD, "edit": NONPROD, "start": NONPROD, "stop": NONPROD, "restart": NONPROD, "delete": NONPROD,
        "deploy": NONPROD, "backup": ALL, "restore": NONPROD, "clone": ALL, "shell": NONPROD,
        "secrets": NONPROD,
    },
    "tester": {"view": ALL, "open": NONPROD},
    # ---- 实例授权名单三档(与组织角色无关,只作用于被授权的那个实例 / 项目)----
    # 可访问:打开 Odoo、看日志与监控。不能改任何设置。
    "viewer": {"view": ALL, "open": ALL, "logs": ALL, "stats": ALL},
    # 可操作:日常运维——启停重启、部署、备份 / 恢复、克隆、Shell、看凭据;
    #        但不能编辑设置、不能删除、不能改名单;对生产实例只放行「启动 / 重启 / 备份 / 克隆」等非破坏性动作。
    "operator": {
        "view": ALL, "open": ALL, "logs": ALL, "stats": ALL,
        "start": ALL, "restart": ALL, "backup": ALL, "clone": ALL,
        "stop": NONPROD, "deploy": NONPROD, "restore": NONPROD, "shell": NONPROD,
        # 不含 secrets(Odoo admin / master 口令只有「可管理」及以上可见)、edit、delete、create
    },
    # 可管理:等同拥有者(owner 行)
}


def is_superadmin(user: User) -> bool:
    return user.role == "admin"


def tenant_active(db: Session, tenant_id: int | None) -> bool:
    """组织是否启用。停用的组织(Tenant.is_active=False)对非超管等同不存在:不能登录到其资源、不能操作其实例。"""
    if tenant_id is None:
        return True
    return bool(db.scalar(select(Tenant.is_active).where(Tenant.id == tenant_id)))


def tenant_role(db: Session, user: User, tenant_id: int) -> str | None:
    """用户在该组织的角色;超管视为 owner;无成员关系或组织已停用返回 None。"""
    if is_superadmin(user):
        return "owner"
    if not tenant_active(db, tenant_id):
        return None
    m = db.scalar(select(Membership).where(Membership.user_id == user.id, Membership.tenant_id == tenant_id))
    return m.role if m else None


def accessible_tenant_ids(db: Session, user: User) -> list[int] | None:
    """None = 全部(超管);否则为有成员关系的组织 id 列表。"""
    if is_superadmin(user):
        return None
    return list(db.scalars(select(Membership.tenant_id).where(Membership.user_id == user.id)).all())


def role_map(db: Session, user: User) -> dict[int, str]:
    """一次查询拿到用户在所有组织的角色 {tenant_id: role}(超管:对任意 tenant 返回 owner 的 defaultdict)。列表类接口用它避免 N+1。"""
    if is_superadmin(user):
        return _AllOwner()
    rows = db.execute(
        select(Membership.tenant_id, Membership.role).join(Tenant, Tenant.id == Membership.tenant_id)
        .where(Membership.user_id == user.id, Tenant.is_active.is_(True))
    ).all()
    return {tid: role for tid, role in rows}


class _AllOwner(dict):
    """超管:任何 tenant 都是 owner(get / [] 都返回 owner;defaultdict 的 get 不会触发默认值,故自定义)。"""

    def get(self, key, default=None):  # noqa: D401
        return "owner"

    def __getitem__(self, key):
        return "owner"

    def __contains__(self, key):
        return True


def has_tenant_role(db: Session, user: User, tenant_id: int, minimum: str) -> bool:
    r = tenant_role(db, user, tenant_id)
    return bool(r) and ROLE_RANK[r] >= ROLE_RANK[minimum]


def require_tenant_role(db: Session, user: User, tenant_id: int, minimum: str = "tester") -> str:
    r = tenant_role(db, user, tenant_id)
    if not r:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "无权访问该组织")
    if ROLE_RANK[r] < ROLE_RANK[minimum]:
        raise HTTPException(status.HTTP_403_FORBIDDEN, f"需要{ROLE_LABEL[minimum]}及以上权限")
    return r


def check_tenant_access(user: User, tenant_id: int, minimum: str = "developer") -> str:
    """无 db 参数版本(供旧代码的 helper 直接调用),内部自开会话。"""
    from .db import SessionLocal

    with SessionLocal() as db:
        return require_tenant_role(db, user, tenant_id, minimum)


def require_superadmin(user: User) -> None:
    if not is_superadmin(user):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "需要超级管理员权限")


def env_allowed(role: str | None, action: str, kind: str) -> bool:
    if not role:
        return False
    allowed = ENV_MATRIX.get(role, {}).get(action)
    if allowed is None:
        return False
    return allowed == ALL or kind in allowed


# ---------------- 实例级访问控制(仿 odoo.sh:创建者 + 授权名单) ----------------
ACL_LEVELS = ("view", "operate", "manage")
ACL_LEVEL_ROLE = {"view": "viewer", "operate": "operator", "manage": "owner"}
ACL_LEVEL_LABEL = {"view": "可访问", "operate": "可操作", "manage": "可管理"}


def acl_root_id(env: Environment) -> int:
    """授权名单挂在项目根实例上(项目内所有环境共享一份名单)。"""
    return env.project_id or env.id


def env_owner_id(db: Session, env: Environment) -> int | None:
    """实例拥有者:自身 owner_user_id;派生环境缺省时沿用项目根实例的拥有者。"""
    if env.owner_user_id is not None or not env.project_id:
        return env.owner_user_id
    root = db.get(Environment, env.project_id)
    return root.owner_user_id if root else None


def purge_env_acl(db: Session, user_id: int, tenant_id: int) -> int:
    """用户不再属于某组织时,清掉他在该组织所有实例上的授权条目(返回清理条数)。
    与 env_role 里的成员前置校验互为双保险:一个防残留数据、一个防判定放行。调用方负责 commit。"""
    from .models import Environment, EnvironmentAcl

    ids = list(db.scalars(select(Environment.id).where(Environment.tenant_id == tenant_id)).all())
    if not ids:
        return 0
    res = db.execute(EnvironmentAcl.__table__.delete().where(
        EnvironmentAcl.user_id == user_id, EnvironmentAcl.environment_id.in_(ids)))
    return res.rowcount or 0


def env_role(db: Session, user: User, env: Environment) -> str | None:
    """用户在该实例上的有效角色(套用 ENV_MATRIX):
    超管 / 拥有者 → owner;授权名单 → 按级别映射;其余 → None(不可见)。组织角色只决定「能否创建实例」与「能否被加入名单」。"""
    if is_superadmin(user):
        return "owner"
    if not tenant_active(db, env.tenant_id):
        return None
    if tenant_role(db, user, env.tenant_id) is None:
        return None  # 已不是该组织成员:拥有者身份与授权名单一律失效(防移出组织后 ACL 残留导致跨组织访问)
    owner_id = env_owner_id(db, env)
    if owner_id == user.id:
        return "owner"
    level = db.scalar(select(EnvironmentAcl.level).where(EnvironmentAcl.environment_id == acl_root_id(env), EnvironmentAcl.user_id == user.id))
    if level:
        return ACL_LEVEL_ROLE.get(level, "viewer")
    return None  # 不在名单、不是拥有者 → 不可见(无拥有者的旧实例启动时已归到内置超管名下)


def env_roles_bulk(db: Session, user: User, envs: list[Environment]) -> dict[int, str | None]:
    """列表接口用:一次查询算出每个实例上的角色(避免 N+1)。"""
    if is_superadmin(user):
        return {e.id: "owner" for e in envs}
    by_id = {e.id: e for e in envs}
    root_ids = {acl_root_id(e) for e in envs}
    # 派生环境的根可能不在本次列表里,补查其 owner
    missing = [rid for rid in root_ids if rid not in by_id]
    root_owner = {e.id: e.owner_user_id for e in envs if not e.project_id}
    if missing:
        for rid, oid in db.execute(select(Environment.id, Environment.owner_user_id).where(Environment.id.in_(missing))).all():
            root_owner[rid] = oid
    levels = dict(db.execute(select(EnvironmentAcl.environment_id, EnvironmentAcl.level).where(EnvironmentAcl.user_id == user.id, EnvironmentAcl.environment_id.in_(root_ids or {-1}))).all())
    inactive = set(db.scalars(select(Tenant.id).where(Tenant.id.in_({e.tenant_id for e in envs} or {-1}), Tenant.is_active.is_(False))).all())
    my_tenants = set(role_map(db, user).keys())  # 仅这些组织的实例才可能有权限(与 env_role 一致)
    out: dict[int, str | None] = {}
    for e in envs:
        if e.tenant_id in inactive or e.tenant_id not in my_tenants:
            out[e.id] = None
            continue
        owner_id = e.owner_user_id if (e.owner_user_id is not None or not e.project_id) else root_owner.get(e.project_id)
        if owner_id == user.id:
            out[e.id] = "owner"
            continue
        lv = levels.get(acl_root_id(e))
        if lv:
            out[e.id] = ACL_LEVEL_ROLE.get(lv, "viewer")
            continue
        out[e.id] = None
    return out


def can_env(db: Session, user: User, env: Environment, action: str) -> bool:
    return env_allowed(env_role(db, user, env), action, env.kind)


def check_env(db: Session, user: User, env: Environment, action: str) -> None:
    role = env_role(db, user, env)
    if not role:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "无权访问该实例(不在授权名单内)" if env_owner_id(db, env) is not None else "无权访问该组织")
    if not env_allowed(role, action, env.kind):
        kind_label = {"production": "生产", "staging": "测试", "dev": "开发"}.get(env.kind, env.kind)
        raise HTTPException(status.HTTP_403_FORBIDDEN, f"{ROLE_LABEL[role]}无权对{kind_label}实例执行此操作")


def check_env_create(db: Session, user: User, tenant_id: int, kind: str) -> None:
    role = tenant_role(db, user, tenant_id)
    if not role:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "无权访问该组织")
    if not env_allowed(role, "create", kind):
        raise HTTPException(status.HTTP_403_FORBIDDEN, f"{ROLE_LABEL[role]}无权创建{'生产' if kind == 'production' else '该类型'}实例")


def owned_env_count(db: Session, owner_id: int) -> int:
    """用户作为拥有者(owner_user_id)的实例数,不含回收站里的。只按拥有者计,不按有权访问的实例计。"""
    from sqlalchemy import func

    return int(db.scalar(select(func.count(Environment.id)).where(Environment.owner_user_id == owner_id, Environment.deleted_at.is_(None))) or 0)


def check_env_quota(db: Session, owner: User | None, adding: int = 1) -> None:
    """实例配额(User.max_envs):None = 不限;0 = 不能创建;超管不受限。
    创建 / 从回收站恢复 / 在项目里派生分支环境时调用,owner 为将成为拥有者的用户(不一定是当前操作者)。"""
    if owner is None or is_superadmin(owner) or owner.max_envs is None:
        return
    if owner.max_envs <= 0:
        raise HTTPException(status.HTTP_403_FORBIDDEN, f"用户「{owner.username}」未被允许创建实例(配额为 0),请联系超级管理员")
    n = owned_env_count(db, owner.id)
    if n + adding > owner.max_envs:
        raise HTTPException(status.HTTP_403_FORBIDDEN, f"用户「{owner.username}」的实例数已达上限({n}/{owner.max_envs}),请先彻底删除不用的实例或联系超级管理员调整配额")


def owned_db_count(db: Session, user: User) -> int:
    """用户已创建的附加数据库数(跨实例,按 created_by = 用户名计;删除中的不算)。"""
    from sqlalchemy import func

    from .models_db import EnvironmentDatabase

    return int(db.scalar(select(func.count(EnvironmentDatabase.id)).where(EnvironmentDatabase.created_by == user.username, EnvironmentDatabase.status != "dropping")) or 0)


def db_quota_state(db: Session, user: User) -> dict:
    """附加数据库配额(User.max_dbs):{limit, used, allowed, reason}。None = 不限;0 = 不能创建;超管不受限。"""
    if is_superadmin(user) or user.max_dbs is None:
        return {"limit": None, "used": owned_db_count(db, user), "allowed": True, "reason": None}
    used = owned_db_count(db, user)
    if user.max_dbs <= 0:
        return {"limit": 0, "used": used, "allowed": False, "reason": "你的账号未被允许创建附加数据库(配额为 0),请联系平台管理员"}
    if used >= user.max_dbs:
        return {"limit": user.max_dbs, "used": used, "allowed": False, "reason": f"你创建的附加数据库已达上限({used}/{user.max_dbs}),请先删除不用的库或联系平台管理员调整配额"}
    return {"limit": user.max_dbs, "used": used, "allowed": True, "reason": None}


def check_db_quota(db: Session, user: User) -> None:
    st = db_quota_state(db, user)
    if not st["allowed"]:
        raise HTTPException(status.HTTP_403_FORBIDDEN, st["reason"])


def is_env_owner(db: Session, user: User, env: Environment) -> bool:
    """实例拥有者(创建者)或超管。删除 / 彻底删除 / 恢复 / 改授权名单 / 转让 只允许他们(「可管理」成员不行)。"""
    return is_superadmin(user) or env_owner_id(db, env) == user.id


def check_env_owner(db: Session, user: User, env: Environment, what: str = "此操作") -> None:
    if not is_env_owner(db, user, env):
        raise HTTPException(status.HTTP_403_FORBIDDEN, f"只有实例拥有者(创建者)或超级管理员可以{what}")


def check_project_create(db: Session, user: User, root: Environment, kind: str) -> None:
    """在某项目里按分支新建 / 改档为 kind 环境:按用户在该项目(根实例)上的有效角色判定 create 动作,
    同时仍需具备组织层面的创建资格(组织角色矩阵),二者都满足才允许。"""
    role = env_role(db, user, root)
    if not role:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "无权访问该项目(不在授权名单内)")
    if not env_allowed(role, "create", kind):
        raise HTTPException(status.HTTP_403_FORBIDDEN, f"{ROLE_LABEL.get(role, role)}无权在本项目里创建{'生产' if kind == 'production' else '该类型'}环境")
    check_env_create(db, user, root.tenant_id, kind)


def shell_allowed(db: Session, user: User, env: Environment) -> bool:
    """Shell = 用户级开关(超管设置,超管自身恒真)× 角色矩阵(owner 全部;developer 开发/测试)。"""
    if not (is_superadmin(user) or getattr(user, "shell_enabled", False)):
        return False
    return can_env(db, user, env, "shell")


def env_permissions(role: str | None, kind: str) -> dict[str, bool]:
    """给前端用:该角色对该类型实例的动作权限表。"""
    return {a: env_allowed(role, a, kind) for a in ENV_ACTIONS}


def can_see_env_data(db: Session, user: User, env: Environment | None, tenant_id: int, minimum: str = "developer") -> bool:
    """备份 / 恢复记录等“属于某实例的数据”是否可见:超管恒可;实例存在 → 实例级角色 ≥ minimum;
    实例已不存在(孤儿备份)→ 仅组织管理员。"""
    if is_superadmin(user):
        return True
    if env is not None:
        return ROLE_RANK.get(env_role(db, user, env) or "", 0) >= ROLE_RANK[minimum]
    return tenant_role(db, user, tenant_id) == "owner"
