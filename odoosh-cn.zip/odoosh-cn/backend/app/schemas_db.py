"""附加数据库相关 schema(独立文件,避免与 schemas.py 并行改动冲突)。"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class DatabaseOut(BaseModel):
    """实例里的一个库:主库(id=None, is_primary=True)或附加库。"""

    id: int | None = None
    environment_id: int
    is_primary: bool = False
    name: str  # 主库显示为「主库」;附加库为短名
    db_name: str
    admin_login: str | None = None  # 管理员登录名(原生建库时填的邮箱;None = admin)
    domain: str | None = None
    url: str | None = None
    status: str = "ready"  # creating | ready | failed | dropping | restoring
    status_message: str | None = None
    progress: int = 0
    source: str | None = None
    source_ref: str | None = None
    expires_at: datetime | None = None
    size_bytes: int | None = None
    created_by: str | None = None
    created_at: datetime | None = None


class DatabaseListOut(BaseModel):
    items: list[DatabaseOut]
    # 能力 / 配额:enabled(实例具备附加库能力)、allowed_now(此刻还能建)、reason(不能建的原因)、limit / used、tenant_limit / tenant_used
    enabled: bool
    allowed_now: bool
    reason: str | None = None
    limit: int
    used: int
    tenant_limit: int | None = None
    tenant_used: int = 0
    user_limit: int | None = None  # 当前用户的附加库配额(None = 不限)
    user_used: int = 0
    code_summary: str | None = None  # 「本实例代码」一行说明,所有库共用


class DatabaseCreate(BaseModel):
    """与 Odoo 原生「创建数据库」表单一致的字段(source=empty 时生效)+ 平台自己的选项。"""

    name: str = Field(min_length=1, max_length=20)  # 数据库名(短名;实际库名 <主库>_<name>)
    # 邮箱 / 登录名,默认 admin。限制字符集:该值会回显在「查看管理员密码」等界面,防止注入 HTML。
    login: str | None = Field(default=None, max_length=128, pattern=r"^[A-Za-z0-9._%+@-]*$")
    password: str | None = Field(default=None, max_length=128)  # 管理员密码,空 = 自动生成
    phone: str | None = Field(default=None, max_length=64)
    lang: str | None = Field(default=None, max_length=16)  # 如 zh_CN
    country_code: str | None = Field(default=None, max_length=8)  # 如 CN
    demo: bool = False  # 演示数据
    source: str = "empty"  # empty(原生建库)| template | clone | backup
    source_ref: str | None = None  # clone:源库名(主库名或附加库库名);backup:备份 id
    neutralize: bool = True  # clone / backup 时是否中性化
    expire_days: int | None = None  # None = 平台默认(db.extra_expire_days);0 = 不过期

    @field_validator("name", mode="before")
    @classmethod
    def _norm(cls, v):
        return v.strip().lower() if isinstance(v, str) else v

    @field_validator("source")
    @classmethod
    def _src(cls, v):
        if v not in ("empty", "template", "clone", "backup"):
            raise ValueError("无效的数据来源")
        return v


class DatabaseUpdate(BaseModel):
    expire_days: int | None = None  # 0 = 不过期;N = 从现在起 N 天


class LicenseUpdate(BaseModel):
    database_id: int | None = None   # None = 主库
    expiration_date: str             # YYYY-MM-DD(按 Odoo 习惯写入 "YYYY-MM-DD 23:59:59")


class DatabaseDeleteIn(BaseModel):
    confirm_name: str
    backup: bool | None = None  # None = 按平台设置 db.backup_before_drop
