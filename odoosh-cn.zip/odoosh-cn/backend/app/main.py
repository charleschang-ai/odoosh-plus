import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy import select
from sqlalchemy.exc import OperationalError

from .auth import hash_password
import os

from .config import settings
from .db import Base, SessionLocal, engine
from .models import User
from .routers import auth, environments, images, repos, settings as settings_router, system, tenants, users
from . import models_git  # noqa: F401 — 注册 Git 相关表,供 create_all 建表
from . import models_backup  # noqa: F401 — 注册备份相关表,供 create_all 建表
from . import models_deploy  # noqa: F401 — 部署记录表
from . import models_metrics  # noqa: F401 — 资源指标表
from . import models_shell  # noqa: F401 — Shell 会话审计表
from . import models_db  # noqa: F401 — 附加数据库表(一个实例多个库)
from . import models_ai  # noqa: F401 — AI 助手:配置/会话/消息/审计/用量
from . import models_bulk  # noqa: F401 — 批量作业表(BulkJob / BulkJobItem)
from . import models_code  # noqa: F401 — 在线代码编辑审计表(CodeEdit)
from . import models_token  # noqa: F401 — 接入令牌表(ApiToken)
from .routers import backups
from .routers import enterprise as enterprise_router
from .routers import projects as projects_router
from .routers import sso as sso_router
from .routers import wake as wake_router
from .routers import shell as shell_router
from .routers import databases as databases_router
from .routers import backup_targets as backup_targets_router
from .routers import ai as ai_router
from .routers import bulk as bulk_router
from .routers import tokens as tokens_router
from .routers import ext as ext_router
from .services import project as project_service
from .services import backup as backup_service
from .services import nginx as nginx_service
from .services import orchestrator as orchestrator_service

log = logging.getLogger("odoosh")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


def _wait_for_db(retries: int = 30):
    for i in range(retries):
        try:
            with engine.connect():
                return
        except OperationalError:
            log.info("等待数据库就绪 (%s/%s)...", i + 1, retries)
            time.sleep(2)
    raise RuntimeError("数据库不可用")


def _auto_add_columns():
    """轻量迁移:为已有表补齐模型里新增的列(仅 ADD COLUMN)。正式的 Alembic 迁移后续引入。"""
    from sqlalchemy import inspect, text

    insp = inspect(engine)
    with engine.begin() as conn:
        for table in Base.metadata.sorted_tables:
            if not insp.has_table(table.name):
                continue
            existing = {c["name"] for c in insp.get_columns(table.name)}
            for col in table.columns:
                if col.name in existing:
                    continue
                coltype = col.type.compile(dialect=engine.dialect)
                default = ""
                if col.default is not None and getattr(col.default, "arg", None) is not None and not callable(col.default.arg):
                    v = col.default.arg
                    default = f" DEFAULT {v!r}" if isinstance(v, str) else f" DEFAULT {v}"
                conn.execute(text(f'ALTER TABLE "{table.name}" ADD COLUMN "{col.name}" {coltype}{default}'))
                log.info("表 %s 新增列 %s", table.name, col.name)
                if col.index:  # 模型声明了 index=True 的新列,补索引(以前升级安装的 project_id/owner_user_id 等一直没索引)
                    conn.execute(text(f'CREATE INDEX IF NOT EXISTS ix_{table.name}_{col.name} ON "{table.name}" ("{col.name}")'))


def _backfill_env_owner():
    """实例级访问控制上线后的一次性迁移:没有拥有者的旧实例归到内置超级管理员名下(否则任何人都看不到它们)。幂等。"""
    from sqlalchemy import select, update

    from .models import Environment, User

    with SessionLocal() as db:
        root = db.scalar(select(User).where(User.username == settings.admin_user))
        if not root:
            return
        n = db.execute(update(Environment).where(Environment.owner_user_id.is_(None)).values(owner_user_id=root.id)).rowcount
        db.commit()
        if n:
            log.info("已把 %s 个无拥有者的实例归到内置管理员 %s 名下", n, root.username)


def _backfill_project_groups():
    """一次性迁移(幂等):同组织里绑定同一仓库的多个根实例合并成一个项目——
    根 = 生产环境(若有)否则最早创建的那个;其余变成它的分支环境(project_id 指向根),它们原有的子环境也一并挂到新根。
    多个生产环境指向同一仓库时不合并(各自保留),避免违反“一个项目一个生产”。"""
    from sqlalchemy import select

    from .models import Environment
    from .services import git as gitsvc

    with SessionLocal() as db:
        roots = db.scalars(select(Environment).where(Environment.project_id.is_(None), Environment.deleted_at.is_(None), Environment.repo_url.is_not(None)).order_by(Environment.id)).all()
        groups: dict[tuple[int, str], list] = {}
        for e in roots:
            key = gitsvc.normalize_repo_url(e.repo_url)
            if key:
                groups.setdefault((e.tenant_id, key), []).append(e)
        n = 0
        for (_tid, _key), envs in groups.items():
            if len(envs) < 2:
                continue
            prods = [e for e in envs if e.kind == "production"]
            if len(prods) > 1:
                continue
            root = prods[0] if prods else envs[0]
            branches = {root.branch or ""}
            for e in envs:
                if e is root:
                    continue
                if (e.branch or "") in branches:
                    continue  # 同分支的另一个环境:保持独立,不合并(避免违反“一个分支一个环境”)
                branches.add(e.branch or "")
                e.project_id = root.id
                for c in db.scalars(select(Environment).where(Environment.project_id == e.id)).all():
                    c.project_id = root.id
                n += 1
        if n:
            db.commit()
            log.info("已把 %s 个同仓库的实例合并为分支环境(一个仓库 = 一个项目)", n)


def _widen_secret_columns():
    """加密后的凭据列比原 String(n) 长:统一改为 TEXT(PostgreSQL 无损、幂等)。"""
    from sqlalchemy import inspect, text

    if engine.dialect.name != "postgresql":
        return
    insp = inspect(engine)
    targets = {"tenants": ["pg_password"], "environments": ["db_password", "admin_password"],
               "git_accounts": ["access_token", "refresh_token"], "repositories": ["token", "webhook_secret"]}
    with engine.begin() as conn:
        for table, cols in targets.items():
            if not insp.has_table(table):
                continue
            types = {c["name"]: str(c["type"]).upper() for c in insp.get_columns(table)}
            for col in cols:
                if col in types and types[col] != "TEXT":
                    conn.execute(text(f'ALTER TABLE "{table}" ALTER COLUMN "{col}" TYPE TEXT'))
                    log.info("列 %s.%s 改为 TEXT", table, col)


def _ensure_indexes():
    """create_all 不会给已有表补索引;这里用 IF NOT EXISTS 补齐常用索引(幂等)。"""
    from sqlalchemy import text

    stmts = [
        "CREATE INDEX IF NOT EXISTS ix_environments_tenant_id ON environments (tenant_id)",
        "CREATE INDEX IF NOT EXISTS ix_environments_status ON environments (status)",
        "CREATE INDEX IF NOT EXISTS ix_environments_expires ON environments (status, expires_at)",
        "CREATE INDEX IF NOT EXISTS ix_backups_tenant_kind_created ON backups (tenant_id, kind, created_at)",
        "CREATE INDEX IF NOT EXISTS ix_push_events_repo_received ON push_events (repository_id, received_at)",
        "CREATE INDEX IF NOT EXISTS ix_env_metrics_env_ts ON env_metrics (environment_id, ts)",
        "CREATE INDEX IF NOT EXISTS ix_env_metrics_ts ON env_metrics (ts)",  # 定期 DELETE ts < cutoff 用,否则全表扫
        "CREATE INDEX IF NOT EXISTS ix_environments_project_id ON environments (project_id)",
        "CREATE INDEX IF NOT EXISTS ix_environments_owner_user_id ON environments (owner_user_id)",
        "CREATE INDEX IF NOT EXISTS ix_environments_tenant_deleted ON environments (tenant_id, deleted_at)",
        # 外部身份:同一来源里一个外部主键只能对应一个平台账号(同步接口靠它保证幂等)
        "CREATE UNIQUE INDEX IF NOT EXISTS uq_users_external ON users (external_source, external_id)",
    ]
    for st in stmts:
        try:
            with engine.begin() as conn:
                conn.execute(text(st))
        except Exception as ex:  # noqa: BLE001 — 表/列不存在(旧库结构不同)时忽略
            log.debug("索引跳过: %s (%s)", st, ex)


def _migrate_enterprise_dir():
    """企业版代码目录统一:数据库里存着旧默认值 /var/lib/odoosh/enterprise 的,改成 offline/enterprise。
    只改这个特定旧默认值,自定义值不动。幂等。"""
    from .models import Setting

    with SessionLocal() as db:
        row = db.get(Setting, "odoo.enterprise_dir")
        if row and (row.value or "").rstrip("/") == "/var/lib/odoosh/enterprise":
            row.value = "/var/lib/odoosh/offline/enterprise"
            db.commit()
            log.info("企业版代码目录已从 /var/lib/odoosh/enterprise 迁移到统一目录 /var/lib/odoosh/offline/enterprise")


def _migrate_memberships():
    """旧模型(users.tenant_id + role tenant_admin/member)→ memberships。幂等。"""
    from .models import Membership

    with SessionLocal() as db:
        n = 0
        for u in db.scalars(select(User).where(User.tenant_id.is_not(None))).all():
            if u.role == "admin":
                continue
            exists = db.scalar(select(Membership).where(Membership.user_id == u.id, Membership.tenant_id == u.tenant_id))
            if not exists:
                role = "owner" if u.role == "tenant_admin" else "developer"
                db.add(Membership(user_id=u.id, tenant_id=u.tenant_id, role=role))
                n += 1
            if u.role in ("tenant_admin", "member"):
                u.role = "member"
        db.commit()
        if n:
            log.info("已迁移 %s 条旧的用户-租户关系到 memberships", n)


def _seed_admin():
    with SessionLocal() as db:
        if not db.scalar(select(User).where(User.username == settings.admin_user)):
            db.add(
                User(
                    username=settings.admin_user,
                    password_hash=hash_password(settings.admin_password),
                    display_name="平台管理员",
                    role="admin",
                )
            )
            db.commit()
            log.info("已创建初始管理员: %s", settings.admin_user)


def _reset_ai_running():
    from sqlalchemy import update

    from .models_ai import AiConversation

    with SessionLocal() as db:
        n = db.execute(update(AiConversation).where(AiConversation.state == "running").values(state="idle")).rowcount
        db.commit()
        if n:
            log.info("已复位 %s 个遗留 running 的 AI 会话", n)


@asynccontextmanager
async def lifespan(app: FastAPI):
    _wait_for_db()
    Base.metadata.create_all(engine)  # 第一版先用 create_all,后续引入 Alembic 迁移
    _auto_add_columns()
    models_git.ensure_schema(engine)  # Git 模块新增列
    _widen_secret_columns()
    from . import crypto as _crypto

    if settings.secret_key_old:
        n = _crypto.rotate_key(engine, settings.secret_key_old)  # ODOOSH_SECRET_KEY 轮换:旧 key 密文 → 新 key
        log.warning("ODOOSH_SECRET_KEY 轮换:已重加密 %s 条记录。请从 .env 删除 ODOOSH_SECRET_KEY_OLD 后再重启一次", n)
    n = _crypto.migrate_plaintext(engine)  # 历史明文令牌/口令 → 加密
    if n:
        log.info("已加密 %s 个历史明文凭据", n)
    from .services import gitpoll as gitpoll_service  # noqa: E402

    gitpoll_service.start_poller()  # 定时轮询远端分支(收不到 Webhook 时的兜底,设置 git.poll_minutes)
    _seed_admin()
    _backfill_env_owner()  # 需在管理员存在之后
    _backfill_project_groups()
    _migrate_memberships()
    _migrate_enterprise_dir()  # 企业版代码目录:旧默认 /var/lib/odoosh/enterprise → 统一目录 offline/enterprise
    from .services import hostip as hostip_service

    hostip_service.resolve_at_startup()  # ODOOSH_BASE_DOMAIN=auto → <宿主机IP>.nip.io(须在 nginx 重写之前)
    backup_service.start_scheduler()  # 每日自动备份 + 过期清理(受「设置」中 backup.* 控制)
    nginx_service.start_reconciler()  # 重写实例 nginx 配置 + 把 web 容器接回所有实例网络(平台重建后必需)
    orchestrator_service.recover_stuck_on_startup()  # 过渡态实例归位
    backup_service.recover_stuck_on_startup()  # 被重启打断的备份 / 恢复任务标记失败(否则永远 running,锁与配额都算不清)
    _ensure_indexes()
    from .services import metrics as metrics_service

    metrics_service.start_collector()  # 每 10s 采一次实例资源(列表 stats 缓存 + Monitor 曲线)
    from .services import sleep as sleep_service

    sleep_service.logs_dir()  # 确保 nginx-logs 目录存在(web 容器把各实例访问日志写在这里)
    sleep_service.start_scheduler()  # 开发实例闲置休眠巡检
    hostip_service.start_watcher()  # auto 模式:IP 变化自动同步实例域名
    # 同步端点 + BackgroundTasks 共用 anyio 线程池,默认 40;长任务(创建/部署/备份)会占满 → 扩容
    try:
        import anyio

        anyio.to_thread.current_default_thread_limiter().total_tokens = 120
    except Exception as ex:  # noqa: BLE001
        log.warning("调整线程池上限失败: %s", ex)
    orchestrator_service.start_expiry_scheduler()  # 过期实例自动删除(全局默认 + 每实例可设)
    from .services import housekeeping as housekeeping_service

    housekeeping_service.start_scheduler()  # 悬空镜像/构建缓存/临时目录/旧检出/git gc/企业版旧目录(每 6 小时)
    project_service.register_hooks()  # push → 测试/开发自动部署
    _reset_ai_running()  # AI 会话:进程重启后遗留的 running 复位为 idle(事件总线在进程内,重启即失效)
    from .services import databases as databases_service

    databases_service.start_scheduler()  # 附加数据库过期自动删除
    settings.started_at = time.time()
    log.info("%s %s 启动完成", settings.app_name, settings.version)
    yield


# API 文档默认关闭:公开的 /docs、/openapi.json 会把完整接口面暴露给未认证访问者。
# 需要时用环境变量 ODOOSH_ENABLE_DOCS=1 打开(建议只在内网调试时)。
_docs = os.environ.get("ODOOSH_ENABLE_DOCS", "0") == "1"
# 挂在 /api/ 下:控制台 nginx 只把 /api/ 反代到本服务,这样开了开关后经 80/443 端口就能直接访问 /api/docs
app = FastAPI(title=settings.app_name, version=settings.version, lifespan=lifespan,
              docs_url="/api/docs" if _docs else None, redoc_url="/api/redoc" if _docs else None,
              openapi_url="/api/openapi.json" if _docs else None)

for r in (auth, users, tenants, environments, images, settings_router, system):
    app.include_router(r.router)
app.include_router(repos.router)
app.include_router(repos.webhook_router)
app.include_router(repos.git_router)
app.include_router(backups.router)
app.include_router(enterprise_router.router)
app.include_router(projects_router.router)
app.include_router(sso_router.router)
app.include_router(wake_router.router)
app.include_router(shell_router.router)
app.include_router(databases_router.router)
app.include_router(backup_targets_router.router)
app.include_router(backup_targets_router.env_router)
app.include_router(backup_targets_router.bk_router)
app.include_router(ai_router.router)
app.include_router(bulk_router.router)
app.include_router(tokens_router.router)
app.include_router(ext_router.router)


@app.exception_handler(ext_router.ApiError)
def _ext_api_error(request, exc: ext_router.ApiError):
    """/api/ext/* 的错误响应带稳定的 code 字段:接入方的重试队列据此判断重试还是转人工,
    不必解析中文文案(见 docs/work-2026-09-04-odoo-integration-design.md 3.4)。"""
    from fastapi.responses import JSONResponse

    return JSONResponse({"detail": exc.detail, "code": exc.code}, status_code=exc.status_code)


@app.get("/api/health")
def health():
    return {"status": "ok", "version": settings.version, "started_at": settings.started_at}
