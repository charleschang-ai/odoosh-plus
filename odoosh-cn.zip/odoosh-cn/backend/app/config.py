from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """平台配置,全部来自环境变量(由 deploy/.env 注入)。"""

    model_config = SettingsConfigDict(env_prefix="ODOOSH_", extra="ignore")

    app_name: str = "OdooshCN"
    version: str = "0.1.0"
    secret_key: str = "change-me"
    secret_key_old: str = ""                   # 轮换密钥时放旧值,启动时把静态加密数据重加密一次,然后删掉
    token_expire_minutes: int = 60 * 24

    database_url: str = "postgresql+psycopg://odoosh:odoosh@db:5432/odoosh"

    admin_user: str = "admin"
    admin_password: str = "admin"

    docker_socket: str = "unix:///var/run/docker.sock"
    data_dir: str = "/var/lib/odoosh"          # 平台容器内看到的数据目录
    host_data_dir: str = "/var/lib/odoosh"     # 宿主机上的同一目录(bind mount 时要用宿主机路径)
    host_src_dir: str = ""                     # 平台源码仓库在宿主机上的路径(自更新用;由 install.sh 写入 .env)
    started_at: float = 0.0                    # 进程启动时间(运行时填充)
    base_domain: str = "localhost"             # 环境域名后缀:<env>-<tenant>.<base_domain>(只占一级,便于一张 *.<base_domain> 泛证书全覆盖);"auto" = 自动用 <宿主机IP>.nip.io(见 services.hostip)
    base_domain_raw: str = ""                  # 运行时填充:.env 里的原始值(auto 时 base_domain 会被解析结果覆盖)
    host_ip: str | None = None                 # 运行时填充:auto 模式探测到的宿主机 IP
    self_image: str = "odoosh/api:dev"         # 平台 api 镜像名(auto 探测 IP 时用它起 host 网络的一次性容器)
    http_port: int = 80                        # 平台对外端口(用于拼接环境访问 URL)
    https_port: int = 443                      # 平台 HTTPS 端口;泛域名证书可用时实例 URL 用它(443 则省略端口)
    env_port_range: str = "10001-10020"        # 端口直连模式的实例端口池;须与 compose 里 web 的端口映射范围一致
    compose_project: str = "odoosh"            # 平台 compose 项目名(用于找到 web 容器)
    images_dir: str = "/app/images"            # 基础镜像 Dockerfile 所在目录
    odoo_src_url: str = "auto"  # auto = 依次探测 GitHub 官方/国内加速代理/Gitee,取最快可用;也可指定固定地址
    pip_index_url: str = "https://pypi.tuna.tsinghua.edu.cn/simple"
    debian_mirror: str = "mirrors.tuna.tsinghua.edu.cn"


settings = Settings()
settings.base_domain_raw = settings.base_domain

# 安全兜底:secret_key 为默认值/过短时拒绝启动(它签发登录 JWT、SSO/Shell 票据、OAuth state)。
# install.sh 会生成 48 位随机值写入 deploy/.env;手工部署请设置 ODOOSH_SECRET_KEY。
if settings.secret_key in ("", "change-me") or len(settings.secret_key) < 16:
    raise RuntimeError("ODOOSH_SECRET_KEY 未设置或过弱(至少 16 位随机字符串),拒绝启动。请在 deploy/.env 中设置后重启。")
