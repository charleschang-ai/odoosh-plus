"""静态加密:数据库中的令牌 / 口令列用 Fernet(密钥由 ODOOSH_SECRET_KEY 派生)加密存储。

- `EncryptedText` 是 SQLAlchemy TypeDecorator:写入时加密为 `enc:<token>`,读取时解密。
- 兼容历史明文:读到不带 `enc:` 前缀的值原样返回;下次写入即变为密文(startup 也会做一次全量迁移)。
- 更换 ODOOSH_SECRET_KEY 会导致已有密文无法解密 → 返回 None 并记录警告,请勿随意更换。
"""

import base64
import hashlib
import logging

from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import Text
from sqlalchemy.types import TypeDecorator

from .config import settings

log = logging.getLogger("odoosh.crypto")
PREFIX = "enc:"

_fernet: Fernet | None = None


def fernet() -> Fernet:
    global _fernet
    if _fernet is None:
        key = base64.urlsafe_b64encode(hashlib.sha256(("odoosh-at-rest:" + settings.secret_key).encode()).digest())
        _fernet = Fernet(key)
    return _fernet


def encrypt(value: str | None) -> str | None:
    if value is None or value == "":
        return value
    if value.startswith(PREFIX):
        return value
    return PREFIX + fernet().encrypt(value.encode()).decode()


def decrypt(value: str | None) -> str | None:
    if value is None or value == "" or not value.startswith(PREFIX):
        return value  # 历史明文
    try:
        return fernet().decrypt(value[len(PREFIX):].encode()).decode()
    except InvalidToken:
        log.warning("密文无法解密(ODOOSH_SECRET_KEY 是否被更换?)")
        return None


class EncryptedText(TypeDecorator):
    """透明加解密的文本列。"""

    impl = Text
    cache_ok = True

    def process_bind_param(self, value, dialect):
        return encrypt(value)

    def process_result_value(self, value, dialect):
        return decrypt(value)


# 静态加密的表/列(环境密码、令牌等);settings 表的密钥项见 routers.settings.is_secret_key
TARGETS = {
    "tenants": ["pg_password"],
    "environments": ["db_password", "admin_password"],
    "environment_databases": ["admin_password"],
    "git_accounts": ["access_token", "refresh_token"],
    "repositories": ["token", "webhook_secret"],
}


def _fernet_for(key: str) -> Fernet:
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(("odoosh-at-rest:" + key).encode()).digest()))


def rotate_key(engine, old_key: str) -> int:
    """换 ODOOSH_SECRET_KEY:把用旧 key 加密的密文改用新 key 重新加密(幂等:已是新 key 密文的行跳过)。
    用法:.env 里把旧值放到 ODOOSH_SECRET_KEY_OLD、新值放到 ODOOSH_SECRET_KEY,重启 api 一次后删掉 OLD。返回改写行数。"""
    from sqlalchemy import text

    if not old_key or old_key == settings.secret_key:
        return 0
    old_f = _fernet_for(old_key)
    new_f = fernet()
    n = 0

    def reenc(val: str) -> str | None:
        if not val or not val.startswith(PREFIX):
            return None
        body = val[len(PREFIX):].encode()
        try:
            new_f.decrypt(body)
            return None  # 已是新 key
        except InvalidToken:
            pass
        try:
            plain = old_f.decrypt(body)
        except InvalidToken:
            return None  # 既不是新 key 也不是旧 key:不动,留给人工处理
        return PREFIX + new_f.encrypt(plain).decode()

    with engine.begin() as conn:
        for table, cols in TARGETS.items():
            for col in cols:
                try:
                    rows = conn.execute(text(f"SELECT id, \"{col}\" FROM \"{table}\" WHERE \"{col}\" LIKE 'enc:%'")).all()
                except Exception:  # noqa: BLE001
                    continue
                for rid, val in rows:
                    nv = reenc(val)
                    if nv:
                        conn.execute(text(f'UPDATE "{table}" SET "{col}" = :v WHERE id = :id'), {"v": nv, "id": rid})
                        n += 1
        try:
            rows = conn.execute(text("SELECT key, value FROM settings WHERE value LIKE 'enc:%'")).all()
            for k, val in rows:
                nv = reenc(val)
                if nv:
                    conn.execute(text("UPDATE settings SET value = :v WHERE key = :k"), {"v": nv, "k": k})
                    n += 1
        except Exception:  # noqa: BLE001
            pass
    return n


def migrate_plaintext(engine) -> int:
    """启动时把仍为明文的敏感列加密。返回改写行数。幂等。"""
    from sqlalchemy import text

    n = 0
    with engine.begin() as conn:
        for table, cols in TARGETS.items():
            for col in cols:
                try:
                    rows = conn.execute(text(f'SELECT id, "{col}" FROM "{table}" WHERE "{col}" IS NOT NULL AND "{col}" <> \'\' AND "{col}" NOT LIKE \'enc:%\'')).all()
                except Exception:  # noqa: BLE001 — 表/列不存在(旧库)时跳过
                    continue
                for rid, val in rows:
                    conn.execute(text(f'UPDATE "{table}" SET "{col}" = :v WHERE id = :id'), {"v": encrypt(val), "id": rid})
                    n += 1
        # 平台设置里的密钥项(git token / OAuth secret / 对象存储 secret …)
        try:
            from .routers.settings import is_secret_key

            rows = conn.execute(text("SELECT key, value FROM settings WHERE value IS NOT NULL AND value <> '' AND value NOT LIKE 'enc:%'")).all()
            for k, val in rows:
                if is_secret_key(k):
                    conn.execute(text("UPDATE settings SET value = :v WHERE key = :k"), {"v": encrypt(val), "k": k})
                    n += 1
        except Exception:  # noqa: BLE001
            pass
    return n
