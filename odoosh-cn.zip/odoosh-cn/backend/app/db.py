from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from .config import settings

_kw = {}
if settings.database_url.startswith("postgresql"):
    # 长任务(创建/部署/备份)线程多,默认 5+10 会 QueuePool limit reached;
    # 以前 20+40 是因为每行日志都开一次连接(现已节流落库),现在 10+20 足够;pool_recycle 防止 PG 端超时后拿到死连接
    # 池子要能喂饱线程池:同步路由跑在 anyio 线程池里(main.py 把它开到 120),
    # 池子太小的话线程拿不到连接只能干等 pool_timeout,高并发时表现为「服务器很闲但请求很慢」。
    # 弹性全部放在 max_overflow 而不是 pool_size —— 二者语义不同,这对小内存机器很关键:
    #   pool_size    常驻连接,归还后不关闭。PG 每条连接是一个后端进程(常驻约 3~5MB),
    #                调大它等于无论闲忙都长期占着内存。
    #   max_overflow 峰值时临时创建、归还即关闭。平时不占,只在真有并发时才付出成本。
    # 于是小机器空闲时的开销与原来一样(10 条),而峰值能力从 30 提到 90。
    # 上限受平台 PG 的 max_connections 约束(compose 里给了 200),90 条留足余量。
    _kw = {"pool_size": 10, "max_overflow": 80, "pool_timeout": 60, "pool_recycle": 1800}
engine = create_engine(settings.database_url, pool_pre_ping=True, **_kw)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    db: Session = SessionLocal()
    try:
        yield db
    finally:
        db.close()
