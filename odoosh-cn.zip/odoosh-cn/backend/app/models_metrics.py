"""实例资源指标采样(Monitor Tab 数据源;后台线程每 10s 采一次,保留 7 天)。"""

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Float, ForeignKey, Index, Integer
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


class EnvMetric(Base):
    __tablename__ = "env_metrics"
    __table_args__ = (Index("ix_env_metrics_env_ts", "environment_id", "ts"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    environment_id: Mapped[int] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"))
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    cpu_pct: Mapped[float | None] = mapped_column(Float)
    mem_bytes: Mapped[int | None] = mapped_column(BigInteger)
    mem_limit: Mapped[int | None] = mapped_column(BigInteger)
    net_rx: Mapped[int | None] = mapped_column(BigInteger)  # 累计字节(前端按差分算速率)
    net_tx: Mapped[int | None] = mapped_column(BigInteger)
    blk_read: Mapped[int | None] = mapped_column(BigInteger)
    blk_write: Mapped[int | None] = mapped_column(BigInteger)
    pids: Mapped[int | None] = mapped_column(Integer)
    # 低频项(每 5 分钟才算一次,其余样本为 None):filestore 目录字节数、数据库字节数
    disk_filestore: Mapped[int | None] = mapped_column(BigInteger)
    disk_db: Mapped[int | None] = mapped_column(BigInteger)
