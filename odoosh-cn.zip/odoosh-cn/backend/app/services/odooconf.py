"""odoo.conf 附加项(仿 odoo.sh:用户不能直接改 odoo.conf,只能在白名单内追加 / 覆盖少数选项)。

三层来源,后者覆盖前者:
  1. 平台模板(orchestrator.write_odoo_conf 按套餐 / 多库 / 资源算出来的,属于平台契约)
  2. 平台全局附加项(系统设置 odoo.extra_conf,超管维护,对所有实例生效)
  3. 实例附加项(Environment.extra_conf,实例设置里填)

校验规则:
  - BLACKLIST:平台管理的键,任何人(含超管)都不能写——这些决定隔离、路由、资源配额
  - 普通用户(实例有「编辑」权的角色)只能写 WHITELIST ∪ 超管扩充的键(设置 odoo.extra_conf_extra_keys)
  - 超管可写任何非 BLACKLIST 的键
  - 非 [options] 的 section(如 [queue_job])整段透传:那是第三方模块自己读的,不影响平台
  - 数值键有上限,防止借此绕开资源配额
"""

from __future__ import annotations

import configparser
import io
import re

_MAX = {
    "limit_time_cpu": 3600,
    "limit_time_real": 7200,
    "limit_time_real_cron": 7200,
    "limit_request": 65536,
    "max_cron_threads": 2,
    "transient_age_limit": 168,
    "osv_memory_count_limit": 1_000_000,
    "websocket_keep_alive_timeout": 3600,
    "websocket_rate_limit_burst": 1000,
    "websocket_rate_limit_delay": 60,
    "smtp_port": 65535,
}
_INT_KEYS = set(_MAX) | {"osv_memory_age_limit"}
_BOOL_KEYS = {"unaccent", "smtp_ssl", "screencasts", "test_enable"}
_NUM_NEG_OK = {"limit_time_real_cron"}  # -1 = 不限(Odoo 语义)
# 逗号分隔的标识符列表(模块名 / 语言代码):只允许字母数字下划线点横线,防止塞进奇怪内容
_LIST_KEYS = {"server_wide_modules": r"^[a-z][a-z0-9_]*$", "load_language": r"^[a-zA-Z]{2,3}(_[A-Za-z0-9]{2,8})?$",
              "translate_modules": r"^[a-z][a-z0-9_]*$"}

# 用户(实例「编辑」权)可写的键 -> 说明(前端提示用)
WHITELIST: dict[str, str] = {
    "server_wide_modules": "服务级模块(如 base,web,queue_job);逗号分隔,会替换默认值 base,web。注意 queue_job 需要 workers > 0(开发实例默认 workers=0,可在资源上限里加内存)",
    "limit_time_cpu": "单请求 CPU 秒数上限(默认 600,最大 3600)",
    "limit_time_real": "单请求真实时间上限(默认 1200,最大 7200)",
    "limit_time_real_cron": "单个定时任务真实时间上限(-1 不限,最大 7200)",
    "limit_request": "worker 处理多少请求后回收(默认 8192,最大 65536)",
    "max_cron_threads": "定时任务线程数(默认 1,0 = 本实例不跑 cron,最大 2)",
    "unaccent": "True = 搜索忽略重音(需要 PG unaccent 扩展)",
    "transient_age_limit": "临时模型记录保留小时数(默认 1)",
    "osv_memory_count_limit": "临时模型记录数上限",
    "log_handler": "按模块设日志等级,如 odoo.addons.queue_job:DEBUG(逗号分隔多个)",
    "email_from": "系统发件人地址",
    "from_filter": "发件人过滤(Odoo 15+)",
    "smtp_server": "SMTP 服务器",
    "smtp_port": "SMTP 端口",
    "smtp_ssl": "True = SMTP 使用 SSL/TLS",
    "smtp_user": "SMTP 用户名",
    "smtp_password": "SMTP 口令",
    "websocket_keep_alive_timeout": "WebSocket 保活秒数(Odoo 16+)",
    "websocket_rate_limit_burst": "WebSocket 限流突发数",
    "websocket_rate_limit_delay": "WebSocket 限流间隔",
    "translate_modules": "翻译导出范围",
    "load_language": "启动时加载的语言(逗号分隔)",
}

# 平台契约:任何人都不能改。值为报错提示
BLACKLIST: dict[str, str] = {
    **{k: "数据库连接由平台管理" for k in ("db_host", "db_port", "db_user", "db_password", "db_name", "db_template",
                                          "db_sslmode", "db_maxconn", "db_maxconn_gevent", "pg_path")},
    "dbfilter": "数据库过滤由平台按域名 / 附加库自动生成",
    "list_db": "数据库管理器由平台关闭",
    "addons_path": "模块路径由平台按版本 / 企业版 / 代码仓库生成",
    "data_dir": "文件存储目录由平台挂载",
    "proxy_mode": "反向代理模式由平台固定开启",
    **{k: "监听端口 / 接口由平台固定" for k in ("http_port", "gevent_port", "longpolling_port", "http_interface", "http_enable",
                                              "xmlrpc_port", "xmlrpc_interface", "xmlrpc", "xmlrpcs", "netrpc")},
    **{k: "进程 / 内存配额由资源上限决定,请在「资源上限」里调整" for k in ("workers", "limit_memory_hard", "limit_memory_soft")},
    "admin_passwd": "Master 口令由平台生成(见「凭据」)",
    "log_level": "请使用「Odoo 日志等级」设置",
    **{k: "日志输出由容器接管" for k in ("logfile", "syslog", "log_db", "log_db_level", "logrotate")},
    **{k: "仅命令行使用" for k in ("init", "update", "stop_after_init", "save", "config", "import_partial", "pidfile",
                               "upgrade_path", "pre_upgrade_scripts", "without_demo_override")},
    "without_demo": "演示数据由平台固定关闭",
    **{k: "测试 / 调试选项不允许写入配置文件" for k in ("test_file", "test_tags", "screenshots", "dev_mode", "dev")},
    **{k: "GeoIP 库路径由平台管理" for k in ("geoip_database", "geoip_city_db", "geoip_country_db")},
}

_KEY_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
_SECTION_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,64}$")
MAX_LEN = 8192


class Parsed:
    def __init__(self) -> None:
        self.options: dict[str, str] = {}
        self.sections: dict[str, dict[str, str]] = {}


def parse(text: str | None) -> tuple[Parsed, list[str]]:
    """解析附加项文本。无 section 头的行视作 [options]。返回 (结果, 语法错误列表)。"""
    out = Parsed()
    text = (text or "").strip()
    if not text:
        return out, []
    if len(text) > MAX_LEN:
        return out, [f"附加配置过长(>{MAX_LEN} 字符)"]
    body = text if text.startswith("[") else "[options]\n" + text
    cp = configparser.RawConfigParser(strict=False, interpolation=None, allow_no_value=False, comment_prefixes=(";", "#"))
    cp.optionxform = str  # 保留大小写(第三方 section 可能区分)
    try:
        cp.read_file(io.StringIO(body))
    except configparser.Error as ex:
        msg = str(ex).splitlines()[0]
        return out, [f"配置语法错误:{msg}"]
    for sec in cp.sections():
        items = {k.strip(): v.strip() for k, v in cp.items(sec)}
        if sec == "options":
            out.options = {k.lower(): v for k, v in items.items()}
        else:
            out.sections[sec] = items
    return out, []


def _check_value(key: str, val: str) -> str | None:
    if "\n" in val or "\r" in val:
        return f"{key}:不允许多行值"
    if key in _BOOL_KEYS and val.lower() not in ("true", "false", "1", "0"):
        return f"{key}:须为 True / False"
    if key in _LIST_KEYS:
        items = [x.strip() for x in val.split(",")]
        if not val.strip() or any(not x or not re.match(_LIST_KEYS[key], x) for x in items):
            return f"{key}:须为逗号分隔的标识符列表(如 base,web,queue_job)"
        if key == "server_wide_modules" and not {"base", "web"} <= set(items):
            return f"{key}:必须包含 base 和 web"
    if key in _INT_KEYS:
        try:
            n = int(val)
        except ValueError:
            return f"{key}:须为整数"
        if n < 0 and not (key in _NUM_NEG_OK and n == -1):
            return f"{key}:不能为负数"
        mx = _MAX.get(key)
        if mx is not None and n > mx:
            return f"{key}:最大 {mx}"
    return None


def validate(text: str | None, *, superadmin: bool, extra_allowed: set[str] | None = None) -> list[str]:
    """返回错误列表(空 = 通过)。"""
    parsed, errs = parse(text)
    if errs:
        return errs
    allowed = set(WHITELIST) | set(extra_allowed or ())
    for k, v in parsed.options.items():
        if not _KEY_RE.match(k):
            errs.append(f"非法键名:{k}")
            continue
        if k in BLACKLIST:
            errs.append(f"{k}:{BLACKLIST[k]}")
            continue
        if not superadmin and k not in allowed:
            errs.append(f"{k}:不在允许列表内(平台管理员可在系统设置里扩充)")
            continue
        e = _check_value(k, v)
        if e:
            errs.append(e)
    for sec, items in parsed.sections.items():
        if not _SECTION_RE.match(sec):
            errs.append(f"非法 section 名:[{sec}]")
            continue
        for k, v in items.items():
            if "\n" in v or "\r" in v:
                errs.append(f"[{sec}] {k}:不允许多行值")
    return errs


def extra_allowed_keys(db) -> set[str]:
    """超管在系统设置里额外放行的键(odoo.extra_conf_extra_keys,逗号分隔),已剔除黑名单。"""
    from ..routers.settings import get_setting

    raw = get_setting(db, "odoo.extra_conf_extra_keys") or ""
    out = set()
    for k in raw.split(","):
        k = k.strip().lower()
        if k and k not in BLACKLIST and _KEY_RE.match(k):
            out.add(k)
    return out


def env_overrides_enabled(db) -> bool:
    from ..routers.settings import get_setting

    return (get_setting(db, "odoo.extra_conf_env_enabled") or "1") == "1"


def merged(db, env) -> Parsed:
    """平台全局附加项 + 实例附加项(后者覆盖前者)。写 odoo.conf 时调用;黑名单键在这里再过滤一遍(防旧数据 / 直接改库)。"""
    from ..routers.settings import get_setting

    out = Parsed()
    sources = [get_setting(db, "odoo.extra_conf")]
    if env_overrides_enabled(db):
        sources.append(getattr(env, "extra_conf", None))
    for src in sources:
        p, errs = parse(src)
        if errs:
            continue
        for k, v in p.options.items():
            if k in BLACKLIST or not _KEY_RE.match(k):
                continue
            out.options[k] = v
        for sec, items in p.sections.items():
            if not _SECTION_RE.match(sec):
                continue
            out.sections.setdefault(sec, {}).update(items)
    return out


def render_sections(sections: dict[str, dict[str, str]]) -> str:
    buf = []
    for sec, items in sections.items():
        buf.append(f"\n[{sec}]")
        for k, v in items.items():
            buf.append(f"{k} = {v}")
    return "\n".join(buf) + ("\n" if buf else "")
