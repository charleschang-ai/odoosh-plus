"""进程内日志发布/订阅 + SSE 生成器。

频道:`env:<id>`(编排日志,EnvLogger 发布)、`dep:<id>`(部署日志,DepLog 发布)。
容器 stdout 通过 docker logs --follow 在独立线程里读取并合并到同一队列。
"""

import json
import queue
import threading
import time
from collections.abc import Iterator

_lock = threading.Lock()
_subs: dict[str, list[queue.Queue]] = {}

END = object()


def publish(channel: str, line: str) -> None:
    with _lock:
        qs = list(_subs.get(channel, ()))
    for q in qs:
        try:
            q.put_nowait(("orch", line))
        except queue.Full:
            pass


def subscribe(channel: str) -> queue.Queue:
    q: queue.Queue = queue.Queue(maxsize=5000)
    with _lock:
        _subs.setdefault(channel, []).append(q)
    return q


def unsubscribe(channel: str, q: queue.Queue) -> None:
    with _lock:
        lst = _subs.get(channel)
        if lst and q in lst:
            lst.remove(q)
        if lst == []:
            _subs.pop(channel, None)


def sse(event: str | None, data: str) -> str:
    """一行日志一个事件;data 用 JSON 字符串编码,前端 JSON.parse,避免换行/编码问题。"""
    head = f"event: {event}\n" if event else ""
    return f"{head}data: {json.dumps(data, ensure_ascii=False)}\n\n"


def follow_container(container, q: queue.Queue, stop: threading.Event, since: int | None = None):
    """后台线程:docker logs --follow → 队列。返回 close() 可提前结束跟随。

    以前只在收到下一块日志时才检查 stop:客户端断开后,安静的容器让这个线程(和一条 docker 连接)一直挂着。
    现在 stop 置位(或调用方 close())时主动关闭 docker 的日志流,线程立即退出。"""
    kw = {"stream": True, "follow": True, "timestamps": False}
    if since:
        kw["since"] = since
    try:
        gen = container.logs(**kw)  # CancellableStream
    except Exception as ex:  # noqa: BLE001
        q.put(("container", f"[日志流中断: {ex}]"))
        return lambda: None
    closed = threading.Event()

    def close():
        if closed.is_set():
            return
        closed.set()
        try:
            gen.close()
        except Exception:  # noqa: BLE001
            pass

    def run():
        try:
            for chunk in gen:
                if stop.is_set() or closed.is_set():
                    break
                for ln in chunk.decode(errors="ignore").splitlines():
                    q.put(("container", ln))
        except Exception as ex:  # noqa: BLE001
            if not (stop.is_set() or closed.is_set()):
                q.put(("container", f"[日志流中断: {ex}]"))
        finally:
            closed.set()

    def watch_stop():
        stop.wait()
        close()

    threading.Thread(target=run, daemon=True, name="logs-follow").start()
    threading.Thread(target=watch_stop, daemon=True, name="logs-follow-stop").start()
    return close


def stream(q: queue.Queue, stop: threading.Event, is_done=None, heartbeat: float = 15.0, idle_check: float = 2.0) -> Iterator[str]:
    """把队列变成 SSE 文本流。is_done() 返回 True 时(且队列已空)结束。空闲时发心跳注释保活。"""
    last = time.time()
    try:
        while True:
            try:
                kind, line = q.get(timeout=idle_check)
            except queue.Empty:
                if is_done and is_done():
                    yield sse("end", "")
                    return
                if time.time() - last > heartbeat:
                    yield ": ping\n\n"
                    last = time.time()
                continue
            if line is END:
                yield sse("end", "")
                return
            last = time.time()
            yield sse(kind, line)
    finally:
        stop.set()
