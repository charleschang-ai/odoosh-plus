"""项目(仓库)视角的环境编排:仿 odoo.sh 的「仓库 → 分支 = 环境(生产 / 测试 / 开发)」。

本模块只做「胶水」:复用 orchestrator(容器)、deploy(代码)、backup(中性化 SQL)、enterprise(企业版代码),
新增的能力:
  - 按分支创建环境(环境名 = 分支名规范化)
  - 改档位(dev/staging/production 之间移动),必要时重建库、切换只读/可写挂载
  - 数据克隆:同组织环境之间 pg_dump | psql + 复制 filestore + 中性化(测试从生产刷新)
  - push 钩子:测试/开发自动部署
  - 企业版升级信息 / 执行
"""

import logging
import os
import re
import shutil
import threading
import time
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import SessionLocal
from ..models import Environment, Tenant
from ..models_git import Repository
from . import dockerx
from . import git as gitsvc

log = logging.getLogger("odoosh.project")

KINDS = ("production", "staging", "dev")
KIND_LABEL = {"production": "生产", "staging": "测试", "dev": "开发"}


# ---------------------------------------------------------------- 项目(= 根实例)↔ 环境
def project_root(db: Session, e: Environment) -> Environment:
    """环境所属项目的根实例(自身或 project_id 指向的实例)。"""
    if e.project_id:
        root = db.get(Environment, e.project_id)
        if root:
            return root
    return e


def project_envs(db: Session, root: Environment) -> list[Environment]:
    """项目内全部环境:根实例 + 从它详情页按分支创建的环境。每个实例是独立项目,不按仓库合并。
    条件下推到 SQL(以前把组织全部环境查出来在 Python 里过滤,一个请求里还会调 3~5 次)。"""
    from sqlalchemy import or_

    return db.scalars(
        select(Environment).where(
            Environment.tenant_id == root.tenant_id,
            Environment.deleted_at.is_(None),  # 回收站里的不算
            or_(Environment.id == root.id, Environment.project_id == root.id),
        ).order_by(Environment.id)
    ).all()


def production_env(db: Session, root: Environment, exclude_id: int | None = None, envs: list[Environment] | None = None) -> Environment | None:
    """envs:调用方已查好的 project_envs 结果,传入则不再查库。"""
    for e in (envs if envs is not None else project_envs(db, root)):
        if e.kind == "production" and e.id != exclude_id:
            return e
    return None


# 兼容旧调用(按仓库汇总)
def repo_envs(db: Session, r: Repository) -> list[Environment]:
    if r.tenant_id is None:
        return []
    key = gitsvc.normalize_repo_url(r.url)
    envs = db.scalars(select(Environment).where(Environment.tenant_id == r.tenant_id).order_by(Environment.id)).all()
    return [e for e in envs if gitsvc.normalize_repo_url(e.repo_url) == key]


def find_repo_for_env(db: Session, e: Environment) -> Repository | None:
    if not e.repo_url:
        return None
    key = gitsvc.normalize_repo_url(e.repo_url)
    for r in db.scalars(select(Repository).where(Repository.tenant_id == e.tenant_id)).all():
        if gitsvc.normalize_repo_url(r.url) == key:
            return r
    return None


def env_name_for_branch(db: Session, tenant_id: int, branch: str) -> str:
    """分支名 → 合法且唯一的环境名(小写、非法字符转 -、去首尾 -,重名加 -2/-3…)。"""
    base = re.sub(r"[^a-z0-9-]+", "-", branch.lower()).strip("-")[:48] or "env"
    if not re.match(r"^[a-z0-9]", base):
        base = "b-" + base
    taken = set(db.scalars(select(Environment.name).where(Environment.tenant_id == tenant_id)).all())
    name, i = base, 2
    while name in taken:
        name = f"{base}-{i}"
        i += 1
    return name


# ---------------------------------------------------------------- 数据克隆(库 + filestore + 中性化)
def _psql(pg, sql: str, database: str = "postgres") -> tuple[int, str]:
    code, out = pg.exec_run(["psql", "-v", "ON_ERROR_STOP=1", "-X", "-q", "-At", "-U", "postgres", "-d", database, "-c", sql])
    return code, out.decode(errors="ignore")


def clone_data(pg, t: Tenant, src: Environment, dst: Environment, say=log.info, neutralize: bool = True, progress=None) -> None:
    """把 src 的数据库与 filestore 复制到 dst(dst 库若存在则先删掉重建)。两库都在同一个租户 PG 容器里。

    数据库:pg_dump(superuser,--no-owner)| psql(以 dst 用户执行,对象归属 dst 用户)。
    filestore:目录复制。之后可选中性化(停 cron / 邮件 / 支付,打标记)。
    调用方负责先停掉 dst 的 Odoo 容器。
    """
    from .backup import NEUTRALIZE_SQL, _chown_tree, _filestore_dir
    from .orchestrator import create_env_database, env_odoo_uid

    if not src.db_name:
        raise RuntimeError(f"来源环境「{src.name}」还没有数据库")
    if not dst.db_name or not dst.db_user or not dst.db_password:
        raise RuntimeError("目标环境的数据库凭据不完整")
    tick = progress or (lambda pct, msg=None: None)

    tick(0, f"重建数据库 {dst.db_name}")
    say(f"重建数据库 {dst.db_name}")
    _psql(pg, f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='{dst.db_name}' AND pid<>pg_backend_pid()")
    code, out = _psql(pg, f"DROP DATABASE IF EXISTS {dst.db_name}")
    if code != 0:
        raise RuntimeError(f"删除旧数据库失败: {out[:300]}")
    create_env_database(pg, dst.db_name, dst.db_user, dst.db_password, say)

    tick(10, f"复制数据库 {src.db_name} → {dst.db_name}")
    say(f"复制数据库 {src.db_name} → {dst.db_name}(pg_dump -Fc | pg_restore -j,数据量大时需要几分钟)...")
    t0 = time.time()
    # 自定义格式 + 并行 pg_restore(COPY 与建索引多路并行)比 plain `pg_dump | psql` 快 3~4 倍;
    # 导入期间关 synchronous_commit、加大 maintenance_work_mem(建索引),少几十万次 fsync。
    # -O 不输出属主,-x 不输出权限;pg_restore 用目标用户执行,新对象自然归目标用户。
    # 中间 dump 落在 bind mount 的租户目录(不是容器 overlay 层),完成即删;密码走环境变量,不进 ps 列表。
    jobs = max(1, min(4, (os.cpu_count() or 2) // 2))
    dump_c = f"/var/lib/postgresql/data/.odoosh-clone-{dst.id}.dump"
    _psql(pg, f'ALTER DATABASE "{dst.db_name}" SET synchronous_commit = off')
    _psql(pg, f'ALTER DATABASE "{dst.db_name}" SET maintenance_work_mem = \'256MB\'')
    sh = (f"rm -f {dump_c}; pg_dump -U postgres -Fc -Z1 -O -x -f {dump_c} {src.db_name} || {{ rm -f {dump_c}; echo DUMP_FAILED; exit 2; }}; "
          f"pg_restore -U {dst.db_user} -d {dst.db_name} --no-owner --no-privileges -j {jobs} {dump_c} 2>&1 | grep -c ERROR; "
          f"rc=${{PIPESTATUS[0]}}; rm -f {dump_c}; exit $rc")
    code, out = pg.exec_run(["bash", "-c", sh], environment={"PGPASSWORD": dst.db_password})
    text = out.decode(errors="ignore").strip()
    if code not in (0, 1):  # pg_restore 有可忽略错误(扩展/权限)时退出码为 1;2 = pg_dump 失败
        raise RuntimeError(f"复制数据库失败: {text[-300:]}")
    n_err = int(text.splitlines()[-1]) if text and text.splitlines()[-1].isdigit() else 0
    ok_code, _ = _psql(pg, "SELECT 1 FROM ir_module_module LIMIT 1", dst.db_name)
    if ok_code != 0:
        raise RuntimeError(f"复制数据库失败:目标库不完整({n_err} 条错误): {text[-300:]}")
    _psql(pg, f'ALTER DATABASE "{dst.db_name}" RESET maintenance_work_mem')
    if dst.kind == "production":
        _psql(pg, f'ALTER DATABASE "{dst.db_name}" SET synchronous_commit = on')
    say(f"数据库复制完成(耗时 {int(time.time() - t0)}s{',SQL 错误 ' + str(n_err) + ' 条(多为扩展/权限,通常可忽略)' if n_err else ''})")

    tick(70, "复制 filestore")
    src_fs = _filestore_dir(t, src)
    dst_fs = _filestore_dir(t, dst)
    if os.path.isdir(dst_fs):
        shutil.rmtree(dst_fs, ignore_errors=True)
    if os.path.isdir(src_fs):
        from .fsutil import copy_tree

        # 同一 uid 的两个实例:硬链接秒级完成、不占额外空间(filestore 内容寻址、从不原地改写);uid 不同则普通复制
        link_ok = env_odoo_uid(src) == env_odoo_uid(dst)
        say(f"复制 filestore {src_fs} → {dst_fs}" + "(硬链接)" if link_ok else f"复制 filestore {src_fs} → {dst_fs}")
        copy_tree(src_fs, dst_fs, link_ok=link_ok)
    else:
        os.makedirs(dst_fs, exist_ok=True)
    _chown_tree(os.path.dirname(dst_fs), env_odoo_uid(dst))

    if neutralize:
        tick(90, "中和数据库(停用 cron / 邮件 / 支付)")
        neutralize_db(pg, dst, say, t)
    else:
        say("按选择:不中和(定时任务 / 外发邮件保持生产设置,请注意)")
    tick(100, "数据就绪")


# ---------------------------------------------------------------- 后台任务:改档位 / 刷新数据
def _set(env_id: int, **fields) -> None:
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if e:
            for k, v in fields.items():
                setattr(e, k, v)
            db.commit()


# 新建预发环境(provision 走克隆)时前端的“是否中和”选择,按 env_id 暂存给编排器读取(默认 True)
_PENDING_NEUTRALIZE: dict[int, bool] = {}


def set_pending_neutralize(env_id: int, value: bool) -> None:
    _PENDING_NEUTRALIZE[env_id] = bool(value)


def pop_pending_neutralize(env_id: int, default: bool = True) -> bool:
    return _PENDING_NEUTRALIZE.pop(env_id, default)


def neutralize_db(pg, e: Environment, say=log.info, t: Tenant | None = None) -> None:
    """中和数据库(odoo.sh 的 neutralized database):
    优先执行 Odoo 官方 `odoo neutralize -d <db>`(Odoo 16+,会跑各模块自带的 neutralize.sql:停 cron、邮件、支付、IAP、社交/网站集成等,
    并写入 database.is_neutralized,界面顶部出现红色「中和数据库」横幅);随后再跑一遍内置 SQL 兜底(解除 base url 冻结等)。"""
    from .backup import NEUTRALIZE_SQL
    from . import orchestrator as orch

    if t is not None and e.container_name:
        try:
            tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
            say("执行 Odoo 官方 neutralize(停用定时任务 / 邮件 / 支付 / 第三方集成,并打上中和标记)")
            code, out = orch.run_oneoff(t, e, tag, ["odoo", "neutralize", "-c", "/etc/odoo/odoo.conf", "-d", e.db_name], suffix="neutralize", timeout=600)
            if code == 0:
                say("官方 neutralize 完成")
            else:
                say(f"官方 neutralize 未成功(退出码 {code}),改用内置中和 SQL:{(out or '')[-200:]}")
        except Exception as ex:  # noqa: BLE001
            say(f"官方 neutralize 执行失败({str(ex)[:120]}),改用内置中和 SQL")
    else:
        say("中性化:停用定时任务、外发邮件、支付服务商,打上「已中性化」标记")
    pw_env = {"PGPASSWORD": e.db_password}
    for sql in NEUTRALIZE_SQL:
        pg.exec_run(["psql", "-v", "ON_ERROR_STOP=0", "-X", "-q", "-U", e.db_user, "-d", e.db_name, "-c", sql], environment=pw_env)


def reset_to_empty_db(db: Session, t: Tenant, e: Environment, say=log.info, progress=None) -> None:
    """把环境的数据库与 filestore 换成全新空库(升生产时选「全新数据库」):
    drop 旧库 → 清空 filestore → 优先从黄金模板库秒建,否则安装 base。调用方需已停容器。"""
    import shutil

    from . import orchestrator as orch, templates as tplsvc

    pg = orch.ensure_tenant_pg(t, db, say)
    tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
    uid = orch.env_odoo_uid(e)
    say(f"丢弃当前数据库 {e.db_name} 与 filestore,换成全新空库")
    progress and progress(10, "删除旧数据库")
    orch.drop_env_database(pg, e.db_name, None)
    # 只清主库自己的 filestore(filestore/filestore/<主库名>)与 sessions;附加库的 filestore 子目录同在此目录下,不能一锅端
    fs = os.path.join(orch.env_dir(t, e), "filestore")
    for sub in (os.path.join(fs, "filestore", e.db_name), os.path.join(fs, "sessions")):
        if os.path.isdir(sub):
            shutil.rmtree(sub, ignore_errors=True)
    orch.ensure_env_role(pg, e.db_user, e.db_password)
    done = False
    if tplsvc.enabled():
        try:
            tpl = tplsvc.resolve(tag, e)
            if tplsvc.template_exists(pg, tpl):
                progress and progress(40, "从模板库创建数据库")
                tplsvc.create_from_template(pg, t, e, tpl, uid, say)
                done = True
        except Exception as ex:  # noqa: BLE001
            say(f"模板库不可用({str(ex)[:120]}),改为直接安装 base")
            orch.drop_env_database(pg, e.db_name, None)
    if not done:
        orch.create_database(pg, e.db_name, e.db_user, "template0", say)
        progress and progress(40, "初始化数据库(安装 base,约 2 分钟)")
        code, init_logs = orch.run_oneoff(t, e, tag, ["odoo", "-c", "/etc/odoo/odoo.conf", "-d", e.db_name, "-i", "base", "--stop-after-init"], suffix="init", timeout=1800)
        if code != 0:
            say("初始化失败,容器输出:\n" + init_logs)
            raise RuntimeError("Odoo 数据库初始化失败")
    progress and progress(80, "设置语言")
    orch.apply_db_language(t, e, tag, pg, e.db_name, e.lang, say)
    say("全新数据库就绪")


def change_kind(env_id: int, new_kind: str, clone_from: int | None = None, expire_days: int | None = None, neutralize: bool = True,
                old_kind: str | None = None, fresh_db: bool = False) -> None:
    """后台:改档位(kind 已由接口先行切换,便于前端即时反馈;这里失败时回退到 old_kind)。
    步骤:停容器 →(可选)从 clone_from 克隆库 / 只中和当前库 / 换全新空库(升生产)→ 过期等字段 → 按新档位重建容器(挂载只读性随之变化)。"""
    from . import nginx, orchestrator as orch

    say = orch.EnvLogger(env_id)
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if not e:
            return
        t = db.get(Tenant, e.tenant_id)
        src = db.get(Environment, clone_from) if clone_from else None
        old_kind = old_kind or e.kind
        label = f"{KIND_LABEL.get(old_kind, old_kind)} → {KIND_LABEL.get(new_kind, new_kind)}"
        orch._set_status(env_id, "cloning" if (src or fresh_db) else "restarting", f"改为{KIND_LABEL.get(new_kind, new_kind)}环境", progress=5)
        say(f"档位变更:{label}" + (f",数据从「{src.name}」克隆" if src else "") + (",换成全新空库" if fresh_db else ""))
        main = dockerx.get_container(e.container_name or "")
        was_running = bool(main and main.status == "running")
        try:
            if e.container_name and main:
                say("停止容器")
                main.stop(timeout=30)
            if src:
                pg = orch.ensure_tenant_pg(t, db, say)
                clone_data(pg, t, src, e, say, neutralize=neutralize, progress=lambda pct, msg=None: orch._progress(env_id, 10 + int(pct * 0.6), msg))
            elif fresh_db and e.db_name:
                reset_to_empty_db(db, t, e, say, progress=lambda pct, msg=None: orch._progress(env_id, 10 + int(pct * 0.6), msg))
            elif neutralize and new_kind != "production" and e.db_name:
                pg = orch.ensure_tenant_pg(t, db, say)
                orch._progress(env_id, 30, "中和数据库")
                neutralize_db(pg, e, say, t)
            e.kind = new_kind
            if new_kind == "production":
                e.expires_at = None
                e.auto_deploy = False
            elif expire_days is not None:
                e.expires_at = orch.compute_expires_at(expire_days, new_kind)
            db.commit()
            if e.container_name:
                orch._progress(env_id, 80, "按新档位重建容器")
                tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
                say("按新档位重建容器")
                c = orch.run_main_container(t, e, tag)
                nginx.reload()
                orch._progress(env_id, 90, "等待 Odoo 就绪")
                ok = orch._wait_healthy(c, say, on_tick=lambda i: orch._progress(env_id, min(99, 90 + i)))
                if not ok:
                    say("Odoo 未在预期时间内就绪,请查看容器日志")
                say(f"档位变更完成:{label}")
                orch._set_status(env_id, "running" if ok else "failed", None if ok else "改档位后未就绪", progress=100 if ok else 0)
            else:
                say(f"档位变更完成:{label}(环境尚未创建)")
                orch._set_status(env_id, "created", None, progress=0)
        except Exception as ex:  # noqa: BLE001
            log.exception("change_kind failed")
            say(f"失败:{ex}")
            try:
                if not fresh_db and not src:
                    e.kind = old_kind  # 未动数据的情况下回退档位;动过数据(克隆 / 换库)则保留新档位供用户重试
                    db.commit()
            except Exception:  # noqa: BLE001
                pass
            try:
                if e.container_name and was_running and not dockerx.get_container(e.container_name):
                    tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
                    orch.run_main_container(t, e, tag)
                elif main and was_running:
                    main.start()
                nginx.reload()
            except Exception as rb:  # noqa: BLE001
                say(f"恢复容器失败:{rb}")
            orch._set_status(env_id, "failed", f"改档位失败:{str(ex)[:200]}", progress=0)


def refresh_from(env_id: int, src_id: int) -> None:
    """后台:用 src 的数据刷新 env(测试「从生产刷新数据」)。停容器 → 克隆 → 启动。"""
    from . import orchestrator as orch

    say = orch.EnvLogger(env_id)
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        src = db.get(Environment, src_id)
        if not e or not src:
            return
        t = db.get(Tenant, e.tenant_id)
        orch._set_status(env_id, "cloning", f"从「{src.name}」刷新数据", progress=5)
        main = dockerx.get_container(e.container_name or "")
        try:
            if main and main.status == "running":
                say("停止容器")
                main.stop(timeout=30)
            pg = orch.ensure_tenant_pg(t, db, say)
            clone_data(pg, t, src, e, say, neutralize=True, progress=lambda pct, msg=None: orch._progress(env_id, 10 + int(pct * 0.75), msg))
            if main:
                orch._progress(env_id, 88, "启动容器")
                main.start()
                ok = orch._wait_healthy(main, say, on_tick=lambda i: orch._progress(env_id, min(99, 90 + i)))
                orch._set_status(env_id, "running" if ok else "failed", None if ok else "刷新后未就绪", progress=100 if ok else 0)
            else:
                orch._set_status(env_id, "stopped", None, progress=0)
            say(f"数据刷新完成(来源「{src.name}」)")
        except Exception as ex:  # noqa: BLE001
            log.exception("refresh_from failed")
            say(f"失败:{ex}")
            try:
                if main:
                    main.start()
            except Exception as ex:  # noqa: BLE001
                log.warning("失败后重启原容器出错: %s", ex)
            orch._set_status(env_id, "failed", f"刷新数据失败:{str(ex)[:200]}", progress=0)


# ---------------------------------------------------------------- push → 自动部署
# push 自动部署的并发上限(每次 push 到多分支/多环境时不至于同时起 N 个 -u all 打爆主机)
_deploy_pool = None


def _pool():
    global _deploy_pool
    if _deploy_pool is None:
        from concurrent.futures import ThreadPoolExecutor

        _deploy_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="push-deploy")
    return _deploy_pool


def _push_hook(repo_id: int, env_ids: list[int], info: dict) -> None:
    """收到 push:先刷新仓库镜像(后台);测试/开发且开启自动部署的环境 → 排队部署该 commit;生产只记录(界面标「待部署」)。"""
    from . import deploy as deploysvc
    from . import orchestrator as orch

    with SessionLocal() as db:
        r = db.get(Repository, repo_id)
        # 无论是否自动部署,都让镜像跟上远端(项目页 / 提交历史读的是本地镜像)
        if r:
            def _refresh(url=r.url, tid=r.tenant_id):
                try:
                    with SessionLocal() as s2:
                        deploysvc.ensure_mirror(s2, tid, url, force=True, fetch_timeout=600)
                except Exception as ex:  # noqa: BLE001
                    log.warning("push 后刷新镜像失败: %s", ex)

            threading.Thread(target=_refresh, daemon=True, name=f"push-mirror-{repo_id}").start()
        for env_id in env_ids:
            e = db.get(Environment, env_id)
            if not e or e.kind == "production" or not e.auto_deploy or (r and not r.auto_deploy):
                continue
            if not e.container_name or e.status not in ("running", "stopped", "sleeping"):
                log.info("push: 环境 #%s 状态 %s,跳过自动部署", env_id, e.status if e else None)
                continue
            action = e.deploy_action or "update_all"
            if action == "update" and not (e.deploy_modules or "").strip():
                action = "restart"
            if not orch.try_claim(db, e, "deploying", "推送触发,已排队"):
                continue
            d = deploysvc.create_record(db, e, "push", action, e.deploy_modules, info.get("pusher") or info.get("author"), sha=info.get("sha") or None)
            _pool().submit(deploysvc.deploy, d.id)


def register_hooks() -> None:
    gitsvc.register_push_hook(_push_hook)


# ---------------------------------------------------------------- 企业版升级
def enterprise_upgrade_info(db: Session, e: Environment) -> dict:
    """{enabled, repo, current, latest, can_upgrade, error}。latest 通过 ls-remote 探测(不拉代码)。"""
    from . import enterprise as entsvc

    out = {"enabled": e.edition == "enterprise", "repo": None, "current": e.enterprise_commit, "latest": None, "can_upgrade": False, "error": None}
    if e.edition != "enterprise":
        return out
    repo = db.get(Repository, e.enterprise_repo_id) if e.enterprise_repo_id else None
    _tried = []
    if not repo:
        repo, _src, _tried = entsvc.resolve_repo(db, e.tenant_id, e.owner_user_id, str(e.odoo_version))
    if not repo:
        out["error"] = entsvc.describe_failure(_tried)
        return out
    # 平台共享仓库地址只对超管可见,这里不下发
    out["repo"] = {"id": repo.id, "name": repo.name, "url": None if repo.scope == "platform" else repo.url, "scope": repo.scope}
    try:
        info = entsvc.probe(repo.url, entsvc.repo_token(db, repo))
    except Exception as ex:  # noqa: BLE001
        out["error"] = str(ex)
        return out
    latest = info["versions"].get(str(e.odoo_version))
    out["latest"] = latest
    out["can_upgrade"] = bool(latest and latest != e.enterprise_commit)
    if not latest:
        out["error"] = f"企业版仓库中没有 {e.odoo_version}.0 分支"
    return out


def enterprise_upgrade(env_id: int, action: str = "update_all", who: str | None = None) -> None:
    """后台:拉取企业版最新代码 → 换挂载重建容器 → 升级模块 → 健康检查(失败回退旧挂载)。"""
    from . import deploy as deploysvc, enterprise as entsvc, nginx, orchestrator as orch

    say = orch.EnvLogger(env_id)
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if not e:
            return
        t = db.get(Tenant, e.tenant_id)
        repo = db.get(Repository, e.enterprise_repo_id) if e.enterprise_repo_id else None
        _tried = []
        if not repo:
            repo, _, _tried = entsvc.resolve_repo(db, t.id, e.owner_user_id, str(e.odoo_version))
        prev_path, prev_commit = e.enterprise_path, e.enterprise_commit
        orch._set_status(env_id, "deploying", "拉取企业版代码", progress=5)
        try:
            if not repo:
                raise RuntimeError(entsvc.describe_failure(_tried))
            path, sha = entsvc.ensure_code(db, repo, e.odoo_version, say, progress=lambda pct, msg: orch._progress(env_id, 5 + int(pct * 0.35), msg))
            if sha == prev_commit and path == prev_path:
                say("企业版代码已是最新,无需升级")
                orch._set_status(env_id, "running" if dockerx.get_container(e.container_name or "") else "stopped", None, progress=0)
                return
            e.enterprise_path, e.enterprise_commit, e.enterprise_repo_id = path, sha, repo.id
            db.commit()
            say(f"企业版代码 {prev_commit[:12] if prev_commit else '?'} → {sha[:12]}")
            tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
            main = dockerx.get_container(e.container_name or "")
            if main:
                say("停止旧容器")
                main.stop(timeout=30)
                main.remove(force=True)
            if action in ("update", "update_all"):
                from . import databases as dbsvc

                mods = "all" if action == "update_all" else ",".join(m.strip() for m in (e.deploy_modules or "").split(",") if m.strip()) or "all"
                for dbname in dbsvc.all_db_names(db, e):  # 主库 + 附加库(企业版通常没有附加库,循环只跑一次)
                    orch._progress(env_id, 45, f"升级模块 {mods}({dbname})")
                    say(f"[{dbname}] 升级模块:-u {mods}")
                    code, out = orch.run_oneoff(
                        t, e, tag, ["odoo", "-c", "/etc/odoo/odoo.conf", "-d", dbname, "-u", mods, "--stop-after-init"], suffix="upgrade",
                        on_tick=lambda i, el: orch._progress(env_id, 45 + min(35, int(el / 240.0 * 35))),
                    )
                    if code != 0:
                        say(f"[{dbname}] 升级失败,容器输出:\n" + out[-2000:])
                        raise RuntimeError(f"模块升级失败({dbname})")
            orch._progress(env_id, 82, "启动容器")
            c = orch.run_main_container(t, e, tag)
            nginx.reload()
            orch._progress(env_id, 90, "等待 Odoo 就绪")
            if not orch._wait_healthy(c, say, on_tick=lambda i: orch._progress(env_id, min(99, 90 + i))):
                raise RuntimeError("升级后 Odoo 未就绪")
            say(f"企业版升级完成:{sha[:12]}")
            orch._set_status(env_id, "running", None, progress=100)
        except Exception as ex:  # noqa: BLE001
            log.exception("enterprise upgrade failed")
            say(f"失败:{ex}")
            try:
                if prev_path and os.path.isdir(prev_path):
                    say(f"回退企业版代码到 {(prev_commit or '')[:12] or '上一版'}")
                    e.enterprise_path, e.enterprise_commit = prev_path, prev_commit
                    db.commit()
                if not dockerx.get_container(e.container_name or ""):
                    tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
                    c = orch.run_main_container(t, e, tag)
                    nginx.reload()
                    ok = orch._wait_healthy(c, say)
                    orch._set_status(env_id, "running" if ok else "failed", None if ok else "回退后未就绪", progress=0)
                else:
                    orch._set_status(env_id, "running", None, progress=0)
            except Exception as rb:  # noqa: BLE001
                say(f"回退失败:{rb}")
                orch._set_status(env_id, "failed", "企业版升级失败且回退失败", progress=0)
