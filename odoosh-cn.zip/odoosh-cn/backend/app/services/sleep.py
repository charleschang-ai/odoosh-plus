"""开发环境闲置休眠 / 唤醒(仿 odoo.sh)。

- 活跃度:nginx 把每个实例的访问日志写到共享数据目录 nginx-logs/<tenant>--<env>.log(buffer 刷盘 ≤10s),
  平台按文件 mtime 判定「最后访问时间」;再与容器启动时间、Environment.last_active_at 取最大值。
- 判定:仅 kind=dev、状态 running、闲置阈值 = 实例 sleep_idle_hours(None → 全局 sleep.idle_hours;0 = 关闭)。
- 休眠:stop 容器,状态 sleeping;nginx 上游不可达 → @down → 平台 /api/wake/<tenant>/<env> 返回「唤醒中」页并后台拉起。
- 唤醒:start 容器 → 健康检查 → running,并刷新 last_active_at。
"""

import logging
import os
import threading
import time
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from ..config import settings
from ..db import SessionLocal
from ..models import Environment, Tenant
from . import dockerx

log = logging.getLogger("odoosh.sleep")

CHECK_INTERVAL = 60


def logs_dir() -> str:
    d = os.path.join(settings.data_dir, "nginx-logs")
    os.makedirs(d, exist_ok=True)
    return d


def access_log_path(tenant_slug: str, env_name: str) -> str:
    return os.path.join(logs_dir(), f"{tenant_slug}--{env_name}.log")


def idle_hours_for(e: Environment, t: Tenant | None = None, default: float | None = None) -> float:
    """优先级:实例 sleep_idle_hours > 组织 sleep_idle_hours > 平台 sleep.idle_hours(可由调用方预先读好传入 default)。"""
    if e.sleep_idle_hours is not None:
        return float(e.sleep_idle_hours)
    if t is not None and t.sleep_idle_hours is not None:
        return float(t.sleep_idle_hours)
    if default is not None:
        return default
    from ..routers.settings import get_setting

    with SessionLocal() as db:
        try:
            return float(get_setting(db, "sleep.idle_hours") or 0)
        except ValueError:
            return 0.0


def last_activity(t: Tenant, e: Environment, container=None) -> datetime | None:
    cands: list[datetime] = []
    if e.last_active_at:
        cands.append(e.last_active_at if e.last_active_at.tzinfo else e.last_active_at.replace(tzinfo=timezone.utc))
    p = access_log_path(t.slug, e.name)
    try:
        cands.append(datetime.fromtimestamp(os.path.getmtime(p), tz=timezone.utc))
    except OSError:
        pass
    if container is not None:
        dt = parse_docker_time(container.attrs.get("State", {}).get("StartedAt"))
        if dt:
            cands.append(dt)
    return max(cands) if cands else None


def parse_docker_time(v: str | None) -> datetime | None:
    """Docker 时间形如 2026-08-16T10:11:12.123456789Z(纳秒);裁到微秒再解析。"""
    if not v or v.startswith("0001-"):
        return None
    try:
        v = v.rstrip("Z")
        if "." in v:
            head, frac = v.split(".", 1)
            v = f"{head}.{frac[:6]}"
        return datetime.fromisoformat(v).replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def touch(env_id: int) -> None:
    from sqlalchemy import update

    with SessionLocal() as db:
        db.execute(update(Environment).where(Environment.id == env_id).values(last_active_at=datetime.now(timezone.utc)))
        db.commit()


# ---------------------------------------------------------------- 休眠
def put_to_sleep(env_id: int, reason: str = "闲置") -> None:
    from . import orchestrator as orch

    say = orch.EnvLogger(env_id)
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if not e or e.kind != "dev":
            return
        if not orch.try_claim(db, e, "stopping", f"{reason},进入休眠"):
            return
        try:
            c = dockerx.get_container(e.container_name or "")
            if c and c.status == "running":
                c.stop(timeout=30)
            say(f"{reason}超过阈值,已休眠(访问域名会自动唤醒)")
            orch._set_status(env_id, "sleeping", None, progress=0)
        except Exception as ex:  # noqa: BLE001
            log.warning("休眠 env#%s 失败: %s", env_id, ex)
            orch._set_status(env_id, "running", None, progress=0)


def wake(env_id: int, who: str = "访问触发") -> bool:
    """唤醒(调用方已把状态置为 waking)。返回是否就绪。"""
    from . import nginx, orchestrator as orch

    say = orch.EnvLogger(env_id)
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if not e:
            return False
        t = db.get(Tenant, e.tenant_id)
        try:
            say(f"唤醒({who})")
            orch.ensure_tenant_pg(t, db, say)
            orch._progress(env_id, 30, "启动容器")
            c = dockerx.get_container(e.container_name or "")
            if not c:
                raise RuntimeError("容器不存在,请重新创建")
            orch.refresh_odoo_conf(t, e, say)  # 休眠期间改过的设置(日志等级 / 附加项 / 附加库)在此生效
            if orch.needs_rebuild(c, t, e):
                # 存量容器缺少安全加固(pids_limit / cap_drop / no-new-privileges / init):唤醒时重建一次
                say("应用安全加固:重建容器后启动")
                tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
                c = orch.run_main_container(t, e, tag)
            else:
                c.start()
            nginx.connect_web_to_network(e.network_name)
            orch._progress(env_id, 60, "等待 Odoo 就绪")
            ok = orch._wait_healthy(c, say, on_tick=lambda i: orch._progress(env_id, min(98, 60 + i * 5)))
            if ok:
                say("已唤醒")
                orch._set_status(env_id, "running", None, progress=100, last_active_at=datetime.now(timezone.utc))
                enforce_project_cap_async(e.project_id or e.id, keep_env_id=env_id)
            else:
                orch._set_status(env_id, "failed", "唤醒后未就绪", progress=0)
            return ok
        except Exception as ex:  # noqa: BLE001
            say(f"唤醒失败: {ex}")
            orch._set_status(env_id, "failed", str(ex)[:250], progress=0)
            return False


def request_wake(env: Environment, db, who: str = "访问触发") -> bool:
    """把 sleeping → waking 并后台唤醒。返回是否发起(已在 waking 中返回 False)。"""
    from . import orchestrator as orch

    if env.status != "sleeping":
        return False
    if not orch.try_claim(db, env, "waking", "唤醒中"):
        return False
    threading.Thread(target=wake, args=(env.id, who), daemon=True, name=f"wake-{env.id}").start()
    return True


# ---------------------------------------------------------------- 每项目同时在线分支数上限
def max_running_per_project() -> int:
    from ..routers.settings import get_setting

    with SessionLocal() as db:
        try:
            return int(get_setting(db, "sleep.max_running_per_project") or 0)
        except ValueError:
            return 0


def enforce_project_cap(project_root_id: int | None = None, keep_env_id: int | None = None, containers: dict | None = None) -> list[int]:
    """每个项目最多同时运行 N 个开发分支环境(N=系统设置 sleep.max_running_per_project,0=不限;生产/测试不计入、不休眠)。
    超出时把「最久没有访问」的开发环境休眠。project_root_id 为空则检查全部项目;keep_env_id 表示刚被唤醒/启动的实例,优先保留。
    返回被休眠的实例 id。"""
    cap = max_running_per_project()
    if cap <= 0:
        return []
    from . import orchestrator as orch  # noqa: F401

    slept: list[int] = []
    with SessionLocal() as db:
        rows = db.execute(
            select(Environment, Tenant).join(Tenant, Tenant.id == Environment.tenant_id)
            .where(Environment.kind == "dev", Environment.status == "running", Environment.container_name.is_not(None), Environment.deleted_at.is_(None))
        ).all()
        groups: dict[int, list[tuple[Environment, Tenant]]] = {}
        for e, t in rows:
            root = e.project_id or e.id
            if project_root_id is not None and root != project_root_id:
                continue
            groups.setdefault(root, []).append((e, t))
        for root, members in groups.items():
            if len(members) <= cap:
                continue
            # 最近活动时间:越久越先睡;刚唤醒的排最后(一次 list 拿全部容器,不再逐个 inspect)
            if containers is None:
                containers = orch.running_containers()
            last_by_id = {
                e.id: (datetime.max.replace(tzinfo=timezone.utc) if e.id == keep_env_id
                       else last_activity(t, e, containers.get(e.container_name)) or datetime.min.replace(tzinfo=timezone.utc))
                for e, t in members
            }
            members.sort(key=lambda item: last_by_id[item[0].id])
            for e, _t in members[: len(members) - cap]:
                slept.append(e.id)
                log.info("项目 #%s 在线开发环境 %d > 上限 %d,休眠最久未访问的 #%s %s", root, len(members), cap, e.id, e.name)
    for env_id in slept:
        put_to_sleep(env_id, f"项目同时在线开发环境超过上限 {cap} 个,自动休眠最久未访问的")
    return slept


def enforce_project_cap_async(project_root_id: int | None, keep_env_id: int | None = None, delay: float = 5.0) -> None:
    """启动 / 唤醒 / 创建完成后延迟几秒再检查(等新容器状态落库)。"""
    def _run():
        time.sleep(delay)
        try:
            enforce_project_cap(project_root_id, keep_env_id)
        except Exception as ex:  # noqa: BLE001
            log.warning("项目在线上限检查出错: %s", ex)
    threading.Thread(target=_run, daemon=True, name="project-cap").start()


# ---------------------------------------------------------------- 巡检
def _check_once() -> None:
    from . import orchestrator as orch

    containers = orch.running_containers()  # 一次 list;以前每分钟每个开发实例一次 inspect(两遍)
    try:
        enforce_project_cap(containers=containers)
    except Exception as ex:  # noqa: BLE001
        log.warning("项目在线上限检查出错: %s", ex)

    now = datetime.now(timezone.utc)
    default_idle = idle_hours_for(Environment(), None)  # 平台默认值只读一次(以前每实例开一个 session)
    with SessionLocal() as db:
        rows = db.execute(
            select(Environment, Tenant).join(Tenant, Tenant.id == Environment.tenant_id)
            .where(Environment.kind == "dev", Environment.status == "running", Environment.container_name.is_not(None))
        ).all()
        todo: list[tuple[int, str, float]] = []
        for e, t in rows:
            hours = idle_hours_for(e, t, default=default_idle)
            if hours <= 0:
                continue
            c = containers.get(e.container_name)
            last = last_activity(t, e, c)
            if last is None:
                continue
            idle = (now - last).total_seconds() / 3600.0
            if idle >= hours:
                todo.append((e.id, e.name, idle))
    for env_id, name, idle in todo:
        log.info("开发实例 #%s %s 闲置 %.1f 小时,休眠", env_id, name, idle)
        put_to_sleep(env_id, f"闲置 {idle:.1f} 小时")


ACCESS_LOG_MAX = 1024 * 1024  # 单个实例访问日志超过 1MB 就截断(只用 mtime,内容无用)


def truncate_access_logs(max_bytes: int = ACCESS_LOG_MAX) -> int:
    """nginx 为每个实例写的访问日志只用于 mtime;超过阈值就清空并保留原 mtime,避免无限增长。返回截断个数。"""
    n = 0
    try:
        names = os.listdir(logs_dir())
    except OSError:
        return 0
    for name in names:
        if not name.endswith(".log"):
            continue
        p = os.path.join(logs_dir(), name)
        try:
            st = os.stat(p)
            if st.st_size <= max_bytes:
                continue
            os.truncate(p, 0)  # nginx 以 O_APPEND 写,截断后继续从 0 追加,不需 reopen
            os.utime(p, (st.st_atime, st.st_mtime))
            n += 1
        except OSError as ex:
            log.debug("截断访问日志 %s 失败: %s", p, ex)
    return n


def start_scheduler(interval: int = CHECK_INTERVAL) -> None:
    def loop():
        time.sleep(30)
        i = 0
        while True:
            try:
                _check_once()
            except Exception as ex:  # noqa: BLE001
                log.warning("休眠巡检出错: %s", ex)
            i += 1
            if i % 10 == 0:  # 每 10 分钟
                try:
                    n = truncate_access_logs()
                    if n:
                        log.info("已截断 %s 个实例访问日志", n)
                except Exception as ex:  # noqa: BLE001
                    log.warning("截断访问日志出错: %s", ex)
            time.sleep(interval)

    threading.Thread(target=loop, name="env-sleep", daemon=True).start()


WAKE_PAGE = """<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta http-equiv="refresh" content="{refresh}">
<title>{title}</title></head>
<body style="font-family:-apple-system,Segoe UI,PingFang SC,Microsoft YaHei,sans-serif;padding:48px;color:#0f172a;background:#f8fafc">
<div style="max-width:560px;margin:10vh auto;background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:32px 36px;box-shadow:0 1px 3px rgba(0,0,0,.05)">
<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
<div style="width:14px;height:14px;border-radius:50%;background:{color};box-shadow:0 0 0 4px {color}33"></div>
<h2 style="margin:0;font-size:20px">{title}</h2></div>
<p style="color:#475569;line-height:1.7;margin:0 0 8px">{body}</p>
<p style="color:#94a3b8;font-size:12px;margin:0">实例 {tenant}/{env} · 页面每 {refresh} 秒自动刷新,就绪后将直接进入 Odoo。</p>
</div></body></html>"""
