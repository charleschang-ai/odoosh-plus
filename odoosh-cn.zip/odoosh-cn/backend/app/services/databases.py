"""附加数据库(一个实例多个库)。

模型:一个分支 = 一个实例(容器 + 一份代码);一个实例 = 1 个主库(Environment.db_name)+ N 个附加库(EnvironmentDatabase)。
所有库共用容器 / 代码 / db_user / filestore 目录;每个附加库多一个子域名 <name>.<实例域名>,
Odoo 靠 odoo.conf 的 `dbfilter = ^(<主库>|<主库>_%d)$` 按请求域名选库(%d = 主机名第一段),
nginx 的 server_name 带 `*.<实例域名>` 通配。因此加库 / 删库既不需要重启 Odoo,也不需要 reload nginx。

规则
- 只有社区版实例可建附加库(企业版按许可证按库授权);未绑仓库的普通实例受设置 db.allow_plain_env 控制。
- 配额三级:平台 db.max_extra_per_env → Tenant.max_dbs_per_env → Environment.max_dbs;组织总量 Tenant.max_dbs_total。
- 附加库名 [a-z0-9]{1,20}(既是库名后缀又是子域名标签,故不允许 - / _),不能与实例名 / 实例域名第一段相同。

`EnvDb` 是「实例 + 指定库」的只读视图:属性透传 Environment,只覆盖 db_name / admin_password / domain / url。
备份、恢复、克隆、中性化、SSO 等原本按 `e.db_name` 工作的服务函数,传入 EnvDb 即可对附加库生效,不必逐个改签名。
"""

import json
import logging
import os
import re
import shutil
import threading
import time
from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import SessionLocal
from ..models import Environment, Tenant
from ..models_db import EnvironmentDatabase
from . import dockerx
from .throttlelog import ThrottledLog

log = logging.getLogger("odoosh.databases")

NAME_RE = re.compile(r"^[a-z0-9]{1,20}$")
BUSY_STATES = ("creating", "dropping", "restoring")


# ---------------------------------------------------------------- 视图
class EnvDb:
    """实例 + 指定库 的视图(row=None 表示主库)。属性透传 Environment,写属性也透传(避免误改到视图上)。"""

    __slots__ = ("_e", "row")

    def __init__(self, e: Environment, row: EnvironmentDatabase | None = None):
        object.__setattr__(self, "_e", e)
        object.__setattr__(self, "row", row)

    # ---- 覆盖的字段 ----
    @property
    def env(self) -> Environment:
        return self._e

    @property
    def is_primary(self) -> bool:
        return self.row is None

    @property
    def database_id(self) -> int | None:
        return self.row.id if self.row is not None else None

    @property
    def db_name(self) -> str | None:
        return self.row.db_name if self.row is not None else self._e.db_name

    @property
    def db_label(self) -> str:
        return self.row.name if self.row is not None else "主库"

    @property
    def admin_password(self) -> str | None:
        if self.row is not None and self.row.admin_password:
            return self.row.admin_password
        return self._e.admin_password

    @property
    def admin_login(self) -> str:
        return (self.row.admin_login if self.row is not None and self.row.admin_login else None) or "admin"

    @property
    def domain(self) -> str | None:
        if self.row is None:
            return self._e.domain
        return domain_of(self._e, self.row)

    @property
    def url(self) -> str | None:
        if self.row is None:
            return self._e.url
        return url_of(self._e, self.row)

    def __getattr__(self, name):
        return getattr(self._e, name)

    def __setattr__(self, name, value):
        if name in ("_e", "row"):
            object.__setattr__(self, name, value)
        else:
            setattr(self._e, name, value)

    def __repr__(self):
        return f"<EnvDb env#{self._e.id} {self.db_name}>"


def view(db: Session, e: Environment, database_id: int | None) -> EnvDb:
    """按 database_id 取视图;None = 主库。附加库不属于该实例时抛 ValueError。"""
    if database_id is None:
        return EnvDb(e)
    row = db.get(EnvironmentDatabase, database_id)
    if row is None or row.environment_id != e.id:
        raise ValueError("附加数据库不存在或不属于该实例")
    return EnvDb(e, row)


def view_by_name(db: Session, e: Environment, db_name: str | None) -> EnvDb:
    """按库名取视图(None / 主库名 = 主库)。"""
    if not db_name or db_name == e.db_name:
        return EnvDb(e)
    row = db.scalar(select(EnvironmentDatabase).where(EnvironmentDatabase.environment_id == e.id, EnvironmentDatabase.db_name == db_name))
    if row is None:
        raise ValueError(f"数据库 {db_name} 不属于该实例")
    return EnvDb(e, row)


# ---------------------------------------------------------------- 命名 / 路由
def extra_db_name(e: Environment, name: str) -> str:
    return f"{e.db_name}_{name}"


def domain_of(e: Environment, row: EnvironmentDatabase) -> str | None:
    return f"{row.name}.{e.domain}" if e.domain else None


def url_of(e: Environment, row: EnvironmentDatabase) -> str | None:
    from .nginx import access_mode, env_url

    if access_mode() == "port":
        return None  # 端口直连模式:附加库无法按域名路由,不给出会 404 的死链(前端据此隐藏/禁用「打开」)
    d = domain_of(e, row)
    if not d:
        return None
    # 恒 http:附加库域名 <库>.<实例>-<组织>.<基础域名> 比实例深一级,而泛证书 *.<基础域名> 只匹配一级
    # (Let's Encrypt 不签 *.*.<域名>),给 https 链接只会让用户撞证书域名不匹配告警。
    return env_url(d, secure=False)


def routing(e: Environment, t: Tenant | None = None) -> dict:
    """主库 / 附加库按域名选库的路由模式(决定 odoo.conf 的 dbfilter 写法)。

    Odoo 的 dbfilter 是一个正则,%d 会被替换成请求主机名的第一段;它是唯一能区分域名的手段,且必须**互斥**:
    对附加库域名 shop.<实例域名>,主库不能也匹配上,否则 Odoo 会弹数据库选择页。
    因此主库那一支不能写成无条件的 ^acme_dev$,而要写成「%d 等于主库自己的域名首段时才匹配」:
      exact:域名首段 == 主库名后缀(旧的两级域名 <实例>.<组织>.<基础域名>):  ^acme_%d$ | ^acme_dev_%d$
      fuzzy:首段与主库名后缀只差 - / _(实例名含 -),
             或首段是当前扁平域名的「<实例>-<组织>」(dev-acme,见 nginx.env_domain):
                                                     ^acme_(?=[%d_]{N}$)dev$ | ^acme_dev_%d$
             (正则做不了字符串变换,退而用「字符集 + 长度」判断:主库后缀的每个字符都要出现在首段里。
              附加库请求的首段是库名(shop),字符集对不上 → 主库那一支不匹配,故两支互斥。
              为防误判,附加库名不得包含主库后缀的全部字符 —— validate_name 已就此校验)
      none: 首段与主库名对不上(超管自定义域名):               ^acme_dev$      —— 不支持附加库
    另一层保险:每个实例有自己的 db_user、只拥有本实例的库,Odoo 列库时只看得到它们,别的实例的 acme_shop 不会被列出。
    """
    db = e.db_name or ""
    if not db:
        return {"mode": "none", "reason": "实例尚未创建数据库", "dbfilter": ""}
    from .nginx import access_mode

    if access_mode() == "port":
        # 端口直连模式:Host 是 IP,%d 取不到有意义的域名首段,dbfilter 只能字面匹配主库;附加库无法按域名区分
        return {"mode": "none", "pfx": "", "suffix": db, "label": "",
                "reason": "端口直连访问模式下无法按域名区分数据库,附加库不可用(切回域名分流模式后恢复)",
                "dbfilter": f"^{re.escape(db)}$"}
    slug = (t.slug if t is not None else (e.tenant.slug if getattr(e, "tenant", None) else "")) or ""
    pfx = f"{slug}_".replace("-", "_") if slug else ""
    suffix = db[len(pfx):] if pfx and db.startswith(pfx) else db
    if not pfx or not suffix:
        pfx, suffix = "", db
    label = (e.domain or "").split(".")[0].lower()
    esc_db, esc_pfx, esc_suffix = re.escape(db), re.escape(pfx), re.escape(suffix)
    if label and label == suffix and pfx:
        return {"mode": "exact", "pfx": pfx, "suffix": suffix, "label": label, "reason": None,
                "dbfilter": f"^{esc_pfx}%d$|^{esc_db}_%d$"}
    # 扁平域名(当前自动格式 <实例>-<组织>.<基础域名>,为了让一张 *.<基础域名> 泛证书覆盖所有实例):
    # 首段 dev-acme 与库名后缀 dev 既不相等也不只差 - / _,但「字符集 + 长度」判据依然成立,
    # 故与 fuzzy 共用同一套 dbfilter 写法(validate_name 对 fuzzy 的防混淆校验也随之生效)
    # 撞车兜底的域名带实例 id(见 nginx.unique_env_domain),两种都要认,否则这些实例白白失去附加库能力
    flats = []
    if slug and e.name:
        flats.append(f"{e.name}-{slug}".lower())
        if getattr(e, "id", None):
            flats.append(f"{e.name}-{slug}-{e.id}".lower())
    if pfx and label and (label.replace("-", "_") == suffix
                          or (label in flats and set(suffix) - {"_"} <= set(label))):
        return {"mode": "fuzzy", "pfx": pfx, "suffix": suffix, "label": label, "reason": None,
                "dbfilter": f"^{esc_pfx}(?=[%d_]{{{len(suffix)}}}$){esc_suffix}$|^{esc_db}_%d$"}
    return {"mode": "none", "pfx": pfx, "suffix": suffix, "label": label,
            "reason": f"实例域名首段「{label or '?'}」与数据库名「{db}」对不上(自定义域名),Odoo 无法按域名区分主库与附加库;改回自动域名后即可使用",
            "dbfilter": f"^{esc_db}$"}


def dbfilter_for(e: Environment, t: Tenant | None = None) -> str:
    """odoo.conf 的 dbfilter(见 routing())。"""
    return routing(e, t)["dbfilter"]


def rows_of(db: Session, e: Environment, ready_only: bool = False) -> list[EnvironmentDatabase]:
    q = select(EnvironmentDatabase).where(EnvironmentDatabase.environment_id == e.id).order_by(EnvironmentDatabase.id)
    if ready_only:
        q = q.where(EnvironmentDatabase.status == "ready")
    return list(db.scalars(q).all())


def all_db_names(db: Session, e: Environment, ready_only: bool = True) -> list[str]:
    """实例的全部库名:主库在前。部署 -u / 删实例 用。"""
    names = [e.db_name] if e.db_name else []
    names += [r.db_name for r in rows_of(db, e, ready_only)]
    return names


def all_views(db: Session, e: Environment, ready_only: bool = True) -> list[EnvDb]:
    return [EnvDb(e)] + [EnvDb(e, r) for r in rows_of(db, e, ready_only)]


def counts_bulk(db: Session, env_ids: list[int]) -> dict[int, int]:
    """{env_id: 附加库数}(列表接口用,一次查询)。"""
    if not env_ids:
        return {}
    rows = db.execute(
        select(EnvironmentDatabase.environment_id, func.count(EnvironmentDatabase.id))
        .where(EnvironmentDatabase.environment_id.in_(env_ids), EnvironmentDatabase.status != "dropping")
        .group_by(EnvironmentDatabase.environment_id)
    ).all()
    return {eid: n for eid, n in rows}


# ---------------------------------------------------------------- 配额 / 准入
def _int_setting(db: Session, key: str, default: int) -> int:
    from ..routers.settings import get_setting

    try:
        return int(get_setting(db, key) or default)
    except ValueError:
        return default


def per_env_limit(db: Session, e: Environment, t: Tenant | None = None) -> int:
    """该实例最多几个附加库:实例覆盖 > 组织覆盖 > 平台默认。"""
    if e.max_dbs is not None:
        return max(0, int(e.max_dbs))
    t = t or db.get(Tenant, e.tenant_id)
    if t is not None and t.max_dbs_per_env is not None:
        return max(0, int(t.max_dbs_per_env))
    return max(0, _int_setting(db, "db.max_extra_per_env", 3))


def tenant_total_used(db: Session, tenant_id: int) -> int:
    return int(db.scalar(select(func.count(EnvironmentDatabase.id)).where(EnvironmentDatabase.tenant_id == tenant_id, EnvironmentDatabase.status != "dropping")) or 0)


def feature_state(db: Session, e: Environment, t: Tenant | None = None) -> dict:
    """前端 / 校验共用:{enabled, reason, limit, used, tenant_limit, tenant_used, allowed_now}。
    enabled = 该实例是否具备附加库能力(社区版 + 绑仓库或允许普通实例 + 配额>0);allowed_now 再叠加实例状态。"""
    t = t or db.get(Tenant, e.tenant_id)
    from ..routers.settings import get_setting

    used = len(rows_of(db, e))
    limit = per_env_limit(db, e, t)
    tenant_limit = t.max_dbs_total if t is not None else None
    tenant_used = tenant_total_used(db, e.tenant_id)
    reason = None
    rt = routing(e, t)
    if (e.edition or "community") == "enterprise":
        reason = "企业版按许可证按数据库授权,不支持附加数据库"
    elif not (e.repo_url and e.branch) and (get_setting(db, "db.allow_plain_env") or "0") != "1":
        reason = "未绑定 Git 仓库的普通实例不能创建附加数据库(平台设置可放开)"
    elif limit <= 0:
        reason = "附加数据库功能未开启(每实例上限为 0)"
    elif rt["mode"] == "none" and e.db_name:
        reason = rt["reason"]
    enabled = reason is None
    allowed_now = enabled and used < limit and (tenant_limit is None or tenant_used < tenant_limit)
    if enabled and used >= limit:
        reason = f"已达本实例上限({limit} 个附加库),请联系管理员提升"
    elif enabled and tenant_limit is not None and tenant_used >= tenant_limit:
        reason = f"已达组织附加库总量上限({tenant_limit} 个)"
    return {"enabled": enabled, "allowed_now": allowed_now, "reason": reason, "limit": limit, "used": used,
            "tenant_limit": tenant_limit, "tenant_used": tenant_used}


def validate_name(db: Session, e: Environment, name: str) -> str:
    name = (name or "").strip().lower()
    if not NAME_RE.match(name):
        raise ValueError("名称只能是 1~20 位小写字母或数字(它同时是子域名和库名后缀,不能含 - 或 _)")
    if name == (e.name or "").lower() or name == (e.domain or "").split(".")[0]:
        raise ValueError("名称不能与实例名 / 实例域名第一段相同(会与主库的域名路由冲突)")
    if name in ("www", "api", "odoosh"):
        raise ValueError("该名称为保留字")
    if not e.db_name:
        raise ValueError("实例尚未创建数据库")
    rt = routing(e)
    if rt["mode"] == "fuzzy":
        # 模糊路由(实例名含 -):主库那一支靠「字符集 ⊆ %d」判断,附加库名若包含主库后缀的全部字符会被误判为主库
        need = set(rt["suffix"]) - {"_"}
        if need and need <= set(name):
            raise ValueError(f"名称不能同时包含实例名「{rt['label']}」的全部字符(会与主库的域名路由混淆),请换一个")
    if len(extra_db_name(e, name)) > 63:
        raise ValueError("库名过长(PostgreSQL 限制 63 字符),请用更短的名称")
    dup = db.scalar(select(EnvironmentDatabase.id).where(EnvironmentDatabase.environment_id == e.id, EnvironmentDatabase.name == name))
    if dup:
        raise ValueError(f"本实例已有名为「{name}」的数据库")
    return name


def check_can_create(db: Session, e: Environment, t: Tenant | None = None) -> None:
    st = feature_state(db, e, t)
    if not st["allowed_now"]:
        raise ValueError(st["reason"] or "当前不能创建附加数据库")
    if not e.container_name or not e.db_name:
        raise ValueError("实例尚未创建完成,请先「创建并启动」")


# ---------------------------------------------------------------- 日志 / 状态
def _update_row(row_id: int, **values) -> None:
    from sqlalchemy import update

    with SessionLocal() as db:
        db.execute(update(EnvironmentDatabase).where(EnvironmentDatabase.id == row_id).values(**values))
        db.commit()


def _set_status(row_id: int, status: str, message: str | None = None, progress: int | None = None) -> None:
    values = {"status": status, "status_message": (message or "")[:250] or None}
    if progress is not None:
        values["progress"] = max(0, min(100, int(progress)))
    _update_row(row_id, **values)


class DbLogger(ThrottledLog):
    """附加库操作日志:同时推到实例的 SSE 日志流(env:<id>),并落到实例 log 字段(与实例日志同一处查看)。"""

    def __init__(self, env_id: int, row_id: int, label: str):
        super().__init__()
        self.env_id, self.row_id, self.label = env_id, row_id, label

    def _persist(self, text: str, last_msg: str) -> None:
        from .orchestrator import _update_env

        _update_env(self.env_id, log=text)

    def __call__(self, msg: str) -> None:
        line = f"[{datetime.now().strftime('%H:%M:%S')}] [库 {self.label}] {msg}"
        log.info("envdb#%s %s", self.row_id, msg)
        self.add(line, msg)
        _update_row(self.row_id, status_message=msg[:250])
        try:
            from . import logstream

            logstream.publish(f"env:{self.env_id}", line)
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------- 建库
def conf_is_legacy(t: Tenant, e: Environment) -> bool:
    """磁盘上的 odoo.conf 是否还是旧格式(带 db_name = / dbfilter 精确匹配):是则容器在跑的配置路由不到附加库,首次加库后需重启一次。"""
    from . import orchestrator as orch

    p = os.path.join(orch.env_dir(t, e), "config", "odoo.conf")
    try:
        with open(p, encoding="utf-8") as f:
            txt = f.read()
    except OSError:
        return False
    m = re.search(r"^\s*dbfilter\s*=\s*(.*)$", txt, re.M)
    cur = (m.group(1).strip() if m else "")
    return bool(re.search(r"^\s*db_name\s*=", txt, re.M)) or cur != dbfilter_for(e, t)


def _rewrite_conf(t: Tenant, e: Environment) -> None:
    """库数变化后重写 odoo.conf(dbfilter 新格式、db_maxconn 按库数放宽);下次重启生效,不主动重启。"""
    try:
        from . import images, orchestrator as orch

        orch.write_odoo_conf(t, e, pg_host=orch.pg_container_name(t), uid=orch.env_odoo_uid(e),
                             core_addons=images.core_addons_for(e))
    except Exception as ex:  # noqa: BLE001
        log.debug("重写 odoo.conf 失败(忽略): %s", ex)


def _restart_for_new_conf(e: Environment, say) -> None:
    """老实例首次加库:容器里跑的还是旧 dbfilter,重启一次以加载新配置(几十秒;主库短暂不可用)。"""
    from . import orchestrator as orch

    c = dockerx.get_container(e.container_name or "")
    if not c or c.status != "running":
        return
    say("首次启用附加数据库:重启实例以加载新的 dbfilter 配置(约 15~30 秒)")
    try:
        c.restart(timeout=30)
        orch._wait_healthy(c, say, timeout=180)
    except Exception as ex:  # noqa: BLE001
        say(f"重启实例失败(请手动重启一次实例):{ex}")


def _opts(row: EnvironmentDatabase) -> dict:
    try:
        return json.loads(row.options or "{}") or {}
    except ValueError:
        return {}


def _jsonrpc_db(container, method: str, args: list, timeout: int = 60) -> dict:
    """在实例容器内调 Odoo 的 /jsonrpc(service=db):list_lang / list_countries / create_database。返回 {"result":…} 或 {"error":…}。"""
    body = json.dumps({"jsonrpc": "2.0", "method": "call", "id": 1, "params": {"service": "db", "method": method, "args": args}})
    code, out = container.exec_run(["curl", "-s", "-m", str(timeout), "-X", "POST", "-H", "Content-Type: application/json",
                                    "--data-binary", body, "http://localhost:8069/jsonrpc"])
    text = (out or b"").decode(errors="ignore")
    if code != 0:
        return {"error": {"message": f"curl 退出码 {code}: {text[-200:]}"}}
    try:
        return json.loads(text)
    except ValueError:
        return {"error": {"message": f"非 JSON 响应: {text[:200]}"}}


def native_options(e: Environment) -> dict:
    """原生建库表单要的语言 / 国家列表(问运行中的 Odoo;拿不到时给一份常用短表)。"""
    langs, countries = [], []
    c = dockerx.get_container(e.container_name or "")
    if c and c.status == "running":
        r = _jsonrpc_db(c, "list_lang", [], timeout=20)
        langs = [{"code": x[0], "name": x[1]} for x in (r.get("result") or []) if isinstance(x, (list, tuple)) and len(x) >= 2]
        r = _jsonrpc_db(c, "list_countries", [e.admin_password or ""], timeout=20)  # 非白名单方法:第一个参数是 master password
        countries = [{"code": x[0], "name": x[1]} for x in (r.get("result") or []) if isinstance(x, (list, tuple)) and len(x) >= 2]
    if not langs:
        langs = [{"code": "zh_CN", "name": "中文 (简体) / Chinese (Simplified)"}, {"code": "zh_TW", "name": "中文 (繁體) / Chinese (Traditional)"},
                 {"code": "en_US", "name": "English (US)"}, {"code": "ja_JP", "name": "日本語 / Japanese"}, {"code": "ko_KR", "name": "한국어 / Korean"}]
    if not countries:
        countries = [{"code": "CN", "name": "中国"}, {"code": "HK", "name": "中国香港"}, {"code": "TW", "name": "台湾"}, {"code": "US", "name": "United States"}, {"code": "SG", "name": "Singapore"}]
    return {"langs": langs, "countries": countries}


# 一次性容器里直接调 Odoo 的 exp_create_database(与数据库管理器「创建数据库」同一段代码:建库 + 装 base + 设登录名/密码/语言/国家/手机/演示数据)。
# 不走运行中实例的 /jsonrpc:那条路被 list_db=False 挡住(check_db_management_enabled),而我们有意关闭 list_db。
_NATIVE_CREATE_PY = r"""
import sys, json
import odoo
import odoo.tools.config  # noqa: F401  (Odoo 19 起 import odoo 不再自动带 tools)
from odoo.tools import config
name, demo, lang, password, login, country, phone = json.loads(sys.argv[1])
config.parse_config(["-c", "/etc/odoo/odoo.conf"])
config["list_db"] = True   # 只在本进程内放开管理函数
import odoo.service.db as dbsvc, inspect
kw = dict(user_password=password, login=login, country_code=country)
if "phone" in inspect.signature(dbsvc.exp_create_database).parameters:  # Odoo 13+ 才有 phone 参数
    kw["phone"] = phone
dbsvc.exp_create_database(name, demo, lang, **kw)
print("NATIVE_CREATE_OK")
"""


def _native_create(t: Tenant, e: Environment, tag: str, row: EnvironmentDatabase, opts: dict, say, on_tick=None) -> None:
    """Odoo 原生建库(一次性容器,同 -i base 的耗时 1~3 分钟):登录名 / 密码 / 语言 / 国家 / 手机 / 演示数据都按表单来。"""
    from . import orchestrator as orch

    login = (opts.get("login") or "admin").strip()
    password = opts.get("password") or row.admin_password or dockerx.rand_password(16)
    lang = opts.get("lang") or "zh_CN"
    country = (opts.get("country_code") or "").strip() or None
    phone = (opts.get("phone") or "").strip() or None
    demo = bool(opts.get("demo"))
    say(f"Odoo 原生建库:登录名 {login},语言 {lang},国家 {country or '-'},演示数据 {'是' if demo else '否'}(安装 base,约 1~3 分钟)")
    args = json.dumps([row.db_name, demo, lang, password, login, country, phone], ensure_ascii=False)
    code, logs = orch.run_oneoff(t, e, tag, ["python3", "-c", _NATIVE_CREATE_PY, args], suffix=f"init-{row.name}", timeout=1800, on_tick=on_tick)
    if code != 0 or "NATIVE_CREATE_OK" not in (logs or ""):
        say("Odoo 建库失败,容器输出:\n" + (logs or "")[-2000:])
        raise RuntimeError("Odoo 建库失败" if code != 124 else "Odoo 建库超时")
    row.admin_login, row.admin_password = login, password


def create(row_id: int) -> None:
    """后台任务:按 source 建库。empty=Odoo 原生 create_database(容器未运行时退化为一次性容器装 base);
    template=黄金模板库秒建;clone=复制本实例另一库;backup=从备份恢复。"""
    from . import orchestrator as orch, templates as tplsvc, images

    with SessionLocal() as db:
        row = db.get(EnvironmentDatabase, row_id)
        if not row:
            return
        e = db.get(Environment, row.environment_id)
        t = db.get(Tenant, e.tenant_id)
        say = DbLogger(e.id, row.id, row.name)
        v = EnvDb(e, row)
        created_db = False
        try:
            _set_status(row.id, "creating", "准备中", 3)
            pg = orch.ensure_tenant_pg(t, db, say)
            tag = e.image_tag or images.base_tag(e.odoo_version, e.base_mode or "official")
            uid = orch.env_odoo_uid(e)
            core_addons = images.core_addons_for(e)
            source = row.source or "empty"
            say(f"创建附加数据库 {row.db_name}(来源:{source})")
            # 老实例的 odoo.conf 还是 db_name + 精确 dbfilter:先重写成新格式;库建好后重启一次容器让它生效
            legacy = conf_is_legacy(t, e)
            _rewrite_conf(t, e)
            # 重试(上次失败留下的半成品库 / filestore)先清掉;附加库的名字空间只属于本平台,可放心删
            code, out = orch._psql(pg, f"SELECT 1 FROM pg_database WHERE datname='{row.db_name}'")
            if "(1 row)" in out:
                say(f"清理上次失败遗留的数据库 {row.db_name}")
                orch.drop_env_database(pg, row.db_name, None)
                shutil.rmtree(os.path.join(orch.env_dir(t, e), "filestore", "filestore", row.db_name), ignore_errors=True)

            if source == "template":
                tpl = tplsvc.resolve(tag, e)
                if not tplsvc.template_exists(pg, tpl):
                    _set_status(row.id, "creating", "首次:构建黄金模板库(约 2 分钟)", 10)
                    tplsvc.build_template(pg, t, e, tag, uid, core_addons, tpl, say,
                                          progress=lambda i, el: _set_status(row.id, "creating", "构建模板库", 10 + min(50, int(el / 120.0 * 50))))
                    tplsvc.gc_old_templates(pg, keep={tpl})
                _set_status(row.id, "creating", "从模板库创建数据库", 65)
                tplsvc.create_from_template(pg, t, v, tpl, uid, say)
                created_db = True
            elif source == "clone":
                from . import project as projectsvc

                src = view_by_name(db, e, row.source_ref)
                if src.db_name == row.db_name:
                    raise RuntimeError("克隆源不能是自己")
                _set_status(row.id, "creating", f"从 {src.db_label} 克隆", 10)
                projectsvc.clone_data(pg, t, src, v, say, neutralize=bool(_opts(row).get("neutralize", True)),
                                      progress=lambda pct, msg=None: _set_status(row.id, "creating", msg, 10 + int(pct * 0.8)))
                created_db = True
            elif source == "backup":
                from . import backup as backupsvc
                from ..models_backup import RestoreJob

                bid = int(row.source_ref or 0)
                b = db.get(backupsvc.Backup, bid) if bid else None
                if not b or b.status != "done":
                    raise RuntimeError("备份不存在或未完成")
                # 先建一个空壳库(恢复流程会 DROP + CREATE),并按锁语义占住实例的备份 / 恢复锁
                orch.create_database(pg, row.db_name, e.db_user, "template0", say)
                created_db = True
                if not backupsvc.try_lock(e.id):
                    raise RuntimeError("该实例正在备份或恢复中,请稍后再试")
                neutralize = bool(_opts(row).get("neutralize", e.kind != "production"))
                job = RestoreJob(backup_id=b.id, tenant_id=e.tenant_id, environment_id=e.id, env_name=e.name,
                                 database_id=row.id, db_name=row.db_name, neutralize=neutralize,
                                 status="running", message="已排队", created_by=row.created_by)
                db.add(job)
                db.commit()
                _set_status(row.id, "creating", f"从备份 #{b.id} 恢复", 10)
                backupsvc.run_restore(job.id, b.id, e.id, neutralize, False, database_id=row.id, manage_env_status=False)
                db.refresh(job)
                if job.status != "done":
                    raise RuntimeError(f"从备份恢复失败:{job.message}")
            else:  # empty:Odoo 原生建库(一次性容器跑 exp_create_database,表单字段全部生效)
                t0 = time.time()
                _set_status(row.id, "creating", "Odoo 原生建库中(安装 base,约 1~3 分钟)", 10)
                created_db = True  # exp_create_database 自己 CREATE DATABASE;失败也要清掉半成品
                _native_create(t, e, tag, row, _opts(row), say,
                               on_tick=lambda i, el: _set_status(row.id, "creating", "Odoo 原生建库中", 10 + min(75, int(el / 150.0 * 75))))
                db.commit()
                say(f"数据库创建完成(耗时 {int(time.time() - t0)}s)")

            _set_status(row.id, "creating", "收尾", 92)
            orch.enable_pg_extensions(pg, row.db_name, say)  # Odoo 原生建库/恢复来的附加库补上标配扩展
            orch.set_db_durability(pg, row.db_name, e.kind == "production")
            fs = os.path.join(orch.env_dir(t, e), "filestore", "filestore", row.db_name)
            os.makedirs(fs, exist_ok=True)
            from .fsutil import chown_tree

            chown_tree(os.path.dirname(fs), uid)
            # 管理员密码:该库独立一份(克隆 / 恢复来的库先沿用源库密码,SSO 首次登录若不匹配会自动重置)
            if not row.admin_password:
                row.admin_password = dockerx.rand_password(16)
                db.commit()
            _rewrite_conf(t, e)
            if legacy:
                _set_status(row.id, "creating", "重启实例以加载新配置", 95)
                _restart_for_new_conf(e, say)
            from . import sso as ssosvc

            ssosvc.ensure_admin_password(t, EnvDb(e, row), say)
            say(f"附加数据库就绪:{url_of(e, row) or row.db_name}")
            _set_status(row.id, "ready", None, 100)
        except Exception as ex:  # noqa: BLE001
            log.exception("create extra db #%s failed", row_id)
            say(f"失败: {ex}")
            try:
                if created_db:
                    pg2 = dockerx.get_container(orch.pg_container_name(t))
                    if pg2:
                        orch.drop_env_database(pg2, row.db_name, None)
                    shutil.rmtree(os.path.join(orch.env_dir(t, e), "filestore", "filestore", row.db_name), ignore_errors=True)
            except Exception as rb:  # noqa: BLE001
                say(f"回滚时出错: {rb}")
            _set_status(row.id, "failed", str(ex)[:250], 0)


# ---------------------------------------------------------------- 删库
def drop(row_id: int, backup_id: int | None = None) -> None:
    """后台任务:可选先备份 → 断开连接 → DROP DATABASE → 删 filestore → 删记录。"""
    from . import backup as backupsvc, orchestrator as orch

    with SessionLocal() as db:
        row = db.get(EnvironmentDatabase, row_id)
        if not row:
            return
        e = db.get(Environment, row.environment_id)
        t = db.get(Tenant, e.tenant_id)
        say = DbLogger(e.id, row.id, row.name)
        try:
            if backup_id:
                _set_status(row.id, "dropping", "删除前备份", 10)
                ok = backupsvc.run_backup(backup_id, e.id)  # 内部会 unlock
                if not ok:
                    raise RuntimeError("删除前备份失败,已中止删除(数据仍保留)")
                say("删除前备份完成")
            _set_status(row.id, "dropping", "删除数据库", 60)
            pg = dockerx.get_container(orch.pg_container_name(t))
            if pg and pg.status == "running":
                say(f"删除数据库 {row.db_name}")
                orch.drop_env_database(pg, row.db_name, None)
            fs = os.path.join(orch.env_dir(t, e), "filestore", "filestore", row.db_name)
            if os.path.isdir(fs):
                _set_status(row.id, "dropping", "删除 filestore", 85)
                shutil.rmtree(fs, ignore_errors=True)
                say(f"删除目录 {fs}")
            db.delete(row)
            db.commit()
            _rewrite_conf(t, e)
            say("附加数据库已删除")
        except Exception as ex:  # noqa: BLE001
            log.exception("drop extra db #%s failed", row_id)
            say(f"删除失败: {ex}")
            _set_status(row.id, "failed", f"删除失败:{str(ex)[:200]},请重试", 0)


def drop_all_for_env(pg, t: Tenant, e: Environment, say=log.info) -> None:
    """删实例时连带删除全部附加库(数据库 + 记录;filestore 随实例目录一起删)。"""
    with SessionLocal() as db:
        rows = rows_of(db, e)
        for r in rows:
            try:
                if pg is not None and pg.status == "running":
                    say(f"删除附加数据库 {r.db_name}")
                    from . import orchestrator as orch

                    orch.drop_env_database(pg, r.db_name, None)
            except Exception as ex:  # noqa: BLE001
                say(f"删除附加数据库 {r.db_name} 失败(忽略): {ex}")
            db.delete(r)
        db.commit()


# ---------------------------------------------------------------- 大小 / 过期
def refresh_sizes(pg, e: Environment) -> dict[str, int]:
    """采集各附加库大小(metrics 采集线程调用),返回 {库名: bytes}。"""
    from . import orchestrator as orch

    out: dict[str, int] = {}
    with SessionLocal() as db:
        rows = rows_of(db, e, ready_only=True)
        if not rows:
            return out
        names = ",".join(f"'{r.db_name}'" for r in rows)
        code, text = orch._psql(pg, f"SELECT datname || '|' || pg_database_size(datname) FROM pg_database WHERE datname IN ({names})")
        if code != 0:
            return out
        for ln in text.splitlines():
            ln = ln.strip()
            if "|" in ln:
                n, _, sz = ln.partition("|")
                if sz.strip().isdigit():
                    out[n.strip()] = int(sz)
        for r in rows:
            if r.db_name in out:
                r.size_bytes = out[r.db_name]
        db.commit()
    return out


def default_expires_at(db: Session) -> datetime | None:
    days = _int_setting(db, "db.extra_expire_days", 0)
    return datetime.now(timezone.utc) + timedelta(days=days) if days > 0 else None


def _expire_once() -> None:
    now = datetime.now(timezone.utc)
    with SessionLocal() as db:
        due = db.scalars(select(EnvironmentDatabase).where(EnvironmentDatabase.expires_at.is_not(None), EnvironmentDatabase.expires_at <= now,
                                                             EnvironmentDatabase.status.in_(("ready", "failed")))).all()
        ids = [(r.id, r.db_name) for r in due]
    for rid, name in ids:
        log.info("附加数据库 #%s %s 已过期,自动删除", rid, name)
        _set_status(rid, "dropping", "已过期,自动删除", 5)
        drop(rid, None)


def start_scheduler(interval: int = 600) -> None:
    def loop():
        while True:
            try:
                _expire_once()
            except Exception as ex:  # noqa: BLE001
                log.warning("附加数据库过期清理出错: %s", ex)
            time.sleep(interval)

    threading.Thread(target=loop, name="envdb-expiry", daemon=True).start()


__all__ = ["EnvDb", "view", "view_by_name", "rows_of", "all_db_names", "all_views", "counts_bulk", "feature_state",
           "validate_name", "check_can_create", "create", "drop", "drop_all_for_env", "refresh_sizes", "dbfilter_for",
           "extra_db_name", "domain_of", "url_of", "default_expires_at", "start_scheduler", "BUSY_STATES", "NAME_RE"]
