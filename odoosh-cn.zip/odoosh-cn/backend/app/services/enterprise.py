"""Odoo 企业版代码:来源于被标记为「企业版」的 Git 仓库(组织自己的优先,否则平台共享)。

- 创建企业版实例时:探测远端 <版本>.0 分支的最新 commit → 本地已有同 commit 目录则复用,
  否则 bare mirror(enterprise/<repo_id>/mirror.git)按版本分支 `fetch --depth 1`(只下增量),
  再增量检出(硬链接同版本上一目录 + 只写变更文件)到 enterprise/<repo_id>/<版本>@<commit>。
- 实例只读挂载该目录;删实例不删代码;同来源同版本的实例共享,全平台只下载一次。
- 已运行实例不自动切换代码;无实例引用且不是最新的老目录由后台清理。
"""

import logging
import os
import re
import shutil
import subprocess
import threading
import time
from urllib.parse import quote, urlsplit, urlunsplit

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..models_git import Repository
from . import git as gitsvc

log = logging.getLogger("odoosh.enterprise")

_locks: dict[str, threading.Lock] = {}
_locks_guard = threading.Lock()
CLONE_TIMEOUT = 1800


def _lock(key: str) -> threading.Lock:
    with _locks_guard:
        return _locks.setdefault(key, threading.Lock())


def base_dir() -> str:
    d = os.path.join(settings.data_dir, "enterprise")
    os.makedirs(d, exist_ok=True)
    return d


def to_host_path(p: str) -> str:
    if p.startswith(settings.data_dir):
        return settings.host_data_dir + p[len(settings.data_dir):]
    return p


# ---------------------------------------------------------------- 来源解析
SOURCE_LABEL = {"own": "您接入的企业版仓库", "tenant": "本组织企业版仓库", "platform": "平台共享企业版仓库"}


def candidate_repos(db: Session, tenant_id: int, user_id: int | None) -> list[tuple[Repository, str]]:
    """企业版代码候选仓库,按优先级排序:
    1. own      该用户自己在本组织接入的企业版仓库(新→旧)
    2. tenant   本组织无接入者的旧企业版仓库(由组织管理员维护)
    3. platform 超级管理员接入的平台共享企业版仓库
    """
    out: list[tuple[Repository, str]] = []
    q = select(Repository).where(Repository.tenant_id == tenant_id, Repository.is_enterprise.is_(True)).order_by(Repository.id.desc())
    tenant_repos = db.scalars(q).all()
    if user_id is not None:
        out += [(r, "own") for r in tenant_repos if r.created_by == user_id]
    out += [(r, "tenant") for r in tenant_repos if r.created_by is None]
    plat = platform_repo(db)
    if plat:
        out.append((plat, "platform"))
    return out


def resolve_repo(db: Session, tenant_id: int, user_id: int | None = None, version: str | None = None,
                 probe_remote: bool = True) -> tuple[Repository | None, str, list[dict]]:
    """选出可用的企业版仓库。返回 (仓库, 来源标签 own|tenant|platform|'', 尝试记录)。

    顺序:**本地优先** —— 任一候选仓库本地已有 `<version>.0` 代码(解出目录或镜像分支)则直接采用,不联网;
    否则按 candidate_repos() 的顺序(own → tenant → platform)逐个探测:必须能连通(令牌有效),
    且若给定 version 则必须存在 `<version>.0` 分支;第一个通过的即采用。
    probe_remote=False 时不联网,直接取第一个候选(仅用于展示)。
    尝试记录形如 [{"source": "own", "repo_id": 3, "name": "...", "ok": False, "reason": "认证失败"}, ...]。
    """
    tried: list[dict] = []
    cands = candidate_repos(db, tenant_id, user_id)
    # 本地优先:已有代码秒级复用且不受 GitHub 连通性影响。更新到最新 commit 走「Git 仓库 → 手动导入代码 → 在线更新」。
    if probe_remote and version:
        for r, src in cands:
            fb = local_fallback(r, str(version))
            sha = fb[1] if fb else mirror_branch_head(r, str(version))
            if sha:
                tried.append({"source": src, "repo_id": r.id, "name": r.name, "ok": True,
                              "reason": f"本地已有 {version}.0@{sha[:12]},直接使用(不联网)",
                              "versions": {str(version): sha[:12]}})
                return r, src, tried
    for r, src in cands:
        rec = {"source": src, "repo_id": r.id, "name": r.name, "ok": False, "reason": None}
        if not probe_remote:
            rec["ok"] = True
            tried.append(rec)
            return r, src, tried
        try:
            info = probe(r.url, repo_token(db, r))
        except Exception as e:  # noqa: BLE001
            rec["reason"] = f"无法连通:{e}"
            tried.append(rec)
            continue
        if version and str(version) not in info["versions"]:
            avail = ", ".join(v + ".0" for v in sorted(info["versions"])) or "无"
            rec["reason"] = f"没有 {version}.0 分支(可用:{avail})"
            tried.append(rec)
            continue
        rec["ok"] = True
        rec["versions"] = {v: sha[:12] for v, sha in info["versions"].items()}
        tried.append(rec)
        return r, src, tried
    return None, "", tried


def describe_failure(tried: list[dict]) -> str:
    if not tried:
        return "未配置企业版仓库:请在「Git 仓库」中接入并标记企业版仓库(自己的,或由超级管理员提供平台共享仓库)"
    parts = [f"{SOURCE_LABEL.get(t['source'], t['source'])}「{t['name']}」:{t['reason']}" for t in tried]
    md = to_host_path(os.path.join(base_dir(), str(tried[0]["repo_id"]), "mirror.git"))
    return ("所有企业版仓库均不可用 — " + ";".join(parts)
            + f"。也可手动导入代码后重试:在宿主机上 git init --bare {md},"
            f"再从任一能访问该仓库的机器把版本分支 fetch/push 进去(如 git --git-dir {md} fetch <可达地址> '+refs/heads/<版本>.0:refs/heads/<版本>.0')")


def platform_repo(db: Session) -> Repository | None:
    return db.scalar(select(Repository).where(Repository.scope == "platform", Repository.is_enterprise.is_(True)).order_by(Repository.id.desc()))


def repo_token(db: Session, r: Repository) -> str | None:
    """仓库可用令牌:手填优先,否则 OAuth 账号令牌。"""
    if r.token:
        return r.token
    if r.account:
        try:
            from . import gitoauth

            return gitoauth.refresh_if_needed(db, r.account).access_token
        except Exception as e:  # noqa: BLE001
            raise RuntimeError(f"获取仓库令牌失败:{e}")
    return None


VERSION_BRANCH = re.compile(r"^(\d{2})\.0$")


def version_branches(branches: dict[str, str]) -> dict[str, str]:
    """{'17': sha, '18': sha, ...}"""
    out = {}
    for name, sha in branches.items():
        m = VERSION_BRANCH.match(name)
        if m:
            out[m.group(1)] = sha
    return out


def probe(url: str, token: str | None) -> dict:
    """探测仓库,返回 {'versions': {'19': sha,...}, 'default_branch': ...}。失败抛 RuntimeError。"""
    branches, default = gitsvc.ls_remote(url, token)
    return {"versions": version_branches(branches), "default_branch": default, "branch_count": len(branches)}


# ---------------------------------------------------------------- 本地目录
def repo_dir(r: Repository) -> str:
    return os.path.join(base_dir(), str(r.id))


def version_dir(r: Repository, version: str, commit: str) -> str:
    return os.path.join(repo_dir(r), f"{version}.0@{commit[:12]}")


def local_versions(r: Repository) -> list[dict]:
    """本地已拉取的目录列表 [{version, commit, path, size_mb, mtime}]。"""
    d = repo_dir(r)
    if not os.path.isdir(d):
        return []
    out = []
    for name in sorted(os.listdir(d)):
        m = re.match(r"^(\d{2})\.0@([0-9a-f]{6,40})$", name)
        p = os.path.join(d, name)
        if not m or not os.path.isdir(p):
            continue
        out.append({"version": m.group(1), "commit": m.group(2), "path": p, "mtime": os.path.getmtime(p)})
    return out


def local_fallback(r: Repository, version: str) -> tuple[str, str] | None:
    """远端不可达时的降级:该版本最近一次完整拉取的本地目录 (路径, commit);无则 None。"""
    best = None
    for item in local_versions(r):
        if item["version"] != version:
            continue
        cf = os.path.join(item["path"], ".odoosh-commit")  # 完成标记:没有说明当时没解压完
        if not os.path.isfile(cf):
            continue
        if best is None or item["mtime"] > best[0]:
            with open(cf) as f:
                sha = f.read().strip()
            best = (item["mtime"], item["path"], sha)
    return (best[1], best[2]) if best else None


def _auth_url(url: str, provider: str, token: str | None) -> str:
    if not token:
        return url
    user = {"github": "x-access-token", "gitee": "oauth2", "gitlab": "oauth2"}.get(provider, "git")
    parts = urlsplit(url)
    netloc = f"{quote(user, safe='')}:{quote(token, safe='')}@{parts.hostname}" + (f":{parts.port}" if parts.port else "")
    return urlunsplit((parts.scheme, netloc, parts.path, parts.query, parts.fragment))


def git_auth_env(provider: str, token: str | None) -> dict:
    """把令牌通过 git 配置环境变量(http.extraHeader)传给子进程,避免出现在 argv(/proc/*/cmdline 全局可读)。"""
    if not token:
        return {}
    import base64

    user = {"github": "x-access-token", "gitee": "oauth2", "gitlab": "oauth2"}.get(provider, "git")
    b = base64.b64encode(f"{user}:{token}".encode()).decode()
    return {"GIT_CONFIG_COUNT": "1", "GIT_CONFIG_KEY_0": "http.extraHeader", "GIT_CONFIG_VALUE_0": f"Authorization: Basic {b}"}


def _redact(text: str, token: str | None) -> str:
    return text.replace(token, "***") if token else text


def mirror_dir(r: Repository) -> str:
    return os.path.join(repo_dir(r), "mirror.git")


def mirror_versions(r: Repository) -> dict[str, str]:
    """镜像里已有的版本分支 {'19': sha, ...}(在线拉取过或手动导入过的都算)。"""
    md = mirror_dir(r)
    if not os.path.isdir(md):
        return {}
    p = subprocess.run(["git", "--git-dir", md, "for-each-ref", "--format=%(refname:short) %(objectname)", "refs/heads"],
                       capture_output=True, text=True)
    out: dict[str, str] = {}
    for line in p.stdout.splitlines():
        name, _, sha = line.partition(" ")
        m = VERSION_BRANCH.match(name.strip())
        if m and re.fullmatch(r"[0-9a-f]{40}", sha.strip()):
            out[m.group(1)] = sha.strip()
    return out


def mirror_branch_head(r: Repository, version: str) -> str | None:
    """本地镜像里 <version>.0 分支头。这是「手动导入代码」的入口:管理员把代码 fetch 进 mirror.git
    (见 describe_failure 里的提示命令)后,远端不可达时也能据此离线创建实例。"""
    md = mirror_dir(r)
    if not os.path.isdir(md):
        return None
    p = subprocess.run(["git", "--git-dir", md, "rev-parse", "--verify", f"refs/heads/{version}.0"],
                       capture_output=True, text=True)
    out = p.stdout.strip()
    return out if p.returncode == 0 and re.fullmatch(r"[0-9a-f]{40}", out) else None


def _run_git_progress(cmd: list[str], env: dict, tok: str | None, progress, label: str, timeout: int) -> tuple[int, list[str]]:
    """跑一个带 --progress 的 git 命令,把 Receiving/Resolving 百分比回调出去;返回 (退出码, 输出尾部)。
    看门狗:总时长超 timeout 或输出停滞超 STALL 都杀掉(以前只在有输出行到来时才检查超时,静默挂起会永远阻塞)。"""
    import collections

    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env, bufsize=1)
    t0 = time.time()
    last_out = [time.time()]
    tail: collections.deque = collections.deque(maxlen=30)
    last_pct = -1
    STALL = 600

    def _watch():
        while proc.poll() is None:
            if time.time() - t0 > timeout or time.time() - last_out[0] > STALL:
                proc.kill()
                return
            time.sleep(5)

    th = threading.Thread(target=_watch, daemon=True)
    th.start()
    try:
        for line in iter(proc.stdout.readline, ""):
            last_out[0] = time.time()
            line = _redact(line.rstrip("\r\n"), tok)
            if not line:
                continue
            tail.append(line)
            m = re.search(r"Receiving objects:\s+(\d+)%", line) or re.search(r"Resolving deltas:\s+(\d+)%", line)
            if m and progress:
                pct = int(m.group(1))
                stage = "接收对象" if "Receiving" in line else "解析增量"
                if pct != last_pct:
                    progress(pct, f"{label}:{stage} {pct}%")
                    last_pct = pct
        proc.wait()
    finally:
        if proc.poll() is None:
            proc.kill()
    if time.time() - t0 > timeout:
        tail.append(f"超时({timeout}s)")
    return proc.returncode, list(tail)


def _latest_local(r: Repository, version: str, exclude: str) -> tuple[str, str, str] | None:
    """该版本最近一次完成的本地目录 (目录, sha, 子目录前缀),作增量硬链接基线;旧格式(无 .odoosh-root)不算。"""
    best = None
    for item in local_versions(r):
        p = item["path"]
        if item["version"] != version or p == exclude:
            continue
        cf, rf = os.path.join(p, ".odoosh-commit"), os.path.join(p, ".odoosh-root")
        if not (os.path.isfile(cf) and os.path.isfile(rf)):
            continue
        if best is None or item["mtime"] > best[0]:
            with open(cf) as f:
                sha = f.read().strip()
            with open(rf) as f:
                prefix = f.read().strip()
            best = (item["mtime"], p, sha, prefix)
    return (best[1], best[2], best[3]) if best else None


def ensure_code(db: Session, r: Repository, version: str, say=log.info, progress=None,
                prefer_local: bool = True) -> tuple[str, str]:
    """确保本地有该仓库 <version>.0 分支的代码。返回 (容器内路径, commit)。

    prefer_local=True(默认):本地已有该版本代码(解出目录或镜像分支)则直接用,不联网、不追最新 commit;
    更新到最新走「Git 仓库 → 手动导入代码 → 在线更新」(即 prefer_local=False:探测远端最新并拉取)。

    以前每个新 commit 都 `git clone --depth 1` 整个仓库(0.5~1GB 下载 + 落盘)。现在:
      1. 每个仓库一个 bare mirror(enterprise/<id>/mirror.git),按版本分支 `fetch --depth 1`——只下载新 commit 相对本地已有对象的增量;
      2. 检出用 deploy.incremental_extract:硬链接同版本上一目录 + 只解出变更文件;首个目录才全量 git archive。
    progress(pct 0-100, msg) 可选回调。
    """
    from .deploy import incremental_extract

    gitsvc.assert_repo_url_safe(r.url)
    tok = None
    sha = None
    if prefer_local:
        fb = local_fallback(r, version)
        if fb:
            say(f"企业版代码已就绪(本地 {version}.0@{fb[1][:12]},秒级复用;需更新到最新可在仓库页「手动导入代码」中在线更新)")
            return fb
        sha = mirror_branch_head(r, version)
        if sha:
            say(f"使用镜像中已有的 {version}.0@{sha[:12]}(离线解出)")
    if not sha:
        say(f"探测企业版仓库 {r.url} 的 {version}.0 分支...")
        try:
            tok = repo_token(db, r)  # OAuth 令牌刷新也要联网,一并纳入降级
            info = probe(r.url, tok)
            sha = info["versions"].get(version)
            if not sha:
                avail = ", ".join(f"{v}.0" for v in sorted(info["versions"])) or "无"
                raise RuntimeError(f"企业版仓库中没有 {version}.0 分支(可用版本分支:{avail})")
        except RuntimeError as e:
            # 远端不可达(或无该分支):先用已解出的本地目录,再用镜像里(手动导入)的分支头
            fb = local_fallback(r, version)
            if fb:
                say(f"连接企业版仓库失败({e}),降级使用本地已有代码 {version}.0@{fb[1][:12]}")
                return fb
            sha = mirror_branch_head(r, version)
            if not sha:
                raise
            say(f"连接企业版仓库失败({e}),使用本地镜像中已导入的 {version}.0@{sha[:12]}")
    from .deploy import check_sha

    sha = check_sha(sha)  # 远端可控值:必须是十六进制,防 git 参数注入(--output=…)与目录穿越
    target = version_dir(r, version, sha)
    key = f"{r.id}:{version}"
    with _lock(key):
        if os.path.isdir(target) and os.path.isfile(os.path.join(target, ".odoosh-commit")):
            say(f"企业版代码已就绪(复用):{version}.0@{sha[:12]}")
            return target, sha
        os.makedirs(repo_dir(r), exist_ok=True)
        env = {"GIT_TERMINAL_PROMPT": "0", "PATH": os.environ.get("PATH", ""), "HOME": "/tmp",
               "GIT_HTTP_LOW_SPEED_LIMIT": "1000", "GIT_HTTP_LOW_SPEED_TIME": "120", **git_auth_env(r.provider, tok)}
        md = mirror_dir(r)
        t0 = time.time()
        with _lock(f"mirror:{r.id}"):
            if not os.path.isdir(md):
                subprocess.run(["git", "init", "--bare", "--quiet", md], check=True, capture_output=True, timeout=60, env=env)
            # 本地已有该 commit(别的版本分支恰好同 commit,或上次 fetch 过)则不用再拉
            have = subprocess.run(["git", "--git-dir", md, "cat-file", "-e", f"{sha}^{{commit}}"], capture_output=True, env=env).returncode == 0
            if not have:
                say(f"拉取企业版代码 {version}.0@{sha[:12]}(增量 fetch --depth 1;首次约 0.5~1GB)...")
                url = gitsvc.parse_repo_url(r.url)["https_url"]
                # github.com 依次尝试:git.github_proxy 配置的加速前缀 → 直连(其余平台只有直连);
                # 最近连不上的加速站跳过;git 下载中断不能续传,单源偶发掉线常见,候选列表跑两轮再判失败
                cands = [u for u in gitsvc.github_url_candidates(url) if gitsvc.source_alive(u, url)] * 2
                code, tail = 1, ["无可用下载源"]
                for i, u in enumerate(cands):
                    try:
                        fenv = gitsvc.pin_env(u, env)  # 钉死校验过的 IP(防 DNS 重绑定)
                    except ValueError as e:
                        tail = [str(e)]
                        continue
                    cmd = ["git", "--git-dir", md, "fetch", "--depth", "1", "--progress", "--no-tags", u,
                           f"+refs/heads/{version}.0:refs/heads/{version}.0"]
                    code, tail = _run_git_progress(cmd, fenv, tok, progress, f"拉取企业版代码 {version}.0", CLONE_TIMEOUT)
                    if code == 0:
                        break
                    if i + 1 < len(cands):
                        say(f"从 {urlsplit(u).hostname} 拉取失败({(tail or ['?'])[-1][:80]}),换下载源重试...")
                if code != 0:
                    raise RuntimeError("拉取企业版代码失败:\n" + "\n".join(tail[-8:]))
                say(f"下载完成(耗时 {int(time.time() - t0)}s)")
        tmp = target + ".tmp"
        shutil.rmtree(tmp, ignore_errors=True)
        os.makedirs(tmp)

        def _has_modules(d: str) -> bool:
            return os.path.isdir(d) and any(os.path.isfile(os.path.join(d, n, "__manifest__.py")) for n in os.listdir(d))

        prefix = incremental_extract(md, sha, tmp, _latest_local(r, version, exclude=target), None, say)
        if prefix is None:
            say("解出代码树(首个目录全量;之后同版本新 commit 只写变更文件)...")
            p1 = subprocess.Popen(["git", "--git-dir", md, "archive", "--format=tar", sha], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
            p2 = subprocess.run(["tar", "-x", "-C", tmp], stdin=p1.stdout, capture_output=True, timeout=1800)
            p1.wait(timeout=1800)
            if p1.returncode != 0 or p2.returncode != 0:
                shutil.rmtree(tmp, ignore_errors=True)
                raise RuntimeError("解出企业版代码失败:" + (p1.stderr.read().decode(errors="ignore")[-300:] if p1.stderr else ""))
            # 校验像 addons 目录:模块在根目录(odoo/enterprise 的结构);兼容模块在 addons/ 子目录的仓库
            if _has_modules(tmp):
                src_root, prefix = tmp, ""
            elif _has_modules(os.path.join(tmp, "addons")):
                say("模块位于仓库的 addons/ 子目录,使用该子目录")
                src_root, prefix = os.path.join(tmp, "addons"), "addons"
            else:
                shutil.rmtree(tmp, ignore_errors=True)
                raise RuntimeError("拉取的内容中没有 Odoo 模块(缺少 __manifest__.py),请确认这是企业版 addons 仓库")
        else:
            src_root = tmp
        with open(os.path.join(src_root, ".odoosh-commit"), "w") as f:
            f.write(sha + "\n")
        with open(os.path.join(src_root, ".odoosh-root"), "w") as f:
            f.write(prefix + "\n")
        if src_root != tmp:
            os.rename(src_root, target)
            shutil.rmtree(tmp, ignore_errors=True)
        else:
            os.rename(tmp, target)
        say(f"企业版代码就绪:{target}(耗时 {int(time.time() - t0)}s)")
        return target, sha


def gc_unreferenced(db: Session) -> int:
    """删除无实例引用且不是各版本最新的老目录。返回删除数。"""
    from ..models import Environment

    referenced = {p for (p,) in db.execute(select(Environment.enterprise_path).where(Environment.enterprise_path.is_not(None))).all()}
    removed = 0
    for r in db.scalars(select(Repository).where(Repository.is_enterprise.is_(True))).all():
        by_ver: dict[str, list[dict]] = {}
        for item in local_versions(r):
            by_ver.setdefault(item["version"], []).append(item)
        for ver, items in by_ver.items():
            items.sort(key=lambda x: x["mtime"], reverse=True)
            for old in items[1:]:  # 保留最新一个
                if old["path"] not in referenced:
                    shutil.rmtree(old["path"], ignore_errors=True)
                    removed += 1
                    log.info("清理企业版旧目录 %s", old["path"])
    return removed
