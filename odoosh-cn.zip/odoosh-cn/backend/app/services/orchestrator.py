"""环境编排器:把「环境」翻译成 Docker 资源。

一个环境 = 专属 network + 目录(filestore/addons/conf)+ 租户 PG 里的一个 database
          + 一个 Odoo 容器 + 一条 nginx 路由。
一个租户 = 一个 PG 容器(所有该租户环境共享)。
"""

import logging
import os
import shlex
import threading
import time
from datetime import datetime, timedelta, timezone

from docker.errors import APIError, NotFound
from docker.types import Mount
from sqlalchemy.orm import Session

from ..config import settings
from ..db import SessionLocal
from ..models import Environment, Tenant
from ..models_git import Repository
from . import dockerx, enterprise, images, nginx
from .throttlelog import ThrottledLog

log = logging.getLogger("odoosh.orch")

# postgres:16 + 预装 pgvector(Odoo 18+ 的 AI/RAG 需要);与 postgres:16 数据格式完全兼容,
# 存量租户 PG 容器在「停止状态下被再次拉起」时自动用新镜像重建(pgdata 为宿主机挂载,数据不丢)
PG_IMAGE = "pgvector/pgvector:pg16"
LABEL_PREFIX = "odoosh"
ODOO_UID = 1000  # 自建镜像内 odoo 用户 uid(官方镜像为 101);实际请用 env_odoo_uid()


def env_odoo_uid(e: Environment) -> int:
    """该环境所用镜像内 odoo 用户的 uid(bind mount 目录 chown 用)。"""
    tag = e.image_tag or images.base_tag(e.odoo_version, e.base_mode or "official")
    return images.image_odoo_uid(tag) if dockerx.image_exists(tag) else ODOO_UID


# ---------------------------------------------------------------- 命名与路径
def pg_container_name(t: Tenant) -> str:
    return f"odoosh-pg-{t.slug}"


def env_container_name(t: Tenant, e: Environment) -> str:
    return f"odoo-{t.slug}-{e.name}"


def env_network_name(t: Tenant, e: Environment) -> str:
    return f"odoosh-{t.slug}-{e.name}"


def tenant_dir(t: Tenant, host: bool = False) -> str:
    base = settings.host_data_dir if host else settings.data_dir
    return os.path.join(base, "tenants", t.slug)


def env_dir(t: Tenant, e: Environment, host: bool = False) -> str:
    return os.path.join(tenant_dir(t, host), "envs", e.name)


# 定制代码目录:每个实例自己的可写 addons 目录(env_dir/addons,「定制代码」Tab 在线编辑 / 上传 / 下载的就是它)。
# 无 Git 实例它就是 /mnt/extra-addons;Git 实例的 /mnt/extra-addons 是共享检出(repos/<key>/,含镜像与其它环境的
# commit)、一律只读,定制目录排在 addons_path 末尾(同名模块以仓库代码优先)。
# 两种实例都额外把它读写挂在 /mnt/custom-addons,让实例内的程序(AI 编程模块、Shell)有一个固定的可写路径。
CUSTOM_ADDONS_MOUNT = "/mnt/custom-addons"


def db_identifier(t: Tenant, e: Environment) -> str:
    return f"{t.slug}_{e.name}".replace("-", "_")


# ---------------------------------------------------------------- 日志
def _update_env(env_id: int, **values) -> None:
    """单条 UPDATE(不 SELECT、不加载 ORM 对象),长任务里高频调用也不占连接。"""
    from sqlalchemy import update

    with SessionLocal() as db:
        db.execute(update(Environment).where(Environment.id == env_id).values(**values))
        db.commit()


class EnvLogger(ThrottledLog):
    """实例操作日志:SSE 即时推送,DB 节流落库(见 throttlelog)。"""

    def __init__(self, env_id: int):
        super().__init__()
        self.env_id = env_id
        self.listeners: list = []  # SSE 订阅者回调(services.logstream 注册)

    def _persist(self, text: str, last_msg: str) -> None:
        _update_env(self.env_id, log=text)

    def __call__(self, msg: str) -> None:
        line = f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"
        log.info("env#%s %s", self.env_id, msg)
        self.add(line, msg)
        try:
            from . import logstream

            logstream.publish(f"env:{self.env_id}", line)
        except Exception:  # noqa: BLE001
            pass


def _set_status(env_id: int, status: str, message: str | None = None, progress: int | None = None, **fields) -> None:
    values = {"status": status, "status_message": message, **fields}
    if progress is not None:
        values["progress"] = max(0, min(100, int(progress)))
    _update_env(env_id, **values)


BUSY_STATES = ("provisioning", "destroying", "starting", "stopping", "restarting", "deploying", "cloning", "waking", "restoring")


def try_claim(db: Session, env: Environment, new_status: str, message: str = "已排队", forbid: tuple = ()) -> bool:
    """原子地把实例从「非忙碌」置为 new_status(条件 UPDATE),避免两个并发请求同时通过 busy 检查各自派发后台任务。
    返回 False 表示实例正忙(或处于 forbid 状态)。成功后 env 对象已刷新。"""
    from sqlalchemy import update

    blocked = tuple(BUSY_STATES) + tuple(forbid)
    res = db.execute(
        update(Environment)
        .where(Environment.id == env.id, Environment.status.not_in(blocked))
        .values(status=new_status, status_message=message, progress=0)
    )
    db.commit()
    db.refresh(env)
    return res.rowcount == 1


def _progress(env_id: int, pct: int, message: str | None = None) -> None:
    """只更新进度(与提示),不改变状态。"""
    values = {"progress": max(0, min(100, int(pct)))}
    if message is not None:
        values["status_message"] = message
    _update_env(env_id, **values)


# ---------------------------------------------------------------- 租户 PG
def tenant_pg_memory_mb() -> int:
    from ..routers.settings import get_setting

    with SessionLocal() as db:
        try:
            return max(512, int(get_setting(db, "limits.tenant_pg_memory_mb") or 1024))
        except ValueError:
            return 1024


def pg_tuning(mem_mb: int) -> dict[str, str]:
    """租户 PG 参数(按容器内存推导)。默认镜像参数是为 128MB 老机器准备的:shared_buffers=128MB、work_mem=4MB、
    max_connections=100(每个 Odoo 实例默认 db_maxconn=64,两个实例就能耗尽)。SSD 场景 random_page_cost 调低,
    wal_compression 显著减少 WAL 写入量(SSD 写放大)。"""
    return {
        "shared_buffers": f"{max(128, mem_mb // 4)}MB",
        "effective_cache_size": f"{max(256, mem_mb * 3 // 4)}MB",
        "work_mem": "16MB",
        "maintenance_work_mem": f"{max(64, min(512, mem_mb // 8))}MB",
        # 每实例 db_maxconn = workers*2+4(线程模式 8 条),固定 200 只够 ~25 个实例,班级规模必撞。
        # 但连接数不能脱离内存空谈:每个 PG 后端进程常驻约 2~3MB、执行期随 work_mem 上浮,
        # 故按容器内存推导(mem_mb//5 ≈ 每连接 5MB 的保守配额)。下限 200 与旧版一致,
        # 不让小内存部署变差;上限 500 —— 再多该上连接池(pgbouncer)而不是继续堆连接。
        # 想支撑更多同时在线实例,先调大设置项 limits.tenant_pg_memory_mb,本项会跟着涨。
        "max_connections": str(max(200, min(500, mem_mb // 5))),
        "max_wal_size": "2GB",
        "checkpoint_completion_target": "0.9",
        "wal_compression": "on",
        "random_page_cost": "1.1",
        "log_min_duration_statement": "2000",
    }


def _pg_command(mem_mb: int) -> list[str]:
    cmd = ["postgres"]
    for k, v in pg_tuning(mem_mb).items():
        cmd += ["-c", f"{k}={v}"]
    return cmd


def apply_pg_tuning(pg, mem_mb: int) -> None:
    """对已存在(旧版本创建、无 command 调优)的租户 PG 容器用 ALTER SYSTEM 写入同样的参数:
    可热加载项立即 pg_reload_conf 生效,shared_buffers/max_connections 在下次容器重启时生效。"""
    try:
        want = pg_tuning(mem_mb)
        cur = _psql(pg, "SHOW shared_buffers")[1]
        cur_mc = _psql(pg, "SHOW max_connections")[1]
        # 两项都要比。只看 shared_buffers 的话:平台升级后 max_connections 的算法变了
        # (现在按内存放宽),而 shared_buffers 早已达标 —— 这里会直接短路返回,
        # 新的连接数永远写不进已存在的租户 PG,升级等于没做。
        if want["shared_buffers"] in cur and want["max_connections"] in cur_mc:
            return  # 两项都已是调优后的值(新容器走 command,或已 ALTER SYSTEM 过并重启)
        # ALTER SYSTEM 不能在事务块里跑:每条单独 -c(psql 多语句一个 -c 会包成一个事务)
        cmd = ["psql", "-v", "ON_ERROR_STOP=1", "-X", "-q", "-U", "postgres", "-d", "postgres"]
        for k, v in want.items():
            cmd += ["-c", f"ALTER SYSTEM SET {k} = '{v}'"]
        cmd += ["-c", "SELECT pg_reload_conf()"]
        code, out = pg.exec_run(cmd)
        if code != 0:
            log.warning("ALTER SYSTEM 调优失败(忽略): %s", out.decode(errors="ignore")[:200])
        else:
            log.info("租户 PG %s 已写入调优参数(shared_buffers/max_connections 下次重启生效)", pg.name)
    except Exception as ex:  # noqa: BLE001
        log.warning("应用 PG 调优失败(忽略): %s", ex)


def set_db_durability(pg, dbname: str, production: bool) -> None:
    """非生产库关闭 synchronous_commit:每次提交不再等 WAL fsync,是 Odoo 写负载下最大的 SSD 写放大来源;
    代价只是断电时可能丢最近 ~0.6s 的事务,对开发/测试库完全可接受。生产库保持 on。"""
    try:
        val = "on" if production else "off"
        _psql(pg, f'ALTER DATABASE "{dbname}" SET synchronous_commit = {val}')
    except Exception as ex:  # noqa: BLE001
        log.debug("设置 synchronous_commit 失败(忽略): %s", ex)


_tuned_pg: set[str] = set()


def ensure_tenant_pg(t: Tenant, db: Session, say=log.info):
    """确保租户 PG 容器存在且运行。返回容器。"""
    name = pg_container_name(t)
    if not t.pg_password:
        t.pg_password = dockerx.rand_password()
        db.commit()
    c = dockerx.get_container(name)
    tune_existing = False
    if c is None:
        say(f"创建租户数据库容器 {name}")
        pgdata_c = os.path.join(tenant_dir(t), "pgdata")
        pgdata_h = os.path.join(tenant_dir(t, host=True), "pgdata")
        os.makedirs(pgdata_c, exist_ok=True)
        if not dockerx.image_exists(PG_IMAGE):
            # 内网/断网:先看离线目录有没有现成的镜像包(与 odoo 镜像同一套机制),没有再走常规拉取
            from . import offline_images

            try:
                offline_images.try_import_for_tag(PG_IMAGE, say=say)
            except Exception as ex:  # noqa: BLE001
                say(f"离线镜像自动导入未成功,继续常规拉取:{ex}")
            if not dockerx.image_exists(PG_IMAGE):
                say(f"拉取镜像 {PG_IMAGE} ...")
                dockerx.pull_image(*PG_IMAGE.split(":"), say=say)  # 默认加速站失败自动换备用站
        mem = tenant_pg_memory_mb()
        c = dockerx.run_container(
            PG_IMAGE,
            name=name,
            command=_pg_command(mem),
            detach=True,
            restart_policy={"Name": "unless-stopped"},
            environment={"POSTGRES_USER": "postgres", "POSTGRES_PASSWORD": t.pg_password, "POSTGRES_DB": "postgres"},
            mounts=[Mount("/var/lib/postgresql/data", pgdata_h, type="bind")],
            labels={f"{LABEL_PREFIX}.tenant": t.slug, f"{LABEL_PREFIX}.role": "tenant-pg"},
            mem_limit=f"{mem}m",
            # 默认 /dev/shm 只有 64MB,并行查询 / 大哈希连接会报 "could not resize shared memory segment"
            shm_size=f"{max(128, mem // 4)}m",
        )
    elif c.status != "running":
        if (c.attrs.get("Config", {}) or {}).get("Image") != PG_IMAGE:
            # 镜像升级窗口:容器停着且镜像不是当前 PG_IMAGE(如 postgres:16 → pgvector):
            # 借机重建(pgdata 是宿主机 bind mount,数据保留;同大版本 PG,格式兼容)
            say(f"租户数据库容器镜像升级为 {PG_IMAGE},重建容器(数据保留)")
            c.remove(force=True)
            return ensure_tenant_pg(t, db, say)
        say(f"启动租户数据库容器 {name}")
        c.start()
        tune_existing = True
    elif name not in _tuned_pg:
        tune_existing = True  # 旧版本创建、一直在跑的容器:每进程检查一次
    # 等待就绪
    for _ in range(60):
        code, _out = c.exec_run("pg_isready -U postgres")
        if code == 0:
            if tune_existing:
                apply_pg_tuning(c, tenant_pg_memory_mb())
                _tuned_pg.add(name)
            return c
        time.sleep(1)
    raise RuntimeError("租户数据库未能在 60 秒内就绪")


def _psql(pg, sql: str, database: str = "postgres") -> tuple[int, str]:
    cmd = ["psql", "-v", "ON_ERROR_STOP=1", "-U", "postgres", "-d", database, "-c", sql]
    code, out = pg.exec_run(cmd)
    return code, out.decode(errors="ignore")


def ensure_env_role(pg, user: str, password: str) -> None:
    code, out = _psql(pg, f"SELECT 1 FROM pg_roles WHERE rolname='{user}'")
    if "(0 rows)" in out:
        code, out = _psql(pg, f"CREATE ROLE {user} LOGIN PASSWORD '{password}' CREATEDB")
        if code != 0:
            raise RuntimeError(f"创建数据库角色失败: {out}")
    else:
        _psql(pg, f"ALTER ROLE {user} WITH PASSWORD '{password}'")


def create_database(pg, dbname: str, user: str, template: str = "template0", say=log.info) -> bool:
    """建库(已存在则跳过,返回 False)。"""
    code, out = _psql(pg, f"SELECT 1 FROM pg_database WHERE datname='{dbname}'")
    if "(0 rows)" not in out:
        return False
    say(f"创建数据库 {dbname}" + (f"(模板 {template})" if template != "template0" else ""))
    code, out = _psql(pg, f"CREATE DATABASE {dbname} OWNER {user} ENCODING 'UTF8' TEMPLATE {template}")
    if code != 0:
        raise RuntimeError(f"创建数据库失败: {out}")
    harden_db_access(pg, dbname, user, say)  # 收回 PUBLIC CONNECT,阻止跨实例连库
    enable_pg_extensions(pg, dbname, say)
    return True


def enable_pg_extensions(pg, dbname: str, say=log.info) -> None:
    """新库标配扩展:pgvector(Odoo 18+ AI/RAG 需要)。幂等;必须用 postgres 超级用户执行(实例的 db_user 权限不够)。
    旧租户 PG 容器(官方 postgres:16 镜像,未升级重建)没有扩展文件:只提示不报错,不影响建库。"""
    code, out = _psql(pg, "CREATE EXTENSION IF NOT EXISTS vector", database=dbname)
    if code != 0:
        say(f"启用 pgvector 扩展失败(旧版租户 PG 容器无此扩展;需要 AI/RAG 时把该 PG 容器停止后再拉起即可自动升级镜像): {out.strip()[:120]}")


def create_env_database(pg, dbname: str, user: str, password: str, say=log.info) -> None:
    ensure_env_role(pg, user, password)
    create_database(pg, dbname, user, "template0", say)


def drop_env_database(pg, dbname: str, user: str | None) -> None:
    _psql(pg, f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='{dbname}'")
    _psql(pg, f"DROP DATABASE IF EXISTS {dbname}")
    if user:
        _psql(pg, f"DROP ROLE IF EXISTS {user}")


LANG_RE = __import__("re").compile(r"^[a-z]{2,3}(_[A-Za-z]{2,4})?$")


def apply_db_language(t: Tenant, e: Environment, tag: str, pg, dbname: str, lang: str | None, say=log.info,
                      loaded: bool = False, mem_mb: int | None = None, cpus: float | None = None) -> None:
    """给一个刚初始化好的空库套用语言(与 Odoo 原生建库选语言的效果一致):
    加载翻译并激活该语言(--load-language)→ 管理员 / 现有用户语言 = lang → 新用户默认语言(ir.default res.partner.lang)= lang。
    loaded=True 表示调用方已在 -i base 时带了 --load-language,只补 SQL。en_US / 空 = 什么都不做。失败只记日志,不影响建库。"""
    lang = (lang or "").strip()
    if not lang or lang == "en_US" or not LANG_RE.match(lang):
        return
    try:
        if not loaded:
            say(f"加载语言 {lang}(翻译 + 激活)...")
            code, out = run_oneoff(t, e, tag, ["odoo", "-c", "/etc/odoo/odoo.conf", "-d", dbname, f"--load-language={lang}", "--stop-after-init"],
                                   suffix="lang", timeout=900, mem_mb=mem_mb, cpus=cpus)
            if code != 0:
                say(f"加载语言失败(忽略,可稍后在 Odoo 设置里安装):{out[-300:]}")
                return
        sql = (
            f"UPDATE res_lang SET active=true WHERE code='{lang}'; "
            f"UPDATE res_partner SET lang='{lang}' WHERE id IN (SELECT partner_id FROM res_users) AND EXISTS (SELECT 1 FROM res_lang WHERE code='{lang}' AND active); "
            f"UPDATE ir_default d SET json_value='\"{lang}\"', write_date=now() FROM ir_model_fields f WHERE d.field_id=f.id AND f.model='res.partner' AND f.name='lang' "
            f"AND d.user_id IS NULL AND d.company_id IS NULL AND d.condition IS NULL; "
            f"INSERT INTO ir_default (field_id, json_value, create_uid, write_uid, create_date, write_date) "
            f"SELECT f.id, '\"{lang}\"', 1, 1, now(), now() FROM ir_model_fields f WHERE f.model='res.partner' AND f.name='lang' "
            f"AND NOT EXISTS (SELECT 1 FROM ir_default d WHERE d.field_id=f.id AND d.user_id IS NULL AND d.company_id IS NULL AND d.condition IS NULL)"
        )
        code, out = _psql(pg, sql, dbname)
        if code != 0:
            say(f"设置默认语言失败(忽略):{out[-200:]}")
        else:
            say(f"默认语言已设为 {lang}")
    except Exception as ex:  # noqa: BLE001
        say(f"设置语言时出错(忽略):{ex}")


# ---------------------------------------------------------------- 配置文件
def enterprise_dir(version: str) -> str:
    """企业版代码目录:<设置 odoo.enterprise_dir>/<大版本>,如 /var/lib/odoosh/enterprise/19(客户自行放置 odoo/enterprise 对应分支)。"""
    from ..routers.settings import get_setting

    with SessionLocal() as db:
        base = get_setting(db, "odoo.enterprise_dir") or os.path.join(settings.data_dir, "enterprise")
    return os.path.join(base, str(version))


def enterprise_dir_host(version: str) -> str:
    d = enterprise_dir(version)
    if d.startswith(settings.data_dir):
        return settings.host_data_dir + d[len(settings.data_dir):]
    return d


def check_enterprise_dir(version: str) -> str:
    """校验企业版目录存在且像一个 addons 目录(至少含一个带 __manifest__.py 的子目录)。返回容器内路径。"""
    d = enterprise_dir(version)
    if not os.path.isdir(d):
        raise RuntimeError(f"企业版代码目录不存在:{d}(宿主机 {enterprise_dir_host(version)})。请将 odoo/enterprise 的 {version}.0 分支放到该目录后重试")
    ok = any(os.path.isfile(os.path.join(d, n, "__manifest__.py")) for n in os.listdir(d)[:500])
    if not ok:
        raise RuntimeError(f"企业版目录 {d} 中未找到任何模块(需包含 __manifest__.py 的模块目录)")
    return d


def worker_plan(e: Environment, mem_mb: int | None = None, cpus: float | None = None) -> dict:
    """按实例真实资源上限推导 Odoo 进程参数。以前 limit_memory_hard=2.5G 硬编码,而容器默认只有 1024m,
    Odoo 自身的软/硬限制永远触发不了,直接被 cgroup OOM 杀掉整个进程(用户看到的是 502 + 容器重启)。

    - 开发/测试:workers=0(线程模式,省内存);生产且内存 >= 1536MB:prefork,workers = min(2*cpus+1, mem/768)。
    - 软/硬限制:线程模式按整容器 75%/90%;prefork 按每 worker 均摊(留 1 份给 gevent/cron)。
    - db_maxconn:线程模式 8 条足够;prefork 每 worker 2 条 + 4。
    - ws_port:prefork 时 websocket 在 gevent 端口 8072,线程模式与 http 同 8069(nginx 配置据此生成)。
    """
    if mem_mb is None or cpus is None:
        m, c = _limits(e)
        mem_mb, cpus = mem_mb or m, cpus or c
    workers = 0
    if e.kind == "production" and mem_mb >= 1536:
        workers = max(2, min(int(cpus * 2) + 1, mem_mb // 768))
    budget = int(mem_mb * 0.9) * 1024 * 1024
    if workers:
        hard = budget // (workers + 1)
    else:
        hard = budget
    soft = int(hard * 0.8)
    return {
        "workers": workers,
        "limit_memory_hard": hard,
        "limit_memory_soft": soft,
        "db_maxconn": (workers * 2 + 4) if workers else 8,
        "ws_port": 8072 if workers else 8069,
    }


def env_ws_port(e: Environment, t: Tenant | None = None) -> int:
    """nginx 应转发 websocket 的端口。以磁盘上现有 odoo.conf 的 workers 为准(容器实际在跑的配置),
    没有配置文件时按 worker_plan 推导——避免平台升级后 nginx 先切到 8072 而容器仍是线程模式。"""
    import re

    try:
        if t is None:
            with SessionLocal() as db:
                t = db.get(Tenant, e.tenant_id)
        p = os.path.join(env_dir(t, e), "config", "odoo.conf")
        with open(p, encoding="utf-8") as f:
            m = re.search(r"^\s*workers\s*=\s*(\d+)", f.read(), re.M)
        if m:
            return 8072 if int(m.group(1)) > 0 else 8069
    except OSError:
        pass
    return worker_plan(e)["ws_port"]


LOG_LEVELS = ("debug", "info", "warn", "error")


def env_log_level(e: Environment) -> str:
    """odoo.conf 的 log_level:实例自己的 log_level 优先,否则全局设置 odoo.log_level(默认 info)。
    容器日志由 Docker 按 20MB×3 轮转,等级越低滚得越快;忙碌的生产实例建议 warn。"""
    lv = (e.log_level or "").strip().lower()
    if lv in LOG_LEVELS:
        return lv
    from ..routers.settings import get_setting

    with SessionLocal() as db:
        lv = (get_setting(db, "odoo.log_level") or "info").strip().lower()
    return lv if lv in LOG_LEVELS else "info"


def write_odoo_conf(t: Tenant, e: Environment, pg_host: str, uid: int, core_addons: str,
                    mem_mb: int | None = None, cpus: float | None = None) -> str:
    d = env_dir(t, e)
    for sub in ("filestore", "addons", "config"):
        os.makedirs(os.path.join(d, sub), exist_ok=True)
    # 企业版 addons 必须排在核心 addons 之前;自定义代码固定在 /mnt/extra-addons(git 实例挂当前 commit 的检出目录,部署即重建容器)
    from . import deploy as deploysvc

    extra = deploysvc.container_addons_path(e)
    addons_path = f"/mnt/enterprise,{core_addons},{extra}" if e.edition == "enterprise" else f"{core_addons},{extra}"
    if e.code_path and os.path.isdir(e.code_path):
        addons_path = f"{addons_path},{CUSTOM_ADDONS_MOUNT}"  # Git 实例:定制代码目录排最后,同名模块以仓库代码优先
    plan = worker_plan(e, mem_mb, cpus)
    # 多库:不写 db_name(否则 prefork 的 cron 只跑 db_name 列表里的库),靠 db_user 只拥有本实例的库 + dbfilter 按域名选库;
    # 主库名以注释形式保留给 Shell 辅助命令读取(odoosh_primary_db)。附加库数越多连接数越紧,db_maxconn 按库数放宽。
    from . import databases as dbsvc

    n_extra = 0
    try:
        with SessionLocal() as _db:
            n_extra = len(dbsvc.rows_of(_db, e))
    except Exception:  # noqa: BLE001
        n_extra = 0
    opts: dict[str, str] = {
        "admin_passwd": e.admin_password,
        "db_host": pg_host,
        "db_port": "5432",
        "db_user": e.db_user,
        "db_password": e.db_password,
        "db_maxconn": str(plan["db_maxconn"] + 4 * n_extra),
        "dbfilter": dbsvc.dbfilter_for(e, t),
        "list_db": "False",
        "addons_path": addons_path,
        "data_dir": "/var/lib/odoo",
        "proxy_mode": "True",
        "http_port": "8069",
        "gevent_port": "8072",
        "workers": str(plan["workers"]),
        "max_cron_threads": "1",
        "limit_memory_hard": str(plan["limit_memory_hard"]),
        "limit_memory_soft": str(plan["limit_memory_soft"]),
        "limit_time_cpu": "600",
        "limit_time_real": "1200",
        "limit_request": "8192",
        "log_level": env_log_level(e),
        "without_demo": "all",
    }
    # 附加项(平台全局 + 实例级,白名单内;黑名单键已在 odooconf 过滤)覆盖 / 追加到模板之后;自定义 section 原样透传
    from . import odooconf

    try:
        with SessionLocal() as _db:
            extra = odooconf.merged(_db, e)
    except Exception:  # noqa: BLE001
        extra = odooconf.Parsed()
    opts.update(extra.options)
    lines = ["[options]", f"; 由 OdooshCN 生成 — 环境 {t.slug}/{e.name}", f"; odoosh_primary_db = {e.db_name}"]
    lines += [f"{k} = {v}" for k, v in opts.items()]
    conf = "\n".join(lines) + "\n" + odooconf.render_sections(extra.sections)
    p = os.path.join(d, "config", "odoo.conf")
    with open(p, "w", encoding="utf-8") as f:
        f.write(conf)
    try:
        os.chmod(p, 0o640)  # 含 master / DB / SMTP 口令:宿主机上其他用户不可读(容器内 odoo 用户是属主)
        os.chmod(os.path.join(d, "config"), 0o750)
    except OSError:
        pass
    # 让容器里的 odoo 用户可读写(官方镜像 uid 101,自建 uid 1000)。
    # 只 chown config/addons(小目录);filestore 可能有几十万文件,只在归属不对时才递归
    from .fsutil import chown_tree

    for sub in ("config", "addons"):
        chown_tree(os.path.join(d, sub), uid)
    fs = os.path.join(d, "filestore")
    try:
        if os.stat(fs).st_uid != uid:
            chown_tree(fs, uid)
    except OSError:
        pass
    return p


def refresh_odoo_conf(t: Tenant, e: Environment, say=None) -> None:
    """启动 / 重启前重写 odoo.conf(日志等级、附加项、资源上限、附加库 dbfilter 等设置改了以后靠这一步生效;配置是 bind 挂载,容器无需重建)。失败只记日志。"""
    if not e.container_name or not e.image_tag:
        return
    try:
        write_odoo_conf(t, e, pg_host=pg_container_name(t), uid=env_odoo_uid(e),
                        core_addons=images.core_addons_for(e))
    except Exception as ex:  # noqa: BLE001
        log.warning("重写 odoo.conf 失败(沿用旧配置): %s", ex)
        if say:
            say(f"重写 odoo.conf 失败,沿用旧配置: {ex}")


def _mounts(t: Tenant, e: Environment) -> list[Mount]:
    from . import deploy as deploysvc

    h = env_dir(t, e, host=True)
    # 自定义代码:已部署则只挂本环境当前 commit 的检出目录(repos/<key>/<branch>@<sha>),只读——它是同仓库各环境共享的,
    # 且改动应经 git push 走部署管线;换 commit 靠重建容器。容器里看不到镜像与其它环境的检出。
    # 否则挂环境自己的定制代码目录(读写)
    if e.code_path and os.path.isdir(e.code_path):
        addons_mount = Mount("/mnt/extra-addons", deploysvc.to_host_path(e.code_path), type="bind", read_only=True)
    else:
        addons_mount = Mount("/mnt/extra-addons", os.path.join(h, "addons"), type="bind")
    os.makedirs(os.path.join(env_dir(t, e), "addons"), exist_ok=True)  # bind 源目录必须先存在
    mounts = [
        Mount("/var/lib/odoo", os.path.join(h, "filestore"), type="bind"),
        addons_mount,
        Mount(CUSTOM_ADDONS_MOUNT, os.path.join(h, "addons"), type="bind"),  # 读写:定制代码目录的固定路径(见 CUSTOM_ADDONS_MOUNT)
        Mount("/etc/odoo/odoo.conf", os.path.join(h, "config", "odoo.conf"), type="bind", read_only=True),
    ]
    if e.edition == "enterprise" and e.enterprise_path:
        mounts.append(Mount("/mnt/enterprise", enterprise.to_host_path(e.enterprise_path), type="bind", read_only=True))
    return mounts


def _labels(t: Tenant, e: Environment) -> dict:
    return {
        f"{LABEL_PREFIX}.tenant": t.slug,
        f"{LABEL_PREFIX}.env": e.name,
        f"{LABEL_PREFIX}.env_id": str(e.id),
        f"{LABEL_PREFIX}.role": "odoo",
        f"{LABEL_PREFIX}.odoo_version": e.odoo_version,
        f"{LABEL_PREFIX}.edition": e.edition or "community",
    }


def container_hardening() -> dict:
    """所有租户 Odoo 容器的通用安全加固(run_container 的 kwargs):
    - pids_limit:封顶进程数,堵住 Shell 里的 fork 炸弹拖垮宿主机 / 其它容器
    - no-new-privileges:禁止 setuid 提权
    - cap_drop ALL:Odoo 纯 Python 应用运行期不需要任何 Linux capability
    容器以 odoo 非 root 用户启动(镜像内 USER odoo),故去 cap / 禁提权不影响运行。"""
    from ..routers.settings import get_setting

    try:
        with SessionLocal() as db:
            pids = int(get_setting(db, "limits.env_pids") or 512)
    except Exception:  # noqa: BLE001
        pids = 512
    # init=True:PID 1 用 docker-init(tini)回收僵尸进程。否则 PID 1=odoo 不回收孤儿进程,
    # Shell 里一波孤儿进程结束后会变僵尸、长期占着 pids 名额,把容器卡死在 pids_limit(需重建才恢复)。
    # SELinux Enforcing 的宿主机(RHEL 系):实例容器要 bind mount 租户目录 / 企业版代码,
    # 不禁用标签会被拒绝。由 install.sh 探测后经 compose 的环境变量传进来。
    sec = ["no-new-privileges:true"]
    if (os.getenv("ODOOSH_SELINUX_OPT") or "").strip() == "label:disable":
        sec.append("label:disable")
    return {"init": True, "security_opt": sec, "cap_drop": ["ALL"], "pids_limit": max(64, pids)}


def harden_db_access(pg, db_name: str, owner: str, say=log.info) -> None:
    """收回 PUBLIC 的 CONNECT 权限,只留库主(该实例的 db_user)与超级用户:
    防止同组织其它实例的 Shell 用自己的 db_user 连到本库(同一 PG 集群、默认 PUBLIC 可 CONNECT)。幂等。"""
    if not db_name or not owner:
        return
    try:
        _psql(pg, f'REVOKE CONNECT ON DATABASE "{db_name}" FROM PUBLIC')
        _psql(pg, f'GRANT CONNECT ON DATABASE "{db_name}" TO "{owner}"')
    except Exception as ex:  # noqa: BLE001
        say(f"收紧数据库连接权限失败(忽略): {ex}")


def mounts_outdated(c, t: Tenant, e: Environment) -> bool:
    """现有容器的代码挂载是否已不是当前布局:/mnt/extra-addons 必须正好挂 code_path(git 实例)或定制目录(无 git),
    且必须有 /mnt/custom-addons。不满足就得重建,否则容器里还是旧的 repos 根目录 / 缺可写目录。"""
    try:
        have = {m.get("Destination"): (m.get("Source") or "").rstrip("/") for m in (c.attrs or {}).get("Mounts", [])}
        for m in _mounts(t, e):
            if m["Target"] in ("/mnt/extra-addons", "/mnt/custom-addons") and have.get(m["Target"]) != m["Source"].rstrip("/"):
                return True
        return False
    except Exception:  # noqa: BLE001
        return False


def needs_rebuild(c, t: Tenant | None = None, e: Environment | None = None) -> bool:
    """现有容器是否缺少当前的安全加固配置(pids_limit / no-new-privileges / cap_drop / init),或(给了 t/e 时)代码挂载布局已过时。
    存量容器在下次启动时按需重建一次即可套用,已对齐的容器直接 start(唤醒仍然快)。"""
    if t is not None and e is not None and mounts_outdated(c, t, e):
        return True
    try:
        want = container_hardening()
        hc = (c.attrs or {}).get("HostConfig") or {}
        if int(hc.get("PidsLimit") or 0) != int(want["pids_limit"]):
            return True
        have = hc.get("SecurityOpt") or []
        if any(opt not in have for opt in want["security_opt"]):
            return True
        if [x.upper() for x in (hc.get("CapDrop") or [])] != ["ALL"]:
            return True
        return not bool(hc.get("Init"))
    except Exception:  # noqa: BLE001
        return False


def _limits(e: Environment | None = None) -> tuple[int, float]:
    """资源上限:实例自己的 mem_mb / cpus 优先,否则全局设置。"""
    from ..routers.settings import get_setting

    with SessionLocal() as db:
        mem = int(get_setting(db, "limits.env_memory_mb") or 1024)
        cpus = float(get_setting(db, "limits.env_cpus") or 1)
    if e is not None:
        if e.mem_mb:
            mem = int(e.mem_mb)
        if e.cpus:
            cpus = float(e.cpus)
    return mem, cpus


def _dev_args(e: Environment) -> list[str]:
    """开发档位实例加 --dev=reload,xml,qweb:改 .py 自动重载、改视图 XML 免重启即生效。

    这是教学场景最省事的一条 —— 没有它,学生每改一行 XML 都要等一次重启。
    只给 dev,生产 / 预发不加(自动重载会吃性能,且不该在那些环境上生效)。
    conf 文件里写不了(odooconf 把 dev 列进了黑名单,那是对的:它是命令行开关不是配置项)。
    设置项 code.dev_reload = 0 可全局关掉。"""
    if (e.kind or "") != "dev":
        return []
    try:
        from ..db import SessionLocal
        from ..routers.settings import get_setting

        with SessionLocal() as db:
            if (get_setting(db, "code.dev_reload") or "1").strip() != "1":
                return []
    except Exception as ex:  # noqa: BLE001  读设置失败不该挡住实例启动
        log.debug("读 code.dev_reload 失败,按默认开启: %s", ex)
    return ["--dev=reload,xml,qweb"]


def run_main_container(t: Tenant, e: Environment, tag: str, mem_mb: int | None = None, cpus: float | None = None):
    """启动(或重建)环境的正式 Odoo 容器。每次重建都重写 odoo.conf 并按当前 code_path 挂代码,存量实例(旧软链布局)自动迁移。"""
    if mem_mb is None or cpus is None:
        m, c = _limits(e)
        mem_mb, cpus = mem_mb or m, cpus or c
    try:
        from . import deploy as deploysvc

        deploysvc.remove_legacy_link(e)
        write_odoo_conf(t, e, pg_host=pg_container_name(t), uid=images.image_odoo_uid(tag),
                        core_addons=images.image_core_addons(tag, e.base_mode or "official"), mem_mb=mem_mb, cpus=cpus)
        # workers 模式与 websocket 端口绑定:同步重写 nginx 配置(调用方随后 reload);非生产库关 synchronous_commit
        if e.domain and e.container_name:
            nginx.write_env_conf(t.slug, e.name, e.container_name, e.domain, worker_plan(e, mem_mb, cpus)["ws_port"])
        if e.db_name:
            pg = dockerx.get_container(pg_container_name(t))
            if pg and pg.status == "running":
                set_db_durability(pg, e.db_name, e.kind == "production")
                harden_db_access(pg, e.db_name, e.db_user)  # 存量实例随重启收紧连库权限(幂等)
    except Exception as ex:  # noqa: BLE001
        log.warning("重写 odoo.conf 失败(继续用现有配置): %s", ex)
    old = dockerx.get_container(e.container_name)
    if old:
        old.remove(force=True)
    return dockerx.run_container(
        tag,
        name=e.container_name,
        command=["odoo", "-c", "/etc/odoo/odoo.conf", *_dev_args(e)],
        detach=True,
        network=e.network_name,
        mounts=_mounts(t, e),
        environment=_container_env(),
        labels=_labels(t, e),
        restart_policy={"Name": "unless-stopped"},
        mem_limit=f"{mem_mb}m",
        nano_cpus=int(cpus * 1e9),
        hostname=e.container_name,
        **container_hardening(),
    )


def _container_env() -> dict:
    """实例容器(主容器 / 一次性)的通用环境变量:pip 走平台配置的国内镜像源(Shell 里 odoosh-pip、部署装依赖都受益)。"""
    from ..config import settings

    env = {}
    if settings.pip_index_url:
        env["PIP_INDEX_URL"] = settings.pip_index_url
    return env


def run_oneoff(t: Tenant, e: Environment, tag: str, command: list[str], suffix: str = "job",
               timeout: int = 1800, on_tick=None, mem_mb: int | None = None, cpus: float | None = None,
               mounts: list | None = None) -> tuple[int, str]:
    """用环境的挂载/网络起一次性容器执行命令(初始化、升级模块等),返回 (退出码, 日志尾部)。mounts 可覆盖默认挂载。"""
    if mem_mb is None or cpus is None:
        m, c = _limits(e)
        mem_mb, cpus = mem_mb or m, cpus or c
    name = f"{e.container_name}-{suffix}"
    old = dockerx.get_container(name)
    if old:
        old.remove(force=True)
    c = dockerx.run_container(
        tag, name=name, command=command, detach=True, network=e.network_name, mounts=mounts if mounts is not None else _mounts(t, e),
        environment=_container_env(),
        labels={**_labels(t, e), f"{LABEL_PREFIX}.role": f"odoo-{suffix}"}, mem_limit=f"{mem_mb}m", nano_cpus=int(cpus * 1e9),
        **container_hardening(),
    )
    t0 = time.time()
    i = 0
    while True:
        c.reload()
        if c.status != "running":
            break
        if time.time() - t0 > timeout:
            c.remove(force=True)
            return 124, f"{suffix} 超时({timeout}s)"
        i += 1
        if on_tick:
            on_tick(i, time.time() - t0)
        time.sleep(3)
    result = c.wait(timeout=60)
    logs = c.logs(tail=80).decode(errors="ignore")
    c.remove(force=True)
    return result.get("StatusCode", 1), logs


# ---------------------------------------------------------------- 主流程
def provision(env_id: int, mem_mb: int | None = None, cpus: float | None = None, clone_from: int | None = None) -> None:
    """创建并启动环境(后台任务)。失败则回滚已创建的资源。

    clone_from:同组织另一环境 id —— 数据库与 filestore 从它克隆并中性化,而不是安装空库(测试从生产克隆)。
    提速点:企业版代码 / 基础镜像 / 租户 PG 三者并行准备;空库优先从「黄金模板库」秒级创建(见 services.templates)。
    """
    from concurrent.futures import ThreadPoolExecutor

    from . import deploy as deploysvc
    from . import templates as tplsvc

    say = EnvLogger(env_id)
    created_network = created_container = created_db = False
    net_name = ""   # 阶段 C 赋值;回滚复用它而不是重算,避免与创建时算出的名字不一致
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if not e:
            return
        t = db.get(Tenant, e.tenant_id)
        if mem_mb is None or cpus is None:
            m, c = _limits(e)
            mem_mb, cpus = mem_mb or m, cpus or c
        _set_status(env_id, "provisioning", "准备中", progress=2)
        try:
            # ---- 阶段 A(并行):企业版代码 / 基础镜像 / 租户 PG。进度 2 → 34
            mode = e.base_mode or "official"
            tag_wanted = images.base_tag(e.odoo_version, mode)
            stage = {"ent": 0, "img": 0, "pg": 0}
            weights = {"ent": 10 if e.edition == "enterprise" else 0, "img": 18, "pg": 4}
            stop_evt = threading.Event()

            def _report(msg: str | None = None):
                tot = sum(weights.values()) or 1
                pct = 2 + int(sum(stage[k] / 100.0 * weights[k] for k in stage) / tot * 32)
                _progress(env_id, min(34, pct), msg)

            def task_enterprise():
                if e.edition != "enterprise":
                    return None
                from . import offline_enterprise

                # 已有实例(重建/重试):沿用它已在用的代码目录,不重新解析、不移动现有代码(保持现有系统不变)
                if e.enterprise_path and os.path.isdir(e.enterprise_path):
                    stage["ent"] = 100
                    say(f"企业版:沿用已有代码目录 {e.enterprise_path}")
                    _report("企业版代码就绪(沿用现有)")
                    return e.enterprise_path, e.enterprise_commit, e.enterprise_repo_id
                # 新实例:统一走离线企业版目录 offline/enterprise/<版本>/(超管上传/放置,全平台按版本共享一套);
                # 目录暂缺但旧 git 检出里有该版本 → 自动复制一份进统一目录(一次性),保证创建不失败
                off = offline_enterprise.resolve_for(str(e.odoo_version)) or offline_enterprise.seed_from_legacy(str(e.odoo_version), say=say)
                if off:
                    stage["ent"] = 100
                    say(f"企业版:使用统一目录 {off}(版本 {e.odoo_version},只读挂载)")
                    _report(f"企业版代码就绪({e.odoo_version})")
                    return off, None, None  # (路径, commit=None, repo_id=None)
                raise RuntimeError(
                    f"未找到 {e.odoo_version} 版本的企业版代码。请超级管理员在「离线企业版代码」里上传该版本后再创建。"
                )

            def task_image():
                if dockerx.image_exists(tag_wanted):
                    stage["img"] = 100
                    _report(f"镜像 {tag_wanted} 已就绪")
                    return tag_wanted
                _report(f"准备镜像 {tag_wanted}(首次需下载,约 10 分钟)")
                start, est = time.time(), 600.0

                def _tick():
                    while not stop_evt.wait(5):
                        stage["img"] = min(95, int((time.time() - start) / est * 100))
                        _report()

                th = threading.Thread(target=_tick, daemon=True)
                th.start()
                try:
                    tag = images.ensure_image(e.odoo_version, mode, say)
                finally:
                    stop_evt.set()
                stage["img"] = 100
                _report(f"镜像 {tag} 就绪")
                return tag

            def task_pg():
                with SessionLocal() as db2:
                    t2 = db2.get(Tenant, t.id)
                    ensure_tenant_pg(t2, db2, say)
                    t.pg_password = t2.pg_password
                stage["pg"] = 100
                _report()
                return True

            with ThreadPoolExecutor(max_workers=3, thread_name_prefix=f"prov-{env_id}") as ex:
                f_ent, f_img, f_pg = ex.submit(task_enterprise), ex.submit(task_image), ex.submit(task_pg)
                ent = f_ent.result()
                tag = f_img.result()
                f_pg.result()
            if ent:
                e.enterprise_path, e.enterprise_commit, e.enterprise_repo_id = ent
                db.commit()
            uid = images.image_odoo_uid(tag)
            core_addons = images.image_core_addons(tag, mode)
            say(f"使用镜像 {tag}(odoo uid={uid},核心 addons {core_addons})")
            if e.edition == "enterprise":
                say(f"企业版:只读挂载 {e.enterprise_path} → /mnt/enterprise(commit {e.enterprise_commit[:12] if e.enterprise_commit else '?'})")
            pg = dockerx.get_container(pg_container_name(t))

            # ---- 阶段 B:自定义代码(绑定了仓库+分支则检出最新提交)34 → 38
            first_deploy = None
            if e.repo_url and e.branch:
                _progress(env_id, 35, f"检出代码 {e.branch}")
                path, cinfo = deploysvc.prepare_code(db, e, uid, None, say)
                e.code_path, e.code_commit = path, cinfo["sha"]
                db.commit()
                say(f"代码就绪:{e.branch}@{cinfo['sha'][:12]} {cinfo['message'][:60]}(模块 {len(deploysvc.modules_in(path))} 个)")
                first_deploy = deploysvc.create_record(db, e, "create", "restart", None, None, sha=cinfo["sha"])
                deploysvc._set(first_deploy.id, status="running", started_at=datetime.now(timezone.utc),
                               commit_message=cinfo["message"][:512], author=cinfo["author"], committed_at=cinfo["committed_at"])

            # ---- 阶段 C:网络 38 → 42
            _progress(env_id, 38, "创建网络")
            net_name = env_network_name(t, e)
            net = dockerx.get_network(net_name)
            if net is None:
                say(f"创建网络 {net_name}")
                net = dockerx.client().networks.create(net_name, driver="bridge", labels=_labels(t, e))
                created_network = True
            pg.reload()
            if pg.id not in [c.id for c in net.containers]:
                net.connect(pg)

            # ---- 阶段 D:凭据 + 目录 + 配置 42 → 48
            e.db_name = e.db_name or db_identifier(t, e)
            e.db_user = e.db_user or db_identifier(t, e)
            e.db_password = e.db_password or dockerx.rand_password()
            e.admin_password = e.admin_password or dockerx.rand_password(16)
            e.image_tag = tag
            e.container_name = env_container_name(t, e)
            e.network_name = net_name
            # unique_env_domain 而非 env_domain:<实例>-<组织> 的拼法可能与另一实例撞车
            # (a-b@c 与 a@b-c),nginx 对重复 server_name 只 warn 并忽略,会让一个实例静默不可达
            e.domain = e.domain or nginx.unique_env_domain(db, e, t.slug)
            db.commit()
            _progress(env_id, 44, "写入配置")
            say(f"写入配置 {env_dir(t, e)}/config/odoo.conf")
            write_odoo_conf(t, e, pg_host=pg_container_name(t), uid=uid, core_addons=core_addons, mem_mb=mem_mb, cpus=cpus)

            # ---- 阶段 E:数据库 48 → 85
            _progress(env_id, 48, "准备数据库角色")
            ensure_env_role(pg, e.db_user, e.db_password)
            client = dockerx.client()
            for stale in (e.container_name, f"{e.container_name}-init"):
                old = dockerx.get_container(stale)
                if old:
                    say(f"移除同名旧容器 {stale}")
                    old.remove(force=True)
            src_env = db.get(Environment, clone_from) if clone_from else None
            if src_env and src_env.tenant_id == t.id and src_env.db_name:
                # 从同组织另一环境(通常是生产)克隆数据库 + filestore,并中性化
                from . import project as projectsvc

                create_database(pg, e.db_name, e.db_user, "template0", say)
                created_db = True
                _progress(env_id, 52, f"从「{src_env.name}」克隆数据库")
                t0 = time.time()
                projectsvc.clone_data(pg, t, src_env, e, say, neutralize=projectsvc.pop_pending_neutralize(e.id, True),
                                      progress=lambda pct, msg=None: _progress(env_id, 52 + int(pct * 0.33), msg))
                say(f"数据克隆完成(耗时 {int(time.time() - t0)}s)")
            else:
                done = False
                if tplsvc.enabled():
                    tpl = tplsvc.resolve(tag, e)
                    try:
                        if not tplsvc.template_exists(pg, tpl):
                            _progress(env_id, 50, "首次:构建黄金模板库(安装 base,约 2 分钟)")
                            tplsvc.build_template(
                                pg, t, e, tag, uid, core_addons, tpl, say,
                                progress=lambda i, el: _progress(env_id, 50 + min(28, int(el / 120.0 * 28))),
                                mem_mb=mem_mb, cpus=cpus,
                            )
                            tplsvc.gc_old_templates(pg, keep={tpl})
                        _progress(env_id, 80, f"从模板库创建数据库")
                        t0 = time.time()
                        tplsvc.create_from_template(pg, t, e, tpl, uid, say)
                        created_db = True
                        say(f"数据库就绪(模板库,耗时 {int(time.time() - t0)}s)")
                        done = True
                        _progress(env_id, 83, "设置语言")
                        apply_db_language(t, e, tag, pg, e.db_name, e.lang, say, mem_mb=mem_mb, cpus=cpus)
                    except Exception as ex:  # noqa: BLE001
                        log.warning("模板库路径失败,回退到直接安装 base: %s", ex)
                        say(f"模板库不可用({str(ex)[:120]}),改为直接安装 base")
                        drop_env_database(pg, e.db_name, None)
                        created_db = False
                if not done:
                    create_database(pg, e.db_name, e.db_user, "template0", say)
                    created_db = True
                    _progress(env_id, 52, "初始化数据库(安装 base 模块,约 2 分钟)")
                    say("初始化 Odoo 数据库,安装 base 模块(约 1~3 分钟)...")
                    t0 = time.time()
                    lang_ok = bool(e.lang and e.lang != "en_US" and LANG_RE.match(e.lang))
                    init_cmd = ["odoo", "-c", "/etc/odoo/odoo.conf", "-d", e.db_name, "-i", "base", "--stop-after-init"] + ([f"--load-language={e.lang}"] if lang_ok else [])
                    code, init_logs = run_oneoff(
                        t, e, tag, init_cmd,
                        suffix="init", timeout=1800, mem_mb=mem_mb, cpus=cpus,
                        on_tick=lambda i, el: _progress(env_id, 52 + min(33, int(el / 120.0 * 33))),
                    )
                    if code != 0:
                        say("初始化失败,容器输出:\n" + init_logs)
                        raise RuntimeError("Odoo 数据库初始化失败" if code != 124 else "Odoo 数据库初始化超时(30 分钟)")
                    say(f"数据库初始化完成(耗时 {int(time.time() - t0)}s)")
                    if lang_ok:
                        apply_db_language(t, e, tag, pg, e.db_name, e.lang, say, loaded=True)

            # ---- 阶段 F:正式容器 86 → 90
            _progress(env_id, 86, "启动 Odoo 容器")
            say(f"启动容器 {e.container_name}")
            c = run_main_container(t, e, tag, mem_mb, cpus)
            created_container = True

            # ---- 阶段 G:nginx 路由 90 → 93
            _progress(env_id, 90, "配置域名")
            nginx.write_env_conf(t.slug, e.name, e.container_name, e.domain, worker_plan(e, mem_mb, cpus)["ws_port"])
            nginx.connect_web_to_network(net_name)
            ok, out = nginx.reload()
            if not ok:
                say(f"nginx reload 失败: {out}")
            e.url = nginx.env_url(e.domain, nginx.public_port_for(db, e))
            if nginx.access_mode() == "port" and not e.public_port:
                say("警告:实例端口池已用尽,本实例暂以域名地址显示(可能无法访问)。请扩大 ODOOSH_ENV_PORT_RANGE / 防火墙放行后重建 web,或清理回收站释放端口,再重启本实例")
            db.commit()

            # ---- 阶段 H:健康检查 93 → 100
            _progress(env_id, 93, "等待 Odoo 就绪")
            if _wait_healthy(c, say, on_tick=lambda i: _progress(env_id, min(99, 93 + i))):
                say(f"环境就绪: {e.url}")
                from . import sso as ssosvc

                ssosvc.ensure_admin_password(t, e, say)  # Odoo admin 密码 = 环境的 admin_password,供一键登录
                _set_status(env_id, "running", None, progress=100, url=e.url, last_active_at=datetime.now(timezone.utc))
                if e.kind == "dev":
                    from . import sleep as sleepsvc
                    sleepsvc.enforce_project_cap_async(e.project_id or e.id, keep_env_id=env_id)
                if first_deploy:
                    deploysvc._set(first_deploy.id, status="success", message="随环境创建部署", finished_at=datetime.now(timezone.utc))
            else:
                say("Odoo 未在预期时间内响应,请查看容器日志")
                _set_status(env_id, "failed", "Odoo 未就绪", progress=0)
                if first_deploy:
                    deploysvc._set(first_deploy.id, status="failed", message="环境未就绪", finished_at=datetime.now(timezone.utc))
        except Exception as ex:  # noqa: BLE001
            log.exception("provision failed")
            say(f"失败: {ex}")
            say("回滚已创建的资源...")
            try:
                if created_container:
                    c2 = dockerx.get_container(e.container_name)
                    if c2:
                        c2.remove(force=True)
                nginx.remove_env_conf(t.slug, e.name)
                if created_db:
                    pg2 = dockerx.get_container(pg_container_name(t))
                    if pg2:
                        drop_env_database(pg2, e.db_name, e.db_user)
                    # 库已删,配套的 filestore(初始化/克隆写进去的)也删掉,不留孤儿数据;config/addons 很小、保留
                    import shutil as _sh

                    _sh.rmtree(os.path.join(env_dir(t, e), "filestore"), ignore_errors=True)
                if created_network:
                    nginx.disconnect_web_from_network(net_name)
                    n2 = dockerx.get_network(net_name)
                    if n2:
                        try:
                            # 创建时把租户共享的 PG 连进了本网络(阶段 C 的 net.connect(pg)),
                            # 不先断开就删不掉。删不掉不是小事:每次失败的 provision 泄漏一个僵尸网络,
                            # 而 Docker 地址池有限(daemon.json 的 default-address-pools),
                            # 一个班反复重试就能耗尽,之后连正常创建都会因分配不到网段而失败。
                            n2.reload()
                            for c3 in list(n2.containers):
                                try:
                                    n2.disconnect(c3, force=True)
                                except APIError as ex3:
                                    log.warning("回滚断开容器 %s 失败: %s", getattr(c3, "name", "?"), ex3)
                            n2.remove()
                        except APIError as ex2:
                            log.warning("回滚删除网络失败: %s", ex2)
                nginx.reload()
            except Exception as rb:  # noqa: BLE001
                say(f"回滚时出错: {rb}")
            _set_status(env_id, "failed", str(ex)[:250], progress=0)


HEALTH_BACKOFF = (0.5, 0.5, 1.0, 1.0, 2.0, 2.0)  # 之后固定 3s:唤醒/重启的就绪平均少等 ~1.5s


def _wait_healthy(container, say, timeout: int = 180, on_tick=None) -> bool:
    deadline = time.time() + timeout
    i = 0
    while time.time() < deadline:
        container.reload()
        if container.status != "running":
            say(f"容器状态 {container.status}")
            return False
        code, _ = container.exec_run(["curl", "-sf", "http://localhost:8069/web/health"])
        if code == 0:
            return True
        # Odoo 12 没有 /web/health:退而看 /web/login 是否 200
        code, _ = container.exec_run(["curl", "-sf", "-o", "/dev/null", "http://localhost:8069/web/login"])
        if code == 0:
            return True
        if on_tick and (i >= len(HEALTH_BACKOFF) or i % 2 == 1):
            on_tick(max(1, i - len(HEALTH_BACKOFF) // 2))
        time.sleep(HEALTH_BACKOFF[i] if i < len(HEALTH_BACKOFF) else 3)
        i += 1
    return False


def start(env_id: int) -> None:
    say = EnvLogger(env_id)
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        t = db.get(Tenant, e.tenant_id)
        _set_status(env_id, "starting", "启动中", progress=10)
        try:
            ensure_tenant_pg(t, db, say)
            _progress(env_id, 30, "启动容器")
            c = dockerx.get_container(e.container_name or "")
            if not c:
                raise RuntimeError("容器不存在,请重新创建")
            refresh_odoo_conf(t, e, say)
            if needs_rebuild(c, t, e):
                # 存量容器缺少安全加固(pids_limit / cap_drop / no-new-privileges / init)或代码挂载布局过时:重建一次后启动。
                # 容器是一次性的(filestore、数据库、~/.local 依赖都在卷里),重建无数据损失。
                say("应用安全加固:重建容器后启动")
                tag = e.image_tag or images.base_tag(e.odoo_version, e.base_mode or "official")
                c = run_main_container(t, e, tag)
            else:
                c.start()
            _progress(env_id, 50, "配置网关")
            nginx.connect_web_to_network(e.network_name)
            nginx.reload()
            _progress(env_id, 60, "等待 Odoo 就绪")
            if _wait_healthy(c, say, on_tick=lambda i: _progress(env_id, min(98, 60 + i * 5))):
                say("已启动")
                _set_status(env_id, "running", None, progress=100)
                if e.kind == "dev":
                    from . import sleep as sleepsvc
                    sleepsvc.enforce_project_cap_async(e.project_id or e.id, keep_env_id=env_id)
            else:
                _set_status(env_id, "failed", "启动后未就绪", progress=0)
        except Exception as ex:  # noqa: BLE001
            say(f"启动失败: {ex}")
            _set_status(env_id, "failed", str(ex)[:250], progress=0)


def stop(env_id: int) -> None:
    say = EnvLogger(env_id)
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        _set_status(env_id, "stopping", "停止中", progress=20)
        c = dockerx.get_container(e.container_name or "")
        if c:
            c.stop(timeout=30)
        say("已停止")
        _set_status(env_id, "stopped", None, progress=100)


def restart(env_id: int) -> None:
    say = EnvLogger(env_id)
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        c = dockerx.get_container(e.container_name or "")
        if not c:
            _set_status(env_id, "failed", "容器不存在", progress=0)
            return
        _set_status(env_id, "restarting", "重启容器", progress=15)
        t = db.get(Tenant, e.tenant_id)
        # 重建容器(而非原地 restart):重写 odoo.conf、对齐代码软链,并应用最新资源上限 / 安全加固(pids_limit / cap_drop / no-new-privileges)。
        # 容器是一次性的(filestore、数据库为外部卷 / 库),重建无数据损失。失败时回退到原地重启,保证「重启」始终可用。
        recreated = False
        tag = e.image_tag or images.base_tag(e.odoo_version, e.base_mode or "official")
        # 定制代码 / 仓库里的 requirements.txt 变了就先装依赖(装到 ~/.local,内容没变秒过);失败不阻断重启,只记日志
        try:
            from . import deploy as deploysvc

            deploysvc.install_requirements(t, e, tag, e.code_path or "", say)
        except Exception as ex:  # noqa: BLE001
            say(f"依赖安装失败(继续重启):{ex}")
        try:
            c = run_main_container(t, e, tag)
            recreated = True
        except Exception as ex:  # noqa: BLE001
            say(f"重建容器失败,回退为原地重启: {ex}")
            refresh_odoo_conf(t, e, say)
            c.restart(timeout=30)
        if recreated:
            nginx.connect_web_to_network(e.network_name)  # 新容器新 IP:让网关重新解析上游
            nginx.reload()
        _progress(env_id, 50, "等待 Odoo 就绪")
        if _wait_healthy(c, say, on_tick=lambda i: _progress(env_id, min(98, 50 + i * 6))):
            say("已重启")
            _set_status(env_id, "running", None, progress=100)
            # 定制代码 / 仓库里新放进来的模块:让「应用」列表认到(Odoo 重启不会自己扫描新目录)
            from . import custom_code as cc

            cc.refresh_module_list_if_needed(t, e, db, say)
        else:
            _set_status(env_id, "failed", "重启后未就绪", progress=0)


def _remove_env_side_files(t: Tenant, e: Environment) -> None:
    """删实例时顺手清掉两处以前会遗留的小文件(失败只记日志,不影响删除流程):
    - nginx-logs/<tenant>--<env>.log(每实例访问日志,最多 1MB)
    - repos/<key>/env-<id> 软链(指向代码检出目录)"""
    try:
        from .sleep import access_log_path

        p = access_log_path(t.slug, e.name)
        if os.path.exists(p):
            os.remove(p)
    except OSError as ex:
        log.debug("删除访问日志失败: %s", ex)
    try:
        if e.code_path:
            from .deploy import env_link_name, repo_root_of

            link = os.path.join(repo_root_of(e.code_path), env_link_name(e))
            if os.path.islink(link):
                os.remove(link)
    except OSError as ex:
        log.debug("删除代码软链失败: %s", ex)


def destroy(env_id: int, keep_data: bool = False) -> None:
    """删除环境的全部 Docker 资源与数据库;keep_data 时保留目录与数据库。"""
    say = EnvLogger(env_id)
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        t = db.get(Tenant, e.tenant_id)
        _set_status(env_id, "destroying", "删除容器", progress=10)
        try:
            for name in (e.container_name, f"{e.container_name}-init"):
                c = dockerx.get_container(name or "")
                if c:
                    say(f"删除容器 {name}")
                    c.remove(force=True)
            _progress(env_id, 40, "移除域名与网络")
            nginx.remove_env_conf(t.slug, e.name)
            if e.network_name:
                nginx.disconnect_web_from_network(e.network_name)
                net = dockerx.get_network(e.network_name)
                if net:
                    pg = dockerx.get_container(pg_container_name(t))
                    if pg:
                        try:
                            net.disconnect(pg, force=True)
                        except APIError as ex:
                            log.warning("PG 容器断开网络失败(忽略): %s", ex)
                    say(f"删除网络 {e.network_name}")
                    try:
                        net.remove()
                    except APIError as ex:
                        say(f"网络删除失败(忽略): {ex}")
            nginx.reload()
            if not keep_data and e.db_name:
                _progress(env_id, 65, "删除数据库")
                pg = dockerx.get_container(pg_container_name(t))
                from . import databases as dbsvc

                dbsvc.drop_all_for_env(pg, t, e, say)  # 附加库先删(它们归 db_user 所有,否则 DROP ROLE 会失败)
                if pg and pg.status == "running":
                    say(f"删除数据库 {e.db_name}")
                    drop_env_database(pg, e.db_name, e.db_user)
                _progress(env_id, 85, "删除文件")
                d = env_dir(t, e)
                if os.path.isdir(d):
                    import shutil

                    shutil.rmtree(d, ignore_errors=True)
                    say(f"删除目录 {d}")
            # 附属文件:nginx 访问日志(只用于休眠判断)与 repos/<key>/env-<id> 软链——以前删实例后一直遗留
            _remove_env_side_files(t, e)
        except Exception as ex:  # noqa: BLE001
            # 清理失败不删记录:否则容器/网络/数据库/nginx 配置成为平台管不到的孤儿。保留 failed 状态供重试删除
            log.exception("destroy env#%s cleanup failed", env_id)
            say(f"清理时出错: {ex}")
            _set_status(env_id, "failed", f"删除失败:{str(ex)[:200]},请重试删除", progress=0)
            return
        db.delete(e)
        db.commit()


def trash(env_id: int, backup_id: int | None = None) -> None:
    """移入回收站:可选先做删除前备份 → 停容器 → 摘域名(nginx)→ 状态 deleted、记录 deleted_at。
    容器 / 网络 / 数据库 / 文件全部保留,恢复只需 untrash()。到期由 start_expiry_scheduler 彻底清理。"""
    from . import backup as backupsvc

    say = EnvLogger(env_id)
    if backup_id:
        _set_status(env_id, "destroying", "删除前备份中", progress=10)
        ok = backupsvc.run_backup(backup_id)  # 内部会 unlock
        say("删除前备份完成" if ok else "删除前备份失败(继续移入回收站,数据仍保留)")
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if not e:
            return
        t = db.get(Tenant, e.tenant_id)
        _set_status(env_id, "destroying", "停止容器", progress=40)
        try:
            c = dockerx.get_container(e.container_name or "")
            if c and c.status == "running":
                c.stop(timeout=30)
            _progress(env_id, 70, "摘除域名")
            try:
                nginx.remove_env_conf(t.slug, e.name)
                nginx.reload()
            except Exception as ex:  # noqa: BLE001
                say(f"摘除域名失败(忽略): {ex}")
        except Exception as ex:  # noqa: BLE001
            say(f"移入回收站时出错: {ex}")
            _set_status(env_id, "failed", f"删除失败:{str(ex)[:200]},请重试", progress=0)
            return
        say("已移入回收站")
        # public_port=None:释放端口回池子(端口直连模式的池子很小,回收站占着不放的话,删除重建几轮就耗尽,
        # 新实例分不到端口会退回域名地址);恢复时 untrash 重新分配
        _set_status(env_id, "deleted", "在回收站中,可恢复", progress=100, deleted_at=datetime.now(timezone.utc), public_port=None)


def untrash(env_id: int) -> None:
    """从回收站恢复:清除 deleted_at → 启动容器 → 写回域名。"""
    _update_env(env_id, deleted_at=None)
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if not e:
            return
        if not e.container_name or not dockerx.get_container(e.container_name):
            # 容器已不存在(例如从未成功创建):回到 stopped/created,由用户重新创建
            _set_status(env_id, "created" if not e.container_name else "failed", "已从回收站取回;容器不存在,请重新创建", progress=0)
            return
        t = db.get(Tenant, e.tenant_id)
        try:
            domain = e.domain
            if not domain and e.url:
                from urllib.parse import urlparse

                domain = urlparse(e.url).hostname or ""
            if domain:
                # 端口直连模式:write_env_conf 内部会重新分配端口(进回收站时已释放),这里同步刷新 URL
                nginx.write_env_conf(t.slug, e.name, e.container_name, domain, env_ws_port(e, t))
                e.url = nginx.env_url(domain, nginx.public_port_for(db, e))
                db.commit()
        except Exception as ex:  # noqa: BLE001
            log.warning("恢复实例 #%s 写回 nginx 失败: %s", env_id, ex)
    start(env_id)


def trash_keep_days(kind: str) -> int:
    from ..routers.settings import get_setting

    with SessionLocal() as db:
        key = "env.trash_keep_days_production" if kind == "production" else "env.trash_keep_days"
        try:
            return int(get_setting(db, key) or 0)
        except ValueError:
            return 7


def _purge_expired_trash() -> None:
    """回收站到期实例:彻底删除。"""
    from sqlalchemy import select

    now = datetime.now(timezone.utc)
    with SessionLocal() as db:
        rows = db.scalars(select(Environment).where(Environment.deleted_at.is_not(None), Environment.status == "deleted")).all()
        due = []
        for e in rows:
            days = trash_keep_days(e.kind)
            if days > 0 and e.deleted_at and (now - e.deleted_at).total_seconds() >= days * 86400:
                due.append((e.id, e.name))
    for env_id, name in due:
        log.info("回收站实例 #%s %s 已到期,彻底删除", env_id, name)
        with SessionLocal() as db:
            e = db.get(Environment, env_id)
            if e and try_claim(db, e, "destroying", "回收站到期清理"):
                destroy(env_id)


def recover_stuck_on_startup() -> None:
    """平台重启时,把停留在过渡态的实例按容器真实状态归位(否则会永远显示「创建中」)。"""
    from sqlalchemy import select

    with SessionLocal() as db:
        stuck = db.scalars(
            select(Environment).where(Environment.status.in_(("provisioning", "starting", "stopping", "restarting", "deploying", "cloning", "destroying", "waking", "restoring")))
        ).all()
        for e in stuck:
            c = dockerx.get_container(e.container_name or "")
            if e.status == "destroying":
                # 删除被打断:保留记录,标记失败,允许用户重新删除
                e.status, e.status_message = "failed", "删除被平台重启打断,请重新删除"
            elif c and c.status == "running":
                e.status, e.status_message = "running", None
            elif c:
                e.status, e.status_message = "stopped", "操作被平台重启打断"
            else:
                e.status, e.status_message = "failed", "操作被平台重启打断,请重试创建"
            e.progress = 0
            log.info("实例 #%s %s 过渡态归位 → %s", e.id, e.name, e.status)
        db.commit()


# ---------------------------------------------------------------- 过期自动删除
def default_expire_days(kind: str) -> int:
    """按全局设置返回新实例的默认过期天数(0 = 永不)。生产实例默认不过期,除非显式开启。"""
    from ..routers.settings import get_setting

    with SessionLocal() as db:
        days = int(get_setting(db, "env.expire_days_default") or 0)
        if kind == "production" and (get_setting(db, "env.expire_apply_production") or "0") != "1":
            return 0
        return days


def compute_expires_at(days: int | None, kind: str) -> datetime | None:
    if days is None:
        days = default_expire_days(kind)
    if not days or days <= 0:
        return None
    return datetime.now(timezone.utc) + timedelta(days=days)


def start_expiry_scheduler(interval: int = 300) -> None:
    """后台线程:每 interval 秒检查一次,删除已过期且不在过渡态的实例。"""
    from sqlalchemy import select

    def loop():
        while True:
            try:
                now = datetime.now(timezone.utc)
                with SessionLocal() as db:
                    due = db.scalars(
                        select(Environment).where(
                            Environment.expires_at.is_not(None),
                            Environment.expires_at <= now,
                            Environment.status.in_(("running", "stopped", "failed", "created", "sleeping")),
                        )
                    ).all()
                    ids = [(e.id, e.name, bool(e.container_name or e.db_name)) for e in due]
                for env_id, name, provisioned in ids:
                    log.info("实例 #%s %s 已过期,自动删除", env_id, name)
                    if provisioned:
                        destroy(env_id)
                    else:
                        with SessionLocal() as db:
                            e = db.get(Environment, env_id)
                            if e:
                                db.delete(e)
                                db.commit()
            except Exception as ex:  # noqa: BLE001
                log.warning("过期清理出错: %s", ex)
            try:
                _purge_expired_trash()
            except Exception as ex:  # noqa: BLE001
                log.warning("回收站清理出错: %s", ex)
            time.sleep(interval)

    threading.Thread(target=loop, name="env-expiry", daemon=True).start()


def container_stats(e: Environment) -> dict | None:
    """运行中容器的即时资源占用(CPU%、内存、启动时间)。不可用时返回 None。"""
    c = dockerx.get_container(e.container_name or "")
    if not c or c.status != "running":
        return None
    try:
        s = c.stats(stream=False, one_shot=True)  # 不带 one_shot 时 daemon 会先采两次样(阻塞 ~1-2s)
        cpu_delta = s["cpu_stats"]["cpu_usage"]["total_usage"] - s["precpu_stats"]["cpu_usage"]["total_usage"]
        sys_delta = s["cpu_stats"].get("system_cpu_usage", 0) - s["precpu_stats"].get("system_cpu_usage", 0)
        ncpu = s["cpu_stats"].get("online_cpus") or len(s["cpu_stats"]["cpu_usage"].get("percpu_usage", [])) or 1
        cpu_pct = (cpu_delta / sys_delta * ncpu * 100.0) if sys_delta > 0 else 0.0
        mem = s["memory_stats"]
        usage = mem.get("usage", 0) - mem.get("stats", {}).get("inactive_file", 0)
        limit = mem.get("limit", 0)
        started = c.attrs.get("State", {}).get("StartedAt")
        return {
            "cpu_percent": round(cpu_pct, 1),
            "mem_usage": max(usage, 0),
            "mem_limit": limit,
            "mem_percent": round(usage / limit * 100.0, 1) if limit else 0.0,
            "started_at": started,
            "pids": s.get("pids_stats", {}).get("current"),
        }
    except Exception:  # noqa: BLE001
        return None


def container_logs(e: Environment, tail: int = 300) -> str:
    c = dockerx.get_container(e.container_name or "")
    if not c:
        return "(容器不存在)"
    return c.logs(tail=tail, timestamps=False).decode(errors="ignore")


_states_cache: tuple[float, dict[str, str]] | None = None
_states_lock = threading.Lock()
STATES_TTL = 1.5  # 前端最快 2s 轮询一次;多个用户/标签页同时轮询时共享同一次 docker list


def container_states(max_age: float = STATES_TTL) -> dict[str, str] | None:
    """一次 list 拿到所有实例容器的状态 {容器名: status},供列表接口批量校正(避免逐个 inspect)。
    结果缓存 max_age 秒(传 0 强制刷新)。Docker 不可用(daemon 重启 / 平台刚起来)时返回 None = 未知,
    调用方应保持原状态;以前返回 {} 会让 sync_status 把所有实例误标成 failed。"""
    global _states_cache
    now = time.monotonic()
    with _states_lock:
        if max_age > 0 and _states_cache and now - _states_cache[0] < max_age:
            return _states_cache[1]
    try:
        states = {c.name: c.status for c in dockerx.client().containers.list(all=True, filters={"label": f"{LABEL_PREFIX}.role=odoo"})}
    except Exception as ex:  # noqa: BLE001
        log.warning("列出实例容器失败(状态暂不校正): %s", ex)
        return None
    with _states_lock:
        _states_cache = (time.monotonic(), states)
    return states


def running_containers() -> dict:
    """{容器名: 容器对象}(仅运行中的实例容器),一次 list 供巡检批量使用。"""
    try:
        return {c.name: c for c in dockerx.client().containers.list(filters={"label": f"{LABEL_PREFIX}.role=odoo", "status": "running"})}
    except Exception as ex:  # noqa: BLE001
        log.warning("列出实例容器失败: %s", ex)
        return {}


def sync_status(e: Environment, states: dict[str, str] | None) -> str:
    """按容器真实状态校正(供列表接口调用)。states 为 container_states() 的结果;None = Docker 暂不可用,保持原状态。"""
    if e.status in BUSY_STATES + ("created", "failed", "sleeping", "deleted"):
        return e.status
    if states is None:
        return e.status
    st = states.get(e.container_name or "")
    if st is None:
        return "failed"
    return "running" if st == "running" else "stopped"
