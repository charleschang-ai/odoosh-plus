"""实例级诊断/修复工具(本期仅超管;将来向租户管理员开放时在 authz.ENV_ACTIONS 加 diagnose/repair 并在此处按动作检查)。

约定:
- 每个工具自己开短会话加载 env,并把该 env 的密钥值登记进 ctx.secrets(loop 对所有输出做脱敏)。
- 变更工具执行后由代码采集执行后状态拼进返回值(「递交核对结果」而不是让模型自己猜成没成)。
"""

from __future__ import annotations

import json
import time

from sqlalchemy import select

from ....db import SessionLocal
from ....models import Environment, Tenant
from ... import dockerx
from .. import guards
from .registry import REGISTRY, Tool, ToolCtx, ToolError, _obj, register


def _require_super(ctx: ToolCtx) -> None:
    if not ctx.is_superadmin:
        raise ToolError("REJECTED:该工具仅限平台超级管理员")


def _authorize(ctx: ToolCtx, db, env: Environment, action: str) -> None:
    """越权防线:非超管的每次实例操作,用与网页按钮同一个 check_env 授权。
    ①会话钉死的组织必须与实例组织一致(跨组织直接拒);②再按矩阵判定该动作。
    check_env 抛 HTTPException(403),转成 ToolError 让模型看到「无权…」。"""
    if ctx.is_superadmin:
        return
    if ctx.tenant_id is None or env.tenant_id != ctx.tenant_id:
        raise ToolError(f"REJECTED:实例 #{env.id} 不在当前会话所属组织,无权访问。")
    from fastapi import HTTPException

    from ....authz import check_env
    from ....models import User

    user = db.get(User, ctx.user_id)
    if not user:
        raise ToolError("REJECTED:用户不存在或已停用。")
    try:
        check_env(db, user, env, action)
    except HTTPException as e:
        raise ToolError(f"REJECTED:{e.detail}")


def _load_env(ctx: ToolCtx, db, env_id, action: str = "view") -> tuple[Environment, Tenant]:
    try:
        env_id = int(env_id)
    except (TypeError, ValueError):
        raise ToolError("env_id 必须是整数;可先用 list_envs 按名称找实例")
    env = db.get(Environment, env_id)
    if not env:
        raise ToolError(f"实例 #{env_id} 不存在;可先用 list_envs 查最新列表")
    _authorize(ctx, db, env, action)  # 授权在读取密钥之前:无权连密钥都不加载
    t = db.get(Tenant, env.tenant_id)
    ctx.add_secret(env.db_password, env.admin_password, t.pg_password if t else None)
    return env, t


def _env_head(env: Environment, t: Tenant) -> str:
    return (f"实例 #{env.id} {env.name}(组织 {t.name if t else env.tenant_id},{env.kind},Odoo {env.odoo_version} {env.edition},"
            f"状态 {env.status}" + (f":{env.status_message}" if env.status_message else "") + ")")


# ---------------- 只读 ----------------

def list_envs(ctx: ToolCtx, args: dict) -> str:
    limit = max(1, min(int(args.get("limit") or 20), 100))
    q = (args.get("query") or "").strip().lower()
    status = (args.get("status") or "").strip()
    with SessionLocal() as db:
        stmt = select(Environment).where(Environment.deleted_at.is_(None))
        if not ctx.is_superadmin:
            # 组织隔离:非超管只在会话所属组织里找
            stmt = stmt.where(Environment.tenant_id == ctx.tenant_id)
        envs = db.scalars(stmt.order_by(Environment.id.desc()).limit(500)).all()
        if not ctx.is_superadmin:
            # 再按每实例有效角色过滤:只保留该用户确有权访问的(env_role 非 None)
            from ....authz import env_roles_bulk
            from ....models import User

            user = db.get(User, ctx.user_id)
            roles = env_roles_bulk(db, user, envs) if user else {}
            envs = [e for e in envs if roles.get(e.id)]
        tenants = {t.id: t.name for t in db.scalars(select(Tenant)).all()}
        out = []
        for e in envs:
            if status and e.status != status:
                continue
            hay = f"{e.name} {tenants.get(e.tenant_id, '')} {e.branch or ''} {e.url or ''}".lower()
            if q and q not in hay:
                continue
            out.append(f"#{e.id}\t{e.name}\t组织={tenants.get(e.tenant_id)}\t{e.kind}\tOdoo{e.odoo_version}\t状态={e.status}"
                       + (f"\t分支={e.branch}" if e.branch else ""))
            if len(out) >= limit:
                break
    return f"匹配 {len(out)} 个实例(最多显示 {limit}):\n" + "\n".join(out) if out else "没有匹配的实例"


def env_info(ctx: ToolCtx, args: dict) -> str:
    with SessionLocal() as db:
        env, t = _load_env(ctx, db, args.get("env_id"), "view")
        lines = [_env_head(env, t)]
        lines.append(f"容器={env.container_name} 网络={env.network_name} 库={env.db_name} 域名={env.url or env.domain or '-'}")
        lines.append(f"仓库={env.repo_url or '-'} 分支={env.branch or '-'} 当前 commit={(env.code_commit or '')[:10] or '-'}"
                     f" 部署动作={env.deploy_action} 自动部署={env.auto_deploy}")
        lines.append(f"资源上限:mem={env.mem_mb or '全局默认'}MB cpus={env.cpus or '全局默认'};日志等级={env.log_level or '全局默认'}"
                     f";休眠小时={env.sleep_idle_hours if env.sleep_idle_hours is not None else '默认'}"
                     f";过期={env.expires_at or '永不'};最后访问={env.last_active_at or '-'}")
        c = dockerx.get_container(env.container_name or "")
        if c:
            st = c.attrs.get("State", {})
            lines.append(f"容器实况:status={c.status} exit={st.get('ExitCode')} oom={st.get('OOMKilled')}"
                         f" restarts={c.attrs.get('RestartCount', 0)} started={st.get('StartedAt', '')[:19]}")
        else:
            lines.append("容器实况:容器不存在")
    return "\n".join(lines)


def env_logs(ctx: ToolCtx, args: dict) -> str:
    tail = max(10, min(int(args.get("tail") or 200), 800))
    grep = (args.get("grep") or "").strip()
    with SessionLocal() as db:
        env, t = _load_env(ctx, db, args.get("env_id"), "logs")
        head = _env_head(env, t)
        orch = (env.log or "").splitlines()[-60:]
        c = dockerx.get_container(env.container_name or "")
        if not c:
            body = "(容器不存在)"
        else:
            body = c.logs(tail=tail, timestamps=True).decode(errors="ignore")
    if grep:
        import re as _re

        try:
            rex = _re.compile(grep, _re.I)
            body = "\n".join(ln for ln in body.splitlines() if rex.search(ln)) or f"(最近 {tail} 行里没有匹配 {grep!r} 的日志)"
        except _re.error:
            body = "\n".join(ln for ln in body.splitlines() if grep.lower() in ln.lower()) or f"(无匹配 {grep!r} 的日志)"
    parts = [head]
    if orch:
        parts.append("最近编排日志:\n" + "\n".join(orch))
    parts.append(f"容器日志(tail={tail}" + (f",过滤={grep!r}" if grep else "") + "):\n" + body)
    return "\n\n".join(parts)


def env_metrics(ctx: ToolCtx, args: dict) -> str:
    from ... import metrics as metricsvc

    rng = args.get("range") or "1h"
    if rng not in metricsvc.RANGES:
        raise ToolError(f"range 必须是 {'/'.join(metricsvc.RANGES)} 之一")
    with SessionLocal() as db:
        env, t = _load_env(ctx, db, args.get("env_id"), "stats")
        head = _env_head(env, t)
    data = metricsvc.series(int(args.get("env_id")), rng)
    pts = data.get("points") or []
    if not pts:
        return head + f"\n最近 {rng} 无采样数据(实例未运行或采集器刚启动)"

    def stat(key, scale=1.0, unit=""):
        vals = [p.get(key) for p in pts if p.get(key) is not None]
        if not vals:
            return f"{key}: 无数据"
        return f"{key}: 最新 {vals[-1] / scale:.1f}{unit},均值 {sum(vals) / len(vals) / scale:.1f}{unit},峰值 {max(vals) / scale:.1f}{unit}"

    lines = [head, f"最近 {rng} 共 {len(pts)} 个采样点:",
             stat("cpu_pct", 1, "%"), stat("mem_bytes", 1024 ** 2, "MB"), stat("net_rx", 1024, "KB/s"),
             stat("net_tx", 1024, "KB/s"), stat("pids", 1, "")]
    disk = data.get("disk")
    if disk:
        lines.append(f"磁盘:filestore={disk.get('filestore')} bytes,数据库={disk.get('db')} bytes")
    return "\n".join(lines)


def env_health(ctx: ToolCtx, args: dict) -> str:
    with SessionLocal() as db:
        env, t = _load_env(ctx, db, args.get("env_id"), "logs")
        head = _env_head(env, t)
        c = dockerx.get_container(env.container_name or "")
        if not c:
            return head + "\n健康探测:容器不存在 → 未通过"
        c.reload()
        if c.status != "running":
            st = c.attrs.get("State", {})
            return head + f"\n健康探测:容器状态 {c.status}(exit={st.get('ExitCode')} oom={st.get('OOMKilled')})→ 未通过"
        code, _ = c.exec_run(["curl", "-sf", "-m", "10", "http://localhost:8069/web/health"])
        if code == 0:
            return head + "\n健康探测:/web/health 200 → 通过(代码实测)"
        code2, _ = c.exec_run(["curl", "-sf", "-m", "10", "-o", "/dev/null", "http://localhost:8069/web/login"])
        if code2 == 0:
            return head + "\n健康探测:/web/health 失败但 /web/login 200(老版本 Odoo 无 health 端点)→ 通过"
        logs = c.logs(tail=25).decode(errors="ignore")
        return head + f"\n健康探测:HTTP 探测失败(容器 running 但 Odoo 未响应)→ 未通过\n容器日志尾部:\n{logs}"


def deploy_history(ctx: ToolCtx, args: dict) -> str:
    from ....models_deploy import Deployment

    limit = max(1, min(int(args.get("limit") or 5), 20))
    dep_id = args.get("dep_id")
    with SessionLocal() as db:
        env, t = _load_env(ctx, db, args.get("env_id"), "logs")
        head = _env_head(env, t)
        if dep_id:
            d = db.get(Deployment, int(dep_id))
            if not d or d.environment_id != env.id:
                raise ToolError("部署记录不存在或不属于该实例")
            return (head + f"\n部署 #{d.id}:{d.status} 动作={d.action} commit={(d.commit_sha or '')[:10]}"
                    f" 触发={d.trigger} by={d.created_by} 耗时={d.duration}s\n日志:\n{d.log or '(空)'}")
        rows = db.scalars(select(Deployment).where(Deployment.environment_id == env.id)
                          .order_by(Deployment.id.desc()).limit(limit)).all()
        if not rows:
            return head + "\n(无部署记录)"
        lines = [head, f"最近 {len(rows)} 次部署(传 dep_id 可看完整日志):"]
        for d in rows:
            lines.append(f"#{d.id}\t{d.status}\t{d.action}\t{(d.commit_sha or '')[:10]}\t{d.trigger}\tby={d.created_by}"
                         f"\t{d.created_at}\t{('耗时' + str(d.duration) + 's') if d.duration else ''}"
                         + (f"\t信息={d.message}" if getattr(d, 'message', None) else ""))
    return "\n".join(lines)


_SQL_TIMEOUT_MS = 10000


def _pg_for(db, env: Environment, t: Tenant):
    from ... import orchestrator

    pg = dockerx.get_container(orchestrator.pg_container_name(t))
    if not pg:
        raise ToolError(f"组织 {t.slug} 的 PostgreSQL 容器不存在或未运行")
    return pg


def env_sql(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    sql = (args.get("sql") or "").strip()
    if not sql:
        raise ToolError("sql 不能为空")
    with SessionLocal() as db:
        env, t = _load_env(ctx, db, args.get("env_id"))
        database = (args.get("database") or env.db_name or "").strip()
        pg = _pg_for(db, env, t)
    # 会话级强制只读 + 语句超时;写操作请用 env_sql_write(需确认)
    code, out = pg.exec_run(
        ["psql", "-v", "ON_ERROR_STOP=1", "-U", "postgres", "-d", database, "-P", "pager=off", "-c", sql],
        environment={"PGOPTIONS": f"-c default_transaction_read_only=on -c statement_timeout={_SQL_TIMEOUT_MS}"})
    text = out.decode(errors="ignore")
    if code != 0:
        return f"SQL 执行失败(exit={code},库={database},会话为只读模式):\n{text}\n若确需写入请改用 env_sql_write(会弹确认卡)。"
    return f"库={database}(只读会话,超时 {_SQL_TIMEOUT_MS // 1000}s):\n{text}"


def read_spill(ctx: ToolCtx, args: dict) -> str:
    path = str(args.get("path") or "")
    try:
        return guards.read_spill_file(ctx.spill_dir, path, int(args.get("offset") or 0), int(args.get("limit") or 200))
    except ValueError as ex:
        raise ToolError(str(ex))


# ---------------- 变更(确认卡) ----------------

def _claim_or_fail(db, env: Environment, new_status: str) -> None:
    from ... import orchestrator

    if not orchestrator.try_claim(db, env, new_status, message="AI 助手发起"):
        raise ToolError(f"实例正忙(状态 {env.status}),未执行;请稍后用 env_info 查看状态后再试")


def _post_state(env_id: int) -> str:
    with SessionLocal() as db:
        e = db.get(Environment, env_id)
        if not e:
            return "实例已不存在"
        c = dockerx.get_container(e.container_name or "")
        cs = c.status if c else "容器不存在"
        return f"执行后状态(代码实测):实例 status={e.status}" + (f"({e.status_message})" if e.status_message else "") + f",容器={cs}"


def _lifecycle(ctx: ToolCtx, args: dict, op: str, claim_status: str) -> str:
    from ... import orchestrator

    with SessionLocal() as db:
        env, t = _load_env(ctx, db, args.get("env_id"), op)  # op(start/stop/restart)即对应的矩阵动作
        if not env.container_name:
            raise ToolError("实例尚未创建过容器,请先在控制台「创建并启动」")
        _claim_or_fail(db, env, claim_status)
        env_id = env.id
    getattr(orchestrator, op)(env_id)  # 同步执行,结束后报实测状态
    return _post_state(env_id)


def env_start(ctx: ToolCtx, args: dict) -> str:
    return _lifecycle(ctx, args, "start", "starting")


def env_stop(ctx: ToolCtx, args: dict) -> str:
    return _lifecycle(ctx, args, "stop", "stopping")


def env_restart(ctx: ToolCtx, args: dict) -> str:
    return _lifecycle(ctx, args, "restart", "restarting")


def orchestrator_try_claim(db, env, status):
    from ... import orchestrator

    return orchestrator.try_claim(db, env, status, message="AI 助手发起")


def env_wake(ctx: ToolCtx, args: dict) -> str:
    from ... import sleep as sleepsvc

    with SessionLocal() as db:
        env, _t = _load_env(ctx, db, args.get("env_id"), "start")  # 唤醒≈启动
        env_id = env.id
        if env.status != "sleeping":
            raise ToolError(f"实例当前状态是 {env.status},不是 sleeping,无需唤醒")
        if not orchestrator_try_claim(db, env, "waking"):  # wake() 要求调用方已置为 waking
            raise ToolError(f"实例正忙(状态 {env.status}),未执行")
    ok = sleepsvc.wake(env_id, who=f"AI({ctx.username})")
    return ("唤醒成功。" if ok else "唤醒未成功。") + _post_state(env_id)


def env_redeploy(ctx: ToolCtx, args: dict) -> str:
    from ... import deploy as deploysvc
    from ....models_deploy import Deployment

    with SessionLocal() as db:
        env, _t = _load_env(ctx, db, args.get("env_id"), "deploy")
        if not env.repo_url or not env.branch:
            raise ToolError("实例未绑定仓库/分支,无法部署;可改用 env_restart")
        action = args.get("action") or env.deploy_action or "update_all"
        if action not in ("restart", "update", "update_all"):
            raise ToolError("action 必须是 restart/update/update_all 之一")
        modules = args.get("modules") if args.get("modules") is not None else env.deploy_modules
        if action == "update" and not (modules or "").strip():
            raise ToolError("action=update 时必须给 modules(逗号分隔的模块列表)")
        _claim_or_fail(db, env, "deploying")
        d = deploysvc.create_record(db, env, "manual", action, modules, f"AI({ctx.username})")
        dep_id, env_id = d.id, env.id
    ok = deploysvc.deploy(dep_id)  # 同步执行:拉代码→换挂载→升级→健康检查,失败自动回退
    with SessionLocal() as db:
        d = db.get(Deployment, dep_id)
        tail = "\n".join((d.log or "").splitlines()[-30:]) if d else ""
    return (f"部署 #{dep_id} {'成功' if ok else '失败(已自动回退到上一版本)'}。" + _post_state(env_id)
            + f"\n部署日志尾部:\n{tail}")


def env_sql_write(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    sql = (args.get("sql") or "").strip()
    if not sql:
        raise ToolError("sql 不能为空")
    with SessionLocal() as db:
        env, t = _load_env(ctx, db, args.get("env_id"))
        database = (args.get("database") or env.db_name or "").strip()
        pg = _pg_for(db, env, t)
    code, out = pg.exec_run(
        ["psql", "-v", "ON_ERROR_STOP=1", "-U", "postgres", "-d", database, "-P", "pager=off", "-c", sql],
        environment={"PGOPTIONS": "-c statement_timeout=30000"})
    return f"库={database} exit={code}:\n{out.decode(errors='ignore')}"


def container_exec(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    cmd = (args.get("command") or "").strip()
    if not cmd:
        raise ToolError("command 不能为空")
    why = guards.is_catastrophic_command(cmd)
    if why:
        raise ToolError(f"REJECTED:命令被判定为灾难级操作({why}),即使确认也不执行。请改用更小粒度的操作。")
    with SessionLocal() as db:
        env, _t = _load_env(ctx, db, args.get("env_id"))
        c = dockerx.get_container(env.container_name or "")
        if not c or c.status != "running":
            raise ToolError("实例容器不存在或未运行;可先 env_start")
    code, out = c.exec_run(["/bin/sh", "-c", cmd])
    return f"exit={code}\n{out.decode(errors='ignore')}"


def nginx_reload(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    from ... import nginx as nginxsvc

    ok, msg = nginxsvc.reload(reconcile=bool(args.get("reconcile")))
    return f"nginx reload {'成功' if ok else '失败'}:{msg}"


# ---------------- 注册 ----------------

_ENV_ID = {"env_id": {"type": "integer", "description": "实例 id(不知道就先 list_envs)"}}

register(Tool(
    name="list_envs", readonly=True, handler=list_envs,
    description="按名称/组织/分支模糊搜索实例,或按状态过滤。返回 id、组织、档位、状态。",
    parameters=_obj({"query": {"type": "string"}, "status": {"type": "string", "description": "如 running/stopped/failed/sleeping"},
                     "limit": {"type": "integer"}})))
register(Tool(
    name="env_info", readonly=True, handler=env_info,
    description="实例详情:配置、仓库/分支、资源上限、容器实况(状态/退出码/OOM/重启次数)。",
    parameters=_obj(dict(_ENV_ID), ["env_id"])))
register(Tool(
    name="env_logs", readonly=True, handler=env_logs, timeout=30,
    description="实例容器日志尾部 + 最近编排日志;grep 可按正则过滤(如 ERROR|Traceback)。",
    parameters=_obj({**_ENV_ID, "tail": {"type": "integer", "description": "默认 200,最多 800"},
                     "grep": {"type": "string", "description": "行过滤正则(可选)"}}, ["env_id"])))
register(Tool(
    name="env_metrics", readonly=True, handler=env_metrics,
    description="实例资源曲线摘要(CPU/内存/网络/进程数的最新值、均值、峰值)。",
    parameters=_obj({**_ENV_ID, "range": {"type": "string", "enum": ["1h", "6h", "24h", "7d"]}}, ["env_id"])))
register(Tool(
    name="env_health", readonly=True, handler=env_health, timeout=45,
    description="一次性健康探测:容器状态 + 容器内 curl Odoo /web/health;失败时附日志尾部。",
    parameters=_obj(dict(_ENV_ID), ["env_id"])))
register(Tool(
    name="deploy_history", readonly=True, handler=deploy_history,
    description="实例部署历史;传 dep_id 看某次部署的完整日志。",
    parameters=_obj({**_ENV_ID, "limit": {"type": "integer"}, "dep_id": {"type": "integer"}}, ["env_id"])))
register(Tool(
    name="env_sql", readonly=True, handler=env_sql, timeout=30,
    description="在实例数据库上执行只读 SQL(会话强制 read-only,超时 10s)。查数据/锁/慢查询用。",
    parameters=_obj({**_ENV_ID, "sql": {"type": "string"},
                     "database": {"type": "string", "description": "默认实例主库;附加库可指定"}}, ["env_id", "sql"])))
register(Tool(
    name="read_spill", readonly=True, handler=read_spill,
    description="分段回读之前被落盘的超长工具输出(offset/limit 按行)。",
    parameters=_obj({"path": {"type": "string"}, "offset": {"type": "integer"}, "limit": {"type": "integer"}}, ["path"])))

register(Tool(
    name="env_start", readonly=False, handler=env_start, timeout=900,
    description="启动实例(同步等待,返回执行后实测状态)。需操作者确认。",
    parameters=_obj(dict(_ENV_ID), ["env_id"])))
register(Tool(
    name="env_stop", readonly=False, handler=env_stop, timeout=900,
    description="停止实例。需操作者确认。",
    parameters=_obj(dict(_ENV_ID), ["env_id"])))
register(Tool(
    name="env_restart", readonly=False, handler=env_restart, timeout=900,
    description="重启实例(同步等待健康检查,返回执行后实测状态)。需操作者确认。",
    parameters=_obj(dict(_ENV_ID), ["env_id"])))
register(Tool(
    name="env_wake", readonly=False, handler=env_wake, timeout=900,
    description="唤醒休眠(sleeping)的开发实例。需操作者确认。",
    parameters=_obj(dict(_ENV_ID), ["env_id"])))
register(Tool(
    name="env_redeploy", readonly=False, handler=env_redeploy, timeout=1800,
    description="重新部署实例分支最新代码(restart/update/update_all;失败自动回退)。需操作者确认。",
    parameters=_obj({**_ENV_ID, "action": {"type": "string", "enum": ["restart", "update", "update_all"]},
                     "modules": {"type": "string", "description": "action=update 时的模块列表,逗号分隔"}}, ["env_id"])))
register(Tool(
    name="env_sql_write", readonly=False, handler=env_sql_write, timeout=720,
    description="在实例数据库上执行写 SQL(超时 30s)。危险操作,需操作者确认;调用前先用 env_sql 验证查询逻辑。",
    parameters=_obj({**_ENV_ID, "sql": {"type": "string"}, "database": {"type": "string"}}, ["env_id", "sql"])))
register(Tool(
    name="container_exec", readonly=False, handler=container_exec, timeout=780,
    description="在实例容器内执行 shell 命令(灾难级命令即使确认也会被拒绝)。需操作者确认。",
    parameters=_obj({**_ENV_ID, "command": {"type": "string"}}, ["env_id", "command"])))
register(Tool(
    name="nginx_reload", readonly=False, handler=nginx_reload, timeout=720,
    description="重载 nginx(reconcile=true 时先重写全部实例配置再 reload)。需操作者确认。",
    parameters=_obj({"reconcile": {"type": "boolean"}})))

# 高危 / 平台性工具:碰业务数据(SQL)、容器内任意命令、平台 nginx —— 一律 super-only,assist 不暴露。
import dataclasses as _dc  # noqa: E402

for _n in ("env_sql", "env_sql_write", "container_exec", "nginx_reload"):
    if _n in REGISTRY:
        REGISTRY[_n] = _dc.replace(REGISTRY[_n], assist=False)
