"""平台级诊断/修复工具(仅超管)。检查项参照运维排查脚本沉淀:
docker events、容器 State/OOMKilled/退出码、平台服务日志、宿主资源、nginx 配置。
"""

from __future__ import annotations

import subprocess
import time

from ....config import settings
from ....db import SessionLocal
from ... import dockerx
from .registry import REGISTRY, Tool, ToolCtx, ToolError, _obj, register


def _require_super(ctx: ToolCtx) -> None:
    # 双层授权的执行层兜底:即使注册表/暴露层出错,平台级工具也绝不为非超管执行
    if not ctx.is_superadmin:
        raise ToolError("REJECTED:该工具仅限平台超级管理员")


def _fmt_bytes(n) -> str:
    try:
        n = float(n)
    except (TypeError, ValueError):
        return "?"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"


# ---------------- 只读 ----------------

def platform_overview(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    import psutil
    from sqlalchemy import func, select

    from ....models import Environment, Tenant, User

    vm = psutil.virtual_memory()
    try:
        disk = psutil.disk_usage(settings.data_dir)
    except OSError:
        disk = psutil.disk_usage("/")
    lines = [f"平台 {settings.app_name} v{settings.version},API 进程启动于 {int(time.time() - settings.started_at)}s 前"]
    with SessionLocal() as db:
        lines.append(f"组织 {db.scalar(select(func.count(Tenant.id)))} 个,实例 {db.scalar(select(func.count(Environment.id)))} 个,"
                     f"用户 {db.scalar(select(func.count(User.id)))} 个")
        rows = db.execute(select(Environment.status, func.count(Environment.id)).where(Environment.deleted_at.is_(None)).group_by(Environment.status)).all()
        lines.append("实例状态分布:" + (", ".join(f"{s}={n}" for s, n in rows) or "无"))
    lines.append(f"宿主:CPU {psutil.cpu_count()} 核 {psutil.cpu_percent(interval=None)}%,"
                 f"内存 {_fmt_bytes(vm.used)}/{_fmt_bytes(vm.total)}({vm.percent}%),"
                 f"数据盘 {_fmt_bytes(disk.used)}/{_fmt_bytes(disk.total)}({disk.percent}%)")
    try:
        info = dockerx.client().info()
        lines.append(f"Docker:运行 {info.get('ContainersRunning', '?')}/{info.get('Containers', '?')} 容器,"
                     f"镜像 {info.get('Images', '?')} 个,版本 {info.get('ServerVersion', '?')}")
    except Exception as ex:  # noqa: BLE001
        lines.append(f"Docker:不可用({ex})")
    return "\n".join(lines)


_SERVICES = ("api", "web", "db")


def platform_service_logs(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    service = str(args.get("service") or "")
    if service not in _SERVICES:
        raise ToolError(f"service 必须是 {'/'.join(_SERVICES)} 之一")
    tail = max(10, min(int(args.get("tail") or 200), 800))
    c = dockerx.find_platform_container(service)
    if not c:
        raise ToolError(f"找不到平台 {service} 容器(compose 项目 {settings.compose_project})")
    kw: dict = {"tail": tail, "timestamps": True}
    since_minutes = args.get("since_minutes")
    if since_minutes:
        kw["since"] = int(time.time() - min(int(since_minutes), 24 * 60) * 60)
    out = c.logs(**kw).decode(errors="ignore")
    return f"平台 {service} 容器({c.name},状态 {c.status})最近日志:\n{out or '(空)'}"


def docker_ps(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    name_filter = str(args.get("name_filter") or "").lower()
    lines = []
    for c in dockerx.client().containers.list(all=True):
        if name_filter and name_filter not in c.name.lower():
            continue
        st = c.attrs.get("State", {})
        hc = (st.get("Health") or {}).get("Status")
        lines.append(
            f"{c.name}\tstatus={c.status}" + (f"({hc})" if hc else "")
            + f"\texit={st.get('ExitCode')}\toom={st.get('OOMKilled')}\trestarts={c.attrs.get('RestartCount', 0)}"
            + f"\tstarted={st.get('StartedAt', '')[:19]}"
            + (f"\tfinished={st.get('FinishedAt', '')[:19]}" if c.status != "running" else "")
        )
    if not lines:
        return "(没有匹配的容器)"
    return f"共 {len(lines)} 个容器(含已停止):\n" + "\n".join(sorted(lines))


_NOISY_EVENTS = (" exec_create", " exec_start", " exec_die", " exec_detach")


def docker_events(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    minutes = max(1, min(int(args.get("minutes") or 60), 24 * 60))
    until = time.time()
    since = until - minutes * 60
    lines = []
    try:
        for ev in dockerx.client().api.events(since=int(since), until=int(until), decode=True):
            typ, action = ev.get("Type", ""), ev.get("Action", "")
            if typ == "container" and any(action.startswith(a.strip()) for a in ("exec_", "top", "attach")):
                continue
            attrs = (ev.get("Actor") or {}).get("Attributes") or {}
            ts = time.strftime("%m-%d %H:%M:%S", time.localtime(ev.get("time", 0)))
            extra = f" exit={attrs['exitCode']}" if attrs.get("exitCode") else ""
            lines.append(f"{ts} {typ} {action} {attrs.get('name', '')}{extra}")
    except Exception as ex:  # noqa: BLE001
        raise ToolError(f"读取 docker events 失败:{ex}")
    if not lines:
        return f"最近 {minutes} 分钟内没有 docker 事件(exec/top/attach 噪音已过滤)"
    return f"最近 {minutes} 分钟 docker 事件({len(lines)} 条,exec/top/attach 已过滤):\n" + "\n".join(lines[-400:])


def host_resources(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    import psutil

    vm = psutil.virtual_memory()
    sw = psutil.swap_memory()
    try:
        disk = psutil.disk_usage(settings.data_dir)
        disk_label = settings.data_dir
    except OSError:
        disk = psutil.disk_usage("/")
        disk_label = "/"
    try:
        load = ", ".join(f"{x:.2f}" for x in psutil.getloadavg())
    except OSError:
        load = "?"
    lines = [
        f"CPU {psutil.cpu_count()} 核,当前 {psutil.cpu_percent(interval=0.3)}%,负载 {load}",
        f"内存 {_fmt_bytes(vm.used)}/{_fmt_bytes(vm.total)}({vm.percent}%),swap {_fmt_bytes(sw.used)}/{_fmt_bytes(sw.total)}",
        f"数据盘 {disk_label}:{_fmt_bytes(disk.used)}/{_fmt_bytes(disk.total)}({disk.percent}%)",
        f"宿主运行 {int(time.time() - psutil.boot_time()) // 3600} 小时",
    ]
    # dmesg 里的 OOM 记录:容器内通常无权限,拿不到时如实说「未检查」而不是「没有」
    try:
        r = subprocess.run(["dmesg"], capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            oom = [ln for ln in r.stdout.splitlines() if any(k in ln.lower() for k in ("oom", "out of memory", "killed process"))]
            lines.append("内核 OOM 记录:" + ("\n" + "\n".join(oom[-10:]) if oom else "无"))
        else:
            lines.append("内核 OOM 记录:未检查(容器内无 dmesg 权限)")
    except Exception:  # noqa: BLE001
        lines.append("内核 OOM 记录:未检查(容器内无 dmesg 权限)")
    return "\n".join(lines)


def nginx_status(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    import os

    c = dockerx.find_platform_container("web")
    if not c:
        raise ToolError("找不到平台 web(nginx)容器")
    code, out = c.exec_run(["nginx", "-t"])
    lines = [f"web 容器 {c.name} 状态 {c.status}", f"nginx -t → exit={code}\n{out.decode(errors='ignore').strip()}"]
    conf_dir = os.path.join(settings.data_dir, "nginx")
    try:
        files = sorted(f for f in os.listdir(conf_dir) if f.endswith(".conf"))
        lines.append(f"实例 server 配置 {len(files)} 份:{', '.join(files[:40])}" + ("…" if len(files) > 40 else ""))
    except OSError as ex:
        lines.append(f"实例配置目录读取失败:{ex}")
    return "\n".join(lines)


# ---------------- 变更(确认卡) ----------------

def platform_service_restart(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    service = str(args.get("service") or "")
    if service not in _SERVICES:
        raise ToolError(f"service 必须是 {'/'.join(_SERVICES)} 之一")
    if service == "api":
        # api 重启 = 自杀:走平台自更新的 helper 容器(docker compose up -d),当前会话会随之中断
        from ... import platform_update

        try:
            platform_update.start("restart")
        except (ValueError, RuntimeError) as ex:
            raise ToolError(f"发起平台重启失败:{ex}")
        return "已发起平台重启(helper 容器执行 docker compose up -d)。api 进程即将退出,本次 AI 会话会中断,请稍后刷新页面确认平台恢复。"
    c = dockerx.find_platform_container(service)
    if not c:
        raise ToolError(f"找不到平台 {service} 容器")
    c.restart(timeout=10)
    c.reload()
    return f"已重启 {c.name}。当前状态:{c.status}(代码实测,非推断)"


def prune_resources(ctx: ToolCtx, args: dict) -> str:
    _require_super(ctx)
    client = dockerx.client()
    freed = 0
    parts = []
    try:
        r = client.images.prune(filters={"dangling": True})
        freed += r.get("SpaceReclaimed") or 0
        parts.append(f"悬空镜像 {len(r.get('ImagesDeleted') or [])} 个")
    except Exception as ex:  # noqa: BLE001
        parts.append(f"镜像清理失败:{ex}")
    try:
        r = client.api.prune_builds()
        freed += r.get("SpaceReclaimed") or 0
        parts.append("构建缓存已清理")
    except Exception as ex:  # noqa: BLE001
        parts.append(f"构建缓存清理失败:{ex}")
    return f"清理完成:{';'.join(parts)};释放约 {_fmt_bytes(freed)}"


# ---------------- 注册 ----------------

register(Tool(
    name="platform_overview", readonly=True, handler=platform_overview,
    description="平台总览:组织/实例/用户数量、实例状态分布、宿主 CPU/内存/磁盘、Docker 汇总。排查任何问题的第一步。",
    parameters=_obj({})))
register(Tool(
    name="platform_service_logs", readonly=True, handler=platform_service_logs, timeout=30,
    description="平台服务(api=后端 / web=nginx / db=平台 PostgreSQL)容器日志尾部。",
    parameters=_obj({"service": {"type": "string", "enum": list(_SERVICES)},
                     "tail": {"type": "integer", "description": "行数,默认 200,最多 800"},
                     "since_minutes": {"type": "integer", "description": "只看最近 N 分钟(可选)"}}, ["service"])))
register(Tool(
    name="docker_ps", readonly=True, handler=docker_ps, timeout=30,
    description="列出所有容器(含已停止):状态/退出码/OOMKilled/重启次数/启停时间。查『谁挂了、是不是 OOM』用。",
    parameters=_obj({"name_filter": {"type": "string", "description": "按名称子串过滤(可选)"}})))
register(Tool(
    name="docker_events", readonly=True, handler=docker_events, timeout=60,
    description="最近 N 分钟的 docker 事件(容器启停/die/oom 等,exec 噪音已过滤)。定位『几点几分发生了什么』。",
    parameters=_obj({"minutes": {"type": "integer", "description": "回看分钟数,默认 60,最多 1440"}})))
register(Tool(
    name="host_resources", readonly=True, handler=host_resources, timeout=30,
    description="宿主机资源:CPU/负载/内存/swap/数据盘用量、内核 OOM 记录(拿不到时会如实标注未检查)。",
    parameters=_obj({})))
register(Tool(
    name="nginx_status", readonly=True, handler=nginx_status, timeout=30,
    description="nginx 配置校验(nginx -t)+ 实例 server 配置清单。实例域名打不开时先查这个。",
    parameters=_obj({})))
register(Tool(
    name="platform_service_restart", readonly=False, handler=platform_service_restart, timeout=720,
    description="重启平台服务容器(web/db 直接重启;api 走自更新 helper 重启整个平台,会中断当前 AI 会话)。需操作者确认。",
    parameters=_obj({"service": {"type": "string", "enum": list(_SERVICES)}}, ["service"])))
register(Tool(
    name="prune_resources", readonly=False, handler=prune_resources, timeout=720,
    description="清理悬空镜像与构建缓存,释放磁盘空间。需操作者确认。",
    parameters=_obj({})))

# 本文件的工具全部是平台级(仅超管 ops 可见;assist 永不暴露)。统一打标,免得每个 register 都写。
import dataclasses as _dc  # noqa: E402

for _n in ("platform_overview", "platform_service_logs", "docker_ps", "docker_events",
           "host_resources", "nginx_status", "platform_service_restart", "prune_resources"):
    if _n in REGISTRY:
        REGISTRY[_n] = _dc.replace(REGISTRY[_n], scope="platform", assist=False)
