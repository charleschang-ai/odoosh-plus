"""工具注册表。

- 每个工具:名称 / 描述 / JSON Schema 参数 / readonly(只读自动执行,变更走确认卡)/ 超时。
- 双层授权:available_tools() 决定模型「看得见」什么;loop._exec_tool 执行前再查一次
  (防幻觉工具名、防模式切换后重放旧 tool_calls);每个 handler 内部还应自查角色。
- handler 契约:fn(ctx: ToolCtx, args: dict) -> str。可预期的失败抛 ToolError(文案直接给模型看,
  以「怎么办」结尾);其余异常由 loop 归一为反馈文本。
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Callable


class ToolError(Exception):
    """可预期的工具失败:message 直接作为工具结果反馈给模型。"""


@dataclass
class ToolCtx:
    user_id: int
    username: str
    is_superadmin: bool
    conv_id: int
    spill_dir: str
    # assist 模式钉死的组织(非超管必填);super 为 None = 全域。实例级工具据此做租户匹配 + check_env
    tenant_id: int | None = None
    # 输出脱敏:工具加载到的密钥值(env.db_password 等)登记到这里,loop 对每个结果做精确替换
    secrets: list[str] = field(default_factory=list)
    # 变更工具的确认回调(loop 注入):confirm(tool, summary) -> bool;MCP 场景为策略函数
    confirm: Callable[[str, str], bool] | None = None
    # 中止信号(loop 注入):长工具应在循环点自查
    aborted: threading.Event | None = None

    def add_secret(self, *values: str | None) -> None:
        for v in values:
            if v and len(v) >= 6 and v not in self.secrets:
                self.secrets.append(v)


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: dict  # JSON Schema(object)
    handler: Callable[[ToolCtx, dict], str]
    readonly: bool = True
    timeout: int = 60  # 秒;弹确认卡的工具须 > 确认等待时间(loop.CONFIRM_TIMEOUT),否则等确认时就超时了
    scope: str = "instance"  # instance = 实例级;platform = 平台级(仅超管 ops)
    # assist(租户组织级助手)是否可用本工具。平台工具与高危工具(SQL/exec)一律 False:
    # 租户 AI 完全不碰业务数据、也够不到平台层。
    assist: bool = True


REGISTRY: dict[str, Tool] = {}


def register(tool: Tool) -> None:
    REGISTRY[tool.name] = tool


def readonly_names() -> set[str]:
    return {t.name for t in REGISTRY.values() if t.readonly}


def available_tools(is_superadmin: bool, mode: str) -> list[str]:
    """模型可见的工具名单。
    - ops(仅超管):全部工具(平台级 + 实例级 + SQL/exec)。
    - assist(非超管组织级助手):仅 scope=instance 且 assist=True 的工具(无平台工具、无 SQL/exec)。
    - help / 其它:零工具。
    """
    if mode == "ops" and is_superadmin:
        return sorted(REGISTRY)
    if mode == "assist":
        return sorted(t.name for t in REGISTRY.values() if t.scope == "instance" and t.assist)
    return []


def openai_specs(names: list[str]) -> list[dict]:
    out = []
    for n in names:
        t = REGISTRY.get(n)
        if t:
            out.append({"type": "function",
                        "function": {"name": t.name, "description": t.description, "parameters": t.parameters}})
    return out


def _obj(props: dict, required: list[str] | None = None) -> dict:
    schema: dict = {"type": "object", "properties": props}
    if required:
        schema["required"] = required
    return schema
