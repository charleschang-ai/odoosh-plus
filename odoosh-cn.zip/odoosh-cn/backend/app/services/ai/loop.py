"""ReAct agent 循环 + Run/RunManager 事件总线(SSE 供前端订阅)。

同步实现(与平台其它长任务一致,跑在 jobs.spawn 的守护线程上;不与 anyio 线程池抢资源)。
一个 Run 承载一次「发一条消息 → agent 跑到停」的全过程,把事件推进进程内可重放的队列,
SSE 端点(routers/ai.py)订阅它;页面刷新中断后重新订阅可回放已产生的事件。

健壮性(参考 ai-lucky-star 实战):
- 错误分类三类独立重试:瞬时错(退避+抖动)、上下文溢出(压缩后估算变小才重试)、空响应(耗尽即接受)。
- 从 DB 重建历史时修复孤儿 tool_call(中止过的会话否则必被 API 拒)。
- 上下文压缩幂等、前缀稳定、带滞回,保服务商前缀缓存;用户消息永不丢。
- 所有工具输出:special-token 中和 + 脱敏 + 超长落盘。
- 变更工具走确认卡(future+超时=拒绝),请求与结果都进 AiToolRun 审计。
- 重复调用熔断:同一 (工具, 参数) 连续多次相同失败即停,提示换思路(lucky-star 缺这一环,我们补上)。
"""

from __future__ import annotations

import hashlib
import json
import logging
import queue
import random
import threading
import time
from datetime import datetime, timezone

from sqlalchemy import func, select

from ...db import SessionLocal
from ...models import User
from ...models_ai import AiConversation, AiMessage, AiToolRun, AiTokenUsage
from . import client as llmclient
from . import guards, prompts
from .helpkb import load as load_help_kb
from .tools import registry

log = logging.getLogger("odoosh.ai.loop")

MAX_ROUNDS = 24
MAX_TOOL_CALLS_PER_ROUND = 8
CONFIRM_TIMEOUT = 300           # 变更工具确认卡等待秒数;工具超时须大于它
LLM_MAX_RETRIES = 2
OVERFLOW_MAX_RETRIES = 2
RETRY_BASE_MS = 600
RETRY_MAX_MS = 12000
DUP_FAIL_LIMIT = 3              # 同一 (工具,参数) 连续相同失败达到此数即熔断
# 上下文压缩阈值(粗略字符估算;中文按更重权重)
COMPACT_TRIGGER_CHARS = 120_000
COMPACT_KEEP_TAIL = 24
TOOL_STUB_CHARS = 1200
RUN_KEEP_SECONDS = 300


# ============================ 事件总线 ============================

class Run:
    """一次发送的事件总线:可重放 history + 多订阅队列 + 确认 future。"""

    def __init__(self, conv_id: int):
        self.conv_id = conv_id
        self.history: list[dict] = []
        self.subs: list[queue.Queue] = []
        self.lock = threading.Lock()
        self.aborted = threading.Event()
        self.ended = False
        self.ended_at: float | None = None
        self._pending_confirm: dict | None = None  # {id, event, result}

    def emit(self, ev: dict) -> None:
        with self.lock:
            self.history.append(ev)
            subs = list(self.subs)
        for q in subs:
            try:
                q.put_nowait(ev)
            except queue.Full:
                pass

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=10000)
        with self.lock:
            for ev in self.history:  # 回放已产生的事件(刷新重连)
                try:
                    q.put_nowait(ev)
                except queue.Full:
                    break
            self.subs.append(q)
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self.lock:
            if q in self.subs:
                self.subs.remove(q)

    def request_confirm(self, call_id: str, tool: str, summary: str) -> bool:
        ev = threading.Event()
        with self.lock:
            self._pending_confirm = {"id": call_id, "event": ev, "result": False}
        self.emit({"type": "confirm_request", "id": call_id, "tool": tool, "summary": summary})
        ok = ev.wait(timeout=CONFIRM_TIMEOUT)
        with self.lock:
            res = bool(self._pending_confirm and self._pending_confirm.get("result"))
            self._pending_confirm = None
        if not ok:
            self.emit({"type": "confirm_result", "id": call_id, "approved": False, "reason": "timeout"})
            return False
        return res

    def resolve_confirm(self, call_id: str, approved: bool) -> bool:
        with self.lock:
            pc = self._pending_confirm
            if not pc or pc["id"] != call_id:
                return False
            pc["result"] = approved
            pc["event"].set()
        self.emit({"type": "confirm_result", "id": call_id, "approved": approved})
        return True

    def finish(self, status: str, message: str = "") -> None:
        self.ended = True
        self.ended_at = time.monotonic()
        self.emit({"type": "end", "status": status, "message": message})


class RunManager:
    def __init__(self):
        self._runs: dict[int, Run] = {}
        self._lock = threading.Lock()

    def get(self, conv_id: int) -> Run | None:
        with self._lock:
            self._gc()
            return self._runs.get(conv_id)

    def create(self, conv_id: int) -> Run:
        with self._lock:
            self._gc()
            run = Run(conv_id)
            self._runs[conv_id] = run
            return run

    def _gc(self) -> None:
        now = time.monotonic()
        for cid in [c for c, r in self._runs.items() if r.ended and r.ended_at and now - r.ended_at > RUN_KEEP_SECONDS]:
            self._runs.pop(cid, None)


manager = RunManager()


# ============================ 持久化辅助 ============================

def _next_seq(db, conv_id: int) -> int:
    return (db.scalar(select(func.max(AiMessage.seq)).where(AiMessage.conversation_id == conv_id)) or 0) + 1


def _persist(db, conv_id: int, role: str, content: str | None, *, tool_calls=None, tool_call_id=None,
             name=None, meta=None, content_full=None) -> AiMessage:
    m = AiMessage(conversation_id=conv_id, seq=_next_seq(db, conv_id), role=role, content=content,
                  tool_calls=json.dumps(tool_calls, ensure_ascii=False) if tool_calls else None,
                  tool_call_id=tool_call_id, name=name,
                  meta=json.dumps(meta, ensure_ascii=False) if meta else None, content_full=content_full)
    db.add(m)
    db.commit()
    db.refresh(m)
    return m


def _set_state(conv_id: int, state: str) -> None:
    with SessionLocal() as db:
        c = db.get(AiConversation, conv_id)
        if c:
            c.state = state
            db.commit()


def _load_history(db, conv_id: int) -> list[dict]:
    """从 DB 重建 OpenAI 消息序列。修复孤儿 tool_call:未被应答的调用补一个哨兵 tool 结果,
    否则中止过的会话下一次请求会因未配对的 tool_call 被 API 拒绝。"""
    rows = db.scalars(select(AiMessage).where(AiMessage.conversation_id == conv_id).order_by(AiMessage.seq)).all()
    msgs: list[dict] = []
    for r in rows:
        if r.role == "assistant":
            m: dict = {"role": "assistant", "content": r.content or ""}
            if r.tool_calls:
                calls = json.loads(r.tool_calls)
                m["tool_calls"] = [{"id": c["id"], "type": "function",
                                    "function": {"name": c["name"], "arguments": json.dumps(c.get("arguments") or {}, ensure_ascii=False)}}
                                   for c in calls]
                answered = {x.tool_call_id for x in rows if x.role == "tool" and x.tool_call_id}
                msgs.append(m)
                for c in calls:
                    if c["id"] not in answered:
                        msgs.append({"role": "tool", "tool_call_id": c["id"], "name": c.get("name"),
                                     "content": "(该次运行被中止,此工具未执行)"})
                continue
            msgs.append(m)
        elif r.role == "tool":
            msgs.append({"role": "tool", "tool_call_id": r.tool_call_id, "name": r.name, "content": r.content or ""})
        elif r.role in ("user", "system"):
            msgs.append({"role": "user" if r.role == "system" else r.role, "content": r.content or ""})
    return msgs


# ============================ 上下文压缩 ============================

def _est(messages: list[dict]) -> int:
    total = 0
    for m in messages:
        c = m.get("content") or ""
        cjk = sum(1 for ch in c if "一" <= ch <= "鿿")
        total += cjk + (len(c) - cjk) // 4 + 40
        for tc in m.get("tool_calls") or []:
            total += len(json.dumps(tc)) // 3
    return total


def _compact(messages: list[dict]) -> list[dict]:
    """幂等、前缀稳定、带滞回。system[0] 与 user 消息永不删;旧 tool 结果先截断,仍超再从最旧端整块丢。"""
    if _est(messages) < COMPACT_TRIGGER_CHARS:
        return messages
    out = [dict(m) for m in messages]
    # 1) 截断靠前的 tool 结果
    for m in out[:-COMPACT_KEEP_TAIL]:
        if m.get("role") == "tool" and m.get("content") and len(m["content"]) > TOOL_STUB_CHARS:
            m["content"] = m["content"][:TOOL_STUB_CHARS] + f"\n…(旧工具结果已截断,原 {len(m['content'])} 字符)"
    if _est(out) < COMPACT_TRIGGER_CHARS * 3 // 4:  # 滞回:降到 3/4 即停
        return out
    # 2) 从最旧端整块丢(保 system[0] 与所有 user;assistant+其 tool 结果作为整体丢)
    head = out[:1]
    body = out[1:]
    keep_tail = body[-COMPACT_KEEP_TAIL:]
    older = body[:-COMPACT_KEEP_TAIL]
    kept = [m for m in older if m.get("role") == "user"]
    result = head + kept + keep_tail
    # 丢弃后可能在 keep_tail 之前留下孤儿 tool 结果(其 assistant 被丢):清掉开头无主的 tool 消息
    while len(result) > 1 and result[1].get("role") == "tool":
        result.pop(1)
    return result


# ============================ 预算 / 用量 ============================

def _today_start() -> datetime:
    now = datetime.now(timezone.utc)
    return now.replace(hour=0, minute=0, second=0, microsecond=0)


def _tokens_used_today(db, user_id: int) -> int:
    total = db.scalar(
        select(func.coalesce(func.sum(AiTokenUsage.prompt_tokens + AiTokenUsage.completion_tokens), 0))
        .where(AiTokenUsage.user_id == user_id, AiTokenUsage.created_at >= _today_start()))
    return int(total or 0)


def _daily_limit(db, cfg) -> int:
    if cfg and cfg.max_daily_tokens is not None:
        return int(cfg.max_daily_tokens)
    from ...routers.settings import get_setting

    try:
        return int(get_setting(db, "ai.daily_token_limit_default") or 0)
    except (TypeError, ValueError):
        return 0


def _check_budget(user_id: int, cfg) -> None:
    with SessionLocal() as db:
        limit = _daily_limit(db, cfg)
        if limit <= 0:
            return
        used = _tokens_used_today(db, user_id)
    if used >= limit:
        raise _Budget(f"今日 AI token 用量已达上限({used}/{limit}),请明日再试或调整上限。")


class _Budget(Exception):
    pass


def _log_usage(user_id, conv_id, provider, model, usage) -> None:
    if not usage:
        return
    with SessionLocal() as db:
        db.add(AiTokenUsage(user_id=user_id, conversation_id=conv_id, provider=provider, model=model,
                            prompt_tokens=int(usage.get("prompt_tokens", 0)), completion_tokens=int(usage.get("completion_tokens", 0))))
        db.commit()


# ============================ LLM 调用带重试 ============================

def _retry_delay_ms(err, attempt) -> float | None:
    ra = getattr(err, "retry_after_ms", None)
    if ra:
        return None if ra > RETRY_MAX_MS else float(ra)  # None = 放弃(等太久不如报错)
    exp = min(RETRY_BASE_MS * (2 ** attempt), RETRY_MAX_MS)
    jitter = 1 + (random.random() * 2 - 1) * 0.1
    return min(exp * jitter, RETRY_MAX_MS)


def _stream_with_retry(run: Run, conn: dict, messages: list[dict], tools: list[dict]):
    """产出增量文本事件到 run,返回 final dict。三类失败各自计数。"""
    transient = 0
    overflow = 0
    empty = 0
    while True:
        if run.aborted.is_set():
            raise _Aborted()
        text_acc: list[str] = []
        final = None
        try:
            for ev in llmclient.stream_chat(conn["base_url"], conn["api_key"], conn["model"], messages, tools=tools,
                                             max_tokens=conn.get("max_tokens", llmclient.DEFAULT_MAX_TOKENS)):
                if run.aborted.is_set():
                    raise _Aborted()
                if ev["type"] == "text":
                    text_acc.append(ev["delta"])
                    run.emit({"type": "text", "delta": ev["delta"]})
                elif ev["type"] == "reasoning":
                    run.emit({"type": "reasoning", "delta": ev["delta"]})
                elif ev["type"] == "final":
                    final = ev
            if final is None:
                raise llmclient.LLMError("模型未返回结果", code="EMPTY_RESPONSE")
        except llmclient.LLMError as e:
            run.emit({"type": "stream_reset"})  # 清掉半截文本
            if e.code == llmclient.CONTEXT_OVERFLOW_CODE:
                if overflow >= OVERFLOW_MAX_RETRIES:
                    raise
                overflow += 1
                before = _est(messages)
                messages[:] = _compact_hard(messages)
                if _est(messages) >= before:
                    raise  # 压不动了,别空转
                run.emit({"type": "notice", "text": "上下文超长,已压缩历史后重试"})
                continue
            if e.code in llmclient.RETRYABLE_CODES:
                if e.code == "EMPTY_RESPONSE":
                    if empty >= LLM_MAX_RETRIES:
                        return {"text": "", "tool_calls": [], "usage": {}, "stop_reason": "empty"}
                    empty += 1
                else:
                    if transient >= LLM_MAX_RETRIES:
                        raise
                    transient += 1
                delay = _retry_delay_ms(e, transient)
                if delay is None:
                    raise
                run.emit({"type": "notice", "text": f"模型调用失败({e.code}),{int(delay)}ms 后重试"})
                _interruptible_sleep(run, delay / 1000.0)
                continue
            raise  # AUTH/QUOTA/INVALID_REQUEST 等不可重试
        return final


def _compact_hard(messages: list[dict]) -> list[dict]:
    """溢出应急:无视阈值,深截 tool 结果再从最旧端丢。"""
    out = [dict(m) for m in messages]
    for m in out[:-8]:
        if m.get("role") == "tool" and m.get("content") and len(m["content"]) > 300:
            m["content"] = m["content"][:300] + "…(截断)"
        if m.get("role") == "assistant" and m.get("content") and len(m["content"]) > 400:
            m["content"] = m["content"][:400] + "…(截断)"
    if len(out) > 12:
        head = out[:1]
        tail = out[-8:]
        kept = [m for m in out[1:-8] if m.get("role") == "user"]
        out = head + kept + tail
        while len(out) > 1 and out[1].get("role") == "tool":
            out.pop(1)
    return out


def _interruptible_sleep(run: Run, seconds: float) -> None:
    end = time.time() + seconds
    while time.time() < end:
        if run.aborted.is_set():
            raise _Aborted()
        time.sleep(min(0.2, end - time.time()))


class _Aborted(Exception):
    pass


# ============================ 工具执行 ============================

def _summ_args(args: dict) -> str:
    try:
        s = json.dumps(args, ensure_ascii=False)
    except Exception:  # noqa: BLE001
        s = str(args)
    return s[:500]


def _audit(conv_id, user_id, tool, args, status, approval, duration_ms, detail) -> None:
    with SessionLocal() as db:
        db.add(AiToolRun(conversation_id=conv_id, user_id=user_id, tool=tool, args_summary=_summ_args(args),
                         status=status, approval=approval, duration_ms=duration_ms, detail=(detail or "")[:2000]))
        db.commit()


def _exec_tool(run: Run, ctx: registry.ToolCtx, allowed: set[str], call: dict) -> tuple[str, str]:
    """执行一个工具调用。返回 (结果文本, status)。所有失败归一为反馈文本,绝不抛出打断循环。"""
    name = call.get("name") or ""
    args = call.get("arguments") or {}
    t0 = time.time()
    if call.get("parse_error"):
        msg = (f"工具未执行:{call['parse_error']}。多为单次输出超出 max_tokens 被截断所致,"
               "请减小本次调用的参数量或分多次调用后重试。")
        _audit(run.conv_id, ctx.user_id, name, {}, "error", None, 0, call["parse_error"])
        return msg, "error"
    tool = registry.REGISTRY.get(name)
    if not tool or name not in allowed:
        valid = ", ".join(sorted(allowed)) or "(无)"
        _audit(run.conv_id, ctx.user_id, name, args, "rejected", None, 0, "未知或不可用工具")
        return f"工具未执行:未知或当前不可用的工具「{name}」。可用工具:{valid}", "rejected"
    # 变更工具:确认卡
    approval = "auto"
    if not tool.readonly:
        summary = _summ_args(args)
        run.emit({"type": "notice", "text": f"AI 请求执行「{name}」,等待确认…"})
        if not run.request_confirm(call["id"], name, f"{name} {summary}"):
            _audit(run.conv_id, ctx.user_id, name, args, "denied", "timeout_denied", int((time.time() - t0) * 1000), "用户拒绝/超时")
            return f"工具未执行:操作者拒绝或未在 {CONFIRM_TIMEOUT}s 内确认「{name}」。请勿重复尝试同一操作,可改用只读工具进一步诊断或询问操作者。", "denied"
        approval = "user_confirm"
    # 执行(在子线程里带超时;超时只能中断等待侧,同步代码继续跑到结束——如实告知)
    result: dict = {}

    def _work():
        try:
            out = tool.handler(ctx, args)
            result["text"] = out if isinstance(out, str) else str(out)
        except registry.ToolError as e:
            result["err"] = str(e)
        except Exception as e:  # noqa: BLE001
            log.exception("工具 %s 执行异常", name)
            result["err"] = f"{type(e).__name__}: {e}"

    th = threading.Thread(target=_work, daemon=True, name=f"ai-tool-{name}")
    th.start()
    th.join(timeout=tool.timeout)
    dur = int((time.time() - t0) * 1000)
    if th.is_alive():
        _audit(run.conv_id, ctx.user_id, name, args, "timeout", approval, dur, "超时")
        return f"工具未执行完:「{name}」超过 {tool.timeout}s 仍未返回(操作可能仍在后台进行)。请缩小范围或稍后用只读工具确认结果。", "timeout"
    if "err" in result:
        _audit(run.conv_id, ctx.user_id, name, args, "error", approval, dur, result["err"])
        return result["err"], "error"
    text = result.get("text", "")
    text = guards.neutralize_special_tokens(text)
    text = guards.redact(text, ctx.secrets)
    text = guards.clip(text, spill_dir=ctx.spill_dir, tool=name)
    _audit(run.conv_id, ctx.user_id, name, args, "ok", approval, dur, f"{len(text)} chars")
    return text, "ok"


# ============================ 主流程 ============================

def _resolve_conn(cfg) -> dict:
    from .config import PROVIDER_PRESETS

    provider = (cfg.provider or "custom") if cfg else "custom"
    preset = PROVIDER_PRESETS.get(provider, {})
    base_url = (cfg.base_url if cfg and cfg.base_url else preset.get("base_url")) or ""
    model = (cfg.model if cfg and cfg.model else preset.get("model")) or ""
    return {"base_url": base_url, "model": model, "api_key": (cfg.api_key if cfg else "") or "",
            "provider": provider, "max_tokens": llmclient.DEFAULT_MAX_TOKENS}


def run_message(conv_id: int, user_id: int) -> None:
    """在后台线程执行:读历史 → ReAct 循环 → 收尾。事件推给 run(SSE 订阅)。"""
    run = manager.get(conv_id)  # send() 已预建;竞态兜底
    if run is None or run.ended:
        run = manager.create(conv_id)
    try:
        _run_inner(run, conv_id, user_id)
    except _Aborted:
        run.finish("aborted")
    except _Budget as e:
        _persist_system_note(conv_id, str(e))
        run.emit({"type": "error", "message": str(e)})
        run.finish("error", str(e))
    except llmclient.LLMError as e:
        _persist_system_note(conv_id, f"模型调用失败:{e}")
        run.emit({"type": "error", "message": str(e), "code": e.code})
        run.finish("error", str(e))
    except Exception as e:  # noqa: BLE001
        log.exception("AI 运行异常 conv=%s", conv_id)
        run.emit({"type": "error", "message": f"内部错误:{e}"})
        run.finish("error", str(e))
    finally:
        # 收尾复位状态:即使这里被二次 abort 打断也要吞掉,否则会话永远卡在 running
        try:
            _set_state(conv_id, "idle")
        except Exception:  # noqa: BLE001
            log.warning("复位会话状态失败 conv=%s", conv_id)


def _persist_system_note(conv_id: int, text: str) -> None:
    with SessionLocal() as db:
        _persist(db, conv_id, "assistant", text, meta={"status": "error"})


def _run_inner(run: Run, conv_id: int, user_id: int) -> None:
    with SessionLocal() as db:
        conv = db.get(AiConversation, conv_id)
        user = db.get(User, user_id)
        if not conv or not user:
            run.finish("error", "会话或用户不存在")
            return
        mode = conv.mode
        conv_tenant_id = conv.tenant_id
        is_super = user.is_superadmin
        username = user.username
        from ...models_ai import AiUserConfig

        cfg = db.scalar(select(AiUserConfig).where(AiUserConfig.user_id == user_id))
        history = _load_history(db, conv_id)

    conn = _resolve_conn(cfg)
    if not conn["api_key"] or not conn["base_url"] or not conn["model"]:
        raise llmclient.LLMError("尚未配置模型 API key / 接入信息,请到「AI 助手 → 接入配置」填写", code="AUTH")

    # 模式判定:ops 仅超管;assist = 非超管组织级助手(须有 tenant 作用域);其余退化为纯问答 help。
    if mode == "ops" and is_super:
        system = prompts.ops_prompt()
        ctx_tenant = None  # 超管全域
    elif mode == "assist" and not is_super and conv_tenant_id is not None:
        system = prompts.assist_prompt(load_help_kb())
        ctx_tenant = conv_tenant_id
    else:
        mode = "help"
        system = prompts.help_prompt(load_help_kb())
        ctx_tenant = conv_tenant_id

    tool_names = registry.available_tools(is_super, mode)
    allowed = set(tool_names)
    tool_specs = registry.openai_specs(tool_names)

    spill_dir = guards.spill_dir_for(conv_id)
    ctx = registry.ToolCtx(user_id=user_id, username=username, is_superadmin=is_super, conv_id=conv_id,
                           spill_dir=spill_dir, tenant_id=ctx_tenant, aborted=run.aborted)

    messages = [{"role": "system", "content": system}] + history
    _check_budget(user_id, cfg)

    dup_tracker: dict[str, int] = {}

    for _round in range(MAX_ROUNDS):
        if run.aborted.is_set():
            raise _Aborted()
        _check_budget(user_id, cfg)
        messages = _compact(messages)
        run.emit({"type": "round", "n": _round + 1})
        final = _stream_with_retry(run, conn, messages, tool_specs)
        _log_usage(user_id, conv_id, conn["provider"], conn["model"], final.get("usage"))
        calls = (final.get("tool_calls") or [])[:MAX_TOOL_CALLS_PER_ROUND]
        text = final.get("text") or ""

        with SessionLocal() as db:
            _persist(db, conv_id, "assistant", text, tool_calls=[{"id": c["id"], "name": c["name"], "arguments": c.get("arguments")} for c in calls] or None,
                     meta={"usage": final.get("usage"), "stop_reason": final.get("stop_reason")})
        messages.append({"role": "assistant", "content": text,
                         **({"tool_calls": [{"id": c["id"], "type": "function",
                                             "function": {"name": c["name"], "arguments": json.dumps(c.get("arguments") or {}, ensure_ascii=False)}}
                                            for c in calls]} if calls else {})})
        if not calls:
            run.emit({"type": "message_done", "text": text})
            _maybe_title(conv_id, messages)
            run.finish("done")
            return

        for call in calls:
            if run.aborted.is_set():
                raise _Aborted()
            run.emit({"type": "tool_call", "id": call["id"], "name": call["name"], "arguments": call.get("arguments")})
            result, status = _exec_tool(run, ctx, allowed, call)
            # 重复失败熔断
            if status in ("error", "rejected", "timeout"):
                key = hashlib.sha1(f"{call['name']}:{json.dumps(call.get('arguments') or {}, sort_keys=True, ensure_ascii=False)}".encode()).hexdigest()
                dup_tracker[key] = dup_tracker.get(key, 0) + 1
                if dup_tracker[key] >= DUP_FAIL_LIMIT:
                    result += f"\n\n[系统提示:同一调用已连续失败 {dup_tracker[key]} 次,请勿再重复,换一种思路或向操作者说明卡点。]"
            run.emit({"type": "tool_result", "id": call["id"], "name": call["name"], "status": status, "content": result})
            with SessionLocal() as db:
                _persist(db, conv_id, "tool", result, tool_call_id=call["id"], name=call["name"], meta={"status": status})
            messages.append({"role": "tool", "tool_call_id": call["id"], "name": call["name"], "content": result})

    # 触顶
    note = "已达单次运行最大轮次上限,先停在这里。如需继续排查请再发一条消息。"
    with SessionLocal() as db:
        _persist(db, conv_id, "assistant", note, meta={"status": "max_rounds"})
    run.emit({"type": "message_done", "text": note})
    run.finish("max_rounds")


def _maybe_title(conv_id: int, messages: list[dict]) -> None:
    """首轮结束后用第一条 user 消息生成简短标题(失败不影响主流程)。"""
    with SessionLocal() as db:
        conv = db.get(AiConversation, conv_id)
        if not conv or conv.title:
            return
        first_user = next((m["content"] for m in messages if m.get("role") == "user" and m.get("content")), "")
        if first_user:
            conv.title = first_user.strip().replace("\n", " ")[:40]
            db.commit()
