"""OpenAI 兼容协议的 LLM 客户端(同步流式,requests)。

设计要点(参考 ai-lucky-star 的实战教训):
- 错误码与文案分离:LLMError.code 供代码路由(重试/压缩/放弃),message 给人看。
- 同一 HTTP 状态码需要按响应正文再细分:配额耗尽在 DeepSeek 是 402、在 OpenAI 是 429+文案;
  上下文溢出是一个普通 400,必须靠正则从 body 里认出来,才能走「压缩后重试」而不是直接报错。
- 传输层异常在生成器边界统一归一为 LLMError(TIMEOUT/TRANSPORT),重试层只看 code。
- 思考型模型可能把整个输出预算花在 reasoning 上:正文与工具调用都为空时,
  不要静默结束(前端看起来像"问了没回答"),把思考尾巴带出来。
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Iterator
from email.utils import parsedate_to_datetime

import requests

log = logging.getLogger("odoosh.ai.client")

# 这些 code 属于瞬时故障,重试可能成功;CONTEXT_WINDOW_EXCEEDED 单独走「压缩历史后重试」
RETRYABLE_CODES = {"EMPTY_RESPONSE", "RATE_LIMIT", "SERVER", "TIMEOUT", "TRANSPORT"}
CONTEXT_OVERFLOW_CODE = "CONTEXT_WINDOW_EXCEEDED"

DEFAULT_MAX_TOKENS = 4096
CONNECT_TIMEOUT = 15
READ_TIMEOUT = 300


class LLMError(Exception):
    def __init__(self, message: str, code: str = "UNKNOWN", retry_after_ms: int | None = None):
        super().__init__(message)
        self.code = code
        self.retry_after_ms = retry_after_ms


_QUOTA_RE = re.compile(r"insufficient[_ ](quota|balance)|exceeded your.*quota|余额不足|欠费|billing", re.I)
_CTX_RE = re.compile(
    r"context[_ ]length|maximum context|context window|too (long|many tokens)|max(imum)?[_ ]?tokens.{0,30}exceed"
    r"|prompt is too long|输入过长|超出.{0,8}(上下文|长度)", re.I)


def classify_http_error(status: int, body: str) -> str:
    if status in (401, 403):
        return "AUTH"
    if status == 402 or _QUOTA_RE.search(body or ""):
        return "QUOTA_EXCEEDED"
    if status == 429:
        return "RATE_LIMIT"
    if status == 400:
        return CONTEXT_OVERFLOW_CODE if _CTX_RE.search(body or "") else "INVALID_REQUEST"
    if status >= 500:
        return "SERVER"
    return f"HTTP_{status}"


def _retry_after_ms(headers) -> int | None:
    ra = headers.get("Retry-After") if headers else None
    if not ra:
        return None
    try:
        return int(float(ra) * 1000)
    except ValueError:
        pass
    try:  # HTTP-date 形式
        import time as _t

        dt = parsedate_to_datetime(ra)
        return max(0, int(dt.timestamp() * 1000 - _t.time() * 1000))
    except Exception:  # noqa: BLE001
        return None


def parse_tool_args(raw: str | None) -> tuple[dict, str]:
    """工具参数 JSON 解析。不做自动修复——修错了比报错更危险;返回可操作的错误描述,
    让模型自己看到「参数被截断/畸形」并重试(多为单次输出超出 max_tokens 被截断所致)。"""
    if not raw:
        return {}, ""
    try:
        v = json.loads(raw)
        if isinstance(v, dict):
            return v, ""
        return {}, f"参数不是 JSON 对象(而是 {type(v).__name__})"
    except Exception:  # noqa: BLE001
        return {}, f"参数 JSON 无法解析(共 {len(raw)} 字符,开头:{raw[:120]}…)"


def _friendly(code: str, body: str) -> str:
    m = {
        "AUTH": "API key 无效或无权限,请在「AI 助手 → 接入配置」里检查",
        "QUOTA_EXCEEDED": "模型服务商余额/配额不足,请前往服务商充值",
        "RATE_LIMIT": "触发模型服务商限流",
        CONTEXT_OVERFLOW_CODE: "上下文超出模型窗口",
        "INVALID_REQUEST": "请求被模型服务商拒绝(参数不合法)",
        "SERVER": "模型服务商服务端错误",
    }
    base = m.get(code, f"模型调用失败({code})")
    tail = (body or "").strip().replace("\n", " ")[:200]
    return f"{base}:{tail}" if tail else base


def stream_chat(base_url: str, api_key: str, model: str, messages: list[dict], tools: list[dict] | None = None,
                max_tokens: int = DEFAULT_MAX_TOKENS, temperature: float | None = None) -> Iterator[dict]:
    """流式对话。产出事件:
    {"type":"text","delta":str} / {"type":"reasoning","delta":str} /
    {"type":"final","text","tool_calls":[{id,name,arguments,parse_error}],"usage":{...},"stop_reason"}
    任何失败抛 LLMError(code 见 classify_http_error / TIMEOUT / TRANSPORT)。
    """
    url = (base_url or "").rstrip("/") + "/chat/completions"
    payload: dict = {"model": model, "messages": messages, "stream": True, "max_tokens": int(max_tokens),
                     "stream_options": {"include_usage": True}}
    if temperature is not None:
        payload["temperature"] = temperature
    if tools:
        payload["tools"] = tools
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    def _post(pl):
        return requests.post(url, json=pl, headers=headers, stream=True, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))

    try:
        r = _post(payload)
        if r.status_code == 400 and "stream_options" in (r.text or ""):
            # 个别 OpenAI 兼容端点不认识 stream_options:去掉重试一次(usage 只能靠最后一个 chunk 自带)
            payload.pop("stream_options", None)
            r = _post(payload)
    except requests.Timeout as e:
        raise LLMError(f"连接模型服务超时:{e}", code="TIMEOUT")
    except requests.RequestException as e:
        raise LLMError(f"无法连接模型服务:{e}", code="TRANSPORT")

    if r.status_code != 200:
        body = ""
        try:
            body = r.text[:2000]
        except Exception:  # noqa: BLE001
            pass
        code = classify_http_error(r.status_code, body)
        raise LLMError(_friendly(code, body), code=code, retry_after_ms=_retry_after_ms(r.headers))

    text_parts: list[str] = []
    reasoning_parts: list[str] = []
    tool_calls: dict[int, dict] = {}
    usage: dict = {}
    stop_reason = None
    try:
        for line in r.iter_lines(decode_unicode=True):
            if not line or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                chunk = json.loads(data)
            except Exception:  # noqa: BLE001
                continue
            if chunk.get("usage"):
                u = chunk["usage"]
                usage = {"prompt_tokens": u.get("prompt_tokens", 0), "completion_tokens": u.get("completion_tokens", 0)}
            for ch in chunk.get("choices") or []:
                if ch.get("finish_reason"):
                    stop_reason = ch["finish_reason"]
                delta = ch.get("delta") or {}
                t = delta.get("content")
                if t:
                    text_parts.append(t)
                    yield {"type": "text", "delta": t}
                rc = delta.get("reasoning_content") or delta.get("reasoning")
                if rc:
                    reasoning_parts.append(rc)
                    yield {"type": "reasoning", "delta": rc}
                for tc in delta.get("tool_calls") or []:
                    idx = tc.get("index", 0)
                    slot = tool_calls.setdefault(idx, {"id": "", "name": "", "arguments": ""})
                    if tc.get("id"):
                        slot["id"] = tc["id"]
                    fn = tc.get("function") or {}
                    if fn.get("name"):
                        slot["name"] = slot["name"] + fn["name"] if slot["name"] else fn["name"]
                    if fn.get("arguments"):
                        slot["arguments"] += fn["arguments"]
    except requests.Timeout as e:
        raise LLMError(f"读取模型响应超时:{e}", code="TIMEOUT")
    except requests.RequestException as e:
        raise LLMError(f"模型响应流中断:{e}", code="TRANSPORT")
    finally:
        try:
            r.close()
        except Exception:  # noqa: BLE001
            pass

    text = "".join(text_parts)
    calls = []
    for idx in sorted(tool_calls):
        c = tool_calls[idx]
        if not c["id"]:
            c["id"] = f"call_{idx}"
        args, err = parse_tool_args(c["arguments"])
        calls.append({"id": c["id"], "name": c["name"], "arguments": args, "raw_arguments": c["arguments"], "parse_error": err})
    reasoning = "".join(reasoning_parts)
    if not text and not calls and reasoning:
        # 思考型模型把输出预算全花在思考上:带出思考尾巴,别让运行看起来"无回复地结束"
        text = "(模型本轮把输出预算用在了思考上,未给出正式回复;以下是它思考的结尾片段)\n" + reasoning[-1200:]
    yield {"type": "final", "text": text, "tool_calls": calls, "usage": usage, "stop_reason": stop_reason}
