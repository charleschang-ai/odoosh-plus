"""安全防线:special-token 中和、脱敏、超长输出落盘(spill)、灾难命令识别。

纵深防御的代码层部分(提示词层的注入边界见 prompts.py,执行层的确认卡见 loop.py):
- 工具输出里的 <|im_end|> / <|User|> 之类文本,在某些推理栈会被 tokenizer 当成真控制 token,
  伪造对话轮次——提示词层"工具输出是数据"防不到这一层,必须在文本层转义。
- 实例日志/SQL 结果是租户可控内容 = 首要不可信输入;进 LLM 前先把已知密钥值精确替换掉,
  绝不让 db_password/API token 落进第三方模型服务商的日志。
"""

from __future__ import annotations

import logging
import os
import re
import secrets as _secrets

log = logging.getLogger("odoosh.ai.guards")

# 要求 ≥1 个词字符,避免误伤 Haskell 的 <|> 之类合法代码
_SPECIAL_TOKEN_RE = re.compile(r"<\|([A-Za-z_▁][A-Za-z0-9_▁./-]*)\|>")


def neutralize_special_tokens(text: str) -> str:
    if not text or "<|" not in text:
        return text
    return _SPECIAL_TOKEN_RE.sub(r"<\\|\1\\|>", text)


# 连接串里的口令:postgresql://user:pass@host / redis://:pass@host …
_URL_CRED_RE = re.compile(r"(\w+://[^/\s:@]+:)([^@\s/]+)(@)")


def redact(text: str, secret_values: list[str] | None = None) -> str:
    """精确替换已知密钥值 + 通用连接串口令。secret_values 由工具在加载 env 行时登记(ToolCtx.secrets)。"""
    if not text:
        return text
    for v in secret_values or []:
        if v and len(v) >= 6 and v in text:
            text = text.replace(v, "***")
    return _URL_CRED_RE.sub(r"\1***\3", text)


# ---------------- 超长输出落盘(spill) ----------------
SPILL_CAP = 8000          # 单个工具结果进上下文的默认上限(字符)
_SPILL_MAX_FILES = 200


def spill_dir_for(conv_id: int) -> str:
    from ...config import settings

    return os.path.join(settings.data_dir, "ai-spill", f"conv_{int(conv_id)}")


def clip(text: str, cap: int = SPILL_CAP, spill_dir: str | None = None, tool: str = "") -> str:
    """超过 cap 时:完整输出写盘,模型拿到 头 + 提示 + 尾,可用 read_spill 分段回读。
    落盘失败则降级为「带标记的」截断——绝不静默硬截(模型不知道被截断会得出错误结论)。"""
    if text is None:
        return ""
    total = len(text)
    if total <= cap:
        return text
    path = None
    if spill_dir:
        try:
            os.makedirs(spill_dir, exist_ok=True)
            if len(os.listdir(spill_dir)) < _SPILL_MAX_FILES:
                fname = f"{_secrets.token_hex(4)}-{re.sub(r'[^A-Za-z0-9_-]', '_', tool or 'out')[:40]}.txt"
                path = os.path.join(spill_dir, fname)
                with open(path, "w", encoding="utf-8", errors="replace") as f:
                    f.write(text)
        except OSError as ex:
            log.warning("spill 落盘失败: %s", ex)
            path = None
    if path:
        notice = (f"\n…(中间省略)…\n【完整输出共 {total} 字符,已保存到 {path};"
                  "用 read_spill 传该路径可分段查看(offset/limit)】\n")
    else:
        notice = f"\n…(中间省略;完整输出共 {total} 字符,已被截断)…\n"
    budget = max(400, cap - len(notice) - 40)  # 先扣掉提示本身的长度,否则总长仍超 cap
    head = text[: budget * 3 // 4]
    tail = text[total - (budget - len(head)):]
    return head + notice + tail


def read_spill_file(spill_dir: str, path: str, offset: int = 0, limit: int = 200) -> str:
    """回读落盘文件:只允许本会话 spill 目录内的文件(resolve 后校验,防符号链接逃逸)。"""
    real_dir = os.path.realpath(spill_dir)
    real = os.path.realpath(path)
    if not real.startswith(real_dir + os.sep):
        raise ValueError("只能读取本会话落盘目录内的文件")
    if not os.path.isfile(real):
        raise ValueError("文件不存在(可能已被清理)")
    with open(real, encoding="utf-8", errors="replace") as f:
        lines = f.read().splitlines()
    offset = max(0, int(offset))
    limit = max(1, min(int(limit), 500))
    part = lines[offset: offset + limit]
    head = f"(共 {len(lines)} 行,显示 {offset + 1}–{min(offset + limit, len(lines))})\n"
    return head + "\n".join(part)


# ---------------- 灾难命令(container_exec 用):即使用户确认也拒绝 ----------------
_CATASTROPHIC = [
    (re.compile(r"\brm\s+(-[a-zA-Z]+\s+)*(/|/\*)(\s|$)"), "删除根目录"),
    (re.compile(r"\bmkfs(\.|\s)"), "格式化文件系统"),
    (re.compile(r"\bdd\s+[^|]*of=/dev/"), "直写块设备"),
    (re.compile(r"\b(shutdown|reboot|halt|poweroff)\b"), "关机/重启宿主"),
    (re.compile(r"(curl|wget)\b[^|;&]*\|\s*(ba|z|da)?sh\b"), "管道执行远程脚本"),
    (re.compile(r":\s*\(\s*\)\s*{.*};\s*:"), "fork 炸弹"),
    (re.compile(r"\b(systemctl|service)\s+(stop|disable|mask)\s+docker"), "停止 Docker 守护进程"),
    (re.compile(r"\bkill(all)?\s+(-9\s+)?(dockerd|containerd)\b"), "杀死 Docker 守护进程"),
]


def is_catastrophic_command(cmd: str) -> str | None:
    """整串检查(在任何切分之前):返回拒绝原因,None = 放行到确认卡。"""
    s = " ".join((cmd or "").split())
    for rex, why in _CATASTROPHIC:
        if rex.search(s):
            return why
    return None
