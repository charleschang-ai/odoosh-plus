"""帮助助手知识库:随代码分发的 help_kb.md(人工整理,只含用户可见功能)。"""

import logging
import os

log = logging.getLogger("odoosh.ai.helpkb")

_cache: str | None = None


def load() -> str:
    global _cache
    if _cache is None:
        path = os.path.join(os.path.dirname(__file__), "help_kb.md")
        try:
            with open(path, encoding="utf-8") as f:
                _cache = f.read()
        except OSError as ex:
            log.warning("帮助知识库读取失败: %s", ex)
            _cache = ""
    return _cache
