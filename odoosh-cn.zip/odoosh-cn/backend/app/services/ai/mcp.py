"""MCP(Model Context Protocol)适配器:把同一套工具注册表暴露给 MCP 客户端(如 Claude Code)。

- 仅超级管理员可用(路由层用 JWT 校验 is_superadmin)。
- 无第三方依赖:直接实现 MCP 的 JSON-RPC 2.0 无状态 HTTP 形态,支持 initialize / tools/list / tools/call / ping。
- 安全:MCP 无内置确认卡(确认交给外部 agent harness)。默认只暴露只读工具;变更工具需平台设置
  ai.mcp_allow_write=1 才放行。每次调用都写 AiToolRun 审计(approval=mcp)。
"""

from __future__ import annotations

import logging
import time

from ...db import SessionLocal
from ...models_ai import AiToolRun
from . import guards
from .tools import registry

log = logging.getLogger("odoosh.ai.mcp")

PROTOCOL_VERSION = "2025-06-18"
SERVER_INFO = {"name": "odoosh-ops", "version": "0.1.0"}


def _mcp_allow_write() -> bool:
    from ...routers.settings import get_setting

    with SessionLocal() as db:
        return (get_setting(db, "ai.mcp_allow_write") or "0") == "1"


def _exposed_tools() -> list[registry.Tool]:
    allow_write = _mcp_allow_write()
    return [t for t in registry.REGISTRY.values() if t.readonly or allow_write]


def _audit(user_id, tool, status, detail, dur_ms) -> None:
    with SessionLocal() as db:
        db.add(AiToolRun(conversation_id=0, user_id=user_id, tool=tool, args_summary="[mcp]",
                         status=status, approval="mcp", duration_ms=dur_ms, detail=(detail or "")[:2000]))
        db.commit()


def _ok(req_id, result):
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _err(req_id, code, message):
    return {"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}}


def handle(body: dict, user) -> dict | None:
    """处理一个 JSON-RPC 请求;通知(无 id)返回 None(HTTP 202)。user 必须是超管(路由层已校验)。"""
    method = body.get("method")
    req_id = body.get("id")
    params = body.get("params") or {}

    if method == "initialize":
        return _ok(req_id, {"protocolVersion": PROTOCOL_VERSION,
                            "capabilities": {"tools": {"listChanged": False}},
                            "serverInfo": SERVER_INFO,
                            "instructions": "OdooshCN 运维诊断工具:检测与修复平台及所有托管实例。变更类工具默认关闭,"
                                            "需管理员在平台设置开启 ai.mcp_allow_write。"})
    if method in ("notifications/initialized", "notifications/cancelled"):
        return None
    if method == "ping":
        return _ok(req_id, {})
    if method == "tools/list":
        tools = [{"name": t.name, "description": t.description
                  + ("" if t.readonly else "(变更操作,MCP 无确认卡,请谨慎)"),
                  "inputSchema": t.parameters} for t in _exposed_tools()]
        return _ok(req_id, {"tools": tools})
    if method == "tools/call":
        name = params.get("name") or ""
        args = params.get("arguments") or {}
        exposed = {t.name for t in _exposed_tools()}
        if name not in exposed:
            return _ok(req_id, {"content": [{"type": "text", "text": f"工具「{name}」不存在或未开放(变更工具需开启 ai.mcp_allow_write)"}], "isError": True})
        tool = registry.REGISTRY[name]
        ctx = registry.ToolCtx(user_id=user.id, username=user.username, is_superadmin=True,
                               conv_id=0, spill_dir=guards.spill_dir_for(0))
        t0 = time.time()
        try:
            out = tool.handler(ctx, args)
            text = out if isinstance(out, str) else str(out)
            text = guards.redact(guards.neutralize_special_tokens(text), ctx.secrets)
            text = guards.clip(text, spill_dir=ctx.spill_dir, tool=name)
            _audit(user.id, name, "ok", f"{len(text)} chars", int((time.time() - t0) * 1000))
            return _ok(req_id, {"content": [{"type": "text", "text": text}]})
        except registry.ToolError as e:
            _audit(user.id, name, "error", str(e), int((time.time() - t0) * 1000))
            return _ok(req_id, {"content": [{"type": "text", "text": str(e)}], "isError": True})
        except Exception as e:  # noqa: BLE001
            log.exception("MCP 工具 %s 异常", name)
            _audit(user.id, name, "error", str(e), int((time.time() - t0) * 1000))
            return _ok(req_id, {"content": [{"type": "text", "text": f"内部错误:{type(e).__name__}: {e}"}], "isError": True})

    return _err(req_id, -32601, f"未知方法:{method}")
