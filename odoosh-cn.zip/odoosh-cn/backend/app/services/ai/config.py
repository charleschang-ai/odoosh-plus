"""LLM 服务商预设(OpenAI 兼容端点)。用户选 provider 即带出默认 base_url/model,可再覆盖。"""

# 只放国内可直连 + OpenAI 兼容的常见服务商;custom = 完全自填(含本地 Ollama/vLLM)。
PROVIDER_PRESETS: dict[str, dict] = {
    "deepseek": {"label": "DeepSeek", "base_url": "https://api.deepseek.com/v1", "model": "deepseek-chat"},
    "qwen": {"label": "通义千问(DashScope)", "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1", "model": "qwen-plus"},
    "zhipu": {"label": "智谱 GLM", "base_url": "https://open.bigmodel.cn/api/paas/v4", "model": "glm-4-plus"},
    "moonshot": {"label": "Kimi(Moonshot)", "base_url": "https://api.moonshot.cn/v1", "model": "moonshot-v1-32k"},
    "custom": {"label": "自定义(OpenAI 兼容)", "base_url": "", "model": ""},
}


def presets_public() -> list[dict]:
    return [{"key": k, "label": v["label"], "base_url": v["base_url"], "model": v["model"]} for k, v in PROVIDER_PRESETS.items()]
