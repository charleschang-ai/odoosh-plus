"""AI 功能:诊断/修复 agent(超管 ops 模式)与功能问答助手(help 模式)。

分层(设计见 docs/work-2026-08-20-ai.md):
- client.py   OpenAI 兼容协议的流式 LLM 客户端 + 错误分类(LLMError.code)
- loop.py     ReAct 循环、重试、上下文压缩、Run/RunManager 事件总线(SSE 供前端订阅)
- prompts.py  system prompt 分段组装 + 注入边界
- guards.py   special-token 中和、脱敏、超长输出落盘、灾难命令识别
- tools/      工具注册表(registry)+ 平台级(platform)/ 实例级(instance)工具
- helpkb.py   帮助助手知识库加载
"""
