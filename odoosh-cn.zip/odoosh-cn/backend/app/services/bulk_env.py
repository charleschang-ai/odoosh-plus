"""批量创建实例:预检 / 提交 / 后台限流执行。

约束(用户已定):
- 权限:仅超管或该组织 owner(组织管理员)。
- 配额:统一拥有者(默认操作者本人,可指定;含超管),按 N 原子校验 User.max_envs。
- 无 Git:一律 official 官方镜像 + 空库(黄金模板秒建);不允许 production;v1 仅 community。
- 快速:两段式(先同步建记录、再后台 provision)+ 先热后扇出 + 全局/同组织并发闸门。
"""

import json
import logging
import re
import threading
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import authz
from ..db import SessionLocal
from ..models import Environment, EnvironmentAcl, Membership, Tenant, User
from ..models_bulk import BulkJob, BulkJobItem
from . import jobs
from . import orchestrator

log = logging.getLogger("odoosh.bulk_env")

NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]*$")
KINDS = ("dev", "staging")  # 批量不建 production
ACL_LEVELS = ("view", "operate", "manage")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _setting_int(db: Session, key: str, default: int) -> int:
    from ..routers.settings import get_setting

    try:
        return int(get_setting(db, key) or default)
    except (TypeError, ValueError):
        return default


# ---------------- 权限 ----------------
def require_env_batch(db: Session, user: User, tenant_id: int) -> None:
    """仅超管或该组织 owner 可批量创建实例。"""
    if authz.is_superadmin(user):
        return
    if authz.tenant_role(db, user, tenant_id) != "owner":
        raise HTTPException(403, "只有超级管理员或组织管理员可以批量创建实例")


# ---------------- 命名 ----------------
def _norm_name(raw: str) -> tuple[str, str | None]:
    v = (raw or "").strip().lower()
    if not v:
        return v, "名称为空"
    if not NAME_RE.match(v):
        return v, "只能含小写字母、数字和中划线,且以字母或数字开头"
    if len(v) > 63:
        return v, "名称过长(≤63)"
    return v, None


def resolve_names(plan) -> list[str]:
    """名称清单优先;否则用前缀 + 补零编号序列展开(原样返回,校验在预检里做)。"""
    if plan.names:
        return [n.strip() for n in plan.names if (n or "").strip()]
    if plan.prefix and plan.count > 0:
        pad = max(1, int(plan.pad or 1))
        return [f"{plan.prefix.strip().lower()}{str(plan.start + i).zfill(pad)}" for i in range(int(plan.count))]
    return []


# ---------------- 预检 ----------------
def _resolve_owner(db: Session, user: User, plan) -> User:
    owner = user if not plan.owner_user_id else db.get(User, plan.owner_user_id)
    if not owner:
        raise HTTPException(404, "指定的拥有者不存在")
    if not (authz.is_superadmin(owner) or authz.tenant_role(db, owner, plan.tenant_id) is not None):
        raise HTTPException(400, f"拥有者「{owner.username}」不是该组织成员")
    return owner


def preflight(db: Session, user: User, plan) -> dict:
    if not db.get(Tenant, plan.tenant_id):
        raise HTTPException(404, "组织不存在")
    require_env_batch(db, user, plan.tenant_id)
    if plan.kind not in KINDS:
        raise HTTPException(400, "批量创建仅支持开发 / 测试实例(不含生产)")
    if plan.base.edition not in ("community", "enterprise"):
        raise HTTPException(400, "版本类型须为 community / enterprise")
    owner = _resolve_owner(db, user, plan)

    max_create = _setting_int(db, "bulk.max_create", 20)
    names = resolve_names(plan)
    warnings: list[str] = []
    if len(names) > max_create:
        warnings.append(f"最多一次创建 {max_create} 个,已截断超出的部分")
        names = names[:max_create]

    existing = {n for (n,) in db.execute(select(Environment.name).where(Environment.tenant_id == plan.tenant_id)).all()}
    items: list[dict] = []
    seen: set[str] = set()
    ok_names: list[str] = []
    for raw in names:
        name, err = _norm_name(raw)
        if not err and name in seen:
            err = "本批内名称重复"
        elif not err and name in existing:
            err = "该组织下已有同名实例"
        seen.add(name)
        ok = err is None
        if ok:
            ok_names.append(name)
        items.append({"name": name or raw, "ok": ok, "reason": err})

    # 配额(统一拥有者)
    used = authz.owned_env_count(db, owner.id)
    limit = None if authz.is_superadmin(owner) else owner.max_envs
    adding = len(ok_names)
    q_ok = True
    q_reason = None
    if limit is not None:
        if limit <= 0:
            q_ok = False
            q_reason = f"拥有者「{owner.username}」不允许创建实例(配额 0)"
        elif used + adding > limit:
            q_ok = False
            q_reason = f"超出拥有者「{owner.username}」的实例配额:已有 {used},本批 +{adding},上限 {limit}"

    # 资源估算 / 上限
    mem_default = _setting_int(db, "limits.env_memory_mb", 1024)
    per_mem = int(plan.base.mem_mb) if plan.base.mem_mb else mem_default
    if not authz.is_superadmin(user) and plan.base.mem_mb and int(plan.base.mem_mb) > mem_default:
        warnings.append(f"内存 {plan.base.mem_mb}MB 超过平台默认 {mem_default}MB,提交时会被拒")
    est_mem = per_mem * adding

    # 企业版:与单个创建同一套 —— ①校验发起用户的企业版权限;②检查统一企业版目录里有该版本
    # (或可从旧 git 检出自动导入)。纯文件系统检查,不联网。
    ent = {"required": False, "available": True, "reason": None, "source": None}
    if plan.base.edition == "enterprise":
        if not authz.is_superadmin(user) and not getattr(user, "can_use_enterprise", True):
            raise HTTPException(403, "你没有创建企业版实例的权限,请联系管理员开通")
        from . import offline_enterprise

        v = str(plan.base.odoo_version)
        if offline_enterprise.resolve_for(v) or offline_enterprise.seedable(v):
            ent = {"required": True, "available": True, "reason": None, "source": "统一企业版目录"}
        else:
            ent = {"required": True, "available": False,
                   "reason": f"未找到 {v} 版本的企业版代码,请超级管理员在「离线企业版代码」里上传该版本", "source": None}
            warnings.append(ent["reason"])

    return {
        "items": items,
        "ok_count": adding,
        "quota": {"owner": owner.username, "used": used, "limit": limit, "adding": adding, "ok": q_ok, "reason": q_reason},
        "est_mem_mb": est_mem,
        "kind": plan.kind,
        "owner_user_id": owner.id,
        "enterprise": ent,
        "warnings": warnings,
    }


# ---------------- 提交 ----------------
def _apply_acl(db: Session, env: Environment, acl: list, tenant_id: int) -> None:
    """初始授权名单:被授权人须是该组织成员;无效项跳过。"""
    for e in acl or []:
        if e.level not in ACL_LEVELS:
            continue
        u = db.get(User, e.user_id)
        if not u or u.id == env.owner_user_id:
            continue
        if not (authz.is_superadmin(u) or authz.tenant_role(db, u, tenant_id) is not None):
            continue
        db.add(EnvironmentAcl(environment_id=env.id, user_id=e.user_id, level=e.level))


def submit(db: Session, user: User, plan, idempotency_key: str | None) -> BulkJob:
    # 幂等:同一用户同一 key → 返回既有作业
    if idempotency_key:
        existed = db.scalar(select(BulkJob).where(BulkJob.idempotency_key == idempotency_key, BulkJob.created_by_id == user.id))
        if existed:
            return existed

    pf = preflight(db, user, plan)
    if not pf["quota"]["ok"]:
        raise HTTPException(403, pf["quota"]["reason"] or "配额不足")
    if pf["enterprise"]["required"] and not pf["enterprise"]["available"]:
        raise HTTPException(400, "企业版代码不可用:" + (pf["enterprise"]["reason"] or ""))
    ok_names = [it["name"] for it in pf["items"] if it["ok"]]
    if not ok_names:
        raise HTTPException(400, "没有可创建的实例(名称均无效或重复)")

    owner = db.get(User, pf["owner_user_id"])
    # 非超管:域名 / 过期只能用默认;资源上限受平台默认约束
    is_super = authz.is_superadmin(user)
    if not is_super:
        mem_default = _setting_int(db, "limits.env_memory_mb", 1024)
        cpu_default = float(_setting_int(db, "limits.env_cpus", 1))
        if plan.base.mem_mb and int(plan.base.mem_mb) > mem_default:
            raise HTTPException(403, f"内存上限不能超过平台默认值 {mem_default} MB")
        if plan.base.cpus and float(plan.base.cpus) > cpu_default:
            raise HTTPException(403, f"CPU 上限不能超过平台默认值 {cpu_default} 核")
    expire_days = plan.base.expire_days if is_super else None

    # 配额二次校验(与建记录同一事务,原子)
    authz.check_env_quota(db, owner, adding=len(ok_names))

    envs: list[Environment] = []
    for name in ok_names:
        env = Environment(
            tenant_id=plan.tenant_id,
            name=name,
            kind=plan.kind,
            odoo_version=plan.base.odoo_version,
            base_mode="official",
            edition=plan.base.edition,
            lang=plan.base.lang,
            repo_url=None,
            branch=None,
            owner_user_id=owner.id,
            mem_mb=int(plan.base.mem_mb) if plan.base.mem_mb else None,
            cpus=float(plan.base.cpus) if plan.base.cpus else None,
            sleep_idle_hours=plan.base.sleep_idle_hours,
            expires_at=orchestrator.compute_expires_at(expire_days, plan.kind),
            status="created",
            status_message="已排队" if plan.provision else "已创建",
        )
        db.add(env)
        db.flush()
        _apply_acl(db, env, plan.base.acl, plan.tenant_id)
        envs.append(env)

    job = BulkJob(
        kind="env.create", scope="environment", tenant_id=plan.tenant_id,
        payload=json.dumps({"kind": plan.kind, "owner_user_id": owner.id, "count": len(envs),
                            "base": plan.base.model_dump(), "provision": plan.provision}, ensure_ascii=False),
        status="queued" if plan.provision else "done",
        total=len(envs), succeeded=0 if plan.provision else len(envs),
        created_by=user.username, created_by_id=user.id, idempotency_key=idempotency_key,
        finished_at=None if plan.provision else _now(),
    )
    db.add(job)
    db.flush()
    for env in envs:
        db.add(BulkJobItem(
            job_id=job.id, target_type="environment", target_id=env.id, label=env.name,
            status="pending" if plan.provision else "success",
            message=None if plan.provision else "仅创建记录,未启动",
        ))
    db.commit()
    db.refresh(job)

    if plan.provision:
        jobs.spawn(run_env_batch, job.id)
    return job


# ---------------- 后台执行:先热后扇出 ----------------
def _set_item(item_id: int, status: str, message: str | None = None, *, started=False, finished=False) -> None:
    with SessionLocal() as db:
        it = db.get(BulkJobItem, item_id)
        if not it:
            return
        it.status = status
        if message is not None:
            it.message = message[:512]
        if started:
            it.started_at = _now()
        if finished:
            it.finished_at = _now()
        db.commit()


def _job_cancelling(job_id: int) -> bool:
    with SessionLocal() as db:
        return db.scalar(select(BulkJob.status).where(BulkJob.id == job_id)) == "cancelling"


def _finalize(job_id: int) -> None:
    with SessionLocal() as db:
        job = db.get(BulkJob, job_id)
        if not job:
            return
        rows = db.execute(select(BulkJobItem.status, func.count()).where(BulkJobItem.job_id == job_id).group_by(BulkJobItem.status)).all()
        by = {s: n for s, n in rows}
        job.succeeded = by.get("success", 0)
        job.failed = by.get("failed", 0)
        job.skipped = by.get("skipped", 0) + by.get("cancelled", 0)
        job.status = "cancelled" if (job.status == "cancelling" and job.succeeded == 0 and job.failed == 0) else "done"
        job.finished_at = _now()
        db.commit()


def _run_one(item_id: int, env_id: int) -> bool:
    _set_item(item_id, "running", started=True)
    try:
        with SessionLocal() as db:
            env = db.get(Environment, env_id)
            if not env:
                raise RuntimeError("实例记录已不存在")
            if env.status == "running":
                _set_item(item_id, "success", "已在运行", finished=True)
                return True
            if not orchestrator.try_claim(db, env, "provisioning", "已排队", forbid=("running",)):
                raise RuntimeError(f"实例正忙:{env.status}")
        orchestrator.provision(env_id)
        with SessionLocal() as db:
            env = db.get(Environment, env_id)
        if env and env.status == "running":
            _set_item(item_id, "success", finished=True)
            return True
        _set_item(item_id, "failed", (env.status_message if env else None) or "创建未成功", finished=True)
        return False
    except Exception as ex:  # noqa: BLE001
        log.exception("批量创建实例项失败 env=%s", env_id)
        _set_item(item_id, "failed", str(ex), finished=True)
        return False


def _run_guarded(job_id: int, item_id: int, env_id: int) -> None:
    if _job_cancelling(job_id):
        _set_item(item_id, "cancelled", "已取消")
        return
    _run_one(item_id, env_id)


def run_env_batch(job_id: int) -> None:
    from concurrent.futures import ThreadPoolExecutor

    with SessionLocal() as db:
        job = db.get(BulkJob, job_id)
        if not job:
            return
        job.status = "running"
        job.started_at = _now()
        db.commit()
        pend = db.scalars(select(BulkJobItem).where(BulkJobItem.job_id == job_id, BulkJobItem.status == "pending").order_by(BulkJobItem.id)).all()
        item_ids = [(it.id, it.target_id) for it in pend]
        workers = max(1, min(_setting_int(db, "bulk.provision_concurrency", 2), _setting_int(db, "bulk.tenant_provision_concurrency", 2)))

    if not item_ids:
        _finalize(job_id)
        return

    # 先热:串行跑第一个,预热租户 PG + 基础镜像 + 模板库
    first_id, first_env = item_ids[0]
    if _job_cancelling(job_id):
        for iid, _ in item_ids:
            _set_item(iid, "cancelled", "已取消")
        _finalize(job_id)
        return
    if not _run_one(first_id, first_env):
        # 预热失败:共享资源没就绪,整批暂停,其余标跳过(可重试)
        for iid, _ in item_ids[1:]:
            _set_item(iid, "skipped", "预热实例失败,批量已暂停;修复后可重试")
        _finalize(job_id)
        return

    # 后扇出:并行其余(此时镜像 / PG / 模板已热,基本是模板秒建 + 起容器)
    rest = item_ids[1:]
    if rest:
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="bulkenv") as ex:
            futs = [ex.submit(_run_guarded, job_id, iid, env) for iid, env in rest]
            for f in futs:
                f.result()
    _finalize(job_id)


# ---------------- 重试 / 取消 ----------------
def retry(db: Session, user: User, job: BulkJob) -> BulkJob:
    failed = db.scalars(select(BulkJobItem).where(BulkJobItem.job_id == job.id, BulkJobItem.status.in_(("failed", "skipped")))).all()
    if not failed:
        raise HTTPException(400, "没有需要重试的项")
    for it in failed:
        it.status = "pending"
        it.message = None
        it.started_at = it.finished_at = None
    job.status = "queued"
    job.finished_at = None
    db.commit()
    jobs.spawn(run_env_batch if job.kind == "env.create" else run_ops, job.id)
    return job


def cancel(db: Session, job: BulkJob) -> BulkJob:
    if job.status not in ("queued", "running"):
        raise HTTPException(409, "作业已结束,无法取消")
    job.status = "cancelling"
    db.execute(
        BulkJobItem.__table__.update().where(BulkJobItem.job_id == job.id, BulkJobItem.status == "pending").values(status="cancelled", message="已取消")
    )
    db.commit()
    return job


# ================= 实例批量操作(start / stop / restart / trash)=================
# 与「创建」不同:目标是已存在的实例,按每个实例的角色矩阵逐项鉴权(部分成功),不限超管 / owner。
OPS: dict[str, dict] = {
    "env.start":    {"action": "start",   "verb": "启动", "busy": "starting",   "final": "running",  "owner": False, "heavy": True},
    "env.stop":     {"action": "stop",    "verb": "停止", "busy": "stopping",   "final": "stopped",  "owner": False, "heavy": False},
    "env.restart":  {"action": "restart", "verb": "重启", "busy": "restarting", "final": "running",  "owner": False, "heavy": True},
    "env.trash":    {"action": "delete",  "verb": "删除", "busy": "destroying", "final": "deleted",  "owner": True,  "heavy": False},
    "env.purge":    {"action": "delete",  "verb": "彻底删除", "busy": "destroying", "final": "gone", "owner": True,  "heavy": False},
    "env.restore":  {"action": "restore", "verb": "恢复", "busy": "starting",   "final": "running",  "owner": True,  "heavy": True},
    "env.sleep":    {"action": "stop",    "verb": "休眠", "busy": "stopping",   "final": "sleeping", "owner": False, "heavy": False, "dev_only": True},
    "env.wake":     {"action": "start",   "verb": "唤醒", "busy": "waking",     "final": "running",  "owner": False, "heavy": True},
    "env.backup":   {"action": "backup",  "verb": "备份", "owner": False, "heavy": False, "backup": True},
    # 元数据类(纯 DB,不动生命周期):串行执行,避免配额 / 名单并发竞争
    "env.edit":     {"action": "edit",    "verb": "修改设置", "owner": False, "db_only": True, "serial": True},
    "env.transfer": {"action": "edit",    "verb": "转让拥有者", "owner": True, "db_only": True, "serial": True, "root": True},
    "acl.grant":    {"action": "edit",    "verb": "添加协作者", "owner": True, "db_only": True, "serial": True, "root": True},
    "acl.revoke":   {"action": "edit",    "verb": "移除协作者", "owner": True, "db_only": True, "serial": True, "root": True},
}
_KIND_LABEL = {"production": "生产", "staging": "测试", "dev": "开发"}
LOG_LEVELS = ("critical", "error", "warn", "info", "debug")


def _precheck_op(db: Session, user: User, env: Environment, kind: str) -> str | None:
    """返回跳过原因(None = 可执行)。与单项接口同一套判定。"""
    spec = OPS[kind]
    role = authz.env_role(db, user, env)
    if not role:
        return "无权访问该实例"
    if spec.get("dev_only") and env.kind != "dev":
        return f"仅开发实例可{spec['verb']}"
    if not authz.env_allowed(role, spec["action"], env.kind):
        return f"无权对{_KIND_LABEL.get(env.kind, env.kind)}实例{spec['verb']}"
    if spec["owner"] and not authz.is_env_owner(db, user, env):
        return f"只有拥有者可{spec['verb']}"
    # 回收站状态:恢复 / 彻底删除针对回收站里的;其余针对未删除的
    if kind == "env.purge":
        if env.deleted_at is None:
            return "不在回收站,请先删除"
    elif kind == "env.restore":
        if env.deleted_at is None:
            return "不在回收站"
    elif kind != "env.trash" and env.deleted_at is not None:
        return "在回收站中,不可操作"
    # 元数据类(edit/transfer/acl)与回收站里的记录:不涉及生命周期,允许在忙碌 / 已删场景外直接改
    if not spec.get("db_only") and env.status in orchestrator.BUSY_STATES:
        return f"正忙:{env.status}"
    if kind == "env.start":
        if env.status == "running":
            return "已在运行"
        if env.status == "sleeping":
            return "休眠中,请单独唤醒"
        if not env.container_name:
            return "尚未创建,请先创建并启动"
    elif kind == "env.stop":
        if env.status in ("stopped", "created") or not env.container_name:
            return "未在运行"
        if env.status == "sleeping":
            return "休眠中(已停用)"
    elif kind == "env.restart":
        if not env.container_name:
            return "尚未创建,请先创建并启动"
        if env.status == "sleeping":
            return "休眠中,请先唤醒"
    elif kind == "env.trash":
        if env.deleted_at is not None:
            return "已在回收站"
        if env.status == "provisioning":
            return "正在创建中"
    elif kind == "env.sleep":
        if env.status != "running":
            return "未在运行"
        if not env.container_name:
            return "尚未创建"
    elif kind == "env.wake":
        if env.status != "sleeping":
            return "未在休眠"
    elif kind == "env.backup":
        if not env.db_name:
            return "尚无数据库,无法备份"
    elif kind == "env.restore":
        dup = db.scalar(select(Environment.id).where(Environment.tenant_id == env.tenant_id, Environment.name == env.name, Environment.id != env.id, Environment.deleted_at.is_(None)))
        if dup:
            return f"已有同名实例「{env.name}」,请先处理"
    return None


def _resolve_targets(db: Session, kind: str, target_ids: list[int]) -> list[int]:
    """root 类动作(转让 / 授权名单)按项目根去重:选中同一项目的多个环境,只作用一次。"""
    ids = list(dict.fromkeys(target_ids))
    if not OPS[kind].get("root"):
        return ids
    out, seen = [], set()
    for eid in ids:
        env = db.get(Environment, eid)
        rid = authz.acl_root_id(env) if env else eid
        if rid in seen:
            continue
        seen.add(rid)
        out.append(rid)
    return out


def preflight_ops(db: Session, user: User, kind: str, target_ids: list[int]) -> dict:
    if kind not in OPS:
        raise HTTPException(400, "未知的批量操作")
    items: list[dict] = []
    ok = 0
    for eid in _resolve_targets(db, kind, target_ids):
        env = db.get(Environment, eid)
        # 不可见 / 不存在统一处理:不泄露实例名与是否存在(防用户枚举 id 探测他人实例)
        if not env or authz.env_role(db, user, env) is None:
            items.append({"env_id": eid, "label": str(eid), "ok": False, "reason": "无权访问该实例或实例不存在"})
            continue
        reason = _precheck_op(db, user, env, kind)
        if reason is None:
            ok += 1
        items.append({"env_id": eid, "label": env.name, "ok": reason is None, "reason": reason})
    return {"kind": kind, "verb": OPS[kind]["verb"], "items": items, "ok_count": ok}


def submit_ops(db: Session, user: User, kind: str, target_ids: list[int], payload: dict | None, idempotency_key: str | None) -> BulkJob:
    if kind not in OPS:
        raise HTTPException(400, "未知的批量操作")
    if idempotency_key:
        existed = db.scalar(select(BulkJob).where(BulkJob.idempotency_key == idempotency_key, BulkJob.created_by_id == user.id))
        if existed:
            return existed

    plan = []  # (env_id, label, reason)
    tenants: set[int] = set()
    for eid in _resolve_targets(db, kind, target_ids):
        env = db.get(Environment, eid)
        if not env or authz.env_role(db, user, env) is None:
            plan.append((eid, str(eid), "无权访问该实例或实例不存在"))  # 不泄露名 / 存在性,也不计入 tenant 分组
            continue
        plan.append((eid, env.name, _precheck_op(db, user, env, kind)))
        tenants.add(env.tenant_id)
    if not any(reason is None for _, _, reason in plan):
        raise HTTPException(400, "没有可执行的实例(均被跳过)")

    job = BulkJob(
        kind=kind, scope="environment", tenant_id=(next(iter(tenants)) if len(tenants) == 1 else None),
        payload=(json.dumps(payload, ensure_ascii=False) if payload else None), status="queued", total=len(plan),
        created_by=user.username, created_by_id=user.id, idempotency_key=idempotency_key,
    )
    db.add(job)
    db.flush()
    for eid, label, reason in plan:
        db.add(BulkJobItem(
            job_id=job.id, target_type="environment", target_id=eid, label=label,
            status="skipped" if reason else "pending", message=reason,
        ))
    db.commit()
    db.refresh(job)
    jobs.spawn(run_ops, job.id)
    return job


def _apply_db_op(db: Session, user: User, env: Environment, kind: str, payload: dict) -> str:
    """纯元数据类操作(edit / transfer / acl.*)。就地改库并 commit;校验失败抛 HTTPException。返回变更摘要。"""
    is_super = authz.is_superadmin(user)
    if kind == "env.edit":
        f = (payload or {}).get("fields", {}) or {}
        if "mem_mb" in f:
            v = int(f["mem_mb"]) if f["mem_mb"] else None
            if v and not is_super:
                cap = _setting_int(db, "limits.env_memory_mb", 1024)
                if v > cap:
                    raise HTTPException(403, f"内存上限不能超过平台默认值 {cap} MB")
            env.mem_mb = v
        if "cpus" in f:
            v = float(f["cpus"]) if f["cpus"] else None
            if v and not is_super:
                cap = float(_setting_int(db, "limits.env_cpus", 1))
                if v > cap:
                    raise HTTPException(403, f"CPU 上限不能超过平台默认值 {cap} 核")
            env.cpus = v
        if "log_level" in f:
            lv = (f["log_level"] or None)
            if lv and lv not in LOG_LEVELS:
                raise HTTPException(422, f"日志等级须为 {'/'.join(LOG_LEVELS)}")
            env.log_level = lv
        if "sleep_idle_hours" in f:
            env.sleep_idle_hours = f["sleep_idle_hours"]
        if "expire_days" in f:
            if not is_super:
                raise HTTPException(403, "过期删除仅平台管理员可设置")
            d = f["expire_days"]
            env.expires_at = orchestrator.compute_expires_at(d, env.kind) if d else None
        db.commit()
        return "已更新"
    if kind == "env.transfer":
        new_id = int((payload or {}).get("new_owner_user_id") or 0)
        nu = db.get(User, new_id)
        if not nu or not nu.is_active:
            raise HTTPException(404, "新拥有者不存在")
        if nu.role != "admin" and not db.scalar(select(Membership).where(Membership.tenant_id == env.tenant_id, Membership.user_id == new_id)):
            raise HTTPException(400, "新拥有者须是该组织成员")
        root = env  # 已在 submit 里按项目根去重
        old_id = root.owner_user_id
        if new_id == old_id:
            return "无变化"
        children = db.scalars(select(Environment).where(Environment.project_id == root.id)).all()
        live_children = sum(1 for c in children if c.deleted_at is None)
        authz.check_env_quota(db, nu, adding=(1 + live_children if root.deleted_at is None else live_children))
        root.owner_user_id = new_id
        for c in children:
            c.owner_user_id = new_id
        db.flush()
        db.execute(EnvironmentAcl.__table__.delete().where(EnvironmentAcl.environment_id == root.id, EnvironmentAcl.user_id == new_id))
        old_user = db.get(User, old_id) if old_id else None
        if old_user and old_user.role != "admin":
            db.add(EnvironmentAcl(environment_id=root.id, user_id=old_id, level="manage"))
        db.commit()
        return f"已转给 {nu.username}"
    if kind in ("acl.grant", "acl.revoke"):
        root = env  # 项目根
        member_ids = set(db.scalars(select(Membership.user_id).where(Membership.tenant_id == root.tenant_id)).all())
        admin_ids = set(db.scalars(select(User.id).where(User.role == "admin")).all())
        owner_id = authz.env_owner_id(db, root)
        existing = {a.user_id: a for a in db.scalars(select(EnvironmentAcl).where(EnvironmentAcl.environment_id == root.id)).all()}
        if kind == "acl.grant":
            n = 0
            for it in (payload or {}).get("entries", []):
                uid, lv = int(it["user_id"]), it.get("level", "view")
                if uid == owner_id or uid in admin_ids:
                    continue
                if uid not in member_ids:
                    raise HTTPException(400, f"用户 #{uid} 不是该组织成员")
                if lv not in ACL_LEVELS:
                    raise HTTPException(400, "无效的授权级别")
                if uid in existing:
                    existing[uid].level = lv
                else:
                    db.add(EnvironmentAcl(environment_id=root.id, user_id=uid, level=lv))
                n += 1
            db.commit()
            return f"已添加/更新 {n} 位协作者"
        # revoke
        uids = {int(x) for x in (payload or {}).get("user_ids", [])}
        gone = 0
        for uid in uids:
            a = existing.get(uid)
            if a:
                db.delete(a)
                gone += 1
        db.commit()
        return f"已移除 {gone} 位协作者"
    raise HTTPException(400, "不支持的操作")


def _do_backup(env_id: int) -> tuple[bool, str]:
    from ..services import backup as backupsvc
    from ..services import databases as dbsvc

    with SessionLocal() as db:
        env = db.get(Environment, env_id)
        t = db.get(Tenant, env.tenant_id)
        if not backupsvc.try_lock(env.id):
            return False, "正在备份 / 恢复中"
        try:
            target = dbsvc.view(db, env, None)  # 主库
            b = backupsvc.new_backup_record(db, target, t, "manual", "批量备份", True, "bulk", push_target_ids="[]")
            bid = b.id
        except Exception:
            backupsvc.unlock(env.id)
            raise
    backupsvc.run_backup(bid, env_id)  # 同步跑到底(内部会释放锁)
    with SessionLocal() as db:
        from ..models_backup import Backup

        b = db.get(Backup, bid)
    if b and b.status == "success":
        return True, ""
    return False, (b.message if b else None) or "备份未成功"


def _run_op(job_id: int, kind: str, uid: int, item_id: int, env_id: int, tenant_sems: dict, lock: threading.Lock, payload: dict) -> None:
    if _job_cancelling(job_id):
        _set_item(item_id, "cancelled", "已取消")
        return
    spec = OPS[kind]
    _set_item(item_id, "running", started=True)
    sem = None
    try:
        with SessionLocal() as db:
            env = db.get(Environment, env_id)
            user = db.get(User, uid)
            if not env or not user:
                _set_item(item_id, "failed", "实例或用户已不存在", finished=True)
                return
            reason = _precheck_op(db, user, env, kind)  # 执行前复检(队列期间权限 / 状态可能变化)
            if reason:
                _set_item(item_id, "skipped", reason, finished=True)
                return
            tenant_id = env.tenant_id
            # 纯元数据类:就地改库,不占生命周期、不进线程限流
            if spec.get("db_only"):
                note = _apply_db_op(db, user, env, kind, payload)
                _set_item(item_id, "success", note, finished=True)
                return
            if kind == "env.purge":
                from ..routers import environments as envrouter

                envrouter._detach_children(db, env)  # 删项目根前把派生环境转走(与单项一致)
            if kind == "env.restore":
                authz.check_env_quota(db, db.get(User, env.owner_user_id) if env.owner_user_id else None)
            if not spec.get("backup") and not orchestrator.try_claim(db, env, spec["busy"], "批量" + spec["verb"], forbid=(("running",) if kind in ("env.start", "env.wake") else ())):
                _set_item(item_id, "skipped", f"正忙:{env.status}", finished=True)
                return
        # 重活按组织限流:同一租户 PG 上并行不超过 tenant_provision_concurrency
        if spec.get("heavy"):
            with lock:
                sem = tenant_sems.get(tenant_id)
            if sem:
                sem.acquire()
        # ---- 执行 ----
        if kind == "env.trash":
            orchestrator.trash(env_id, None)
        elif kind == "env.purge":
            orchestrator.destroy(env_id, False)
        elif kind == "env.restore":
            orchestrator.untrash(env_id)
        elif kind == "env.sleep":
            from ..services import sleep as sleepsvc
            sleepsvc.put_to_sleep(env_id, "批量休眠")
        elif kind == "env.wake":
            from ..services import sleep as sleepsvc
            sleepsvc.wake(env_id, "批量唤醒")
        elif kind == "env.backup":
            ok, msg = _do_backup(env_id)
            _set_item(item_id, "success" if ok else "failed", None if ok else msg, finished=True)
            return
        else:
            getattr(orchestrator, spec["action"])(env_id)
        # ---- 判定结果 ----
        with SessionLocal() as db:
            env = db.get(Environment, env_id)
        if kind == "env.purge":
            ok = env is None
        elif kind == "env.trash":
            ok = bool(env) and env.deleted_at is not None
        elif kind == "env.restore":
            ok = bool(env) and env.deleted_at is None and env.status == "running"
        else:
            ok = bool(env) and env.status == spec["final"]
        if ok:
            _set_item(item_id, "success", finished=True)
        else:
            _set_item(item_id, "failed", (env.status_message if env else None) or f"{spec['verb']}未成功", finished=True)
    except HTTPException as ex:
        _set_item(item_id, "failed", str(ex.detail), finished=True)
    except Exception as ex:  # noqa: BLE001
        log.exception("批量%s失败 env=%s", spec["verb"], env_id)
        _set_item(item_id, "failed", str(ex), finished=True)
    finally:
        if sem is not None:
            sem.release()


def run_ops(job_id: int) -> None:
    from concurrent.futures import ThreadPoolExecutor

    with SessionLocal() as db:
        job = db.get(BulkJob, job_id)
        if not job:
            return
        kind = job.kind
        uid = job.created_by_id
        spec = OPS[kind]
        payload = json.loads(job.payload) if job.payload else {}
        job.status = "running"
        job.started_at = _now()
        db.commit()
        pend = db.scalars(select(BulkJobItem).where(BulkJobItem.job_id == job_id, BulkJobItem.status == "pending").order_by(BulkJobItem.id)).all()
        item_ids = [(it.id, it.target_id) for it in pend]
        heavy = spec.get("heavy", False)
        if spec.get("serial"):
            workers = 1  # 元数据类串行:避免配额 / 名单并发竞争
        else:
            workers = _setting_int(db, "bulk.provision_concurrency", 2) if heavy else _setting_int(db, "bulk.op_concurrency", 6)
        tconc = _setting_int(db, "bulk.tenant_provision_concurrency", 2)
        tenants = {db.get(Environment, eid).tenant_id for _, eid in item_ids if db.get(Environment, eid)}

    if not item_ids:
        _finalize(job_id)
        return
    lock = threading.Lock()
    tenant_sems = {t: threading.Semaphore(max(1, tconc)) for t in tenants} if heavy else {}
    with ThreadPoolExecutor(max_workers=max(1, workers), thread_name_prefix="bulkop") as ex:
        futs = [ex.submit(_run_op, job_id, kind, uid, iid, env, tenant_sems, lock, payload) for iid, env in item_ids]
        for f in futs:
            f.result()
    _finalize(job_id)
