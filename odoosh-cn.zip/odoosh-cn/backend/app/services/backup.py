"""环境备份与恢复。

备份文件 = Odoo 官方「数据库管理器」zip 格式 + 一份平台专用的自定义格式 dump(双格式并存):
    dump.pgc        pg_dump -Fc -Z1(自定义格式,STORED):平台内恢复用 pg_restore -j N 并行导入,大库快 3~4 倍
    dump.sql        由 dump.pgc 经 pg_restore -f - 转出的明文(DEFLATE):兼容 Odoo /web/database/manager 与其他工具
    filestore/      该数据库的 filestore(可选,STORED)
    manifest.json   元信息(db 名、版本、已安装模块、odoosh.{edition,include_filestore,dump_custom})
数据库只 pg_dump 一次;下载后可在任何 Odoo 实例里恢复;从其它 Odoo 导出的备份(只有 dump.sql)也可上传后恢复。

流程(均在后台线程执行;备份受 backup.max_concurrent 并发闸门限制;前端轮询 / 恢复日志走 SSE):
  备份:租户 PG 容器内 pg_dump -Fc 落到 PG 数据目录临时文件 → cat 流式写进 zip → pg_restore -f - 转明文流式写进 zip
        → filestore 逐文件 STORED → 删临时文件
  恢复:实例状态置 restoring(BUSY)→(可选先备份目标环境)→ 停 Odoo 容器 → 重建数据库
        → 有 dump.pgc:流式写到 PG 数据目录 → pg_restore -j N;否则 dump.sql 流式喂 psql stdin
        → 完整性探测(ir_module_module / res_users)→ 备份含 filestore 才替换 filestore → (可选中性化,官方 odoo neutralize)
        → 启动容器 → 按容器真实状态归位实例状态
"""

import collections
import io
import json
import logging
import os
import re
import shutil
import tempfile
import queue
import threading
import time
import zipfile
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from ..config import settings
from ..db import SessionLocal
from ..models import Environment, Setting, Tenant
from ..models_backup import Backup, RestoreJob, TenantBackupPolicy
from . import dockerx
from .orchestrator import ODOO_UID, ensure_tenant_pg, env_dir, env_odoo_uid, pg_container_name
from .throttlelog import ThrottledLog

log = logging.getLogger("odoosh.backup")

_env_locks: set[int] = set()  # 正在备份/恢复中的环境 id(进程内互斥)
_lock = threading.Lock()

# 备份/恢复设置的默认值(与 routers/settings.py 中 DEFAULTS 保持一致;这里再兜底一份)
_DEFAULTS = {
    "backup.dir": "",
    "backup.keep_days": "7",
    "backup.auto_enabled": "0",
    "backup.auto_hour": "3",
    "backup.auto_kinds": "production",
    "backup.upload_max_mb": "4096",
    "backup.keep_days_manual": "0",   # 手动/上传备份保留天数(0 = 永久)
    "backup.quota_mb": "0",           # 每组织备份总量上限 MB(0 = 不限);超出时先删最旧的自动/恢复前备份,再删最旧的手动/上传
    "backup.max_concurrent": "2",     # 同时最多跑几个备份任务(手动 + 自动一起算);其余排队
    "backup.restore_jobs": "0",       # pg_restore -j 并行度;0 = 自动(CPU 数一半,1~4)
    "backup.remote_concurrency": "3", # 用户远程目标推送的并发线程数(工作线程池大小),防止批量备份完成时线程/连接暴涨
    "backup.replica_enabled": "0",    # 1 = 备份完成后推送到 S3 兼容对象存储(异地副本)
    "backup.replica_endpoint": "",    # 如 https://oss-cn-hangzhou.aliyuncs.com / http://minio:9000;AWS 留空
    "backup.replica_bucket": "",
    "backup.replica_region": "",
    "backup.replica_access_key": "",
    "backup.replica_secret": "",      # 以 _secret 结尾 → 设置接口掩码
    "backup.replica_prefix": "odoosh/",
}


def _int_setting(key: str, default: int) -> int:
    try:
        return max(0, int(get_setting(key) or default))
    except ValueError:
        return default


def quota_bytes() -> int:
    return _int_setting("backup.quota_mb", 0) * 1024 * 1024


def tenant_usage_bytes(db, tenant_id: int) -> int:
    from sqlalchemy import func

    return int(db.scalar(select(func.coalesce(func.sum(Backup.size_bytes), 0)).where(Backup.tenant_id == tenant_id)) or 0)


def in_use_backup_ids(db) -> set[int]:
    """正在被某个恢复任务读取的备份 id:配额腾位 / 过期清理 / 手动删除都不得碰它们
    (以前「恢复前自动备份」触发的配额清理可能把正要打开的那个备份删掉)。"""
    return {bid for (bid,) in db.execute(select(RestoreJob.backup_id).where(RestoreJob.status == "running", RestoreJob.backup_id.is_not(None))).all()}


def enforce_quota(db, tenant_id: int, incoming_bytes: int = 0) -> int:
    """把该组织备份总量压到配额之内(为 incoming_bytes 的新备份腾位):按「自动/恢复前 → 手动/上传」、各自从最旧开始删。
    返回删除个数。配额为 0 表示不限。删不动(全是 running / 正在被恢复)时由调用方决定是否拒绝。"""
    quota = quota_bytes()
    if quota <= 0:
        return 0
    used = tenant_usage_bytes(db, tenant_id)
    n = 0
    if used + incoming_bytes <= quota:
        return 0
    busy = in_use_backup_ids(db)
    for kinds in (("auto", "pre_restore"), ("manual", "upload")):
        rows = db.scalars(
            select(Backup).where(Backup.tenant_id == tenant_id, Backup.kind.in_(kinds), Backup.status != "running", Backup.id.not_in(busy or {-1})).order_by(Backup.created_at)
        ).all()
        for b in rows:
            if used + incoming_bytes <= quota:
                break
            try:
                delete_backup_file(b)
            except OSError:
                pass
            used -= int(b.size_bytes or 0)
            db.delete(b)
            n += 1
        if used + incoming_bytes <= quota:
            break
    db.commit()
    if n:
        log.info("组织 #%s 备份超出配额,已删除 %s 个最旧备份", tenant_id, n)
    return n


def check_quota_or_raise(db, tenant_id: int, incoming_bytes: int) -> None:
    """新备份 / 上传前:先按配额腾位;仍放不下就拒绝(而不是把数据盘写满)。"""
    quota = quota_bytes()
    if quota <= 0:
        return
    enforce_quota(db, tenant_id, incoming_bytes)
    used = tenant_usage_bytes(db, tenant_id)
    if used + incoming_bytes > quota:
        raise RuntimeError(f"备份总量超出配额:已用 {used >> 20} MB + 本次约 {incoming_bytes >> 20} MB > {quota >> 20} MB(可删除旧备份或调大 backup.quota_mb)")


def upload_limit_bytes() -> int:
    try:
        return max(1, int(get_setting("backup.upload_max_mb") or 4096)) * 1024 * 1024
    except ValueError:
        return 4096 * 1024 * 1024


# ---------------------------------------------------------------- 设置与路径
_settings_cache: tuple[float, dict[str, str]] | None = None
_SETTINGS_TTL = 30.0


def _load_settings() -> dict[str, str]:
    """一次查出全部 backup.* 设置并缓存 30s(以前每个 key 开一个 session;platform_defaults 一次要读 4 个,
    调度线程每分钟 × 每组织都要算)。"""
    global _settings_cache
    if _settings_cache and time.time() - _settings_cache[0] < _SETTINGS_TTL:
        return _settings_cache[1]
    vals: dict[str, str] = {}
    with SessionLocal() as db:
        from ..crypto import decrypt

        for row in db.scalars(select(Setting).where(Setting.key.like("backup.%"))).all():
            if row.value not in (None, ""):
                vals[row.key] = decrypt(row.value) if row.key.endswith(("_secret", "_token", ".password")) else row.value
    _settings_cache = (time.time(), vals)
    return vals


def invalidate_settings_cache() -> None:
    global _settings_cache
    _settings_cache = None


def get_setting(key: str) -> str:
    return _load_settings().get(key) or _DEFAULTS.get(key, "")


def backups_root() -> str:
    """备份根目录。必须位于数据目录之内(平台容器只挂载了数据目录)。"""
    d = get_setting("backup.dir") or os.path.join(settings.data_dir, "backups")
    if not os.path.abspath(d).startswith(os.path.abspath(settings.data_dir)):
        log.warning("备份目录 %s 不在数据目录内,改用默认位置", d)
        d = os.path.join(settings.data_dir, "backups")
    os.makedirs(d, exist_ok=True)
    return d


def backup_path(b: Backup) -> str | None:
    if not b.filename:
        return None
    return os.path.join(backups_root(), b.filename)


def _tmp_dir() -> str:
    d = os.path.join(backups_root(), ".tmp")
    os.makedirs(d, exist_ok=True)
    return d


def try_lock(env_id: int) -> bool:
    with _lock:
        if env_id in _env_locks:
            return False
        _env_locks.add(env_id)
        return True


def unlock(env_id: int) -> None:
    with _lock:
        _env_locks.discard(env_id)


def is_locked(env_id: int) -> bool:
    with _lock:
        return env_id in _env_locks


# ---------------------------------------------------------------- Docker 辅助
def _exec_to_fileobj(container, cmd: list[str], f, environment: dict | None = None) -> tuple[int, str]:
    """在容器内执行命令,把 stdout 流式写入文件对象 f,返回 (退出码, stderr 摘要)。"""
    api = dockerx.client().api
    ex = api.exec_create(container.id, cmd, stdout=True, stderr=True, environment=environment)
    stream = api.exec_start(ex["Id"], stream=True, demux=True)
    err = io.BytesIO()
    for out, e in stream:
        if out:
            f.write(out)
        if e:
            if err.tell() < 8192:
                err.write(e)
    code = api.exec_inspect(ex["Id"]).get("ExitCode", 1)
    return code, err.getvalue().decode(errors="ignore")


def _exec_from_fileobj(container, cmd: list[str], src, environment: dict | None = None, chunk: int = 1 << 20,
                       total: int = 0, on_progress=None) -> tuple[int, str]:
    """在容器内执行命令,把文件对象 src 流式喂给它的 stdin(不落盘、不打 tar、不 put_archive),
    返回 (退出码, 输出尾部)。输出由独立线程边读边丢弃(只留尾部),避免 stdin 写满 / stdout 未读的死锁。"""
    import socket as _socket

    from docker.utils.socket import frames_iter

    api = dockerx.client().api
    ex = api.exec_create(container.id, cmd, stdin=True, stdout=True, stderr=True, environment=environment)
    sock = api.exec_start(ex["Id"], socket=True)
    raw = getattr(sock, "_sock", sock)
    tail = collections.deque(maxlen=32)  # 最近的输出片段(约 <32KB)
    err_lines: list[bytes] = []          # 含 ERROR 的行(最多留 50 条,psql -q 时输出基本就是它们)
    n_err = 0

    def _reader():
        nonlocal n_err
        rest = b""
        try:
            for _stream, data in frames_iter(sock, False):
                if not data:
                    continue
                tail.append(data[-1024:])
                rest += data
                *lines, rest = rest.split(b"\n")
                for ln in lines:
                    if b"ERROR" in ln:
                        n_err += 1
                        if len(err_lines) < 50:
                            err_lines.append(ln[:500])
                if len(rest) > 65536:
                    rest = rest[-4096:]
        except Exception:  # noqa: BLE001
            pass

    th = threading.Thread(target=_reader, daemon=True)
    th.start()
    sent = 0
    last_tick = -1
    try:
        while True:
            buf = src.read(chunk)
            if not buf:
                break
            raw.sendall(buf)
            sent += len(buf)
            if on_progress:
                tick = int(sent * 20 / total) if total else sent >> 26  # 每 5% 或每 64MB
                if tick != last_tick:
                    last_tick = tick
                    try:
                        on_progress(sent, total)
                    except Exception:  # noqa: BLE001
                        pass
    finally:
        try:
            raw.shutdown(_socket.SHUT_WR)  # 发 EOF,psql 才会结束
        except OSError:
            pass
    th.join()
    try:
        sock.close()
    except Exception:  # noqa: BLE001
        pass
    code = api.exec_inspect(ex["Id"]).get("ExitCode", 1)
    text = b"".join(tail).decode(errors="ignore")
    if err_lines:
        text = "\n".join(ln.decode(errors="ignore") for ln in err_lines) + f"\n... 共 {n_err} 条 ERROR\n" + text
    return code, text


def _exec_to_file(container, cmd: list[str], path: str, environment: dict | None = None) -> tuple[int, str]:
    """在容器内执行命令,把 stdout 流式写入 path,返回 (退出码, stderr 摘要)。"""
    with open(path, "wb") as f:
        return _exec_to_fileobj(container, cmd, f, environment)


def _psql(pg, sql: str, database: str = "postgres", user: str = "postgres", password: str | None = None):
    cmd = ["psql", "-v", "ON_ERROR_STOP=1", "-X", "-q", "-At", "-U", user, "-d", database, "-c", sql]
    env = {"PGPASSWORD": password} if password else None
    code, out = pg.exec_run(cmd, environment=env)
    return code, out.decode(errors="ignore")


def _wait_http(container, timeout: int = 180) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        container.reload()
        if container.status != "running":
            return False
        code, _ = container.exec_run(["curl", "-sf", "http://localhost:8069/web/health"])
        if code == 0:
            return True
        code, _ = container.exec_run(["curl", "-sf", "-o", "/dev/null", "http://localhost:8069/web/login"])  # Odoo 12 无 /web/health
        if code == 0:
            return True
        time.sleep(3)
    return False


class _heartbeat:
    """长阶段(pg_restore)期间每 interval 秒写一行「进行中 … 已 N 秒」,让 UI 不再冻结数小时。"""

    def __init__(self, say, label: str, interval: int = 30):
        self.say, self.label, self.interval = say, label, interval
        self._stop = threading.Event()

    def __enter__(self):
        t0 = time.time()

        def loop():
            while not self._stop.wait(self.interval):
                self.say(f"{self.label}…已 {int(time.time() - t0)} 秒")

        threading.Thread(target=loop, daemon=True).start()
        return self

    def __exit__(self, *exc):
        self._stop.set()


def _chown_tree(path: str, uid: int = ODOO_UID) -> None:
    """按环境所用镜像的 odoo uid(官方镜像 101 / 自建 1000)修正归属(chown -R)。"""
    from .fsutil import chown_tree

    chown_tree(path, uid)


def _filestore_dir(t: Tenant, e: Environment) -> str:
    """Odoo data_dir=/var/lib/odoo 挂载自 env_dir/filestore,故 filestore 实际在 …/filestore/filestore/<db>。"""
    return os.path.join(env_dir(t, e), "filestore", "filestore", e.db_name or "")


def _scan_files(path: str) -> list[tuple[str, int]]:
    """一次 scandir 遍历收集 (文件路径, 大小);entry.stat() 在 Linux 上通常无额外系统调用。"""
    out: list[tuple[str, int]] = []
    stack = [path]
    while stack:
        d = stack.pop()
        try:
            with os.scandir(d) as it:
                for en in it:
                    try:
                        if en.is_dir(follow_symlinks=False):
                            stack.append(en.path)
                        elif en.is_file(follow_symlinks=False):
                            out.append((en.path, en.stat(follow_symlinks=False).st_size))
                    except OSError:
                        continue
        except OSError:
            continue
    return out


def _dir_size(path: str) -> int:
    return sum(sz for _p, sz in _scan_files(path))


def check_free_space(path: str, need_bytes: int, label: str = "备份目录") -> None:
    """开始写大文件前预检剩余空间,不够就早失败,避免把数据盘写满拖垮所有实例。"""
    try:
        free = shutil.disk_usage(path).free
    except OSError:
        return
    if free < need_bytes:
        raise RuntimeError(f"{label}剩余空间不足:还剩 {free // (1 << 20)} MB,预计需要 {need_bytes // (1 << 20)} MB")


# ---------------------------------------------------------------- 备份
def _set_backup(bid: int, **fields) -> None:
    with SessionLocal() as db:
        b = db.get(Backup, bid)
        if b:
            for k, v in fields.items():
                setattr(b, k, v)
            db.commit()


def new_backup_record(db, e: Environment, t: Tenant, kind: str, note: str | None, include_filestore: bool, who: str | None, push_target_ids: str | None = None) -> Backup:
    b = Backup(
        tenant_id=t.id,
        environment_id=e.id,
        tenant_slug=t.slug,
        env_name=e.name,
        odoo_version=e.odoo_version,
        db_name=e.db_name,
        database_id=getattr(e, "database_id", None),  # e 为 databases.EnvDb(附加库视图)时指向该库
        kind=kind,
        status="running",
        message="已排队",
        note=note,
        include_filestore=include_filestore,
        created_by=who,
        push_target_ids=push_target_ids,
    )
    db.add(b)
    db.commit()
    db.refresh(b)
    return b


# 并发闸门:同时最多跑 backup.max_concurrent 个备份(默认 2)。以前调度器给每个实例直接起线程,
# 几十个实例同时 pg_dump + 打包 filestore → 一台机的 IO/CPU 风暴(而且都在 api 容器里)。
_gate_lock = threading.Lock()
_gate: dict = {"sem": None, "n": 0}


def _concurrency_gate() -> threading.BoundedSemaphore:
    n = max(1, _int_setting("backup.max_concurrent", 2) or 2)
    with _gate_lock:
        if _gate["sem"] is None or _gate["n"] != n:
            _gate["sem"], _gate["n"] = threading.BoundedSemaphore(n), n
        return _gate["sem"]


def run_backup(backup_id: int, env_id: int | None = None) -> bool:
    """执行备份(后台任务)。返回是否成功。调用方需已 try_lock(env_id);传入 env_id 可保证记录缺失时锁也会释放。"""
    sem = _concurrency_gate()
    got = False
    try:
        if not sem.acquire(blocking=False):
            _set_backup(backup_id, message=f"排队等待(同时最多 {_gate['n']} 个备份)")
            sem.acquire()
        got = True
        with SessionLocal() as db:
            b = db.get(Backup, backup_id)
            if not b or not b.environment_id:
                return False
            env_id = env_id or b.environment_id
            e = db.get(Environment, b.environment_id)
            t = db.get(Tenant, b.tenant_id)
            if not e or not t:
                _set_backup(backup_id, status="failed", message="环境或租户不存在", finished_at=datetime.now(timezone.utc))
                return False
            if b.database_id:
                from . import databases as dbsvc

                try:
                    e = dbsvc.view(db, e, b.database_id)  # 附加库:同一实例、不同 db_name / filestore 子目录
                except ValueError as ex:
                    _set_backup(backup_id, status="failed", message=str(ex), finished_at=datetime.now(timezone.utc))
                    return False
            return _do_backup(db, b, e, t)
    except Exception as ex:  # noqa: BLE001
        log.exception("backup #%s failed", backup_id)
        _set_backup(backup_id, status="failed", message=str(ex)[:500], finished_at=datetime.now(timezone.utc))
        return False
    finally:
        if got:
            sem.release()
        if env_id is not None:
            unlock(env_id)


class _CountingWriter:
    """包一层文件对象:统计写入字节并按 5% 或每 64MB 回调一次进度(pg_dump / cat 流式写 zip 用)。"""

    def __init__(self, f, on_progress, total: int = 0):
        self.f, self.on_progress, self.total, self.n, self._last = f, on_progress, total, 0, -1

    def write(self, data):
        self.f.write(data)
        self.n += len(data)
        if self.total:
            pct = int(self.n * 100 / self.total)
            if pct // 5 != self._last:
                self._last = pct // 5
                self.on_progress(self.n, self.total)
        elif self.n >> 26 != self._last:  # 每 64MB
            self._last = self.n >> 26
            self.on_progress(self.n, 0)


def _pg_tmp_path(name: str) -> str:
    """PG 容器里数据目录下的临时文件路径(bind mount,不在 overlay 层)。"""
    return f"/var/lib/postgresql/data/{name}"


def _pg_file_size(pg, path: str) -> int:
    code, out = pg.exec_run(["stat", "-c", "%s", path])
    try:
        return int(out.decode().strip()) if code == 0 else 0
    except ValueError:
        return 0


def _pct_or_mb(n: int, tot: int) -> str:
    return f"{int(n * 100 / tot)}%" if tot else f"{n >> 20} MB"


def _do_backup(db, b: Backup, e: Environment, t: Tenant) -> bool:
    if not e.db_name:
        raise RuntimeError("环境尚未创建数据库,无法备份")
    _set_backup(b.id, message="准备租户数据库")
    pg = ensure_tenant_pg(t, db)

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    rel = os.path.join(t.slug, e.name, f"{e.db_name}-{stamp}.zip")
    final_path = os.path.join(backups_root(), rel)
    os.makedirs(os.path.dirname(final_path), exist_ok=True)
    # 空间预检:dump 压缩后大致 = 库大小的一半,filestore 基本不可压缩;不够就早失败
    entries: list[tuple[str, int]] = []
    fs = _filestore_dir(t, e)
    if b.include_filestore and os.path.isdir(fs):
        entries = _scan_files(fs)
    db_bytes = 0
    try:
        code, out = _psql(pg, f"SELECT pg_database_size('{e.db_name}')")
        if code == 0:
            db_bytes = int(out.strip() or 0)
    except Exception:  # noqa: BLE001
        pass
    estimate = db_bytes // 2 + sum(sz for _p, sz in entries)
    check_free_space(backups_root(), estimate + (256 << 20))
    check_quota_or_raise(db, t.id, estimate)
    tmp = tempfile.mkdtemp(prefix=f"bk-{b.id}-", dir=_tmp_dir())
    zip_tmp = os.path.join(tmp, "backup.zip")
    pgc_tmp = _pg_tmp_path(f".odoosh-bk-{b.id}.pgc")  # PG 容器数据目录里的临时自定义格式 dump
    try:
        # 双格式并存:
        #   dump.pgc  pg_dump -Fc(自定义格式,自带压缩):平台内恢复用 pg_restore -j N 并行导入,比 plain psql 快 3~4 倍
        #   dump.sql  由 dump.pgc 经 pg_restore -f - 转出的明文(不再第二次读库):兼容 Odoo 数据库管理器 / 其他工具
        # 数据库只 pg_dump 一次;两份都流式写进 zip(不在 api 侧落盘)。
        with zipfile.ZipFile(zip_tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=3, allowZip64=True) as zf:
            _set_backup(b.id, message="导出数据库 (pg_dump -Fc)")
            t0 = time.time()
            code, out = pg.exec_run(["bash", "-c", f"rm -f {pgc_tmp}; pg_dump -U postgres -Fc -Z1 --no-owner --no-privileges -f {pgc_tmp} {e.db_name}"])
            if code != 0:
                raise RuntimeError(f"pg_dump 失败: {out.decode(errors='ignore')[-300:]}")
            pgc_size = _pg_file_size(pg, pgc_tmp)
            log.info("backup #%s pg_dump -Fc 完成 %s bytes,耗时 %ss", b.id, pgc_size, int(time.time() - t0))
            _set_backup(b.id, message=f"写入 dump.pgc({pgc_size >> 20} MB)")
            # 自定义格式已压缩:STORED,不再 DEFLATE
            zi = zipfile.ZipInfo("dump.pgc", date_time=time.localtime()[:6])
            zi.compress_type = zipfile.ZIP_STORED
            with zf.open(zi, "w", force_zip64=True) as pgc_f:
                w = _CountingWriter(pgc_f, lambda n, tot: _set_backup(b.id, message=f"写入 dump.pgc {_pct_or_mb(n, tot)}"), pgc_size)
                code, err = _exec_to_fileobj(pg, ["cat", pgc_tmp], w)
            if code != 0:
                raise RuntimeError(f"读取 dump.pgc 失败: {err[:300]}")
            _set_backup(b.id, message="转出 dump.sql(明文,兼容 Odoo 数据库管理器)")
            with zf.open("dump.sql", "w", force_zip64=True) as dump_f:
                w = _CountingWriter(dump_f, lambda n, tot: _set_backup(b.id, message=f"转出 dump.sql {_pct_or_mb(n, 0)}"))
                code, err = _exec_to_fileobj(pg, ["pg_restore", "-f", "-", "--no-owner", "--no-privileges", pgc_tmp], w)
            if code != 0:
                raise RuntimeError(f"转出 dump.sql 失败: {err[:300]}")
            pg.exec_run(["rm", "-f", pgc_tmp])

            # 2. manifest(尽量按 Odoo 的格式)
            _set_backup(b.id, message="读取模块清单")
            modules: dict[str, str] = {}
            code, out = _psql(pg, "SELECT name, latest_version FROM ir_module_module WHERE state='installed'", e.db_name)
            if code == 0:
                for line in out.splitlines():
                    if "|" in line:
                        n, v = line.split("|", 1)
                        modules[n] = v
            _code, pgver = _psql(pg, "SHOW server_version")
            try:
                ver_int = int(str(e.odoo_version or "0").split(".")[0])
            except ValueError:
                ver_int = 0
            major = f"{e.odoo_version}.0"
            manifest = {
                "odoo_dump": "1",
                "db_name": e.db_name,
                "version": major,
                "version_info": [ver_int, 0, 0, "final", 0, ""],
                "major_version": major,
                "pg_version": pgver.strip(),
                "modules": modules,
                "odoosh": {"tenant": t.slug, "env": e.name, "backup_id": b.id, "created_at": stamp,
                           "edition": e.edition, "include_filestore": bool(b.include_filestore), "dump_custom": "dump.pgc"},
            }
            zf.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False))

            # 3. filestore
            if b.include_filestore:
                _set_backup(b.id, message="打包 filestore")
                if entries:
                    # 只遍历一次(上面预检时已收集 path+size),不再为算进度分母先 os.walk 一遍
                    total = sum(sz for _p, sz in entries)
                    done = 0
                    last_pct = -1
                    for p, sz in entries:
                        arc = os.path.join("filestore", os.path.relpath(p, fs)).replace(os.sep, "/")
                        try:
                            # filestore 里绝大多数是 PDF/JPG/PNG/OOXML 这类已压缩内容:再 DEFLATE 只烧 CPU 不省空间,
                            # 直接 STORED(zip 允许逐成员指定压缩方式,Odoo 后台恢复照样能读)
                            zf.write(p, arc, compress_type=zipfile.ZIP_STORED)
                            done += sz
                        except OSError:
                            continue
                        pct = int(done * 100 / total) if total else 100
                        if pct != last_pct and pct % 5 == 0:
                            last_pct = pct
                            _set_backup(b.id, message=f"打包 filestore {pct}%")
        os.replace(zip_tmp, final_path)
        size = os.path.getsize(final_path)
        _set_backup(
            b.id,
            status="done",
            message=None,
            filename=rel.replace(os.sep, "/"),
            size_bytes=size,
            finished_at=datetime.now(timezone.utc),
        )
        log.info("backup #%s done: %s (%s bytes)", b.id, rel, size)
        try:
            from . import replica

            replica.push_async(b.id)  # 异地副本(启用时):后台推送,不阻塞备份完成
        except Exception as ex:  # noqa: BLE001
            log.warning("发起副本推送失败: %s", ex)
        try:
            from . import remote

            remote.schedule_push(b.id)  # 用户自有远程目标(实例配置里选的):逐目标后台推送
        except Exception as ex:  # noqa: BLE001
            log.warning("发起远程目标推送失败: %s", ex)
        return True
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        try:
            pg.exec_run(["rm", "-f", pgc_tmp])
        except Exception:  # noqa: BLE001
            pass


def delete_backup_file(b: Backup) -> None:
    try:
        from . import replica

        replica.delete(b)  # 远端副本一并删(best effort)
    except Exception as ex:  # noqa: BLE001
        log.debug("删除远端副本失败(忽略): %s", ex)
    try:
        from . import remote

        remote.on_local_delete(b)  # 用户远程目标:仅 delete_with_local 的目标同步删
    except Exception as ex:  # noqa: BLE001
        log.debug("删除用户远程副本失败(忽略): %s", ex)
    p = backup_path(b)
    if p and os.path.isfile(p):
        os.remove(p)
        # 顺手清掉空目录
        d = os.path.dirname(p)
        while d != backups_root() and os.path.isdir(d) and not os.listdir(d):
            os.rmdir(d)
            d = os.path.dirname(d)


def inspect_zip(path: str) -> dict:
    """校验备份文件,返回 manifest(可能为空 dict)。额外附带两个平台字段:
    `_has_filestore`(zip 里有没有 filestore/ 成员)、`_dump_size`(dump.sql 解压后字节数,估算导入所需空间)。"""
    if not zipfile.is_zipfile(path):
        raise ValueError("不是有效的 zip 文件")
    with zipfile.ZipFile(path) as zf:
        infos = zf.infolist()
        names = {i.filename for i in infos}
        dump = "dump.sql" if "dump.sql" in names else ("dump" if "dump" in names else None)
        if not dump:
            raise ValueError("zip 内缺少 dump.sql(需要 Odoo 数据库管理器导出的 zip 格式)")
        manifest: dict = {}
        if "manifest.json" in names:
            try:
                manifest = json.loads(zf.read("manifest.json")) or {}
            except Exception:  # noqa: BLE001
                manifest = {}
        manifest["_has_filestore"] = any(i.filename.startswith("filestore/") and not i.is_dir() for i in infos)
        manifest["_dump_size"] = zf.getinfo(dump).file_size
        manifest["_pgc_size"] = zf.getinfo("dump.pgc").file_size if "dump.pgc" in names else 0
        return manifest


# ---------------------------------------------------------------- 恢复
class _JobLog(ThrottledLog):
    KEEP = 300

    def __init__(self, job_id: int):
        super().__init__()
        self.job_id = job_id

    def _persist(self, text: str, last_msg: str) -> None:
        from sqlalchemy import update

        with SessionLocal() as db:
            db.execute(update(RestoreJob).where(RestoreJob.id == self.job_id).values(log=text, message=last_msg[:500]))
            db.commit()

    def __call__(self, msg: str) -> None:
        line = f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"
        log.info("restore#%s %s", self.job_id, msg)
        self.add(line, msg)
        try:
            from . import logstream

            logstream.publish(f"restore:{self.job_id}", line)  # SSE 即时推送(GET /backups/restores/{id}/log/stream)
        except Exception:  # noqa: BLE001
            pass


def _finish_job(job_id: int, ok: bool, message: str | None = None) -> None:
    with SessionLocal() as db:
        j = db.get(RestoreJob, job_id)
        if j:
            j.status = "done" if ok else "failed"
            if message:
                j.message = message[:500]
            j.finished_at = datetime.now(timezone.utc)
            db.commit()


NEUTRALIZE_SQL = [
    # 停用定时任务与外发/收取邮件,避免测试环境替生产干活
    "UPDATE ir_cron SET active = false",
    "UPDATE ir_mail_server SET active = false",
    "UPDATE fetchmail_server SET active = false",
    # 解除 base url 冻结,让 Odoo 按新域名重新生成
    "DELETE FROM ir_config_parameter WHERE key IN ('web.base.url.freeze')",
    # 换掉数据库 uuid:同一份数据恢复 / 克隆出的多个环境不再共用身份(企业版授权、publisher warranty、IAP 都按它识别)
    "UPDATE ir_config_parameter SET value = gen_random_uuid()::text, write_date = now() WHERE key = 'database.uuid'",
    # 标记(Odoo 17+ 用该参数在界面上显示「中性化数据库」横幅)
    "INSERT INTO ir_config_parameter (key, value, create_date, write_date) "
    "SELECT 'database.is_neutralized', 'true', now(), now() "
    "WHERE NOT EXISTS (SELECT 1 FROM ir_config_parameter WHERE key='database.is_neutralized')",
]


def _restore_finalize_status(env_id: int, container, fallback: str) -> None:
    """恢复结束后按容器真实状态归位实例状态(恢复期间为 restoring)。
    container 为 None(还没走到停容器那步就失败,比如空间预检 / 恢复前备份失败)时按容器名重新 inspect,
    不能直接用 fallback:那样一个还在跑的实例会被标成 stopped。"""
    from . import orchestrator as orch

    st = fallback
    try:
        if container is None:
            with SessionLocal() as db:
                e = db.get(Environment, env_id)
                container = dockerx.get_container(e.container_name) if e and e.container_name else None
        if container is not None:
            container.reload()
            st = "running" if container.status == "running" else "stopped"
    except Exception:  # noqa: BLE001
        pass
    orch._set_status(env_id, st, None, progress=100 if st == "running" else 0)


def run_restore(job_id: int, backup_id: int, env_id: int, neutralize: bool, backup_before: bool,
                database_id: int | None = None, manage_env_status: bool = True) -> None:
    """恢复(后台任务)。调用方需已 try_lock(env_id) 且(manage_env_status 时)已把实例状态 claim 为 restoring。

    database_id:恢复到该实例的附加库(databases.EnvDb 视图);此时不停容器(其他库照常服务),只断开该库连接后重建;
    manage_env_status=False:不改实例状态 / 进度(附加库操作不该让实例显示「恢复中」)。

    正确性要点(2026-08 审计后加固):
    - 备份不含 filestore(仅数据库 / 上传的纯 SQL zip)时保留目标现有 filestore,不再无条件清空
    - 导入后探测 ir_module_module / res_users;探测失败 → 任务失败(以前 ON_ERROR_STOP=0 下半截导入也算成功)
    - 导入前按 dump 解压大小预检租户 PG 数据目录剩余空间
    - 恢复期间实例状态为 restoring(BUSY),部署 / 启停 / 休眠 / 唤醒都会被挡住;结束后按容器真实状态归位
    - 中性化优先走 project.neutralize_db(官方 odoo neutralize:停支付 / IAP / 社交等),再跑内置 SQL 兜底
    """
    from . import orchestrator as orch

    say = _JobLog(job_id)
    odoo_container = None
    was_running = False
    prior_status = "stopped"
    pg = None
    ok = False
    pgc_path = None  # 写进 PG 数据目录的临时 dump.pgc;正常路径由 pg_restore 命令末尾 rm,异常路径在 finally 兜底
    prog = orch._progress if manage_env_status else (lambda *a, **k: None)
    try:
        with SessionLocal() as db:
            b = db.get(Backup, backup_id)
            e = db.get(Environment, env_id)
            if not b or not e:
                raise RuntimeError("备份或环境不存在")
            t = db.get(Tenant, e.tenant_id)
            if not e.db_name or not e.db_user or not e.container_name:
                raise RuntimeError("目标环境尚未创建完成,请先「创建并启动」")
            if database_id:
                from . import databases as dbsvc

                e = dbsvc.view(db, e, database_id)  # 抛 ValueError → 任务失败
                say(f"目标:附加数据库 {e.db_name}(实例其他库不受影响,不停容器)")
            src = backup_path(b)
            if src and not os.path.isfile(src) and b.replica_status == "done":
                from . import replica

                replica.pull(b, src, say)  # 本地丢了(换盘 / 误删)→ 从异地副本拉回并校验 sha256
            if src and not os.path.isfile(src):
                from . import remote

                remote.pull(b, src, say)  # 再试用户自己的远程目标
            if not src or not os.path.isfile(src):
                raise RuntimeError("备份文件不存在")
            say(f"校验备份文件 {b.filename}")
            manifest = inspect_zip(src)
            has_fs = bool(manifest.get("_has_filestore"))
            dump_size = int(manifest.get("_dump_size") or 0)
            pgc_size = int(manifest.get("_pgc_size") or 0)
            src_ver = str(manifest.get("major_version") or manifest.get("version") or "")
            if src_ver and not src_ver.startswith(f"{e.odoo_version}."):
                say(f"注意:备份来自 Odoo {src_ver},目标环境为 {e.odoo_version},恢复后可能需要升级")
            src_ed = (manifest.get("odoosh") or {}).get("edition")
            if src_ed and src_ed != e.edition:
                say(f"注意:备份来自{'企业版' if src_ed == 'enterprise' else '社区版'}环境,目标环境为{'企业版' if e.edition == 'enterprise' else '社区版'}")
            if not has_fs:
                say("备份不含 filestore:只恢复数据库,目标环境现有附件文件保留")

            # 空间预检:dump 明文导入后的库体积大致 ≈ dump 大小(索引会再大一些);不够就早失败,别把整块数据盘写满
            if dump_size or pgc_size:
                check_free_space(orch.tenant_dir(t), int(dump_size * 1.3) + pgc_size + (512 << 20), "组织数据库目录")

            # 0. 恢复前先备份目标环境
            if backup_before:
                say("恢复前先备份目标环境...")
                prog(env_id, 5, "恢复前备份")
                pre = new_backup_record(db, e, t, "pre_restore", f"恢复 #{backup_id} 前自动备份", True, None)
                try:
                    _do_backup(db, pre, e, t)
                    say(f"已生成恢复前备份 #{pre.id}")
                except Exception as ex:  # noqa: BLE001
                    _set_backup(pre.id, status="failed", message=str(ex)[:500], finished_at=datetime.now(timezone.utc))
                    raise RuntimeError(f"恢复前备份失败,已中止: {ex}")

            pg = ensure_tenant_pg(t, db, say)

            # 1. 停容器(附加库不停:其他库照常服务,靠 pg_terminate_backend 断开该库连接)
            odoo_container = dockerx.get_container(e.container_name)
            if database_id:
                pass
            elif odoo_container and odoo_container.status == "running":
                was_running = True
                prior_status = "running"
                say(f"停止容器 {e.container_name}")
                prog(env_id, 20, "停止容器")
                odoo_container.stop(timeout=30)

            # 2. 重建数据库
            say(f"重建数据库 {e.db_name}")
            prog(env_id, 25, "重建数据库")
            _psql(pg, f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='{e.db_name}' AND pid<>pg_backend_pid()")
            code, out = _psql(pg, f"DROP DATABASE IF EXISTS {e.db_name}")
            if code != 0:
                raise RuntimeError(f"删除旧数据库失败: {out[:300]}")
            code, out = _psql(pg, f"CREATE DATABASE {e.db_name} OWNER {e.db_user} ENCODING 'UTF8' TEMPLATE template0")
            if code != 0:
                raise RuntimeError(f"创建数据库失败: {out[:300]}")
            from .orchestrator import enable_pg_extensions

            enable_pg_extensions(pg, e.db_name, say)  # 先启用扩展再 restore:源库用过 pgvector 的 dump 才能顺利导入
            # 导入期间关掉 synchronous_commit(少几十万次 fsync)、加大 maintenance_work_mem(建索引);结束后按档位恢复
            _psql(pg, f'ALTER DATABASE "{e.db_name}" SET synchronous_commit = off')
            _psql(pg, f"ALTER DATABASE \"{e.db_name}\" SET maintenance_work_mem = '256MB'")

            # 3. 导入
            t0 = time.time()
            errors: list[str] = []
            n_errors = 0
            if pgc_size:
                # 平台自己的备份带 dump.pgc(自定义格式):先把它流式写到 PG 容器数据目录(bind mount),再 pg_restore -j N 并行导入
                #(COPY 与建索引多路并行,比 plain psql 快 3~4 倍;pg_restore -j 需要可寻址文件,不能走 stdin)
                jobs = _int_setting("backup.restore_jobs", 0) or max(1, min(4, (os.cpu_count() or 2) // 2))
                pgc_path = _pg_tmp_path(f".odoosh-restore-{job_id}.pgc")
                say(f"写入 dump.pgc 到数据库容器({pgc_size >> 20} MB)")
                prog(env_id, 30, "写入 dump.pgc")
                with zipfile.ZipFile(src) as zf, zf.open("dump.pgc") as pgc_stream:
                    code, text = _exec_from_fileobj(pg, ["bash", "-c", f"cat > {pgc_path}"], pgc_stream, total=pgc_size,
                                                    on_progress=lambda n, tot: say(f"写入 dump.pgc {_pct_or_mb(n, tot)}"))
                if code != 0:
                    raise RuntimeError(f"写入 dump.pgc 失败: {text[-300:]}")
                say(f"并行导入数据库 (pg_restore -j {jobs})...")
                prog(env_id, 40, f"导入数据库(pg_restore -j {jobs})")
                sh = (f"pg_restore -U {e.db_user} -d {e.db_name} --no-owner --no-privileges -j {jobs} {pgc_path} 2>&1 | grep -c ERROR; "
                      f"rc=${{PIPESTATUS[0]}}; rm -f {pgc_path}; exit $rc")
                with _heartbeat(say, "pg_restore 导入中"):
                    code, out = pg.exec_run(["bash", "-c", sh], environment={"PGPASSWORD": e.db_password or ""})
                text = out.decode(errors="ignore").strip()
                last = text.splitlines()[-1] if text else "0"
                n_errors = int(last) if last.isdigit() else 0
                if code not in (0, 1):  # 1 = 有可忽略错误(扩展 / 权限);其他 = 失败
                    raise RuntimeError(f"pg_restore 导入失败(退出码 {code}): {text[-300:]}")
                if n_errors:
                    # 退出码 1 也可能是 COPY 数据阶段出错(磁盘满 / 写失败 / 内存不足):这类不是「可忽略」,直接判失败
                    fatal = re.search(r"No space left|could not write|could not extend|out of memory|COPY failed|canceling statement", text, re.I)
                    if fatal:
                        raise RuntimeError(f"pg_restore 导入过程中出现致命错误({fatal.group(0)}),共 {n_errors} 条: {text[-300:]}")
            else:
                # 上传的 Odoo 官方 zip / 旧版备份:只有 dump.sql,流式喂给 psql stdin(零落盘,边解压边导入)
                say(f"导入数据库 (psql){',dump 约 ' + str(dump_size >> 20) + ' MB' if dump_size else ''}...")
                prog(env_id, 30, "导入数据库")
                with zipfile.ZipFile(src) as zf:
                    dump_member = "dump.sql" if "dump.sql" in zf.namelist() else "dump"
                    with zf.open(dump_member) as dump_stream:
                        code, text = _exec_from_fileobj(
                            pg,
                            ["psql", "-X", "-q", "-v", "ON_ERROR_STOP=0", "-U", e.db_user, "-d", e.db_name],
                            dump_stream,
                            environment={"PGPASSWORD": e.db_password or ""},
                            total=dump_size,
                            on_progress=lambda n, tot: say(f"导入数据库 {_pct_or_mb(n, tot)}"),
                        )
                errors = [ln for ln in text.splitlines() if "ERROR" in ln and not ln.startswith("... 共")]
                m_total = re.search(r"\.\.\. 共 (\d+) 条 ERROR", text)
                n_errors = int(m_total.group(1)) if m_total else len(errors)
                if code != 0:
                    raise RuntimeError(f"psql 导入失败: {text[-300:]}")
            # 导入结果探测:核心表必须在且有数据,否则视为失败(而不是带着半截库标记 done)
            probe_code, probe_out = _psql(pg, "SELECT (SELECT count(*) FROM ir_module_module) || '|' || (SELECT count(*) FROM res_users)", e.db_name)
            parts = probe_out.strip().split("|")
            probe_ok = probe_code == 0 and len(parts) >= 2 and all(x.strip().isdigit() and int(x) > 0 for x in parts[:2])
            if not probe_ok:
                raise RuntimeError(f"数据库导入不完整(ir_module_module / res_users 不可用,共 {n_errors} 条 SQL 错误):\n" + "\n".join(errors[:5]))
            _psql(pg, f'ALTER DATABASE "{e.db_name}" RESET maintenance_work_mem')
            if n_errors:
                say(f"数据库导入完成(耗时 {int(time.time() - t0)}s),但有 {n_errors} 条 SQL 错误(多为扩展 / 权限,前 5 条):\n" + "\n".join(errors[:5]))
            else:
                say(f"数据库导入完成(耗时 {int(time.time() - t0)}s)")
            from .orchestrator import set_db_durability

            set_db_durability(pg, e.db_name, e.kind == "production")

            # 4. filestore(仅当备份里带了 filestore 才替换;否则保留现有)
            fs = _filestore_dir(t, e)
            if has_fs:
                prog(env_id, 70, "还原 filestore")
                with zipfile.ZipFile(src) as zf:
                    members = [m for m in zf.infolist() if m.filename.startswith("filestore/") and not m.is_dir()]
                    total_unc = sum(m.file_size for m in members)
                    if len(members) > 2_000_000 or total_unc > 200 * 1024 ** 3:
                        raise RuntimeError(f"filestore 解压后过大({len(members)} 个文件 / {total_unc // 1024 ** 3} GB),拒绝恢复")
                    check_free_space(env_dir(t, e), total_unc + (256 << 20), "实例数据目录")
                    say(f"还原 filestore({len(members)} 个文件,{total_unc >> 20} MB)")
                    if os.path.isdir(fs):
                        shutil.rmtree(fs, ignore_errors=True)
                    os.makedirs(fs, exist_ok=True)
                    fs_abs = os.path.abspath(fs)
                    made: set[str] = set()
                    done_n = 0
                    last_pct = -1
                    for m in members:
                        rel = os.path.relpath(m.filename, "filestore")
                        target = os.path.normpath(os.path.join(fs, rel))
                        if target != fs_abs and not target.startswith(fs_abs + os.sep):
                            continue  # 防 zip 路径穿越(带分隔符比较,否则 filestore_x 这类同前缀兄弟目录也会放行)
                        d = os.path.dirname(target)
                        if d not in made:
                            os.makedirs(d, exist_ok=True)
                            made.add(d)
                        with zf.open(m) as s_, open(target, "wb") as d_:
                            shutil.copyfileobj(s_, d_, 1024 * 1024)
                        done_n += 1
                        pct = int(done_n * 100 / len(members)) if members else 100
                        if pct != last_pct and pct % 10 == 0:
                            last_pct = pct
                            say(f"还原 filestore {pct}%")
                _chown_tree(os.path.dirname(fs), env_odoo_uid(e))
            elif not os.path.isdir(fs):
                os.makedirs(fs, exist_ok=True)
                _chown_tree(os.path.dirname(fs), env_odoo_uid(e))

            # 5. 中性化(官方 odoo neutralize 优先,内置 SQL 兜底;两条路径都会换掉 database.uuid)
            if neutralize:
                prog(env_id, 85, "中性化")
                from .project import neutralize_db

                neutralize_db(pg, e, say, t)

            # 6. 启动容器
            if odoo_container and not database_id:
                say(f"启动容器 {e.container_name}")
                prog(env_id, 90, "启动容器")
                odoo_container.start()
                if _wait_http(odoo_container):
                    say("Odoo 已就绪")
                else:
                    say("Odoo 启动后未在预期时间内响应,请查看容器日志")
            ok = True
            _finish_job(job_id, True, "恢复完成" + (f"({n_errors} 条 SQL 错误,已通过完整性探测)" if n_errors else ""))
    except Exception as ex:  # noqa: BLE001
        log.exception("restore #%s failed", job_id)
        say(f"失败: {ex}")
        if odoo_container and was_running and not database_id:
            try:
                odoo_container.start()
            except Exception as ex2:  # noqa: BLE001
                log.warning("恢复失败后重启容器出错: %s", ex2)
        _finish_job(job_id, False, str(ex))
    finally:
        if pgc_path and pg is not None:
            try:
                pg.exec_run(["rm", "-f", pgc_path])
            except Exception:  # noqa: BLE001
                pass
        if manage_env_status:
            _restore_finalize_status(env_id, odoo_container, prior_status if not ok else "running")
        unlock(env_id)


# ---------------------------------------------------------------- 组织级自动备份策略
def _truthy(v: str) -> bool:
    return str(v).strip().lower() in ("1", "true", "yes", "on")


def _split_kinds(v: str) -> list[str]:
    return [k.strip() for k in (v or "").split(",") if k.strip() in ("production", "staging", "dev")]


def platform_defaults() -> dict:
    """平台级默认策略(系统设置 backup.*),组织未自定义时沿用。"""
    try:
        keep = int(get_setting("backup.keep_days") or 7)
    except ValueError:
        keep = 7
    try:
        hour = int(get_setting("backup.auto_hour") or 3)
    except ValueError:
        hour = 3
    return {
        "auto_enabled": _truthy(get_setting("backup.auto_enabled")),
        "auto_hour": max(0, min(23, hour)),
        "auto_kinds": _split_kinds(get_setting("backup.auto_kinds") or "production") or ["production"],
        "keep_days": max(0, keep),
        "include_filestore": True,
        "include_extra_dbs": _truthy(get_setting("backup.auto_extra_dbs")),
    }


def get_policy(db, tenant_id: int, create: bool = False) -> TenantBackupPolicy | None:
    p = db.scalar(select(TenantBackupPolicy).where(TenantBackupPolicy.tenant_id == tenant_id))
    if p is None and create:
        p = TenantBackupPolicy(tenant_id=tenant_id, mode="inherit")
        db.add(p)
        db.commit()
        db.refresh(p)
    return p


def effective_policy(p: TenantBackupPolicy | None) -> dict:
    """合并平台默认后的实际生效值。"""
    if p is None or p.mode != "custom":
        return platform_defaults()
    return {
        "auto_enabled": bool(p.auto_enabled),
        "auto_hour": int(p.auto_hour or 0),
        "auto_kinds": _split_kinds(p.auto_kinds) or ["production"],
        "keep_days": int(p.keep_days or 0),
        "include_filestore": bool(p.include_filestore),
        "include_extra_dbs": bool(p.include_extra_dbs),
    }


def tenant_storage_dir(slug: str) -> str:
    """该组织备份所在目录(平台根目录下按组织 slug 分目录)。"""
    return os.path.join(backups_root(), slug)


def next_run_str(eff: dict, last_run_at: datetime | None) -> str | None:
    if not eff["auto_enabled"]:
        return None
    now = datetime.now()
    nxt = now.replace(hour=eff["auto_hour"], minute=0, second=0, microsecond=0)
    ran_today = bool(last_run_at) and last_run_at.astimezone().date() == now.date()
    if nxt <= now or ran_today:
        nxt += timedelta(days=1)
    return nxt.strftime("%Y-%m-%d %H:%M")


def policy_status(db, tenant_id: int) -> dict:
    """给统计接口用:某组织的自动备份状态。"""
    p = get_policy(db, tenant_id)
    eff = effective_policy(p)
    return {
        "scheduler_enabled": eff["auto_enabled"],
        "next_run": next_run_str(eff, p.last_run_at if p else None),
        "last_run": p.last_run_at.astimezone().strftime("%Y-%m-%d %H:%M") if p and p.last_run_at else None,
        "policy_mode": p.mode if p else "inherit",
    }


def scheduler_status() -> dict:
    """平台视角(超管未选组织时):显示平台默认策略。"""
    eff = platform_defaults()
    return {
        "scheduler_enabled": eff["auto_enabled"],
        "next_run": next_run_str(eff, None),
        "last_run": None,
        "policy_mode": None,
    }


def env_effective_policy(c, tenant_eff: dict) -> dict:
    """实例级生效策略:实例配置 custom → 用实例自己的;off → 关闭;inherit / 无配置 → 组织生效策略。"""
    if c is None or c.auto_mode == "inherit":
        return dict(tenant_eff, source="tenant")
    if c.auto_mode == "off":
        return dict(tenant_eff, auto_enabled=False, source="env")
    return {
        "auto_enabled": True, "auto_hour": int(c.auto_hour or 0), "auto_kinds": ["production", "staging", "dev"],
        "keep_days": int(c.keep_days or 0), "include_filestore": bool(c.include_filestore), "include_extra_dbs": bool(c.include_extra_dbs),
        "source": "env",
    }


def run_auto_backups(tenant_id: int | None = None, who: str = "scheduler", tenant_ids: list[int] | None = None,
                     env_id: int | None = None) -> int:
    """按各组织生效策略,给符合类型的已创建实例各发起一次自动备份;返回发起数量。

    tenant_id / tenant_ids 指定时只处理这些组织(不判断开关与时刻,即「立即执行」);
    否则处理所有已启用自动备份、且当前小时匹配、今天尚未跑过的组织。
    """
    from ..models_backup import EnvironmentBackupConfig
    from . import databases as dbsvc

    n = 0
    now = datetime.now()
    manual = tenant_id is not None or tenant_ids is not None or env_id is not None
    wanted = set(tenant_ids or []) | ({tenant_id} if tenant_id is not None else set())
    with SessionLocal() as db:
        if env_id is not None:  # 「立即备份本实例」:只跑这一个实例,按实例级生效策略
            e0 = db.get(Environment, env_id)
            if not e0:
                return 0
            wanted = {e0.tenant_id}
        q = select(Tenant).where(Tenant.is_active.is_(True)).order_by(Tenant.id)
        if manual:
            q = q.where(Tenant.id.in_(wanted or {-1}))
        tenants = db.scalars(q).all()
        # 实例级配置(custom / off 覆盖组织策略)一次读出
        env_cfgs = {c.environment_id: c for c in db.scalars(select(EnvironmentBackupConfig).where(EnvironmentBackupConfig.auto_mode != "inherit")).all()}
        if not manual:
            # 定时路径:平台默认 / 组织自定义 / 实例自定义都没在这个小时 → 直接返回(不逐组织写策略行)
            defaults = platform_defaults()
            customs = db.scalars(select(TenantBackupPolicy).where(TenantBackupPolicy.mode == "custom")).all()
            due_default = defaults["auto_enabled"] and defaults["auto_hour"] == now.hour
            due_custom = any(c.auto_enabled and int(c.auto_hour or 0) == now.hour for c in customs)
            due_env = any(c.auto_mode == "custom" and int(c.auto_hour or 0) == now.hour for c in env_cfgs.values())
            if not due_default and not due_custom and not due_env:
                return 0
        for t in tenants:
            p = get_policy(db, t.id, create=True)
            teff = effective_policy(p)
            tenant_due = True
            if not manual:
                tenant_due = bool(teff["auto_enabled"] and now.hour == teff["auto_hour"]
                                  and not (p.last_run_at and p.last_run_at.astimezone().date() == now.date()))
                if tenant_due:
                    p.last_run_at = datetime.now(timezone.utc)  # 仅定时触发时记录,「立即执行」不影响当天计划
                    db.commit()
            q = select(Environment).where(Environment.tenant_id == t.id, Environment.db_name.is_not(None), Environment.deleted_at.is_(None))
            if env_id is not None:
                q = q.where(Environment.id == env_id)
            envs = db.scalars(q).all()
            ran_tenant = False
            for e in envs:
                c = env_cfgs.get(e.id)
                eff = env_effective_policy(c, teff)
                if eff["source"] == "tenant":
                    # 沿用组织策略:组织本轮到点(或手动)且实例类型在策略范围内
                    if not (manual or tenant_due) or e.kind not in eff["auto_kinds"] or not eff["auto_enabled"]:
                        continue
                    ran_tenant = True
                else:
                    if not eff["auto_enabled"]:
                        continue  # 实例级关闭
                    if not manual:
                        if now.hour != eff["auto_hour"]:
                            continue
                        if c.last_run_at and c.last_run_at.astimezone().date() == now.date():
                            continue
                        c.last_run_at = datetime.now(timezone.utc)
                        db.commit()
                if e.status in ("provisioning", "destroying"):
                    continue
                if not try_lock(e.id):
                    # 上一次备份 / 恢复还没结束(超长备份跨天):以前静默跳过,连日志都没有
                    log.warning("自动备份跳过实例 #%s %s/%s:上一个备份或恢复任务仍在进行", e.id, t.slug, e.name)
                    continue
                try:
                    # 主库 + (策略开启时)附加库:同一实例的多个库串行跑在一个线程里(共用实例锁,末尾统一释放)
                    targets = dbsvc.all_views(db, e) if eff.get("include_extra_dbs") else [dbsvc.EnvDb(e)]
                    ids = [new_backup_record(db, v, t, "auto", "每日自动备份", eff["include_filestore"], who).id for v in targets]
                    _dispatch_backup(ids, e.id)  # 有界工作池派发(线程数 = backup.max_concurrent),避免大规模下每实例一线程
                    n += len(ids)
                except Exception:  # 单个实例出错(建记录 / 起线程失败)不影响其余实例的自动备份
                    unlock(e.id)  # 释放锁,否则该实例直到重启都不能再备份 / 恢复
                    log.exception("自动备份实例 #%s %s/%s 失败,跳过", e.id, t.slug, e.name)
                if eff["source"] == "env" and eff["keep_days"]:
                    prune_old_backups(t.id, eff["keep_days"], env_id=e.id)
            if env_id is None and (ran_tenant or manual):  # 单实例「立即备份」不触发整组织清理(只按实例保留天数清自己)
                prune_old_backups(t.id, teff["keep_days"])
    return n


# 自动备份派发:固定大小工作池(线程数 = backup.max_concurrent),避免「每实例一线程」在大量实例时 spawn 成百上千个阻塞线程。
# 真正的备份并发仍由 run_backup 内的 _concurrency_gate 信号量控制;这里只是把「同时存在的派发线程数」封顶。
_dispatch_q: "queue.Queue" = queue.Queue()
_dispatch_started = False
_dispatch_lock = threading.Lock()


def _ensure_dispatchers() -> None:
    global _dispatch_started
    with _dispatch_lock:
        if _dispatch_started:
            return
        _dispatch_started = True
        for i in range(max(1, _int_setting("backup.max_concurrent", 2) or 2)):
            threading.Thread(target=_dispatch_loop, daemon=True, name=f"auto-backup-{i}").start()


def _dispatch_loop() -> None:
    while True:
        ids, env_id = _dispatch_q.get()
        try:
            _run_backups_serial(ids, env_id)
        except Exception:  # noqa: BLE001  (run_backup 内部已 unlock;此处兜底再解锁,unlock 幂等)
            log.exception("自动备份派发执行失败 env#%s", env_id)
            unlock(env_id)
        finally:
            _dispatch_q.task_done()


def _dispatch_backup(backup_ids: list[int], env_id: int) -> None:
    """把一个实例的自动备份(主库 + 附加库串行)排入有界工作队列。调用方须已 try_lock(env_id)。"""
    _ensure_dispatchers()
    _dispatch_q.put((backup_ids, env_id))


def _run_backups_serial(backup_ids: list[int], env_id: int) -> None:
    """同一实例的多个库(主库 + 附加库)依次备份;实例锁在最后一个结束时释放(run_backup 内部会 unlock,前面的先重新占住)。"""
    for i, bid in enumerate(backup_ids):
        if i > 0 and not try_lock(env_id):
            _set_backup(bid, status="failed", message="实例锁被占用,跳过", finished_at=datetime.now(timezone.utc))
            continue
        run_backup(bid, env_id)


def prune_old_backups(tenant_id: int | None = None, keep_days: int | None = None, env_id: int | None = None) -> int:
    """删除超过保留天数的自动/恢复前备份;手动/上传备份按 backup.keep_days_manual(0 = 永久);
    最后按 backup.quota_mb 把每个组织的总量压到配额内。

    tenant_id 为空时按各组织自己的生效策略逐一清理。env_id 给定时只清理该实例(实例级自定义保留天数);
    组织级清理会跳过有实例级自定义保留天数的实例(它们按自己的来)。
    """
    from ..models_backup import EnvironmentBackupConfig

    n = 0
    keep_manual = _int_setting("backup.keep_days_manual", 0)
    with SessionLocal() as db:
        if tenant_id is None:
            targets = [(t.id, effective_policy(get_policy(db, t.id))["keep_days"]) for t in db.scalars(select(Tenant)).all()]
        else:
            if keep_days is None:
                keep_days = effective_policy(get_policy(db, tenant_id))["keep_days"]
            targets = [(tenant_id, keep_days)]
        busy = in_use_backup_ids(db)
        custom_envs = set()
        if env_id is None:
            custom_envs = set(db.scalars(select(EnvironmentBackupConfig.environment_id).where(
                EnvironmentBackupConfig.auto_mode == "custom", EnvironmentBackupConfig.keep_days > 0)).all())
        for tid, keep in targets:
            for kinds, days in ((("auto", "pre_restore"), keep), (("manual", "upload"), keep_manual)):
                if days <= 0:
                    continue
                cutoff = datetime.now(timezone.utc) - timedelta(days=days)
                q = select(Backup).where(
                    Backup.tenant_id == tid,
                    Backup.kind.in_(kinds),
                    Backup.status != "running",
                    Backup.id.not_in(busy or {-1}),
                    Backup.created_at < cutoff,
                )
                if env_id is not None:
                    q = q.where(Backup.environment_id == env_id)
                elif custom_envs and kinds[0] == "auto":
                    q = q.where((Backup.environment_id.is_(None)) | (Backup.environment_id.not_in(custom_envs)))
                old = db.scalars(q).all()
                for b in old:
                    try:
                        delete_backup_file(b)
                    except OSError:
                        pass
                    db.delete(b)
                    n += 1
            db.commit()
            n += enforce_quota(db, tid)
        db.commit()
    if n:
        log.info("已清理 %s 个过期自动备份", n)
    return n


def recover_stuck_on_startup() -> int:
    """平台重启时,把停留在 running 的备份 / 恢复任务标记为失败(线程随进程消失,不会再回来更新)。
    以前这些行永远 running:不能删、不进保留期、不计配额,对应实例的锁也拿不到 → 每天自动备份静默跳过。"""
    now = datetime.now(timezone.utc)
    n = 0
    with SessionLocal() as db:
        for b in db.scalars(select(Backup).where(Backup.status == "running")).all():
            b.status, b.message, b.finished_at = "failed", "被平台重启打断", now
            n += 1
        for j in db.scalars(select(RestoreJob).where(RestoreJob.status == "running")).all():
            j.status, j.message, j.finished_at = "failed", "被平台重启打断(数据库可能不完整,请重新恢复)", now
            n += 1
        db.commit()
    if n:
        log.info("已把 %s 个被重启打断的备份/恢复任务标记为失败", n)
    return n


def running_backup_ids() -> set[int]:
    with SessionLocal() as db:
        return {bid for (bid,) in db.execute(select(Backup.id).where(Backup.status == "running")).all()}


_sched_state = {"thread": None, "stop": False}


def _scheduler_loop() -> None:
    i = 0
    while not _sched_state["stop"]:
        try:
            n = run_auto_backups()
            if n:
                log.info("自动备份已发起 %s 个实例", n)
        except Exception:  # noqa: BLE001
            log.exception("backup scheduler error")
        i += 1
        if i % 10 == 0:  # 每 10 分钟:重试未成功推送的异地副本
            try:
                from . import replica

                k = replica.retry_pending()
                if k:
                    log.info("重试推送 %s 个备份的异地副本", k)
            except Exception:  # noqa: BLE001
                log.exception("replica retry error")
            try:
                from . import remote

                k = remote.retry_pending()
                if k:
                    log.info("重试推送 %s 个备份到用户远程目标", k)
            except Exception:  # noqa: BLE001
                log.exception("remote retry error")
        if i % 60 == 0:  # 每小时:按目标保留天数清理远端过期副本
            try:
                from . import remote

                k = remote.prune_remote()
                if k:
                    log.info("清理远端过期副本 %s 个", k)
            except Exception:  # noqa: BLE001
                log.exception("remote prune error")
        time.sleep(60)


def start_scheduler() -> None:
    if _sched_state["thread"] is None:
        th = threading.Thread(target=_scheduler_loop, daemon=True, name="backup-scheduler")
        _sched_state["thread"] = th
        th.start()
