"""备份异地副本:备份完成后异步推送到 S3 兼容对象存储(MinIO / 阿里云 OSS / 腾讯云 COS / AWS S3 …)。

为什么:备份文件和实例数据在同一块盘 / 同一台机上,磁盘或主机级故障时会一起丢,备份就失去了意义。
做什么:
  - push(backup_id):单次流式读本地 zip,同时算 sha256 并 multipart 上传(不额外读第二遍);成功后记 replica_status=done
  - delete(b):本地删除备份(过期 / 配额 / 手动 / 删组织)时顺手删远端对象(best effort)
  - pull(b):本地文件丢失时(比如换盘后)从远端拉回并校验 sha256,恢复流程自动调用
  - retry_pending():调度线程定期重试 pending / failed 的推送(网络抖动、对象存储临时不可用)
设置(系统设置 backup.replica_*):enabled / endpoint / bucket / region / access_key / secret / prefix
不做:加密(用对象存储自身的服务端加密)、跨云多副本、独立的副本保留期(与本地一致:本地删远端也删)。
"""

import hashlib
import logging
import os
import threading
import time
from datetime import datetime, timezone

from sqlalchemy import select

from ..db import SessionLocal
from ..models_backup import Backup

log = logging.getLogger("odoosh.replica")

_lock = threading.Lock()
_inflight: set[int] = set()


def _cfg() -> dict:
    from .backup import get_setting

    return {
        "enabled": str(get_setting("backup.replica_enabled") or "0").strip().lower() in ("1", "true", "yes", "on"),
        "endpoint": (get_setting("backup.replica_endpoint") or "").strip(),
        "bucket": (get_setting("backup.replica_bucket") or "").strip(),
        "region": (get_setting("backup.replica_region") or "").strip() or None,
        "access_key": (get_setting("backup.replica_access_key") or "").strip(),
        "secret": get_setting("backup.replica_secret") or "",
        "prefix": (get_setting("backup.replica_prefix") or "odoosh/").strip().lstrip("/"),
    }


def enabled() -> bool:
    c = _cfg()
    return bool(c["enabled"] and c["bucket"] and c["access_key"] and c["secret"])


def _client(c: dict | None = None):
    import boto3
    from botocore.config import Config

    c = c or _cfg()
    kw = {
        "aws_access_key_id": c["access_key"],
        "aws_secret_access_key": c["secret"],
        "config": Config(signature_version="s3v4", s3={"addressing_style": "path"}, retries={"max_attempts": 3}, connect_timeout=15, read_timeout=120),
    }
    if c["endpoint"]:
        kw["endpoint_url"] = c["endpoint"]
    if c["region"]:
        kw["region_name"] = c["region"]
    return boto3.client("s3", **kw)


def object_key(b: Backup, prefix: str | None = None) -> str:
    p = prefix if prefix is not None else _cfg()["prefix"]
    return f"{p}{b.filename}" if p else (b.filename or "")


class _HashingReader:
    """只支持顺序 read 的文件包装:边读边算 sha256。不提供 seek/tell → boto3 按非可寻址流处理,顺序分片上传。"""

    def __init__(self, path: str):
        self.f = open(path, "rb")
        self.h = hashlib.sha256()
        self.n = 0

    def read(self, size: int = -1) -> bytes:
        data = self.f.read(size)
        if data:
            self.h.update(data)
            self.n += len(data)
        return data

    def close(self) -> None:
        self.f.close()


def _set(bid: int, **fields) -> None:
    with SessionLocal() as db:
        b = db.get(Backup, bid)
        if b:
            for k, v in fields.items():
                setattr(b, k, v)
            db.commit()


def push(backup_id: int) -> bool:
    """推送一个已完成的备份到对象存储。返回是否成功。同一备份不会并发推两次。"""
    with _lock:
        if backup_id in _inflight:
            return False
        _inflight.add(backup_id)
    try:
        c = _cfg()
        if not enabled():
            return False
        with SessionLocal() as db:
            b = db.get(Backup, backup_id)
            if not b or b.status != "done" or not b.filename:
                return False
            from .backup import backup_path

            path = backup_path(b)
            key = object_key(b, c["prefix"])
            size = b.size_bytes
        if not path or not os.path.isfile(path):
            _set(backup_id, replica_status="failed", replica_error="本地文件不存在")
            return False
        _set(backup_id, replica_status="pending", replica_error=None, replica_key=key)
        from boto3.s3.transfer import TransferConfig

        t0 = time.time()
        rd = _HashingReader(path)
        try:
            _client(c).upload_fileobj(rd, c["bucket"], key, Config=TransferConfig(multipart_chunksize=64 * 1024 * 1024, max_concurrency=2, use_threads=True))
        finally:
            rd.close()
        sha = rd.h.hexdigest()
        _set(backup_id, replica_status="done", replica_at=datetime.now(timezone.utc), replica_error=None, sha256=sha)
        log.info("备份 #%s 已推送副本 s3://%s/%s(%s MB,%ss)", backup_id, c["bucket"], key, (size or rd.n) >> 20, int(time.time() - t0))
        return True
    except Exception as ex:  # noqa: BLE001
        log.warning("备份 #%s 推送副本失败: %s", backup_id, ex)
        _set(backup_id, replica_status="failed", replica_error=str(ex)[:500])
        return False
    finally:
        with _lock:
            _inflight.discard(backup_id)


def push_async(backup_id: int) -> None:
    if not enabled():
        return
    from . import jobs

    jobs.spawn(push, backup_id)


def delete(b: Backup) -> None:
    """删远端对象(best effort;远端删不掉只记日志,不阻塞本地删除)。"""
    if not b.replica_key or b.replica_status not in ("done", "pending", "failed"):
        return
    try:
        c = _cfg()
        if not (c["bucket"] and c["access_key"] and c["secret"]):
            return
        _client(c).delete_object(Bucket=c["bucket"], Key=b.replica_key)
    except Exception as ex:  # noqa: BLE001
        log.warning("删除备份 #%s 的远端副本失败(忽略): %s", b.id, ex)


def pull(b: Backup, dest: str, say=log.info) -> None:
    """从远端拉回本地(dest),校验 sha256;失败抛异常。"""
    if b.replica_status != "done" or not b.replica_key:
        raise RuntimeError("该备份没有可用的异地副本")
    c = _cfg()
    if not (c["bucket"] and c["access_key"] and c["secret"]):
        raise RuntimeError("未配置异地副本存储")
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = dest + ".pulling"
    say(f"本地备份文件缺失,从异地副本拉回 s3://{c['bucket']}/{b.replica_key}({(b.size_bytes or 0) >> 20} MB)")
    t0 = time.time()
    h = hashlib.sha256()
    with open(tmp, "wb") as f:
        _client(c).download_fileobj(c["bucket"], b.replica_key, f)
    with open(tmp, "rb") as f:
        for chunk in iter(lambda: f.read(4 << 20), b""):
            h.update(chunk)
    if b.sha256 and h.hexdigest() != b.sha256:
        os.remove(tmp)
        raise RuntimeError("副本校验和不匹配,拒绝使用(远端文件可能损坏)")
    os.replace(tmp, dest)
    say(f"副本已拉回并校验通过({int(time.time() - t0)}s)")


def retry_pending(limit: int = 3) -> int:
    """重试推送失败 / 未推送的备份(调度线程每 10 分钟调一次)。返回发起数量。"""
    if not enabled():
        return 0
    with SessionLocal() as db:
        rows = db.scalars(
            select(Backup)
            .where(Backup.status == "done", Backup.filename.is_not(None), (Backup.replica_status.is_(None)) | (Backup.replica_status.in_(("failed", "pending"))))
            .order_by(Backup.id.desc())
            .limit(limit)
        ).all()
        ids = [b.id for b in rows]
    n = 0
    for bid in ids:
        with _lock:
            if bid in _inflight:
                continue
        push_async(bid)
        n += 1
    return n


def test_connection() -> dict:
    """系统设置页「测试连接」:HeadBucket + 写读删一个小对象。"""
    c = _cfg()
    if not (c["bucket"] and c["access_key"] and c["secret"]):
        return {"ok": False, "error": "请先填写 bucket / access key / secret"}
    try:
        cl = _client(c)
        cl.head_bucket(Bucket=c["bucket"])
        key = f"{c['prefix']}.odoosh-connection-test"
        cl.put_object(Bucket=c["bucket"], Key=key, Body=b"ok")
        cl.get_object(Bucket=c["bucket"], Key=key)["Body"].read()
        cl.delete_object(Bucket=c["bucket"], Key=key)
        return {"ok": True}
    except Exception as ex:  # noqa: BLE001
        return {"ok": False, "error": str(ex)[:500]}
