"""为每个环境生成 nginx server 配置,并让平台 web(nginx)容器 reload。"""

import logging
import os

from ..config import settings
from . import dockerx

log = logging.getLogger("odoosh.nginx")

# server 主体两种访问模式共用;头部按模式二选一:
#   域名分流(默认):listen 80 + server_name,靠 Host 头区分实例
#   端口直连(platform.access_mode=port):每实例一个专属端口,地址 = http://<IP>:<端口>,无需域名/备案
_HEAD_DOMAIN = """server {{
    listen 80;
{tls}    # 通配子域名 = 该实例的附加数据库(<库名>.<实例域名>),同一容器,Odoo 按 dbfilter(%d)选库
    server_name {domain} *.{domain};
"""
# 泛域名证书就绪时追加到 80 之后(同一个 server 同时听 80/443)。
# 刻意不做 HTTP → HTTPS 跳转:证书过期 / 续期失败时 80 仍可用,不至于全部实例同时不可访问。
_TLS_LINES = """    listen 443 ssl;
    http2 on;
    ssl_certificate     {crt};
    ssl_certificate_key {key};
"""
_HEAD_PORT = """server {{
{tls}"""
# 无 IP 证书时的明文监听(与 _TLS_LINES_PORT 二选一,nginx 不允许同端口既明文又 SSL)
_PLAIN_LINES_PORT = """    listen {port};
"""
# 端口直连 + 公网 IP 证书(deploy/ssl-ip.sh)就绪:该端口整体转 https。
# 证书的 SAN 是 IP,而本模式的地址就是 https://<IP>:<端口>,故浏览器完全信任、无需域名。
# error_page 497:客户端用明文 http 打这个 SSL 端口时(旧书签)跳到 https,而不是回一堆二进制乱码。
_TLS_LINES_PORT = """    listen {port} ssl;
    http2 on;
    ssl_certificate     {crt};
    ssl_certificate_key {key};
    error_page 497 https://$host:{port}$request_uri;
"""
_BODY = """    client_max_body_size 512m;
    # 单 IP 限速 / 限连接:挡脚本刷接口。注意限流键是客户端 IP —— 学校 / 企业走同一出口 NAT 时,
    # 全体成员共用一份配额,故按班级规模给足(Odoo 的 longpolling 本身就是长连接,很吃 limit_conn)。
    limit_req zone=odoo burst=500 nodelay;
    limit_conn perip 300;
    proxy_read_timeout 720s;
    proxy_connect_timeout 720s;
    proxy_send_timeout 720s;
    proxy_set_header X-Forwarded-Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header Host $host;

    # 访问日志写到共享数据目录(平台只看文件 mtime 判断实例是否闲置 → 休眠,不解析内容);
    # tick 格式每请求 1 字节 + buffer,把这项持续写盘降到可忽略;由 services.sleep 定期截断
    access_log /var/log/nginx/odoosh/{tenant_slug}--{env_name}.log {log_format} buffer=8k flush=10s;

    set $odoo_http http://{container}:8069;
    set $odoo_ws   http://{container}:{ws_port};

    # 一键登录:平台 API 在实例域名下兑换票据并种 Odoo session cookie
    location = /odoosh/sso {{
        set $odoosh_api http://api:8000;
        proxy_pass $odoosh_api/api/sso/open$is_args$args;
        proxy_redirect off;
    }}
    location /websocket {{
        proxy_pass $odoo_ws;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
    }}
    location / {{
        proxy_pass $odoo_http;
        proxy_redirect off;
    }}
    error_page 502 503 504 = @down;
    location @down {{
        # 上游不可达:交给平台判断——休眠中则自动唤醒并返回「唤醒中」页;否则返回「未就绪」页
        set $odoosh_api http://api:8000;
        limit_req zone=wake burst=50 nodelay;
        rewrite ^ /api/wake/{tenant_slug}/{env_name} break;
        proxy_pass $odoosh_api;
        proxy_intercept_errors off;
    }}
    gzip on;
    gzip_types text/css text/plain text/xml application/xml application/json application/javascript;
}}
"""

_PREFIX = "# 由 OdooshCN 自动生成 — 环境 {tenant}/{env}\n# 使用变量 + resolver,容器停止时不影响 nginx 整体 reload\n"
TEMPLATE = _PREFIX + _HEAD_DOMAIN + _BODY
PORT_TEMPLATE = _PREFIX + _HEAD_PORT + _BODY


def access_mode() -> str:
    """实例访问模式:domain(域名分流,默认)| port(每实例一个端口;未备案云服务器 / 纯内网适用)。"""
    try:
        from ..db import SessionLocal
        from ..routers.settings import get_setting

        with SessionLocal() as db:
            v = (get_setting(db, "platform.access_mode") or "domain").strip().lower()
        return "port" if v == "port" else "domain"
    except Exception:  # noqa: BLE001
        return "domain"


def port_range() -> tuple[int, int]:
    """端口直连模式的实例端口池(ODOOSH_ENV_PORT_RANGE,须与 compose 的端口映射范围一致)。"""
    try:
        lo, hi = (settings.env_port_range or "").split("-", 1)
        lo, hi = int(lo), int(hi)
        return (lo, hi) if lo <= hi else (hi, lo)
    except ValueError:
        return 10001, 10020


def access_host() -> str:
    """端口直连模式下 URL 用的主机部分:优先 auto 探测的 IP;基础域名是 <IP>.nip.io/sslip.io 时抽出 IP
    (端口模式的意义就是不带域名,别让 nip.io 留在 URL 里挨 DPI 拦截);其余(内网自定义主机名等)原样使用。"""
    import re

    if settings.host_ip:
        return settings.host_ip
    m = re.match(r"^(\d+(?:\.\d+){3})\.(?:nip|sslip)\.io$", settings.base_domain or "")
    return m.group(1) if m else (settings.base_domain or "localhost")


def ensure_port(db, e) -> int | None:
    """端口直连模式:返回实例已分配的端口,没有则从端口池取最小空闲值并落库。池耗尽返回 None(记日志)。
    回收站里的实例仍占着端口,彻底删除后释放。"""
    from sqlalchemy import select

    from ..models import Environment

    lo, hi = port_range()
    # 不信任传入对象缓存的 public_port:创建流程里 write_env_conf 用独立会话分配过端口,外层会话对象可能还是
    # 陈旧的 None——若据此重复分配,会造成「配置监听 A、URL 写 B」错位,孤儿端口 A 再被下个实例分走后
    # 两份配置 listen 同一端口,nginx -t 永久失败、后续 reload 全部无效
    cur = db.scalar(select(Environment.public_port).where(Environment.id == e.id))
    if cur and lo <= cur <= hi:
        e.public_port = cur
        return cur
    used = set(db.scalars(select(Environment.public_port).where(Environment.public_port.is_not(None))).all())
    for p in range(lo, hi + 1):
        if p not in used:
            e.public_port = p
            db.commit()
            log.info("实例 %s 分配端口 %s(端口直连模式)", e.name, p)
            return p
    log.warning("端口池 %s-%s 已用尽,实例 %s 无法分配端口(可在 .env 调大 ODOOSH_ENV_PORT_RANGE 并重建 web)", lo, hi, e.name)
    return None


def public_port_for(db, e) -> int | None:
    """当前模式下实例应使用的端口(域名模式恒为 None)。"""
    return ensure_port(db, e) if access_mode() == "port" else None


def _port_of(tenant_slug: str, env_name: str) -> int | None:
    """按 (组织, 实例名) 取端口(write_env_conf 内部用,独立会话)。"""
    if access_mode() != "port":
        return None
    from sqlalchemy import select

    from ..db import SessionLocal
    from ..models import Environment, Tenant

    with SessionLocal() as db:
        # 排除回收站(deleted_at 非空):同名实例删了重建后,回收站里会有重名记录;取最新一条保底,绝不抛 MultipleResultsFound
        e = db.scalars(
            select(Environment).join(Tenant, Tenant.id == Environment.tenant_id)
            .where(Tenant.slug == tenant_slug, Environment.name == env_name, Environment.deleted_at.is_(None))
            .order_by(Environment.id.desc())
        ).first()
        return ensure_port(db, e) if e else None


def conf_dir() -> str:
    d = os.path.join(settings.data_dir, "nginx")
    os.makedirs(d, exist_ok=True)
    return d


def conf_path(tenant_slug: str, env_name: str) -> str:
    return os.path.join(conf_dir(), f"{tenant_slug}--{env_name}.conf")


# ---------------------------------------------------------------- 泛域名证书(实例 HTTPS)
CERT_NAME = "wildcard"                # certs/wildcard.crt|.key,由 deploy/ssl-domain.sh 签发并自动续期(域名模式)
# 端口直连模式用的公网 IP 证书(deploy/ssl-ip.sh 签发,Let's Encrypt shortlived,约 6.6 天、每日自动续期)。
# 该模式下实例地址是 https://<公网IP>:<端口> —— 名字就是 IP,正好被 IP 证书覆盖,无需域名即可拿到浏览器信任的 HTTPS。
IP_CERT_NAME = "console"
NGINX_CERTS_DIR = "/etc/nginx/certs"  # web 容器内的挂载点(compose:${ODOOSH_DATA_DIR}/certs:ro)


def cert_files(name: str = CERT_NAME) -> tuple[str, str]:
    """(证书, 私钥)在 api 容器内的路径。api 挂载了整个数据目录,故可直接判断文件在不在。
    name:CERT_NAME(域名模式的泛证书)或 IP_CERT_NAME(端口直连模式的公网 IP 证书)。"""
    d = os.path.join(settings.data_dir, "certs")
    return os.path.join(d, f"{name}.crt"), os.path.join(d, f"{name}.key")


_pem_cache: dict[str, dict] = {}  # crt 路径 -> {sig, ok, not_after};两种证书各自缓存,不互相冲刷


def _pem_sig(crt: str, key: str):
    """证书 / 私钥的 stat 指纹;文件没变就不重复解析(regenerate_all 会逐实例调用)。"""
    try:
        cs, ks = os.stat(crt), os.stat(key)
    except OSError:
        return None
    return (cs.st_mtime_ns, cs.st_size, ks.st_mtime_ns, ks.st_size)


def _pem_load(crt: str, key: str) -> dict:
    """解析证书并缓存 {ok, not_after}。ok = 证书可解析且私钥非空;not_after = 到期时间(aware datetime)。

    只缓存解析结果,**有效期由调用方每次现算**(见 https_ready):证书过期时文件并没变,
    靠 stat 指纹发现不了,必须拿 not_after 和当前时间比。"""
    ent = _pem_cache.setdefault(crt, {"sig": None, "ok": False, "not_after": None})
    sig = _pem_sig(crt, key)
    if sig is None:
        ent.update(sig=None, ok=False, not_after=None)
        return {"ok": False, "not_after": None}
    if ent["sig"] != sig:
        ok, exp = False, None
        try:
            from datetime import timezone

            from cryptography import x509

            with open(crt, "rb") as f:
                cert = x509.load_pem_x509_certificate(f.read())
            exp = getattr(cert, "not_valid_after_utc", None)  # cryptography >= 42;旧版无时区
            if exp is None:
                exp = cert.not_valid_after.replace(tzinfo=timezone.utc)
            ok = os.path.getsize(key) > 0
        except Exception as ex:  # noqa: BLE001
            log.warning("证书 %s 无法解析,暂不启用 HTTPS(仍走明文): %s", crt, ex)
        ent.update(sig=sig, ok=ok, not_after=exp)
    return {"ok": ent["ok"], "not_after": ent["not_after"]}


def _pem_usable(crt: str, key: str) -> bool:
    """证书与私钥都在,且证书确实能解析(**不看有效期**:过期证书对 nginx 仍是合法配置)。

    损坏的证书必须当作「没有证书」:写进配置后 nginx -t 失败 → reload 不生效(旧配置还在跑,尚可容忍),
    但只要 web 容器此后重启一次,nginx 就根本起不来 —— 所有实例一起挂。宁可降级成纯 80。"""
    return _pem_load(crt, key)["ok"]


def tls_enabled() -> bool:
    """HTTPS 总开关(系统设置 platform.tls_enabled);读不到按开启处理。"""
    try:
        from ..db import SessionLocal
        from ..routers.settings import get_setting

        with SessionLocal() as db:
            return (get_setting(db, "platform.tls_enabled") or "1") == "1"
    except Exception as ex:  # noqa: BLE001
        log.debug("读取 platform.tls_enabled 失败(按开启处理): %s", ex)
        return True


def tls_ready(name: str = CERT_NAME) -> bool:
    """该证书能否写进 nginx 配置:总开关未关 + 证书与私钥存在且可解析(**不看有效期**)。

    证书不可用时**绝不能**把 ssl_certificate 写进配置 —— 所有实例共用一个 nginx,
    一处配置坏掉会连累全部实例,而不只是没有 HTTPS。"""
    return tls_enabled() and _pem_usable(*cert_files(name))


def ip_tls_ready() -> bool:
    """端口直连模式:公网 IP 证书(ssl-ip.sh 的 console.crt)可用。"""
    return tls_ready(IP_CERT_NAME)


def _cert_name_for_mode() -> str:
    """当前访问模式该用哪张证书:端口直连 → IP 证书;域名分流 → 泛域名证书。"""
    return IP_CERT_NAME if access_mode() == "port" else CERT_NAME


def _tls_block() -> str:
    """域名模式:证书就绪时让实例在 80 之外再听 443。"""
    if not tls_ready():
        return ""
    return _TLS_LINES.format(crt=f"{NGINX_CERTS_DIR}/{CERT_NAME}.crt", key=f"{NGINX_CERTS_DIR}/{CERT_NAME}.key")


def _port_listen_block(port: int) -> str:
    """端口直连模式的监听行:有可用 IP 证书 → SSL;否则明文。"""
    return _tls_block_port(port) or _PLAIN_LINES_PORT.format(port=port)


def _tls_block_port(port: int) -> str:
    """端口直连模式:IP 证书就绪时把实例端口改成 SSL。

    与域名模式不同,这里**不能**同端口既明文又 SSL(nginx 不允许 `listen N;` 与 `listen N ssl;` 并存),
    所以该端口整体转 https;再用 error_page 497 把误用明文 http 打进来的请求跳到 https,避免用户看到乱码。

    判据用 cert_valid(**看有效期**)而非 ip_tls_ready,与域名模式刻意不同:
    域名模式下 80 / 443 是两个端口,证书过期时 80 还在,保留 443 无妨;
    端口模式每个实例只有一个端口,证书一过期若仍监听 SSL,URL 退回的 http 请求会被 497 又跳回 https
    → 撞证书错误,兜底彻底失效。故这里必须随有效期一起回落明文。"""
    if not cert_valid(IP_CERT_NAME):
        return ""
    return _TLS_LINES_PORT.format(port=port, crt=f"{NGINX_CERTS_DIR}/{IP_CERT_NAME}.crt",
                                  key=f"{NGINX_CERTS_DIR}/{IP_CERT_NAME}.key")


def _is_ip(host: str) -> bool:
    """access_host 是否为 IP 字面量。IP 证书的 SAN 是 IP,只有用 IP 访问才匹配;
    若管理员把 access_host 配成了内网主机名,给 https 只会撞证书不匹配,故必须判一下。"""
    import ipaddress

    try:
        ipaddress.ip_address((host or "").strip())
        return True
    except ValueError:
        return False


def cert_valid(name: str) -> bool:
    """证书可解析**且在有效期内**。过期检测不能靠文件指纹(过期时文件没变),必须现算。"""
    if not tls_ready(name):
        return False
    exp = _pem_load(*cert_files(name))["not_after"]
    if exp is None:
        return False
    from datetime import datetime, timezone

    return exp > datetime.now(timezone.utc)


def https_ready() -> bool:
    """**实例 URL 能否用 https**(与 tls_ready 分工不同,别混用):

    - tls_ready:配置层——证书可解析就让 nginx 监听 TLS。过期证书对 nginx 仍是合法配置。
    - https_ready:链接层——只有证书**确实在有效期内**才把用户往 https 送。

    按访问模式取对应证书:端口直连用公网 IP 证书(https://<IP>:<端口>),域名分流用泛域名证书。
    续期失败导致证书过期时本函数转 False → 平台生成的实例地址自动退回 http,
    巡检线程同时把 nginx 配置改回明文,用户无感继续用;续期恢复后自动切回 https。"""
    return cert_valid(_cert_name_for_mode())


# 剩余天数低于此值时系统页标红:一张泛证书服务所有实例,过期 = 全部实例同时报证书错误
CERT_WARN_DAYS = 20


def cert_status() -> dict:
    """泛域名证书状态(系统页展示)。acme.sh 的 cron 正常时永远不会过期,
    但 DNS API key 失效 / cron 没跑 / 换过服务器都会让续期静默失败,所以要能一眼看到剩余天数。"""
    from datetime import datetime, timezone

    crt, key = cert_files()
    st: dict = {"enabled": True, "present": os.path.isfile(crt) and os.path.isfile(key),
                "not_after": None, "days_left": None, "domains": [], "warn": False, "error": None,
                "renewed_at": None}
    try:
        from ..db import SessionLocal
        from ..routers.settings import get_setting

        with SessionLocal() as db:
            st["enabled"] = (get_setting(db, "platform.tls_enabled") or "1") == "1"
    except Exception as ex:  # noqa: BLE001
        log.debug("读取 platform.tls_enabled 失败: %s", ex)
    if not st["present"]:
        return st
    try:
        # 证书文件的 mtime = acme.sh 上次续期并安装的时间(--reloadcmd 会重写这两个文件)
        st["renewed_at"] = datetime.fromtimestamp(os.path.getmtime(crt), tz=timezone.utc).isoformat()
    except OSError as ex:
        log.debug("读取证书 mtime 失败: %s", ex)
    try:
        from cryptography import x509

        with open(crt, "rb") as f:
            cert = x509.load_pem_x509_certificate(f.read())
        exp = getattr(cert, "not_valid_after_utc", None)  # cryptography >= 42;旧版是无时区的 not_valid_after
        if exp is None:
            exp = cert.not_valid_after.replace(tzinfo=timezone.utc)
        st["not_after"] = exp.isoformat()
        st["days_left"] = int((exp - datetime.now(timezone.utc)).total_seconds() // 86400)
        st["warn"] = st["days_left"] < CERT_WARN_DAYS
        try:
            san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
            st["domains"] = san.get_values_for_type(x509.DNSName)
        except x509.ExtensionNotFound:
            pass
    except Exception as ex:  # noqa: BLE001
        st["error"] = str(ex)[:200]
        st["warn"] = True
    return st


def env_domain(tenant_slug: str, env_name: str) -> str:
    """实例域名:<实例>-<组织>.<基础域名>。

    刻意只占**一级**子域(用 - 而非 . 连接实例与组织):泛域名证书 *.<基础域名> 只匹配一级,
    两级(<实例>.<组织>.<基础域名>)就得每组织/每实例单独签证书,会撞 Let's Encrypt 的签发频率限制。
    扁平化后一张泛证书覆盖全部实例,新建实例无需任何证书操作。

    注意:拼接可能撞车(实例 a-b @ 组织 c 与 实例 a @ 组织 b-c 都得到 a-b-c),
    nginx 对重复 server_name 只 warn 并忽略后者 —— 一个实例会静默不可达、且其域名指向别人的实例。
    因此**取自动域名一律走 unique_env_domain(),不要直接用本函数**。"""
    return f"{env_name}-{tenant_slug}.{settings.base_domain}"


def auto_domain_prefixes(env_name: str, tenant_slug: str, env_id: int | None = None) -> tuple[str, ...]:
    """「这个域名是平台自动生成的」的判据(用于基础域名变更时跟着更新;超管自定义域名则保持不变)。
    含三种:扁平、撞车时带实例 id 的扁平、以及旧的两级格式(存量实例一次性迁移)。"""
    pfx = [f"{env_name}-{tenant_slug}.", f"{env_name}.{tenant_slug}."]
    if env_id is not None:
        pfx.insert(1, f"{env_name}-{tenant_slug}-{env_id}.")
    return tuple(pfx)


def unique_env_domain(db, e, tenant_slug: str, taken: set[str] | None = None) -> str:
    """自动域名 + 唯一性兜底。撞车时退化为 <实例>-<组织>-<实例id>,仍只占一级子域,泛证书照样覆盖。
    taken:同一批重写中已分配的域名(库里还没 commit,单靠查询看不到)。"""
    from sqlalchemy import select

    from ..models import Environment

    want = env_domain(tenant_slug, e.name)
    dup = (taken is not None and want in taken) or db.scalar(
        select(Environment.id).where(Environment.domain == want, Environment.id != e.id,
                                     Environment.deleted_at.is_(None)).limit(1)
    )
    if dup:
        want = f"{e.name}-{tenant_slug}-{e.id}.{settings.base_domain}"
        log.warning("实例 %s/%s 的自动域名与既有实例冲突,改用带 id 的域名 %s", tenant_slug, e.name, want)
    if taken is not None:
        taken.add(want)
    return want


def env_url(domain: str, public_port: int | None = None, secure: bool | None = None) -> str:
    """实例访问地址(控制台「打开实例」按钮、通知里的链接都用它)。

    public_port 非空 = 端口直连模式(http[s]://<公网IP>:<端口>):用公网 IP 证书(ssl-ip.sh),
           它的 SAN 就是这个 IP,故无需域名也能拿到浏览器信任的 HTTPS;证书失效则退回 http。
    secure:None = 按 https_ready() 自动判定(证书有效才用 https,过期/损坏/缺失自动退回 http);
           显式 False 用于**附加数据库**——它的域名 <库>.<实例>-<组织>.<基础域名> 比实例深一级,
           而泛证书 *.<基础域名> 只匹配一级,走 https 必然撞「证书域名不匹配」告警,故恒 http。"""
    if public_port:
        # IP 证书只对「用 IP 访问」有效;access_host 若被配成域名(自定义主机名)就不能用它
        ip_https = secure is not False and cert_valid(IP_CERT_NAME) and _is_ip(access_host())
        return f"{'https' if ip_https else 'http'}://{access_host()}:{public_port}"
    if secure is None:
        secure = https_ready()
    if secure:
        port = "" if settings.https_port == 443 else f":{settings.https_port}"
        return f"https://{domain}{port}"
    port = "" if settings.http_port == 80 else f":{settings.http_port}"
    return f"http://{domain}{port}"


_tick_cache: tuple[float, bool] | None = None


def access_log_format() -> str:
    """web 容器的 nginx 主配置定义了 `tick` 格式时用它,否则回退 combined(平台 api 先于 web 升级的过渡期不致 nginx -t 失败)。"""
    global _tick_cache
    import time

    if _tick_cache and time.time() - _tick_cache[0] < 300:
        return "tick" if _tick_cache[1] else "combined"
    ok = False
    try:
        web = dockerx.find_platform_container("web")
        if web and web.status == "running":
            code, _ = web.exec_run(["grep", "-q", "log_format  tick", "/etc/nginx/nginx.conf"])
            ok = code == 0
    except Exception as ex:  # noqa: BLE001
        log.debug("探测 nginx tick 日志格式失败: %s", ex)
    _tick_cache = (time.time(), ok)
    return "tick" if ok else "combined"


def write_env_conf(tenant_slug: str, env_name: str, container: str, domain: str, ws_port: int = 8069) -> str:
    """workers=0(线程模式)时 websocket 与 http 同端口 8069;多 worker 模式时改为 8072。"""
    import re

    # 防 nginx 配置注入:所有插入模板的值只允许 [a-z0-9.-_]
    for v in (tenant_slug, env_name, container, domain):
        if not re.match(r"^[A-Za-z0-9._-]+$", v or ""):
            raise ValueError(f"非法的 nginx 配置值: {v!r}")
    p = conf_path(tenant_slug, env_name)
    port = _port_of(tenant_slug, env_name)  # 端口直连模式下自动分配/复用;域名模式为 None
    tpl = PORT_TEMPLATE if port else TEMPLATE
    with open(p, "w", encoding="utf-8") as f:
        f.write(
            tpl.format(
                tenant=tenant_slug.replace("-", "_"),
                env=env_name.replace("-", "_"),
                tenant_slug=tenant_slug,
                env_name=env_name,
                container=container,
                domain=domain,
                port=port,
                ws_port=ws_port,
                # 端口模式:监听行(SSL 或明文)整块由 _port_listen_block 决定;域名模式:80 之外可选追加 443
                tls=_port_listen_block(port) if port else _tls_block(),
                log_format=access_log_format(),
            )
        )
    return p


def remove_env_conf(tenant_slug: str, env_name: str) -> None:
    p = conf_path(tenant_slug, env_name)
    if os.path.exists(p):
        os.remove(p)


def connect_web_to_network(network_name: str) -> None:
    web = dockerx.find_platform_container("web")
    if not web:
        log.warning("找不到平台 web 容器,跳过网络接入")
        return
    net = dockerx.get_network(network_name)
    if not net:
        return
    net.reload()
    if web.id not in [c.id for c in net.containers]:
        net.connect(web)


def disconnect_web_from_network(network_name: str) -> None:
    web = dockerx.find_platform_container("web")
    net = dockerx.get_network(network_name)
    if web and net:
        try:
            net.disconnect(web, force=True)
        except Exception as ex:  # noqa: BLE001
            log.warning("web 容器断开网络 %s 失败: %s", network_name, ex)


def reconcile_networks() -> int:
    """对账:确保平台 web(nginx)容器接入了所有实例的网络。

    web 容器在平台升级/重建后会丢失动态接入的网络,导致 nginx 解析不到实例容器名而返回 503。
    返回本次新接入的网络数。
    """
    from ..db import SessionLocal
    from ..models import Environment
    from sqlalchemy import select

    web = dockerx.find_platform_container("web")
    if not web:
        return 0
    web.reload()
    attached = set(web.attrs.get("NetworkSettings", {}).get("Networks", {}).keys())
    with SessionLocal() as db:
        names = [n for (n,) in db.execute(select(Environment.network_name).where(Environment.network_name.is_not(None))).all()]
    added = 0
    for name in names:
        if name in attached:
            continue
        net = dockerx.get_network(name)
        if not net:
            continue
        try:
            net.connect(web)
            added += 1
            log.info("web 容器接入实例网络 %s", name)
        except Exception as e:  # noqa: BLE001
            log.warning("接入网络 %s 失败: %s", name, e)
    return added


_reload_lock = None


def reload(reconcile: bool = False) -> tuple[bool, str]:
    """nginx -t && nginx -s reload。默认不做全量网络对账(巡检线程每 20s 做);调用方已显式 connect 所需网络。"""
    import threading

    global _reload_lock
    if _reload_lock is None:
        _reload_lock = threading.Lock()
    web = dockerx.find_platform_container("web")
    if not web:
        return False, "找不到平台 web 容器"
    if reconcile:
        try:
            reconcile_networks()
        except Exception as e:  # noqa: BLE001
            log.warning("网络对账失败: %s", e)
    with _reload_lock:  # 并发 reload 串行化,避免 nginx 同时收到多个 HUP
        code, out = web.exec_run("nginx -t")
        if code != 0:
            return False, out.decode(errors="ignore")
        code, out = web.exec_run("nginx -s reload")
    return code == 0, out.decode(errors="ignore")


def regenerate_all() -> int:
    """按数据库记录重写所有实例的 nginx 配置(模板升级后让旧实例也生效)。返回条数。"""
    from ..db import SessionLocal
    from ..models import Environment, Tenant
    from sqlalchemy import select

    n = 0
    mode = access_mode()
    taken: set[str] = set()  # 本批已分配的自动域名,防同批两个实例算出同一个(见 unique_env_domain)
    with SessionLocal() as db:
        # 自愈不变量:回收站实例不占端口(老数据在释放逻辑上线前进的回收站,这里统一清掉)
        from sqlalchemy import update

        db.execute(update(Environment).values(public_port=None).where(Environment.deleted_at.is_not(None), Environment.public_port.is_not(None)))
        # 排除回收站实例:它们的域名/端口已摘除,不该被重写回来(且与同名新实例共用一个 conf 文件路径,会互相覆盖)
        rows = db.execute(
            select(Environment, Tenant).join(Tenant, Tenant.id == Environment.tenant_id)
            .where(Environment.container_name.is_not(None), Environment.deleted_at.is_(None))
        ).all()
        for e, t in rows:
            try:
                # 基础域名(ODOOSH_BASE_DOMAIN)变更后,自动生成格式(<实例>-<组织>.<旧基础域名>)的域名跟着更新;
                # 超管手工指定的自定义域名(不符合该格式)保持不变。
                # 旧格式 <实例>.<组织>. 也认:一次性迁移到扁平域名(两级子域拿不到泛证书)
                is_auto = not e.domain or e.domain.startswith(auto_domain_prefixes(e.name, t.slug, e.id))
                want = unique_env_domain(db, e, t.slug, taken) if is_auto else e.domain
                if is_auto and e.domain != want:
                    log.info("实例 %s/%s 域名 %s → %s(基础域名变更)", t.slug, e.name, e.domain, want)
                    e.domain = want
                # URL 按当前访问模式重算(域名/端口切换、基础域名或平台端口变化都在这里收敛)
                want_url = env_url(e.domain, ensure_port(db, e) if mode == "port" else None)
                if e.url != want_url:
                    log.info("实例 %s/%s 地址 %s → %s", t.slug, e.name, e.url, want_url)
                    e.url = want_url
                if e.domain:
                    from .orchestrator import env_ws_port

                    write_env_conf(t.slug, e.name, e.container_name, e.domain, env_ws_port(e, t))
                    n += 1
            except Exception as ex:  # noqa: BLE001  # 单个实例出错(如端口池耗尽)不拖垮其余实例的同步
                log.warning("同步实例 %s/%s 失败(跳过): %s", t.slug, e.name, ex)
        db.commit()
    return n


def start_reconciler(interval: int = 20) -> None:
    """后台巡检线程:启动时重写配置并对账一次,之后每 interval 秒对账一次(含证书状态翻转)。"""
    import threading
    import time

    def loop():
        last_tls = last_https = None
        try:
            last_tls, last_https = tls_ready(_cert_name_for_mode()), https_ready()
            n = regenerate_all()
            log.info("已重写 %s 个实例的 nginx 配置(443=%s,链接用 https=%s)", n, last_tls, last_https)
            reload(reconcile=True)
        except Exception as e:  # noqa: BLE001
            log.warning("启动时重写 nginx 配置失败: %s", e)
        while True:
            try:
                # 证书状态翻转(续期成功/失败、证书过期、总开关切换)→ 重写全部实例配置与 URL。
                # e.url 是存库的,不重写就不会变:证书过期后必须靠这里把链接退回 http,
                # 否则控制台会一直把用户送到报证书错误的 https 页面。
                cur_tls, cur_https = tls_ready(_cert_name_for_mode()), https_ready()
                if (cur_tls, cur_https) != (last_tls, last_https):
                    log.info("证书状态变化(443:%s→%s,https 链接:%s→%s),重写全部实例配置与地址",
                             last_tls, cur_tls, last_https, cur_https)
                    last_tls, last_https = cur_tls, cur_https
                    regenerate_all()
                    ok, out = reload()
                    log.info("证书状态变化后 reload nginx: %s %s", ok, out.strip()[:120])
                n = reconcile_networks()
                if n:
                    ok, out = reload()
                    log.info("对账后 reload nginx: %s %s", ok, out.strip()[:120])
            except Exception as e:  # noqa: BLE001
                log.warning("nginx 对账巡检出错: %s", e)
            time.sleep(interval)

    threading.Thread(target=loop, name="nginx-reconciler", daemon=True).start()
