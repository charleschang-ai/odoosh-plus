"""基础镜像 odoosh-base:<版本> 的构建与查询。"""

import json
import logging
import os
import subprocess
import time

from ..config import settings
from . import dockerx, joblog

log = logging.getLogger("odoosh.images")

BASE_REPO = "odoosh-base"

# Odoo 源码地址候选:GitHub 官方优先(直连 + 国内加速代理),都不行再用 Gitee 镜像
ODOO_GITHUB = "https://github.com/odoo/odoo.git"
ODOO_SRC_CANDIDATES = [
    ("GitHub 官方", ODOO_GITHUB),
    ("GitHub 加速 ghproxy.net", "https://ghproxy.net/https://github.com/odoo/odoo.git"),
    ("GitHub 加速 gh-proxy.com", "https://gh-proxy.com/https://github.com/odoo/odoo.git"),
    ("GitHub 加速 kkgithub", "https://kkgithub.com/odoo/odoo.git"),
    ("GitHub 加速 gitmirror", "https://hub.gitmirror.com/https://github.com/odoo/odoo.git"),
    ("Gitee 镜像", "https://gitee.com/mirrors/odoo.git"),
]
PROBE_TIMEOUT = 8  # 秒;超过则视为太慢


def pick_odoo_src_url(version: str, say=log.info) -> str:
    """按顺序探测各候选源(git ls-remote 指定分支),返回第一个在限时内响应的地址。"""
    if settings.odoo_src_url and settings.odoo_src_url != "auto":
        say(f"使用配置指定的源码地址 {settings.odoo_src_url}")
        return settings.odoo_src_url
    branch = f"refs/heads/{version}.0"
    from concurrent.futures import ThreadPoolExecutor

    def probe(item):
        label, url = item
        t0 = time.time()
        try:
            r = subprocess.run(
                ["git", "ls-remote", "--heads", url, branch],
                capture_output=True, text=True, timeout=PROBE_TIMEOUT,
                env={"GIT_TERMINAL_PROMPT": "0", "PATH": os.environ.get("PATH", "")},
            )
            dt = time.time() - t0
            ok = r.returncode == 0 and branch in r.stdout
            return label, url, ok, dt, None
        except subprocess.TimeoutExpired:
            return label, url, False, float(PROBE_TIMEOUT), "超时"
        except Exception as e:  # noqa: BLE001
            return label, url, False, time.time() - t0, str(e)

    # 并行探测全部候选,取最快可用者(原先串行最坏 6×8s)
    with ThreadPoolExecutor(max_workers=len(ODOO_SRC_CANDIDATES)) as ex:
        results = list(ex.map(probe, ODOO_SRC_CANDIDATES))
    for label, url, ok, dt, err in results:
        say(f"源码地址探测:{label} {'可用' if ok else ('出错 ' + err if err else '不可用')}({dt:.1f}s)")
    good = sorted([r for r in results if r[2]], key=lambda r: r[3])
    if good:
        say(f"选用最快源:{good[0][0]} → {good[0][1]}")
        return good[0][1]
    say("所有候选都不理想,回退 Gitee 镜像")
    return "https://gitee.com/mirrors/odoo.git"


OFFICIAL_REPO = "odoo"  # Docker Hub 官方镜像 odoo:<版本>

def pull_official_image(version: str, jid: str, say=log.info) -> None:
    """拉 odoo:<version>(dockerx.pull_image:默认源失败自动换备用加速站),进度与切换过程写入 joblog。"""
    def _say(m):
        joblog.append(jid, m)
        say(m)

    dockerx.pull_image(OFFICIAL_REPO, version, say=_say, on_status=lambda st: joblog.append(jid, st))


def base_tag(version: str, mode: str = "official") -> str:
    """official → odoo:19(官方镜像,默认);custom → odoosh-base:19(源码自建)。"""
    return f"{OFFICIAL_REPO}:{version}" if mode == "official" else f"{BASE_REPO}:{version}"


def image_profile(mode: str) -> dict:
    """(兜底假设,探测失败时用)官方镜像历史上是 deb 安装(dist-packages),自建是 /opt/odoo。
    2026-08 起官方镜像新构建改成了源码布局,写死会炸——运行时请用 core_addons_for()/image_core_addons() 探测真实路径。"""
    if mode == "official":
        return {"core_addons": "/usr/lib/python3/dist-packages/odoo/addons"}
    return {"core_addons": "/opt/odoo/addons"}


_addons_cache: dict[str, str] = {}


def image_core_addons(tag: str, mode: str = "official") -> str:
    """镜像内 Odoo 核心 addons 目录:起一次性容器 import odoo 取真实路径,按镜像 id 持久化(镜像更新自动重探)。
    上游会不通知地重构镜像布局(官方 19 在 2026-08-20 从 deb 布局改成 /opt/odoo 源码布局),不能写死。"""
    if tag in _addons_cache:
        return _addons_cache[tag]
    fallback = image_profile(mode)["core_addons"]
    try:
        image_id = dockerx.client().images.get(tag).id
    except Exception:  # noqa: BLE001
        image_id = None
    key = f"images.addons.{image_id.split(':')[-1][:24]}" if image_id else None
    if key:
        try:
            from ..db import SessionLocal
            from ..models import Setting

            with SessionLocal() as db:
                row = db.get(Setting, key)
                if row and (row.value or "").startswith("/"):
                    _addons_cache[tag] = row.value
                    return row.value
        except Exception as ex:  # noqa: BLE001
            log.debug("读取 addons 路径缓存失败: %s", ex)
    # odoo.addons.__path__ 在 deb 布局(全部模块一个目录)和源码布局(base 在 odoo/addons、全量模块在顶层 addons)
    # 都可导入;源码布局要把两个目录都进 addons_path(以 web 模块在哪为判据),返回逗号拼接
    probe = (
        "import odoo.addons,os;p=list(odoo.addons.__path__)[0];out=[p];"
        "alt=os.path.join(os.path.dirname(os.path.dirname(p)),'addons');"
        "(not os.path.isdir(os.path.join(p,'web'))) and os.path.isdir(os.path.join(alt,'web')) and out.append(alt);"
        "print(','.join(out))"
    )
    try:
        out = dockerx.client().containers.run(tag, ["python3", "-c", probe], remove=True, entrypoint="")
        path = out.decode(errors="ignore").strip().splitlines()[-1]
        if not path.startswith("/"):
            raise ValueError(f"探测输出异常: {path!r}")
    except Exception as ex:  # noqa: BLE001
        log.warning("探测镜像 %s 的核心 addons 路径失败(用兜底 %s): %s", tag, fallback, ex)
        _addons_cache[tag] = fallback  # 失败值不持久化,下次(可能镜像已就绪)重探
        return fallback
    _addons_cache[tag] = path
    if key:
        try:
            from ..db import SessionLocal
            from ..models import Setting

            with SessionLocal() as db:
                row = db.get(Setting, key)
                if row:
                    row.value = path
                else:
                    db.add(Setting(key=key, value=path))
                db.commit()
        except Exception as ex:  # noqa: BLE001
            log.debug("写入 addons 路径缓存失败: %s", ex)
    log.info("镜像 %s 核心 addons 路径 = %s", tag, path)
    return path


def core_addons_for(e) -> str:
    """按环境取核心 addons 路径(环境固化的镜像 tag 优先)。"""
    mode = e.base_mode or "official"
    tag = getattr(e, "image_tag", None) or base_tag(e.odoo_version, mode)
    return image_core_addons(tag, mode)


_uid_cache: dict[str, int] = {}


def image_odoo_uid(tag: str) -> int:
    """镜像内 Odoo 运行用户的 uid(官方旧构建 100、2026-08 起新构建与自建 1000),用于 bind mount 目录 chown。

    探测要起一个容器(1~3s,且在部署/重建容器的关键路径上);结果按镜像 id 持久化到 Setting(images.uid.<id>),
    平台重启后不再重新探测,镜像更新(id 变化)才会重探。"""
    if tag in _uid_cache:
        return _uid_cache[tag]
    try:
        image_id = dockerx.client().images.get(tag).id
    except Exception:  # noqa: BLE001
        image_id = None
    key = f"images.uid.{image_id.split(':')[-1][:24]}" if image_id else None
    if key:
        try:
            from ..db import SessionLocal
            from ..models import Setting

            with SessionLocal() as db:
                row = db.get(Setting, key)
                if row and str(row.value).isdigit():
                    _uid_cache[tag] = int(row.value)
                    return _uid_cache[tag]
        except Exception as ex:  # noqa: BLE001
            log.debug("读取 uid 缓存失败: %s", ex)
    try:
        # 探测镜像「默认运行用户」的 uid(不指定 user,尊重镜像的 USER 指令)——挂载目录要 chown 给实际运行者;
        # 以前按用户名 odoo 查,镜像改用户名/布局就失效
        out = dockerx.client().containers.run(tag, ["id", "-u"], remove=True, entrypoint="")
        uid = int(out.decode().strip().splitlines()[-1])
        if uid == 0:  # 镜像以 root 兜底运行:回退按用户名探测
            out = dockerx.client().containers.run(tag, ["id", "-u", "odoo"], remove=True, entrypoint="", user="root")
            uid = int(out.decode().strip().splitlines()[-1])
    except Exception:  # noqa: BLE001
        # 官方镜像 odoo 用户历史 uid=100(旧注释写 101 是把 gid 看串了);新构建(2026-08)是 1000;自建 1000
        uid = 100 if tag.startswith(OFFICIAL_REPO + ":") else 1000
        key = None  # 探测失败的默认值不持久化,下次再试
        log.warning("探测镜像 %s 运行用户 uid 失败,暂用兜底值 %s(若创建实例报权限错误,多半是它不对)", tag, uid)
    _uid_cache[tag] = uid
    if key:
        try:
            from ..db import SessionLocal
            from ..models import Setting

            with SessionLocal() as db:
                row = db.get(Setting, key)
                if row:
                    row.value = str(uid)
                else:
                    db.add(Setting(key=key, value=str(uid)))
                db.commit()
        except Exception as ex:  # noqa: BLE001
            log.debug("写入 uid 缓存失败: %s", ex)
    return uid


def ensure_image(version: str, mode: str, say=log.info) -> str:
    """确保镜像存在:官方镜像 → docker pull(走加速站);自建 → 构建。返回 tag。"""
    tag = base_tag(version, mode)
    if dockerx.image_exists(tag):
        return tag
    # 内网/断网:镜像不在本地时,先看离线目录有没有现成的镜像包,自动 docker load(用户无需去镜像页手动导入)。
    # 目录里没有匹配包则返回 False,继续常规拉取/构建。
    try:
        from . import offline_images

        if offline_images.try_import_for_tag(tag, say=say) and dockerx.image_exists(tag):
            say(f"镜像 {tag} 就绪(离线导入)")
            return tag
    except Exception as ex:  # noqa: BLE001
        say(f"离线镜像自动导入未成功,继续常规流程:{ex}")
    if mode == "official":
        say(f"拉取官方镜像 {tag}(约 1.5GB,走 Docker 加速站)...")
        jid = f"pull-{version}"
        joblog.start(jid)
        try:
            pull_official_image(version, jid, say)
        except Exception as ex:  # noqa: BLE001
            joblog.finish(jid, False)
            raise RuntimeError(str(ex))
        joblog.finish(jid, True)
        say(f"镜像 {tag} 就绪")
        return tag
    say(f"基础镜像 {tag} 不存在,开始从源码构建(首次约 10~20 分钟,可在「基础镜像」页查看进度)")
    if not build_base_image(version):
        raise RuntimeError(f"基础镜像 {tag} 构建失败,详见「基础镜像」页日志")
    return tag


def pull_official(version: str) -> bool:
    """更新官方镜像(重新 pull)。"""
    jid = f"pull-{version}"
    joblog.start(jid)
    try:
        pull_official_image(version, jid)
        joblog.append(jid, f"完成:{OFFICIAL_REPO}:{version}")
        joblog.finish(jid, True)
        return True
    except Exception as e:  # noqa: BLE001
        joblog.append(jid, f"失败:{e}")
        joblog.finish(jid, False)
        return False


def job_id(version: str) -> str:
    return f"build-base-{version}"


def list_base_images() -> list[dict]:
    items = []
    for img in dockerx.client().images.list(name=BASE_REPO) + dockerx.client().images.list(name=OFFICIAL_REPO):
        items.append(
            {
                "id": img.short_id,
                "tags": img.tags,
                "size": img.attrs.get("Size", 0),
                "created": img.attrs.get("Created"),
            }
        )
    return items


def py_image_for(version: str) -> str:
    """源码自建时用的 Python 基础镜像:Odoo 各大版本支持的 Python 范围不同(12/13:3.6~3.8;14:3.6~3.9;15/16:3.8~3.10;17:3.10~3.12;18+:3.10+/3.12)。
    统一用 slim-bookworm 变体(Dockerfile 里改 apt 源的路径按 bookworm 写)。"""
    try:
        v = int(str(version).split(".")[0])
    except ValueError:
        v = 19
    if v <= 13:
        return "python:3.8-slim-bookworm"
    if v == 14:
        return "python:3.9-slim-bookworm"
    if v <= 16:
        return "python:3.10-slim-bookworm"
    if v == 17:
        return "python:3.11-slim-bookworm"
    return "python:3.12-slim-bookworm"


def build_base_image(version: str) -> bool:
    """同步构建(在后台线程里调用),日志写入 joblog。"""
    jid = job_id(version)
    joblog.start(jid)
    tag = base_tag(version)
    path = os.path.join(settings.images_dir, "odoo-base")
    src_url = pick_odoo_src_url(version, say=lambda m: joblog.append(jid, m))
    py_image = py_image_for(version)
    # 先把 Python 基础镜像拉到本地(带加速站回退);若默认源不通,把 FROM 改成成功的那个加速站的完整引用,
    # 否则 buildkit 解析 FROM 元数据时仍会去撞默认加速站的 429
    try:
        repo, ptag = py_image.split(":", 1)
        host = dockerx.pull_image(repo, ptag, say=lambda m: joblog.append(jid, m))
        if host:
            py_image = f"{host}/library/{py_image}"
    except Exception as ex:  # noqa: BLE001
        joblog.append(jid, f"预拉取 Python 基础镜像失败(继续尝试构建):{ex}")
    joblog.append(jid, f"开始构建 {tag},源码 {src_url} 分支 {version}.0(--depth 1),Python 基础镜像 {py_image}")
    try:
        api = dockerx.client().api
        stream = api.build(
            path=path,
            tag=tag,
            rm=True,
            decode=True,
            buildargs={
                "PY_IMAGE": py_image,
                "ODOO_VERSION": f"{version}.0",
                "ODOO_SRC_URL": src_url,
                "PIP_INDEX_URL": settings.pip_index_url,
                "DEBIAN_MIRROR": settings.debian_mirror,
            },
        )
        ok = True
        for chunk in stream:
            if "stream" in chunk:
                joblog.append(jid, chunk["stream"])
            elif "error" in chunk:
                joblog.append(jid, "ERROR: " + chunk["error"])
                ok = False
            elif "status" in chunk:
                joblog.append(jid, chunk["status"] + (" " + chunk.get("progress", "") if chunk.get("progress") else ""))
            elif "aux" in chunk:
                joblog.append(jid, "aux: " + json.dumps(chunk["aux"]))
        if ok and dockerx.image_exists(tag):
            joblog.append(jid, f"构建完成:{tag}")
        else:
            ok = False
            joblog.append(jid, "构建失败")
        joblog.finish(jid, ok)
        return ok
    except Exception as e:  # noqa: BLE001
        log.exception("build base image failed")
        joblog.append(jid, f"异常: {e}")
        joblog.finish(jid, False)
        return False
