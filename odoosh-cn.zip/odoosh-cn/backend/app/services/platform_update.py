"""平台自身的重启 / 更新(超级管理员)。

API 容器里没有源码与 compose,因此起一个一次性的「更新助手」容器(docker CLI + compose 插件),
挂载 docker.sock 与源码目录,在里面执行:
    [git pull] → docker compose -f deploy/docker-compose.yml --env-file deploy/.env up -d [--build] api web
API/web 会被它重建;前端轮询 /api/health 等待恢复,并可读取助手容器日志。
"""

import logging
import time

from docker.errors import APIError, NotFound

from ..config import settings
from . import dockerx

log = logging.getLogger("odoosh.update")

UPDATER_NAME = "odoosh-updater"
UPDATER_IMAGE = "docker:27-cli"  # 官方 docker CLI 镜像,自带 compose/buildx 插件

MODES = {
    "restart": "仅重启平台服务(api / web)",
    "rebuild": "按当前源码重新构建并重启(应用本地代码改动)",
    "pull": "先 git pull 拉取最新代码,再重新构建并重启",
}


def _script(mode: str, services: str = "api web") -> str:
    lines = [
        "set -e",
        "cd /src",
        "echo '== OdooshCN 平台更新助手 =='",
        f"echo 模式: {mode}",
    ]
    if mode == "pull":
        lines += [
            "if ! command -v git >/dev/null; then sed -i 's#dl-cdn.alpinelinux.org#mirrors.tuna.tsinghua.edu.cn#g' /etc/apk/repositories && apk add --no-cache git >/dev/null; fi",
            "git config --global --add safe.directory /src",
            "echo '== git pull =='",
            "git pull --ff-only",
        ]
    compose = "docker compose -f deploy/docker-compose.yml --env-file deploy/.env"
    if mode == "restart":
        lines += [f"echo '== restart =='", f"{compose} up -d --force-recreate {services}"]
    else:
        lines += [
            "echo '== build =='",
            # 加速站限流(429)时最多重试 3 次
            f"n=0; until {compose} build {services}; do n=$((n+1)); [ $n -ge 3 ] && exit 1; echo '构建失败,10 秒后重试(镜像站可能限流)'; sleep 10; done",
            "echo '== up =='",
            f"{compose} up -d {services}",
        ]
    lines += ["echo '== 完成 =='"]
    return "\n".join(lines)


def start(mode: str, services: str = "api web") -> dict:
    if mode not in MODES:
        raise ValueError(f"未知模式 {mode}")
    src = settings.host_src_dir
    if not src:
        raise RuntimeError("未配置源码目录(ODOOSH_SRC_DIR),无法自更新;请在 deploy/.env 中设置为仓库根目录的宿主机路径")
    client = dockerx.client()
    old = dockerx.get_container(UPDATER_NAME)
    if old:
        if old.status == "running":
            raise RuntimeError("已有更新任务在运行")
        old.remove(force=True)
    if not dockerx.image_exists(UPDATER_IMAGE):
        log.info("拉取更新助手镜像 %s", UPDATER_IMAGE)
        try:
            dockerx.pull_image(*UPDATER_IMAGE.split(":"), say=log.info)
        except Exception as ex:  # noqa: BLE001  # 加速站限流等:给 400 可读错误,而非未捕获异常变 500
            raise RuntimeError(f"拉取更新助手镜像 {UPDATER_IMAGE} 失败(镜像站可能限流):{ex}。"
                               f"可在服务器上手动执行 docker pull {UPDATER_IMAGE} 后重试") from ex
    c = dockerx.run_container(  # 统一入口:自带 json-file 20m×3 轮转,不依赖宿主机 daemon.json
        UPDATER_IMAGE,
        name=UPDATER_NAME,
        entrypoint=["sh", "-c"],
        command=[_script(mode, services)],
        detach=True,
        volumes={
            "/var/run/docker.sock": {"bind": "/var/run/docker.sock", "mode": "rw"},
            src: {"bind": "/src", "mode": "rw"},
        },
        environment={"DOCKER_HOST": "unix:///var/run/docker.sock"},
        labels={"odoosh.role": "updater"},
        working_dir="/src",
    )
    log.info("平台更新助手已启动 mode=%s container=%s", mode, c.short_id)
    return {"container": c.short_id, "mode": mode, "started": time.time()}


def status(since: float | None = None) -> dict:
    c = dockerx.get_container(UPDATER_NAME)
    if not c:
        return {"exists": False, "running": False, "exit_code": None, "log": ""}
    st = c.attrs.get("State", {})  # get_container 已是刚 inspect 的结果,不必再 reload 一次
    return {
        "exists": True,
        "running": c.status == "running",
        "exit_code": st.get("ExitCode") if c.status != "running" else None,
        "started_at": st.get("StartedAt"),
        "finished_at": st.get("FinishedAt") if c.status != "running" else None,
        # since:只返回该时间之后的新日志(前端轮询期间累加,不再每 4s 全量传 200 行)
        "log": (c.logs(since=int(since)) if since else c.logs(tail=200)).decode(errors="ignore"),
        "log_ts": int(time.time()),
    }
