"""实例资源指标采集(后台线程)。

- 每 INTERVAL 秒对所有 running 实例做一次 docker stats(one_shot,毫秒级),CPU% 由相邻两次采样差分得到;
- 最新一份放内存 `latest`,供 /environments/stats 直接返回(不再在请求里阻塞采样);
- 每次采样落 env_metrics 表(Monitor Tab 曲线),保留 RETENTION_DAYS 天;
- 每 DISK_EVERY 次采样(约 5 分钟)算一次 filestore 目录大小与数据库大小(低频,较慢)。
"""

import logging
import os
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

from sqlalchemy import delete, select

from ..db import SessionLocal
from ..models import Environment, Tenant
from ..models_metrics import EnvMetric
from . import dockerx

log = logging.getLogger("odoosh.metrics")

INTERVAL = 10
PERSIST_EVERY = 6     # 内存 latest 仍每 10s 刷新;DB 每 6 tick(60s)写一行 60s 窗口平均值
                      # (以前每 10s 一行:6 万行/实例/周,100 个实例 600 万行 + 持续 WAL;曲线 240 个点根本用不到那么密)
DISK_EVERY = 360      # 磁盘占用每 360 tick(1 小时)算一次:du 一个几十万文件的 filestore 是全量 stat 遍历,
                      # 以前 5 分钟一次、8 并发,会持续冲刷 page cache 影响所有实例
RETENTION_DAYS = 7

_lock = threading.Lock()
latest: dict[int, dict] = {}          # env_id -> 最新样本(给列表页 / 卡片用)
_prev_cpu: dict[int, tuple[int, int, float]] = {}  # env_id -> (cpu_total, system_total, ts)
_disk: dict[int, tuple[int | None, int | None]] = {}  # env_id -> (filestore_bytes, db_bytes)
_acc: dict[int, list] = {}  # env_id -> [cpu_sum, mem_sum, n]:落库窗口内的累计,写完清零
_started = False


def _sample_one(env_id: int, c) -> dict | None:
    try:
        s = c.stats(stream=False, one_shot=True)
    except Exception as ex:  # noqa: BLE001
        log.debug("stats env#%s 失败: %s", env_id, ex)
        return None
    now = time.time()
    cpu = s.get("cpu_stats", {})
    cpu_total = cpu.get("cpu_usage", {}).get("total_usage", 0)
    sys_total = cpu.get("system_cpu_usage", 0)
    ncpu = cpu.get("online_cpus") or len(cpu.get("cpu_usage", {}).get("percpu_usage") or []) or 1
    cpu_pct = None
    prev = _prev_cpu.get(env_id)
    if prev and sys_total > prev[1] and cpu_total >= prev[0]:
        cpu_pct = round((cpu_total - prev[0]) / (sys_total - prev[1]) * ncpu * 100.0, 1)
    _prev_cpu[env_id] = (cpu_total, sys_total, now)
    mem = s.get("memory_stats", {})
    usage = max(mem.get("usage", 0) - mem.get("stats", {}).get("inactive_file", 0), 0)
    limit = mem.get("limit", 0)
    rx = tx = 0
    for v in (s.get("networks") or {}).values():
        rx += v.get("rx_bytes", 0)
        tx += v.get("tx_bytes", 0)
    br = bw = 0
    for it in (s.get("blkio_stats", {}).get("io_service_bytes_recursive") or []):
        if it.get("op", "").lower() == "read":
            br += it.get("value", 0)
        elif it.get("op", "").lower() == "write":
            bw += it.get("value", 0)
    return {
        "cpu_percent": cpu_pct if cpu_pct is not None else 0.0,
        "mem_usage": usage,
        "mem_limit": limit,
        "mem_percent": round(usage / limit * 100.0, 1) if limit else 0.0,
        "net_rx": rx, "net_tx": tx, "blk_read": br, "blk_write": bw,
        "pids": s.get("pids_stats", {}).get("current"),
        "started_at": c.attrs.get("State", {}).get("StartedAt"),
        "ts": now,
    }


def _disk_sizes(t: Tenant, e: Environment) -> tuple[int | None, int | None]:
    from . import orchestrator as orch

    fs = os.path.join(orch.env_dir(t, e), "filestore")
    fs_bytes = None
    if os.path.isdir(fs):
        try:
            out = subprocess.run(["du", "-sb", fs], capture_output=True, text=True, timeout=120).stdout
            fs_bytes = int(out.split()[0])
        except Exception:  # noqa: BLE001
            fs_bytes = None
    db_bytes = None
    if e.db_name:
        pg = dockerx.get_container(orch.pg_container_name(t))
        if pg and pg.status == "running":
            try:
                code, out = orch._psql(pg, f"SELECT pg_database_size('{e.db_name}')")
                if code == 0:
                    for ln in out.splitlines():
                        ln = ln.strip()
                        if ln.isdigit():
                            db_bytes = int(ln)
                            break
            except Exception:  # noqa: BLE001
                pass
            # 附加库:顺便刷新各库大小(写回 environment_databases.size_bytes),实例总量 = 主库 + 附加库
            try:
                from . import databases as dbsvc

                extra = dbsvc.refresh_sizes(pg, e)
                if extra and db_bytes is not None:
                    db_bytes += sum(extra.values())
            except Exception:  # noqa: BLE001
                pass
    return fs_bytes, db_bytes


def _tick(n: int) -> None:
    try:
        import psutil

        psutil.cpu_percent(interval=None)  # 预热,主机 CPU% 由 system/overview 用 interval=None 读取
    except Exception:  # noqa: BLE001
        pass
    with SessionLocal() as db:
        rows = db.execute(
            select(Environment, Tenant).join(Tenant, Tenant.id == Environment.tenant_id).where(Environment.status == "running", Environment.container_name.is_not(None))
        ).all()
        envs = [(e, t) for e, t in rows]
    if not envs:
        with _lock:
            latest.clear()
        return
    # 一次 list 拿到所有 odoo 容器,避免逐个 inspect
    by_name = {}
    try:
        for c in dockerx.client().containers.list(filters={"label": "odoosh.role=odoo", "status": "running"}):
            by_name[c.name] = c
    except Exception as ex:  # noqa: BLE001
        log.warning("列出容器失败: %s", ex)
        return
    do_disk = n % DISK_EVERY == 0
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(_sample_one, e.id, by_name[e.container_name]): (e, t) for e, t in envs if e.container_name in by_name}
        results = {}
        for f, (e, t) in futs.items():
            r = f.result()
            if r:
                results[e.id] = (r, e, t)
    if do_disk:
        # 磁盘统计单线程串行(不与采样并发、不多个 du 一起冲 IO),且只在首次或 tick 到点时算
        for e, t in envs:
            try:
                _disk[e.id] = _disk_sizes(t, e)
            except Exception:  # noqa: BLE001
                pass
    # 已删除的实例从进程内字典里清掉(以前 _prev_cpu/_disk 只增不减)
    alive = {e.id for e, _t in envs}
    for d in (_prev_cpu, _disk, _acc):
        for k in [k for k in d if k not in alive]:
            d.pop(k, None)
    now = datetime.now(timezone.utc)
    with _lock:
        latest.clear()
        for eid, (r, e, t) in results.items():
            d = _disk.get(eid)
            if d:
                r["disk_filestore"], r["disk_db"] = d
            latest[eid] = r
    # 窗口累计;每 PERSIST_EVERY tick 落一行(cpu/mem 为窗口平均,累计量取最新)
    for eid, (r, e, t) in results.items():
        a = _acc.setdefault(eid, [0.0, 0, 0])
        a[0] += r["cpu_percent"] or 0
        a[1] += r["mem_usage"] or 0
        a[2] += 1
    if results and n % PERSIST_EVERY == 0:
        with SessionLocal() as db:
            for eid, (r, e, t) in results.items():
                a = _acc.pop(eid, None) or [r["cpu_percent"] or 0, r["mem_usage"] or 0, 1]
                cnt = max(1, a[2])
                d = _disk.get(eid) if do_disk else None
                db.add(EnvMetric(
                    environment_id=eid, ts=now, cpu_pct=round(a[0] / cnt, 1), mem_bytes=int(a[1] / cnt), mem_limit=r["mem_limit"],
                    net_rx=r["net_rx"], net_tx=r["net_tx"], blk_read=r["blk_read"], blk_write=r["blk_write"], pids=r["pids"],
                    disk_filestore=d[0] if d else None, disk_db=d[1] if d else None,
                ))
            db.commit()


def _prune() -> None:
    """分批删除过期样本(单事务几百万行会长时间持锁、产生大量 WAL 与表膨胀)。"""
    from sqlalchemy import select

    cutoff = datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)
    with SessionLocal() as db:
        while True:
            ids = db.scalars(select(EnvMetric.id).where(EnvMetric.ts < cutoff).limit(5000)).all()
            if not ids:
                break
            db.execute(delete(EnvMetric).where(EnvMetric.id.in_(ids)))
            db.commit()
            if len(ids) < 5000:
                break


def start_collector() -> None:
    global _started
    if _started:
        return
    _started = True

    def loop():
        n = 0
        while True:
            t0 = time.time()
            try:
                _tick(n)
                if n % 360 == 0:  # 每小时清一次过期数据
                    _prune()
            except Exception as ex:  # noqa: BLE001
                log.warning("指标采集出错: %s", ex)
            n += 1
            time.sleep(max(1.0, INTERVAL - (time.time() - t0)))

    threading.Thread(target=loop, name="metrics-collector", daemon=True).start()


def get_latest(env_ids: list[int]) -> dict[str, dict]:
    with _lock:
        return {str(i): latest[i] for i in env_ids if i in latest}


RANGES = {"1h": timedelta(hours=1), "6h": timedelta(hours=6), "24h": timedelta(hours=24), "7d": timedelta(days=7)}


def series(env_id: int, rng: str = "1h", points: int = 240) -> dict:
    """返回按时间桶降采样后的曲线数据(每桶取平均 / 累计量取最后值)。"""
    span = RANGES.get(rng, RANGES["1h"])
    since = datetime.now(timezone.utc) - span
    from types import SimpleNamespace

    cols = (EnvMetric.ts, EnvMetric.cpu_pct, EnvMetric.mem_bytes, EnvMetric.mem_limit, EnvMetric.net_rx, EnvMetric.net_tx,
            EnvMetric.blk_read, EnvMetric.blk_write, EnvMetric.pids, EnvMetric.disk_filestore, EnvMetric.disk_db)
    with SessionLocal() as db:
        # 只取列元组,不物化 ORM 对象(7d 曲线上万行时省一个量级的内存/时间)
        rows = [SimpleNamespace(**dict(zip(("ts", "cpu_pct", "mem_bytes", "mem_limit", "net_rx", "net_tx", "blk_read", "blk_write",
                                          "pids", "disk_filestore", "disk_db"), row)))
                for row in db.execute(select(*cols).where(EnvMetric.environment_id == env_id, EnvMetric.ts >= since).order_by(EnvMetric.ts)).all()]
    if not rows:
        return {"range": rng, "points": [], "disk": None}
    bucket = max(span.total_seconds() / points, INTERVAL * PERSIST_EVERY)
    out: list[dict] = []
    cur_key = None
    acc: list = []
    prev_last = None  # 上一桶最后一个样本(累计量差分的起点)

    def _rate(a, b, attr: str) -> int:
        if a is None:
            return 0
        dt = (b.ts - a.ts).total_seconds()
        if dt <= 0:
            return 0
        va, vb = getattr(a, attr) or 0, getattr(b, attr) or 0
        return max(0, int((vb - va) / dt)) if vb >= va else 0  # 容器重启后计数归零 → 0

    def flush():
        nonlocal prev_last
        if not acc:
            return
        n = len(acc)
        last = acc[-1]
        base = prev_last or (acc[0] if n > 1 else None)
        out.append({
            "ts": last.ts.isoformat(),
            "cpu": round(sum((m.cpu_pct or 0) for m in acc) / n, 1),
            "mem": int(sum((m.mem_bytes or 0) for m in acc) / n),
            "mem_limit": last.mem_limit,
            # 网络 / 磁盘 IO:累计值差分 → 字节/秒
            "net_rx_bps": _rate(base, last, "net_rx"),
            "net_tx_bps": _rate(base, last, "net_tx"),
            "blk_read_bps": _rate(base, last, "blk_read"),
            "blk_write_bps": _rate(base, last, "blk_write"),
            "pids": last.pids,
        })
        prev_last = last

    for m in rows:
        key = int(m.ts.timestamp() // bucket)
        if cur_key is not None and key != cur_key:
            flush()
            acc = []
        cur_key = key
        acc.append(m)
    flush()
    disk_rows = [m for m in rows if m.disk_filestore is not None or m.disk_db is not None]
    disk = None
    if disk_rows:
        disk = {"points": [{"ts": m.ts.isoformat(), "filestore": m.disk_filestore, "db": m.disk_db} for m in disk_rows[-points:]],
                "latest": {"filestore": disk_rows[-1].disk_filestore, "db": disk_rows[-1].disk_db}}
    return {"range": rng, "points": out, "disk": disk}
