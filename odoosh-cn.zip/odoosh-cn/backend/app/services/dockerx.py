"""Docker 客户端与通用工具。"""

import secrets
import string

import docker
from docker.errors import NotFound, NullResource

from ..config import settings

_client: docker.DockerClient | None = None

# 平台创建的所有容器(实例 / 租户 PG / 一次性任务)统一的日志轮转:不依赖宿主机 daemon.json 是否配置过 log-opts,
# 否则 Odoo(log_level=info)的 stdout 会在 /var/lib/docker/containers 下无限增长
LOG_CONFIG = {"Type": "json-file", "Config": {"max-size": "20m", "max-file": "3"}}


def client() -> docker.DockerClient:
    global _client
    if _client is None:
        # max_pool_size:默认 10;指标采集 8 线程 + 每个 SSE 日志流各占一条长连接 + 编排线程,超出即频繁建/拆 socket
        _client = docker.DockerClient(base_url=settings.docker_socket, timeout=600, max_pool_size=64)
    return _client


def run_container(image: str, **kw):
    """containers.run 的统一入口:强制附带日志轮转配置(可被 kw 覆盖)。"""
    from docker.types import LogConfig

    lc = kw.pop("log_config", None) or LOG_CONFIG
    if isinstance(lc, dict):
        lc = LogConfig(type=lc["Type"], config=lc.get("Config", {}))
    return client().containers.run(image, log_config=lc, **kw)


def rand_password(n: int = 24) -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(n))


def get_container(name: str | None):
    if not name:
        return None
    try:
        return client().containers.get(name)
    except (NotFound, NullResource):
        return None


def get_network(name: str | None):
    if not name:
        return None
    try:
        return client().networks.get(name)
    except (NotFound, NullResource):
        return None


# 备用加速站:daemon.json 里配的 registry-mirrors 对冷门 tag 常返回 429/5xx,而 dockerd 遇到 429 不会顺延到下一个 mirror。
# 这里在应用层兜底:默认源失败 → 逐个用 <加速站>/library/<repo>:<tag> 拉,拉到后打回 <repo>:<tag>。
# 顺序:设置项 docker.registry_mirror(去掉 https://)排最前,其后是内置候选。
FALLBACK_MIRRORS = [
    "docker.1ms.run", "docker.m.daocloud.io", "dockerproxy.net", "docker.hlmirror.com", "hub.rat.dev", "docker-0.unsee.tech", "docker.xuanyuan.me",
]


def _mirror_candidates() -> list[str]:
    hosts: list[str] = []
    try:
        from ..db import SessionLocal
        from ..routers.settings import get_setting

        with SessionLocal() as db:
            m = (get_setting(db, "docker.registry_mirror") or "").strip()
        m = m.replace("https://", "").replace("http://", "").strip("/")
        if m:
            hosts.append(m)
    except Exception:  # noqa: BLE001
        pass
    for h in FALLBACK_MIRRORS:
        if h not in hosts:
            hosts.append(h)
    return hosts


def _pull_stream(repo: str, tag: str, on_status=None) -> None:
    last = ""
    for chunk in client().api.pull(repo, tag=tag, stream=True, decode=True):
        if chunk.get("error"):
            raise RuntimeError(chunk["error"])
        if on_status:
            st = chunk.get("status", "")
            if chunk.get("id"):
                st = f"{chunk['id']}: {st} {chunk.get('progress', '')}"
            if st != last:
                on_status(st)
                last = st


def pull_image(repo: str, tag: str, say=None, on_status=None, official: bool = True) -> str:
    """拉取 repo:tag(Docker Hub 官方库 official=True 时备用站路径为 library/<repo>)。
    先走 daemon 默认(其配置的加速站),失败再逐个试备用加速站;成功后本地一定存在 repo:tag。
    返回实际成功的来源("" = 默认源,否则为加速站域名)。全部失败抛 RuntimeError。"""
    say = say or (lambda m: None)
    full = f"{repo}:{tag}"
    errors: list[str] = []
    try:
        _pull_stream(repo, tag, on_status)
        if image_exists(full):
            return ""
        errors.append("默认源拉取后镜像不存在")
    except Exception as ex:  # noqa: BLE001
        errors.append(f"默认源: {str(ex)[-160:]}")
        say(f"默认加速站拉取 {full} 失败({str(ex)[-120:]}),改用备用加速站重试")
    path = f"library/{repo}" if official and "/" not in repo else repo
    for host in _mirror_candidates():
        alias = f"{host}/{path}"
        say(f"尝试 {host} 拉取 {full} …")
        try:
            _pull_stream(alias, tag, on_status)
            img = client().images.get(f"{alias}:{tag}")
            img.tag(repo, tag)
            try:
                client().images.remove(f"{alias}:{tag}", force=False)  # 只摘掉别名标签,层保留
            except Exception:  # noqa: BLE001
                pass
            if image_exists(full):
                say(f"经 {host} 拉取成功 → {full}")
                return host
        except Exception as ex:  # noqa: BLE001
            errors.append(f"{host}: {str(ex)[-120:]}")
            say(f"{host} 失败:{str(ex)[-160:]}")
    raise RuntimeError(f"拉取镜像 {full} 失败(默认源与备用加速站都不可用):" + " | ".join(errors[-3:]))


def image_exists(tag: str | None) -> bool:
    if not tag:
        return False
    try:
        client().images.get(tag)
        return True
    except (NotFound, NullResource):
        return False


_platform_cache: dict[str, tuple[float, str]] = {}  # service -> (ts, container id)


def find_platform_container(service: str):
    """通过 compose 标签找到平台自己的容器(如 web)。结果按 id 缓存 60s(nginx reload 高频调用)。"""
    import time

    hit = _platform_cache.get(service)
    if hit and time.time() - hit[0] < 60:
        try:
            return client().containers.get(hit[1])
        except (NotFound, NullResource):
            _platform_cache.pop(service, None)
    for c in client().containers.list(
        all=True,
        filters={
            "label": [
                f"com.docker.compose.project={settings.compose_project}",
                f"com.docker.compose.service={service}",
            ]
        },
    ):
        _platform_cache[service] = (time.time(), c.id)
        return c
    return None
