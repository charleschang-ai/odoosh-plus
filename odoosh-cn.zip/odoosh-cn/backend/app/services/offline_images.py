"""离线镜像包:检测约定目录里的 docker save tar 并导入(docker load),供内网/断网环境用。

约定目录(容器内)= <data_dir>/offline/images,对应宿主机 <host_data_dir>/offline/images
(compose 把整个数据目录同路径挂进 api 容器,所以管理员往宿主机该目录拷 tar,容器内即可读、可 docker load)。

用法:在有网机器上 `docker save odoo:19 -o odoo-19.tar`,拷到服务器该目录,平台「基础镜像」页即可检测并一键导入。
"""

import json
import logging
import os
import tarfile
import time

from ..config import settings
from . import dockerx, joblog

log = logging.getLogger("odoosh.offline_images")

SUBDIR = os.path.join("offline", "images")
# 允许的镜像包后缀(docker save 产物;.tar 可秒级读清单,.tar.gz 需顺序解压故大文件跳过预读)
TAR_SUFFIXES = (".tar", ".tar.gz", ".tgz")
# 预读清单(取镜像 tag)的体积上限:.tar 任意大小都便宜(seek 跳过数据);.tar.gz 超过此值就不预读,只按文件名展示
PEEK_GZ_MAX = 512 * 1024 * 1024


def images_dir() -> str:
    """容器内的离线镜像目录(自动创建)。"""
    d = os.path.join(settings.data_dir, SUBDIR)
    os.makedirs(d, exist_ok=True)
    return d


def host_images_dir() -> str:
    """宿主机上的同一目录(给管理员看往哪拷文件;host_data_dir 未配时回退容器内路径)。"""
    base = settings.host_data_dir or settings.data_dir
    return os.path.join(base, SUBDIR)


def _safe_path(name: str) -> str:
    """把文件名解析成目录内的绝对路径,拒绝路径穿越。"""
    if not name or "/" in name or "\\" in name or name in (".", ".."):
        raise ValueError("非法文件名")
    d = images_dir()
    p = os.path.realpath(os.path.join(d, name))
    if os.path.dirname(p) != os.path.realpath(d):
        raise ValueError("非法文件名")
    return p


def sanitize_upload_name(filename: str) -> str:
    """把上传文件名收敛成安全的 basename,并校验后缀。用于网页上传落盘到离线目录。"""
    name = os.path.basename((filename or "").strip().replace("\\", "/"))
    if not name or name in (".", ".."):
        raise ValueError("文件名为空")
    if not name.lower().endswith(TAR_SUFFIXES):
        raise ValueError("只接受 docker save 导出的 .tar / .tar.gz / .tgz")
    # 只保留常见安全字符,其余替换为下划线(避免奇异文件名)
    import re

    base, dot, ext = name.partition(".")
    base = re.sub(r"[^A-Za-z0-9._-]", "_", base)[:100] or "image"
    return base + dot + ext


def upload_dest(filename: str) -> tuple[str, str]:
    """返回(最终路径, 临时 .part 路径);上传先写 .part,完成后 rename,避免扫描到半截文件。
    .part 带随机后缀:同名文件被并发上传时各写各的,不会互相写花。"""
    from uuid import uuid4

    safe = sanitize_upload_name(filename)
    d = images_dir()
    final = _safe_path(safe)  # 复用穿越校验
    return final, os.path.join(d, f".{safe}.{uuid4().hex[:8]}.part")


def _norm_tag(tag: str) -> str:
    """把镜像引用归一成 docker 本地的短写法,便于跟 odoo:19 这种名字比对。
      docker.io/library/odoo:19        → odoo:19
      docker.io/pgvector/pgvector:pg16 → pgvector/pgvector:pg16
    开了 containerd 镜像存储的 Docker(Docker Desktop 现已默认)导出的是 OCI 布局,
    名字里带完整 registry 前缀;docker load 之后本地显示的却是短名,不归一就会匹配不上。"""
    t = (tag or "").strip()
    for p in ("docker.io/", "index.docker.io/", "registry-1.docker.io/"):
        if t.startswith(p):
            t = t[len(p):]
            break
    if t.startswith("library/"):
        t = t[len("library/"):]
    return t


def peek_tags(path: str) -> list[str] | None:
    """不导入,只读 tar 里的镜像清单取 tag。兼容传统 docker save 的 manifest.json 与 OCI 的 index.json。
    返回:list(可能为空 [] = 是镜像包但未打标签,仍可导入);None = 不是镜像包 / 文件损坏。
    只读几 KB 元数据,不解压镜像层。"""
    try:
        with tarfile.open(path, "r:*") as tf:
            # 传统布局:manifest.json → [{"RepoTags": ["odoo:19"], ...}]
            try:
                m = tf.getmember("manifest.json")
                data = json.loads(tf.extractfile(m).read().decode("utf-8", "ignore"))
                tags: list[str] = []
                for entry in data:
                    for t in entry.get("RepoTags") or []:
                        t = _norm_tag(t)
                        if t and t not in tags:
                            tags.append(t)
                return tags  # 有 manifest 即是有效镜像包(空列表 = 未打标签)
            except KeyError:
                pass
            # OCI 布局:index.json → manifests[].annotations 里的镜像名
            try:
                m = tf.getmember("index.json")
                idx = json.loads(tf.extractfile(m).read().decode("utf-8", "ignore"))
                tags = []
                for man in idx.get("manifests") or []:
                    ann = man.get("annotations") or {}
                    t = _norm_tag(ann.get("io.containerd.image.name") or ann.get("org.opencontainers.image.ref.name") or "")
                    if t and t not in tags:
                        tags.append(t)
                return tags
            except KeyError:
                return None  # tar 里既无 manifest.json 也无 index.json → 不是镜像包
    except Exception as ex:  # noqa: BLE001
        log.debug("预读镜像包 %s 清单失败(可能损坏或非 tar): %s", path, ex)
        return None


def scan() -> list[dict]:
    """列出离线镜像目录里的 tar 包。每项含 status:
      ok      读到镜像清单(tags 为标签列表;空列表 = 有效但未打标签)
      unknown 大 gzip 包,主动跳过预读(不解压以省资源;仍可导入,建议改用未压缩 .tar)
      bad     .tar 却读不到镜像清单 —— 可能损坏,或不是 docker save 的镜像包
    只读几 KB 元数据,不碰镜像层,几十个大包也是瞬时。"""
    d = images_dir()
    out: list[dict] = []
    try:
        names = sorted(os.listdir(d))
    except OSError:
        return out
    for name in names:
        if name.endswith(".part"):
            # 上传中断(浏览器关掉 / 网断)留下的半截文件:超过 6 小时没写入就当孤儿清掉,
            # 否则 GB 级的残片会一直占着磁盘且没人看得见
            try:
                orphan = os.path.join(d, name)
                if time.time() - os.path.getmtime(orphan) > 6 * 3600:
                    os.remove(orphan)
                    log.info("清理中断上传的临时文件 %s", orphan)
            except OSError:
                pass
            continue
        if not name.lower().endswith(TAR_SUFFIXES):
            continue
        p = os.path.join(d, name)
        if not os.path.isfile(p):
            continue
        try:
            st = os.stat(p)
        except OSError:
            continue
        is_gz = name.lower().endswith((".gz", ".tgz"))
        if is_gz and st.st_size > PEEK_GZ_MAX:
            tags, status = None, "unknown"      # 大 gzip 顺序解压代价高,跳过预读
        else:
            tags = peek_tags(p)
            status = "bad" if tags is None else "ok"
        imported = bool(tags) and all(dockerx.image_exists(t) for t in tags)
        out.append({
            "name": name,
            "size": st.st_size,
            "mtime": st.st_mtime,
            "tags": tags,          # 标签列表 / [] 未打标签 / None 未预读或非镜像包
            "status": status,      # ok | unknown | bad
            "imported": imported,  # 该包内所有 tag 都已在本地
        })
    return out


def job_id(name: str) -> str:
    return f"offline-load-{name}"


def _load_tar(path: str, emit) -> list[str]:
    """docker load 单个 tar,进度逐行回调 emit,返回导入的镜像 tag 列表。出错抛异常。"""
    loaded: list[str] = []
    with open(path, "rb") as f:
        # 低层 load_image 返回进度流;传统布局每导入一个镜像会有一行 "Loaded image: <tag>"
        for chunk in dockerx.client().api.load_image(f, quiet=False):
            if not isinstance(chunk, dict):
                continue
            if chunk.get("error"):
                raise RuntimeError(chunk["error"])
            msg = (chunk.get("stream") or chunk.get("status") or "").strip()
            if not msg:
                continue
            emit(msg)
            if msg.lower().startswith("loaded image"):
                loaded.append(msg.split(":", 1)[-1].strip())
    return loaded


def import_tar(name: str) -> bool:
    """docker load 导入指定 tar(供镜像页手动导入),进度写入 joblog。成功返回 True。"""
    jid = job_id(name)
    joblog.start(jid)
    try:
        path = _safe_path(name)
    except ValueError as ex:
        joblog.append(jid, f"文件名非法:{ex}")
        joblog.finish(jid, False)
        return False
    if not os.path.isfile(path):
        joblog.append(jid, f"文件不存在:{name}")
        joblog.finish(jid, False)
        return False
    joblog.append(jid, f"开始导入 {name}({os.path.getsize(path) // (1024 * 1024)} MB),docker load…")
    try:
        loaded = _load_tar(path, lambda m: joblog.append(jid, m))
        joblog.append(jid, f"导入完成:{name}" + (f"(镜像:{', '.join(loaded)})" if loaded else ""))
        joblog.finish(jid, True)
        return True
    except Exception as ex:  # noqa: BLE001
        log.exception("导入离线镜像 %s 失败", name)
        joblog.append(jid, f"导入失败:{ex}")
        joblog.finish(jid, False)
        return False


def try_import_for_tag(tag: str, say=log.info) -> bool:
    """按需自动导入:在离线目录里找含指定镜像 tag 的包并 docker load(创建实例时无镜像则自动调用,用户无需手动)。
    找到匹配包且导入后本地确实出现该 tag → True;目录里没有匹配包 → False(交回常规拉取/构建流程)。"""
    try:
        files = scan()
    except Exception:  # noqa: BLE001
        return False
    cand = [f for f in files if f.get("tags") and tag in f["tags"]]
    if not cand:
        return False
    for f in cand:
        path = os.path.join(images_dir(), f["name"])
        say(f"发现离线镜像包 {f['name']} 含 {tag},自动导入(docker load)…")
        try:
            _load_tar(path, say)
            if dockerx.image_exists(tag):
                say(f"离线导入成功:{tag}")
                return True
        except Exception as ex:  # noqa: BLE001
            log.warning("离线包 %s 导入失败: %s", f["name"], ex)
            say(f"离线包 {f['name']} 导入失败:{ex}")
    return False


def delete_tar(name: str) -> bool:
    """删除已导入的 tar 以释放磁盘(离线包动辄 GB 级)。"""
    path = _safe_path(name)
    if os.path.isfile(path):
        os.remove(path)
        return True
    return False
