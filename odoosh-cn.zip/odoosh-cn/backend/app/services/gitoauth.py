"""GitHub / Gitee OAuth 授权与"写"操作 API(列仓库、建仓库、建分支、建 Webhook)。

- OAuth App 的 client_id / client_secret 由平台管理员配置,存于 Setting 表(键见 OAUTH_KEYS)。
- 用户授权一次后令牌存 GitAccount;Gitee 令牌 1 天过期,用 refresh_token 自动续期。
- 只读的分支/提交读取仍走 services/git.py(smart-HTTP),本模块负责需要"账号身份"的操作。
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode

import requests
from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..models import Setting
from ..models_git import GitAccount

log = logging.getLogger("odoosh.gitoauth")
TIMEOUT = 15
UA = "OdooshCN/0.1"

PROVIDERS = ("github", "gitee")
OAUTH_KEYS = {p: (f"git.{p}_client_id", f"git.{p}_client_secret") for p in PROVIDERS}
SCOPES = {
    "github": "repo admin:repo_hook read:user",
    "gitee": "user_info projects hook",
}


class OAuthError(RuntimeError):
    pass


# ---------------------------------------------------------------- 平台级 OAuth App 配置
def get_oauth_apps(db: Session) -> dict[str, dict]:
    from ..crypto import decrypt

    rows = {s.key: decrypt(s.value) for s in db.scalars(select(Setting).where(Setting.key.like("git.%"))).all()}
    return {
        p: {"client_id": rows.get(cid) or "", "client_secret": rows.get(sec) or "", "configured": bool(rows.get(cid) and rows.get(sec))}
        for p, (cid, sec) in OAUTH_KEYS.items()
    }


def set_oauth_app(db: Session, provider: str, client_id: str | None, client_secret: str | None) -> None:
    cid_key, sec_key = OAUTH_KEYS[provider]
    for key, val in ((cid_key, client_id), (sec_key, client_secret)):
        if val is None:
            continue  # None = 不修改(密钥留空表示保持)
        if key == sec_key and val:
            from ..crypto import encrypt

            val = encrypt(val)  # client_secret 静态加密
        row = db.get(Setting, key)
        if row:
            row.value = val
        else:
            db.add(Setting(key=key, value=val))
    db.commit()


def _app(db: Session, provider: str) -> tuple[str, str]:
    apps = get_oauth_apps(db)
    a = apps.get(provider)
    if not a or not a["configured"]:
        raise OAuthError(f"管理员尚未配置 {provider} 的 OAuth 应用(Client ID / Secret)")
    return a["client_id"], a["client_secret"]


# ---------------------------------------------------------------- 授权流程
def make_state(user_id: int, provider: str, redirect_uri: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=10)
    return jwt.encode({"sub": str(user_id), "p": provider, "r": redirect_uri, "exp": exp, "k": "gitoauth"}, settings.secret_key, algorithm="HS256")


def parse_state(state: str) -> dict:
    try:
        d = jwt.decode(state, settings.secret_key, algorithms=["HS256"])
    except JWTError as e:
        raise OAuthError("授权状态无效或已过期,请重新发起连接") from e
    if d.get("k") != "gitoauth":
        raise OAuthError("授权状态无效")
    return {"user_id": int(d["sub"]), "provider": d["p"], "redirect_uri": d["r"]}


def authorize_url(db: Session, provider: str, user_id: int, redirect_uri: str) -> str:
    client_id, _ = _app(db, provider)
    state = make_state(user_id, provider, redirect_uri)
    if provider == "github":
        q = {"client_id": client_id, "redirect_uri": redirect_uri, "scope": SCOPES["github"], "state": state}
        return "https://github.com/login/oauth/authorize?" + urlencode(q)
    if provider == "gitee":
        q = {"client_id": client_id, "redirect_uri": redirect_uri, "response_type": "code", "scope": SCOPES["gitee"], "state": state}
        return "https://gitee.com/oauth/authorize?" + urlencode(q)
    raise OAuthError("不支持的平台")


def exchange_code(db: Session, provider: str, code: str, redirect_uri: str) -> dict:
    """用授权码换令牌。返回 {access_token, refresh_token, expires_at, scopes}。"""
    client_id, client_secret = _app(db, provider)
    try:
        if provider == "github":
            r = requests.post(
                "https://github.com/login/oauth/access_token",
                data={"client_id": client_id, "client_secret": client_secret, "code": code, "redirect_uri": redirect_uri},
                headers={"Accept": "application/json", "User-Agent": UA},
                timeout=TIMEOUT,
            )
        else:
            r = requests.post(
                "https://gitee.com/oauth/token",
                data={
                    "grant_type": "authorization_code",
                    "code": code,
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "redirect_uri": redirect_uri,
                },
                headers={"Accept": "application/json", "User-Agent": UA},
                timeout=TIMEOUT,
            )
    except requests.RequestException as e:
        raise OAuthError(f"连接 {provider} 失败: {e}") from e
    j = r.json() if r.content else {}
    if r.status_code != 200 or "access_token" not in j:
        raise OAuthError(j.get("error_description") or j.get("error") or f"换取令牌失败 (HTTP {r.status_code})")
    return _token_fields(j)


def _token_fields(j: dict) -> dict:
    exp = None
    if j.get("expires_in"):
        exp = datetime.now(timezone.utc) + timedelta(seconds=int(j["expires_in"]))
    return {"access_token": j["access_token"], "refresh_token": j.get("refresh_token"), "expires_at": exp, "scopes": j.get("scope")}


def refresh_if_needed(db: Session, acc: GitAccount) -> GitAccount:
    """Gitee 令牌到期前 5 分钟自动刷新;GitHub OAuth App 令牌不过期。"""
    if acc.provider != "gitee" or not acc.expires_at or not acc.refresh_token:
        return acc
    if acc.expires_at - timedelta(minutes=5) > datetime.now(timezone.utc):
        return acc
    try:
        r = requests.post(
            "https://gitee.com/oauth/token",
            data={"grant_type": "refresh_token", "refresh_token": acc.refresh_token},
            headers={"Accept": "application/json", "User-Agent": UA},
            timeout=TIMEOUT,
        )
        j = r.json()
        if r.status_code != 200 or "access_token" not in j:
            raise OAuthError(j.get("error_description") or "刷新 Gitee 令牌失败,请重新连接账号")
    except requests.RequestException as e:
        raise OAuthError(f"刷新 Gitee 令牌失败: {e}") from e
    f = _token_fields(j)
    acc.access_token, acc.refresh_token, acc.expires_at = f["access_token"], f["refresh_token"] or acc.refresh_token, f["expires_at"]
    db.commit()
    return acc


# ---------------------------------------------------------------- Provider API 客户端
class Client:
    """极简 GitHub / Gitee REST 客户端(只封装本平台用到的几个接口)。"""

    def __init__(self, provider: str, token: str):
        self.provider = provider
        self.token = token
        self.base = "https://api.github.com" if provider == "github" else "https://gitee.com/api/v5"

    def _req(self, method: str, path: str, **kw) -> requests.Response:
        headers = {"User-Agent": UA, "Accept": "application/vnd.github+json" if self.provider == "github" else "application/json"}
        params = dict(kw.pop("params", {}) or {})
        if self.provider == "github":
            headers["Authorization"] = f"Bearer {self.token}"
        else:
            params["access_token"] = self.token
        try:
            r = requests.request(method, self.base + path, headers=headers, params=params, timeout=TIMEOUT, **kw)
        except requests.RequestException as e:
            raise OAuthError(f"请求 {self.provider} 失败: {e}") from e
        if r.status_code == 401:
            raise OAuthError(f"{self.provider} 令牌无效或已过期,请重新连接账号")
        if r.status_code >= 400:
            try:
                msg = r.json().get("message") or r.text[:200]
            except ValueError:
                msg = r.text[:200]
            raise OAuthError(f"{self.provider} 返回 {r.status_code}: {msg}")
        return r

    # ---- 用户
    def me(self) -> dict:
        j = self._req("GET", "/user").json()
        return {"login": j.get("login"), "name": j.get("name"), "avatar_url": j.get("avatar_url")}

    # ---- 仓库
    def list_repos(self, page: int = 1, per_page: int = 100) -> list[dict]:
        if self.provider == "github":
            j = self._req("GET", "/user/repos", params={"per_page": per_page, "page": page, "sort": "updated", "affiliation": "owner,collaborator,organization_member"}).json()
        else:
            j = self._req("GET", "/user/repos", params={"per_page": per_page, "page": page, "sort": "updated"}).json()
        out = []
        for r in j:
            out.append(
                {
                    "full_name": r.get("full_name") or f"{(r.get('owner') or {}).get('login')}/{r.get('name')}",
                    "name": r.get("name"),
                    "owner": (r.get("owner") or {}).get("login"),
                    "private": bool(r.get("private")),
                    "clone_url": r.get("clone_url") or r.get("html_url", "") + ".git",
                    "html_url": r.get("html_url"),
                    "default_branch": r.get("default_branch"),
                    "description": r.get("description"),
                    "updated_at": r.get("updated_at") or r.get("pushed_at"),
                }
            )
        return out

    def list_all_repos(self, max_pages: int = 5) -> list[dict]:
        out: list[dict] = []
        for page in range(1, max_pages + 1):
            batch = self.list_repos(page=page)
            out.extend(batch)
            if len(batch) < 100:
                break
        return out

    def create_repo(self, name: str, private: bool = True, description: str | None = None) -> dict:
        body = {"name": name, "private": private, "auto_init": True}
        if description:
            body["description"] = description
        r = self._req("POST", "/user/repos", json=body if self.provider == "github" else None, data=None if self.provider == "github" else body).json()
        return {
            "full_name": r.get("full_name"),
            "clone_url": r.get("clone_url") or r.get("html_url", "") + ".git",
            "html_url": r.get("html_url"),
            "default_branch": r.get("default_branch"),
        }

    # ---- 分支
    def branch_sha(self, owner: str, repo: str, branch: str) -> str:
        if self.provider == "github":
            j = self._req("GET", f"/repos/{owner}/{repo}/git/ref/heads/{branch}").json()
            return j["object"]["sha"]
        j = self._req("GET", f"/repos/{owner}/{repo}/branches/{branch}").json()
        return j["commit"]["sha"]

    def create_branch(self, owner: str, repo: str, new_branch: str, from_branch: str) -> dict:
        if self.provider == "github":
            sha = self.branch_sha(owner, repo, from_branch)
            j = self._req("POST", f"/repos/{owner}/{repo}/git/refs", json={"ref": f"refs/heads/{new_branch}", "sha": sha}).json()
            return {"name": new_branch, "sha": j.get("object", {}).get("sha", sha)}
        j = self._req("POST", f"/repos/{owner}/{repo}/branches", data={"refs": from_branch, "branch_name": new_branch}).json()
        return {"name": j.get("name", new_branch), "sha": (j.get("commit") or {}).get("sha")}

    def delete_branch(self, owner: str, repo: str, branch: str) -> None:
        if self.provider == "github":
            self._req("DELETE", f"/repos/{owner}/{repo}/git/refs/heads/{branch}")
            return
        # Gitee v5 没有删除分支的公开接口
        raise OAuthError("Gitee 暂不支持通过 API 删除分支,请在 Gitee 网页操作")

    # ---- Webhook
    def create_webhook(self, owner: str, repo: str, url: str, secret: str) -> str:
        """创建 push webhook,返回其 id。若同 URL 已存在则复用。"""
        for h in self.list_webhooks(owner, repo):
            if h.get("url") == url:
                return str(h["id"])
        if self.provider == "github":
            j = self._req(
                "POST",
                f"/repos/{owner}/{repo}/hooks",
                json={"name": "web", "active": True, "events": ["push"], "config": {"url": url, "content_type": "json", "secret": secret, "insecure_ssl": "0"}},
            ).json()
        else:
            j = self._req("POST", f"/repos/{owner}/{repo}/hooks", data={"url": url, "password": secret, "push_events": "true"}).json()
        return str(j["id"])

    def list_webhooks(self, owner: str, repo: str) -> list[dict]:
        j = self._req("GET", f"/repos/{owner}/{repo}/hooks").json()
        out = []
        for h in j:
            url = (h.get("config") or {}).get("url") if self.provider == "github" else h.get("url")
            out.append({"id": h.get("id"), "url": url})
        return out

    def delete_webhook(self, owner: str, repo: str, hook_id: str) -> None:
        try:
            self._req("DELETE", f"/repos/{owner}/{repo}/hooks/{hook_id}")
        except OAuthError as e:
            if "404" not in str(e):
                raise
