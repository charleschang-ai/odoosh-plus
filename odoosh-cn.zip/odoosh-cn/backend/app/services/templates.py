"""黄金模板库:同一租户 PG 内,按 (Odoo 版本, 版本类型, 镜像模式, 镜像 id) 维护一份「已装好 base 的空库」。

首次创建某种组合的实例时,先把 base 装进模板库(1~3 分钟,与原来一样);之后同组合的实例
直接 `CREATE DATABASE … TEMPLATE odoosh_tpl_*`(秒级)+ 复制模板 filestore,创建耗时从分钟降到秒。

设计要点
- 模板库的对象归属专用角色 odoosh_tpl(它不拥有任何 database,所以对新库执行
  REASSIGN OWNED BY odoosh_tpl TO <实例用户> 时不会波及共享对象);模板库本身 OWNER postgres。
- 建好后置 datistemplate=true / datallowconn=false:既能当模板,又保证没有连接(CREATE DATABASE 的前提)。
- 模板名带镜像 id 前 8 位:镜像更新(Odoo 小版本升级)后自动用新模板,旧模板惰性清理。
- 模板 filestore 放 tenants/<slug>/templates/<tpl>/filestore/filestore/<tpl>,创建实例时复制到实例 filestore/<db_name>。
"""

import logging
import os
import re
import time

from docker.types import Mount

from ..config import settings
from ..models import Environment, Tenant
from . import dockerx

log = logging.getLogger("odoosh.templates")

TPL_ROLE = "odoosh_tpl"


def template_name(version: str, edition: str, mode: str, image_id: str) -> str:
    v = re.sub(r"[^0-9]", "", str(version)) or "0"
    return f"odoosh_tpl_{v}_{(edition or 'community')[:3]}_{(mode or 'official')[:3]}_{image_id[:8]}"


def _image_short_id(tag: str) -> str:
    try:
        return dockerx.client().images.get(tag).id.split(":")[-1][:12]
    except Exception:  # noqa: BLE001
        return "unknown"


def template_dir(t: Tenant, tpl: str, host: bool = False) -> str:
    from .orchestrator import tenant_dir

    return os.path.join(tenant_dir(t, host), "templates", tpl)


def _psql(pg, sql: str, database: str = "postgres") -> tuple[int, str]:
    from .orchestrator import _psql as p

    return p(pg, sql, database)


def template_exists(pg, tpl: str) -> bool:
    code, out = _psql(pg, f"SELECT 1 FROM pg_database WHERE datname='{tpl}' AND datistemplate")
    return code == 0 and "(1 row)" in out


def ensure_tpl_role(pg) -> None:
    code, out = _psql(pg, f"SELECT 1 FROM pg_roles WHERE rolname='{TPL_ROLE}'")
    if "(0 rows)" in out:
        pw = dockerx.rand_password()
        code, out = _psql(pg, f"CREATE ROLE {TPL_ROLE} LOGIN PASSWORD '{pw}' NOSUPERUSER NOCREATEDB")
        if code != 0:
            raise RuntimeError(f"创建模板角色失败: {out}")


def _tpl_password(pg) -> str:
    """每次建模板时重置模板角色口令(不持久化),用完即弃。"""
    pw = dockerx.rand_password()
    code, out = _psql(pg, f"ALTER ROLE {TPL_ROLE} WITH PASSWORD '{pw}'")
    if code != 0:
        raise RuntimeError(f"设置模板角色口令失败: {out}")
    return pw


def build_template(pg, t: Tenant, e: Environment, tag: str, uid: int, core_addons: str, tpl: str,
                   say=log.info, progress=None, mem_mb: int | None = None, cpus: float | None = None) -> None:
    """在租户 PG 内创建模板库并用一次性容器安装 base。失败抛异常(调用方回退到直接安装)。"""
    from . import orchestrator as orch

    ensure_tpl_role(pg)
    pw = _tpl_password(pg)
    # 若上次半途而废留下同名库,先清掉
    _psql(pg, f"UPDATE pg_database SET datistemplate=false, datallowconn=true WHERE datname='{tpl}'")
    _psql(pg, f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='{tpl}'")
    _psql(pg, f"DROP DATABASE IF EXISTS {tpl}")
    code, out = _psql(pg, f"CREATE DATABASE {tpl} OWNER postgres ENCODING 'UTF8' TEMPLATE template0")
    if code == 0:
        orch.enable_pg_extensions(pg, tpl, say)  # 模板库带上扩展,之后从模板克隆的实例库自动继承
    if code != 0:
        raise RuntimeError(f"创建模板库失败: {out}")
    # PG15+ public schema 默认不给非 owner CREATE 权限
    for sql in (f"GRANT ALL ON DATABASE {tpl} TO {TPL_ROLE}", f"GRANT ALL ON SCHEMA public TO {TPL_ROLE}"):
        code, out = _psql(pg, sql, tpl if "SCHEMA" in sql else "postgres")
        if code != 0:
            raise RuntimeError(f"授权模板角色失败: {out}")

    # 模板专用目录:filestore + 配置 + 空 addons
    d = template_dir(t, tpl)
    dh = template_dir(t, tpl, host=True)
    for sub in ("filestore", "config", "addons"):
        os.makedirs(os.path.join(d, sub), exist_ok=True)
    addons_path = f"/mnt/enterprise,{core_addons},/mnt/extra-addons" if e.edition == "enterprise" else f"{core_addons},/mnt/extra-addons"
    conf = f"""[options]
; OdooshCN 模板库初始化配置 {tpl}
db_host = {orch.pg_container_name(t)}
db_port = 5432
db_user = {TPL_ROLE}
db_password = {pw}
db_name = {tpl}
dbfilter = ^{tpl}$
list_db = False
addons_path = {addons_path}
data_dir = /var/lib/odoo
workers = 0
max_cron_threads = 0
without_demo = all
log_level = warn
"""
    with open(os.path.join(d, "config", "odoo.conf"), "w", encoding="utf-8") as f:
        f.write(conf)
    from .fsutil import chown_tree

    chown_tree(d, uid)
    mounts = [
        Mount("/var/lib/odoo", os.path.join(dh, "filestore"), type="bind"),
        Mount("/mnt/extra-addons", os.path.join(dh, "addons"), type="bind", read_only=True),
        Mount("/etc/odoo/odoo.conf", os.path.join(dh, "config", "odoo.conf"), type="bind", read_only=True),
    ]
    if e.edition == "enterprise" and e.enterprise_path:
        from . import enterprise

        mounts.append(Mount("/mnt/enterprise", enterprise.to_host_path(e.enterprise_path), type="bind", read_only=True))

    say(f"首次使用该组合({e.odoo_version} / {e.edition} / {e.base_mode}):先在模板库 {tpl} 安装 base(约 1~3 分钟,之后同类实例秒级创建)")
    t0 = time.time()
    code, logs = orch.run_oneoff(
        t, e, tag, ["odoo", "-c", "/etc/odoo/odoo.conf", "-d", tpl, "-i", "base", "--stop-after-init"],
        suffix="tplinit", timeout=1800, on_tick=progress, mem_mb=mem_mb, cpus=cpus, mounts=mounts,
    )
    if code != 0:
        say("模板库初始化失败,容器输出:\n" + logs)
        _psql(pg, f"DROP DATABASE IF EXISTS {tpl}")
        raise RuntimeError("模板库初始化失败")
    # 冻结为模板:不允许连接、标记 template
    code, out = _psql(pg, f"UPDATE pg_database SET datistemplate=true, datallowconn=false WHERE datname='{tpl}'")
    if code != 0:
        raise RuntimeError(f"标记模板库失败: {out}")
    say(f"模板库 {tpl} 就绪(耗时 {int(time.time() - t0)}s)")


def create_from_template(pg, t: Tenant, e: Environment, tpl: str, uid: int, say=log.info) -> None:
    """用模板库创建实例库:CREATE DATABASE … TEMPLATE + 归属改为实例用户 + 复制模板 filestore。"""
    from . import orchestrator as orch

    code, out = _psql(pg, f"CREATE DATABASE {e.db_name} OWNER {e.db_user} ENCODING 'UTF8' TEMPLATE {tpl}")
    if code != 0:
        raise RuntimeError(f"从模板创建数据库失败: {out}")
    code, out = _psql(pg, f"REASSIGN OWNED BY {TPL_ROLE} TO {e.db_user}", e.db_name)
    if code != 0:
        raise RuntimeError(f"移交数据库对象归属失败: {out}")
    _psql(pg, f"GRANT ALL ON SCHEMA public TO {e.db_user}", e.db_name)
    # filestore:模板 filestore/filestore/<tpl> → 实例 filestore/filestore/<db_name>
    src = os.path.join(template_dir(t, tpl), "filestore", "filestore", tpl)
    dst = os.path.join(orch.env_dir(t, e), "filestore", "filestore", e.db_name)
    if os.path.isdir(src):
        from .fsutil import chown_tree, copy_tree

        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if os.path.isdir(dst):
            import shutil

            shutil.rmtree(dst, ignore_errors=True)
        copy_tree(src, dst, link_ok=True)  # 模板与实例同镜像同 uid:硬链接
        chown_tree(os.path.dirname(dst), uid)
    say(f"已从模板库 {tpl} 创建数据库 {e.db_name}")


def gc_old_templates(pg, keep: set[str]) -> None:
    """删除与 keep 中模板「同组合(版本/类型/模式)但镜像 id 不同」的旧模板库(镜像升级后遗留);其他组合的模板不动。"""
    code, out = _psql(pg, "SELECT datname FROM pg_database WHERE datname LIKE 'odoosh_tpl_%' AND datistemplate")
    if code != 0:
        return
    prefixes = {k.rsplit("_", 1)[0] + "_" for k in keep}
    for ln in out.splitlines():
        name = ln.strip()
        if name.startswith("odoosh_tpl_") and name not in keep and any(name.startswith(pf) for pf in prefixes):
            _psql(pg, f"UPDATE pg_database SET datistemplate=false WHERE datname='{name}'")
            _psql(pg, f"DROP DATABASE IF EXISTS {name}")
            log.info("清理旧模板库 %s", name)


def enabled() -> bool:
    from ..db import SessionLocal
    from ..routers.settings import get_setting

    with SessionLocal() as db:
        return (get_setting(db, "env.use_template_db") or "1") == "1"


def resolve(tag: str, e: Environment) -> str:
    return template_name(e.odoo_version, e.edition or "community", e.base_mode or "official", _image_short_id(tag))
