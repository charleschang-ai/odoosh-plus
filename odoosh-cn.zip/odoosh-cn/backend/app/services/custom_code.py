"""无 git 实例的定制代码通道:把 Odoo 模块放进实例 addons 目录,并支持在线浏览 / 编辑。

每个实例都有一个可写 addons 目录(env_dir/addons),读写挂载到容器 /mnt/custom-addons(无仓库实例同时也是
/mnt/extra-addons;Git 实例的 /mnt/extra-addons 是只读的仓库检出,定制目录排在 addons_path 末尾,同名模块仓库优先)。
四种入库方式并存,后端只负责"放进 addons",互不冲突:
  A. 直接放目录:有服务器权限的人把模块拷进宿主机上的该目录(界面显示路径),平台扫描即认。
  B. 上传压缩包:上传 zip → 解压 → 按模块合并进 addons。同名模块两种策略(见 merge_zip 的 mode):
     replace = 整目录替换(默认,干净);merge = 只覆盖包里有的文件,保留自己后加的文件。
  C. 新建模块骨架:scaffold_module 直接生成一个能装能跑的模块(模型 + 视图 + 菜单 + 权限)。
  D. 在线编辑:list_tree / read_file / write_file / create_entry / delete_entry / rename_entry
     + save_upload_file(往模块里塞图片等零散二进制文件)。

放好后重启实例(orchestrator.restart)让 Odoo 认到模块(重启 / 部署后自动 update_list 登记新模块,见
refresh_module_list_if_needed);改了模型/视图则走「升级模块」;「部署最新」的 update_all 也会把定制目录里改过的模块一并 -u。
安全边界:所有路径经 _resolve 归一(realpath 后必须仍在 addons 内,拦 ../ 与软链);
可写文件按 TEXT_EXT 白名单;单文件 MAX_EDIT_BYTES;写完 chown 给容器内 odoo uid。
"""

import ast
import csv
import hashlib
import io
import logging
import os
import re
import shutil
import time
import xml.etree.ElementTree as ET
import zipfile

from ..models import Environment, Tenant
from . import orchestrator as orch

log = logging.getLogger("odoosh.custom_code")


class QuotaError(ValueError):
    """超出实例代码目录配额(路由层转 413,与普通参数错误区分开)。"""


class ConflictError(ValueError):
    """并发冲突:文件在客户端编辑期间被别处改过(路由层转 409)。"""


def addons_dir(t: Tenant, e: Environment) -> str:
    """实例定制 addons 目录(api 容器内可读写路径),挂载到容器 /mnt/custom-addons(无仓库实例也即 /mnt/extra-addons)。"""
    return os.path.join(orch.env_dir(t, e), "addons")


def host_addons_dir(t: Tenant, e: Environment) -> str:
    """宿主机上的同一目录(给有服务器权限的人看往哪拷代码)。"""
    return os.path.join(orch.env_dir(t, e, host=True), "addons")


def _has_modules(d: str) -> bool:
    try:
        return os.path.isdir(d) and any(
            os.path.isfile(os.path.join(d, n, "__manifest__.py")) for n in os.listdir(d)
        )
    except OSError:
        return False


def _module_names(d: str) -> list[str]:
    """目录下的模块名。软链目录一律不算模块 —— 否则 `ln -s /别人的目录 mymod` 会被
    当成本实例的模块列出来,进而被打包下载(os.walk 对顶层软链是会走进去的)。"""
    if not os.path.isdir(d):
        return []
    return [n for n in sorted(os.listdir(d))
            if not os.path.islink(os.path.join(d, n))
            and os.path.isfile(os.path.join(d, n, "__manifest__.py"))]


# ---------------------------------------------------------------- 部署快照:定制目录不在 git 里,靠内容指纹判断「上次部署后改过什么」
SNAPSHOT_FILE = ".odoosh-deployed.json"  # 放 env_dir(不在 addons 里:不进文件树 / 下载包 / 配额)


def module_hashes(t: Tenant, e: Environment) -> dict[str, str]:
    """定制目录里每个模块的内容指纹 {模块名: sha1}:按相对路径 + 文件内容,跳过软链 / SKIP_DIRS / .pyc。模块都很小,直接读内容。"""
    d = addons_dir(t, e)
    out: dict[str, str] = {}
    for name in _module_names(d):
        h = hashlib.sha1()
        base = os.path.join(d, name)
        for r, dirs, files in os.walk(base):
            dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS and not os.path.islink(os.path.join(r, x)))
            for fn in sorted(files):
                fp = os.path.join(r, fn)
                if fn.endswith((".pyc", ".odoosh-tmp")) or os.path.islink(fp):
                    continue
                h.update(os.path.relpath(fp, base).encode("utf-8", "replace") + b"\0")
                try:
                    with open(fp, "rb") as f:
                        for chunk in iter(lambda: f.read(65536), b""):
                            h.update(chunk)
                except OSError:
                    continue
                h.update(b"\0")
        out[name] = h.hexdigest()
    return out


def _snapshot_path(t: Tenant, e: Environment) -> str:
    return os.path.join(orch.env_dir(t, e), SNAPSHOT_FILE)


def load_snapshot(t: Tenant, e: Environment) -> dict[str, str]:
    """上次部署 / 升级成功时的模块指纹;没有则 {}。"""
    try:
        import json

        with open(_snapshot_path(t, e), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_snapshot(t: Tenant, e: Environment, hashes: dict[str, str] | None = None) -> None:
    """部署 / 升级模块成功后记下当前指纹,下次只对改过的模块 -u。失败只记日志。"""
    import json

    try:
        p = _snapshot_path(t, e)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(hashes if hashes is not None else module_hashes(t, e), f, ensure_ascii=False, indent=0)
        os.replace(tmp, p)
    except OSError as ex:
        log.warning("写定制代码部署快照失败(实例 %s): %s", e.id, ex)


def custom_changes(t: Tenant, e: Environment) -> dict:
    """相对上次快照的差异:{changed: [改过的], new: [快照里没有的], removed: [目录里没了的], hashes: 当前指纹}。
    从没做过快照时,所有模块都算 new。"""
    cur = module_hashes(t, e)
    old = load_snapshot(t, e)
    return {
        "changed": sorted(n for n, h in cur.items() if n in old and old[n] != h),
        "new": sorted(n for n in cur if n not in old),
        "removed": sorted(n for n in old if n not in cur),
        "hashes": cur,
    }


# ---------------------------------------------------------------- 让 Odoo「应用」列表认到新放进来的模块
# Odoo 只在 -i/-u 或手动「更新应用列表」(要开开发者模式)时扫描 addons 目录;单纯重启不会把新目录登记进
# ir_module_module,于是「AI 写了模块 → 重启 → 应用里找不到」。这里在重启 / 部署后自动补一次 update_list。
def _db_module_names(t: Tenant, e: Environment, dbname: str) -> set[str] | None:
    pg = orch.dockerx.get_container(orch.pg_container_name(t))
    if not pg or pg.status != "running":
        return None
    code, out = orch._psql(pg, "COPY (SELECT name FROM ir_module_module) TO STDOUT", dbname)
    if code != 0:
        return None
    return {ln.strip() for ln in out.splitlines() if ln.strip()}


def refresh_module_list_if_needed(t: Tenant, e: Environment, db, say=log.info) -> list[str]:
    """定制目录 / 仓库检出里有 Odoo 库还不认识的模块时,起一次性容器跑 update_list 登记进「应用」列表(主库 + 附加库)。
    返回登记了的模块名。任何失败只记日志,不影响调用方(重启 / 部署)的结果。"""
    try:
        from . import databases as dbsvc
        from . import deploy as deploysvc

        on_disk = set(_module_names(addons_dir(t, e)))
        if e.code_path and os.path.isdir(e.code_path):
            on_disk |= set(deploysvc.modules_in(e.code_path))
        if not on_disk:
            return []
        dbs = dbsvc.all_db_names(db, e) or ([e.db_name] if e.db_name else [])
        todo: list[str] = []
        for dbname in dbs:
            known = _db_module_names(t, e, dbname)
            if known is None:
                continue
            missing = sorted(on_disk - known)
            if not missing:
                continue
            say(f"[{dbname}] 新模块 {', '.join(missing[:8])}{'…' if len(missing) > 8 else ''} 还未登记,更新应用列表…")
            tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
            script = "env['ir.module.module'].update_list(); env.cr.commit(); print('ODOOSH_UPDATE_LIST_OK')"
            code, out = orch.run_oneoff(
                t, e, tag, ["bash", "-c", f"echo \"{script}\" | odoo shell -c /etc/odoo/odoo.conf -d {dbname} --no-http"],
                suffix="modlist", timeout=300)
            if code == 0 and "ODOOSH_UPDATE_LIST_OK" in (out or ""):
                say(f"[{dbname}] 应用列表已更新,可在 Odoo「应用」里安装:{', '.join(missing[:8])}")
                todo += missing
            else:
                say(f"[{dbname}] 更新应用列表失败(退出码 {code}),请在 Odoo 开发者模式下手动「更新应用列表」:\n" + (out or "")[-600:])
        return todo
    except Exception as ex:  # noqa: BLE001
        log.warning("更新应用列表失败(实例 %s): %s", e.id, ex)
        say(f"更新应用列表失败:{ex}")
        return []


def list_modules(t: Tenant, e: Environment) -> list[dict]:
    """当前 addons 目录里的模块 [{name, version}](供详情页展示 / 扫描)。"""
    d = addons_dir(t, e)
    out: list[dict] = []
    for n in _module_names(d):
        ver = ""
        try:
            data = ast.literal_eval(open(os.path.join(d, n, "__manifest__.py"), encoding="utf-8").read())
            if isinstance(data, dict):
                ver = str(data.get("version", ""))
        except Exception:  # noqa: BLE001
            pass
        out.append({"name": n, "version": ver})
    return out


def _safe_extract(zip_path: str, dest: str, max_bytes: int = 0, max_files: int = 0) -> int:
    """解压 zip 到 dest,返回实际写出的字节数。三重防护:

    1. 路径穿越(zip slip):每个成员归一化后必须仍在 dest 内。
    2. 文件数上限。
    3. **解压后体积上限,边写边实际计量** —— 不能只看 zip 头里的 file_size,那是压缩包自己声明的、
       可以伪造;42.zip 这类炸弹正是靠极高压缩比,小小一个包解出几十 GB 撑爆宿主盘。
    自己逐成员写而不用 extractall,也顺带避免 extractall 造出目录以外的东西。"""
    root = os.path.realpath(dest)
    written = 0
    with zipfile.ZipFile(zip_path) as z:
        infos = z.infolist()
        if max_files and len(infos) > max_files:
            raise QuotaError(f"压缩包内有 {len(infos)} 个文件,超过上限 {max_files}")
        declared = sum(i.file_size for i in infos)
        if max_bytes and declared > max_bytes:  # 快速拒绝(声明值可伪造,故下面还要实际计量)
            raise QuotaError(f"压缩包解压后约 {declared // 1024 // 1024}MB,超过上限 {max_bytes // 1024 // 1024}MB")
        for m in infos:
            p = os.path.realpath(os.path.join(dest, m.filename))
            if p != root and not p.startswith(root + os.sep):
                raise ValueError(f"压缩包含非法路径:{m.filename}")
            if m.is_dir():
                os.makedirs(p, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with z.open(m) as src, open(p, "wb") as dst:
                while True:
                    chunk = src.read(64 * 1024)
                    if not chunk:
                        break
                    written += len(chunk)
                    if max_bytes and written > max_bytes:
                        raise QuotaError(
                            f"压缩包解压后超过上限 {max_bytes // 1024 // 1024}MB(已写 {written // 1024 // 1024}MB),"
                            "疑似压缩炸弹或包里带了不该提交的大文件")
                    dst.write(chunk)
    return written


def _module_root(d: str) -> str | None:
    """定位解压内容里的模块根:模块直接在 d 下 → d;整包被套了一层单目录 → 该子目录;都不是 → None。"""
    if _has_modules(d):
        return d
    try:
        entries = [n for n in os.listdir(d) if os.path.isdir(os.path.join(d, n))]
    except OSError:
        return None
    if len(entries) == 1:
        sub = os.path.join(d, entries[0])
        if _has_modules(sub):
            return sub
    return None


def _chown_tree(path: str, uid: int) -> None:
    try:
        os.chown(path, uid, uid)
        for r, dirs, files in os.walk(path):
            for n in dirs + files:
                try:
                    os.chown(os.path.join(r, n), uid, uid)
                except OSError:
                    pass
    except OSError as ex:
        log.warning("chown %s → %s 失败: %s", path, uid, ex)


def _strip_symlinks(root: str) -> int:
    """删掉目录树里所有软链(目录和文件)。返回删掉的个数。

    平台自己从不在 addons 里建软链,但学生在实例 Shell 里对这个目录有写权限,可以建。
    留着的话,后续的合并复制会顺着它写到 addons 之外 —— 而平台数据目录整个 rw 挂在
    api 容器里,那等于让学生覆盖别的实例的 odoo.conf / certs。"""
    n = 0
    for r, dirs, files in os.walk(root):
        for name in list(dirs):
            p = os.path.join(r, name)
            if os.path.islink(p):
                os.unlink(p)
                dirs.remove(name)  # 不再往里走(它已经没了)
                n += 1
        for name in files:
            p = os.path.join(r, name)
            if os.path.islink(p):
                os.unlink(p)
                n += 1
    return n


def _merge_into(src: str, module: str, adir: str, uid: int) -> None:
    """把 src 目录逐文件合并进 addons/<module>/:同名覆盖,其余保留。

    不能用 shutil.copytree(dirs_exist_ok=True) —— 目标里若有软链目录,copytree 会顺着它
    把文件写到 addons 外面。这里每个目标路径都过 _resolve(realpath 后必须仍在 addons 内)。"""
    for r, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(r, d))]
        for n in files:
            sp = os.path.join(r, n)
            if os.path.islink(sp):
                continue
            rel = os.path.relpath(sp, src).replace(os.sep, "/")
            dp = _resolve(adir, f"{module}/{rel}")  # 越界直接抛 ValueError,整批上传失败
            _makedirs_owned(os.path.dirname(dp), adir, uid)
            shutil.copyfile(sp, dp)
            _chown_one(dp, uid)


def merge_zip(t: Tenant, e: Environment, zip_path: str, mode: str = "replace", db=None) -> dict:
    """解压 zip 并按模块合并进实例 addons。包里没有的模块一律保留不动。用完删 zip。

    同名模块的处理由 mode 决定 —— 这是「上传」与「在线编辑」共存的关键:
      replace(默认):整目录替换。包里删掉的文件这边也没了,状态最干净;但在线编辑后又传同名包会覆盖掉自己的改动。
      merge:只覆盖包里有的文件,自己在模块里新加的文件保留。适合「传了个基础包,再自己加文件」的教学流程。
    返回 {"new": [...], "updated": [...], "mode": ...};压缩包里没有模块则抛 ValueError。"""
    if mode not in ("replace", "merge"):
        raise ValueError("mode 只能是 replace 或 merge")
    adir = addons_dir(t, e)
    os.makedirs(adir, exist_ok=True)
    lim = limits(db)
    tmp = os.path.join(orch.env_dir(t, e), ".upload_tmp")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    try:
        # 解压阶段就按实际写出量掐断(防压缩炸弹);上限用实例配额,超了整批拒绝
        _safe_extract(zip_path, tmp, max_bytes=lim["max_bytes"], max_files=lim["max_files"])
        root = _module_root(tmp)
        if not root:
            raise ValueError("压缩包里没有 Odoo 模块(缺少含 __manifest__.py 的模块目录)")
        new: list[str] = []
        updated: list[str] = []
        uid = orch.env_odoo_uid(e)
        for m in _module_names(root):
            src, dst = os.path.join(root, m), os.path.join(adir, m)
            if os.path.islink(dst):
                # 模块目录本身被换成了软链:直接摘掉,当作新模块处理(不能 rmtree,那会报错;
                # 也不能 move 进去,那会写到软链目标里)
                os.unlink(dst)
                log.warning("实例 %s 的模块目录 %s 是软链,已摘除后重建", e.id, m)
            if os.path.exists(dst):
                updated.append(m)
                if mode == "merge":
                    _strip_symlinks(dst)      # 先清掉预埋的软链
                    _merge_into(src, m, adir, uid)  # 再逐文件校验路径后复制
                    continue
                shutil.rmtree(dst, ignore_errors=True)  # replace:整目录替换,不残留旧文件
            else:
                new.append(m)
            shutil.move(src, dst)
        _chown_tree(adir, uid)
        # 合并后再核一次总量:单个包没超,但累加到已有代码上可能超
        check_quota(db, t, e)
        log.info("实例 %s 合并定制代码(%s):新增 %s,更新 %s", e.id, mode, new, updated)
        return {"new": new, "updated": updated, "mode": mode}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        try:
            os.remove(zip_path)
        except OSError:
            pass


def delete_module(t: Tenant, e: Environment, name: str) -> bool:
    """从 addons 目录删掉某个模块(卸载请先在 Odoo 里操作;这里只删代码文件)。"""
    if not name or "/" in name or "\\" in name or name in (".", ".."):
        raise ValueError("非法模块名")
    d = addons_dir(t, e)
    p = os.path.realpath(os.path.join(d, name))
    if os.path.dirname(p) != os.path.realpath(d):
        raise ValueError("非法模块名")
    if os.path.isdir(p):
        shutil.rmtree(p, ignore_errors=True)
        return True
    return False


def build_download_zip(t: Tenant, e: Environment, out_path: str, module: str | None = None) -> int:
    """把 addons 目录打包成 zip 到 out_path,返回字节数。空目录也生成空 zip。
    module 给了就只打包那一个模块(交单个作业 / 分发单个模块用),zip 内仍带模块目录这一层。"""
    adir = addons_dir(t, e)
    base = adir
    if module:
        if module not in _module_names(adir):
            raise ValueError(f"模块 {module} 不存在")
        base = os.path.join(adir, module)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        if os.path.isdir(base):
            # 软链一律不打包(目录不递归、文件不写入)。学生在实例 Shell 里对这个目录有写权限,能建
            #   ln -s /var/lib/odoosh/tenants/别家/envs/x/config/odoo.conf notes.txt
            # 而平台数据目录整个挂在 api 容器里 —— 跟随软链就等于把别的实例的 DB 口令、
            # certs 私钥打包给学生下载。文件树与在线读已各自挡住,这里是最后一处出口。
            for r, dirs, files in os.walk(base):  # followlinks 默认 False,再显式滤掉软链目录
                dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not os.path.islink(os.path.join(r, d))]
                for n in files:
                    if n.endswith(".pyc") or n.endswith(".odoosh-tmp"):
                        continue
                    fp = os.path.join(r, n)
                    if os.path.islink(fp):
                        log.warning("实例 %s 打包时跳过软链 %s", e.id, os.path.relpath(fp, adir))
                        continue
                    arc = os.path.relpath(fp, adir)  # 相对 addons:module 模式下自带模块目录层
                    z.write(fp, arc)
    return os.path.getsize(out_path)


# ================================================================ 在线编辑(文件树 / 读写 / 骨架)
# 可在线编辑的文本类型:覆盖 Odoo 模块常见的全部文件。二进制(图片等)在树里可见,走上传 / 下载通道。
TEXT_EXT = {
    ".py", ".xml", ".csv", ".po", ".pot", ".js", ".ts", ".css", ".scss", ".less",
    ".json", ".txt", ".md", ".rst", ".yml", ".yaml", ".html", ".cfg", ".conf",
    ".sql", ".xsl", ".xslt", ".sh", ".ini",
}
TEXT_NAMES = {".gitignore", ".gitkeep", ".gitattributes", "LICENSE", "COPYING", "Makefile", "requirements.txt"}
SKIP_DIRS = {".git", "__pycache__", "node_modules", ".idea", ".vscode", ".DS_Store"}
MAX_EDIT_BYTES = 2 * 1024 * 1024   # 单文件在线编辑上限(2MB)
MAX_TREE_NODES = 5000              # 文件树节点上限(误传巨型包时保护前端)


def is_editable(name: str) -> bool:
    """该文件名是否支持在线编辑(按扩展名 / 特殊文件名白名单)。"""
    return os.path.splitext(name)[1].lower() in TEXT_EXT or name in TEXT_NAMES


def _resolve(adir: str, rel: str, must_exist: bool = False) -> str:
    """相对路径 → addons 目录内的绝对路径。拦截 ../ 与软链穿越(realpath 后必须仍在 addons 内)。"""
    rel = (rel or "").strip().replace("\\", "/").strip("/")
    if not rel:
        raise ValueError("路径不能为空")
    parts = rel.split("/")
    if any(p in ("", ".", "..") for p in parts):
        raise ValueError("非法路径")
    if any(len(p) > 128 for p in parts) or len(parts) > 16:
        raise ValueError("路径层级或名称过长")
    root = os.path.realpath(adir)
    p = os.path.realpath(os.path.join(root, rel))
    if p != root and not p.startswith(root + os.sep):
        raise ValueError("非法路径(越出实例代码目录)")
    if must_exist and not os.path.exists(p):
        raise ValueError("文件或目录不存在")
    return p


_chown_warned: set[int] = set()


def _chown_one(path: str, uid: int) -> None:
    """把文件属主交给容器内的 odoo 用户。失败不抛(不该因此挡住保存),但**必须留痕** ——
    chown 失败的现象是「保存成功、容器却读不到」,日志里一个字都没有的话根本无从查起。
    按 uid 去重,避免每次保存都刷一行。"""
    try:
        os.chown(path, uid, uid)
    except OSError as ex:
        if uid not in _chown_warned:
            _chown_warned.add(uid)
            log.warning("chown 到 uid=%s 失败(%s):容器内 odoo 用户可能读不到新写的文件,"
                        "现象会是「保存成功但改动不生效」。api 容器需以 root 运行。", uid, ex)


def _makedirs_owned(path: str, adir: str, uid: int) -> None:
    """建目录并把新建的每一层 chown 给容器内 odoo 用户(否则容器里读不到)。"""
    root = os.path.realpath(adir)
    missing, cur = [], os.path.realpath(path)
    while cur != root and cur.startswith(root + os.sep) and not os.path.exists(cur):
        missing.append(cur)
        cur = os.path.dirname(cur)
    os.makedirs(path, exist_ok=True)
    for m in reversed(missing):
        _chown_one(m, uid)


def list_tree(t: Tenant, e: Environment) -> dict:
    """整个 addons 目录的嵌套文件树。顶层含 __manifest__.py 的目录标记 module=True。"""
    adir = addons_dir(t, e)
    os.makedirs(adir, exist_ok=True)
    state = {"count": 0, "truncated": False}

    def walk(d: str, rel: str) -> list[dict]:
        out: list[dict] = []
        try:
            names = os.listdir(d)
        except OSError:
            return out
        # 目录在前、文件在后,各自不区分大小写排序
        names.sort(key=lambda n: (not os.path.isdir(os.path.join(d, n)), n.lower()))
        for n in names:
            if n in SKIP_DIRS or n.endswith(".pyc"):
                continue
            p = os.path.join(d, n)
            if os.path.islink(p):  # 不跟随软链(防环 + 防越界)
                continue
            if state["count"] >= MAX_TREE_NODES:
                state["truncated"] = True
                return out
            state["count"] += 1
            r = f"{rel}/{n}" if rel else n
            if os.path.isdir(p):
                out.append({
                    "name": n, "path": r, "dir": True,
                    "module": rel == "" and os.path.isfile(os.path.join(p, "__manifest__.py")),
                    "children": walk(p, r),
                })
            else:
                try:
                    size = os.path.getsize(p)
                except OSError:
                    size = 0
                out.append({"name": n, "path": r, "dir": False, "size": size, "editable": is_editable(n)})
        return out

    return {"tree": walk(adir, ""), "truncated": state["truncated"], "max_nodes": MAX_TREE_NODES}


def read_file(t: Tenant, e: Environment, rel: str) -> dict:
    """读文件内容。不可编辑(二进制 / 超大 / 非 UTF-8)时 editable=False + reason,不报错。"""
    p = _resolve(addons_dir(t, e), rel, must_exist=True)
    if os.path.isdir(p):
        raise ValueError("这是一个目录,不是文件")
    size = os.path.getsize(p)
    # mtime 回给前端,保存时带回来做乐观并发校验(见 write_file 的 expect_mtime)
    base = {"path": rel, "size": size, "content": None, "editable": False, "mtime": os.path.getmtime(p)}
    if not is_editable(os.path.basename(p)):
        return {**base, "reason": "该文件类型不支持在线编辑(二进制或未知类型),请下载后用本地工具处理"}
    if size > MAX_EDIT_BYTES:
        return {**base, "reason": f"文件 {size // 1024}KB,超过 {MAX_EDIT_BYTES // 1024 // 1024}MB 在线编辑上限"}
    try:
        with open(p, "rb") as f:
            raw = f.read()
        text = raw.decode("utf-8")
        return {**base, "content": text, "editable": True, "lint": lint_content(rel, text)}
    except UnicodeDecodeError:
        return {**base, "reason": "文件不是 UTF-8 编码,无法在线编辑(下载后转码再传回)"}


def write_file(t: Tenant, e: Environment, rel: str, content: str, db=None,
               expect_mtime: float | None = None) -> dict:
    """写文件(原子替换)。父目录不存在会自动建。只允许白名单内的文本类型。

    expect_mtime:读文件时拿到的 mtime。给了就做乐观并发校验 —— 文件在这期间被别人
    (另一个标签页 / 同学 / Shell)改过就抛 ConflictError,避免静默覆盖掉对方的改动。
    返回里带 lint:语法预检结果,**不阻止保存**,由前端提示学生。"""
    adir = addons_dir(t, e)
    p = _resolve(adir, rel)
    name = os.path.basename(p)
    if not is_editable(name):
        raise ValueError(f"不支持在线编辑 {name}(仅限 .py/.xml/.csv/.po/.js/.scss 等文本文件)")
    if os.path.isdir(p):
        raise ValueError("同名目录已存在")
    data = (content or "").encode("utf-8")
    if len(data) > MAX_EDIT_BYTES:
        raise ValueError(f"内容 {len(data) // 1024}KB,超过 {MAX_EDIT_BYTES // 1024 // 1024}MB 上限")

    existed = os.path.isfile(p)
    old_size = os.path.getsize(p) if existed else 0
    if existed and expect_mtime is not None and abs(os.path.getmtime(p) - expect_mtime) > 0.001:
        raise ConflictError("这个文件在你编辑期间被改过了(另一个标签页?)。请刷新拿到最新内容再改,以免覆盖别人的改动")
    check_quota(db, t, e, add_bytes=len(data), add_files=0 if existed else 1, replacing=old_size)

    lim = limits(db)
    if existed:
        save_history(t, e, rel, lim["history_keep"])  # 覆盖前留一份,误改能回滚

    uid = orch.env_odoo_uid(e)
    _makedirs_owned(os.path.dirname(p), adir, uid)
    tmp = f"{p}.odoosh-tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, p)  # 原子:写到一半失败也不会毁掉原文件
    _chown_one(p, uid)
    return {"path": rel, "size": len(data), "mtime": os.path.getmtime(p),
            "lint": lint_content(rel, content or "")}


def create_entry(t: Tenant, e: Environment, rel: str, kind: str = "file", db=None) -> dict:
    """新建空文件或目录。新建 .py 时自动往同目录 __init__.py 补 import(见 _auto_init_import)。"""
    adir = addons_dir(t, e)
    p = _resolve(adir, rel)
    if os.path.exists(p):
        raise ValueError("同名文件或目录已存在")
    uid = orch.env_odoo_uid(e)
    if kind == "dir":
        _makedirs_owned(p, adir, uid)
        return {"path": rel, "dir": True}

    if not is_editable(os.path.basename(p)):
        raise ValueError("只能新建文本文件(.py/.xml/.csv/.po/.js/.scss 等);图片等请用「上传文件」")
    check_quota(db, t, e, add_files=1)
    _makedirs_owned(os.path.dirname(p), adir, uid)
    with open(p, "wb"):
        pass
    _chown_one(p, uid)
    return {"path": rel, "dir": False, "init_updated": _auto_init_import(adir, rel, uid)}


def delete_entry(t: Tenant, e: Environment, rel: str) -> dict:
    """删除文件或目录(目录递归删)。历史版本一并清掉(留着对不上号,只会误导)。
    同时把 __init__.py 里指向它的 import 摘掉 —— 否则模块一加载就 ImportError。"""
    adir = addons_dir(t, e)
    p = _resolve(adir, rel, must_exist=True)
    is_dir = os.path.isdir(p)
    if is_dir:
        shutil.rmtree(p, ignore_errors=True)
    else:
        os.remove(p)
        drop_history(t, e, rel)
    return {"path": rel, "dir": is_dir,
            "init_updated": _auto_init_remove(adir, rel, orch.env_odoo_uid(e))}


def rename_entry(t: Tenant, e: Environment, rel: str, new_rel: str) -> dict:
    """重命名 / 移动(两端都必须在 addons 目录内)。"""
    adir = addons_dir(t, e)
    src = _resolve(adir, rel, must_exist=True)
    dst = _resolve(adir, new_rel)
    if src == dst:
        return {"path": new_rel}
    if os.path.exists(dst):
        raise ValueError("目标路径已存在")
    if os.path.isdir(src) and dst.startswith(src + os.sep):
        raise ValueError("不能把目录移动到它自己里面")
    uid = orch.env_odoo_uid(e)
    _makedirs_owned(os.path.dirname(dst), adir, uid)
    shutil.move(src, dst)
    if not os.path.isdir(dst):
        drop_history(t, e, rel)  # 旧路径的历史对不上新名字了
    # __init__.py 跟着改名走:先摘旧名再补新名,否则旧 import 指向不存在的文件 → ImportError
    removed = _auto_init_remove(adir, rel, uid)
    added = _auto_init_import(adir, new_rel, uid)
    return {"path": new_rel, "init_updated": added or removed}


def save_upload_file(t: Tenant, e: Environment, rel_dir: str, filename: str, data: bytes, db=None) -> dict:
    """上传单个文件到指定目录(图标、图片、xlsx 数据等 zip 之外的零散文件)。"""
    name = os.path.basename((filename or "").replace("\\", "/")).strip()
    if not name or name.startswith("."):
        raise ValueError("非法文件名")
    rel = f"{rel_dir.strip('/')}/{name}" if rel_dir and rel_dir.strip("/") else name
    adir = addons_dir(t, e)
    p = _resolve(adir, rel)
    if os.path.isdir(p):
        raise ValueError("同名目录已存在")
    existed = os.path.isfile(p)
    check_quota(db, t, e, add_bytes=len(data), add_files=0 if existed else 1,
                replacing=os.path.getsize(p) if existed else 0)
    uid = orch.env_odoo_uid(e)
    _makedirs_owned(os.path.dirname(p), adir, uid)
    tmp = f"{p}.odoosh-tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, p)
    _chown_one(p, uid)
    return {"path": rel, "size": len(data)}


# ---------------------------------------------------------------- 新建模块骨架
MODULE_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,62}$")

_SCAFFOLD_MANIFEST = '''{
    "name": "@@LABEL@@",
    "version": "@@VERSION@@",
    "summary": "@@LABEL@@",
    "author": "@@AUTHOR@@",
    "category": "Uncategorized",
    "license": "LGPL-3",
    # 依赖的其它模块。用到销售/库存等功能时把模块技术名加进来
    "depends": ["base"],
    # 需要加载的数据文件,顺序有意义:先权限(security)后视图(views)
    "data": [
        "security/ir.model.access.csv",
        "views/views.xml",
    ],
    # 装了这个模块后能在「应用」里搜到
    "installable": True,
    "application": True,
}
'''

_SCAFFOLD_ROOT_INIT = '''from . import models
'''

_SCAFFOLD_MODELS_INIT = '''from . import models
'''

_SCAFFOLD_MODELS = '''from odoo import api, fields, models


class @@CLASS@@(models.Model):
    # _name 是数据库表名的来源:@@MODEL@@ → 表 @@TABLE@@
    _name = "@@MODEL@@"
    _description = "@@LABEL@@"

    name = fields.Char(string="名称", required=True)
    description = fields.Text(string="说明")
    quantity = fields.Integer(string="数量", default=1)
    price = fields.Float(string="单价")
    total = fields.Float(string="金额", compute="_compute_total", store=True)
    active = fields.Boolean(string="启用", default=True)

    @api.depends("quantity", "price")
    def _compute_total(self):
        # 依赖字段变化时自动重算;store=True 表示结果存进数据库,可以排序 / 搜索
        for rec in self:
            rec.total = rec.quantity * rec.price
'''

_SCAFFOLD_VIEWS = '''<?xml version="1.0" encoding="utf-8"?>
<odoo>

    <!-- 列表视图 -->
    <record id="view_@@SNAKE@@_list" model="ir.ui.view">
        <field name="name">@@MODEL@@.list</field>
        <field name="model">@@MODEL@@</field>
        <field name="arch" type="xml">
            <@@LISTTAG@@ string="@@LABEL@@">
                <field name="name"/>
                <field name="quantity"/>
                <field name="price"/>
                <field name="total"/>
            </@@LISTTAG@@>
        </field>
    </record>

    <!-- 表单视图 -->
    <record id="view_@@SNAKE@@_form" model="ir.ui.view">
        <field name="name">@@MODEL@@.form</field>
        <field name="model">@@MODEL@@</field>
        <field name="arch" type="xml">
            <form string="@@LABEL@@">
                <sheet>
                    <group>
                        <field name="name"/>
                        <field name="active"/>
                    </group>
                    <group>
                        <field name="quantity"/>
                        <field name="price"/>
                        <field name="total"/>
                    </group>
                    <group>
                        <field name="description"/>
                    </group>
                </sheet>
            </form>
        </field>
    </record>

    <!-- 动作:点菜单后打开什么 -->
    <record id="action_@@SNAKE@@" model="ir.actions.act_window">
        <field name="name">@@LABEL@@</field>
        <field name="res_model">@@MODEL@@</field>
        <field name="view_mode">@@VIEWMODE@@</field>
    </record>

    <!-- 菜单:根菜单 → 子菜单 → 动作 -->
    <menuitem id="menu_@@SNAKE@@_root" name="@@LABEL@@" sequence="10"/>
    <menuitem id="menu_@@SNAKE@@" name="@@LABEL@@"
              parent="menu_@@SNAKE@@_root" action="action_@@SNAKE@@" sequence="10"/>

</odoo>
'''

_SCAFFOLD_ACCESS = '''id,name,model_id:id,group_id:id,perm_read,perm_write,perm_create,perm_unlink
access_@@SNAKE@@_user,@@MODEL@@ user,model_@@SNAKE@@,base.group_user,1,1,1,1
'''

_SCAFFOLD_README = '''# @@LABEL@@

平台生成的模块骨架。

## 目录说明

    @@MODULE@@/
      __manifest__.py            模块清单:名称 / 依赖 / 要加载的数据文件
      __init__.py                告诉 Python 加载 models 包
      models/models.py           模型(= 数据库表 + 业务逻辑)
      views/views.xml            视图 / 动作 / 菜单
      security/ir.model.access.csv  访问权限(不写这个,菜单点开会报没权限)

## 改完怎么生效

| 改了什么 | 操作 |
| --- | --- |
| models 里加 / 改字段 | 「升级模块」(要改数据库表结构) |
| views.xml | 「升级模块」 |
| ir.model.access.csv | 「升级模块」 |
| .py 里只改方法体 | 「重启使生效」 |
| 新建的模块第一次安装 | Odoo 里「应用」→ 更新应用列表 → 搜索本模块 → 安装 |
'''


def _scaffold_files(module: str, label: str, version: str, author: str) -> dict[str, str]:
    """按模块名生成骨架文件 {相对路径: 内容}。Odoo 17+ 列表视图标签为 list(16 及以前是 tree)。"""
    model = f"{module}.{module}"
    snake = model.replace(".", "_")
    klass = "".join(w.capitalize() for w in module.split("_")) or "Model"
    try:
        major = int(str(version).split(".")[0])
    except ValueError:
        major = 18
    list_tag = "list" if major >= 17 else "tree"
    view_mode = "list,form" if major >= 17 else "tree,form"
    subs = {
        "@@MODULE@@": module,
        "@@LABEL@@": label,
        "@@VERSION@@": f"{major}.0.1.0.0",
        "@@AUTHOR@@": author,
        "@@MODEL@@": model,
        "@@TABLE@@": snake,
        "@@SNAKE@@": snake,
        "@@CLASS@@": klass,
        "@@LISTTAG@@": list_tag,
        "@@VIEWMODE@@": view_mode,
    }

    def fill(tpl: str) -> str:
        for k, v in subs.items():
            tpl = tpl.replace(k, v)
        return tpl

    return {
        "__manifest__.py": fill(_SCAFFOLD_MANIFEST),
        "__init__.py": fill(_SCAFFOLD_ROOT_INIT),
        "models/__init__.py": fill(_SCAFFOLD_MODELS_INIT),
        "models/models.py": fill(_SCAFFOLD_MODELS),
        "views/views.xml": fill(_SCAFFOLD_VIEWS),
        "security/ir.model.access.csv": fill(_SCAFFOLD_ACCESS),
        "README.md": fill(_SCAFFOLD_README),
    }


def scaffold_module(t: Tenant, e: Environment, name: str, label: str = "", author: str = "") -> dict:
    """在 addons 目录里生成一个可直接安装的模块骨架(模型 + 列表/表单视图 + 菜单 + 权限)。"""
    name = (name or "").strip().lower()
    if not MODULE_NAME_RE.match(name):
        raise ValueError("模块技术名只能用小写字母、数字、下划线,以字母开头(如 school_student)")
    adir = addons_dir(t, e)
    root = _resolve(adir, name)
    if os.path.exists(root):
        raise ValueError(f"模块 {name} 已存在")
    files = _scaffold_files(name, (label or "").strip() or name, e.odoo_version or "18", (author or "").strip() or "OdooshCN")
    uid = orch.env_odoo_uid(e)
    _makedirs_owned(root, adir, uid)
    for rel, content in files.items():
        p = os.path.join(root, rel)
        _makedirs_owned(os.path.dirname(p), adir, uid)
        with open(p, "w", encoding="utf-8") as f:
            f.write(content)
        _chown_one(p, uid)
    log.info("实例 %s 生成模块骨架 %s", e.id, name)
    return {"module": name, "files": sorted(files), "entry": f"{name}/models/models.py"}


# ---------------------------------------------------------------- 升级模块(无 Git 实例的 -u)
def update_modules(env_id: int, modules: str) -> None:
    """对本实例的主库 + 附加库执行 odoo -u <modules>,完成后重建容器拉起。由 jobs.spawn 后台调用。

    改了模型字段 / 视图 / 权限后必须走这条(重启不会重读 XML、也不会改表结构)。
    与 deploy.py 的 -u 相同套路:先停容器 → 逐库一次性容器跑 -u → 再拉起;
    主库失败即判定整体失败,附加库失败只记日志不阻断(代码是同一份,由用户按库处理)。"""
    say = orch.EnvLogger(env_id)
    with orch.SessionLocal() as db:
        e = db.get(Environment, env_id)
        if not e:
            return
        t = db.get(Tenant, e.tenant_id)
        mods = ",".join(m.strip() for m in (modules or "").split(",") if m.strip()) or "all"
        tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
        orch._set_status(env_id, "deploying", f"升级模块 {mods}", progress=5)
        say(f"升级模块:-u {mods}")
        # 先装依赖:被升级的模块可能在加载时 import 新包(requirements.txt 放模块里或定制目录根都行)
        try:
            from . import deploy as deploysvc

            deploysvc.install_requirements(t, e, tag, e.code_path or "", say)
        except Exception as ex:  # noqa: BLE001
            say(f"依赖安装失败,未升级:{ex}")
            orch._set_status(env_id, "failed", f"依赖安装失败:{str(ex)[:150]}", progress=0)
            return

        c = orch.dockerx.get_container(e.container_name or "")
        if c:
            try:
                c.reload()
                if c.status == "running":
                    say("停止容器以升级模块")
                    c.stop(timeout=30)
            except Exception as ex:  # noqa: BLE001
                say(f"停止容器失败(继续尝试升级): {ex}")

        from . import databases as dbsvc

        targets = dbsvc.all_db_names(db, e) or ([e.db_name] if e.db_name else [])
        if not targets:
            orch._set_status(env_id, "failed", "实例还没有数据库", progress=0)
            return

        main_failed = False
        for idx, dbname in enumerate(targets):
            base = 10 + int(idx * 60 / max(1, len(targets)))
            span = max(1, int(60 / max(1, len(targets))))
            orch._progress(env_id, base, f"升级模块 {mods}({dbname})")
            say(f"[{dbname}] -u {mods}(约 1~5 分钟)")
            code, out = orch.run_oneoff(
                t, e, tag,
                ["odoo", "-c", "/etc/odoo/odoo.conf", "-d", dbname, "-u", mods, "--stop-after-init"],
                suffix="upgrade",
                on_tick=lambda i, el, b=base, sp=span: orch._progress(env_id, b + min(sp, int(el / 180.0 * sp))),
            )
            if code != 0:
                say(f"[{dbname}] 升级失败,容器输出:\n" + out[-2000:])
                if dbname == e.db_name:
                    main_failed = True
                    break
                say(f"[{dbname}] 附加库升级失败,继续处理其他库")
            else:
                say(f"[{dbname}] 升级完成")

        if not main_failed:
            save_snapshot(t, e)  # 「部署最新」据此只 -u 之后再改过的模块

        # 无论成败都把容器拉回来:失败时代码还在,用户要能进去看日志改代码
        orch._progress(env_id, 75, "启动容器")
        try:
            c = orch.run_main_container(t, e, tag)
            orch.nginx.connect_web_to_network(e.network_name)
            orch.nginx.reload()
        except Exception as ex:  # noqa: BLE001
            say(f"启动容器失败: {ex}")
            orch._set_status(env_id, "failed", "升级后容器启动失败", progress=0)
            return
        ok = orch._wait_healthy(c, say, on_tick=lambda i: orch._progress(env_id, min(98, 80 + i * 5)))
        if main_failed:
            orch._set_status(env_id, "failed", f"模块 {mods} 升级失败(见日志)", progress=0)
        elif ok:
            say("模块升级完成")
            orch._set_status(env_id, "running", None, progress=100)
        else:
            orch._set_status(env_id, "failed", "升级后未就绪", progress=0)


# ================================================================ 配额(防单个学生撑爆宿主盘)
# 内存 / CPU / PidsLimit 早就有上限,存储一直没有 —— 教学场景一台机带一个班,
# 一个学生传个大包或建一堆文件就能把全班拖下水。四个数都可在「系统设置」里调。
DEFAULT_MAX_BYTES = 200 * 1024 * 1024   # 每实例 addons 总字节
DEFAULT_MAX_FILES = 3000                # 每实例 addons 文件数
DEFAULT_MAX_UPLOAD = 200 * 1024 * 1024  # 单次 zip 上传字节(接收阶段就掐断)
DEFAULT_HISTORY_KEEP = 10               # 每个文件保留几个历史版本


def limits(db) -> dict:
    """从设置读配额;0 = 不限。db 为 None(单元测试 / 无会话场景)时用默认值。"""
    if db is None:
        return {"max_bytes": DEFAULT_MAX_BYTES, "max_files": DEFAULT_MAX_FILES,
                "max_upload": DEFAULT_MAX_UPLOAD, "history_keep": DEFAULT_HISTORY_KEEP}

    def num(key: str, default: int) -> int:
        from ..routers.settings import get_setting
        try:
            return max(0, int((get_setting(db, key) or "").strip() or default))
        except Exception:  # noqa: BLE001
            return default

    return {
        "max_bytes": num("code.max_bytes", DEFAULT_MAX_BYTES),
        "max_files": num("code.max_files", DEFAULT_MAX_FILES),
        "max_upload": num("code.max_upload_bytes", DEFAULT_MAX_UPLOAD),
        "history_keep": num("code.history_keep", DEFAULT_HISTORY_KEEP),
    }


def usage(t: Tenant, e: Environment) -> dict:
    """addons 目录当前占用 {bytes, files}。软链不计(它们不属于本实例)。"""
    total = files = 0
    for r, dirs, names in os.walk(addons_dir(t, e)):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not os.path.islink(os.path.join(r, d))]
        for n in names:
            p = os.path.join(r, n)
            if os.path.islink(p):
                continue
            try:
                total += os.path.getsize(p)
            except OSError:
                continue
            files += 1
    return {"bytes": total, "files": files}


def check_quota(db, t: Tenant, e: Environment, add_bytes: int = 0, add_files: int = 0, replacing: int = 0) -> None:
    """写入前的配额检查。replacing = 被覆盖文件的原大小(不算新增)。超限抛 QuotaError。"""
    lim = limits(db)
    if not lim["max_bytes"] and not lim["max_files"]:
        return
    u = usage(t, e)
    nb = u["bytes"] - replacing + add_bytes
    if lim["max_bytes"] and nb > lim["max_bytes"]:
        raise QuotaError(
            f"代码目录将达 {nb // 1024 // 1024}MB,超过本实例上限 "
            f"{lim['max_bytes'] // 1024 // 1024}MB。请删掉不用的模块,或让管理员调大 code.max_bytes")
    nf = u["files"] + add_files
    if lim["max_files"] and nf > lim["max_files"]:
        raise QuotaError(f"文件数将达 {nf},超过本实例上限 {lim['max_files']} 个")


# ================================================================ 保存前的语法预检
# 学生最痛的循环是:改代码 → 保存 → 升级模块(1~5 分钟)→ 打开 Odoo 报错 → 回来一行行找。
# 这里在「保存」那一刻就把语法错误指出来,把这个循环砍掉。
# 原则:**只提示不拦截** —— 写到一半先存一下是完全正常的需求。
def lint_content(rel: str, content: str) -> list[dict]:
    """轻量语法检查,返回 [{level: error|warn, line, message}];空列表 = 没发现问题。"""
    name = os.path.basename(rel)
    ext = os.path.splitext(name)[1].lower()
    out: list[dict] = []

    if ext == ".py":
        try:
            ast.parse(content, filename=name)
        except SyntaxError as ex:
            return [{"level": "error", "line": ex.lineno or 1,
                     "message": f"Python 语法错误:{ex.msg}"}]
        if name == "__manifest__.py":
            try:
                data = ast.literal_eval(content)
            except (ValueError, SyntaxError):
                return [{"level": "error", "line": 1,
                         "message": "__manifest__.py 必须是一个纯字典字面量 {...},里面不能有变量或函数调用"}]
            if not isinstance(data, dict):
                return [{"level": "error", "line": 1, "message": "__manifest__.py 的内容必须是一个字典 {...}"}]
            if not data.get("name"):
                out.append({"level": "warn", "line": 1, "message": "缺少 name —— Odoo「应用」里会显示不出名字"})
            for key in ("depends", "data"):
                if key in data and not isinstance(data[key], (list, tuple)):
                    out.append({"level": "error", "line": 1, "message": f"{key} 必须是列表,如 [\"base\"]"})

    elif ext in (".xml", ".xsl", ".xslt"):
        try:
            ET.fromstring(content.encode("utf-8"))
        except ET.ParseError as ex:
            line = (getattr(ex, "position", None) or (1, 0))[0]
            out.append({"level": "error", "line": line, "message": f"XML 语法错误:{ex}"})

    elif ext == ".csv":
        rows = [r for r in csv.reader(io.StringIO(content)) if r]
        if rows:
            width = len(rows[0])
            for i, r in enumerate(rows[1:], start=2):
                if len(r) != width:
                    out.append({"level": "error", "line": i,
                                "message": f"第 {i} 行有 {len(r)} 列,但表头是 {width} 列(多半是漏了逗号或多了逗号)"})
                    break
            if name == "ir.model.access.csv":
                head = {h.strip() for h in rows[0]}
                need = {"id", "name", "model_id:id", "perm_read", "perm_write", "perm_create", "perm_unlink"}
                missing = need - head
                if missing:
                    out.append({"level": "warn", "line": 1, "message": f"表头缺少:{', '.join(sorted(missing))}"})

    return out


# ================================================================ 保存历史(误覆盖能回滚)
def _history_root(t: Tenant, e: Environment) -> str:
    """历史版本目录。放在 env_dir 下、addons **之外** —— 不会被挂进容器、不进文件树、不进下载包。"""
    return os.path.join(orch.env_dir(t, e), ".code_history")


def _history_slot(t: Tenant, e: Environment, rel: str) -> str:
    # 用 hash 做目录名:相对路径里有 /,直接当目录名会撞车或再造一层嵌套
    return os.path.join(_history_root(t, e), hashlib.sha1(rel.encode("utf-8")).hexdigest()[:16])


HISTORY_MAX_FILE = 512 * 1024  # 超过这个大小的文件不留历史(历史目录不占 addons 配额,得自己收着)


def save_history(t: Tenant, e: Environment, rel: str, keep: int = DEFAULT_HISTORY_KEEP) -> None:
    """覆盖写之前把旧内容存一份。文件不存在(新建)则什么都不做。失败只记日志,绝不能因此挡住保存。"""
    if keep <= 0:
        return
    try:
        src = _resolve(addons_dir(t, e), rel, must_exist=True)
        if not os.path.isfile(src):
            return
        if os.path.getsize(src) > HISTORY_MAX_FILE:
            return  # 手写的代码不会这么大;留 10 份大文件会让 .code_history 无界增长
        slot = _history_slot(t, e, rel)
        os.makedirs(slot, exist_ok=True)
        with open(os.path.join(slot, "path.txt"), "w", encoding="utf-8") as f:
            f.write(rel)  # 供列表接口显示原始路径
        ts = time.strftime("%Y%m%d-%H%M%S")
        dst, i = os.path.join(slot, ts), 0
        while os.path.exists(dst):  # 同一秒内连续保存
            i += 1
            dst = os.path.join(slot, f"{ts}-{i}")
        shutil.copyfile(src, dst)
        versions = sorted(n for n in os.listdir(slot) if n != "path.txt")
        for old in versions[:-keep] if len(versions) > keep else []:
            try:
                os.remove(os.path.join(slot, old))
            except OSError:
                pass
    except Exception as ex:  # noqa: BLE001
        log.warning("实例 %s 存历史版本失败(%s): %s", e.id, rel, ex)


def list_history(t: Tenant, e: Environment, rel: str) -> list[dict]:
    """某文件的历史版本,新的在前。"""
    slot = _history_slot(t, e, rel)
    if not os.path.isdir(slot):
        return []
    out = []
    for n in sorted((x for x in os.listdir(slot) if x != "path.txt"), reverse=True):
        p = os.path.join(slot, n)
        try:
            out.append({"version": n, "size": os.path.getsize(p),
                        "at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(os.path.getmtime(p)))})
        except OSError:
            continue
    return out


def read_history(t: Tenant, e: Environment, rel: str, version: str) -> str:
    """读某个历史版本的内容。"""
    if not re.fullmatch(r"\d{8}-\d{6}(-\d+)?", version or ""):
        raise ValueError("非法的版本号")
    p = os.path.join(_history_slot(t, e, rel), version)
    if not os.path.isfile(p):
        raise ValueError("该历史版本不存在")
    with open(p, "rb") as f:
        return f.read().decode("utf-8", errors="replace")


def drop_history(t: Tenant, e: Environment, rel: str) -> None:
    """文件被删 / 改名时清掉它的历史(改名后旧历史对不上号,留着只会误导)。"""
    shutil.rmtree(_history_slot(t, e, rel), ignore_errors=True)


# ================================================================ 新建 .py 自动补 __init__.py
def _init_sibling(adir: str, rel: str) -> tuple[str, str, str] | None:
    """(同目录 __init__.py 的相对路径, 绝对路径, 该条目在 import 里的名字);不适用则 None。

    rel 是 .py 文件 → 名字是去掉 .py 的文件名;rel 是目录 → 名字就是目录名(包导入)。"""
    parts = rel.split("/")
    if len(parts) < 2:
        return None
    if rel.endswith(".py"):
        mod = parts[-1][:-3]
        if mod in ("__init__", "__manifest__"):
            return None
    else:
        mod = parts[-1]
    init_rel = "/".join(parts[:-1] + ["__init__.py"])
    p = os.path.join(adir, init_rel)
    if not os.path.isfile(p) or os.path.islink(p):
        return None
    return init_rel, p, mod


def _init_write(p: str, text: str, uid: int) -> None:
    tmp = f"{p}.odoosh-tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, p)
    _chown_one(p, uid)


def _auto_init_remove(adir: str, rel: str, uid: int) -> str | None:
    """删 / 改名 .py(或子包目录)时,把同目录 __init__.py 里对应的 `from . import <名>` 去掉。

    不做这件事的后果很重:文件没了、import 还在 → Odoo 加载模块直接 ImportError,
    **整个模块起不来**,而学生只是删了个自己不要的文件,完全想不到是这个原因。
    只动「单独一行、只导入这一个名字」的那种;`from . import a, b` 这种共享行只摘掉其中一项。
    返回被改动的 __init__.py 相对路径;没改则 None。"""
    got = _init_sibling(adir, rel)
    if not got:
        return None
    init_rel, p, mod = got
    try:
        with open(p, encoding="utf-8") as f:
            lines = f.read().splitlines()
    except (OSError, UnicodeDecodeError):
        return None

    out, changed = [], False
    pat = re.compile(r"^(\s*from\s+\.\s+import\s+)([^#\n]*?)(\s*(?:#.*)?)$")
    for ln in lines:
        m = pat.match(ln)
        if not m:
            out.append(ln)
            continue
        names = [x.strip() for x in m.group(2).split(",") if x.strip()]
        if mod not in names:
            out.append(ln)
            continue
        names.remove(mod)
        changed = True
        if names:  # 共享行:只摘掉这一个,别把同行的其它导入也删了
            out.append(f"{m.group(1)}{', '.join(names)}{m.group(3)}")
        # names 为空 = 整行去掉
    if not changed:
        return None
    _init_write(p, "\n".join(out).rstrip("\n") + "\n", uid)
    return init_rel


def _auto_init_import(adir: str, rel: str, uid: int) -> str | None:
    """在某目录下新建 .py 时,往同目录的 __init__.py 追加 `from . import <名>`。

    Odoo 不会自动发现 .py 文件 —— 学生建了 models/student.py 却忘了这行,模块照样能装,
    但代码根本不加载,而且**没有任何报错**。这是 Odoo 新手最难自己查出来的坑。
    返回被改动的 __init__.py 相对路径;不需要改则返回 None。"""
    if not rel.endswith(".py"):
        return None
    got = _init_sibling(adir, rel)  # 没有 __init__.py 就不擅自造(可能是 static/ 这类非 Python 目录)
    if not got:
        return None
    init_rel, p, mod = got
    try:
        with open(p, encoding="utf-8") as f:
            cur = f.read()
    except (OSError, UnicodeDecodeError):
        return None
    if re.search(rf"^\s*from\s+\.\s+import\s+[^\n#]*\b{re.escape(mod)}\b", cur, re.M):
        return None  # 已经导过了(\b 边界:student 不会被 student2 误判成已导入)
    _init_write(p, (cur.rstrip("\n") + "\n" if cur.strip() else "") + f"from . import {mod}\n", uid)
    return init_rel


# ================================================================ 审计
def audit(db, e: Environment, user, action: str, path: str | None = None,
          detail: str | None = None, size: int | None = None) -> None:
    """记一条代码改动审计(只记写入类动作;读不记,量大且没用)。
    失败只记日志 —— 审计写不进去不该把学生的保存也一起弄失败。"""
    try:
        from ..models_code import CodeEdit

        db.add(CodeEdit(
            environment_id=e.id, tenant_id=e.tenant_id, env_name=e.name,
            user_id=getattr(user, "id", None), username=getattr(user, "username", None),
            action=action, path=(path or None) and str(path)[:512],
            detail=(detail or None) and str(detail)[:512], size=size,
        ))
        db.commit()
    except Exception as ex:  # noqa: BLE001
        log.warning("写代码审计失败(%s %s): %s", action, path, ex)
        try:
            db.rollback()
        except Exception:  # noqa: BLE001
            pass


def last_job_error(e: Environment, lines: int = 40) -> dict:
    """最近一次编排(升级 / 重启)的日志尾部 + 状态。

    学生点「升级模块」失败后,以前只能切到「日志」Tab 自己翻;这里把尾巴直接给编辑器,
    并把看起来像报错的行挑出来 —— 那是他们卡住的第一现场。
    Environment.log 是 EnvLogger 节流落库的最近一次编排日志(deferred 列)。"""
    text = (e.log or "").rstrip("\n")
    rows = text.split("\n") if text else []
    tail = "\n".join(rows[-lines:])
    hits = [ln for ln in rows[-200:] if re.search(r"(?i)error|失败|traceback|exception|critical|not found", ln)]
    return {
        "status": e.status,
        "message": e.status_message,
        "failed": e.status == "failed",
        "tail": tail,
        "errors": hits[-8:],
    }


# ================================================================ 代码补全用的库内元数据
# 从实例**自己的数据库**读 ir_model / ir_model_fields,喂给编辑器的补全。
# 这是网页编辑器能做、本地 IDE 反而做不到的事:补全里出现的是这个库里真实存在的模型和字段,
# 包括学生自己刚建的那个 —— 写错模型名是 Odoo 新手最常见的错误之一,而报错往往指向别处。
# 不做类型推断(那要语言服务器,每个学生 300-600MB),只做「名字对不对」这一层。
_schema_cache: dict[int, tuple[float, dict]] = {}
SCHEMA_TTL = 120.0          # 秒;装完模块想立刻看到新模型可以带 refresh=1 强刷
SCHEMA_MAX_FIELDS = 20000   # 字段总数上限(装满模块的库有上万个字段,别把响应撑爆)


def _pg_query(t: Tenant, sql: str, dbname: str) -> list[list[str]]:
    """在租户 PG 容器里跑一条只读查询,返回按 | 切好的行。查询由平台写死,学生碰不到。"""
    pg = orch.dockerx.get_container(orch.pg_container_name(t))
    if not pg:
        raise RuntimeError("租户数据库容器不在")
    code, out = pg.exec_run(
        ["psql", "-v", "ON_ERROR_STOP=1", "-X", "-q", "-At", "-U", "postgres", "-d", dbname, "-c", sql])
    text = out.decode(errors="ignore")
    if code != 0:
        raise RuntimeError(text.strip()[-300:])
    return [ln.split("|") for ln in text.splitlines() if ln.strip()]


def schema_for(t: Tenant, e: Environment, refresh: bool = False) -> dict:
    """{"models": [{"model","name","fields":[{"name","ttype","relation"}]}], "stale": bool, "reason": str|None}

    实例没起来 / 库还没建 / 查询失败,都返回空列表 + reason,**绝不抛错** ——
    补全拿不到数据只是少了提示,不该让编辑器整个用不了。"""
    now = time.time()
    hit = _schema_cache.get(e.id)
    if hit and not refresh and now - hit[0] < SCHEMA_TTL:
        return hit[1]

    out = {"models": [], "stale": True, "reason": None}
    if not e.db_name:
        out["reason"] = "实例还没有数据库"
        return out
    try:
        # Odoo 16+ 把可翻译字段(含 ir_model.name)改成了 jsonb:{"en_US": "Contact", "zh_CN": "联系人"}。
        # 直接 COALESCE(name,'') 会报 invalid input syntax for type json,所以先看列类型再决定怎么取。
        typ = _pg_query(
            t, "SELECT data_type FROM information_schema.columns "
               "WHERE table_name='ir_model' AND column_name='name'", e.db_name)
        is_json = bool(typ) and typ[0][0].strip() in ("jsonb", "json")
        name_expr = (
            "COALESCE(name->>'en_US', (SELECT v FROM jsonb_each_text(name) AS kv(k, v) LIMIT 1), '')"
            if is_json else "COALESCE(name, '')"
        )
        rows = _pg_query(t, f"SELECT model, {name_expr} FROM ir_model ORDER BY model", e.db_name)
        models = {r[0]: {"model": r[0], "name": r[1] if len(r) > 1 else "", "fields": []} for r in rows if r and r[0]}
        frows = _pg_query(
            t,
            "SELECT m.model, f.name, f.ttype, COALESCE(f.relation,'') "
            "FROM ir_model_fields f JOIN ir_model m ON m.id = f.model_id "
            f"ORDER BY m.model, f.name LIMIT {SCHEMA_MAX_FIELDS}",
            e.db_name,
        )
        for r in frows:
            if len(r) < 3 or r[0] not in models:
                continue
            models[r[0]]["fields"].append({"name": r[1], "ttype": r[2], "relation": r[3] if len(r) > 3 else ""})
        out = {"models": list(models.values()), "stale": False, "reason": None}
    except Exception as ex:  # noqa: BLE001
        # 常见原因:实例没起来、库还没初始化、Odoo 版本差异导致列结构不同。
        # 别把原因写死成某一个 —— 上一版写「实例可能没在运行」,实际是 jsonb 类型问题,反而误导排查。
        out["reason"] = f"读取库内模型失败,补全只有关键字:{str(ex)[:200]}"
        log.warning("实例 %s 取补全元数据失败: %s", e.id, ex)

    _schema_cache[e.id] = (now, out)
    return out


def drop_schema_cache(env_id: int) -> None:
    """升级模块后模型/字段会变,把缓存丢掉,下次补全拿到的是新的。"""
    _schema_cache.pop(env_id, None)
