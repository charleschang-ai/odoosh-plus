"""Git 仓库对接:URL 解析、远端分支读取、提交信息、Webhook 校验/解析。

设计要点
- 分支列表通过 git smart-HTTP 协议(GET <repo>/info/refs?service=git-upload-pack)直接读取,
  无需在平台容器内安装 git,对 GitHub / Gitee / GitLab / Gitea / 自建裸仓库通用。
- 提交详情(消息/作者/时间)在 provider 已知时通过其 REST API 补充,失败不影响主流程。
- Webhook 支持 GitHub(HMAC-SHA256)、Gitee(密码 / 签名两种模式)、GitLab(明文 token)与通用明文 token。
- 环境编排模块可通过 register_push_hook() 注册回调,在收到 push 时自动重新部署;本模块不直接依赖编排器。
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import time
import json
import logging
import re
import secrets
import threading
from datetime import datetime, timezone
from typing import Callable
from urllib.parse import quote, urlparse

import requests

log = logging.getLogger("odoosh.git")

TIMEOUT = 15
UA = "OdooshCN/0.1 (+https://gitee.com/changjiaqi666/odoosh-cn)"
REFS_MAX_BYTES = 8 * 1024 * 1024  # info/refs 响应上限(10 万个 ref 也就几 MB;防自建仓库地址喂超大响应撑爆内存)

_session: requests.Session | None = None
_session_lock = threading.Lock()


def http() -> requests.Session:
    """模块级 requests.Session:同一主机的连接复用(一次同步 = ls-remote + 上百次 commit API,以前每次都新建 TLS)。"""
    global _session
    if _session is None:
        with _session_lock:
            if _session is None:
                sess = requests.Session()
                adapter = _SafeAdapter(pool_connections=8, pool_maxsize=16)  # 连接时再校验真实 IP(防 DNS 重绑定)
                sess.mount("https://", adapter)
                sess.mount("http://", adapter)
                _session = sess
    return _session


# ---------------------------------------------------------------- SSRF:连接时校验 / 钉死 IP
def _is_bad_ip(a: str) -> bool:
    import ipaddress

    try:
        ip = ipaddress.ip_address(a.split("%")[0])
    except ValueError:
        return True
    return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified


def resolve_safe(host: str) -> list[str]:
    """解析主机名并校验全部地址(除非管理员放开 git.allow_private_hosts)。返回地址列表(IPv4 优先)。"""
    import socket

    host = (host or "").lower()
    if not host:
        raise ValueError("仓库地址缺少主机名")
    if host == "localhost" or host.endswith(".localhost") or host.endswith(".internal"):
        if not _allow_private_hosts():
            raise ValueError("不允许使用本机/内网地址作为仓库地址(可在系统设置中放开 git.allow_private_hosts)")
    try:
        infos = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
    except socket.gaierror as e:
        raise ValueError(f"无法解析仓库主机名 {host}: {e}") from e
    addrs: list[str] = []
    for ai in infos:
        a = ai[4][0]
        if a not in addrs:
            addrs.append(a)
    if not addrs:
        raise ValueError(f"无法解析仓库主机名 {host}")
    if not _allow_private_hosts():
        for a in addrs:
            if _is_bad_ip(a):
                raise ValueError(f"仓库主机 {host} 解析到内网/保留地址 {a},已拒绝(可在系统设置中放开 git.allow_private_hosts)")
    addrs.sort(key=lambda a: (":" in a, a))  # IPv4 在前
    return addrs


def _make_safe_conn(base):
    class _SafeConn(base):
        def _new_conn(self):
            # 只在建 TCP 连接的瞬间把 _dns_host 换成刚校验过的 IP(校验与连接之间不再有第二次 DNS 解析,
            # DNS rebinding 窗口关闭),连上后立刻还原。不能一直保持 IP:urllib3 的 host 属性由 _dns_host 派生,
            # TLS SNI/证书校验、http.client 的 Host 请求头都读它 —— 保持 IP 会报
            # "certificate is not valid for '<ip>'",或带着 Host: <ip> 被 CDN 301 循环 / WAF 拦截
            orig = self._dns_host
            addrs = resolve_safe(orig.rstrip("."))
            self._dns_host = addrs[0]
            try:
                return super()._new_conn()
            finally:
                self._dns_host = orig

    return _SafeConn


def _build_safe_adapter_cls():
    from urllib3.connection import HTTPConnection, HTTPSConnection
    from urllib3.connectionpool import HTTPConnectionPool, HTTPSConnectionPool
    from urllib3.poolmanager import PoolManager

    class _P(HTTPConnectionPool):
        ConnectionCls = _make_safe_conn(HTTPConnection)

    class _PS(HTTPSConnectionPool):
        ConnectionCls = _make_safe_conn(HTTPSConnection)

    class _SafeAdapter(requests.adapters.HTTPAdapter):
        def init_poolmanager(self, connections, maxsize, block=False, **kw):
            self.poolmanager = PoolManager(num_pools=connections, maxsize=maxsize, block=block, **kw)
            self.poolmanager.pool_classes_by_scheme = {"http": _P, "https": _PS}

    return _SafeAdapter


_SafeAdapter = _build_safe_adapter_cls()


def git_config_env(env: dict, key: str, value: str) -> dict:
    """往 GIT_CONFIG_COUNT/KEY_n/VALUE_n 环境变量里追加一条配置(与 git_auth_env 的 http.extraHeader 共存)。"""
    env = dict(env or {})
    n = int(env.get("GIT_CONFIG_COUNT") or 0)
    env[f"GIT_CONFIG_KEY_{n}"] = key
    env[f"GIT_CONFIG_VALUE_{n}"] = value
    env["GIT_CONFIG_COUNT"] = str(n + 1)
    return env


def pin_env(url: str, env: dict | None = None) -> dict:
    """给 git 子进程钉死远端 IP:先解析 + 校验,再用 http.curloptResolve(git ≥ 2.37 / curl)让 git 只连这些地址,
    不再自己做第二次 DNS 解析。返回追加了配置的环境变量字典。"""
    p = urlparse(url if "://" in url else "https://" + url)
    host = (p.hostname or "").lower()
    port = p.port or (443 if p.scheme == "https" else 80)
    addrs = resolve_safe(host)
    return git_config_env(env or {}, "http.curloptResolve", f"{host}:{port}:{','.join(addrs)}")

PROVIDER_HOSTS = {
    "github.com": "github",
    "gitee.com": "gitee",
    "gitlab.com": "gitlab",
}


# ---------------------------------------------------------------- URL 解析
def parse_repo_url(url: str) -> dict:
    """解析仓库地址,返回 {provider, host, owner, repo, https_url}。

    支持:
      https://github.com/owner/repo(.git)
      git@gitee.com:owner/repo.git
      ssh://git@host/owner/repo.git
      https://host/group/sub/repo.git(GitLab 子组:owner = group/sub)
    """
    u = url.strip()
    m = re.match(r"^(?:ssh://)?git@([^:/]+)[:/](.+?)(?:\.git)?/?$", u)
    if m:
        host, path = m.group(1), m.group(2)
        https_url = f"https://{host}/{path}.git"
    else:
        p = urlparse(u if "://" in u else "https://" + u)
        if not p.netloc or not p.path.strip("/"):
            raise ValueError("无法识别的仓库地址")
        host = p.hostname or ""
        path = p.path.strip("/")
        if path.endswith(".git"):
            path = path[:-4]
        https_url = f"{p.scheme}://{p.netloc}/{path}.git"
    parts = path.split("/")
    if len(parts) < 2:
        raise ValueError("仓库地址应形如 https://gitee.com/<owner>/<repo>.git")
    owner, repo = "/".join(parts[:-1]), parts[-1]
    provider = PROVIDER_HOSTS.get(host.lower(), "gitlab" if "gitlab" in host.lower() else "generic")
    return {"provider": provider, "host": host, "owner": owner, "repo": repo, "https_url": https_url}


def normalize_repo_url(url: str | None) -> str:
    """用于比较两个地址是否指向同一仓库:host/owner/repo(小写,去 .git)。"""
    if not url:
        return ""
    try:
        info = parse_repo_url(url)
        return f"{info['host']}/{info['owner']}/{info['repo']}".lower()
    except ValueError:
        return url.strip().lower().rstrip("/").removesuffix(".git")


def new_secret() -> str:
    return secrets.token_hex(20)


# ---------------------------------------------------------------- SSRF 防护
_allow_cache: tuple[float, bool] | None = None


def _allow_private_hosts() -> bool:
    """设置 git.allow_private_hosts=1 时允许内网/自建 Git 服务(默认关闭)。结果缓存 30s。"""
    global _allow_cache
    import time

    if _allow_cache and time.time() - _allow_cache[0] < 30:
        return _allow_cache[1]
    try:
        from ..db import SessionLocal
        from ..routers.settings import get_setting

        with SessionLocal() as db:
            v = (get_setting(db, "git.allow_private_hosts") or "0") == "1"
    except Exception:  # noqa: BLE001
        v = False
    _allow_cache = (time.time(), v)
    return v


_proxy_cache: tuple[float, list[str]] | None = None


def github_proxies() -> list[str]:
    """设置 git.github_proxy:gh-proxy 类加速前缀(逗号分隔,按顺序尝试)。结果缓存 30s。

    形如 https://gh.example.com,用法为 <前缀>/https://github.com/owner/repo.git;
    只对 github.com 的仓库生效。注意:私有仓库的令牌会经过代理方,应使用只读细粒度令牌或自建代理。"""
    global _proxy_cache
    if _proxy_cache and time.time() - _proxy_cache[0] < 30:
        return _proxy_cache[1]
    out: list[str] = []
    try:
        from ..db import SessionLocal
        from ..routers.settings import get_setting

        with SessionLocal() as db:
            raw = get_setting(db, "git.github_proxy") or ""
        for p in re.split(r"[,\s]+", raw.strip()):
            p = p.rstrip("/")
            if not p:
                continue
            u = urlparse(p)
            if u.scheme in ("http", "https") and u.hostname:
                out.append(p)
            else:
                log.warning("忽略无效的 GitHub 加速前缀:%s", p)
    except Exception:  # noqa: BLE001
        out = []
    _proxy_cache = (time.time(), out)
    return out


def github_url_candidates(https_url: str) -> list[str]:
    """github.com 仓库的候选访问地址:配置的加速前缀在前(国内直连常年不通,先走代理),直连兜底。
    非 github.com 或未配置加速时就是 [原地址]。"""
    p = urlparse(https_url)
    if (p.hostname or "").lower() != "github.com":
        return [https_url]
    return [f"{prefix}/{https_url}" for prefix in github_proxies()] + [https_url]


# 失效下载源记忆:加速站连不上(连接层失败)就记 3 分钟,期间探测/拉代码都跳过它,
# 避免每次都先耗一遍超时(前端请求 15s 就断了,轮不到直连兜底)。直连永不标记。
_dead_sources: dict[str, float] = {}
DEAD_SOURCE_TTL = 180.0


def _source_key(candidate: str, repo_url: str) -> str:
    if candidate != repo_url and candidate.endswith(repo_url):
        return candidate[: -len(repo_url)].rstrip("/")
    return "@direct"


def mark_source_dead(candidate: str, repo_url: str) -> None:
    key = _source_key(candidate, repo_url)
    if key != "@direct":
        _dead_sources[key] = time.time()
        log.warning("下载源 %s 连接失败,%d 秒内跳过", key, int(DEAD_SOURCE_TTL))


def source_alive(candidate: str, repo_url: str) -> bool:
    t = _dead_sources.get(_source_key(candidate, repo_url))
    return not t or time.time() - t >= DEAD_SOURCE_TTL


def assert_repo_url_safe(url: str) -> None:
    """服务端将主动连接该地址(ls-remote / fetch / clone),故须防 SSRF:
    只允许 http(s);主机不得解析到环回 / 私网 / 链路本地 / 元数据地址(除非管理员显式放开)。"""
    import ipaddress
    import socket

    info = parse_repo_url(url)
    p = urlparse(info["https_url"])
    if p.scheme not in ("http", "https"):
        raise ValueError("仓库地址只支持 http(s)")
    host = (p.hostname or "").lower()
    # 不缓存「主机名已安全」:每次都重新解析校验;真正连接时(requests 适配器 / git curloptResolve)再用校验过的 IP
    resolve_safe(host)


# ---------------------------------------------------------------- smart-HTTP ls-remote
def _basic_auth(provider: str, token: str | None) -> tuple[str, str] | None:
    if not token:
        return None
    user = {"github": "x-access-token", "gitee": "oauth2", "gitlab": "oauth2"}.get(provider, "git")
    return (user, token)


def _pkt_lines(data: bytes):
    """把 pkt-line 流切成 bytes 片段;flush 包(0000)产出 None。"""
    i, n = 0, len(data)
    while i + 4 <= n:
        ln = int(data[i : i + 4], 16)
        if ln == 0:
            yield None
            i += 4
            continue
        yield data[i + 4 : i + ln]
        i += ln


_SHA_RE = re.compile(r"[0-9a-fA-F]{7,64}")  # 远端返回的 commit sha 白名单


def ls_remote(url: str, token: str | None = None) -> tuple[dict[str, str], str | None]:
    """返回 ({branch: sha}, default_branch)。失败抛 RuntimeError(含可读原因)。"""
    info = parse_repo_url(url)
    try:
        assert_repo_url_safe(url)
    except ValueError as e:
        raise RuntimeError(str(e)) from e
    def _get_refs(endpoint: str) -> tuple[int, bytes]:
        """GET info/refs,手动跟随重定向(最多 3 次),每一跳都重新做 SSRF 校验。"""
        body, status = b"", 0
        for _ in range(4):
            with http().get(
                endpoint,
                auth=_basic_auth(info["provider"], token),
                headers={"User-Agent": UA, "Accept": "*/*"},
                timeout=(5, TIMEOUT),  # 连接 5s / 读 15s:多候选依次尝试时,连不上的源快速让位
                allow_redirects=False,
                stream=True,
            ) as r:
                if getattr(r, "is_redirect", False) and r.headers.get("Location"):
                    endpoint = requests.compat.urljoin(endpoint, r.headers["Location"])
                    assert_repo_url_safe(endpoint.split("/info/refs")[0])
                    continue
                status = r.status_code
                if status == 200:
                    chunks, size = [], 0
                    for ch in r.iter_content(64 * 1024):
                        size += len(ch)
                        if size > REFS_MAX_BYTES:
                            raise RuntimeError(f"仓库 refs 列表超过 {REFS_MAX_BYTES // (1 << 20)} MB,拒绝处理")
                        chunks.append(ch)
                    body = b"".join(chunks)
                break
        return status, body

    def _smart_http(b: bytes) -> bool:
        return b.startswith(b"001e# service=git-upload-pack") or b"git-upload-pack" in b[:64]

    # github.com 依次尝试:配置的加速前缀(git.github_proxy)→ 直连;其余仓库只有直连
    statuses: list[int] = []
    conn_err: str | None = None
    body, status = b"", 0
    try:
        for base in github_url_candidates(info["https_url"]):
            if not source_alive(base, info["https_url"]):  # 最近连不上的加速站直接跳过
                continue
            endpoint = base.rstrip("/") + "/info/refs?service=git-upload-pack"
            try:
                status, body = _get_refs(endpoint)
            except requests.RequestException as e:
                conn_err = f"连接仓库失败: {e}"
                mark_source_dead(base, info["https_url"])
                continue
            if status == 200 and _smart_http(body):
                break
            statuses.append(status)
    except ValueError as e:
        raise RuntimeError(str(e)) from e
    if not (status == 200 and _smart_http(body)):
        # 多个来源都失败时,报最有信息量的一种:认证/404 等 HTTP 状态优先于连接超时
        if any(s in (401, 403) for s in statuses):
            raise RuntimeError("认证失败:仓库为私有或令牌无效/权限不足")
        if 404 in statuses:
            raise RuntimeError("仓库不存在(404),请检查地址;私有仓库需填写访问令牌")
        if status == 200:
            raise RuntimeError("目标地址不是 git smart-HTTP 服务(可能是网页地址或需要登录)")
        if statuses:
            raise RuntimeError(f"仓库返回 HTTP {statuses[-1]}")
        raise RuntimeError(conn_err or "连接仓库失败")

    branches: dict[str, str] = {}
    default: str | None = None
    for pkt in _pkt_lines(body):
        if pkt is None or pkt.startswith(b"#"):
            continue
        line, _, caps = pkt.partition(b"\0")
        if caps:
            m = re.search(rb"symref=HEAD:refs/heads/(\S+)", caps)
            if m:
                default = m.group(1).decode()
        line = line.strip()
        if not line or b" " not in line:
            continue
        sha, ref = line.split(b" ", 1)
        ref = ref.decode()
        sha_s = sha.decode(errors="ignore")
        # 远端 git 服务器完全可控:sha 只允许十六进制,否则丢弃。
        # 否则形如 `--output=/path` 的值会被当作 git 参数(git archive / cat-file 等)造成任意文件写。
        if not _SHA_RE.fullmatch(sha_s):
            continue
        if ref.startswith("refs/heads/") and not ref.endswith("^{}"):
            branches[ref[len("refs/heads/") :]] = sha_s
    if default is None:
        for cand in ("main", "master", "develop"):
            if cand in branches:
                default = cand
                break
        if default is None and branches:
            default = sorted(branches)[0]
    return branches, default


# ---------------------------------------------------------------- 提交详情(provider API)
def _api_headers(provider: str, token: str | None) -> dict:
    h = {"User-Agent": UA, "Accept": "application/json"}
    if token:
        if provider == "github":
            h["Authorization"] = f"Bearer {token}"
        elif provider == "gitlab":
            h["PRIVATE-TOKEN"] = token
    return h


def fetch_commit(info: dict, sha: str, token: str | None) -> dict | None:
    """返回 {sha, message, author, date} 或 None(不支持/失败)。"""
    provider, host, owner, repo = info["provider"], info["host"], info["owner"], info["repo"]
    try:
        if provider == "github":
            r = http().get(
                f"https://api.github.com/repos/{owner}/{repo}/commits/{sha}",
                headers=_api_headers(provider, token),
                timeout=TIMEOUT,
            )
            if r.status_code != 200:
                return None
            j = r.json()
            c = j.get("commit", {})
            return {
                "sha": j.get("sha", sha),
                "message": c.get("message"),
                "author": (c.get("author") or {}).get("name"),
                "date": (c.get("author") or {}).get("date"),
            }
        if provider == "gitee":
            params = {"access_token": token} if token else {}
            r = http().get(
                f"https://gitee.com/api/v5/repos/{owner}/{repo}/commits/{sha}",
                params=params,
                headers=_api_headers(provider, None),
                timeout=TIMEOUT,
            )
            if r.status_code != 200:
                return None
            j = r.json()
            c = j.get("commit", {})
            return {
                "sha": j.get("sha", sha),
                "message": c.get("message"),
                "author": (c.get("author") or {}).get("name"),
                "date": (c.get("author") or {}).get("date"),
            }
        if provider == "gitlab":
            pid = quote(f"{owner}/{repo}", safe="")
            r = http().get(
                f"https://{host}/api/v4/projects/{pid}/repository/commits/{sha}",
                headers=_api_headers(provider, token),
                timeout=TIMEOUT,
            )
            if r.status_code != 200:
                return None
            j = r.json()
            return {
                "sha": j.get("id", sha),
                "message": j.get("message"),
                "author": j.get("author_name"),
                "date": j.get("committed_date"),
            }
    except (requests.RequestException, ValueError):
        return None
    return None


def sync_branches(url: str, token: str | None, detail_limit: int | None = None) -> dict:
    """读取远端分支并尽量补充提交详情。返回可直接 JSON 化的快照:
    {"default_branch": str|None, "synced_at": iso, "branches": [{name, sha, message, author, date}]}
    """
    info = parse_repo_url(url)
    refs, default = ls_remote(url, token)
    if detail_limit is None:
        # 无令牌时 GitHub 匿名 API 限额很低(60/h),少取一些
        detail_limit = 100 if token else 20
    names = sorted(refs, key=lambda n: (n != default, n))
    branches = [{"name": n, "sha": refs[n], "message": None, "author": None, "date": None} for n in names]
    # 提交详情并行拉取(原先逐分支串行,100 个分支要 30s+)
    if info["provider"] != "generic":
        from concurrent.futures import ThreadPoolExecutor

        todo = branches[:detail_limit]
        with ThreadPoolExecutor(max_workers=8) as ex:
            details = list(ex.map(lambda it: fetch_commit(info, it["sha"], token), todo))
        for item, c in zip(todo, details):
            if c:
                item.update({k: c.get(k) for k in ("message", "author", "date")})
                if item["message"]:
                    item["message"] = item["message"].strip().splitlines()[0][:200]  # 只保留提交信息首行
    return {
        "default_branch": default,
        "synced_at": datetime.now(timezone.utc).isoformat(),
        "branches": branches,
    }


# ---------------------------------------------------------------- Webhook 校验与解析
def _hex_or_none(v) -> str | None:
    """webhook 载荷里的 commit sha 不可信:只接受十六进制,否则当作未知(后续按远端分支头处理)。"""
    v = str(v or "").strip()
    return v if re.fullmatch(r"[0-9a-fA-F]{7,64}", v) else None


def _ct_eq(a: str | None, b: str | None) -> bool:
    return bool(a) and bool(b) and hmac.compare_digest(a.encode(), b.encode())


def verify_webhook(headers: dict, body: bytes, secret: str, query_token: str | None = None) -> str:
    """校验签名。返回识别出的来源('github'|'gitee'|'gitlab'|'generic'),失败抛 PermissionError。"""
    h = {k.lower(): v for k, v in headers.items()}

    # GitHub: X-Hub-Signature-256: sha256=<hmac_sha256(secret, body)>
    if sig := h.get("x-hub-signature-256"):
        want = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        if _ct_eq(sig, want):
            return "github"
        raise PermissionError("GitHub 签名不匹配")

    # Gitee: X-Gitee-Token — 密码模式(明文 == secret) 或 签名模式(base64(hmac_sha256(secret, "<ts>\n<secret>")))
    if tok := h.get("x-gitee-token"):
        if _ct_eq(tok, secret):
            return "gitee"
        ts = h.get("x-gitee-timestamp")
        if ts:
            try:
                skew = abs(time.time() * 1000 - int(ts))  # Gitee 时间戳为毫秒
            except ValueError:
                skew = None
            if skew is None or skew > 5 * 60 * 1000:
                raise PermissionError("Gitee 签名时间戳过期(允许 ±5 分钟,防重放)")
            digest = hmac.new(secret.encode(), f"{ts}\n{secret}".encode(), hashlib.sha256).digest()
            if _ct_eq(tok, base64.b64encode(digest).decode()):
                return "gitee"
        raise PermissionError("Gitee 密码/签名不匹配")

    # GitLab: X-Gitlab-Token 明文
    if tok := h.get("x-gitlab-token"):
        if _ct_eq(tok, secret):
            return "gitlab"
        raise PermissionError("GitLab Secret Token 不匹配")

    # 通用:X-Webhook-Token 头(不再接受 ?token= 查询参数:会落进反代 / 访问日志)
    if _ct_eq(h.get("x-webhook-token"), secret):
        return "generic"
    if query_token:
        raise PermissionError("请把密钥放在请求头 X-Webhook-Token,不支持 ?token= 查询参数")
    raise PermissionError("缺少或无效的 Webhook 凭据")


def parse_push_payload(source: str, headers: dict, payload: dict) -> dict | None:
    """把各平台的 push 事件统一为 {branch, sha, message, author, pusher, deleted}。
    非 push 事件(如 ping / issue)返回 None。
    """
    h = {k.lower(): v for k, v in headers.items()}
    event = (h.get("x-github-event") or h.get("x-gitee-event") or h.get("x-gitlab-event") or "push").lower()
    if event not in ("push", "push hook"):
        return None
    ref = payload.get("ref") or ""
    if not ref.startswith("refs/heads/"):
        return None  # tag 推送等忽略
    branch = ref[len("refs/heads/") :]
    after = payload.get("after") or payload.get("checkout_sha") or ""
    deleted = bool(payload.get("deleted")) or (after and set(after) == {"0"})

    head = payload.get("head_commit") or {}
    if not head and payload.get("commits"):
        head = payload["commits"][-1] or {}
    author = (head.get("author") or {}).get("name") if isinstance(head.get("author"), dict) else head.get("author")
    pusher = payload.get("pusher") or {}
    pusher_name = pusher.get("name") if isinstance(pusher, dict) else pusher
    pusher_name = pusher_name or payload.get("user_name") or (payload.get("sender") or {}).get("login")

    message = head.get("message") or ""
    return {
        "branch": branch,
        "sha": None if deleted else _hex_or_none(head.get("id") or after),
        "message": message.strip().splitlines()[0][:500] if message else None,
        "author": author,
        "pusher": pusher_name,
        "deleted": bool(deleted),
    }


# ---------------------------------------------------------------- push 回调注册(供编排模块使用)
PushHook = Callable[[int, list[int], dict], None]
"""签名:hook(repository_id, matched_env_ids, push_info) — 在后台任务里被调用。"""

_push_hooks: list[PushHook] = []


def register_push_hook(fn: PushHook) -> None:
    """编排模块调用,例如:
        from app.services import git as gitsvc
        gitsvc.register_push_hook(lambda repo_id, env_ids, info: [redeploy(i) for i in env_ids])
    """
    if fn not in _push_hooks:
        _push_hooks.append(fn)


def has_push_hooks() -> bool:
    return bool(_push_hooks)


def run_push_hooks(repository_id: int, env_ids: list[int], info: dict) -> None:
    for fn in list(_push_hooks):
        try:
            fn(repository_id, env_ids, info)
        except Exception:  # noqa: BLE001 — 单个回调失败不影响其他回调
            log.exception("push hook %s 执行失败", getattr(fn, "__name__", fn))


def dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False)
