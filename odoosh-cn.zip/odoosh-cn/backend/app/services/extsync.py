"""第三方身份同步:按 (来源, 外部主键) 幂等地建 / 改 / 停用平台用户,并按需开通实例。

设计原则(docs/work-2026-09-04-odoo-integration-design.md 第 0 节):
**平台提供机制,接入方提供策略。** 本模块不认识「学生」「班级」「课程」,只认识
「把某个外部身份放进令牌绑定的组织,给这些角色 / 配额 / 菜单,并开一个这样规格的实例」。
角色、配额、菜单、实例规格全部由调用方传入,平台只校验不越界(上限见 ApiToken)。

幂等是本模块的核心约定:同一个 external_id 调多少次 upsert,结果都一样。接入方
因此不需要维护「这人同步过没有」的状态,失败重试直接重放即可。
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import authz
from ..auth import hash_password, revoke_tokens
from ..models import Environment, Membership, Tenant, User
from ..models_token import ApiToken
from . import accounts, orchestrator
from .apitokens import ENV_NAME_RE, env_name_candidates, normalize_env_name, tenant_ids_for

log = logging.getLogger("odoosh.extsync")

# 与 accounts.USERNAME_RE 一致:字母 / 数字开头,可含 . _ -,2~64 位
USERNAME_RE = accounts.USERNAME_RE
# 组织内角色,按权限从低到高;调用方传入的角色不得超过令牌的 max_grant_role
ROLE_ORDER = ("tester", "developer", "owner")
MENU_KEYS = ("dashboard", "repos", "ai", "backups", "settings", "upgrade", "databases")


class SyncError(Exception):
    """带稳定错误码的同步失败。code 供接入方的队列判断该重试还是转人工(见设计文档 3.4)。"""

    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status


# ---------------------------------------------------------------- 校验
def _check_role(tok: ApiToken, role: str | None) -> str:
    role = (role or "developer").strip()
    if role not in ROLE_ORDER:
        raise SyncError("invalid_role", f"角色「{role}」无效,可选:{' / '.join(ROLE_ORDER)}")
    ceiling = tok.max_grant_role if tok.max_grant_role in ROLE_ORDER else "developer"
    if ROLE_ORDER.index(role) > ROLE_ORDER.index(ceiling):
        raise SyncError("exceeds_token_limit", f"该令牌最多只能授予「{ceiling}」角色,不能授予「{role}」", 403)
    return role


def _resolve_tenant(db: Session, tok: ApiToken, ref) -> Tenant:
    """请求里的 tenant(id 或 slug)→ 组织。未指定 = 令牌绑定组织;指定别的组织须令牌 allow_any_tenant。

    未开 allow_any_tenant 时**先判权限再查库**:否则调用方可以靠 404 与 403 的差别
    枚举出平台上有哪些组织。"""
    bound = db.get(Tenant, tok.tenant_id)
    if ref in (None, "", 0):
        t = bound
    else:
        ref = str(ref).strip()
        if not tok.allow_any_tenant:
            if bound is None or ref not in (str(bound.id), bound.slug):
                raise SyncError("exceeds_token_limit", "该令牌只能把用户落在绑定组织,不允许指定其他组织", 403)
            t = bound
        else:
            t = db.get(Tenant, int(ref)) if ref.isdigit() else db.scalar(select(Tenant).where(Tenant.slug == ref))
            if t is None:
                raise SyncError("tenant_not_found", f"组织「{ref}」不存在", 404)
    if t is None or not t.is_active:
        raise SyncError("tenant_inactive", "目标组织不存在或已停用", 409)
    return t


def _check_platform_role(tok: ApiToken, role: str | None) -> str:
    """平台角色:member(默认)或 admin。admin 能看所有组织,须令牌显式放行。"""
    role = (role or "member").strip()
    if role not in ("member", "admin"):
        raise SyncError("invalid_role", f"平台角色「{role}」无效,可选:member / admin")
    if role == "admin" and not tok.allow_admin_role:
        raise SyncError("exceeds_token_limit", "该令牌不允许把用户设为平台管理员", 403)
    return role


def _check_username(db: Session, username: str, me: User | None) -> str:
    username = (username or "").strip()
    if not USERNAME_RE.match(username):
        raise SyncError("invalid_username", f"用户名「{username}」不合法(字母/数字开头,可含 . _ -,2~64 位)")
    taken = db.scalar(select(User).where(User.username == username))
    if taken is not None and (me is None or taken.id != me.id):
        raise SyncError("username_taken", f"用户名「{username}」已被其他账号占用,请换一个", 409)
    return username


def _apply_quota(user: User, quota: dict | None) -> None:
    """配额:传了才改;None 表示不限。"""
    if not quota:
        return
    for field in ("max_envs", "max_dbs"):
        if field in quota:
            v = quota[field]
            setattr(user, field, None if v is None else max(0, int(v)))


def _apply_menus(user: User, menus: dict | None) -> None:
    """菜单可见性:传了才改,未提及的键保持原值。"""
    if not menus:
        return
    for key in MENU_KEYS:
        if key in menus:
            setattr(user, f"menu_{key}", bool(menus[key]))


# ---------------------------------------------------------------- upsert
def upsert_user(db: Session, tok: ApiToken, data: dict) -> dict:
    """按 (tok.source, external_id) 建或改用户。返回结果字典;失败抛 SyncError。调用方负责 commit。"""
    from . import apitokens as toksvc

    external_id = str(data.get("external_id") or "").strip()
    if not external_id:
        raise SyncError("missing_external_id", "缺少 external_id(接入方的稳定主键)")

    user = toksvc.find_by_external(db, tok, external_id)
    created = user is None
    if created and not tok.allow_create_user:
        raise SyncError("create_not_allowed", "该令牌不允许创建新用户,只能更新已存在的账号", 403)

    tenant = _resolve_tenant(db, tok, data.get("tenant"))
    role = _check_role(tok, data.get("tenant_role"))
    platform_role = _check_platform_role(tok, data.get("role"))
    username = _check_username(db, data.get("username") or "", user)
    active = bool(data.get("active", True))

    if created:
        user = User(
            username=username,
            # 随机密码:同步来的账号只能走免登入口,密码不告知任何人,也不返回
            password_hash=hash_password(accounts.gen_password(24)),
            role=platform_role,     # 默认 member;令牌 allow_admin_role 打开时才可能是 admin
            external_source=tok.source,
            external_id=external_id,
        )
        db.add(user)
    else:
        if user.role == "admin" and not tok.allow_admin_role:
            # 令牌无权管理平台管理员:既不能把他降级,也不能改他的属性
            raise SyncError("target_is_admin", "该外部身份对应的是平台管理员账号,此令牌无权修改", 403)
        user.username = username
        user.role = platform_role

    if data.get("display_name") is not None:
        user.display_name = (str(data["display_name"]).strip() or None)
    if data.get("shell_enabled") is not None:
        user.shell_enabled = bool(data["shell_enabled"])
    if data.get("can_use_enterprise") is not None:
        user.can_use_enterprise = bool(data["can_use_enterprise"])
    _apply_quota(user, data.get("quota"))
    _apply_menus(user, data.get("menus"))

    if user.is_active and not active:
        revoke_tokens(user)  # 由启用转停用:让已签发的登录令牌立即失效
    user.is_active = active
    db.flush()

    # 组织成员关系:落在解析出的组织(默认为令牌绑定组织);该用户在其他组织的关系保持不动
    m = db.scalar(select(Membership).where(Membership.user_id == user.id, Membership.tenant_id == tenant.id))
    if m is None:
        db.add(Membership(user_id=user.id, tenant_id=tenant.id, role=role))
    elif m.role != role:
        m.role = role
    db.flush()

    out = {"user_id": user.id, "username": user.username, "created": created,
           "role": user.role, "tenant_id": tenant.id, "tenant_slug": tenant.slug, "tenant_role": role,
           "active": user.is_active, "env_id": None, "env_name": None, "env_status": None}

    prov = data.get("provision")
    if prov and active:
        env, spawned = ensure_env(db, tok, user, prov, tenant_id=tenant.id)
        out.update(env_id=env.id, env_name=env.name, env_status=env.status, env_created=spawned)
    return out


# ---------------------------------------------------------------- 停用
def deactivate_user(db: Session, tok: ApiToken, external_id: str, stop_envs: bool = True) -> dict:
    """停用账号(永不删除用户 / 实例 / 代码)。stop_envs 决定是否同时停机。调用方负责 commit。"""
    from . import apitokens as toksvc

    user = toksvc.find_by_external(db, tok, str(external_id or "").strip())
    if user is None:
        raise SyncError("user_not_found", f"外部身份 {external_id} 在本平台没有对应账号", 404)
    was_active = user.is_active
    user.is_active = False
    revoke_tokens(user)
    db.flush()
    stopped = _stop_user_envs(db, tok, user) if stop_envs else []
    log.info("extsync 停用 user#%s(external=%s/%s),停机实例 %s", user.id, tok.source, external_id, stopped)
    return {"user_id": user.id, "username": user.username, "was_active": was_active, "stopped_envs": stopped}


def _stop_user_envs(db: Session, tok: ApiToken, user: User) -> list[int]:
    """把该用户在令牌组织下运行中的实例排队停机;返回被处理的实例 id。失败只记日志,不影响停用本身。"""
    from . import jobs

    envs = db.scalars(select(Environment).where(
        Environment.tenant_id.in_(tenant_ids_for(db, tok, user)), Environment.owner_user_id == user.id,
        Environment.deleted_at.is_(None), Environment.status.in_(("running", "sleeping")))).all()
    done = []
    for e in envs:
        try:
            e.status = "stopping"
            db.flush()
            jobs.spawn(orchestrator.stop, e.id)
            done.append(e.id)
        except Exception as ex:  # noqa: BLE001
            log.warning("extsync 停机 env#%s 失败: %s", e.id, ex)
    return done


def delete_user(db: Session, tok: ApiToken, external_id: str, purge_envs: bool = False) -> dict:
    """彻底删除平台账号(不可恢复)。需要令牌开启 allow_delete_user。调用方负责 commit。

    该用户拥有的实例先进回收站(容器停掉、域名摘除,数据保留 env.trash_keep_days 天可恢复);
    purge_envs=True 则连同数据一起立即销毁。删除账号本身不可恢复。
    平台管理员账号一律拒绝删除 —— 接入方不该有能力删掉运维账号。"""
    from . import apitokens as toksvc

    if not tok.allow_delete_user:
        raise SyncError("delete_not_allowed",
                        "该令牌不允许删除用户;如需「删除即删除」,请在接入令牌里开启「允许删除用户」", 403)
    user = toksvc.find_by_external(db, tok, str(external_id or "").strip())
    if user is None:
        raise SyncError("user_not_found", f"外部身份 {external_id} 在本平台没有对应账号", 404)
    if user.role == "admin":
        raise SyncError("target_is_admin", "平台管理员账号不能通过接入令牌删除", 403)

    envs = db.scalars(select(Environment).where(
        Environment.tenant_id.in_(tenant_ids_for(db, tok, user)),
        Environment.owner_user_id == user.id, Environment.deleted_at.is_(None))).all()
    username = user.username
    # 实例处理 + 删除本身跟控制台的删除用户共用一份实现,免得两条路径行为分叉
    handled = accounts.delete_with_envs(db, user, purge_envs=purge_envs, envs=envs)
    log.info("extsync 删除 user#%s(%s,external=%s/%s),实例 %s(%s)",
             user.id, username, tok.source, external_id, handled, "purge" if purge_envs else "trash")
    return {"username": username, "deleted": True, "envs": handled,
            "envs_purged": bool(purge_envs), "external_id": str(external_id)}


# ---------------------------------------------------------------- 对账
def reconcile(db: Session, tok: ApiToken, external_ids: list[str], stop_envs: bool = True,
              confirm: bool = False, max_ratio: float = 0.3) -> dict:
    """全量对账:把该来源下不在名单里的账号停用。名单为空、或将停用的比例超过 max_ratio 时拒绝,
    需 confirm=True 显式确认 —— 接入方一次查询失败就把整个班停掉的事故必须挡住。调用方负责 commit。"""
    keep = {str(x).strip() for x in (external_ids or []) if str(x).strip()}
    rows = db.scalars(select(User).where(User.external_source == tok.source, User.is_active.is_(True))).all()
    total = len(rows)
    victims = [u for u in rows if (u.external_id or "") not in keep]
    if not keep and not confirm:
        raise SyncError("empty_list", "名单为空会停用该来源下所有账号;确认无误请传 confirm=true", 400)
    if total and len(victims) / total > max_ratio and not confirm:
        raise SyncError("too_many_deactivations",
                        f"本次将停用 {len(victims)}/{total} 个账号,超过 {int(max_ratio * 100)}% 的保护阈值;"
                        "请确认名单完整后传 confirm=true", 409)
    for u in victims:
        u.is_active = False
        revoke_tokens(u)
        db.flush()
        if stop_envs:
            _stop_user_envs(db, tok, u)
    log.info("extsync 对账 source=%s 名单 %s 人,停用 %s 人", tok.source, len(keep), len(victims))
    return {"source": tok.source, "in_list": len(keep), "active_before": total,
            "deactivated": len(victims), "deactivated_users": [u.username for u in victims]}


# ---------------------------------------------------------------- 实例
def list_envs(db: Session, tok: ApiToken, user: User) -> list[dict]:
    """该用户在令牌可操作组织下拥有的实例(不含回收站)。"""
    envs = db.scalars(select(Environment).where(
        Environment.tenant_id.in_(tenant_ids_for(db, tok, user)), Environment.owner_user_id == user.id,
        Environment.deleted_at.is_(None)).order_by(Environment.id)).all()
    return [{"id": e.id, "name": e.name, "kind": e.kind, "status": e.status, "tenant_id": e.tenant_id,
             "status_message": e.status_message, "progress": e.progress,
             "odoo_version": e.odoo_version, "edition": e.edition, "url": e.url,
             "created_at": e.created_at.isoformat() if e.created_at else None} for e in envs]


def ensure_env(db: Session, tok: ApiToken, user: User, spec: dict,
               tenant_id: int | None = None) -> tuple[Environment, bool]:
    """保证该用户有一个实例。已有(按 name 匹配,未指定 name 则任意一个)则原样返回。
    返回 (实例, 本次是否新建)。失败抛 SyncError。调用方负责 commit。"""
    tenant_id = tenant_id or _resolve_tenant(db, tok, spec.get("tenant")).id
    name = normalize_env_name(spec.get("name"))   # 与 create_env / resolve_env 同一套规则,才幂等
    q = select(Environment).where(Environment.tenant_id == tenant_id,
                                  Environment.owner_user_id == user.id,
                                  Environment.deleted_at.is_(None))
    if name:
        q = q.where(Environment.name.in_(env_name_candidates(name, user.id)))
    existing = db.scalars(q.order_by(Environment.id)).first()
    if existing is not None:
        return existing, False
    return create_env(db, tok, user, spec, tenant_id=tenant_id), True


def create_env(db: Session, tok: ApiToken, user: User, spec: dict, tenant_id: int | None = None) -> Environment:
    """为指定用户开通实例(异步创建并启动)。规格由调用方给,平台只校验上限与配额。调用方负责 commit。"""
    from ..routers.settings import get_setting
    from . import jobs

    tenant_id = tenant_id or _resolve_tenant(db, tok, spec.get("tenant")).id
    if tok.max_envs_per_user <= 0:
        raise SyncError("provision_not_allowed", "该令牌不允许开通实例(每人上限为 0)", 403)
    if not user.is_active:
        raise SyncError("user_inactive", f"用户「{user.username}」已停用,不能开通实例", 409)
    if user.role != "admin" and not db.scalar(select(Membership.id).where(
            Membership.user_id == user.id, Membership.tenant_id == tenant_id)):
        raise SyncError("not_in_tenant", f"用户「{user.username}」不是该组织成员,请先同步用户再开通实例", 403)

    owned = int(db.scalar(select(func.count(Environment.id)).where(
        Environment.tenant_id == tenant_id, Environment.owner_user_id == user.id,
        Environment.deleted_at.is_(None))) or 0)
    if owned >= tok.max_envs_per_user:
        raise SyncError("exceeds_token_limit",
                        f"用户「{user.username}」已有 {owned} 个实例,达到该令牌的每人上限({tok.max_envs_per_user})", 403)
    # 平台自身的配额(User.max_envs)仍然生效,两者取严
    try:
        authz.check_env_quota(db, user)
    except Exception as ex:  # HTTPException
        raise SyncError("quota_exceeded", getattr(ex, "detail", str(ex)), 403)

    name = normalize_env_name(spec.get("name") or user.username, fallback=f"u{user.id}")
    if not ENV_NAME_RE.match(name):   # 兜底:规范化之后正常到不了这里
        raise SyncError("invalid_env_name", f"实例名「{name}」不合法(小写字母/数字开头,可含 -,最长 63 位)")
    # 不过滤 deleted_at 是有意的:回收站里的实例恢复时要用回原名,名字得一直占着。
    # 首选名被占就退到 <名字>-<用户id>,否则删过一次用户之后就再也建不出实例了。
    candidates = env_name_candidates(name, user.id)
    taken = set(db.scalars(select(Environment.name).where(
        Environment.tenant_id == tenant_id, Environment.name.in_(candidates))).all())
    free = next((c for c in candidates if c not in taken), None)
    if free is None:
        raise SyncError("env_name_taken", f"该组织下「{name}」及其备选名都已被占用,请先清空回收站", 409)
    if free != name:
        log.info("extsync 实例名「%s」已被占用(含回收站),改用「%s」", name, free)
    name = free

    kind = str(spec.get("kind") or "dev").strip()
    if kind not in ("dev", "staging"):
        raise SyncError("invalid_env_kind", "接入令牌只能开通 dev / staging 实例,不能开通生产实例", 403)
    edition = str(spec.get("edition") or "community").strip()
    if edition == "enterprise" and not user.can_use_enterprise:
        raise SyncError("enterprise_not_allowed", f"用户「{user.username}」没有创建企业版实例的权限", 403)

    env = Environment(
        tenant_id=tenant_id,
        name=name,
        kind=kind,
        odoo_version=str(spec.get("odoo_version") or get_setting(db, "odoo.default_version") or "18"),
        edition=edition,
        lang=spec.get("lang", "zh_CN"),
        owner_user_id=user.id,
        mem_mb=spec.get("mem_mb"),
        cpus=spec.get("cpus"),
        sleep_idle_hours=spec.get("sleep_idle_hours"),
        status="provisioning",
    )
    env.expires_at = orchestrator.compute_expires_at(spec.get("expire_days"), env.kind)
    db.add(env)
    db.flush()
    log.info("extsync 开通 env#%s「%s」给 user#%s(%s)", env.id, env.name, user.id, user.username)
    jobs.spawn(orchestrator.provision, env.id)
    return env


__all__ = ["SyncError", "upsert_user", "deactivate_user", "delete_user", "reconcile",
           "list_envs", "ensure_env", "create_env"]
