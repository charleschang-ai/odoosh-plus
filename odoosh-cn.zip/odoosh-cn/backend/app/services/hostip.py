"""基础域名 auto 模式:自动探测宿主机对外 IP,基础域名 = <IP>.nip.io(泛域名解析到该 IP,局域网/公网都能直接访问,无需自备域名)。

- ODOOSH_BASE_DOMAIN=auto 时启用;探测方式:用平台自己的镜像起一个 --network host 的一次性容器,
  在宿主机网络命名空间里做 UDP connect(不发包)取出口 IP(api 容器本身在 bridge 网络里看不到宿主机 IP)。
- 后台每 CHECK 秒复查;IP 变了(换 Wi-Fi / DHCP 重新分配)→ 更新基础域名并重写所有实例的 nginx 配置与 URL。
- 有真实域名后把 ODOOSH_BASE_DOMAIN 设为域名(泛解析 *.域名 → 服务器 IP)即可,本模块不再介入。
"""

import logging
import re
import socket
import threading
import time

from ..config import settings
from . import dockerx

log = logging.getLogger("odoosh.hostip")

CHECK = 600  # IP 一个月才变一次;以前 120s 一次(每天 720 次探测容器创建/删除)
_PROBE = "import socket;s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.connect(('8.8.8.8',80));print(s.getsockname()[0])"


def _ip_from_hex(h: str) -> str:
    b = bytes.fromhex(h)[::-1]
    return ".".join(str(x) for x in b)


def host_ip_from_proc(pid: int = 1) -> str | None:
    """api 容器以 pid: host 运行:/proc/1/net/* 是宿主机网络命名空间的视图,直接读默认路由网卡与本机地址,
    不用起容器(零成本)。取默认路由所在网卡的子网内的 LOCAL 地址。"""
    try:
        with open(f"/proc/{pid}/net/route") as f:
            rows = [ln.split() for ln in f.read().splitlines()[1:]]
    except OSError:
        return None
    dev = None
    subnets: list[tuple[int, int]] = []
    for r in rows:
        if len(r) < 8:
            continue
        iface, dest, mask = r[0], int(r[1], 16), int(r[7], 16)
        if dest == 0 and dev is None:
            dev = iface
    if not dev:
        return None
    for r in rows:
        if len(r) >= 8 and r[0] == dev and int(r[7], 16) != 0:
            subnets.append((int(r[1], 16), int(r[7], 16)))
    try:
        with open(f"/proc/{pid}/net/fib_trie") as f:
            lines = f.read().splitlines()
    except OSError:
        return None
    locals_: list[str] = []
    prev = None
    for ln in lines:
        m = re.search(r"\|-- (\d+\.\d+\.\d+\.\d+)", ln)
        if m:
            prev = m.group(1)
            continue
        if "/32 host LOCAL" in ln and prev and not prev.startswith("127."):
            locals_.append(prev)
    for ip in locals_:
        n = int.from_bytes(socket.inet_aton(ip), "little")
        if any((n & mask) == dest for dest, mask in subnets):
            return ip
    return None


def detect_host_ip() -> str | None:
    """宿主机出口 IPv4。先读宿主机网络命名空间的 /proc(pid: host,零成本),再试一次性 host 网络容器,
    最后退回本容器视角(仅当 api 跑在 host 网络时才准)。"""
    ip = host_ip_from_proc()
    if ip:
        return ip
    try:
        out = dockerx.client().containers.run(
            settings.self_image, ["python", "-c", _PROBE], network_mode="host", remove=True, detach=False, stdout=True, stderr=False,
        )
        ip = out.decode(errors="ignore").strip()
        if re.match(r"^\d+\.\d+\.\d+\.\d+$", ip):
            return ip
    except Exception as ex:  # noqa: BLE001
        log.warning("探测宿主机 IP 失败(helper 容器): %s", ex)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if not ip.startswith("172."):  # bridge 网段说明只是容器 IP,不可用
            return ip
    except Exception:  # noqa: BLE001
        pass
    return None


def detect_public_ip() -> str | None:
    """出口公网 IPv4(云服务器 NAT 场景公网 IP 不在网卡上,只能靠外部探测)。多源、短超时,全失败返回 None。"""
    import requests

    for url in ("https://api.ipify.org", "https://myip.ipip.net", "https://ifconfig.me/ip"):
        try:
            m = re.search(r"\d+\.\d+\.\d+\.\d+", requests.get(url, timeout=3).text)
            if m:
                return m.group(0)
        except Exception:  # noqa: BLE001
            continue
    return None


def _reachable_via(ip: str) -> bool:
    """平台能否通过该 IP 访问到「自己」:云服务器的 NAT 回环能打通且 /api/health 的 started_at 与本进程一致。
    WSL/家庭网络探测到的公网 IP 是路由器的,这里会失败 → 回落网卡 IP,行为与从前一致。"""
    import requests

    try:
        r = requests.get(f"http://{ip}:{settings.http_port}/api/health", timeout=3)
        return r.status_code == 200 and abs(float(r.json().get("started_at") or 0) - float(settings.started_at)) < 1
    except Exception:  # noqa: BLE001
        return False


_VERIFIED_KEY = "platform.verified_public_ip"


def _recall_verified() -> str | None:
    try:
        from ..db import SessionLocal
        from ..models import Setting

        with SessionLocal() as db:
            row = db.get(Setting, _VERIFIED_KEY)
            return (row.value or "").strip() or None if row else None
    except Exception:  # noqa: BLE001
        return None


def _remember_verified(ip: str) -> None:
    try:
        from ..db import SessionLocal
        from ..models import Setting

        with SessionLocal() as db:
            row = db.get(Setting, _VERIFIED_KEY)
            if row:
                row.value = ip
            else:
                db.add(Setting(key=_VERIFIED_KEY, value=ip))
            db.commit()
    except Exception as ex:  # noqa: BLE001
        log.debug("记录已验证公网 IP 失败: %s", ex)


def pick_auto_ip() -> str | None:
    """auto 模式选 IP:公网 IP 存在、与网卡 IP 不同、且确实映射到本机时优先(NAT 云服务器);否则网卡 IP(WSL/局域网)。
    验证过的公网 IP 会持久化:api 刚重启时 web 未就绪、回环探测必然失败,若本次探测到的公网 IP 与上次验证一致
    则直接采信——否则重启后头一分钟建的实例会把内网 IP 写进 URL。"""
    nic = detect_host_ip()
    pub = detect_public_ip()
    if pub and pub != nic:
        if _reachable_via(pub):
            _remember_verified(pub)
            log.info("auto 基础域名选用公网 IP %s(网卡 IP %s 为内网,NAT 回环验证通过)", pub, nic)
            return pub
        if pub == _recall_verified():
            log.info("公网 IP %s 暂时探测不到本平台(web 可能未就绪),与先前验证结果一致,直接采信", pub)
            return pub
        log.info("探测到公网 IP %s 但经其访问不到本平台(家庭 NAT/回环不通/端口未放行),沿用网卡 IP %s", pub, nic)
    return nic


def domain_for(ip: str) -> str:
    return f"{ip}.nip.io"


def effective_raw() -> str:
    """基础域名的原始配置:系统设置 platform.base_domain(非空且不是占位的 localhost)优先,否则 .env 的 ODOOSH_BASE_DOMAIN。"""
    try:
        from ..db import SessionLocal
        from ..routers.settings import get_setting

        with SessionLocal() as db:
            v = (get_setting(db, "platform.base_domain") or "").strip().lower()
        if v and v != "localhost":
            return v
    except Exception as ex:  # noqa: BLE001
        log.debug("读取 platform.base_domain 失败: %s", ex)
    return (settings.base_domain_raw or "localhost").strip().lower()


def is_auto() -> bool:
    return effective_raw() == "auto"


_last_sync: tuple[str, int] | None = None  # 上次成功同步时的 (基础域名, HTTP 端口)


def apply(sync: bool = True) -> str:
    """按当前配置计算生效的基础域名(auto → <IP>.nip.io),写入 settings.base_domain;
    基础域名或 HTTP 端口相对上次成功同步有变化时,重写全部实例域名/URL + nginx(实例 URL 里拼着端口,
    只比较域名会漏掉改 ODOOSH_HTTP_PORT 的场景)。每个进程首次 sync 必跑一遍,自愈重启期间的漂移。返回生效值。"""
    global _last_sync
    raw = effective_raw()
    if raw == "auto":
        ip = pick_auto_ip()
        want = domain_for(ip) if ip else (settings.base_domain or "localhost")
        settings.host_ip = ip
    else:
        want = raw
    if want != settings.base_domain:
        log.info("基础域名 %s → %s(配置 %s)", settings.base_domain, want, raw)
        settings.base_domain = want
    from . import nginx

    stamp = (want, settings.http_port, nginx.access_mode())
    if sync and stamp != _last_sync:
        try:
            from . import nginx

            n = nginx.regenerate_all()
            ok, out = nginx.reload()
            log.info("已同步 %s 个实例域名(域名 %s,端口 %s);nginx reload %s %s", n, want, settings.http_port, ok, (out or "").strip()[:100])
            _last_sync = stamp  # 失败不记账,下个周期重试
        except Exception as ex:  # noqa: BLE001
            log.warning("同步实例域名失败: %s", ex)
    return settings.base_domain


def resolve_at_startup() -> None:
    """启动时算出生效基础域名(此时 nginx 配置尚未重写,不必同步)。"""
    apply(sync=False)
    log.info("基础域名生效值 %s(配置 %s,宿主机 IP %s)", settings.base_domain, effective_raw(), settings.host_ip)


def start_watcher(interval: int = CHECK) -> None:
    """后台复查:auto 模式下 IP 变化 → 自动同步;系统设置改了基础域名也在这里兜底(保存时已即时 apply)。
    首次复查提前到 60s:api 启动时 web 尚未就绪,NAT 回环探测(pick_auto_ip)必然失败而先选了网卡 IP,
    等 web 起来后这次复查会把云服务器纠正为公网 IP 并同步所有实例域名。"""

    def loop():
        delay = 60
        while True:
            time.sleep(delay)
            delay = interval
            try:
                apply(sync=True)
            except Exception as ex:  # noqa: BLE001
                log.warning("基础域名复查出错: %s", ex)

    threading.Thread(target=loop, name="hostip-watcher", daemon=True).start()
