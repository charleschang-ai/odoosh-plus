"""用户自有远程备份目标(S3 兼容 / SFTP / WebDAV):备份完成后推送副本到用户自己的服务器 / NAS / 对象存储。

与 replica.py(平台级单一 S3 副本,超管配置)并存:这里是「每个用户自己的目标、每个实例自己选」。
  - 目标 BackupTarget:连接参数 JSON(密钥字段 Fernet 加密);只有创建者与超管可见可改
  - 实例配置 EnvironmentBackupConfig.target_ids:该实例的备份(主库 + 附加库,每个库各一份)推到哪些目标
  - 副本 BackupReplica:backup × target 的推送状态;失败由调度线程定期重试;可手动重推
  - 远端保留:按目标 keep_days 清理(只删我们自己推上去的、记录在 BackupReplica 里的对象,不碰用户其它文件)
  - 本地删除备份时:目标 delete_with_local=True 才同步删远端,默认保留(用户的 NAS 是他的冷备)
  - 恢复时本地文件丢失:按 done 的副本依次尝试拉回并校验 sha256

远端路径:<prefix>/<组织slug>/<实例名>/<库名>/<文件名>  —— 用户在 NAS 上一眼能认。
驱动接口:test() / put(local_path, key) -> (sha256, size) / get(key, dest) / delete(key)
"""

from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import posixpath
import queue
import threading
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import quote, urlsplit, urlunsplit

from sqlalchemy import select

from .. import crypto
from ..db import SessionLocal
from ..models import Environment, Tenant
from ..models_backup import Backup, BackupReplica, BackupTarget, EnvironmentBackupConfig

log = logging.getLogger("odoosh.remote")

KINDS = ("s3", "sftp", "webdav")
KIND_LABEL = {"s3": "S3 兼容对象存储", "sftp": "SFTP(SSH)", "webdav": "WebDAV"}
SECRET_FIELDS = {"s3": ("secret_key",), "sftp": ("password", "private_key"), "webdav": ("password",)}
MAX_ATTEMPTS = 5
CHUNK = 1 << 20

_lock = threading.Lock()
_inflight: set[int] = set()  # 正在推送的 replica id

# 固定大小工作线程池:限制并发网络传输数与线程数(否则夜间批量备份完成时会 spawn 上百个线程/连接打向同一 NAS)。
_pool_lock = threading.Lock()
_task_q: "queue.Queue" = queue.Queue()   # 队列元素为无参可调用(推送 / 删除任务)
_queued: set[int] = set()          # 已入队待推送的 replica id(去重)
_workers_started = False
DEFAULT_CONCURRENCY = 3


# ---------------------------------------------------------------- 配置读写
def load_config(t: BackupTarget, reveal: bool = False) -> dict:
    """解出目标配置;reveal=False 时密钥字段用 '******' 掩码(给前端)。"""
    try:
        c = json.loads(t.config or "{}") or {}
    except ValueError:
        c = {}
    out = dict(c)
    for k in SECRET_FIELDS.get(t.kind, ()):
        v = c.get(k)
        if not v:
            out[k] = ""
        elif reveal:
            out[k] = crypto.decrypt(v) if str(v).startswith(crypto.PREFIX) else v
        else:
            out[k] = "******"
    return out


def store_config(t: BackupTarget, incoming: dict) -> None:
    """写入配置:密钥字段为空或 '******' 时保留旧值,否则加密后存。"""
    old = {}
    try:
        old = json.loads(t.config or "{}") or {}
    except ValueError:
        pass
    new = {}
    for k, v in (incoming or {}).items():
        if k in SECRET_FIELDS.get(t.kind, ()):
            if v is None or v == "" or v == "******":
                if old.get(k):
                    new[k] = old[k]
            else:
                new[k] = crypto.encrypt(str(v))
        else:
            new[k] = v
    t.config = json.dumps(new, ensure_ascii=False)


def _norm_prefix(p: str | None) -> str:
    p = (p or "").strip().strip("/")
    return "/".join(x for x in p.split("/") if x and x != "..")  # 去掉 .. 防止跳出目标目录


def remote_key(t: BackupTarget, b: Backup) -> str:
    """<prefix>/<组织>/<实例>/<库名>/<文件名>。"""
    import re as _re

    def _seg(x: str) -> str:  # 路径片段清洗:db_name 可能来自用户上传备份的 manifest.json
        return _re.sub(r"[^A-Za-z0-9._-]+", "_", (x or "").strip()).strip("._") or ""

    fname = _seg(posixpath.basename((b.filename or "").replace(os.sep, "/"))) or f"backup-{b.id}.zip"
    parts = [_norm_prefix(t.prefix), _seg(b.tenant_slug), _seg(b.env_name), _seg(b.db_name) or "db", fname]
    return "/".join(x for x in parts if x)


# ---------------------------------------------------------------- 驱动
class _HashingReader:
    """顺序读文件并同时算 sha256(不提供 seek → boto3 按流式分片上传)。"""

    def __init__(self, path: str):
        self.f = open(path, "rb")
        self.h = hashlib.sha256()
        self.n = 0

    def read(self, size: int = -1) -> bytes:
        data = self.f.read(size)
        if data:
            self.h.update(data)
            self.n += len(data)
        return data

    def close(self) -> None:
        self.f.close()


def _sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


class S3Driver:
    def __init__(self, c: dict):
        import boto3
        from botocore.config import Config

        self.bucket = (c.get("bucket") or "").strip()
        if not self.bucket:
            raise ValueError("S3 目标缺少 bucket")
        kw = {
            "aws_access_key_id": (c.get("access_key") or "").strip(),
            "aws_secret_access_key": c.get("secret_key") or "",
            "config": Config(signature_version="s3v4", retries={"max_attempts": 3}, connect_timeout=30, read_timeout=300,
                             s3={"addressing_style": "path" if c.get("path_style") else "auto"}),
        }
        ep = (c.get("endpoint") or "").strip()
        if ep:
            kw["endpoint_url"] = ep
        if (c.get("region") or "").strip():
            kw["region_name"] = c["region"].strip()
        self.s3 = boto3.client("s3", **kw)

    def test(self) -> None:
        self.s3.head_bucket(Bucket=self.bucket)
        key = ".odoosh-test"
        self.s3.put_object(Bucket=self.bucket, Key=key, Body=b"ok")
        self.s3.get_object(Bucket=self.bucket, Key=key)["Body"].read()
        self.s3.delete_object(Bucket=self.bucket, Key=key)

    def put(self, path: str, key: str) -> tuple[str, int]:
        from boto3.s3.transfer import TransferConfig

        r = _HashingReader(path)
        try:
            self.s3.upload_fileobj(r, self.bucket, key, Config=TransferConfig(multipart_chunksize=16 << 20, max_concurrency=2))
        finally:
            r.close()
        return r.h.hexdigest(), r.n

    def get(self, key: str, dest: str) -> None:
        with open(dest, "wb") as f:
            self.s3.download_fileobj(self.bucket, key, f)

    def delete(self, key: str) -> None:
        self.s3.delete_object(Bucket=self.bucket, Key=key)


class SftpDriver:
    def __init__(self, c: dict):
        import paramiko

        self.host = (c.get("host") or "").strip()
        if not self.host:
            raise ValueError("SFTP 目标缺少主机地址")
        self.port = int(c.get("port") or 22)
        self.user = (c.get("username") or "").strip() or "root"
        self.password = c.get("password") or None
        self.pkey = None
        pem = (c.get("private_key") or "").strip()
        if pem:
            last = None
            for cls in (paramiko.Ed25519Key, paramiko.RSAKey, paramiko.ECDSAKey):
                try:
                    self.pkey = cls.from_private_key(io.StringIO(pem), password=self.password or None)
                    break
                except Exception as ex:  # noqa: BLE001
                    last = ex
            if self.pkey is None:
                raise ValueError(f"私钥无法解析:{last}")
        raw = (c.get("base_path") or "").strip()
        self.base = _norm_prefix(raw)
        if raw.startswith("/") and self.base:
            self.base = "/" + self.base  # 绝对路径;否则相对登录目录
        self._ssh = None
        self._sftp = None

    def _open(self):
        import paramiko

        if self._sftp is not None:
            return self._sftp
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(self.host, port=self.port, username=self.user, password=None if self.pkey else self.password,
                    pkey=self.pkey, timeout=20, banner_timeout=30, auth_timeout=30, allow_agent=False, look_for_keys=False)
        self._ssh = ssh
        self._sftp = ssh.open_sftp()
        ch = self._sftp.get_channel()
        if ch is not None:
            ch.settimeout(600)  # 传输中途卡住时 600s 内抛超时,避免线程永久挂起
        return self._sftp

    def close(self) -> None:
        try:
            if self._sftp:
                self._sftp.close()
            if self._ssh:
                self._ssh.close()
        except Exception:  # noqa: BLE001
            pass
        self._sftp = self._ssh = None

    def _full(self, key: str) -> str:
        return posixpath.join(self.base, key) if self.base else key

    def _mkdirs(self, sftp, path: str) -> None:
        parts = [p for p in path.split("/") if p]
        cur = "/" if path.startswith("/") else ""
        for p in parts:
            cur = posixpath.join(cur, p) if cur else p
            try:
                sftp.stat(cur)
            except OSError:
                sftp.mkdir(cur)

    def test(self) -> None:
        sftp = self._open()
        try:
            if self.base:
                self._mkdirs(sftp, self.base)
            p = self._full(".odoosh-test")
            with sftp.open(p, "wb") as f:
                f.write(b"ok")
            with sftp.open(p, "rb") as f:
                assert f.read() == b"ok"
            sftp.remove(p)
        finally:
            self.close()

    def put(self, path: str, key: str) -> tuple[str, int]:
        sftp = self._open()
        try:
            full = self._full(key)
            self._mkdirs(sftp, posixpath.dirname(full))
            h = hashlib.sha256()
            n = 0
            tmp = full + ".part"
            with open(path, "rb") as src, sftp.open(tmp, "wb") as dst:
                dst.set_pipelined(True)
                for chunk in iter(lambda: src.read(CHUNK), b""):
                    dst.write(chunk)
                    h.update(chunk)
                    n += len(chunk)
            try:
                sftp.remove(full)
            except OSError:
                pass
            sftp.rename(tmp, full)
            return h.hexdigest(), n
        finally:
            self.close()

    def get(self, key: str, dest: str) -> None:
        sftp = self._open()
        try:
            sftp.get(self._full(key), dest)
        finally:
            self.close()

    def delete(self, key: str) -> None:
        sftp = self._open()
        try:
            try:
                sftp.remove(self._full(key))
            except FileNotFoundError:
                pass
        finally:
            self.close()


class WebdavDriver:
    def __init__(self, c: dict):
        import requests

        url = (c.get("url") or "").strip()
        if not url:
            raise ValueError("WebDAV 目标缺少地址")
        if not url.endswith("/"):
            url += "/"
        self.base = url
        self.s = requests.Session()
        if (c.get("username") or "").strip():
            self.s.auth = ((c.get("username") or "").strip(), c.get("password") or "")
        self.s.headers["User-Agent"] = "odoosh-backup/1.0"
        self.s.max_redirects = 0  # 不跟随重定向:否则可绕过内网校验
        self.verify = not bool(c.get("insecure"))

    def _url(self, key: str) -> str:
        return self.base + "/".join(quote(p, safe="") for p in key.split("/") if p)

    def _mkcol(self, key_dir: str) -> None:
        parts = [p for p in key_dir.split("/") if p]
        cur = ""
        for p in parts:
            cur = f"{cur}/{p}" if cur else p
            r = self.s.request("MKCOL", self._url(cur) + "/", timeout=30, verify=self.verify)
            if r.status_code not in (200, 201, 204, 301, 302, 405, 409):  # 405 = 已存在
                raise RuntimeError(f"MKCOL {cur} → HTTP {r.status_code}")

    def test(self) -> None:
        r = self.s.request("PROPFIND", self.base, headers={"Depth": "0"}, timeout=30, verify=self.verify)
        if r.status_code in (401, 403):
            raise RuntimeError(f"认证失败(HTTP {r.status_code})")
        if r.status_code >= 400 and r.status_code != 405:
            raise RuntimeError(f"PROPFIND → HTTP {r.status_code}")
        u = self._url(".odoosh-test")
        r = self.s.put(u, data=b"ok", timeout=30, verify=self.verify)
        if r.status_code not in (200, 201, 204):
            raise RuntimeError(f"PUT → HTTP {r.status_code}")
        r = self.s.get(u, timeout=30, verify=self.verify)
        if r.status_code != 200 or r.content != b"ok":
            raise RuntimeError(f"GET → HTTP {r.status_code}")
        self.s.delete(u, timeout=30, verify=self.verify)

    def put(self, path: str, key: str) -> tuple[str, int]:
        self._mkcol(posixpath.dirname(key))
        r = _HashingReader(path)
        size = os.path.getsize(path)
        try:
            resp = self.s.put(self._url(key), data=r, headers={"Content-Length": str(size)}, timeout=(30, 600), verify=self.verify)
        finally:
            r.close()
        if resp.status_code not in (200, 201, 204):
            raise RuntimeError(f"PUT → HTTP {resp.status_code}")  # 不回显响应正文(避免成为 SSRF 读原语)
        return r.h.hexdigest(), r.n

    def get(self, key: str, dest: str) -> None:
        with self.s.get(self._url(key), stream=True, timeout=(30, 600), verify=self.verify) as resp:
            if resp.status_code != 200:
                raise RuntimeError(f"GET → HTTP {resp.status_code}")
            with open(dest, "wb") as f:
                for chunk in resp.iter_content(CHUNK):
                    f.write(chunk)

    def delete(self, key: str) -> None:
        r = self.s.delete(self._url(key), timeout=30, verify=self.verify)
        if r.status_code not in (200, 202, 204, 404):
            raise RuntimeError(f"DELETE → HTTP {r.status_code}")


def _assert_host_safe(host: str | None) -> None:
    """远程目标的主机必须解析到公网地址,防止把平台当跳板扫描 / 读写内网(SSRF)。
    复用 git.resolve_safe(同一套内网/保留地址判定与 git.allow_private_hosts 开关)。"""
    from . import git as gitsvc

    h = (host or "").strip()
    if not h:
        raise ValueError("缺少主机地址")
    gitsvc.resolve_safe(h)


def _assert_url_safe(url: str | None) -> None:
    u = (url or "").strip()
    if not u:
        raise ValueError("缺少地址")
    parts = urlsplit(u if "://" in u else "http://" + u)
    if parts.scheme not in ("http", "https"):
        raise ValueError(f"不支持的协议 {parts.scheme}")
    _assert_host_safe(parts.hostname)


def driver(t: BackupTarget):
    c = load_config(t, reveal=True)
    if t.kind == "s3":
        ep = (c.get("endpoint") or "").strip()
        if ep:
            _assert_url_safe(ep)
    elif t.kind == "sftp":
        _assert_host_safe(c.get("host"))
    elif t.kind == "webdav":
        _assert_url_safe(c.get("url"))
    if t.kind == "s3":
        return S3Driver(c)
    if t.kind == "sftp":
        return SftpDriver(c)
    if t.kind == "webdav":
        return WebdavDriver(c)
    raise ValueError(f"未知目标类型 {t.kind}")


def describe(t: BackupTarget) -> str:
    """列表里显示的一句话地址(不含密钥)。"""
    c = load_config(t)
    if t.kind == "s3":
        return f"{c.get('endpoint') or 'AWS S3'} / {c.get('bucket') or ''}"
    if t.kind == "sftp":
        return f"{c.get('username') or 'root'}@{c.get('host') or ''}:{c.get('port') or 22}{(' ' + c['base_path']) if c.get('base_path') else ''}"
    if t.kind == "webdav":
        return c.get("url") or ""
    return ""


def test_target(t: BackupTarget) -> dict:
    started = time.time()
    try:
        driver(t).test()
        return {"ok": True, "ms": int((time.time() - started) * 1000)}
    except Exception as ex:  # noqa: BLE001
        return {"ok": False, "error": str(ex)[:500], "ms": int((time.time() - started) * 1000)}


# ---------------------------------------------------------------- 实例配置
def env_config(db, env_id: int, create: bool = False) -> EnvironmentBackupConfig | None:
    c = db.scalar(select(EnvironmentBackupConfig).where(EnvironmentBackupConfig.environment_id == env_id))
    if c is None and create:
        c = EnvironmentBackupConfig(environment_id=env_id)
        db.add(c)
        db.commit()
        db.refresh(c)
    return c


def env_target_ids(c: EnvironmentBackupConfig | None) -> list[int]:
    if not c:
        return []
    try:
        return [int(x) for x in json.loads(c.target_ids or "[]")]
    except (ValueError, TypeError):
        return []


def env_targets(db, env_id: int) -> list[BackupTarget]:
    ids = env_target_ids(env_config(db, env_id))
    if not ids:
        return []
    rows = db.scalars(select(BackupTarget).where(BackupTarget.id.in_(ids), BackupTarget.enabled.is_(True))).all()
    return sorted(rows, key=lambda r: ids.index(r.id))


# ---------------------------------------------------------------- 推送
def _set_replica(rid: int, **fields) -> None:
    with SessionLocal() as db:
        r = db.get(BackupReplica, rid)
        if r:
            for k, v in fields.items():
                setattr(r, k, v)
            db.commit()


def schedule_push(backup_id: int) -> int:
    """备份完成后调用:按实例配置建 pending 副本记录并异步推送。返回目标数。"""
    with SessionLocal() as db:
        b = db.get(Backup, backup_id)
        if not b or not b.environment_id or b.status != "done":
            return 0
        override = getattr(b, "push_target_ids", None)
        if override is not None:  # 手动备份显式指定(本地=「[]」/ 远程=「[id,...]」)
            try:
                want = [int(x) for x in json.loads(override or "[]")]
            except (ValueError, TypeError):
                want = []
            if not want:
                return 0  # 仅本地
            rows = db.scalars(select(BackupTarget).where(BackupTarget.id.in_(want), BackupTarget.enabled.is_(True))).all()
            targets = sorted(rows, key=lambda r: want.index(r.id))
        else:  # 自动备份:沿用实例配置
            targets = env_targets(db, b.environment_id)
        ids = []
        for t in targets:
            r = db.scalar(select(BackupReplica).where(BackupReplica.backup_id == b.id, BackupReplica.target_id == t.id))
            if r is None:
                r = BackupReplica(backup_id=b.id, target_id=t.id, status="pending", remote_key=remote_key(t, b))
                db.add(r)
                db.flush()
            ids.append(r.id)
        db.commit()
    for rid in ids:
        push_async(rid)
    return len(ids)


def _worker_count() -> int:
    from .backup import get_setting

    try:
        return max(1, min(16, int(get_setting("backup.remote_concurrency") or DEFAULT_CONCURRENCY)))
    except (ValueError, TypeError):
        return DEFAULT_CONCURRENCY


def _ensure_workers() -> None:
    global _workers_started
    with _pool_lock:
        if _workers_started:
            return
        _workers_started = True
        for i in range(_worker_count()):
            threading.Thread(target=_worker_loop, daemon=True, name=f"remote-push-{i}").start()


def _worker_loop() -> None:
    while True:
        job = _task_q.get()
        try:
            job()
        except Exception:  # noqa: BLE001
            log.exception("remote worker error")
        finally:
            _task_q.task_done()


def _submit(job) -> None:
    _ensure_workers()
    _task_q.put(job)


def push_async(replica_id: int) -> None:
    """把一次推送排入工作队列(线程数 = backup.remote_concurrency,默认 3;已在队列 / 推送中的不重复入队)。"""
    with _pool_lock:
        if replica_id in _queued or replica_id in _inflight:
            return
        _queued.add(replica_id)

    def _job(rid=replica_id):
        with _pool_lock:
            _queued.discard(rid)
        push(rid)

    _submit(_job)


def delete_async(target_id: int, key: str, replica_id: int | None = None, new_status: str | None = None) -> None:
    """把一次远端删除排入同一工作队列(不阻塞请求线程 / 调度线程)。"""
    def _job():
        with SessionLocal() as db:
            t = db.get(BackupTarget, target_id)
        if not t or not key:
            return
        try:
            driver(t).delete(key)
            if replica_id and new_status:
                _set_replica(replica_id, status=new_status)
        except Exception as ex:  # noqa: BLE001
            log.warning("删除远端副本失败 target#%s %s: %s", target_id, key, ex)

    _submit(_job)


def push(replica_id: int) -> bool:
    with _lock:
        if replica_id in _inflight:
            return False
        _inflight.add(replica_id)
    try:
        with SessionLocal() as db:
            r = db.get(BackupReplica, replica_id)
            if not r:
                return False
            b = db.get(Backup, r.backup_id)
            t = db.get(BackupTarget, r.target_id)
            if not b or not t or b.status != "done":
                return False
            from .backup import backup_path

            src = backup_path(b)
            if not src or not os.path.isfile(src):
                _set_replica(replica_id, status="failed", error="本地备份文件不存在", attempts=(r.attempts or 0) + 1)
                return False
            key = r.remote_key or remote_key(t, b)
            attempts = (r.attempts or 0) + 1
            tname = t.name
        _set_replica(replica_id, status="pending", error=None, remote_key=key, attempts=attempts)
        started = time.time()
        try:
            local_size = os.path.getsize(src)
            sha, n = driver(t).put(src, key)
            if n != local_size:  # 上传被截断(服务端仍可能回 2xx)→ 视为失败,等待重试覆盖
                raise RuntimeError(f"上传字节数不符(本地 {local_size} / 已传 {n}),可能被中断")
        except Exception as ex:  # noqa: BLE001
            log.warning("remote push backup #%s → %s failed: %s", b.id, tname, ex)
            _set_replica(replica_id, status="failed", error=str(ex)[:500])
            with SessionLocal() as db:
                tt = db.get(BackupTarget, t.id)
                if tt:
                    tt.last_error = str(ex)[:500]
                    db.commit()
            return False
        _set_replica(replica_id, status="done", sha256=sha, size_bytes=n, error=None, pushed_at=datetime.now(timezone.utc))
        with SessionLocal() as db:
            tt = db.get(BackupTarget, t.id)
            if tt:
                tt.last_error = None
                db.commit()
        log.info("remote push backup #%s → %s ok (%s bytes, %.1fs)", b.id, tname, n, time.time() - started)
        return True
    except Exception as ex:  # noqa: BLE001
        log.exception("remote push error")
        _set_replica(replica_id, status="failed", error=str(ex)[:500])
        return False
    finally:
        with _lock:
            _inflight.discard(replica_id)


def retry_pending(limit: int = 3) -> int:
    """调度线程定期调用:重试 pending / failed(未超过最大次数)的副本。"""
    with SessionLocal() as db:
        rows = db.scalars(
            select(BackupReplica).where(BackupReplica.status.in_(("pending", "failed")), BackupReplica.attempts < MAX_ATTEMPTS)
            .order_by(BackupReplica.status.desc(), BackupReplica.id).limit(limit * 5)  # failed 优先于 pending
        ).all()
        with _pool_lock:
            ids = [r.id for r in rows if r.id not in _inflight and r.id not in _queued][:limit]
    for rid in ids:
        push_async(rid)
    return len(ids)


# ---------------------------------------------------------------- 删除 / 清理 / 拉回
def on_local_delete(b: Backup) -> None:
    """本地删除备份时:delete_with_local 的目标同步删远端(best effort);其余只标记本地已删。"""
    with SessionLocal() as db:
        rows = db.scalars(select(BackupReplica).where(BackupReplica.backup_id == b.id)).all()
        jobs = []
        for r in rows:
            t = db.get(BackupTarget, r.target_id)
            if r.status == "done" and t and t.delete_with_local and r.remote_key:
                jobs.append((t, r.id, r.remote_key))
    for t, rid, key in jobs:
        delete_async(t.id, key, rid, "deleted")  # 走工作池,不阻塞删除备份的请求线程


def prune_remote(limit: int = 20) -> int:
    """按目标 keep_days 删除过期的远端副本(只删我们推上去的对象)。"""
    now = datetime.now(timezone.utc)
    n = 0
    with SessionLocal() as db:
        targets = db.scalars(select(BackupTarget).where(BackupTarget.keep_days > 0, BackupTarget.enabled.is_(True))).all()
        jobs = []
        for t in targets:
            cutoff = now - timedelta(days=int(t.keep_days))
            rows = db.scalars(
                select(BackupReplica).where(BackupReplica.target_id == t.id, BackupReplica.status == "done", BackupReplica.pushed_at < cutoff)
                .order_by(BackupReplica.pushed_at).limit(limit)
            ).all()
            jobs += [(t, r.id, r.remote_key) for r in rows if r.remote_key]
    for t, rid, key in jobs:
        delete_async(t.id, key, rid, "expired")  # 走工作池,不阻塞备份调度线程
        n += 1
    return n


def pull(b: Backup, dest: str, say=log.info) -> bool:
    """本地备份文件丢失时,从任一 done 的远程副本拉回并校验 sha256。"""
    with SessionLocal() as db:
        rows = db.scalars(select(BackupReplica).where(BackupReplica.backup_id == b.id, BackupReplica.status == "done")).all()
        cands = [(db.get(BackupTarget, r.target_id), r.remote_key, r.sha256) for r in rows]
    for t, key, sha in cands:
        if not t or not key:
            continue
        say(f"本地备份文件不存在,从远程目标「{t.name}」拉回 …")
        tmp = dest + ".pulling"
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            driver(t).get(key, tmp)
            if sha and _sha256_file(tmp) != sha:
                raise RuntimeError("sha256 校验不一致")
            os.replace(tmp, dest)
            say(f"已从「{t.name}」拉回并校验通过")
            return True
        except Exception as ex:  # noqa: BLE001
            say(f"从「{t.name}」拉回失败:{ex}")
            try:
                os.remove(tmp)
            except OSError:
                pass
    return False


def replicas_for(db, backup_ids: list[int]) -> dict[int, list[dict]]:
    """列表接口用:一次取多个备份的副本状态。"""
    if not backup_ids:
        return {}
    rows = db.scalars(select(BackupReplica).where(BackupReplica.backup_id.in_(backup_ids))).all()
    tids = {r.target_id for r in rows}
    names = {t.id: t for t in db.scalars(select(BackupTarget).where(BackupTarget.id.in_(tids or {-1}))).all()}
    out: dict[int, list[dict]] = {}
    for r in rows:
        t = names.get(r.target_id)
        out.setdefault(r.backup_id, []).append({
            "id": r.id, "target_id": r.target_id, "target_name": t.name if t else f"#{r.target_id}", "kind": t.kind if t else None,
            "status": r.status, "error": r.error, "pushed_at": r.pushed_at, "sha256": r.sha256, "attempts": r.attempts,
        })
    return out
