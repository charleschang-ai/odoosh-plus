"""长任务日志的节流落库基类。

以前 EnvLogger / DepLog / _JobLog 每收到一行就把「最近 N 行」整块 UPDATE 进 TEXT 列:一次 60 行的创建 = 60 个事务、
每次重写越来越大的行(O(n²) 的 WAL/TOAST 写入),还要 60 次从连接池取连接。实时展示走的是 SSE(logstream.publish),
DB 里的日志只需是「最终可回看的快照」,所以这里改为:内存缓冲立即更新,DB 最多每 INTERVAL 秒写一次,
安静下来后由定时器补最后一次 flush。
"""

import logging
import threading
import time

log = logging.getLogger("odoosh.throttlelog")


class ThrottledLog:
    INTERVAL = 2.0   # DB 最小写入间隔(秒)
    KEEP = 400       # 落库保留最近多少行

    def __init__(self) -> None:
        self.buf: list[str] = []
        self._lock = threading.Lock()
        self._last_flush = 0.0
        self._timer: threading.Timer | None = None
        self._dirty = False
        self._last_msg = ""

    # 子类实现:把文本快照(与最后一条消息)写入 DB
    def _persist(self, text: str, last_msg: str) -> None:  # pragma: no cover - 抽象
        raise NotImplementedError

    def add(self, line: str, msg: str = "") -> None:
        do_flush = False
        with self._lock:
            self.buf.append(line)
            if len(self.buf) > self.KEEP * 2:  # 内存缓冲也有界(长升级可能几千行)
                del self.buf[: -self.KEEP]
            self._dirty = True
            self._last_msg = msg
            now = time.monotonic()
            if now - self._last_flush >= self.INTERVAL:
                do_flush = True
            elif self._timer is None:
                t = threading.Timer(self.INTERVAL - (now - self._last_flush), self.flush)
                t.daemon = True
                self._timer = t
                t.start()
        if do_flush:
            self.flush()

    def flush(self) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
            if not self._dirty:
                return
            self._dirty = False
            self._last_flush = time.monotonic()
            text = "\n".join(self.buf[-self.KEEP:])
            msg = self._last_msg
        try:
            self._persist(text, msg)
        except Exception as ex:  # noqa: BLE001
            log.warning("日志落库失败(忽略): %s", ex)

    def text(self) -> str:
        with self._lock:
            return "\n".join(self.buf[-self.KEEP:])
