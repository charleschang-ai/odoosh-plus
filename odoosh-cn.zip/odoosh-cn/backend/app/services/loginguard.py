"""登录防护:图形验证码 + 失败计数锁定 + 伪哈希(防用户名枚举计时侧信道)。

全部进程内状态(api 是单进程 uvicorn,够用;多进程部署需换 Redis)。
- 验证码:`captcha` 库(Pillow 画图)生成 4 位字母数字(去掉易混字符,字大、少噪点、不画干扰线,以看得清为先),一次性、5 分钟有效,最多缓存 20000 个(防刷内存)。
- 锁定:同一用户名连续失败 N 次(设置 auth.max_failures,默认 5)锁 3 分钟;同一 IP 失败 4N 次也锁。
  锁定只针对登录接口,不影响已登录会话。
- 设置 auth.captcha = 0 可关闭验证码(内网 / 自用);nginx 层还有 limit_req 兜底。
"""

from __future__ import annotations

import base64
import io
import secrets
import string
import threading
import time

import bcrypt

_lock = threading.Lock()
_captchas: dict[str, tuple[str, float]] = {}  # id -> (code, expires_at)
_fails: dict[str, list[float]] = {}  # key("u:<name>" / "ip:<addr>") -> 失败时间戳列表
_locked: dict[str, float] = {}  # key -> 解锁时间

CAPTCHA_TTL = 300
CAPTCHA_MAX = 20000
WINDOW = 600  # 失败计数窗口(秒)
LOCK_SECONDS = 180
_ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"  # 去掉 0/O/1/I 等易混字符

# 用户不存在时也跑一次 bcrypt,让「不存在」与「密码错」耗时一致
_DUMMY_HASH = bcrypt.hashpw(b"odoosh-dummy-password", bcrypt.gensalt()).decode()


def _setting(db, key: str, default: str) -> str:
    from ..routers.settings import get_setting

    try:
        return (get_setting(db, key) or default).strip()
    except Exception:  # noqa: BLE001
        return default


def captcha_enabled(db) -> bool:
    return _setting(db, "auth.captcha", "1") == "1"


def max_failures(db) -> int:
    try:
        return max(1, int(_setting(db, "auth.max_failures", "5")))
    except ValueError:
        return 5


# ---------------------------------------------------------------- 验证码
def _prune(now: float) -> None:
    dead = [k for k, (_, exp) in _captchas.items() if exp < now]
    for k in dead:
        _captchas.pop(k, None)
    if len(_captchas) > CAPTCHA_MAX:  # 被刷:丢最老的一半
        for k in sorted(_captchas, key=lambda k: _captchas[k][1])[: len(_captchas) // 2]:
            _captchas.pop(k, None)


CAPTCHA_LEN = 4


def _captcha_renderer():
    """比库默认清楚得多的验证码:字大、字符只轻微旋转 / 扭曲、几个噪点、不画干扰线。
    登录防刷主要靠一次性校验 + 失败锁定 + nginx limit_req,验证码不必难到人也认不出。"""
    from captcha.image import ImageCaptcha

    class ClearCaptcha(ImageCaptcha):
        # 新版 captcha 库把字符旋转 / 扭曲幅度做成了属性;老版本没有这些属性,赋值也无害
        character_rotate = (-8, 8)
        character_warp_dx = (0.03, 0.08)
        character_warp_dy = (0.03, 0.08)
        word_space_probability = 0.3
        word_offset_dx = 0.15

        def create_noise_dots(self, image, color, width=2, number=6):
            return super().create_noise_dots(image, color, width, number)

        def create_noise_curve(self, image, color):
            return image  # 不画干扰线

    return ClearCaptcha(width=170, height=60, font_sizes=(46, 50, 52))


def new_captcha() -> tuple[str, str]:
    """返回 (id, data-url PNG)。"""
    code = "".join(secrets.choice(_ALPHABET) for _ in range(CAPTCHA_LEN))
    cid = secrets.token_urlsafe(16)
    img = _captcha_renderer().generate(code)
    data = base64.b64encode(img.getvalue() if isinstance(img, io.BytesIO) else img.read()).decode()
    now = time.time()
    with _lock:
        _prune(now)
        _captchas[cid] = (code, now + CAPTCHA_TTL)
    return cid, "data:image/png;base64," + data


def check_captcha(cid: str | None, code: str | None) -> bool:
    """一次性校验:无论对错都作废该 id(防爆破)。"""
    if not cid or not code:
        return False
    with _lock:
        item = _captchas.pop(cid, None)
    if not item:
        return False
    real, exp = item
    return exp >= time.time() and secrets.compare_digest(real.lower(), code.strip().lower())


# ---------------------------------------------------------------- 失败计数 / 锁定
def _keys(username: str, ip: str | None) -> list[str]:
    ks = [f"u:{(username or '').lower()[:64]}"]
    if ip:
        ks.append(f"ip:{ip}")
    return ks


def locked_seconds(username: str, ip: str | None) -> int:
    """返回剩余锁定秒数(0 = 未锁定)。"""
    now = time.time()
    with _lock:
        best = 0
        for k in _keys(username, ip):
            until = _locked.get(k, 0)
            if until > now:
                best = max(best, int(until - now))
            elif k in _locked:
                _locked.pop(k, None)
        return best


def record_failure(username: str, ip: str | None, limit: int) -> int:
    """记一次失败;若达到阈值则锁定,返回本次触发的锁定秒数(0 = 未锁)。IP 维度阈值放宽 4 倍(NAT 后多人共用)。"""
    now = time.time()
    locked = 0
    with _lock:
        for k in _keys(username, ip):
            lst = [t for t in _fails.get(k, []) if now - t < WINDOW]
            lst.append(now)
            _fails[k] = lst
            thr = limit if k.startswith("u:") else limit * 4
            if len(lst) >= thr:
                _locked[k] = now + LOCK_SECONDS
                _fails[k] = []
                locked = LOCK_SECONDS
        if len(_fails) > 50000:  # 防被刷爆内存
            for k in [k for k, v in _fails.items() if not v or now - v[-1] > WINDOW]:
                _fails.pop(k, None)
    return locked


def record_success(username: str, ip: str | None) -> None:
    with _lock:
        for k in _keys(username, ip):
            _fails.pop(k, None)
            _locked.pop(k, None)


def dummy_verify(password: str) -> None:
    """用户不存在时也消耗一次 bcrypt 时间。"""
    try:
        bcrypt.checkpw(password.encode(), _DUMMY_HASH.encode())
    except Exception:  # noqa: BLE001
        pass
