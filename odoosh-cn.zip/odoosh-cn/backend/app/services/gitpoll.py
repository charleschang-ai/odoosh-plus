"""推送事件处理 + 定时轮询远端分支(无公网、收不到 Webhook 时的兜底)。

- record_push(): Webhook 与轮询共用——落 PushEvent、更新分支快照、匹配绑定实例。
- dispatch_push(): 调用编排模块注册的部署回调(services/git.register_push_hook)。
- poll_repo(): 拉一次远端分支,与快照比对,新分支/sha 变化 → 视为 push,分支消失 → 视为删除。
- start_poller(): 后台线程,每 N 分钟轮询所有仓库;N 来自 Setting `git.poll_minutes`(默认 5,0 = 关闭)。
"""

from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import SessionLocal
from ..models import Environment, Setting
from ..models_git import PushEvent, Repository
from . import git as gitsvc

log = logging.getLogger("odoosh.gitpoll")

POLL_KEY = "git.poll_minutes"
POLL_DEFAULT = 5
POLL_SOURCE = "轮询"

state = {"running": False, "last_run": None, "last_result": None, "thread_started": False}
_lock = threading.Lock()


# ---------------------------------------------------------------- 共用:记录一次 push
def envs_for_repo(db: Session, r: Repository) -> list:
    key = gitsvc.normalize_repo_url(r.url)
    # 只取有 repo_url 的行且只查需要的列(以前平台级仓库无 WHERE,整表 ORM 物化后在 Python 里归一化比较)
    q = select(Environment.id, Environment.branch, Environment.repo_url).where(Environment.repo_url.is_not(None), Environment.deleted_at.is_(None))
    if r.tenant_id is not None:
        q = q.where(Environment.tenant_id == r.tenant_id)
    from types import SimpleNamespace

    return [SimpleNamespace(id=eid, branch=br, repo_url=url) for eid, br, url in db.execute(q).all() if gitsvc.normalize_repo_url(url) == key]


def record_push(db: Session, r: Repository, info: dict, envs: list[Environment] | None = None) -> tuple[PushEvent, list[int], bool]:
    """落库一条推送事件并更新分支快照。返回 (event, 匹配的实例 id, 是否需要触发部署)。调用方负责 commit 之后 dispatch。
    envs:调用方已查好的该仓库绑定实例(一次轮询多个分支变化时复用,避免每个分支扫一遍)。"""
    matched = [e for e in (envs if envs is not None else envs_for_repo(db, r)) if (e.branch or "") == info["branch"]]
    env_ids = [e.id for e in matched]
    should_deploy = bool(r.auto_deploy and env_ids and not info["deleted"])
    if should_deploy:
        result = "处理中"
    elif info["deleted"]:
        result = "分支已删除"
    elif env_ids:
        result = "已记录;该仓库未开启自动部署"
    else:
        result = "已记录;无绑定环境"
    ev = PushEvent(
        repository_id=r.id,
        branch=info["branch"],
        commit_sha=info["sha"],
        commit_message=info["message"],
        author=info["author"],
        pusher=info["pusher"],
        deleted=info["deleted"],
        matched_env_ids=",".join(map(str, env_ids)) or None,
        result=result,
    )
    db.add(ev)
    _update_snapshot(r, info)
    db.commit()
    db.refresh(ev)
    return ev, env_ids, should_deploy


def _update_snapshot(r: Repository, info: dict) -> None:
    """把这次 push 合并进分支快照,避免用户再手动同步。"""
    if not r.branches_json:
        return
    try:
        snap = json.loads(r.branches_json)
    except ValueError:
        return
    lst = snap.get("branches", [])
    now = datetime.now().astimezone().isoformat()
    if info["deleted"]:
        snap["branches"] = [b for b in lst if b["name"] != info["branch"]]
    else:
        for b in lst:
            if b["name"] == info["branch"]:
                b.update(sha=info["sha"], message=info["message"], author=info["author"], date=info.get("date") or now)
                break
        else:
            lst.append({"name": info["branch"], "sha": info["sha"], "message": info["message"], "author": info["author"], "date": info.get("date") or now})
    r.branches_json = gitsvc.dumps(snap)


def dispatch_push(repo_id: int, event_id: int, env_ids: list[int], info: dict) -> None:
    """调用已注册的部署回调并回写结果(可在 BackgroundTasks 或轮询线程中执行)。"""
    if gitsvc.has_push_hooks():
        gitsvc.run_push_hooks(repo_id, env_ids, info)
        result = f"已触发 {len(env_ids)} 个环境重新部署"
    else:
        result = "已记录;自动部署尚未接入" if env_ids else "已记录;无绑定环境"
    with SessionLocal() as db:
        ev = db.get(PushEvent, event_id)
        if ev:
            ev.result = result
            db.commit()


# ---------------------------------------------------------------- 轮询
def _set_repo_error(repo_id: int, msg: str) -> None:
    with SessionLocal() as db:
        r = db.get(Repository, repo_id)
        if r:
            r.last_error = msg[:512]
            db.commit()


def poll_repo(repo_id: int) -> list[dict]:
    """检查一个仓库的远端分支变化。返回本次产生的事件摘要列表。

    分三段:读输入(短 session)→ 全部网络 IO(不持有连接;以前整段包在一个 session 里,ls-remote + 上百次
    commit API 期间连接池被占着)→ 写结果(短 session)。变化分支的 commit 详情并行拉取。"""
    found: list[dict] = []
    # ---- 1. 读输入
    with SessionLocal() as db:
        r = db.get(Repository, repo_id)
        if not r:
            return found
        token = None
        if r.token:
            token = r.token
        elif r.account:
            try:
                from . import gitoauth

                token = gitoauth.refresh_if_needed(db, r.account).access_token
            except Exception as e:  # noqa: BLE001
                r.last_error = f"轮询:{e}"[:512]
                db.commit()
                return found
        url = r.url
        old: dict[str, str] = {}
        if r.branches_json:
            try:
                old = {b["name"]: b.get("sha") for b in json.loads(r.branches_json).get("branches", [])}
            except ValueError:
                old = {}
    first_time = not old

    # ---- 2. 网络
    try:
        info = gitsvc.parse_repo_url(url)
        refs, default = gitsvc.ls_remote(url, token)
    except (RuntimeError, ValueError) as e:
        _set_repo_error(repo_id, f"轮询失败:{e}")
        return found
    snap = None
    details: dict[str, dict | None] = {}
    changed: list[str] = []
    removed: list[str] = []
    if first_time:
        try:
            snap = gitsvc.sync_branches(url, token)  # 没有基线:只建立快照,不产生事件
        except (RuntimeError, ValueError) as e:
            _set_repo_error(repo_id, f"轮询失败:{e}")
            return found
    else:
        changed = [n for n, sha in refs.items() if old.get(n) != sha]
        removed = [n for n in old if n not in refs]
        if changed and info["provider"] != "generic":
            from concurrent.futures import ThreadPoolExecutor

            with ThreadPoolExecutor(max_workers=min(8, len(changed))) as ex:
                futs = {n: ex.submit(gitsvc.fetch_commit, info, refs[n], token) for n in changed}
                for n, f in futs.items():
                    try:
                        details[n] = f.result()
                    except Exception:  # noqa: BLE001
                        details[n] = None

    # ---- 3. 写结果
    with SessionLocal() as db:
        r = db.get(Repository, repo_id)
        if not r:
            return found
        if snap is not None:
            r.branches_json = gitsvc.dumps(snap)
        else:
            envs = envs_for_repo(db, r) if (changed or removed) else []
            for name in changed:
                sha = refs[name]
                detail = details.get(name)
                msg = (detail or {}).get("message")
                push = {
                    "branch": name,
                    "sha": sha,
                    "message": msg.strip().splitlines()[0][:500] if msg else None,
                    "author": (detail or {}).get("author"),
                    "date": (detail or {}).get("date"),
                    "pusher": POLL_SOURCE,
                    "deleted": False,
                }
                ev, env_ids, deploy = record_push(db, r, push, envs)
                found.append({"branch": name, "sha": sha, "event_id": ev.id, "environments": env_ids})
                if deploy:
                    dispatch_push(r.id, ev.id, env_ids, push)
            for name in removed:
                push = {"branch": name, "sha": None, "message": None, "author": None, "pusher": POLL_SOURCE, "deleted": True}
                ev, env_ids, _ = record_push(db, r, push, envs)
                found.append({"branch": name, "sha": None, "event_id": ev.id, "environments": env_ids, "deleted": True})
        r.default_branch = default or r.default_branch
        r.branches_synced_at = datetime.now(timezone.utc)
        r.last_error = None
        db.commit()
    return found


def poll_all() -> dict:
    """轮询全部仓库(串行,避免同时打爆 Git 平台限额)。"""
    if not _lock.acquire(blocking=False):
        return {"skipped": True, "reason": "上一轮尚未结束"}
    state["running"] = True
    started = time.time()
    total_events = 0
    repos_done = 0
    errors = 0
    try:
        with SessionLocal() as db:
            ids = list(db.scalars(select(Repository.id).order_by(Repository.id)).all())
        for rid in ids:
            try:
                total_events += len(poll_repo(rid))
                repos_done += 1
            except Exception:  # noqa: BLE001
                errors += 1
                log.exception("轮询仓库 #%s 失败", rid)
        res = {"repos": repos_done, "events": total_events, "errors": errors, "seconds": round(time.time() - started, 1)}
        state["last_run"] = datetime.now(timezone.utc).isoformat()
        state["last_result"] = res
        if total_events:
            log.info("轮询完成: %s", res)
        return res
    finally:
        state["running"] = False
        _lock.release()


def get_interval(db: Session | None = None) -> int:
    def _read(s: Session) -> int:
        row = s.get(Setting, POLL_KEY)
        try:
            return max(0, int(row.value)) if row and row.value not in (None, "") else POLL_DEFAULT
        except ValueError:
            return POLL_DEFAULT

    if db is not None:
        return _read(db)
    with SessionLocal() as s:
        return _read(s)


def set_interval(db: Session, minutes: int) -> None:
    row = db.get(Setting, POLL_KEY)
    if row:
        row.value = str(minutes)
    else:
        db.add(Setting(key=POLL_KEY, value=str(minutes)))
    db.commit()


def _loop() -> None:
    time.sleep(20)  # 等平台启动稳定
    while True:
        minutes = get_interval()
        if minutes > 0:
            t0 = time.time()
            try:
                poll_all()
            except Exception:  # noqa: BLE001
                log.exception("轮询线程异常")
            time.sleep(max(30.0, minutes * 60 - (time.time() - t0)))  # 扣掉本轮耗时,间隔不再随仓库数漂移
        else:
            time.sleep(60)  # 已关闭:每分钟看一次设置是否被打开


def start_poller() -> None:
    if state["thread_started"]:
        return
    state["thread_started"] = True
    threading.Thread(target=_loop, name="git-poller", daemon=True).start()
    log.info("Git 远端分支轮询已启动(间隔由设置 %s 控制,默认 %s 分钟)", POLL_KEY, POLL_DEFAULT)
