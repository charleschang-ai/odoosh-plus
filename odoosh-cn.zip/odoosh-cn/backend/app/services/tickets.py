"""短期一次性票据(SSO 一键登录、Web Shell):HS256 JWT + 进程内「已兑换」集合。

- 每张票据带 jti,兑换即作废(同一票据在有效期内再次出现直接拒绝,防 URL 泄露后重放)。
- 带 tv(token_version):用户改密 / 被停用后,已签发的票据同样失效。
- 兑换时重新加载用户并确认 is_active;调用方再按动作做一次权限检查(权限可能在签发后被撤销)。
"""

from __future__ import annotations

import secrets
import threading
import time

from jose import JWTError, jwt

from ..config import settings

_lock = threading.Lock()
_used: dict[str, float] = {}  # jti -> 过期时间


def issue(kind: str, env_id: int, user, ttl: int, extra: dict | None = None) -> str:
    payload = {"sub": kind, "env": int(env_id), "uid": int(user.id), "tv": int(getattr(user, "token_version", 0) or 0),
               "jti": secrets.token_urlsafe(12), "exp": int(time.time()) + int(ttl)}
    if extra:
        payload.update(extra)
    return jwt.encode(payload, settings.secret_key, algorithm="HS256")


def consume_jti(jti: str, exp: float | None) -> None:
    """一次性消费 jti:同一 jti 在有效期内再次出现直接拒绝(抛 ValueError)。供本模块与其它短期票据共用。"""
    now = time.time()
    with _lock:
        for k in [k for k, e in _used.items() if e < now]:
            _used.pop(k, None)
        if jti in _used:
            raise ValueError("票据已使用过")
        _used[jti] = float(exp or now + 300)


def redeem(token: str, kind: str, db) -> tuple[dict, object]:
    """校验 + 一次性消费。返回 (payload, user)。任何问题抛 ValueError(文案可直接给用户看)。"""
    from ..models import User

    try:
        p = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
    except JWTError as e:
        raise ValueError(f"票据无效或已过期:{e}")
    if p.get("sub") != kind or "env" not in p or "uid" not in p or "jti" not in p:
        raise ValueError("票据无效")
    consume_jti(p["jti"], p.get("exp"))
    user = db.get(User, int(p["uid"]))
    if not user or not user.is_active:
        raise ValueError("用户不存在或已停用")
    if int(p.get("tv", 0)) != int(user.token_version or 0):
        raise ValueError("票据已失效(账号凭据已变更)")
    return p, user
