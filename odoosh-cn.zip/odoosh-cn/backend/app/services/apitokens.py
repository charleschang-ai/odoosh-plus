"""接入令牌:生成 / 校验,以及「令牌 + 用户名 → 该用户自己的实例」的解析。

两种短期 JWT 都用平台 secret_key 签,靠 sub / typ 与登录令牌区分(auth.get_current_user 只认 typ=access):
- 身份确认凭据(typ=idcheck,5 分钟):超管创建令牌前先输一次当前密码,通过后拿到它,创建接口凭它放行。
- 免登入口票据(sub=ext-open,5 分钟,可重复使用):handoff 返回的地址里带它;/api/ext/open 用它确认
  「令牌仍有效 + 用户仍有效 + 实例仍归他」后,才签发真正一次性的实例 SSO 票据(services.sso)。
  可重复使用是为了实例休眠时能停在唤醒等待页自动刷新,直到就绪再进入。
"""

from __future__ import annotations

import hashlib
import re
import secrets
import time
from datetime import datetime, timezone

from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..models import Environment, Membership, Tenant, User
from ..models_token import ApiToken

PREFIX = "osh_"
IDENTITY_TTL = 300   # 身份确认凭据有效秒数
OPEN_TTL = 300       # 免登入口地址有效秒数
MAX_DAYS = 730       # 令牌最长有效天数


# ---------------------------------------------------------------- 生成 / 哈希
def hash_token(plain: str) -> str:
    return hashlib.sha256(plain.encode()).hexdigest()


def generate() -> tuple[str, str, str]:
    """返回 (明文, 哈希, 前缀)。明文只回显一次。"""
    plain = PREFIX + secrets.token_urlsafe(32)
    return plain, hash_token(plain), plain[:12]


def _utc(dt: datetime | None) -> datetime | None:
    return None if dt is None else (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc))


def is_expired(tok: ApiToken, now: datetime | None = None) -> bool:
    return tok.expires_at is not None and _utc(tok.expires_at) <= (now or datetime.now(timezone.utc))


def status_of(tok: ApiToken) -> str:
    if tok.revoked_at:
        return "revoked"
    return "expired" if is_expired(tok) else "active"


# ---------------------------------------------------------------- 身份确认凭据
def issue_identity_grant(user: User) -> str:
    return jwt.encode({"sub": str(user.id), "typ": "idcheck", "tv": int(user.token_version or 0),
                       "jti": secrets.token_urlsafe(8), "exp": int(time.time()) + IDENTITY_TTL},
                      settings.secret_key, algorithm="HS256")


def check_identity_grant(grant: str, user: User) -> None:
    try:
        p = jwt.decode(grant or "", settings.secret_key, algorithms=["HS256"])
    except JWTError:
        raise ValueError("身份验证已过期,请重新输入密码")
    if p.get("typ") != "idcheck" or p.get("sub") != str(user.id) or int(p.get("tv", -1)) != int(user.token_version or 0):
        raise ValueError("身份验证已过期,请重新输入密码")


# ---------------------------------------------------------------- 校验
def validate(db: Session, tok: ApiToken) -> None:
    """令牌是否仍可用;不可用抛 ValueError(文案可直接返回给调用方)。"""
    if tok.revoked_at:
        raise ValueError("令牌已吊销")
    if is_expired(tok):
        raise ValueError("令牌已过期")
    creator = db.get(User, tok.user_id)
    if not creator or not creator.is_active or creator.role != "admin":
        raise ValueError("令牌创建者已停用或不再是超级管理员")
    tenant = db.get(Tenant, tok.tenant_id)
    if not tenant or not tenant.is_active:
        raise ValueError("令牌绑定的组织不存在或已停用")


def lookup(db: Session, plain: str | None) -> ApiToken:
    """按明文找到并校验令牌;找不到 / 不可用抛 ValueError。"""
    plain = (plain or "").strip()
    if not plain.startswith(PREFIX):
        raise ValueError("令牌无效")
    tok = db.scalar(select(ApiToken).where(ApiToken.token_hash == hash_token(plain)))
    if not tok:
        raise ValueError("令牌无效")
    validate(db, tok)
    return tok


def scopes_of(tok: ApiToken) -> set[str]:
    return {s.strip() for s in (tok.scopes or "").split(",") if s.strip()}


def has_scope(tok: ApiToken, scope: str) -> bool:
    return scope in scopes_of(tok)


def check_scope(tok: ApiToken, scope: str) -> None:
    """令牌是否被授予该权限范围;没有抛 PermissionError。"""
    if not has_scope(tok, scope):
        raise PermissionError(f"该令牌没有「{scope}」权限,请在接入令牌设置里勾选后重试")


def find_by_external(db: Session, tok: ApiToken, external_id: str) -> User | None:
    """按 (来源, 外部主键) 找平台用户;找不到返回 None。"""
    return db.scalar(select(User).where(User.external_source == tok.source,
                                        User.external_id == str(external_id).strip()))


def resolve_user(db: Session, tok: ApiToken, uid: str | None) -> User:
    """令牌 + 标识 → 用户。标识先按 external_id 找,找不到再按用户名找(两种形式都支持,便于未同步时直接用用户名调试)。
    找不到 / 已停用抛 LookupError;不在令牌组织抛 PermissionError;参数问题抛 ValueError。"""
    uid = (uid or "").strip()
    if not uid:
        raise ValueError("缺少 uid(接入方的用户唯一标识:external_id 或 OdooshCN 用户名)")
    user = find_by_external(db, tok, uid) or db.scalar(select(User).where(User.username == uid))
    if not user or not user.is_active:
        raise LookupError(f"用户 {uid} 不存在或已停用")
    if user.role != "admin":
        q = select(Membership.id).where(Membership.user_id == user.id)
        if not tok.allow_any_tenant:
            q = q.where(Membership.tenant_id == tok.tenant_id)
        if not db.scalar(q):
            raise PermissionError(f"用户 {uid} 不是令牌" + ("可操作组织" if tok.allow_any_tenant else "绑定组织") + "的成员")
    return user


def tenant_ids_for(db: Session, tok: ApiToken, user: User) -> list[int]:
    """令牌能替该用户操作的组织:默认只有绑定组织;令牌开了 allow_any_tenant 时是该用户所在的全部启用组织。"""
    if not tok.allow_any_tenant:
        return [tok.tenant_id]
    rows = db.execute(select(Membership.tenant_id).join(Tenant, Tenant.id == Membership.tenant_id)
                      .where(Membership.user_id == user.id, Tenant.is_active.is_(True))).all()
    ids = [t for (t,) in rows]
    return ids or [tok.tenant_id]


ENV_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}$")
_ENV_NAME_BAD = re.compile(r"[^a-z0-9-]+")


def normalize_env_name(raw, fallback: str = "") -> str:
    """把接入方给的实例名收拾成合法的实例名:转小写,非法字符变 -,连续的 - 合并,去掉首尾的 -,
    截到 63 位(DNS 单段上限)。收拾完什么都不剩时用 fallback。

    为什么平台要替接入方做这一步:实例名会变成主机名的一段(<实例>-<组织>.<基础域名>),而主机名
    只认字母、数字和连字符 —— teacher_wang 在接入方那边是个完全正常的用户名,到这里却是非法实例名。
    这里原本是直接报错、要求接入方自己转换,但接入模块一旦发到各个学校就改不动了,平台多做一步
    远比指望每个接入方各写一份转换靠谱。

    幂等性靠的是「查找和创建走同一个函数」:resolve_env / ensure_env 都先 normalize,所以接入方
    拿 teacher_wang 来查,查到的就是当初建出来的 teacher-wang,不会重复创建。接入方想知道实际用的
    是哪个名字,upsert / create 的响应里有 env_name。"""
    name = _ENV_NAME_BAD.sub("-", str(raw or "").strip().lower()).strip("-")
    name = re.sub(r"-{2,}", "-", name)[:63].rstrip("-")
    return name or fallback


def env_name_candidates(name: str, user_id: int) -> list[str]:
    """首选名被占用时依次尝试的备选名。

    实例名在组织内唯一,而且**回收站里的实例仍然占着名字**(恢复时要用回原名)。所以「删掉用户
    → 实例进回收站 → 再把用户同步回来」这条路,如果不换名字就会永远卡在 env_name_taken 上,
    接入方那边表现为「同步成功了但实例死活建不出来」。

    查找(resolve_env / ensure_env)和创建都按这个列表来,所以下次同步仍然认得出是同一个实例。
    截断时留出后缀的位置,保证每个候选名都还在 63 位以内。"""
    out = [name]
    for suffix in [f"-{user_id}"] + [f"-{user_id}-{i}" for i in range(2, 10)]:
        base = name[:63 - len(suffix)].rstrip("-") or f"u{user_id}"
        out.append(base + suffix)
    return out


def resolve_env(db: Session, tok: ApiToken, user: User, env_name: str | None = None) -> Environment:
    """用户在令牌可操作组织下拥有的实例;没有抛 LookupError。多个时根实例优先、再按 id 升序;可用 env_name 指定。"""
    q = select(Environment).where(Environment.tenant_id.in_(tenant_ids_for(db, tok, user)),
                                  Environment.owner_user_id == user.id,
                                  Environment.deleted_at.is_(None))
    if env_name:
        # 按规范化后的名字查:库里存的一定是规范化过的,接入方传原始写法也要能命中;
        # 带上备选名,首选名当初被占、实际建成 <名字>-<uid> 的那些也找得到
        q = q.where(Environment.name.in_(env_name_candidates(normalize_env_name(env_name), user.id)))
    envs = db.scalars(q.order_by(Environment.project_id.is_not(None), Environment.id)).all()
    if not envs:
        raise LookupError(f"用户 {user.username} 在该组织下没有" + (f"名为 {env_name} 的实例" if env_name else "实例"))
    return envs[0]


def resolve(db: Session, tok: ApiToken, uid: str | None, env_name: str | None = None) -> tuple[User, Environment]:
    """resolve_user + resolve_env 的合体(target=odoo 用)。"""
    user = resolve_user(db, tok, uid)
    return user, resolve_env(db, tok, user, env_name)


# ---------------------------------------------------------------- 控制台登录 code(target=console)
CODE_TTL = 60


def make_login_code(tok: ApiToken, user: User) -> str:
    """一次性、60 秒:前端 /auth/callback 拿它换平台登录令牌。不直接把登录令牌放 URL(有效期长、会留在历史记录里)。"""
    return jwt.encode({"sub": "ext-code", "tok": int(tok.id), "uid": int(user.id), "tv": int(user.token_version or 0),
                       "jti": secrets.token_urlsafe(12), "exp": int(time.time()) + CODE_TTL},
                      settings.secret_key, algorithm="HS256")


def redeem_login_code(db: Session, code: str) -> tuple[ApiToken, User]:
    """校验并一次性消费 code;任何问题抛 ValueError。"""
    from . import tickets

    try:
        p = jwt.decode(code or "", settings.secret_key, algorithms=["HS256"])
    except JWTError as ex:
        raise ValueError(f"登录凭据无效或已过期:{ex}")
    if p.get("sub") != "ext-code" or not all(k in p for k in ("tok", "uid", "jti")):
        raise ValueError("登录凭据无效")
    tickets.consume_jti(p["jti"], p.get("exp"))
    tok = db.get(ApiToken, int(p["tok"]))
    if not tok:
        raise ValueError("令牌不存在")
    validate(db, tok)
    user = db.get(User, int(p["uid"]))
    if not user or not user.is_active or int(p.get("tv", -1)) != int(user.token_version or 0):
        raise ValueError("用户不存在或已停用")
    return tok, user


# ---------------------------------------------------------------- 免登入口票据
def make_open_ticket(tok: ApiToken, user: User, env: Environment) -> str:
    return jwt.encode({"sub": "ext-open", "tok": int(tok.id), "uid": int(user.id), "env": int(env.id),
                       "tv": int(user.token_version or 0), "exp": int(time.time()) + OPEN_TTL},
                      settings.secret_key, algorithm="HS256")


def read_open_ticket(db: Session, t: str) -> tuple[ApiToken, User, Environment]:
    """校验入口票据(可重复使用,直到过期);任何问题抛 ValueError。"""
    try:
        p = jwt.decode(t or "", settings.secret_key, algorithms=["HS256"])
    except JWTError as ex:
        raise ValueError(f"链接无效或已过期:{ex}")
    if p.get("sub") != "ext-open" or not all(k in p for k in ("tok", "uid", "env")):
        raise ValueError("链接无效")
    tok = db.get(ApiToken, int(p["tok"]))
    if not tok:
        raise ValueError("令牌不存在")
    validate(db, tok)
    user = db.get(User, int(p["uid"]))
    if not user or not user.is_active or int(p.get("tv", -1)) != int(user.token_version or 0):
        raise ValueError("用户不存在或已停用")
    env = db.get(Environment, int(p["env"]))
    if not env or env.deleted_at or env.tenant_id != tok.tenant_id or env.owner_user_id != user.id:
        raise ValueError("实例不存在或已不属于该用户")
    return tok, user, env


__all__ = ["PREFIX", "IDENTITY_TTL", "OPEN_TTL", "CODE_TTL", "MAX_DAYS", "generate", "hash_token", "is_expired", "status_of",
           "issue_identity_grant", "check_identity_grant", "validate", "lookup", "scopes_of", "has_scope", "check_scope",
           "find_by_external", "resolve_user", "resolve_env", "resolve",
           "make_open_ticket", "read_open_ticket", "make_login_code", "redeem_login_code"]
