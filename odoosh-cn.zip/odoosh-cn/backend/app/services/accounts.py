"""用户账号的公共逻辑(单条 / 批量共用):成员关系同步、批量创建、批量更新。

router 里的单条创建 / 编辑仍走 routers/users.py;这里抽出「多条用户」要复用的那部分,
既给批量接口用,也让 router 的 `_sync_memberships` 收敛到同一份实现,避免两条路径校验分叉。
"""

import logging
import re
import secrets
import string

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import authz
from ..auth import hash_password, revoke_tokens
from ..config import settings
from ..models import Environment, Membership, Tenant, User

log = logging.getLogger("odoosh.accounts")

# 用户名:字母 / 数字开头,允许 . _ -,2~64 位。批量导入时用它拦下 CSV 里的脏数据(单条接口只有长度限制)
USERNAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{1,63}$")
MEMBERSHIP_LABEL = {"owner": "组织管理员", "developer": "开发者", "tester": "测试者"}


def is_root(user: User) -> bool:
    """内置超级管理员(ODOOSH_ADMIN_USER):任何批量都不能停用 / 降级 / 改密。"""
    return user.username == settings.admin_user


def gen_password(n: int = 12) -> str:
    """随机初始密码(去掉易混字符);仅在创建响应里回显一次,不落库、不写日志。"""
    alphabet = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"
    return "".join(secrets.choice(alphabet) for _ in range(n))


def sync_memberships(db: Session, user: User, items: list) -> None:
    """整体替换用户的组织角色(同一组织只保留一条)。超级管理员不需要成员关系,一并清空并清 ACL 残留。

    items: list[schemas.MembershipIn]。与原 routers/users.py._sync_memberships 行为一致。
    """
    if authz.is_superadmin(user):
        for m in db.scalars(select(Membership).where(Membership.user_id == user.id)).all():
            authz.purge_env_acl(db, user.id, m.tenant_id)
        db.query(Membership).filter(Membership.user_id == user.id).delete()
        return
    wanted: dict[int, str] = {}
    for it in items:
        if it.role not in authz.ROLES:
            raise HTTPException(400, f"无效角色 {it.role}")
        if not db.get(Tenant, it.tenant_id):
            raise HTTPException(404, f"组织 {it.tenant_id} 不存在")
        wanted[it.tenant_id] = it.role
    existing = {m.tenant_id: m for m in db.scalars(select(Membership).where(Membership.user_id == user.id)).all()}
    for tid, m in existing.items():
        if tid not in wanted:
            authz.purge_env_acl(db, user.id, tid)  # 退出该组织:清掉其实例授权
            db.delete(m)
        elif m.role != wanted[tid]:
            m.role = wanted[tid]
    for tid, role in wanted.items():
        if tid not in existing:
            db.add(Membership(user_id=user.id, tenant_id=tid, role=role))


def apply_membership_op(db: Session, user: User, mode: str, items: list, remove_tenant_ids: list[int]) -> str | None:
    """批量赋权:在不整体替换的前提下增量地加 / 改 / 减组织成员关系。返回一句变更摘要(无变化返回 None)。

    mode:
      add     —— 加入 items 里的组织(已在则改角色);不动其它组织。
      replace —— 用 items 整体替换该用户的组织列表(= sync_memberships)。
      remove  —— 退出 remove_tenant_ids 里的组织(清 ACL 残留)。
    超级管理员无成员关系,直接跳过。
    """
    if authz.is_superadmin(user):
        return None
    if mode == "replace":
        before = {m.tenant_id: m.role for m in db.scalars(select(Membership).where(Membership.user_id == user.id)).all()}
        sync_memberships(db, user, items)
        after = {it.tenant_id: it.role for it in items}
        return "替换组织角色" if before != after else None
    existing = {m.tenant_id: m for m in db.scalars(select(Membership).where(Membership.user_id == user.id)).all()}
    changed: list[str] = []
    if mode == "add":
        for it in items:
            if it.role not in authz.ROLES:
                raise HTTPException(400, f"无效角色 {it.role}")
            t = db.get(Tenant, it.tenant_id)
            if not t:
                raise HTTPException(404, f"组织 {it.tenant_id} 不存在")
            m = existing.get(it.tenant_id)
            if m is None:
                db.add(Membership(user_id=user.id, tenant_id=it.tenant_id, role=it.role))
                changed.append(f"加入{t.name}")
            elif m.role != it.role:
                m.role = it.role
                changed.append(f"{t.name}改{MEMBERSHIP_LABEL.get(it.role, it.role)}")
    elif mode == "remove":
        for tid in remove_tenant_ids:
            m = existing.get(tid)
            if m is not None:
                authz.purge_env_acl(db, user.id, tid)
                db.delete(m)
                t = db.get(Tenant, tid)
                changed.append(f"退出{t.name if t else tid}")
    else:
        raise HTTPException(400, f"未知的赋权模式 {mode}")
    return "、".join(changed) if changed else None


def create_one(db: Session, row) -> tuple[User, str]:
    """创建一个用户(不 commit,调用方统一提交)。返回 (user, 明文密码)。

    row: schemas.BulkUserRowIn。用户名重复 / 组织不存在等抛 HTTPException,交给批量层作为「整批失败」处理。
    """
    if not USERNAME_RE.match(row.username or ""):
        raise HTTPException(400, f"用户名「{row.username}」不合法(字母/数字开头,可含 . _ -,2~64 位)")
    if db.scalar(select(User).where(User.username == row.username)):
        raise HTTPException(409, f"用户名「{row.username}」已存在")
    role = "admin" if row.role == "admin" else "member"
    plain = (row.password or "").strip() or gen_password()
    user = User(
        username=row.username,
        password_hash=hash_password(plain),
        display_name=(row.display_name or None),
        role=role,
        shell_enabled=bool(row.shell_enabled),
        menu_dashboard=bool(row.menu_dashboard),
        menu_repos=bool(row.menu_repos),
        menu_ai=bool(row.menu_ai),
        menu_backups=bool(row.menu_backups),
        menu_settings=bool(row.menu_settings),
        menu_upgrade=bool(row.menu_upgrade),
        menu_databases=bool(row.menu_databases),
        max_envs=row.max_envs if (row.max_envs is None or row.max_envs >= 0) else None,
        max_dbs=row.max_dbs if (row.max_dbs is None or row.max_dbs >= 0) else None,
    )
    db.add(user)
    db.flush()
    sync_memberships(db, user, list(row.memberships or []))
    return user, plain


# ---------------------------------------------------------------- 删除
def delete_with_envs(db: Session, user: User, purge_envs: bool = False, envs=None) -> list[int]:
    """删除用户,并先处理掉他名下的实例;返回被处理的实例 id。调用方负责 commit。

    实例必须先处理:Environment.owner_user_id 只是个普通整数列,**没有外键约束**,数据库既不会
    级联也不会拦。直接 db.delete(user) 会留下 owner_user_id 指向不存在账号的孤儿实例 ——
    配额算不到它、列表里没有归属、只有超管在总览里才翻得到。

    envs:调用方已经筛好的实例(接入令牌只能动自己组织内的那些);None = 该用户名下全部未删除实例。
    purge_envs:True 连容器、数据库、文件一并销毁,不可恢复;False(默认)进回收站,数据保留可恢复。
    单个实例处理失败不阻断删除:用户还是要删掉的,失败的实例会留在日志里等人工处理。
    """
    from . import jobs, orchestrator

    if envs is None:
        envs = db.scalars(select(Environment).where(
            Environment.owner_user_id == user.id, Environment.deleted_at.is_(None))).all()
    handled: list[int] = []
    for e in envs:
        try:
            if not e.container_name and not e.db_name:
                db.delete(e)              # 从未编排过:直接删记录,没有容器和数据要收拾
            elif purge_envs:
                e.status = "destroying"
                db.flush()
                jobs.spawn(orchestrator.destroy, e.id)
            else:
                jobs.spawn(orchestrator.trash, e.id)   # 停容器、摘域名,数据按保留天数留着
            handled.append(e.id)
        except Exception as ex:  # noqa: BLE001
            log.warning("删除用户 #%s 时处理实例 env#%s 失败(用户仍会被删除): %s", user.id, e.id, ex)
    db.delete(user)   # 成员关系与实例授权由外键级联清理
    db.flush()
    log.info("删除用户 #%s(%s),实例 %s(%s)", user.id, user.username, handled,
             "purge" if purge_envs else "trash")
    return handled
