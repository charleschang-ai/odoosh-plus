"""平台级离线企业版代码:内网无 git 时,把企业版 addons 按版本放到约定目录,创建实例直接只读挂载。

约定目录(容器内)= <data_dir>/offline/enterprise/<版本>/,对应宿主机 <host_data_dir>/offline/enterprise/<版本>/。
版本目录里直接放企业版 addons 模块(每个模块含 __manifest__.py),模块在根目录或 addons/ 子目录都可。

与「Git 仓库(企业版)」来源并存:创建企业版实例时,平台离线目录里有对应版本 → 直接用(不联网、不依赖 git);
没有 → 回落到现有的 git 仓库探测/拉取流程。企业版代码需组织自行持有合法授权,平台不分发代码。
"""

import logging
import os
import re
import shutil
import threading
import time
import zipfile
from uuid import uuid4

from ..config import settings

log = logging.getLogger("odoosh.offline_enterprise")

# 按版本的播种锁:批量创建同版本企业版实例时,多个 worker 会同时发现「统一目录还没有这个版本」
# 而一起往里复制 —— 彼此 rmtree 掉对方的临时目录 / 成品,结果可能是半套代码被挂载。
_seed_locks: dict[str, threading.Lock] = {}
_seed_locks_guard = threading.Lock()


def _seed_lock(version: str) -> threading.Lock:
    with _seed_locks_guard:
        return _seed_locks.setdefault(version, threading.Lock())


def base_dir() -> str:
    """统一的企业版代码目录(容器内)。由系统设置 odoo.enterprise_dir 控制,默认 <data_dir>/offline/enterprise。"""
    d = None
    try:
        from ..db import SessionLocal
        from ..routers.settings import get_setting

        with SessionLocal() as db:
            d = (get_setting(db, "odoo.enterprise_dir") or "").strip()
    except Exception as ex:  # noqa: BLE001
        log.debug("读取 odoo.enterprise_dir 失败,用默认: %s", ex)
    d = d or os.path.join(settings.data_dir, "offline", "enterprise")
    os.makedirs(d, exist_ok=True)
    return d


def host_base_dir() -> str:
    """宿主机上的同一目录(容器内路径在 data_dir 下时,前缀换成 host_data_dir)。"""
    d = base_dir()
    if d.startswith(settings.data_dir):
        return (settings.host_data_dir or settings.data_dir) + d[len(settings.data_dir):]
    return d


def _has_modules(d: str) -> bool:
    """目录下是否有 Odoo 模块(任一子目录含 __manifest__.py)。与 enterprise.ensure_code 的判据一致。"""
    try:
        return os.path.isdir(d) and any(
            os.path.isfile(os.path.join(d, n, "__manifest__.py")) for n in os.listdir(d)
        )
    except OSError:
        return False


def _module_count(d: str) -> int:
    try:
        return sum(1 for n in os.listdir(d) if os.path.isfile(os.path.join(d, n, "__manifest__.py")))
    except OSError:
        return 0


def _version_dir_candidates(version: str) -> list[str]:
    """接受 '19' 或 '19.0':两种目录名都认(优先与用户输入一致的)。"""
    v = str(version).strip()
    base = v[:-2] if v.endswith(".0") else v
    return [base, f"{base}.0"]


def addons_root(version_path: str) -> tuple[str, str] | None:
    """定位版本目录里真正的 addons 根,按顺序尝试(返回 (绝对路径, 相对子路径),找不到 → None):
      1. 模块直接在版本目录下           → (根, '')
      2. 在 addons/ 子目录              → (…, 'addons')
      3. 整仓库文件夹拷进来(单层包裹,如 19/enterprise/…)→ 认该包裹目录,及其 addons/ 子目录
    即 git clone 出来的外层文件夹整个拖进版本目录也能识别,不必手动拍平。"""
    if _has_modules(version_path):
        return version_path, ""
    sub = os.path.join(version_path, "addons")
    if _has_modules(sub):
        return sub, "addons"
    # 单层包裹:版本目录下只有一个子目录(忽略隐藏目录与散落文件)时,进去找
    try:
        entries = [n for n in os.listdir(version_path) if not n.startswith(".") and os.path.isdir(os.path.join(version_path, n))]
    except OSError:
        return None
    if len(entries) == 1:
        wrap = os.path.join(version_path, entries[0])
        if _has_modules(wrap):
            return wrap, entries[0]
        wrap_addons = os.path.join(wrap, "addons")
        if _has_modules(wrap_addons):
            return wrap_addons, f"{entries[0]}/addons"
    return None


def resolve_for(version: str) -> str | None:
    """创建企业版实例时调用:平台离线目录里有该版本合法代码 → 返回要挂载的容器内 addons 根路径;否则 None。"""
    d = base_dir()
    for name in _version_dir_candidates(version):
        p = os.path.join(d, name)
        if os.path.isdir(p):
            root = addons_root(p)
            if root:
                return root[0]
    return None


# ---------------------------------------------------------------- 从旧 git 检出自动播种(一次性)
def _legacy_checkout_candidates(version: str) -> list[str]:
    """旧 git 企业版检出目录(<data_dir>/enterprise/<仓库id>/<版本>.0@<commit>,含完成标记),按 mtime 新→旧。"""
    base = os.path.join(settings.data_dir, "enterprise")
    out: list[str] = []
    if not os.path.isdir(base):
        return out
    pat = re.compile(rf"^{re.escape(_norm_version(version))}\.0@[0-9a-f]{{6,40}}$")
    try:
        for rid in os.listdir(base):
            d = os.path.join(base, rid)
            if not os.path.isdir(d):
                continue
            for name in os.listdir(d):
                p = os.path.join(d, name)
                if pat.match(name) and os.path.isdir(p) and os.path.isfile(os.path.join(p, ".odoosh-commit")):
                    out.append(p)
    except OSError:
        return out
    out.sort(key=os.path.getmtime, reverse=True)
    return out


def seedable_versions() -> dict[str, str]:
    """旧 git 检出里有、统一目录还没有的版本 {版本: commit 短号}(卡片展示"可自动导入"用)。"""
    base = os.path.join(settings.data_dir, "enterprise")
    found: dict[str, tuple[float, str]] = {}
    if not os.path.isdir(base):
        return {}
    pat = re.compile(r"^(\d{2})\.0@([0-9a-f]{6,40})$")
    try:
        for rid in os.listdir(base):
            d = os.path.join(base, rid)
            if not os.path.isdir(d):
                continue
            for name in os.listdir(d):
                m = pat.match(name)
                p = os.path.join(d, name)
                if not m or not os.path.isdir(p) or not os.path.isfile(os.path.join(p, ".odoosh-commit")):
                    continue
                mt = os.path.getmtime(p)
                cur = found.get(m.group(1))
                if cur is None or mt > cur[0]:
                    found[m.group(1)] = (mt, m.group(2)[:12])
    except OSError:
        pass
    return {v: c for v, (_mt, c) in found.items() if resolve_for(v) is None}


def seedable(version: str) -> bool:
    """统一目录没有该版本,但旧 git 检出里有 → 创建时可自动复制一份进来(创建不会失败)。"""
    return bool(_legacy_checkout_candidates(version))


def seed_from_legacy(version: str, say=log.info) -> str | None:
    """统一目录缺该版本时,从最近一次旧 git 检出复制一份进来(仅一次;之后统一目录即唯一来源)。
    返回可挂载的 addons 根路径;无可播种来源或失败 → None。
    同版本并发调用(批量创建实例)由 _seed_lock 串行化:先到的那个复制,后到的直接用结果。"""
    with _seed_lock(_norm_version(version)):
        return _seed_from_legacy_locked(version, say)


def _seed_from_legacy_locked(version: str, say=log.info) -> str | None:
    got = resolve_for(version)  # 拿到锁后重查:等锁期间可能已被前一个调用复制好了
    if got:
        return got
    cands = _legacy_checkout_candidates(version)
    if not cands:
        return None
    src = cands[0]
    vdir = os.path.join(base_dir(), _norm_version(version))
    if os.path.isdir(vdir) and os.listdir(vdir):
        # 目录已存在且有内容却没识别出模块:结构不对,不敢覆盖别人放的东西,交回报错提示
        log.warning("统一企业版目录 %s 已有内容但未识别出模块,跳过自动播种", vdir)
        return None
    # 临时目录名唯一(仍以 .seeding 结尾,scan() 的孤儿清理照样认):
    # 即便有别的进程/上次崩溃留下同名目录,也不会互相 rmtree
    tmp = f"{vdir}.{uuid4().hex[:8]}.seeding"
    shutil.rmtree(tmp, ignore_errors=True)
    say(f"统一企业版目录暂无 {version} 版,自动从已有代码复制一份(仅此一次):{src}")
    try:
        # 约定布局:版本目录下套一层仓库文件夹(<版本>/enterprise/<模块>),与手动拷贝 clone 出来的目录一致
        os.makedirs(tmp)
        shutil.copytree(src, os.path.join(tmp, "enterprise"))
        for m in (".odoosh-commit", ".odoosh-root"):  # git 检出的标记文件,统一目录里不需要
            try:
                os.remove(os.path.join(tmp, "enterprise", m))
            except OSError:
                pass
        shutil.rmtree(vdir, ignore_errors=True)  # 仅可能是空目录(上面已挡有内容的)
        os.rename(tmp, vdir)
        _ensure_readable(vdir)
        say(f"已复制到统一目录:{vdir}/enterprise")
        return resolve_for(version)
    except Exception as ex:  # noqa: BLE001
        log.exception("自动播种企业版代码失败(版本 %s)", version)
        shutil.rmtree(tmp, ignore_errors=True)
        say(f"自动复制失败:{ex}")
        return None


def _mounted_paths() -> list[tuple[str, str]]:
    """未删除实例已挂载的企业版代码:[(“组织/实例”, 绝对路径)]。一次查询,给下面两个函数共用。"""
    from sqlalchemy import select

    from ..db import SessionLocal
    from ..models import Environment, Tenant

    try:
        with SessionLocal() as db:
            rows = db.execute(
                select(Tenant.slug, Environment.name, Environment.enterprise_path)
                .join(Tenant, Tenant.id == Environment.tenant_id)
                .where(Environment.enterprise_path.is_not(None), Environment.deleted_at.is_(None))
            ).all()
    except Exception as ex:  # noqa: BLE001  查不到就别拦着操作,只是少了提示
        log.warning("查询企业版目录占用情况失败: %s", ex)
        return []
    return [(f"{slug}/{env_name}", os.path.realpath(path or "")) for slug, env_name, path in rows]


def envs_using(version_dir: str) -> list[str]:
    """哪些未删除的实例正把该版本目录(或其子目录)只读挂载进容器,返回 ["组织/实例", ...]。

    企业版代码是 bind mount 的活目录:在宿主机上删文件 / 覆盖模块,运行中的实例**立刻**就读不到了
    (下次读 assets、数据文件、懒加载模块时报错),不是「重建才受影响」。删除和覆盖前先问一下这里。"""
    root = os.path.realpath(version_dir)
    return sorted(lbl for lbl, p in _mounted_paths() if p == root or p.startswith(root + os.sep))


def _in_use_map(base: str) -> dict[str, list[str]]:
    """{版本目录名: ["组织/实例", ...]} —— 一次查询覆盖所有版本,供 scan() 用。"""
    base_r = os.path.realpath(base)
    out: dict[str, list[str]] = {}
    for lbl, p in _mounted_paths():
        if not p.startswith(base_r + os.sep):
            continue
        top = os.path.relpath(p, base_r).split(os.sep)[0]
        if top and top != os.pardir:
            out.setdefault(top, []).append(lbl)
    return {k: sorted(v) for k, v in out.items()}


def scan() -> list[dict]:
    """列出离线企业版目录里的各版本:是否合法(含模块)、模块数、addons 是否在子目录、被哪些实例挂载着。
    顺带清理导入被打断遗留的 <版本>.seeding 临时目录(半小时无写入视为孤儿)。"""
    d = base_dir()
    out: list[dict] = []
    try:
        names = sorted(os.listdir(d))
    except OSError:
        return out
    in_use = _in_use_map(d)
    for name in names:
        p = os.path.join(d, name)
        if not os.path.isdir(p):
            continue
        if name.endswith(".seeding"):  # 导入用的临时目录:不当版本列出;孤儿(导入中途平台重启)自动清掉
            try:
                if time.time() - os.path.getmtime(p) > 1800:
                    shutil.rmtree(p, ignore_errors=True)
                    log.info("清理中断的导入临时目录 %s", p)
            except OSError:
                pass
            continue
        m = re.fullmatch(r"(\d{2})(?:\.0)?", name)  # 只认 19 或 19.0 形式的版本目录
        version = m.group(1) if m else name
        root = addons_root(p)
        out.append({
            "name": name,
            "version": version,
            "valid": root is not None,
            "modules": _module_count(root[0]) if root else 0,
            "subdir": root[1] if root else None,   # '' 根目录 / 'addons' 子目录 / None 非法
            "in_use": in_use.get(name, []),        # 正挂载该目录的实例("组织/实例");删除/覆盖会立刻影响它们
        })
    return out


def _norm_version(version: str) -> str:
    """'19' 或 '19.0' → '19'(上传落盘统一用不带 .0 的目录名;scan/resolve 两种都认)。"""
    v = str(version).strip()
    return v[:-2] if v.endswith(".0") else v


def _module_names(d: str) -> list[str]:
    if not os.path.isdir(d):
        return []
    return [n for n in sorted(os.listdir(d)) if os.path.isfile(os.path.join(d, n, "__manifest__.py"))]


def _safe_extract(zip_path: str, dest: str) -> None:
    root = os.path.realpath(dest)
    with zipfile.ZipFile(zip_path) as z:
        for m in z.namelist():
            p = os.path.realpath(os.path.join(dest, m))
            if p != root and not p.startswith(root + os.sep):
                raise ValueError(f"压缩包含非法路径:{m}")
        z.extractall(dest)


def _module_root(d: str) -> str | None:
    """定位解压内容里的模块根:模块直接在 d 下 → d;整包套了一层单目录 → 该子目录;都不是 → None。"""
    if _has_modules(d):
        return d
    try:
        entries = [n for n in os.listdir(d) if os.path.isdir(os.path.join(d, n))]
    except OSError:
        return None
    if len(entries) == 1:
        sub = os.path.join(d, entries[0])
        if _has_modules(sub):
            return sub
    return None


def _ensure_readable(path: str) -> None:
    """企业版目录是只读挂载给容器 odoo 用户读:确保目录可进入、文件可读。"""
    try:
        for r, dirs, files in os.walk(path):
            os.chmod(r, 0o755)
            for n in files:
                try:
                    os.chmod(os.path.join(r, n), 0o644)
                except OSError:
                    pass
    except OSError as ex:
        log.warning("设置企业版目录可读权限失败 %s: %s", path, ex)


def upload_zip(version: str, zip_path: str) -> dict:
    """超管上传企业版 addons zip → 解压按模块合并进 offline/enterprise/<版本>/(新模块新增、同名更新、其余保留)。
    返回 {"new": [...], "updated": [...]}。压缩包里没有模块则抛 ValueError。用完删 zip。"""
    vdir = os.path.join(base_dir(), _norm_version(version))
    os.makedirs(vdir, exist_ok=True)
    tmp = os.path.join(base_dir(), f".upload_tmp_{_norm_version(version)}")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    try:
        _safe_extract(zip_path, tmp)
        root = _module_root(tmp)
        if not root:
            raise ValueError("压缩包里没有 Odoo 模块(缺少含 __manifest__.py 的模块目录)")
        # 落盘目标:版本目录里已识别出的 addons 根(合并进去,避免出现两个根);全新版本则按约定
        # 套一层仓库文件夹 <版本>/enterprise/(与手动拷贝 clone 目录、自动导入的布局一致)
        existing = addons_root(vdir)
        dest = existing[0] if existing else os.path.join(vdir, "enterprise")
        os.makedirs(dest, exist_ok=True)
        new: list[str] = []
        updated: list[str] = []
        for m in _module_names(root):
            dst = os.path.join(dest, m)
            if os.path.exists(dst):
                shutil.rmtree(dst, ignore_errors=True)
                updated.append(m)
            else:
                new.append(m)
            shutil.move(os.path.join(root, m), dst)
        _ensure_readable(vdir)
        log.info("上传离线企业版代码 版本 %s:新增 %s,更新 %s", version, new, updated)
        # 覆盖同名模块 = 在活挂载底下换文件,已在用该版本的实例要重启才稳(否则可能读到半新半旧的文件)
        in_use = envs_using(vdir) if updated else []
        return {"new": new, "updated": updated, "in_use": in_use}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        try:
            os.remove(zip_path)
        except OSError:
            pass


def delete_version(name: str, force: bool = False) -> bool:
    """删除某个版本目录(整棵代码树)。仅超管调用。

    目录是 bind mount 给实例容器的活目录:删了运行中的实例立刻就读不到代码。
    因此有实例正在用时默认拒绝;确实要删由调用方传 force=True(界面会二次确认)。"""
    if not name or "/" in name or "\\" in name or name in (".", ".."):
        raise ValueError("非法目录名")
    d = base_dir()
    p = os.path.realpath(os.path.join(d, name))
    if os.path.dirname(p) != os.path.realpath(d):
        raise ValueError("非法目录名")
    if not os.path.isdir(p):
        return False
    if not force:
        using = envs_using(p)
        if using:
            raise ValueError(
                f"该版本代码正被 {len(using)} 个实例挂载使用:{', '.join(using[:8])}"
                + (" 等" if len(using) > 8 else "")
                + "。删除后这些实例会立刻读不到企业版模块(不是重建才受影响)。"
                  "请先删除/迁移这些实例,或确认后强制删除。"
            )
    shutil.rmtree(p, ignore_errors=True)
    log.info("删除离线企业版代码目录 %s(force=%s)", p, force)
    return True
