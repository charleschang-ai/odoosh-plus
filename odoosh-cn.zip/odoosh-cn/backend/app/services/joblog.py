"""进程内的任务日志缓冲(构建镜像等长任务用),前端轮询读取。"""

import threading
import time
from collections import deque

_lock = threading.Lock()
_jobs: dict[str, dict] = {}
KEEP_DONE = 3600  # 已结束任务的日志保留 1 小时(前端还能回看),之后释放(以前永不清理)


def _evict() -> None:
    now = time.time()
    for k in [k for k, j in _jobs.items() if j["done"] and now - (j.get("finished") or j["started"]) > KEEP_DONE]:
        _jobs.pop(k, None)


def start(job_id: str) -> None:
    with _lock:
        _evict()
        _jobs[job_id] = {"lines": deque(maxlen=2000), "done": False, "ok": None, "started": time.time(), "finished": None}


def append(job_id: str, line: str) -> None:
    with _lock:
        job = _jobs.get(job_id)
        if job:
            for ln in line.rstrip("\n").split("\n"):
                job["lines"].append(ln)


def finish(job_id: str, ok: bool) -> None:
    with _lock:
        job = _jobs.get(job_id)
        if job:
            job["done"] = True
            job["ok"] = ok
            job["finished"] = time.time()


def get(job_id: str) -> dict | None:
    with _lock:
        job = _jobs.get(job_id)
        if not job:
            return None
        return {"lines": list(job["lines"]), "done": job["done"], "ok": job["ok"], "started": job["started"]}


def running(job_id: str) -> bool:
    with _lock:
        job = _jobs.get(job_id)
        return bool(job and not job["done"])
