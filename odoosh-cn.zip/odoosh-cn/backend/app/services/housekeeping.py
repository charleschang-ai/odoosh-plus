"""平台定期清理(磁盘):以前这些要么只在成功路径顺手做、要么只有手动入口、要么根本没有——
崩溃残留的临时目录、悬空镜像、构建缓存、只增不减的 bare mirror 松散对象都会悄悄吃掉 SSD。

每 INTERVAL 秒(默认 6 小时,启动后 5 分钟先跑一次)做:
  1. Docker:删除悬空镜像(<none>,基础镜像重建/官方镜像更新后遗留),清理 7 天前的构建缓存
  2. 临时目录:backups/.tmp/bk-*|rs-*、repos/<key>/*.tmp、enterprise/<id>/*.tmp 中超过 TMP_MAX_AGE 的残留
  3. 代码检出:所有仓库跑一遍 deploy.gc_checkouts(部署失败的仓库以前永远不会被清理)
  4. bare mirror:git gc --auto(fetch 累积的松散对象与小包)
  5. 企业版:enterprise.gc_unreferenced(以前只有手动按钮)
  6. 历史记录:保留期外的部署 / 恢复记录(先清日志正文,再按每实例保留条数删除)、Shell 会话审计、Git 推送事件
     (保留期见系统设置 history.*)
  7. 孤儿访问日志:nginx-logs/ 下没有对应实例的 <tenant>--<env>.log
  8. 租户 PG 数据目录里超过 24h 的 .odoosh-* 中转 dump(备份 / 恢复 / 克隆异常中断遗留)
"""

import logging
import os
import shutil
import subprocess
import threading
import time

log = logging.getLogger("odoosh.housekeeping")

INTERVAL = 6 * 3600
FIRST_DELAY = 300
TMP_MAX_AGE = 6 * 3600
BUILD_CACHE_KEEP = "168h"


def _rm_stale(path: str, max_age: float, predicate=None) -> int:
    """删除 path 下超过 max_age 秒未修改、且 predicate(name) 为真的子目录/文件。"""
    n = 0
    if not os.path.isdir(path):
        return 0
    now = time.time()
    try:
        names = os.listdir(path)
    except OSError:
        return 0
    for name in names:
        if predicate and not predicate(name):
            continue
        p = os.path.join(path, name)
        try:
            if now - os.lstat(p).st_mtime < max_age:
                continue
            if os.path.isdir(p) and not os.path.islink(p):
                shutil.rmtree(p, ignore_errors=True)
            else:
                os.remove(p)
            n += 1
            log.info("清理残留 %s", p)
        except OSError:
            continue
    return n


def prune_docker() -> dict:
    from . import dockerx

    out = {"images": 0, "build_cache": 0}
    try:
        r = dockerx.client().images.prune(filters={"dangling": True})
        out["images"] = r.get("SpaceReclaimed", 0) or 0
    except Exception as ex:  # noqa: BLE001
        log.debug("清理悬空镜像失败: %s", ex)
    try:
        r = dockerx.client().api.prune_builds(filters={"until": BUILD_CACHE_KEEP})
        out["build_cache"] = r.get("SpaceReclaimed", 0) or 0
    except Exception as ex:  # noqa: BLE001
        log.debug("清理构建缓存失败: %s", ex)
    return out


def clean_tmp_dirs() -> int:
    n = 0
    try:
        from .backup import backups_root, running_backup_ids

        # 正在跑的备份(bk-<id>-xxxx)的临时目录不能碰:目录 mtime 是创建时的,超长备份(>6h)以前会被从底下抽掉
        live = running_backup_ids()

        def _not_live(name: str) -> bool:
            if name.startswith("bk-"):
                try:
                    return int(name.split("-")[1]) not in live
                except (IndexError, ValueError):
                    return True
            return True

        n += _rm_stale(os.path.join(backups_root(), ".tmp"), TMP_MAX_AGE, _not_live)
    except Exception as ex:  # noqa: BLE001
        log.debug("清理备份临时目录失败: %s", ex)
    try:
        from .deploy import repos_root

        root = repos_root()
        for key in os.listdir(root):
            n += _rm_stale(os.path.join(root, key), TMP_MAX_AGE, lambda s: s.endswith(".tmp"))
    except Exception as ex:  # noqa: BLE001
        log.debug("清理检出临时目录失败: %s", ex)
    try:
        from .enterprise import base_dir

        root = base_dir()
        if os.path.isdir(root):
            for rid in os.listdir(root):
                n += _rm_stale(os.path.join(root, rid), TMP_MAX_AGE, lambda s: s.endswith(".tmp"))
    except Exception as ex:  # noqa: BLE001
        log.debug("清理企业版临时目录失败: %s", ex)
    return n


def clean_pg_tmp_dumps(max_age_hours: int = 24) -> int:
    """租户 PG 容器数据目录里的 .odoosh-*.pgc / .odoosh-clone-*.dump(备份 / 恢复 / 克隆的中转文件):正常路径都会删,
    api 被杀 / 容器异常时会留下几 GB 的孤儿。这里把超过 max_age_hours 的清掉(正在跑的任务不会用这么久)。"""
    from . import dockerx

    n = 0
    try:
        for c in dockerx.client().containers.list(filters={"name": "odoosh-pg-", "status": "running"}):
            code, out = c.exec_run(["sh", "-c", f"find /var/lib/postgresql/data -maxdepth 1 -name '.odoosh-*' -type f -mmin +{max_age_hours * 60} -print -delete | wc -l"])
            if code == 0:
                try:
                    k = int(out.decode().strip().splitlines()[-1] or 0)
                except (ValueError, IndexError):
                    k = 0
                if k:
                    log.info("清理 %s 数据目录里 %s 个过期中转 dump", c.name, k)
                    n += k
    except Exception as ex:  # noqa: BLE001
        log.debug("清理 PG 中转文件失败: %s", ex)
    return n


def gc_git_mirrors() -> int:
    """对每个 bare mirror 跑 git gc --auto。gc.autoDetach=false 让它在前台跑完(不留孤儿进程),
    --auto 只在松散对象/包数量超阈值时才真的动手,平时是空操作。"""
    from .deploy import repos_root

    n = 0
    root = repos_root()
    try:
        keys = os.listdir(root)
    except OSError:
        return 0
    env = {"GIT_TERMINAL_PROMPT": "0", "PATH": os.environ.get("PATH", ""), "HOME": "/tmp"}
    mirrors = [os.path.join(root, key, "mirror.git") for key in keys]
    try:
        from .enterprise import base_dir

        eroot = base_dir()
        mirrors += [os.path.join(eroot, rid, "mirror.git") for rid in os.listdir(eroot)]  # 企业版代码镜像(shallow,老 commit 会变成垃圾)
    except OSError:
        pass
    for md in mirrors:
        if not os.path.isdir(md):
            continue
        try:
            subprocess.run(["git", "--git-dir", md, "-c", "gc.autoDetach=false", "gc", "--auto", "--quiet"],
                           capture_output=True, timeout=1800, env=env)
            n += 1
        except Exception as ex:  # noqa: BLE001
            log.debug("git gc %s 失败: %s", md, ex)
    return n


def gc_checkouts_all() -> int:
    from .deploy import gc_checkouts, repos_root

    n = 0
    root = repos_root()
    try:
        keys = os.listdir(root)
    except OSError:
        return 0
    for key in keys:
        if os.path.isdir(os.path.join(root, key, "mirror.git")):
            try:
                n += gc_checkouts(key)
            except Exception as ex:  # noqa: BLE001
                log.debug("清理检出 %s 失败: %s", key, ex)
    return n


def gc_enterprise() -> int:
    from ..db import SessionLocal
    from .enterprise import gc_unreferenced

    with SessionLocal() as db:
        return gc_unreferenced(db)


# 历史记录保留期默认值(系统设置 history.* 可改;0 = 永久保留)
HISTORY_KEEP_DAYS = 90     # 部署 / 恢复记录:超过 N 天且已结束的清掉(日志 TEXT 列只增不减)
HISTORY_KEEP_PER_ENV = 50  # 但每个实例至少保留最近 N 条部署记录(回滚 / 追溯用)
SHELL_KEEP_DAYS = 180      # Shell 会话审计(生产实例键盘输入最多 200KB/次,以前从不清理)
PUSH_KEEP_DAYS = 90        # Git 推送事件(以前只随仓库删除级联)


def _int_setting(db, key: str, default: int) -> int:
    from ..routers.settings import get_setting

    try:
        v = get_setting(db, key)
        return int(v) if v not in (None, "") else default
    except (TypeError, ValueError):
        return default


def prune_history() -> dict:
    """清理老的历史记录(保留期取自系统设置 history.*):
    - 部署记录:先把保留期外、已结束记录的日志正文清空(占空间的是 log 列),再删除超过每实例保留条数的更老记录
    - 恢复任务、Shell 会话审计、Git 推送事件:保留期外直接删除
    每项 0 = 永久保留。"""
    from datetime import datetime, timedelta, timezone

    from sqlalchemy import delete, func, select, update

    from ..db import SessionLocal
    from ..models_backup import RestoreJob
    from ..models_deploy import Deployment
    from ..models_git import PushEvent
    from ..models_shell import ShellSession

    now = datetime.now(timezone.utc)
    out = {"deploy_logs_cleared": 0, "deployments_deleted": 0, "restore_jobs_deleted": 0, "shell_sessions_deleted": 0, "push_events_deleted": 0}
    with SessionLocal() as db:
        keep_days = _int_setting(db, "history.keep_days", HISTORY_KEEP_DAYS)
        keep_per_env = _int_setting(db, "history.keep_per_env", HISTORY_KEEP_PER_ENV)
        if keep_days > 0:
            cutoff = now - timedelta(days=keep_days)
            done = Deployment.status.in_(("success", "failed"))
            out["deploy_logs_cleared"] = db.execute(
                update(Deployment).where(Deployment.created_at < cutoff, done, Deployment.log.is_not(None)).values(log=None)
            ).rowcount
            # 每实例第 keep_per_env 条之后、且超过保留期的删除。子查询里就按日期/状态过滤,不再把全部部署 id 拉进内存
            ranked = select(
                Deployment.id, Deployment.created_at, Deployment.status,
                func.row_number().over(partition_by=Deployment.environment_id, order_by=Deployment.id.desc()).label("rn"),
            ).subquery()
            old_ids = select(ranked.c.id).where(ranked.c.rn > keep_per_env, ranked.c.created_at < cutoff, ranked.c.status.in_(("success", "failed")))
            out["deployments_deleted"] = db.execute(delete(Deployment).where(Deployment.id.in_(old_ids))).rowcount
            out["restore_jobs_deleted"] = db.execute(
                delete(RestoreJob).where(RestoreJob.created_at < cutoff, RestoreJob.status.in_(("done", "failed")))
            ).rowcount
        shell_days = _int_setting(db, "history.shell_keep_days", SHELL_KEEP_DAYS)
        if shell_days > 0:
            out["shell_sessions_deleted"] = db.execute(
                delete(ShellSession).where(ShellSession.started_at < now - timedelta(days=shell_days), ShellSession.status != "open")
            ).rowcount
        push_days = _int_setting(db, "history.push_keep_days", PUSH_KEEP_DAYS)
        if push_days > 0:
            out["push_events_deleted"] = db.execute(delete(PushEvent).where(PushEvent.received_at < now - timedelta(days=push_days))).rowcount
        db.commit()
    return out


def clean_orphan_access_logs() -> int:
    """nginx-logs/<tenant>--<env>.log 只用于休眠判断;实例删除 / 改名后文件会留下(destroy 现在会顺手删,这里兜底)。
    删除没有对应「组织+实例名」的文件,返回删除数。"""
    from sqlalchemy import select

    from ..db import SessionLocal
    from ..models import Environment, Tenant
    from .sleep import logs_dir

    d = logs_dir()
    try:
        names = [n for n in os.listdir(d) if n.endswith(".log")]
    except OSError:
        return 0
    if not names:
        return 0
    with SessionLocal() as db:
        alive = {f"{slug}--{name}.log" for slug, name in db.execute(select(Tenant.slug, Environment.name).join(Environment, Environment.tenant_id == Tenant.id)).all()}
    n = 0
    for name in names:
        if name in alive:
            continue
        try:
            os.remove(os.path.join(d, name))
            n += 1
            log.info("清理孤儿访问日志 %s", name)
        except OSError:
            continue
    return n


def run_once() -> dict:
    res: dict = {}
    for name, fn in (("docker", prune_docker), ("tmp", clean_tmp_dirs), ("checkouts", gc_checkouts_all),
                     ("git_gc", gc_git_mirrors), ("enterprise", gc_enterprise), ("history", prune_history),
                     ("access_logs", clean_orphan_access_logs), ("pg_tmp", clean_pg_tmp_dumps)):
        try:
            res[name] = fn()
        except Exception as ex:  # noqa: BLE001
            log.warning("housekeeping %s 出错: %s", name, ex)
            res[name] = f"error: {ex}"
    log.info("housekeeping 完成: %s", res)
    return res


def start_scheduler(interval: int = INTERVAL, first_delay: int = FIRST_DELAY) -> None:
    def loop():
        time.sleep(first_delay)
        while True:
            try:
                run_once()
            except Exception as ex:  # noqa: BLE001
                log.warning("housekeeping 出错: %s", ex)
            time.sleep(interval)

    threading.Thread(target=loop, name="housekeeping", daemon=True).start()
