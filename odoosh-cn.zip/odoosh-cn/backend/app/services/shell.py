"""实例 Shell(Web 终端):浏览器 xterm ⇄ WebSocket ⇄ docker exec(bash,容器内 odoo 用户)。

权限:authz.shell_allowed(用户级开关 × 角色矩阵)。票据:60 秒一次性 JWT(浏览器 WebSocket 不能带 Authorization 头)。
会话开始时把一组 odoo.sh 风格的辅助命令写进容器 /tmp/.odoosh/bin(容器一次性,所以每次会话重新写):
  odoo-bin shell / odoo-update [模块] / odoo-install 模块 / odoosh-restart / odoosh-storage / odoosh-sql-access / odoosh-pip / odoosh-logs / odoosh-help
"""

import logging
import threading
import time

from jose import JWTError, jwt

from ..config import settings
from ..models import Environment
from . import dockerx

log = logging.getLogger("odoosh.shell")

TICKET_TTL = 60
IDLE_TIMEOUT = 30 * 60
MAX_SESSIONS_PER_ENV = 3

_active: dict[int, int] = {}  # env_id -> 当前会话数


def make_ticket(env_id: int, user, database_id: int | None = None) -> str:
    """database_id:附加库 id(会话内 odoo shell / psql 指向该库);None = 主库。一次性、带 jti/tv(见 services.tickets)。"""
    from . import tickets

    return tickets.issue("shell", env_id, user, TICKET_TTL, {"db": int(database_id)} if database_id else None)


def read_ticket(token: str, db) -> tuple[dict, object]:
    from . import tickets

    return tickets.redeem(token, "shell", db)


# ---------------------------------------------------------------- 容器内辅助命令
_HELPERS = r'''
set -e
D=/tmp/.odoosh/bin; mkdir -p "$D"
conf() { sed -n "s/^[[:space:]]*$1[[:space:]]*=[[:space:]]*//p" /etc/odoo/odoo.conf | head -1; }
# 目标库:平台按会话传入 ODOOSH_DB(附加库);否则主库(新配置写在注释 odoosh_primary_db,旧配置写在 db_name)
DB="${ODOOSH_DB:-}"
[ -z "$DB" ] && DB=$(sed -n "s/^;[[:space:]]*odoosh_primary_db[[:space:]]*=[[:space:]]*//p" /etc/odoo/odoo.conf | head -1)
[ -z "$DB" ] && DB=$(conf db_name)
DBU=$(conf db_user); DBP=$(conf db_password); DBH=$(conf db_host)
RC="/tmp/.odoosh/bashrc-$DB"

cat > "$D/odoosh-help" <<'EOF'
#!/bin/bash
cat <<'MENU'
  OdooshCN 实例 Shell —— 可用命令(仿 odoo.sh):
  $ odoo-bin shell             打开 Odoo shell(ORM 交互,env / self 可用)
  $ odoo-update [模块,模块|all] 升级数据库中的模块(默认 all);完成后建议 odoosh-restart
  $ odoo-install 模块,模块      安装模块(app)
  $ odoosh-restart             重启本实例的 Odoo(容器会重建,Shell 需重新打开)
  $ odoosh-storage             查看本实例的存储占用(filestore / 代码 / 容器文件系统)
  $ odoosh-sql-access          查看数据库连接信息(仅平台内网可达)
  $ odoosh-pip install 包名     安装 Python 依赖(装到 ~/.local,重建容器后仍在;走国内镜像)
                               正式方案:写进仓库或 /mnt/custom-addons(根或模块内)的 requirements.txt,部署 / 重启自动装
  $ odoosh-logs                日志说明(Odoo 日志在平台「日志」Tab;这里可查看安装/升级输出)
  $ psql                       进入本实例数据库(已配置连接信息,直接回车)
  $ odoosh-help                显示本菜单
  提示:容器是一次性的,除 /var/lib/odoo(filestore)、数据库以外的改动在重建后会丢失;
        依赖请写进仓库根目录 requirements.txt —— 每次部署会自动安装到本实例 ~/.local(持久);
        仓库代码目录 /mnt/extra-addons 请勿直接修改(通过 git push 更新);
        /mnt/custom-addons 是本实例的「定制代码」目录(可写、持久、已在 addons_path 内),AI 编程 / 临时改代码请写这里,
        写好的模块可在平台「定制代码」Tab 里查看、编辑、下载。
MENU
EOF

cat > "$D/odoo-bin" <<EOF
#!/bin/bash
# odoo-bin shell → Odoo 交互式 shell;其它子命令原样透传
if [ "\$1" = "shell" ]; then shift; exec odoo shell -c /etc/odoo/odoo.conf -d "\${ODOOSH_DB:-$DB}" --no-http "\$@"; fi
exec odoo -c /etc/odoo/odoo.conf "\$@"
EOF

cat > "$D/odoo-update" <<EOF
#!/bin/bash
M="\${1:-all}"
echo ">>> 升级模块 \$M(数据库 \${ODOOSH_DB:-$DB})…  完成后建议执行 odoosh-restart"
exec odoo -c /etc/odoo/odoo.conf -d "\${ODOOSH_DB:-$DB}" -u "\$M" --stop-after-init --no-http --log-level=warn
EOF

cat > "$D/odoo-install" <<EOF
#!/bin/bash
[ -z "\$1" ] && { echo "用法:odoo-install 模块名[,模块名]"; exit 1; }
echo ">>> 安装模块 \$1(数据库 \${ODOOSH_DB:-$DB})…  完成后建议执行 odoosh-restart"
exec odoo -c /etc/odoo/odoo.conf -d "\${ODOOSH_DB:-$DB}" -i "\$1" --stop-after-init --no-http --log-level=warn
EOF

cat > "$D/odoosh-restart" <<'EOF'
#!/bin/bash
echo ">>> 正在重启 Odoo(容器将由 Docker 自动拉起,约 15~30 秒;本 Shell 会断开,请重新打开)"
sleep 1
kill -TERM 1 2>/dev/null || pkill -TERM -f "odoo" || true
EOF

cat > "$D/odoosh-storage" <<'EOF'
#!/bin/bash
echo "== filestore(数据库附件,持久)"; du -sh /var/lib/odoo 2>/dev/null
echo "== 自定义代码 /mnt/extra-addons"; du -sh /mnt/extra-addons 2>/dev/null
[ /mnt/custom-addons -ef /mnt/extra-addons ] || { echo "== 定制代码 /mnt/custom-addons(可写,持久)"; du -sh /mnt/custom-addons 2>/dev/null; }
[ -d /mnt/enterprise ] && { echo "== 企业版代码 /mnt/enterprise(只读共享)"; du -sh /mnt/enterprise 2>/dev/null; }
echo "== 用户级 Python 依赖 ~/.local"; du -sh ~/.local 2>/dev/null || echo "(无)"
echo "== 容器文件系统"; df -h / | tail -1
EOF

cat > "$D/odoosh-sql-access" <<EOF
#!/bin/bash
echo "数据库连接信息(仅平台内网可达;外部访问请通过平台管理员开通端口映射):"
echo "  host=$DBH  port=5432  dbname=\${ODOOSH_DB:-$DB}  user=$DBU  password=$DBP"
echo "  psql 已预配置:直接输入 psql 即可进入"
EOF

cat > "$D/odoosh-pip" <<'EOF'
#!/bin/bash
# 临时安装:装到 ~/.local(/var/lib/odoo 卷),容器重建后仍在;正式方案写进仓库或定制代码目录的 requirements.txt(部署 / 重启时自动装)。
# 镜像源:容器环境变量 PIP_INDEX_URL 已由平台设置为国内镜像,pip 直接读取
sub="$1"; shift
# 加速:优先平台下发的 PIP_INDEX_URL(容器环境变量),没有就用清华源兜底;只有 install/download/wheel 认 --index-url
IDX="${PIP_INDEX_URL:-https://pypi.tuna.tsinghua.edu.cn/simple}"
case "$sub" in
  install)        exec python3 -m pip install --user --break-system-packages --index-url "$IDX" "$@" ;;
  download|wheel) exec python3 -m pip "$sub" --index-url "$IDX" "$@" ;;   # 这两个子命令不认 --user
  list|freeze)    exec python3 -m pip "$sub" --user "$@" ;;
  *)              exec python3 -m pip "$sub" --break-system-packages "$@" ;;   # uninstall / show / check 等
esac
EOF

cat > "$D/odoosh-logs" <<'EOF'
#!/bin/bash
echo "Odoo 运行日志输出到容器 stdout,请在平台实例详情的「日志」Tab 查看/过滤/下载。"
echo "在本 Shell 里执行 odoo-update / odoo-install 时,输出会直接显示在这里。"
EOF

chmod +x "$D"/*
cat > "$RC" <<EOF
export PATH="$D:\$PATH"
export ODOOSH_DB="$DB"
export HOME=/var/lib/odoo
export PGHOST="$DBH" PGPORT=5432 PGDATABASE="$DB" PGUSER="$DBU" PGPASSWORD="$DBP"
export PS1='\[\e[1;35m\]odoosh\[\e[0m\]:\[\e[1;34m\]\w\[\e[0m\]\$ '
alias ll='ls -alF'
cd /var/lib/odoo 2>/dev/null || true
odoosh-help
EOF
cp "$RC" /tmp/.odoosh/bashrc
'''


def _exec(container, cmd: list[str], user: str | None = None) -> tuple[int, str]:
    code, out = container.exec_run(cmd, user=user)
    return code, (out or b"").decode(errors="ignore")


def prepare(container, uid: int, db_name: str | None = None) -> None:
    """写入辅助命令与 bashrc(以容器内 odoo 用户身份,/tmp 可写)。db_name 指定时会话操作该库(附加库),否则主库。"""
    env = {"ODOOSH_DB": db_name} if db_name else {}
    code, out = container.exec_run(["bash", "-c", _HELPERS], user=str(uid), environment=env or None)
    out = (out or b"").decode(errors="ignore")
    if code != 0:
        raise RuntimeError(f"初始化 Shell 辅助命令失败:{out[-300:]}")


def open_exec(container, uid: int, cols: int = 120, rows: int = 32, root: bool = False, db_name: str | None = None):
    """创建带 TTY 的 exec 并返回 (exec_id, 原始 socket)。db_name 须与 prepare 时一致(bashrc 按库分文件)。"""
    api = dockerx.client().api
    rc = f"/tmp/.odoosh/bashrc-{db_name}" if db_name else "/tmp/.odoosh/bashrc"
    ex = api.exec_create(
        container.id, ["bash", "--rcfile", rc, "-i"], stdin=True, stdout=True, stderr=True, tty=True,
        user="root" if root else str(uid), workdir="/var/lib/odoo", environment={"TERM": "xterm-256color", "LANG": "C.UTF-8", "COLUMNS": str(cols), "LINES": str(rows), "PIP_INDEX_URL": settings.pip_index_url},
    )
    sock = api.exec_start(ex["Id"], socket=True, tty=True)
    raw = getattr(sock, "_sock", sock)
    try:
        api.exec_resize(ex["Id"], height=rows, width=cols)
    except Exception:  # noqa: BLE001
        pass
    return ex["Id"], raw


def resize(exec_id: str, cols: int, rows: int) -> None:
    try:
        dockerx.client().api.exec_resize(exec_id, height=max(1, rows), width=max(1, cols))
    except Exception:  # noqa: BLE001
        pass


_active_lock = threading.Lock()  # 并发 WebSocket 握手时的读-改-写要互斥,否则会超过 MAX_SESSIONS_PER_ENV


def acquire(env_id: int) -> bool:
    with _active_lock:
        n = _active.get(env_id, 0)
        if n >= MAX_SESSIONS_PER_ENV:
            return False
        _active[env_id] = n + 1
        return True


def release(env_id: int) -> None:
    with _active_lock:
        n = _active.get(env_id, 0)
        if n <= 1:
            _active.pop(env_id, None)
        else:
            _active[env_id] = n - 1


def container_for(e: Environment):
    c = dockerx.get_container(e.container_name or "")
    if not c or c.status != "running":
        raise RuntimeError("实例未在运行,无法打开 Shell")
    return c


__all__ = ["make_ticket", "read_ticket", "prepare", "open_exec", "resize", "acquire", "release", "container_for", "IDLE_TIMEOUT"]
