"""长任务派发:独立守护线程,不占用 Starlette 的共享线程池。

FastAPI 的 BackgroundTasks 里放同步函数时,会在 anyio 线程池(与所有 `def` 端点共用)里执行。
创建实例 / 部署 / 备份 / 恢复动辄几分钟到几十分钟,几个并发就能把池子占满,整个 API 随之无响应。
路由里写 `bg.add_task(jobs.spawn, fn, *args)`:响应发出后立刻起线程并归还池线程,顺序语义与原来一致。
"""

import logging
import threading

log = logging.getLogger("odoosh.jobs")


def _run(fn, args, kwargs) -> None:
    try:
        fn(*args, **kwargs)
    except Exception:  # noqa: BLE001
        log.exception("后台任务 %s 异常退出", getattr(fn, "__name__", fn))


def spawn(fn, *args, **kwargs) -> threading.Thread:
    name = f"job-{getattr(fn, '__name__', 'task')}"
    t = threading.Thread(target=_run, args=(fn, args, kwargs), name=name, daemon=True)
    t.start()
    return t
