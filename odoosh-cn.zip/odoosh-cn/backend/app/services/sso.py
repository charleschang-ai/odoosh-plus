"""一键登录实例(免密进入 Odoo)。

流程:
  1. 前端向平台 API 申请一次性票据:POST /api/environments/{id}/sso-url → {url: http://<实例域名>/odoosh/sso?t=...}
  2. 浏览器打开该地址;实例域名的 nginx 把 /odoosh/sso 反代到平台 API(/api/sso/open),
     此时响应就落在实例域名下,可以直接给浏览器种 Odoo 的 session_id cookie
  3. API 校验票据 → 在实例容器内 curl /web/session/authenticate(admin + 环境记录的 admin_password)
     → 拿到 session_id → 302 到 /web 并 Set-Cookie
  4. 若认证失败(库是克隆/恢复来的,admin 密码不同),先把 admin 的密码重置为环境记录的 admin_password 再登一次。

Odoo 内置账号:login=admin;密码 = Environment.admin_password(创建时随机生成,同时也是 master password)。
"""

import json
import logging
import re
import time

from jose import JWTError, jwt

from ..config import settings
from ..models import Environment, Tenant
from . import dockerx

log = logging.getLogger("odoosh.sso")

ADMIN_LOGIN = "admin"
TICKET_TTL = 90  # 秒


def make_ticket(env_id: int, user, database_id: int | None = None) -> str:
    """database_id:附加库 id(登录该库,票据在该库的子域名下兑换);None = 主库。一次性、带 jti/tv(见 services.tickets)。"""
    from . import tickets

    return tickets.issue("sso", env_id, user, TICKET_TTL, {"db": int(database_id)} if database_id else None)


def read_ticket(token: str, db) -> tuple[dict, object]:
    """校验并一次性消费票据;返回 (payload, user)。"""
    from . import tickets

    return tickets.redeem(token, "sso", db)


def _exec(container, cmd: list[str], timeout: int = 30) -> tuple[int, str]:
    code, out = container.exec_run(cmd)
    return code, (out or b"").decode(errors="ignore")


def authenticate(container, db_name: str, login: str, password: str, host: str | None = None) -> str | None:
    """容器内 curl JSON-RPC 认证,成功返回 session_id,失败返回 None。
    host:请求带的 Host 头。Odoo 用 dbfilter(按主机名 %d)校验目标库,附加库必须用它自己的子域名才能通过校验;主库传不传都行。"""
    body = json.dumps({"jsonrpc": "2.0", "method": "call", "params": {"db": db_name, "login": login, "password": password}})
    cmd = ["curl", "-s", "-i", "-m", "20", "-X", "POST", "-H", "Content-Type: application/json"]
    if host:
        cmd += ["-H", f"Host: {host}"]
    code, out = _exec(container, cmd + ["--data-binary", body, "http://localhost:8069/web/session/authenticate"])
    if code != 0:
        log.warning("sso curl 失败: %s", out[-200:])
        return None
    head, _, payload = out.partition("\r\n\r\n")
    m = re.search(r"session_id=([^;\s]+)", head)
    try:
        j = json.loads(payload or "{}")
    except ValueError:
        j = {}
    if j.get("error") or not j.get("result") or not j["result"].get("uid"):
        return None
    return m.group(1) if m else None


def reset_admin_password(odoo_container, pg_container, e: Environment, password: str) -> None:
    """用 Odoo 自带的 passlib 生成哈希,直接写进 res_users(适用于克隆 / 恢复来的库)。"""
    code, out = _exec(odoo_container, ["python3", "-c",
                                       "import sys;from passlib.context import CryptContext;print(CryptContext(['pbkdf2_sha512']).hash(sys.argv[1]))", password])
    h = out.strip().splitlines()[-1] if out.strip() else ""
    if code != 0 or not h.startswith("$pbkdf2"):
        raise RuntimeError(f"生成密码哈希失败:{out[-200:]}")
    sql = f"UPDATE res_users SET password={_q(h)}, active=true WHERE login={_q(_login_of(e))}"
    code, out = _exec(pg_container, ["psql", "-v", "ON_ERROR_STOP=1", "-X", "-q", "-U", "postgres", "-d", e.db_name, "-c", sql])
    if code != 0:
        raise RuntimeError(f"写入密码失败:{out[-200:]}")


def _q(s: str) -> str:
    return "'" + s.replace("'", "''") + "'"


def _login_of(e) -> str:
    """该库的管理员登录名:附加库(databases.EnvDb)可能是原生建库时填的邮箱;主库恒为 admin。"""
    return getattr(e, "admin_login", None) or ADMIN_LOGIN


def ensure_admin_password(t: Tenant, e: Environment, say=log.info) -> None:
    """创建/克隆完成后调用:把 admin 用户密码设为环境记录的 admin_password(尽力而为,失败只记日志)。"""
    from .orchestrator import pg_container_name

    try:
        c = dockerx.get_container(e.container_name or "")
        pg = dockerx.get_container(pg_container_name(t))
        if not c or not pg or not e.admin_password:
            return
        if authenticate(c, e.db_name, _login_of(e), e.admin_password, host=e.domain):
            return
        reset_admin_password(c, pg, e, e.admin_password)
        say(f"已设置 Odoo 管理员账号 {ADMIN_LOGIN} 的密码(见实例设置)")
    except Exception as ex:  # noqa: BLE001
        say(f"设置 Odoo 管理员密码失败(不影响使用,可用一键登录时自动重置):{ex}")


def login_session(t: Tenant, e: Environment) -> str:
    """返回可用的 Odoo session_id;必要时重置 admin 密码。抛 RuntimeError。e 可为 databases.EnvDb(附加库视图)。"""
    from .orchestrator import pg_container_name

    c = dockerx.get_container(e.container_name or "")
    if not c or c.status != "running":
        raise RuntimeError("实例未在运行")
    if not e.admin_password or not e.db_name:
        raise RuntimeError("实例缺少管理员密码或数据库")
    sid = authenticate(c, e.db_name, _login_of(e), e.admin_password, host=e.domain)
    if sid:
        return sid
    pg = dockerx.get_container(pg_container_name(t))
    if not pg:
        raise RuntimeError("找不到组织数据库容器")
    reset_admin_password(c, pg, e, e.admin_password)
    sid = authenticate(c, e.db_name, _login_of(e), e.admin_password, host=e.domain)
    if not sid:
        raise RuntimeError("重置密码后仍无法登录 Odoo,请查看容器日志")
    return sid


def sso_url(e: Environment, ticket: str) -> str:
    return f"{(e.url or '').rstrip('/')}/odoosh/sso?t={ticket}"


__all__ = ["make_ticket", "read_ticket", "login_session", "ensure_admin_password", "sso_url", "ADMIN_LOGIN"]
