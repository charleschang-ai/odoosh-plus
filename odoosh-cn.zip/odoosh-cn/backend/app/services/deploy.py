"""代码部署管线:仓库镜像 → 按 commit 检出 → 换挂载重建容器 → (可选)升级模块 → 健康检查 → 失败回退。

目录:
  repos/<key>/mirror.git                bare 镜像(用仓库凭据 fetch,不存凭据)
  repos/<key>/<branch>@<sha12>/         某 commit 的检出(git archive,无 .git),只读挂载到 /mnt/extra-addons
                                        每个环境只挂自己那一个检出目录(换 commit = 重建容器),容器里看不到镜像与其它环境的检出
<key> = 已接入仓库的 id;未接入(手填公开地址)则为 URL 的短 hash。
"""

import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import threading
import time
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..db import SessionLocal
from ..models import Environment, Tenant
from ..models_deploy import Deployment
from ..models_git import Repository
from . import dockerx
from . import git as gitsvc
from .enterprise import _redact, git_auth_env, repo_token
from .throttlelog import ThrottledLog

log = logging.getLogger("odoosh.deploy")

_locks: dict[str, threading.Lock] = {}
_guard = threading.Lock()
_last_fetch: dict[str, float] = {}
FETCH_THROTTLE = 30  # 秒内不重复 fetch


def _lock(key: str) -> threading.Lock:
    with _guard:
        return _locks.setdefault(key, threading.Lock())


def _git(args: list[str], cwd: str | None = None, timeout: int = 600, token: str | None = None, extra_env: dict | None = None) -> str:
    env = {"GIT_TERMINAL_PROMPT": "0", "PATH": os.environ.get("PATH", ""), "HOME": "/tmp", **(extra_env or {})}
    r = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
    if r.returncode != 0:
        raise RuntimeError(_redact((r.stderr or r.stdout).strip()[-800:], token))
    return r.stdout


# ---------------------------------------------------------------- 仓库解析
def find_repo(db: Session, tenant_id: int, repo_url: str | None) -> Repository | None:
    if not repo_url:
        return None
    key = gitsvc.normalize_repo_url(repo_url)
    for r in db.scalars(select(Repository).where(Repository.tenant_id == tenant_id)).all():
        if gitsvc.normalize_repo_url(r.url) == key:
            return r
    return None


def repo_key(repo: Repository | None, repo_url: str) -> str:
    if repo:
        return str(repo.id)
    return "u-" + hashlib.sha1(gitsvc.normalize_repo_url(repo_url).encode()).hexdigest()[:10]


def repos_root() -> str:
    d = os.path.join(settings.data_dir, "repos")
    os.makedirs(d, exist_ok=True)
    return d


def mirror_dir(key: str) -> str:
    return os.path.join(repos_root(), key, "mirror.git")


def to_host_path(p: str) -> str:
    if p.startswith(settings.data_dir):
        return settings.host_data_dir + p[len(settings.data_dir):]
    return p


def _clone_url(repo: Repository | None, repo_url: str, token: str | None) -> tuple[str, dict]:
    """返回 (不含凭据的 https 地址, 传给 git 子进程的鉴权环境变量)。"""
    try:
        info = gitsvc.parse_repo_url(repo_url)
        url = info["https_url"]
        provider = info["provider"]
    except Exception:  # noqa: BLE001
        url, provider = repo_url, "generic"
    return url, git_auth_env(provider, token)


# ---------------------------------------------------------------- 镜像
def _fetch_mirror(md: str, key: str, repo: Repository | None, repo_url: str, tok: str | None, timeout: int, say=log.info) -> None:
    say("同步仓库镜像(git fetch)...")
    gitsvc.assert_repo_url_safe(repo_url)
    url, aenv = _clone_url(repo, repo_url, tok)
    aenv = gitsvc.pin_env(url, aenv)  # 钉死校验过的 IP,git 不再自己解析(防 DNS 重绑定)
    _git(["--git-dir", md, "fetch", "--prune", "--force", url, "+refs/heads/*:refs/heads/*"], timeout=timeout, token=tok, extra_env=aenv)
    _last_fetch[key] = time.time()


_bg_fetching: set[str] = set()


def ensure_mirror(db: Session, tenant_id: int, repo_url: str, force: bool = False, say=log.info,
                  fetch_timeout: int = 1800, background: bool = False) -> tuple[str, Repository | None]:
    """确保镜像存在并(节流地)更新到最新。返回 (mirror 目录, 仓库记录或 None)。

    background=True(请求路径用):镜像已存在时不阻塞请求——过期则起后台线程 fetch,立即返回当前镜像;
    镜像尚不存在时首次同步 fetch(限时 fetch_timeout)。force=True 总是同步 fetch。
    """
    repo = find_repo(db, tenant_id, repo_url)
    key = repo_key(repo, repo_url)
    md = mirror_dir(key)
    tok = repo_token(db, repo) if repo else None
    lk = _lock("mirror:" + key)
    if background and not force and os.path.isdir(md) and not lk.acquire(blocking=False):
        # 请求路径:镜像已存在、但正有别的线程在 fetch(可能要几分钟)——不等锁,直接用当前镜像,页面轮询不被卡住
        return md, repo
    if not (background and not force and os.path.isdir(md)):
        lk.acquire()
    try:
        fresh = not os.path.isdir(md)
        if fresh:
            os.makedirs(os.path.dirname(md), exist_ok=True)
            say(f"初始化仓库镜像 {repo_url}")
            _git(["init", "--bare", md])
        stale = time.time() - _last_fetch.get(key, 0) > FETCH_THROTTLE
        if force or fresh or (stale and not background):
            _fetch_mirror(md, key, repo, repo_url, tok, fetch_timeout, say)
        elif stale and background and key not in _bg_fetching:
            _bg_fetching.add(key)

            def _bg():
                try:
                    with _lock("mirror:" + key):
                        _fetch_mirror(md, key, repo, repo_url, tok, 600)
                except Exception as ex:  # noqa: BLE001
                    log.warning("后台同步镜像 %s 失败: %s", repo_url, ex)
                finally:
                    _bg_fetching.discard(key)

            threading.Thread(target=_bg, daemon=True, name=f"mirror-fetch-{key}").start()
    finally:
        lk.release()
    return md, repo


def resolve_commit(md: str, branch: str) -> str:
    try:
        return _git(["--git-dir", md, "rev-parse", "--verify", f"refs/heads/{branch}^{{commit}}"]).strip()
    except RuntimeError:
        raise RuntimeError(f"仓库中没有分支「{branch}」")


_SHA_RE = re.compile(r"^[0-9a-fA-F]{7,64}$")


def check_sha(sha: str | None) -> str:
    """commit sha 只允许十六进制(来自 webhook 载荷的值不可信,防 `--output=…` 之类的 git 参数注入)。"""
    if not sha or not _SHA_RE.match(str(sha)):
        raise ValueError(f"非法的 commit: {str(sha)[:40]!r}")
    return str(sha)


def commit_info(md: str, sha: str) -> dict:
    out = _git(["--git-dir", md, "log", "-1", "--format=%H%x1f%an%x1f%at%x1f%s", check_sha(sha), "--"]).strip()
    h, an, at, s = (out.split("\x1f") + ["", "", "", ""])[:4]
    return {"sha": h, "author": an, "committed_at": datetime.fromtimestamp(int(at or 0), tz=timezone.utc), "message": s}


def list_commits(md: str, branch: str, limit: int = 50, skip: int = 0) -> list[dict]:
    try:
        out = _git(["--git-dir", md, "log", f"--max-count={limit}", f"--skip={skip}", "--format=%H%x1f%an%x1f%at%x1f%s", f"refs/heads/{branch}"])
    except RuntimeError:
        return []
    items = []
    for line in out.splitlines():
        if not line.strip():
            continue
        h, an, at, s = (line.split("\x1f") + ["", "", "", ""])[:4]
        items.append({"sha": h, "author": an, "committed_at": datetime.fromtimestamp(int(at or 0), tz=timezone.utc).isoformat(), "message": s})
    return items


def list_branches(md: str) -> list[dict]:
    try:
        out = _git(["--git-dir", md, "for-each-ref", "--sort=-committerdate", "--format=%(refname:short)%1f%(objectname)%1f%(committerdate:unix)%1f%(subject)", "refs/heads/"])
    except RuntimeError:
        return []
    items = []
    for line in out.splitlines():
        n, sha, at, s = (line.split("\x1f") + ["", "", "", ""])[:4]
        if n:
            items.append({"name": n, "sha": sha, "committed_at": datetime.fromtimestamp(int(at or 0), tz=timezone.utc).isoformat(), "message": s})
    return items


# ---------------------------------------------------------------- 检出
def _safe(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "-", name)[:60]


MARK_COMMIT = ".odoosh-commit"
MARK_ROOT = ".odoosh-root"      # 检出目录对应仓库内的子目录前缀(""=仓库根,"addons"=addons/ 子目录)
INCR_MAX_PATHS = 2000           # 变更文件超过这个数就干脆全量解(命令行长度 / 收益都不划算)


def _has_modules(d: str) -> bool:
    return os.path.isdir(d) and any(os.path.isfile(os.path.join(d, n, "__manifest__.py")) for n in os.listdir(d))


def _latest_checkout(key: str, exclude: str) -> tuple[str, str, str] | None:
    """同仓库最近一次完成的检出:(目录, sha, 子目录前缀)。没有可用的返回 None。"""
    base = os.path.join(repos_root(), key)
    best = None
    try:
        names = os.listdir(base)
    except OSError:
        return None
    for n in names:
        p = os.path.join(base, n)
        if n == "mirror.git" or n.endswith(".tmp") or "@" not in n or p == exclude or not os.path.isdir(p):
            continue
        cf, rf = os.path.join(p, MARK_COMMIT), os.path.join(p, MARK_ROOT)
        if not os.path.isfile(cf) or not os.path.isfile(rf):
            continue  # 旧格式(没有 .odoosh-root)的检出不作为增量基线
        try:
            mt = os.path.getmtime(cf)
            if best is None or mt > best[0]:
                with open(cf) as f:
                    sha = f.read().strip()
                with open(rf) as f:
                    prefix = f.read().strip()
                best = (mt, p, sha, prefix)
        except OSError:
            continue
    return (best[1], best[2], best[3]) if best else None


def incremental_extract(md: str, sha: str, tmp: str, prev: tuple[str, str, str] | None, uid: int | None, say) -> str | None:
    """增量检出:硬链接上一次检出 prev=(目录, sha, 子目录前缀),再只解出两 commit 之间变更的文件。
    成功返回子目录前缀;不适用/失败返回 None(调用方全量解)。企业版代码(enterprise.ensure_code)也用它。

    以前每个 commit 都把整棵树 `git archive | tar -x` 写一遍——10 次部署 500MB 的仓库要写 5GB,而相邻 commit 99% 的文件相同。
    硬链接是安全的:检出目录只读挂进容器,从不原地改写;变更文件先 unlink 再写(断开链接,不影响旧检出)。"""
    if not prev:
        return None
    prev_dir, prev_sha, prefix = prev
    if prev_sha == sha:
        return None
    try:
        if uid is not None and os.stat(os.path.join(prev_dir, MARK_COMMIT)).st_uid != uid:
            return None  # 上一检出归属不同 uid:硬链接后 chown 会连带改掉旧检出,放弃增量
        out = _git(["--git-dir", md, "diff", "--name-only", "--no-renames", "-z", "--diff-filter=d", prev_sha, sha], timeout=300)
        kept = [x for x in out.split("\0") if x]                     # 新 sha 里存在的变更文件(A/M/T)
        out = _git(["--git-dir", md, "diff", "--name-only", "--no-renames", "-z", "--diff-filter=D", prev_sha, sha], timeout=300)
        deleted = [x for x in out.split("\0") if x]
    except (RuntimeError, OSError) as ex:
        log.debug("增量检出:计算差异失败,回退全量: %s", ex)
        return None
    if len(kept) + len(deleted) > INCR_MAX_PATHS:
        return None
    pre = prefix + "/" if prefix else ""

    def _rel(path: str) -> str | None:
        if pre and not path.startswith(pre):
            return None  # 变更在子目录之外,与检出无关
        return path[len(pre):]

    try:
        shutil.rmtree(tmp, ignore_errors=True)  # tmp 若已存在,cp 会把 prev 拷成它的子目录
        subprocess.run(["cp", "-al", prev_dir, tmp], check=True, capture_output=True, timeout=600)
        for m in (MARK_COMMIT, MARK_ROOT):
            try:
                os.unlink(os.path.join(tmp, m))
            except OSError:
                pass
        for path in deleted + kept:
            rel = _rel(path)
            if not rel:
                continue
            fp = os.path.join(tmp, rel)
            if os.path.lexists(fp):
                if os.path.isdir(fp) and not os.path.islink(fp):
                    shutil.rmtree(fp, ignore_errors=True)
                else:
                    os.unlink(fp)
        # 删除后清掉变空的父目录(目录→文件之类的形态变化才不会卡住 tar)
        for path in deleted:
            rel = _rel(path)
            d = os.path.dirname(os.path.join(tmp, rel)) if rel else None
            while d and d != tmp and os.path.isdir(d) and not os.listdir(d):
                os.rmdir(d)
                d = os.path.dirname(d)
        to_extract = [p for p in kept if _rel(p)]
        if to_extract:
            strip = str(prefix.count("/") + 1) if prefix else "0"
            p1 = subprocess.Popen(["git", "--git-dir", md, "archive", "--format=tar", sha, "--", *to_extract],
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            p2 = subprocess.run(["tar", "-x", "-C", tmp, f"--strip-components={strip}"], stdin=p1.stdout, capture_output=True, timeout=600)
            p1.wait(timeout=600)
            if p1.returncode != 0 or p2.returncode != 0:
                raise RuntimeError((p1.stderr.read().decode(errors="ignore") if p1.stderr else "") + p2.stderr.decode(errors="ignore"))
        if not _has_modules(tmp):
            raise RuntimeError("增量结果里没有模块目录(仓库布局可能变了)")
    except Exception as ex:  # noqa: BLE001
        log.info("增量检出失败,回退全量: %s", str(ex)[-200:])
        shutil.rmtree(tmp, ignore_errors=True)
        os.makedirs(tmp)
        return None
    say(f"增量检出(基于 {prev_sha[:12]}:变更 {len(to_extract)} 个文件,删除 {len(deleted)} 个,其余硬链接复用)")
    return prefix


def checkout(md: str, key: str, branch: str, sha: str, uid: int, say=log.info) -> str:
    """把 sha 检出到 repos/<key>/<branch>@<sha12>(已存在则复用)。返回容器内路径。
    优先增量(硬链接上一检出 + 只解变更文件),否则全量 git archive。"""
    target = os.path.join(repos_root(), key, f"{_safe(branch)}@{sha[:12]}")
    with _lock("co:" + target):
        if os.path.isdir(target) and os.path.isfile(os.path.join(target, MARK_COMMIT)):
            return target
        tmp = target + ".tmp"
        shutil.rmtree(tmp, ignore_errors=True)
        os.makedirs(tmp)
        say(f"检出代码 {branch}@{sha[:12]} ...")
        from .fsutil import chown_tree

        prefix = incremental_extract(md, sha, tmp, _latest_checkout(key, exclude=target), uid, say)
        if prefix is not None:
            with open(os.path.join(tmp, MARK_COMMIT), "w") as f:
                f.write(sha + "\n")
            with open(os.path.join(tmp, MARK_ROOT), "w") as f:
                f.write(prefix + "\n")
            os.chown(os.path.join(tmp, MARK_COMMIT), uid, uid)
            os.chown(os.path.join(tmp, MARK_ROOT), uid, uid)
            os.rename(tmp, target)
            return target
        p1 = subprocess.Popen(["git", "--git-dir", md, "archive", "--format=tar", check_sha(sha)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        p2 = subprocess.run(["tar", "-x", "-C", tmp], stdin=p1.stdout, capture_output=True, timeout=600)
        p1.wait(timeout=600)
        if p1.returncode != 0 or p2.returncode != 0:
            shutil.rmtree(tmp, ignore_errors=True)
            raise RuntimeError("检出代码失败:" + (p1.stderr.read().decode(errors="ignore")[-300:] if p1.stderr else ""))
        # 模块在根目录或 addons/ 子目录
        root, prefix = tmp, ""
        if not _has_modules(tmp) and _has_modules(os.path.join(tmp, "addons")):
            root, prefix = os.path.join(tmp, "addons"), "addons"
            say("模块位于仓库 addons/ 子目录")
        with open(os.path.join(root, MARK_COMMIT), "w") as f:
            f.write(sha + "\n")
        with open(os.path.join(root, MARK_ROOT), "w") as f:
            f.write(prefix + "\n")
        chown_tree(root, uid)
        if root != tmp:
            os.rename(root, target)
            shutil.rmtree(tmp, ignore_errors=True)
        else:
            os.rename(tmp, target)
        return target


def gc_checkouts(key: str, keep: int = 2) -> int:
    """清理 repos/<key>/ 下不再被任何环境引用的旧检出目录(每个分支保留最近 keep 个)。返回删除数。"""
    base = os.path.join(repos_root(), key)
    if not os.path.isdir(base):
        return 0
    with SessionLocal() as db:
        referenced = {p for (p,) in db.execute(select(Environment.code_path).where(Environment.code_path.is_not(None))).all()}
    by_branch: dict[str, list[tuple[float, str]]] = {}
    for n in os.listdir(base):
        if n == "mirror.git" or n.endswith(".tmp") or "@" not in n:
            continue
        p = os.path.join(base, n)
        if not os.path.isdir(p) or p in referenced or os.path.realpath(p) in referenced:
            continue
        by_branch.setdefault(n.rsplit("@", 1)[0], []).append((os.path.getmtime(p), p))
    removed = 0
    for lst in by_branch.values():
        lst.sort(reverse=True)
        for _, p in lst[keep:]:
            shutil.rmtree(p, ignore_errors=True)
            removed += 1
    if removed:
        log.info("清理旧检出目录 %s 个(%s)", removed, key)
    return removed


# ---------------------------------------------------------------- 代码挂载(每个环境只挂自己的检出目录)
# 曾经的做法是挂整个 repos/<key>/ 根 + env-<id> 软链,部署只切软链再原地重启。副作用是容器里能看到镜像和
# 同仓库所有环境的检出(AI 编程模块的目录选择器里一堆 master@sha / env-N),路径也随 sha 变。现在「重启」本身
# 就是重建容器,省下的几秒没有意义,所以改回直接挂 code_path:部署 / 回退 = 换 code_path + 重建容器。
def repo_root_of(code_path: str) -> str:
    """repos/<key>/<branch>@<sha> → repos/<key>"""
    return os.path.dirname(code_path.rstrip("/"))


def env_link_name(e: Environment) -> str:
    return f"env-{e.id}"


def container_addons_path(e: Environment) -> str:
    """容器内自定义 addons 路径:固定 /mnt/extra-addons(git 实例挂当前 commit 的检出;无 git 实例挂定制目录)。"""
    return "/mnt/extra-addons"


def remove_legacy_link(e: Environment) -> None:
    """删掉旧布局遗留的 repos/<key>/env-<id> 软链(存量实例第一次重建 / 部署时顺手清理,失败只记日志)。"""
    if not e.code_path:
        return
    link = os.path.join(repo_root_of(e.code_path), env_link_name(e))
    try:
        if os.path.islink(link):
            os.remove(link)
    except OSError as ex:
        log.debug("删除旧代码软链失败: %s", ex)


def changed_modules(md: str, old_sha: str | None, new_sha: str, path: str) -> list[str] | None:
    """两个 commit 之间有改动的顶层模块(存在于新检出中)。无法判断(无 old_sha / diff 失败)返回 None = 全部。"""
    if not old_sha or old_sha == new_sha:
        return [] if old_sha == new_sha else None
    try:
        out = _git(["--git-dir", md, "diff", "--name-only", check_sha(old_sha), check_sha(new_sha), "--"], timeout=120)
    except RuntimeError:
        return None
    mods = set(modules_in(path))
    # 仓库可能把模块放在 addons/ 子目录(checkout 时已把根切到 addons/)
    hit: set[str] = set()
    for ln in out.splitlines():
        parts = ln.strip().split("/")
        if not parts:
            continue
        for i in range(min(2, len(parts))):
            if parts[i] in mods:
                hit.add(parts[i])
                break
    return sorted(hit)


def installed_modules(t: Tenant, e: Environment) -> set[str] | None:
    """主库里已安装的模块名;查不到(库不存在 / PG 没起)返回 None。"""
    from . import orchestrator as orch

    if not e.db_name:
        return None
    pg = dockerx.get_container(orch.pg_container_name(t))
    if not pg or pg.status != "running":
        return None
    code, out = orch._psql(pg, "COPY (SELECT name FROM ir_module_module WHERE state IN ('installed','to upgrade')) TO STDOUT", e.db_name)
    if code != 0:
        return None
    return {ln.strip() for ln in out.splitlines() if ln.strip()}


def custom_code_changes(t: Tenant, e: Environment, say=log.info) -> list[str]:
    """定制代码目录(/mnt/custom-addons,不在 git 里)相对上次部署 / 升级快照有改动、且主库已安装的模块,供 update_all 一并 -u。
    新写的还没安装的模块 -u 不会装,只提示用户去「应用」里装;判断不了安装状态时全部纳入(-u 未安装模块无副作用)。"""
    from . import custom_code as cc

    try:
        info = cc.custom_changes(t, e)
    except Exception as ex:  # noqa: BLE001
        log.warning("扫描定制代码目录失败(实例 %s): %s", e.id, ex)
        return []
    if info["removed"]:
        say(f"定制代码:模块 {', '.join(info['removed'])} 已从目录删除(数据库里若已安装请在「应用」中卸载)")
    cand = info["changed"] + info["new"]
    if not cand:
        return []
    installed = installed_modules(t, e)
    todo = [m for m in cand if installed is None or m in installed]
    skip = [m for m in cand if m not in todo]
    if skip:
        say(f"定制代码:模块 {', '.join(skip)} 尚未安装(-u 不会安装),请在 Odoo「应用」里安装")
    if todo:
        say(f"定制代码:检测到 {len(todo)} 个模块有改动:{', '.join(todo)}")
    return todo


def modules_in(path: str) -> list[str]:
    try:
        return sorted(n for n in os.listdir(path) if os.path.isfile(os.path.join(path, n, "__manifest__.py")))
    except OSError:
        return []


# ---------------------------------------------------------------- 部署记录
def _set(dep_id: int, **fields) -> None:
    from sqlalchemy import update

    with SessionLocal() as db:
        db.execute(update(Deployment).where(Deployment.id == dep_id).values(**fields))
        db.commit()


class DepLog(ThrottledLog):
    KEEP = 300

    def __init__(self, dep_id: int, also=None):
        super().__init__()
        self.dep_id = dep_id
        self.also = also

    def _persist(self, text: str, last_msg: str) -> None:
        _set(self.dep_id, log=text)

    def __call__(self, msg: str) -> None:
        line = f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"
        self.add(line, msg)
        if self.also:
            self.also(msg)
        log.info("deploy#%s %s", self.dep_id, msg)
        try:
            from . import logstream

            logstream.publish(f"dep:{self.dep_id}", line)
        except Exception:  # noqa: BLE001
            pass


def create_record(db: Session, e: Environment, trigger: str, action: str, modules: str | None, who: str | None,
                  sha: str | None = None, databases: list[str] | None = None) -> Deployment:
    """databases:本次 -u 只作用于这些库(库名列表);None = 实例全部库(主库 + 附加库)。"""
    d = Deployment(
        environment_id=e.id, tenant_id=e.tenant_id, repo_url=e.repo_url, branch=e.branch,
        commit_sha=sha, trigger=trigger, action=action, modules=modules, status="queued", created_by=who,
        databases=",".join(databases) if databases else None,
    )
    db.add(d)
    db.commit()
    db.refresh(d)
    return d


# ---------------------------------------------------------------- 主流程
def prepare_code(db: Session, e: Environment, uid: int, sha: str | None, say=log.info) -> tuple[str, dict]:
    """镜像同步 → 解析 commit → 检出。返回 (路径, commit 信息)。"""
    md, repo = ensure_mirror(db, e.tenant_id, e.repo_url, say=say)
    key = repo_key(repo, e.repo_url)
    target_sha = sha or resolve_commit(md, e.branch)
    info = commit_info(md, target_sha)
    path = checkout(md, key, e.branch, target_sha, uid, say)
    return path, info


REQUIREMENTS_TIMEOUT = 1200
# 离线 wheel 仓库在实例容器里的挂载点(内网无 PyPI 时用 --find-links 从这里装)
OFFLINE_PIP_MOUNT = "/mnt/offline-pip"


def offline_wheels_dir() -> str | None:
    """<data_dir>/offline/pip/instance —— 有包就返回容器内路径,否则 None(回落到 PyPI / 内网源)。
    包由 deploy/fetch-offline-deps.sh --instance-req 在有网机器上下好后拷进来。"""
    d = os.path.join(settings.data_dir, "offline", "pip", "instance")
    try:
        if os.path.isdir(d) and any(n.endswith((".whl", ".tar.gz", ".zip")) for n in os.listdir(d)):
            return d
    except OSError:
        pass
    return None


def requirements_files(t: Tenant, e: Environment, checkout_path: str | None) -> list[tuple[str, str]]:
    """要安装的 requirements.txt:仓库根目录 + 定制代码目录根 + 定制目录里每个模块自己的(AI 写的模块常把依赖放模块里)。
    返回 [(宿主机路径, 容器内路径)]。"""
    from . import custom_code as cc
    from . import orchestrator as orch

    out: list[tuple[str, str]] = []
    if checkout_path and os.path.isfile(os.path.join(checkout_path, "requirements.txt")):
        out.append((os.path.join(checkout_path, "requirements.txt"), f"{container_addons_path(e)}/requirements.txt"))
    d = cc.addons_dir(t, e)
    if os.path.isfile(os.path.join(d, "requirements.txt")):
        out.append((os.path.join(d, "requirements.txt"), f"{orch.CUSTOM_ADDONS_MOUNT}/requirements.txt"))
    for name in cc._module_names(d):
        f = os.path.join(d, name, "requirements.txt")
        if os.path.isfile(f):
            out.append((f, f"{orch.CUSTOM_ADDONS_MOUNT}/{name}/requirements.txt"))
    return out


def requirements_sha(t: Tenant, e: Environment, checkout_path: str | None) -> tuple[list[tuple[str, str]], str | None]:
    """返回 (requirements 文件列表, 所有文件内容合起来的 sha256);一个都没有时返回 ([], None)。"""
    files = requirements_files(t, e, checkout_path)
    if not files:
        return [], None
    h = hashlib.sha256()
    for host, cont in files:
        h.update(cont.encode("utf-8") + b"\0")
        try:
            with open(host, "rb") as fh:
                h.update(fh.read())
        except OSError:
            pass
        h.update(b"\0")
    return files, h.hexdigest()


def install_requirements(t: Tenant, e: Environment, tag: str, checkout_path: str | None, say=log.info) -> bool:
    """安装 requirements.txt 里的 Python 依赖(odoo.sh 同款行为):仓库根目录的 + 定制代码目录(根 / 各模块)的,见 requirements_files。
    部署、重启、「升级模块」都会调,内容没变就秒过。

    - 装到 ~/.local(= /var/lib/odoo/.local,实例独有的 filestore 卷)→ 每实例隔离、容器重建后仍在
    - 用一次性容器执行(与模块升级同机制),主容器停着也能装;以非 root 的 odoo 用户运行
    - 内容未变(requirements_sha 相同)则跳过,避免每次部署都跑一遍 pip
    返回 True=已安装/无需安装;抛异常=安装失败(由调用方按部署失败回退)。
    """
    from ..routers.settings import get_setting
    from . import orchestrator as orch

    files, sha = requirements_sha(t, e, checkout_path)
    if not files:
        return True
    with SessionLocal() as db:
        if (get_setting(db, "deploy.install_requirements") or "1") != "1":
            say("检测到 requirements.txt,但平台已关闭自动安装依赖(系统设置),跳过")
            return True
    if sha and sha == (e.requirements_sha or ""):
        say("requirements.txt 未变化,跳过依赖安装(依赖已在 ~/.local)")
        return True
    n = 0
    for host, _cont in files:
        try:
            n += sum(1 for ln in open(host, encoding="utf-8", errors="ignore") if ln.strip() and not ln.strip().startswith("#"))
        except OSError:
            pass
    say(f"检测到 {len(files)} 个 requirements.txt({', '.join(c for _h, c in files)};共 {n} 条),安装 Python 依赖到 ~/.local(约 1~5 分钟)…")
    req_args = " ".join(f"-r '{c}'" for _h, c in files)
    # 离线仓库:<data_dir>/offline/pip/instance 里有 wheel 就只读挂进容器,用本地包装(内网没有 PyPI)。
    # 由 deploy/fetch-offline-deps.sh --instance-req 在有网机器上下载,wheel 需与实例镜像的 Python / 架构一致。
    wheels, extra_mounts = offline_wheels_dir(), None
    if wheels:
        from docker.types import Mount

        extra_mounts = orch._mounts(t, e) + [
            Mount(OFFLINE_PIP_MOUNT, to_host_path(wheels), type="bind", read_only=True)
        ]
        say(f"使用离线依赖仓库 {OFFLINE_PIP_MOUNT}(不访问 PyPI)")
        pip_args = f"--no-index --find-links '{OFFLINE_PIP_MOUNT}'"
    else:
        pip_args = ""
    cmd = ("set -e; export HOME=/var/lib/odoo; "
           f"python3 -m pip install --user --break-system-packages --no-input --disable-pip-version-check {pip_args} {req_args}")
    env_prefix = ""
    if settings.pip_index_url and not wheels:
        env_prefix = f"export PIP_INDEX_URL='{settings.pip_index_url}'; "
    code, out = orch.run_oneoff(t, e, tag, ["sh", "-c", env_prefix + cmd], suffix="pip",
                                timeout=REQUIREMENTS_TIMEOUT, mounts=extra_mounts)
    tail = (out or "")[-2000:]
    if code != 0:
        say(f"依赖安装失败(退出码 {code}),输出:")
        say(tail)
        if wheels:
            say(f"提示:当前用的是离线 wheel 仓库({wheels}),里面可能缺这次新增的包。"
                "在有网机器上执行 deploy/fetch-offline-deps.sh --only pip --instance-req <本仓库的 requirements.txt> 补齐后拷回该目录。")
        else:
            say("提示:内网无法访问 PyPI 时,可用 deploy/fetch-offline-deps.sh 预下载 wheel 放到 "
                "<数据目录>/offline/pip/instance/,或在「系统设置」关掉「部署时自动安装依赖」。")
        raise RuntimeError("requirements.txt 依赖安装失败,已回退代码;请检查依赖名称/版本或网络")
    for ln in [x for x in (out or "").splitlines() if "Successfully installed" in x or "Requirement already satisfied" in x][-3:]:
        say(f"  {ln.strip()[:200]}")
    say("依赖安装完成")
    with SessionLocal() as db2:
        row = db2.get(Environment, e.id)
        if row:
            row.requirements_sha = sha
            db2.commit()
    e.requirements_sha = sha
    return True


def deploy(dep_id: int) -> bool:
    """执行一次部署(后台任务)。

    流程:同步镜像 → 检出 commit → 切换 code_path → 停掉旧容器 → (可选)-u 变更模块 → 用新检出目录重建容器 → 健康检查;失败回退 code_path 并重建。
    """
    from . import orchestrator as orch

    say = DepLog(dep_id)
    with SessionLocal() as db:
        d = db.get(Deployment, dep_id)
        if not d:
            return False
        e = db.get(Environment, d.environment_id)
        t = db.get(Tenant, e.tenant_id) if e else None
        if not e or not t:
            _set(dep_id, status="failed", message="环境不存在", finished_at=datetime.now(timezone.utc))
            return False
        _set(dep_id, status="running", started_at=datetime.now(timezone.utc))
        orch._set_status(e.id, "deploying", "准备代码", progress=5)
        prev_path, prev_commit = e.code_path, e.code_commit
        try:
            if not e.repo_url or not e.branch:
                raise RuntimeError("实例未绑定仓库/分支")
            uid = orch.env_odoo_uid(e)
            md, repo = ensure_mirror(db, e.tenant_id, e.repo_url, say=say)
            target_sha = d.commit_sha or resolve_commit(md, e.branch)
            info = commit_info(md, target_sha)
            path = checkout(md, repo_key(repo, e.repo_url), e.branch, target_sha, uid, say)
            _set(dep_id, commit_sha=info["sha"], commit_message=info["message"][:512], author=info["author"], committed_at=info["committed_at"])
            say(f"目标提交 {info['sha'][:12]}:{info['message'][:80]}(模块 {len(modules_in(path))} 个)")

            # 决定要升级的模块
            action = d.action
            mods = ""
            if action == "update":
                mods = ",".join(m.strip() for m in (d.modules or "").split(",") if m.strip())
                if not mods:
                    raise RuntimeError("未指定要升级的模块")
            elif action == "update_all":
                ch = changed_modules(md, prev_commit, info["sha"], path)
                cc_todo = custom_code_changes(t, e, say)  # 定制目录(不在 git 里)的改动也一并升级
                if ch is None:
                    mods = "all"
                    say("无法判断变更范围(首次部署或历史缺失),升级全部模块 -u all")
                elif not ch and not cc_todo:
                    say("代码相对当前部署无模块变更,只重启")
                    action = "restart"
                else:
                    if ch:
                        say(f"仓库代码检测到 {len(ch)} 个模块有改动:{','.join(ch)}")
                    mods = ",".join(ch + [m for m in cc_todo if m not in ch])
            e.code_path, e.code_commit = path, info["sha"]
            db.commit()
            remove_legacy_link(e)
            say(f"代码目录 → {os.path.basename(path)}")

            tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
            # 先装依赖再升级模块:被升级的模块可能在加载时 import 这些包
            orch._progress(e.id, 20, "安装依赖")
            install_requirements(t, e, tag, path, say)
            # 代码目录是按检出目录挂载的,换 commit 必须重建容器:先停掉旧容器(也给 -u 腾出数据库连接)
            main = dockerx.get_container(e.container_name or "")
            if main:
                orch._progress(e.id, 30, "停止容器")
                say("停止旧容器(切换代码目录需重建)")
                main.stop(timeout=30)
                main.remove(force=True)
            # 下面的 -u 一次性容器也用这份 odoo.conf:先按新布局重写(存量实例的 addons_path 还写着 /mnt/extra-addons/env-<id>)
            orch.write_odoo_conf(t, e, pg_host=orch.pg_container_name(t), uid=uid, core_addons=orch.images.core_addons_for(e))

            db_results: dict[str, str] = {}
            if action in ("update", "update_all"):
                # 多库:主库 + 附加库共用这份代码,逐库 -u(默认全部;部署时可勾选)。主库失败 → 整次部署失败并回退代码;
                # 附加库失败 → 记录在 db_results,不阻断其他库(代码已切换,由用户按库处理)
                from . import databases as dbsvc

                all_names = dbsvc.all_db_names(db, e)
                if d.databases:
                    wanted = [x.strip() for x in d.databases.split(",") if x.strip()]
                    targets = [n for n in all_names if n in wanted]
                    for n in all_names:
                        if n not in targets:
                            db_results[n] = "skipped"
                else:
                    targets = all_names
                if not targets:
                    targets = [e.db_name]
                for idx, dbname in enumerate(targets):
                    base_pct = 40 + int(idx * 35 / max(1, len(targets)))
                    span = max(1, int(35 / max(1, len(targets))))
                    orch._progress(e.id, base_pct, f"升级模块 {mods}({dbname})")
                    say(f"[{dbname}] 升级模块:-u {mods}(约 1~5 分钟)" if len(targets) > 1 else f"升级模块:-u {mods}(约 1~5 分钟)")
                    code, out = orch.run_oneoff(
                        t, e, tag, ["odoo", "-c", "/etc/odoo/odoo.conf", "-d", dbname, "-u", mods, "--stop-after-init"], suffix="upgrade",
                        on_tick=lambda i, el, b=base_pct, sp=span: orch._progress(e.id, b + min(sp, int(el / 180.0 * sp))),
                    )
                    if code != 0:
                        db_results[dbname] = "failed"
                        say(f"[{dbname}] 升级失败,容器输出:\n" + out[-2000:])
                        if dbname == e.db_name:
                            _set(dep_id, db_results=json.dumps(db_results, ensure_ascii=False))
                            raise RuntimeError("模块升级失败(主库)")
                        say(f"[{dbname}] 附加库升级失败,继续处理其他库")
                    else:
                        db_results[dbname] = "success"
                        say(f"[{dbname}] 模块升级完成" if len(targets) > 1 else "模块升级完成")
                _set(dep_id, db_results=json.dumps(db_results, ensure_ascii=False))

            orch._progress(e.id, 80, "启动容器")
            say("以新代码目录重建容器")
            c = orch.run_main_container(t, e, tag)
            orch.nginx.connect_web_to_network(e.network_name)  # 新容器新 IP:让网关重新解析上游
            orch.nginx.reload()
            orch._progress(e.id, 90, "等待 Odoo 就绪")
            if not orch._wait_healthy(c, say, on_tick=lambda i: orch._progress(e.id, min(99, 90 + i))):
                raise RuntimeError("部署后 Odoo 未就绪")
            n_fail = sum(1 for v in db_results.values() if v == "failed")
            from . import custom_code as cc

            cc.save_snapshot(t, e)  # 定制代码指纹:下次 update_all 只 -u 之后再改过的
            cc.refresh_module_list_if_needed(t, e, db, say)  # 没走 -u 的部署:新模块也要登记进「应用」列表
            say(f"部署完成:{info['sha'][:12]}" + (f"(注意:{n_fail} 个附加库升级失败,见各库结果)" if n_fail else ""))
            _set(dep_id, status="success", message=f"已部署 {info['sha'][:12]}" + (f",{n_fail} 个附加库升级失败" if n_fail else ""), finished_at=datetime.now(timezone.utc))
            orch._set_status(e.id, "running", None, progress=100)
            try:
                gc_checkouts(repo_key(repo, e.repo_url))
            except Exception as ex:  # noqa: BLE001
                log.warning("清理旧检出失败: %s", ex)
            return True
        except Exception as ex:  # noqa: BLE001
            log.exception("deploy failed")
            say(f"失败:{ex}")
            # 回退:恢复上一版 code_path,并用它重建容器(容器的代码挂载跟着 code_path 走,不能原地重启)
            try:
                if prev_path and os.path.isdir(prev_path):
                    say(f"回退到 {(prev_commit or '')[:12] or '上一版'}")
                    e.code_path, e.code_commit = prev_path, prev_commit
                    db.commit()
                tag = e.image_tag or orch.images.base_tag(e.odoo_version, e.base_mode or "official")
                main = dockerx.get_container(e.container_name or "")
                if main:
                    main.stop(timeout=30)
                    main.remove(force=True)
                c = orch.run_main_container(t, e, tag)
                orch.nginx.connect_web_to_network(e.network_name)
                orch.nginx.reload()
                ok = orch._wait_healthy(c, say)
                orch._set_status(e.id, "running" if ok else "failed", None if ok else "回退后未就绪", progress=0)
            except Exception as rb:  # noqa: BLE001
                say(f"回退失败:{rb}")
                orch._set_status(e.id, "failed", "部署失败且回退失败", progress=0)
            _set(dep_id, status="failed", message=str(ex)[:500], finished_at=datetime.now(timezone.utc))
            # 失败路径也清理旧检出(否则一直部署失败的仓库会无限累积);仍被引用的目录不会被删
            try:
                gc_checkouts(repo_key(repo, e.repo_url))
            except Exception as gex:  # noqa: BLE001
                log.debug("清理旧检出失败: %s", gex)
            return False
