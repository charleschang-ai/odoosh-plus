"""文件系统工具:批量 chown / 复制(用系统命令,比 Python 逐文件快一个量级)。"""

import logging
import os
import shutil
import subprocess

log = logging.getLogger("odoosh.fs")


def chown_tree(path: str, uid: int, gid: int | None = None) -> None:
    """递归修改归属。优先 `chown -R`(万文件目录 1~2s;Python os.walk 需数十秒),失败回退 Python。"""
    if not os.path.exists(path):
        return
    gid = uid if gid is None else gid
    try:
        subprocess.run(["chown", "-R", f"{uid}:{gid}", path], check=True, capture_output=True, timeout=600)
        return
    except Exception as ex:  # noqa: BLE001
        log.debug("chown -R 失败,回退 Python: %s", ex)
    for root, _dirs, files in os.walk(path):
        try:
            os.chown(root, uid, gid)
            for n in files:
                os.chown(os.path.join(root, n), uid, gid)
        except OSError:
            pass


def copy_tree(src: str, dst: str, link_ok: bool = False) -> None:
    """目录复制。link_ok=True 时优先硬链接(`cp -al`):秒级完成、不占额外空间——适用于 Odoo filestore
    (内容寻址 <sha1> 文件,只新增/删除、从不原地改写,两个实例共享 inode 是安全的);ext4 上 reflink 会退化成全量拷贝,
    50GB 的 filestore 每次「从生产刷新预发」都要写 50GB。其次 `cp -a --reflink=auto`(XFS/btrfs 上 CoW),再回退 shutil。
    注意:硬链接的两个环境必须用同一 uid(chown 会一起改)。"""
    os.makedirs(os.path.dirname(dst.rstrip("/")), exist_ok=True)
    if link_ok:
        try:
            subprocess.run(["cp", "-al", src, dst], check=True, capture_output=True, timeout=3600)
            return
        except Exception as ex:  # noqa: BLE001
            log.debug("cp -al 失败(可能跨文件系统),回退普通复制: %s", ex)
            shutil.rmtree(dst, ignore_errors=True)
    try:
        subprocess.run(["cp", "-a", "--reflink=auto", src, dst], check=True, capture_output=True, timeout=3600)
        return
    except Exception as ex:  # noqa: BLE001
        log.debug("cp -a 失败,回退 shutil.copytree: %s", ex)
        shutil.rmtree(dst, ignore_errors=True)
    shutil.copytree(src, dst, symlinks=True)


def du_bytes(path: str, timeout: int = 120) -> int | None:
    try:
        out = subprocess.run(["du", "-sb", path], capture_output=True, text=True, timeout=timeout).stdout
        return int(out.split()[0])
    except Exception:  # noqa: BLE001
        return None
