"""批量作业模型(通用):一个 BulkJob 挂 N 个 BulkJobItem。

首个使用者是「批量创建实例」(kind=env.create);以后 start/stop/deploy 等编排类批量复用同一张表。
用户类批量(创建/更新/删除用户)是秒级同步动作,走 routers/users.py 的快通道,不落这张表。
"""

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


class BulkJob(Base):
    __tablename__ = "bulk_jobs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    kind: Mapped[str] = mapped_column(String(32), index=True)  # env.create ...
    scope: Mapped[str] = mapped_column(String(16), default="environment")
    tenant_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    payload: Mapped[str | None] = mapped_column(Text)  # 动作计划 JSON(便于回看 / 重试)
    status: Mapped[str] = mapped_column(String(16), default="queued", index=True)  # queued|running|done|cancelling|cancelled
    total: Mapped[int] = mapped_column(Integer, default=0)
    succeeded: Mapped[int] = mapped_column(Integer, default=0)
    failed: Mapped[int] = mapped_column(Integer, default=0)
    skipped: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[str | None] = mapped_column(String(64))
    created_by_id: Mapped[int] = mapped_column(Integer, index=True)
    idempotency_key: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)  # 防双击 / 重试:重复提交返回同一 job
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class BulkJobItem(Base):
    __tablename__ = "bulk_job_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("bulk_jobs.id", ondelete="CASCADE"), index=True)
    target_type: Mapped[str] = mapped_column(String(16), default="environment")
    target_id: Mapped[int | None] = mapped_column(Integer, nullable=True)  # 建成后回填 env.id(前端可跳实例)
    label: Mapped[str] = mapped_column(String(128))  # 实例名快照(目标被删后结果仍可读)
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending|running|success|failed|skipped|cancelled
    message: Mapped[str | None] = mapped_column(String(512))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
