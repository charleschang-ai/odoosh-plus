from datetime import datetime

import re

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


def norm_slug(v, label):
    """把用户输入规范成合法标识(组织标识 / 实例名共用)。

    这类字段会被拼进容器名、Docker 网络名、数据库名和访问域名,而这些地方都只认
    小写 ASCII —— 所以能自动纠正的就自动纠正,纠不了的用中文说清错在哪,
    而不是把 Pydantic 的 "String should match pattern ..." 原样丢给用户。
    自动处理:去首尾空白、转小写、空格 / 下划线 / 点转中划线、合并连续中划线、去掉首尾多余中划线。
    """
    if not isinstance(v, str):
        return v
    s = re.sub(r"[\s_.]+", "-", v.strip().lower())
    s = re.sub(r"-{2,}", "-", s).strip("-")
    if not s:
        raise ValueError(f"{label}不能为空(只能用小写字母、数字和中划线,如 acme)")
    # 保序去重:sorted() 会把「上海科技」打乱成「上技海科」,报错反而让人看不懂
    bad = list(dict.fromkeys(re.findall(r"[^a-z0-9-]", s)))
    if bad:
        cjk = any("一" <= c <= "鿿" for c in bad)
        tip = ",中文请改用拼音或英文" if cjk else ""
        raise ValueError(
            f"{label}不能包含「{''.join(bad)}」—— 只能用小写字母、数字和中划线{tip}。"
            f"大写字母、空格和下划线会自动转换,例如「Shanghai Keji」→ shanghai-keji"
        )
    if len(s) < 2:
        raise ValueError(f"{label}至少 2 个字符(只能用小写字母、数字和中划线,如 acme)")
    return s


# 域名:仅允许 a-z0-9-.(写入 nginx server_name 前必须校验,防配置注入)
DOMAIN_RE = re.compile(r"^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$")


def _v_enum(v, allowed: tuple, label: str):
    if v is None:
        return v
    if not isinstance(v, str) or v.strip() not in allowed:
        raise ValueError(f"{label}须为 {' / '.join(allowed)}")
    return v.strip()


def _v_version(v):
    """Odoo 版本:两位数字(12~99);会拼进镜像 tag / 源码分支名 / 企业版目录,不接受其它字符。"""
    if v is None:
        return v
    v = str(v).strip()
    if not re.fullmatch(r"\d{2}", v):
        raise ValueError("Odoo 版本须为两位数字,如 17 / 18 / 19")
    return v


def _v_modules(v):
    """模块名列表(逗号分隔):只允许 a-z0-9_ 与逗号 / 空白。"""
    if v is None:
        return v
    if not isinstance(v, str):
        raise ValueError("模块列表格式不正确")
    v = ",".join(x.strip() for x in v.replace(";", ",").split(",") if x.strip())
    if v and not re.fullmatch(r"[a-z0-9_]+(,[a-z0-9_]+)*", v):
        raise ValueError("模块名只能包含小写字母、数字和下划线,多个用逗号分隔")
    return v or None


def _norm_domain(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    if not isinstance(v, str):
        raise ValueError("域名格式不正确")
    v = v.strip().lower()
    if not DOMAIN_RE.match(v):
        raise ValueError("域名只能包含小写字母、数字、中划线和点")
    return v


# ---- auth ----
class LoginIn(BaseModel):
    captcha_id: str | None = None
    captcha_code: str | None = None
    username: str
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---- users ----
class MembershipOut(ORM):
    tenant_id: int
    tenant_slug: str = ""
    tenant_name: str = ""
    role: str


class UserOut(ORM):
    id: int
    username: str
    display_name: str | None
    role: str  # admin = 超级管理员;member = 普通用户
    is_active: bool
    shell_enabled: bool = False
    can_use_enterprise: bool = True  # 是否可创建企业版实例
    menu_dashboard: bool = True  # 菜单可见性:总览
    menu_repos: bool = True      # 菜单可见性:Git 仓库
    menu_ai: bool = True         # 菜单可见性:AI 助手
    menu_backups: bool = True    # 菜单可见性:备份与恢复
    menu_settings: bool = False  # 实例「设置」Tab(默认关)
    menu_upgrade: bool = False   # 实例「升级」Tab(默认关)
    menu_databases: bool = False  # 实例「数据库」Tab(默认关)
    max_envs: int | None = None  # 实例配额(按拥有者计数);None = 不限,0 = 不能创建
    env_count: int = 0  # 当前作为拥有者的实例数(不含回收站)
    max_dbs: int | None = None  # 附加数据库配额(按创建者计数);None = 不限,0 = 不能创建
    db_count: int = 0  # 当前已创建的附加库数
    tenant_id: int | None
    created_at: datetime
    memberships: list[MembershipOut] = []
    is_root: bool = False  # 内置超级管理员(ODOOSH_ADMIN_USER):不可删除 / 停用 / 降级


class MeOut(UserOut):
    is_superadmin: bool = False
    memberships: list[MembershipOut] = []


class MemberOut(ORM):
    id: int  # membership id
    user_id: int
    username: str
    display_name: str | None
    role: str
    is_active: bool
    created_at: datetime


class MemberAdd(BaseModel):
    username: str
    role: str = "developer"
    # 用户不存在时可顺带创建(需提供密码)
    password: str | None = None
    display_name: str | None = None


class MemberUpdate(BaseModel):
    role: str


class MembershipIn(BaseModel):
    tenant_id: int
    role: str = "developer"  # owner | developer | tester


class UserCreate(BaseModel):
    username: str = Field(min_length=2, max_length=64)
    password: str = Field(min_length=4)
    display_name: str | None = None
    role: str = "member"  # admin | member
    shell_enabled: bool = False
    can_use_enterprise: bool = True
    menu_dashboard: bool = True
    menu_repos: bool = True
    menu_ai: bool = True
    menu_backups: bool = True
    menu_settings: bool = False
    menu_upgrade: bool = False
    menu_databases: bool = False
    max_envs: int | None = None
    max_dbs: int | None = None
    tenant_id: int | None = None  # 兼容旧表单
    memberships: list[MembershipIn] | None = None  # 租户角色列表


class UserUpdate(BaseModel):
    display_name: str | None = None
    role: str | None = None
    is_active: bool | None = None
    shell_enabled: bool | None = None
    can_use_enterprise: bool | None = None
    menu_dashboard: bool | None = None
    menu_repos: bool | None = None
    menu_ai: bool | None = None
    menu_backups: bool | None = None
    menu_settings: bool | None = None
    menu_upgrade: bool | None = None
    menu_databases: bool | None = None
    max_envs: int | None = None  # 传 null = 不限
    max_dbs: int | None = None  # 附加数据库配额;传 null = 不限
    tenant_id: int | None = None
    password: str | None = None
    memberships: list[MembershipIn] | None = None  # 传入则整体替换


# ---- 批量用户(超级管理员) ----
class BulkUserRowIn(BaseModel):
    """批量创建里的一行(组织已解析成 tenant_id)。"""

    username: str = Field(min_length=2, max_length=64)
    display_name: str | None = None
    password: str | None = None  # 空 = 服务端生成随机初始密码
    role: str = "member"  # admin | member
    shell_enabled: bool = False
    menu_dashboard: bool = True  # 菜单可见性(批量创建时对整批统一设置)
    menu_repos: bool = True
    menu_ai: bool = True
    menu_backups: bool = True
    menu_settings: bool = False
    menu_upgrade: bool = False
    menu_databases: bool = False
    max_envs: int | None = None
    max_dbs: int | None = None
    memberships: list[MembershipIn] = []


class BulkParseIn(BaseModel):
    text: str  # 粘贴的文本 / CSV(带或不带表头均可)


class BulkRowPreview(BaseModel):
    row: BulkUserRowIn
    membership_labels: list[str] = []  # 人话:["Acme·开发者", ...]
    will_generate_password: bool = False
    errors: list[str] = []  # 非空 = 该行不可创建


class BulkParseOut(BaseModel):
    rows: list[BulkRowPreview]
    ok_count: int
    error_count: int


class BulkCreateIn(BaseModel):
    rows: list[BulkUserRowIn]


class BulkCreatedUser(BaseModel):
    id: int
    username: str
    display_name: str | None = None
    role: str
    password: str  # 明文,仅本次响应回显一次(不落库)
    membership_labels: list[str] = []


class BulkCreateOut(BaseModel):
    created: list[BulkCreatedUser]


class BulkUpdateIn(BaseModel):
    user_ids: list[int]
    # 以下字段「传了才改」;max_* 因为 null 有「不限」含义,用单独的 set_* 开关消除歧义
    role: str | None = None  # admin | member
    is_active: bool | None = None
    shell_enabled: bool | None = None
    menu_dashboard: bool | None = None  # 菜单可见性(传了才改)
    menu_repos: bool | None = None
    menu_ai: bool | None = None
    menu_backups: bool | None = None
    menu_settings: bool | None = None
    menu_upgrade: bool | None = None
    menu_databases: bool | None = None
    set_max_envs: bool = False
    max_envs: int | None = None
    set_max_dbs: bool = False
    max_dbs: int | None = None
    # 批量赋权(组织成员关系):不传 membership_mode 则不动
    membership_mode: str | None = None  # add | remove | replace
    memberships: list[MembershipIn] = []  # add / replace 用
    remove_tenant_ids: list[int] = []  # remove 用


class BulkDeleteIn(BaseModel):
    user_ids: list[int]
    purge_envs: bool = False   # 默认 False:实例进回收站,数据可恢复;True 才连数据一起销毁


class BulkResultRow(BaseModel):
    user_id: int
    username: str
    status: str  # success | failed | skipped
    message: str | None = None


class BulkUpdateOut(BaseModel):
    results: list[BulkResultRow]
    succeeded: int
    failed: int
    skipped: int


# ---- tenants ----
class TenantOut(ORM):
    id: int
    slug: str
    name: str
    description: str | None
    is_active: bool
    sleep_idle_hours: float | None = None  # 组织级开发实例闲置休眠默认(小时);None = 平台默认,0 = 不休眠
    max_dbs_per_env: int | None = None  # 附加库配额:每实例上限(None = 平台默认 db.max_extra_per_env)
    max_dbs_total: int | None = None  # 附加库配额:组织总量(None = 不限)
    created_at: datetime


class TenantCreate(BaseModel):
    slug: str = Field(min_length=2, max_length=64)
    name: str
    description: str | None = None
    # 可选:一步到位指定首任租户管理员(已有用户名,或新用户名 + 密码)
    owner_username: str | None = None
    owner_password: str | None = None
    owner_display_name: str | None = None

    @field_validator("slug", mode="before")
    @classmethod
    def _norm_slug(cls, v):
        """组织标识会拼进容器名(odoo-<组织>-<实例>)、Docker 网络和访问域名,必须是小写 ASCII。"""
        return norm_slug(v, "组织标识")


class TenantUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    is_active: bool | None = None
    sleep_idle_hours: float | None = None  # 组织管理员可设
    max_dbs_per_env: int | None = None  # 仅超管可设(配额)
    max_dbs_total: int | None = None


# ---- environments ----
class EnvironmentOut(ORM):
    id: int
    tenant_id: int
    name: str
    kind: str
    odoo_version: str
    base_mode: str = "official"
    edition: str = "community"
    lang: str | None = "zh_CN"  # 主库初始语言
    enterprise_commit: str | None = None
    enterprise_repo_id: int | None = None
    code_commit: str | None = None
    deploy_action: str = "update_all"
    deploy_modules: str | None = None
    auto_deploy: bool = True
    branch: str | None
    repo_url: str | None
    domain: str | None
    status: str
    status_message: str | None = None
    progress: int = 0
    expires_at: datetime | None = None
    mem_mb: int | None = None
    cpus: float | None = None
    sleep_idle_hours: float | None = None  # 开发实例闲置休眠阈值(小时);None = 全局默认,0 = 不休眠
    log_level: str | None = None  # Odoo 日志等级;None = 全局默认(odoo.log_level)
    max_dbs: int | None = None  # 附加库上限(None = 组织 / 平台默认)
    extra_conf: str | None = None  # odoo.conf 附加项(白名单内);重启生效
    extra_db_count: int = 0  # 附加库数量(列表 / 详情接口填充)
    last_active_at: datetime | None = None
    project_id: int | None = None  # 从别的实例详情页派生时指向根实例;None = 自身是项目根
    image_tag: str | None = None
    container_name: str | None = None
    db_name: str | None = None
    url: str | None = None
    created_at: datetime
    # 访问控制 / 回收站
    owner_user_id: int | None = None
    deleted_at: datetime | None = None
    my_role: str | None = None  # 当前用户在该实例上的有效角色(owner/developer/tester),前端据此显隐按钮


class EnvironmentDetail(EnvironmentOut):
    log: str | None = None
    admin_password: str | None = None


class EnvironmentCreate(BaseModel):
    tenant_id: int
    name: str = Field(min_length=1, max_length=64)
    kind: str = "dev"
    odoo_version: str = "18"
    base_mode: str = "official"
    edition: str = "community"
    lang: str | None = "zh_CN"  # 主库初始语言(Odoo 语言代码,如 zh_CN / en_US)
    branch: str | None = None
    repo_url: str | None = None
    domain: str | None = None
    # 过期天数:None = 使用全局默认;0 = 永不过期
    expire_days: int | None = None
    sleep_idle_hours: float | None = None  # 开发实例闲置休眠(小时);None = 组织/平台默认
    acl: list["EnvAclIn"] | None = None  # 初始授权名单(可选);创建者自动成为拥有者

    @field_validator("name", mode="before")
    @classmethod
    def _norm_name(cls, v):
        """实例名用于容器 / 数据库 / 域名:自动转小写、去首尾空白;其余非法字符给出中文提示。"""
        if not isinstance(v, str):
            return v
        return norm_slug(v, "实例名")

    @field_validator("domain", mode="before")
    @classmethod
    def _v_domain(cls, v):
        return _norm_domain(v)

    @field_validator("odoo_version", mode="before")
    @classmethod
    def _v_ver(cls, v):
        return _v_version(v)

    @field_validator("base_mode", mode="before")
    @classmethod
    def _v_mode(cls, v):
        return _v_enum(v, ("official", "custom"), "基础镜像模式")

    @field_validator("edition", mode="before")
    @classmethod
    def _v_edition(cls, v):
        return _v_enum(v, ("community", "enterprise"), "版本类型")

    @field_validator("kind", mode="before")
    @classmethod
    def _v_kind(cls, v):
        return _v_enum(v, ("production", "staging", "dev"), "实例类型")


class EnvAclIn(BaseModel):
    user_id: int
    level: str = "view"  # view | operate | manage

    @field_validator("level")
    @classmethod
    def _v_level(cls, v):
        if v not in ("view", "operate", "manage"):
            raise ValueError("无效的授权级别")
        return v


class EnvAclOut(BaseModel):
    user_id: int
    username: str
    display_name: str | None = None
    level: str
    is_owner: bool = False


class EnvAclState(BaseModel):
    owner_user_id: int | None = None
    owner_username: str | None = None
    entries: list[EnvAclOut] = []
    candidates: list[EnvAclOut] = []  # 可加入名单的组织成员(含已在名单里的,level 为当前级别或空)


EnvironmentCreate.model_rebuild()


class EnvironmentUpdate(BaseModel):
    kind: str | None = None
    odoo_version: str | None = None
    base_mode: str | None = None
    edition: str | None = None
    lang: str | None = None  # 仅在实例尚未创建数据库前有意义
    deploy_action: str | None = None
    deploy_modules: str | None = None
    auto_deploy: bool | None = None
    expire_days: int | None = None  # 传 0 = 永不;传 N = 从现在起 N 天后过期
    branch: str | None = None
    repo_url: str | None = None
    domain: str | None = None
    mem_mb: int | None = None  # 每实例资源上限;0/None = 全局默认
    cpus: float | None = None
    sleep_idle_hours: float | None = None  # 开发实例闲置休眠(小时);None = 全局默认;0 = 不休眠
    log_level: str | None = None  # Odoo 日志等级 debug/info/warn/error;None/'' = 全局默认;重启生效
    max_dbs: int | None = None  # 附加库上限;None = 组织 / 平台默认(超管 / 组织管理员可改)
    extra_conf: str | None = None  # odoo.conf 附加项;普通用户仅白名单键,超管任意非黑名单键;''/None = 清空

    @field_validator("domain", mode="before")
    @classmethod
    def _v_domain(cls, v):
        return _norm_domain(v)

    @field_validator("odoo_version", mode="before")
    @classmethod
    def _v_ver(cls, v):
        return _v_version(v)

    @field_validator("base_mode", mode="before")
    @classmethod
    def _v_mode(cls, v):
        return _v_enum(v, ("official", "custom"), "基础镜像模式")

    @field_validator("edition", mode="before")
    @classmethod
    def _v_edition(cls, v):
        return _v_enum(v, ("community", "enterprise"), "版本类型")

    @field_validator("kind", mode="before")
    @classmethod
    def _v_kind(cls, v):
        return _v_enum(v, ("production", "staging", "dev"), "实例类型")

    @field_validator("deploy_modules", mode="before")
    @classmethod
    def _v_mods(cls, v):
        return _v_modules(v)


# ---- deployments ----
class DeployIn(BaseModel):
    commit: str | None = None  # None = 分支最新
    action: str | None = None  # restart | update | update_all;None = 实例默认
    modules: str | None = None
    databases: list[str] | None = None  # -u 作用的库名列表(主库 + 附加库);None = 全部

    @field_validator("modules", mode="before")
    @classmethod
    def _v_mods(cls, v):
        return _v_modules(v)

    @field_validator("commit", mode="before")
    @classmethod
    def _v_commit(cls, v):
        if v is None or (isinstance(v, str) and not v.strip()):
            return None
        if not isinstance(v, str) or not re.fullmatch(r"[0-9a-fA-F]{7,64}", v.strip()):
            raise ValueError("commit 须为 7~64 位十六进制")
        return v.strip()


class DeploymentOut(ORM):
    id: int
    environment_id: int
    branch: str | None
    commit_sha: str | None
    commit_message: str | None
    author: str | None
    committed_at: datetime | None
    trigger: str
    action: str
    modules: str | None
    databases: str | None = None  # 本次 -u 作用的库(逗号分隔);None = 全部
    db_results: str | None = None  # JSON {库名: success|failed|skipped}
    status: str
    message: str | None
    created_by: str | None
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    duration: float | None = None


class DeploymentDetail(DeploymentOut):
    log: str | None = None


# ---- settings ----
class SettingsOut(BaseModel):
    values: dict[str, str | None]


class SettingsIn(BaseModel):
    values: dict[str, str | None]


# ---- 定制代码在线编辑(无 Git 实例) ----
class CodeWriteIn(BaseModel):
    content: str = ""
    # 读文件时拿到的 mtime,原样带回来做乐观并发校验;不传 = 不校验(强制覆盖)
    mtime: float | None = None


class CodeEntryIn(BaseModel):
    path: str
    kind: str = "file"  # file | dir

    @field_validator("kind")
    @classmethod
    def _kind(cls, v):
        if v not in ("file", "dir"):
            raise ValueError("kind 只能是 file 或 dir")
        return v


class CodeRenameIn(BaseModel):
    path: str
    new_path: str


class CodeScaffoldIn(BaseModel):
    name: str
    label: str = ""
    author: str = ""
