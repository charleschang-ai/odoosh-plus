"""在线代码编辑的审计。

Shell 有 shell_sessions 记录谁开过终端、生产还录输入;代码编辑此前什么都不留 ——
教学场景要判分、查抄袭、追「谁把这个模块删了」,没有依据。
一条记录 = 一次写入类动作(读不记,否则量太大且没用)。
"""

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


class CodeEdit(Base):
    __tablename__ = "code_edits"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    environment_id: Mapped[int | None] = mapped_column(ForeignKey("environments.id", ondelete="SET NULL"), nullable=True, index=True)
    tenant_id: Mapped[int] = mapped_column(Integer, index=True)
    env_name: Mapped[str] = mapped_column(String(64))  # 快照:实例被删后记录仍可读
    user_id: Mapped[int | None] = mapped_column(Integer, index=True)
    username: Mapped[str | None] = mapped_column(String(64))
    # write | create | delete | rename | upload_file | upload_zip | scaffold | update_modules | restore
    action: Mapped[str] = mapped_column(String(24), index=True)
    path: Mapped[str | None] = mapped_column(String(512))
    detail: Mapped[str | None] = mapped_column(String(512))  # 新路径 / 模块名 / 版本号等
    size: Mapped[int | None] = mapped_column(Integer)        # 写入字节数(可判断改动量)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)
