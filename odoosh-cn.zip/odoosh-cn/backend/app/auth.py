from datetime import datetime, timedelta, timezone

import bcrypt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from sqlalchemy.orm import Session

from .config import settings
from .db import get_db
from .models import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()


def verify_password(pw: str, pw_hash: str) -> bool:
    try:
        return bcrypt.checkpw(pw.encode(), pw_hash.encode())
    except ValueError:
        return False


def create_token(user: User) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=settings.token_expire_minutes)
    payload = {"sub": str(user.id), "username": user.username, "role": user.role, "exp": exp,
               "tv": int(user.token_version or 0), "typ": "access"}
    return jwt.encode(payload, settings.secret_key, algorithm="HS256")


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    cred_exc = HTTPException(status.HTTP_401_UNAUTHORIZED, "登录已失效,请重新登录")
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
        # 只接受登录令牌:平台内其它 JWT(OAuth state、SSO / Shell / 下载票据)与本令牌同密钥同算法,
        # 必须靠 typ 显式区分,否则 OAuth state(sub 恰好是 user_id)可被当作 Bearer 令牌使用。
        if payload.get("typ") != "access" or "k" in payload:
            raise cred_exc
        if "tv" not in payload:  # tv 不给默认值:缺失即视为非法(旧令牌需重新登录)
            raise cred_exc
        user_id = int(payload.get("sub"))
        tv = int(payload["tv"])
    except (JWTError, TypeError, ValueError):
        raise cred_exc
    user = db.get(User, user_id)
    if not user or not user.is_active or tv != int(user.token_version or 0):
        raise cred_exc  # 改密 / 停用后旧令牌失效
    return user


def revoke_tokens(user: User) -> None:
    """使该用户所有已签发的 JWT 失效(改密、停用、管理员重置密码时调用;调用方负责 commit)。"""
    user.token_version = int(user.token_version or 0) + 1


def user_from_token(token: str, db: Session) -> User:
    """给不能带 Authorization 头的场景(EventSource / WebSocket)用:从查询参数里的 JWT 解析用户。"""
    return get_current_user(token=token, db=db)


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "需要平台管理员权限")
    return user
