#!/usr/bin/env bash
# 给平台控制台签发「公网 IP」的免费 HTTPS 证书(Let's Encrypt IP 证书,shortlived 配置,有效期约 6.6 天)。
# 用 acme.sh 的 HTTP 文件验证 + 内置 cron 自动续期(约每 3 天换新证书并自动 reload nginx),装好后无需人工维护。
#
# 用法:  sudo bash deploy/ssl-ip.sh --email you@example.com [--ip 1.2.3.4] [--domain a.example.com]...
#   --email   Let's Encrypt 账号邮箱(仅用于到期提醒,不会验证;不能用 example.com)
#   --ip      服务器公网 IP,不传则自动探测
#   --domain  额外写进同一张证书的域名(可重复)。适用于 DNS 服务商不支持泛解析、
#             但想让控制台走域名 HTTPS 的场景:一张证书的 SAN 同时覆盖 IP 与这些域名,
#             两者都用 HTTP-01 验证,不需要泛解析、不需要 DNS 服务商 API 凭据。
#             不传则沿用上次的列表(记在 certs/.extra_domains);传 --domain '' 清空。
#             注意:只适合控制台等固定域名。**不要**把各 Odoo 实例的域名加进来 ——
#             实例的 server 块会吞掉 /.well-known 请求,导致下次续期验证失败。
#
# 前提:80 端口必须对全网开放(CA 通过 http://IP/.well-known/acme-challenge/ 验证,来源 IP 不固定,
#       安全组不能只放行自己 IP)。443 也需在安全组放行。
# 说明:此证书覆盖 https://IP 的平台控制台,以及 --domain 传入的固定域名;
#       各 Odoo 实例的子域名不在覆盖范围(实例 HTTPS 见 deploy/ssl-domain.sh 或端口直连模式)。
#       域名 + 泛域名证书就绪后,替换 $DATA_DIR/certs/console.crt/.key 并扩展 server_name 即可复用本管线。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"
COMPOSE=(docker compose -f "$SCRIPT_DIR/docker-compose.yml" --env-file "$ENV_FILE")

info() { echo -e "\033[1;34m[odoosh-ssl]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[   ok   ]\033[0m $*"; }
warn() { echo -e "\033[1;33m[  warn  ]\033[0m $*"; }
die()  { echo -e "\033[1;31m[  fail  ]\033[0m $*"; exit 1; }

EMAIL=""
IP=""
DOMAINS=()
DOMAINS_SET=0   # 区分「没传 --domain」与「传了空值表示清空」
while [[ $# -gt 0 ]]; do
  case "$1" in
    --email) EMAIL="$2"; shift 2 ;;
    --ip) IP="$2"; shift 2 ;;
    --domain) DOMAINS_SET=1; [[ -n "$2" ]] && DOMAINS+=("$2"); shift 2 ;;
    -h|--help) sed -n '2,19p' "$0"; exit 0 ;;
    *) die "未知参数: $1(--help 查看用法)" ;;
  esac
done

[[ $EUID -eq 0 ]] || die "请用 root(或 sudo)运行"
[[ -f "$ENV_FILE" ]] || die "找不到 $ENV_FILE,请先完成平台安装(deploy/install.sh)"
DATA_DIR=$(grep -E '^ODOOSH_DATA_DIR=' "$ENV_FILE" | cut -d= -f2-)
HTTP_PORT=$(grep -E '^ODOOSH_HTTP_PORT=' "$ENV_FILE" | cut -d= -f2-)
[[ -n "$DATA_DIR" ]] || die ".env 里没有 ODOOSH_DATA_DIR"
HTTP_PORT="${HTTP_PORT:-80}"
[[ "$HTTP_PORT" == "80" ]] || warn "平台 HTTP 端口是 $HTTP_PORT(非 80):Let's Encrypt 只验证 80 端口,需自行保证 80 → 平台 web 的转发,否则验证会失败"

CERTS_DIR="$DATA_DIR/certs"
mkdir -p "$CERTS_DIR/webroot/.well-known/acme-challenge"

# ---------- 1. 邮箱 ----------
ACME_HOME="$HOME/.acme.sh"
if [[ -z "$EMAIL" ]]; then
  [[ -f "$CERTS_DIR/.email" ]] && EMAIL=$(cat "$CERTS_DIR/.email")
  [[ -n "$EMAIL" ]] || die "首次运行需要 --email 你的邮箱(仅用于证书到期提醒)"
fi
[[ "$EMAIL" == *@* && "$EMAIL" != *example.com ]] || die "邮箱格式不对(Let's Encrypt 拒绝 example.com)"
echo "$EMAIL" >"$CERTS_DIR/.email"

# ---------- 2. 公网 IP ----------
if [[ -z "$IP" ]]; then
  IP=$(curl -fsS -m 5 https://api.ipify.org 2>/dev/null || true)
  [[ -n "$IP" ]] || IP=$(curl -fsS -m 5 https://myip.ipip.net 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | head -1 || true)
  [[ -n "$IP" ]] || die "自动探测公网 IP 失败,请用 --ip 指定"
fi
[[ "$IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "不是合法的 IPv4 地址: $IP"

# ---------- 2b. 额外域名 ----------
# 没显式传 --domain 就沿用上次:续期由 acme.sh 按首签时的域名列表跑,
# 这里保持一致,免得重跑本脚本反而把域名从证书里摘掉、控制台 HTTPS 突然报错。
EXTRA_FILE="$CERTS_DIR/.extra_domains"
if [[ $DOMAINS_SET -eq 0 && -s "$EXTRA_FILE" ]]; then
  while IFS= read -r line; do [[ -n "$line" ]] && DOMAINS+=("$line"); done <"$EXTRA_FILE"
fi
for d in ${DOMAINS[@]+"${DOMAINS[@]}"}; do
  [[ "$d" =~ ^[a-zA-Z0-9.-]+$ && "$d" == *.* ]] || die "域名格式不对: $d"
  # HTTP-01 时 CA 会去 http://<域名>/.well-known/... 取文件,解析不到或指向别的机器必然失败,
  # 且会消耗 Let's Encrypt 的失败次数配额,所以先自检一次。
  got=$(getent hosts "$d" 2>/dev/null | awk '{print $1}' | head -1)
  [[ "$got" == "$IP" ]] || warn "域名 $d 解析到 ${got:-<解析不到>},与本机 $IP 不符 —— HTTP-01 验证多半会失败"
done
if [[ ${#DOMAINS[@]} -gt 0 ]]; then printf '%s\n' "${DOMAINS[@]}" >"$EXTRA_FILE"; else : >"$EXTRA_FILE"; fi

info "目标 IP: $IP    邮箱: $EMAIL${DOMAINS[0]+    额外域名: ${DOMAINS[*]}}"

# ---------- 3. 确保 web 容器是带 443/ACME 支持的新版 ----------
if ! "${COMPOSE[@]}" exec -T web test -f /etc/nginx/console-locations.inc >/dev/null 2>&1; then
  info "web 容器还是旧版(缺少 443/ACME 支持),重新构建并启动(约 1~3 分钟)..."
  "${COMPOSE[@]}" up -d --build web
fi

# 自测 ACME 验证链路:nginx 应能从 webroot 目录吐出文件
TOKEN="selftest-$RANDOM"
echo ok >"$CERTS_DIR/webroot/.well-known/acme-challenge/$TOKEN"
if ! curl -fsS -m 5 "http://127.0.0.1:${HTTP_PORT}/.well-known/acme-challenge/$TOKEN" | grep -q ok; then
  rm -f "$CERTS_DIR/webroot/.well-known/acme-challenge/$TOKEN"
  die "ACME 验证链路自测失败:nginx 未能读到 webroot 文件。请确认已 git pull 最新代码并执行过 ${COMPOSE[*]} up -d --build web"
fi
rm -f "$CERTS_DIR/webroot/.well-known/acme-challenge/$TOKEN"
ok "ACME 验证链路自测通过"

# ---------- 4. 安装 acme.sh(gitee 优先,github 兜底) ----------
if [[ ! -x "$ACME_HOME/acme.sh" ]]; then
  info "安装 acme.sh ..."
  TMP=$(mktemp -d)
  git clone --depth 1 https://gitee.com/neilpang/acme.sh.git "$TMP/acme.sh" 2>/dev/null \
    || git clone --depth 1 https://github.com/acmesh-official/acme.sh.git "$TMP/acme.sh" \
    || die "下载 acme.sh 失败(gitee/github 都拉不动)"
  (cd "$TMP/acme.sh" && ./acme.sh --install -m "$EMAIL" >/dev/null)
  rm -rf "$TMP"
  ok "acme.sh 安装完成(含每日自动续期 cron)"
fi
ACME=("$ACME_HOME/acme.sh")
"${ACME[@]}" --register-account -m "$EMAIL" --server letsencrypt >/dev/null 2>&1 || true

# ---------- 5. 签发(已有未到期证书时 acme.sh 会跳过,幂等) ----------
info "向 Let's Encrypt 申请证书(shortlived,约 6.6 天有效,cron 每日检查、到 3 天龄自动续期)..."
D_ARGS=(-d "$IP")
for d in ${DOMAINS[@]+"${DOMAINS[@]}"}; do D_ARGS+=(-d "$d"); done
# SAN 里含 IP 时整张证书必须走 shortlived profile,域名部分也跟着变 6.6 天 —— CA 的规定,不是缺陷。
# 域名列表变了(如新加 --domain)但旧证书未到期时 acme.sh 会跳过,必须 --force 才重签;
# 只在「现有证书确实缺了目标域名」时才 force,避免每次运行都无谓重签、撞签发频率限制。
FORCE=()
for d in ${DOMAINS[@]+"${DOMAINS[@]}"}; do
  san=$(openssl x509 -in "$CERTS_DIR/console.crt" -noout -ext subjectAltName 2>/dev/null || true)
  grep -qE "DNS:$d([,[:space:]]|$)" <<<"$san" || { FORCE=(--force); info "现有证书里没有 $d,本次强制重签"; break; }
done
set +e
"${ACME[@]}" --issue --server letsencrypt --cert-profile shortlived --days 3 \
  ${FORCE[@]+"${FORCE[@]}"} "${D_ARGS[@]}" --webroot "$CERTS_DIR/webroot"
RC=$?
set -e
if [[ $RC -ne 0 && $RC -ne 2 ]]; then   # 2 = 未到期跳过
  die "签发失败(退出码 $RC)。最常见原因:
  1) 80 端口未对全网开放(安全组/防火墙),Let's Encrypt 访问不到 http://$IP/.well-known/acme-challenge/
  2) --domain 指定的域名没解析到 $IP(上面的自检会给出 warn)"
fi

# ---------- 6. 安装证书到平台目录 + 注册续期后的自动部署(复制 + reload nginx) ----------
RELOAD_CMD="docker compose -f $SCRIPT_DIR/docker-compose.yml --env-file $ENV_FILE exec -T web nginx -s reload"
"${ACME[@]}" --install-cert -d "$IP" \
  --fullchain-file "$CERTS_DIR/console.crt" \
  --key-file "$CERTS_DIR/console.key" \
  --reloadcmd "$RELOAD_CMD"
chmod 600 "$CERTS_DIR/console.key"

# ---------- 7. 生成 443 server 配置并加载(证书文件已就位后才写,避免 nginx -t 失败) ----------
CONF="$DATA_DIR/nginx/console-ssl.conf"
cat >"$CONF" <<'EOF'
# 平台控制台 HTTPS(deploy/ssl-ip.sh 生成;证书由 acme.sh 自动续期并 reload)
server {
    listen 443 ssl default_server;
    http2 on;
    server_name _;
    ssl_certificate     /etc/nginx/certs/console.crt;
    ssl_certificate_key /etc/nginx/certs/console.key;
    include /etc/nginx/console-locations.inc;
}
EOF
"${COMPOSE[@]}" exec -T web sh -c 'nginx -t && nginx -s reload' || die "nginx 配置校验失败,请查看 ${COMPOSE[*]} logs web"

echo
ok "HTTPS 已就绪:"
echo "    控制台:   https://$IP"
for d in ${DOMAINS[@]+"${DOMAINS[@]}"}; do echo "              https://$d"; done
echo "    证书:     $CERTS_DIR/console.crt(约 6.6 天有效,acme.sh cron 每日检查、自动续期 + reload,无需人工干预)"
echo "    查看续期: $ACME_HOME/acme.sh --list"
echo "    注意:     80 端口须始终对全网开放(续期验证用);安全组记得放行 443"
echo "    覆盖范围: 仅平台控制台 https://$IP;各 Odoo 实例子域名仍走 HTTP,等域名 + 泛域名证书后全覆盖"
