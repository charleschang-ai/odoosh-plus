#!/usr/bin/env bash
# 给平台控制台 + 所有 Odoo 实例签发「泛域名」HTTPS 证书(Let's Encrypt,90 天,acme.sh 自动续期)。
#
# 一张 *.<域名> 覆盖全部实例:实例域名是扁平的 <实例>-<组织>.<域名>(只占一级子域),
# 所以新建实例无需任何证书操作,加多少个实例都是这一张证书。
#
# 用法:  sudo bash deploy/ssl-domain.sh --domain sh.example.com --email you@example.com --dns dns_ali
#   --domain  基础域名(必须与系统设置里的「基础域名」一致)
#   --email   Let's Encrypt 账号邮箱(仅用于到期提醒;不能用 example.com)
#   --dns     acme.sh 的 DNS 插件:dns_ali(阿里云)/ dns_dp(DNSPod)/ dns_cf(Cloudflare)/ dns_gd(GoDaddy)…
#
# 为什么必须用 DNS 验证:Let's Encrypt 规定泛域名证书只能走 DNS-01,HTTP 文件验证签不出 *.域名。
# 好处是不依赖 80 端口(未备案 / 80 被拦时照样能签发和续期)。
#
# 前提:先在 DNS 服务商配好泛解析 *.<域名> → 服务器 IP,并导出该服务商的 API 凭据,例如阿里云:
#   export Ali_Key="xxx"; export Ali_Secret="yyy"
#   (凭据会被 acme.sh 保存到 ~/.acme.sh/account.conf 供后续自动续期使用;请用权限最小的子账号)
#
# 与 ssl-ip.sh 的关系:ssl-ip.sh 签的是「公网 IP」的短期证书,只保护控制台。
# 本脚本签域名泛证书,同时保护控制台与全部实例;两者用不同的证书文件,可以只留本脚本。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"
COMPOSE=(docker compose -f "$SCRIPT_DIR/docker-compose.yml" --env-file "$ENV_FILE")

info() { echo -e "\033[1;34m[odoosh-ssl]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[   ok   ]\033[0m $*"; }
warn() { echo -e "\033[1;33m[  warn  ]\033[0m $*"; }
die()  { echo -e "\033[1;31m[  fail  ]\033[0m $*"; exit 1; }

DOMAIN=""; EMAIL=""; DNS_PLUGIN=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --domain) DOMAIN="$2"; shift 2 ;;
    --email)  EMAIL="$2";  shift 2 ;;
    --dns)    DNS_PLUGIN="$2"; shift 2 ;;
    -h|--help) sed -n '2,25p' "$0"; exit 0 ;;
    *) die "未知参数: $1(--help 查看用法)" ;;
  esac
done

[[ $EUID -eq 0 ]] || die "请用 root(或 sudo)运行"
[[ -f "$ENV_FILE" ]] || die "找不到 $ENV_FILE,请先完成平台安装(deploy/install.sh)"
DATA_DIR=$(grep -E '^ODOOSH_DATA_DIR=' "$ENV_FILE" | cut -d= -f2-)
[[ -n "$DATA_DIR" ]] || die ".env 里没有 ODOOSH_DATA_DIR"
CERTS_DIR="$DATA_DIR/certs"
mkdir -p "$CERTS_DIR"

[[ -n "$DOMAIN" ]] || die "必须指定 --domain(基础域名,如 sh.example.com)"
[[ "$DOMAIN" =~ ^[a-zA-Z0-9.-]+$ && "$DOMAIN" == *.* ]] || die "域名格式不对: $DOMAIN"
[[ -n "$DNS_PLUGIN" ]] || die "必须指定 --dns(如 dns_ali / dns_dp / dns_cf);泛域名证书只能用 DNS 验证"
ACME_HOME="$HOME/.acme.sh"
if [[ -z "$EMAIL" ]]; then
  [[ -f "$CERTS_DIR/.email" ]] && EMAIL=$(cat "$CERTS_DIR/.email")
  [[ -n "$EMAIL" ]] || die "首次运行需要 --email 你的邮箱(仅用于证书到期提醒)"
fi
[[ "$EMAIL" == *@* && "$EMAIL" != *example.com ]] || die "邮箱格式不对(Let's Encrypt 拒绝 example.com)"
echo "$EMAIL" >"$CERTS_DIR/.email"
info "域名: $DOMAIN(含泛域名 *.$DOMAIN)  邮箱: $EMAIL  DNS 插件: $DNS_PLUGIN"

# ---------- 1. 泛解析自检:*.域名 必须已经指向本机 ----------
# 解析不了就先别签(签发会失败,且会消耗 Let's Encrypt 的失败次数配额)
PROBE="acme-probe-$RANDOM.$DOMAIN"
if command -v getent >/dev/null 2>&1 && ! getent hosts "$PROBE" >/dev/null 2>&1; then
  warn "泛解析自检未通过:$PROBE 解析不到。"
  warn "请确认已在 DNS 服务商添加 *.$DOMAIN → 服务器 IP 的 A 记录(DNS 生效可能要几分钟)。"
  read -r -p "仍要继续签发吗?(y/N) " yn
  [[ "$yn" == "y" || "$yn" == "Y" ]] || exit 1
else
  ok "泛解析自检通过"
fi

# ---------- 2. 安装 acme.sh(gitee 优先,github 兜底) ----------
if [[ ! -x "$ACME_HOME/acme.sh" ]]; then
  info "安装 acme.sh ..."
  TMP=$(mktemp -d)
  git clone --depth 1 https://gitee.com/neilpang/acme.sh.git "$TMP/acme.sh" 2>/dev/null \
    || git clone --depth 1 https://github.com/acmesh-official/acme.sh.git "$TMP/acme.sh" \
    || die "下载 acme.sh 失败(gitee/github 都拉不动)"
  (cd "$TMP/acme.sh" && ./acme.sh --install -m "$EMAIL" >/dev/null)
  rm -rf "$TMP"
  ok "acme.sh 安装完成(含每日自动续期 cron)"
fi
ACME=("$ACME_HOME/acme.sh")
"${ACME[@]}" --register-account -m "$EMAIL" --server letsencrypt >/dev/null 2>&1 || true

# ---------- 3. 签发泛域名证书(已有未到期证书时 acme.sh 会跳过,幂等) ----------
info "向 Let's Encrypt 申请泛域名证书(DNS-01 验证,90 天有效,cron 每日检查、到期前自动续期)..."
set +e
"${ACME[@]}" --issue --server letsencrypt --dns "$DNS_PLUGIN" \
  -d "$DOMAIN" -d "*.$DOMAIN"
RC=$?
set -e
if [[ $RC -ne 0 && $RC -ne 2 ]]; then   # 2 = 未到期跳过
  echo
  die "签发失败(退出码 $RC)。常见原因:
  1) DNS 服务商 API 凭据没导出或没权限(如阿里云需 export Ali_Key / Ali_Secret)
  2) --dns 插件名不对(阿里云 dns_ali / DNSPod dns_dp / Cloudflare dns_cf)
  3) 域名不在该 DNS 服务商托管
  查看详细日志:$ACME_HOME/acme.sh --issue ... --debug 2"
fi

# ---------- 4. 安装证书 + 注册续期后自动部署(复制 + reload nginx) ----------
# 文件名固定 wildcard.crt/.key:平台(services/nginx.py)据此判断能否给实例配 443
RELOAD_CMD="docker compose -f $SCRIPT_DIR/docker-compose.yml --env-file $ENV_FILE exec -T web nginx -s reload"
"${ACME[@]}" --install-cert -d "$DOMAIN" \
  --fullchain-file "$CERTS_DIR/wildcard.crt" \
  --key-file "$CERTS_DIR/wildcard.key" \
  --reloadcmd "$RELOAD_CMD"
chmod 600 "$CERTS_DIR/wildcard.key"
ok "证书已安装到 $CERTS_DIR/wildcard.crt"

# ---------- 5. 控制台 443:用同一张泛证书,并收窄 server_name ----------
# 原先 ssl-ip.sh 生成的是 default_server + server_name _,会把「实例域名的 HTTPS 请求」也吞掉
# (浏览器看到控制台的证书 → 域名不匹配告警,内容也不是那个实例)。这里明确只认控制台域名,
# 另留一个 default_server 兜底:未知域名直接断开,不再错误地落到控制台。
CONF="$DATA_DIR/nginx/console-ssl.conf"
cat >"$CONF" <<EOF
# 平台控制台 HTTPS(deploy/ssl-domain.sh 生成;证书由 acme.sh 自动续期并 reload)
server {
    listen 443 ssl;
    http2 on;
    server_name $DOMAIN;
    ssl_certificate     /etc/nginx/certs/wildcard.crt;
    ssl_certificate_key /etc/nginx/certs/wildcard.key;
    include /etc/nginx/console-locations.inc;
}
# 未知域名兜底:不匹配任何实例 / 控制台时直接关闭连接
server {
    listen 443 ssl default_server;
    server_name _;
    ssl_certificate     /etc/nginx/certs/wildcard.crt;
    ssl_certificate_key /etc/nginx/certs/wildcard.key;
    return 444;
}
EOF

# ---------- 6. 让实例配置带上 443:重新生成全部实例的 nginx 配置 ----------
# 平台在证书文件存在时才会给实例写 ssl_certificate(否则 nginx -t 会失败、拖垮所有实例路由),
# 所以证书就位后要触发一次重生成。这里直接调平台内部函数,避免依赖登录态。
info "重新生成全部实例的 nginx 配置(让实例监听 443)..."
"${COMPOSE[@]}" exec -T api python -c "
from app.services import nginx
print('tls_ready =', nginx.tls_ready())
print('regenerated', nginx.regenerate_all(), 'envs')
print('reload', nginx.reload())
" || warn "自动重生成失败:请在平台「系统设置」里随便保存一次,或重启 api 容器触发"

"${COMPOSE[@]}" exec -T web sh -c 'nginx -t && nginx -s reload' || die "nginx 配置校验失败,请查看 ${COMPOSE[*]} logs web"

echo
ok "HTTPS 已就绪:控制台 https://$DOMAIN,所有实例 https://<实例>-<组织>.$DOMAIN"
echo "    证书:     $CERTS_DIR/wildcard.crt(90 天有效,acme.sh cron 自动续期 + reload)"
echo "    覆盖范围: $DOMAIN 与 *.$DOMAIN —— 一张证书覆盖全部实例,新建实例无需任何证书操作"
echo "    注意:     附加数据库的子域名(<库>.<实例>-<组织>.$DOMAIN)比实例深一级,泛证书覆盖不到,只能走 HTTP"
echo
info "请立刻确认自动续期任务已注册(这一步别跳过):"
echo "    $ACME_HOME/acme.sh --list        # 应能看到 $DOMAIN 及其续期时间"
echo "    crontab -l | grep acme           # 应有每日执行的 acme.sh cron"
echo "    平台「系统」页会显示证书剩余天数,少于 20 天会标红"
echo
warn "刻意未做 HTTP → HTTPS 跳转:万一证书过期或续期失败,80 端口仍可访问,不会所有实例同时不可用。"
