#!/usr/bin/env bash
# OdooshCN 卸载脚本
# 用法:  bash deploy/uninstall.sh              # 停止并删除平台容器 + 所有租户实例容器/网络,保留数据目录
#        bash deploy/uninstall.sh --purge      # 同时删除数据目录(平台库、备份、租户数据,不可恢复!)
#        bash deploy/uninstall.sh --keep-tenants   # 只停平台,不动租户实例容器(排查平台问题时用)
#        bash deploy/uninstall.sh --yes        # 跳过 --purge 的二次确认(自动化脚本里用)
#
# 说明:平台自己的容器由 docker compose 管理,租户实例容器(odoo-<租户>-<实例>、odoosh-pg-<租户>)
#       是平台通过 Docker API 直接创建的,compose down 管不到 —— 所以这里按 odoosh.* 标签统一清理,
#       否则卸载后会残留一堆容器和网络,--purge 删掉数据目录后它们还挂着已消失的 bind mount。
#       镜像只删平台自建的 odoosh/api、odoosh/web;odoo / postgres / pgvector 一律保留
#       (内网环境删了就拉不回来了,重装还要用)。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"
PURGE=0
KEEP_TENANTS=0
ASSUME_YES=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --purge) PURGE=1; shift ;;
    --keep-tenants) KEEP_TENANTS=1; shift ;;
    --yes|-y) ASSUME_YES=1; shift ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "未知参数: $1(--help 查看用法)"; exit 1 ;;
  esac
done

if [[ $PURGE -eq 1 && $KEEP_TENANTS -eq 1 ]]; then
  echo "--purge 与 --keep-tenants 不能一起用:租户容器还跑着,数据目录被删会让它们挂着已消失的 bind mount。"
  exit 1
fi

info() { echo -e "\033[1;34m[odoosh]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[  ok  ]\033[0m $*"; }
warn() { echo -e "\033[1;33m[ warn ]\033[0m $*"; }
die()  { echo -e "\033[1;31m[ fail ]\033[0m $*"; exit 1; }

command -v docker >/dev/null 2>&1 || die "本机没有 docker,无需卸载(要删数据目录请手工 rm -rf)"
DOCKER="docker"
if ! docker info >/dev/null 2>&1; then
  if sudo docker info >/dev/null 2>&1; then DOCKER="sudo docker"
  else die "Docker 服务未运行(systemctl status docker 查看原因);仅想删数据目录的话请手工 rm -rf"; fi
fi

# 从 .env 读键值:grep 无匹配会返回 1,在 set -euo pipefail 下会让整个脚本静默退出 —— 必须兜底。
# tr -d '\r':.env 被 Windows 编辑器改过会带 CRLF,残留 \r 会让 rm -rf 的目标路径不对。
env_get() { [[ -f "$ENV_FILE" ]] && sed -n "s/^$1=//p" "$ENV_FILE" | head -n1 | tr -d '\r' || true; }
DATA_DIR="$(env_get ODOOSH_DATA_DIR)"
DATA_DIR="${DATA_DIR:-/var/lib/odoosh}"

# ---------- 1. 租户实例:容器 + 网络(平台用 Docker API 建的,compose 管不到) ----------
if [[ $KEEP_TENANTS -eq 1 ]]; then
  info "--keep-tenants:保留租户实例容器与网络"
else
  info "清理租户实例容器..."
  # 两路取名字并集:① 平台给实例容器打的 odoosh.tenant 标签(见 orchestrator.py 的 LABEL_PREFIX);
  # ② 命名规则兜底(标签丢失 / 老版本):odoo-<租户>-<实例>、odoosh-pg-<租户>。
  # 用 --format '{{.Names}}' + grep 在客户端锚定,不依赖 docker name 过滤器的正则方言
  # (不同版本对 ^/ 前缀的处理不一致,且无锚定会误伤用户自己名字里带 odoo 的容器)。
  TENANT_NAMES=$(
    { $DOCKER ps -a --filter "label=odoosh.tenant" --format '{{.Names}}' 2>/dev/null || true
      $DOCKER ps -a --format '{{.Names}}' 2>/dev/null | grep -E '^(odoo-|odoosh-pg-)' || true
    } | sort -u
  )
  if [[ -n "$TENANT_NAMES" ]]; then
    echo "$TENANT_NAMES" | sed 's/^/    rm /'
    # shellcheck disable=SC2086
    $DOCKER rm -f $TENANT_NAMES >/dev/null 2>&1 || true
    ok "已删除 $(echo "$TENANT_NAMES" | grep -c .) 个租户容器"
  else
    info "  没有租户实例容器"
  fi
fi

# ---------- 2. 平台容器(compose) ----------
info "停止并删除平台容器..."
if [[ -f "$ENV_FILE" ]]; then
  (cd "$SCRIPT_DIR" && $DOCKER compose --env-file "$ENV_FILE" down --remove-orphans) || true
else
  warn "未找到 $ENV_FILE,按项目名 odoosh 清理"
  (cd "$SCRIPT_DIR" && $DOCKER compose -p odoosh down --remove-orphans) 2>/dev/null || true
  # 没有 .env 时 compose 可能因变量缺失而什么都没做,再按容器名兜一次
  PLAT=$($DOCKER ps -a --format '{{.Names}}' 2>/dev/null | grep -E '^odoosh-(api|web|db)-[0-9]+$' || true)
  if [[ -n "$PLAT" ]]; then
    # shellcheck disable=SC2086
    $DOCKER rm -f $PLAT >/dev/null 2>&1 || true
    ok "已删除平台容器: $(echo "$PLAT" | tr '\n' ' ')"
  fi
fi

# ---------- 3. 实例网络 ----------
if [[ $KEEP_TENANTS -eq 0 ]]; then
  NETS=$($DOCKER network ls --format '{{.Name}}' 2>/dev/null | grep -E '^odoosh-' || true)
  if [[ -n "$NETS" ]]; then
    # shellcheck disable=SC2086
    echo "$NETS" | xargs -r $DOCKER network rm >/dev/null 2>&1 || true
    ok "已删除 $(echo "$NETS" | grep -c . || true) 个实例网络"
  fi
fi

# ---------- 4. 平台自建镜像 ----------
# 只删我们自己 build 的;odoo / postgres / pgvector 保留 —— 内网删了拉不回来,重装还要用
info "删除平台自建镜像(odoo / postgres / pgvector 等公共镜像一律保留)..."
$DOCKER rmi odoosh/api:dev odoosh/web:dev >/dev/null 2>&1 || true

# ---------- 5. 数据目录 ----------
if [[ $PURGE -eq 1 ]]; then
  # 删之前把路径本身校验一遍:.env 被改坏 / 变量为空时,rm -rf 的目标不能是 / 或系统目录
  case "$DATA_DIR" in
    ""|"/"|"/usr"|"/etc"|"/var"|"/var/lib"|"/home"|"/root"|"/opt"|"/data")
      die "拒绝删除数据目录「$DATA_DIR」—— 这个路径看起来不对(.env 里的 ODOOSH_DATA_DIR 可能为空或被改坏)。
    确认无误的话请手工执行: sudo rm -rf <正确的数据目录>" ;;
  esac
  [[ "$DATA_DIR" == /* ]] || die "数据目录不是绝对路径「$DATA_DIR」,拒绝删除"
  [[ -d "$DATA_DIR" ]] || { warn "数据目录 $DATA_DIR 不存在,跳过"; rm -f "$ENV_FILE"; ok "已卸载"; exit 0; }

  echo
  warn "即将永久删除 $DATA_DIR"
  echo "         包含:平台数据库、所有租户实例数据与 filestore、备份、离线资源包"
  echo "         大小:$(du -sh "$DATA_DIR" 2>/dev/null | cut -f1 || echo '?')"
  if [[ $ASSUME_YES -eq 1 ]]; then
    warn "--yes:跳过确认"
  elif [[ -t 0 ]]; then
    read -r -p "确认删除请输入 DELETE(其它任意输入取消): " ans
    [[ "$ans" == "DELETE" ]] || { info "已取消,数据目录保留"; exit 0; }
  else
    die "非交互环境下删除数据目录需要显式加 --yes"
  fi

  if [[ -w "$DATA_DIR" ]]; then rm -rf "$DATA_DIR"; else sudo rm -rf "$DATA_DIR"; fi
  rm -f "$ENV_FILE"
  ok "数据目录与配置已删除"
else
  ok "已卸载(数据目录 $DATA_DIR 与 $ENV_FILE 已保留,重新执行 install.sh 可恢复)"
  echo "    要连数据一起删: bash deploy/uninstall.sh --purge"
fi
