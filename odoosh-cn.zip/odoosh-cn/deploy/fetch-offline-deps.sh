#!/usr/bin/env bash
# OdooshCN 离线依赖预下载 —— 在「有外网」的机器上执行,把内网装不了的东西提前抓下来。
#
# 与 export-offline.sh 的分工:
#   export-offline.sh    导出 Docker 镜像(平台 / PostgreSQL / Odoo / 企业版代码)
#   fetch-offline-deps.sh(本脚本)  下载镜像之外的东西:宿主机 Docker 安装包、pip wheel、npm 依赖
# 两者产出同一个 offline/ 目录结构,可以先后跑、合并成一个资源包。
#
# 产出:
#   <输出目录>/offline/
#     ├── packages/         宿主机 Docker 安装包(*.deb / *.rpm)+ install-docker.sh
#     ├── pip/
#     │   ├── backend/      平台后端 requirements.txt 的 wheel(仅内网需要重新构建平台镜像时用)
#     │   └── instance/     客户 Odoo 模块 requirements.txt 的 wheel(★ 部署实例时会用到)
#     ├── npm/              前端 node_modules.tar.gz(仅内网需要重新构建平台镜像时用)
#     └── images/           --with-build-images 时:构建用基础镜像(python / node / nginx)
#
# 用法:
#   bash deploy/fetch-offline-deps.sh                          # Docker 安装包 + 后端 wheel + npm
#   bash deploy/fetch-offline-deps.sh --os ubuntu:22.04        # 按内网服务器的发行版下 Docker 包(重要!)
#   bash deploy/fetch-offline-deps.sh --instance-req /path/客户模块/requirements.txt
#   bash deploy/fetch-offline-deps.sh --only docker            # 只下 Docker 安装包
#   bash deploy/fetch-offline-deps.sh --with-build-images       # 连构建用基础镜像一起导出
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

OUT_DIR="$PWD/odoosh-offline"
OS_IMAGE=""                 # 空 = 用本机发行版;内网服务器发行版不同时必须显式指定
ONLY=""                     # docker | pip | npm | build-images(逗号分隔);空 = 默认全套
INSTANCE_REQS=()            # 客户模块的 requirements.txt(可多次)
INSTANCE_IMAGE="odoo:19"    # 用哪个镜像的 Python 下载实例依赖(必须与实例实际用的镜像一致)
WITH_BUILD_IMAGES=0
PIP_INDEX="https://pypi.tuna.tsinghua.edu.cn/simple"
NPM_REGISTRY="https://registry.npmmirror.com"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --out) OUT_DIR="$2"; shift 2 ;;
    --os) OS_IMAGE="$2"; shift 2 ;;
    --only) ONLY="$2"; shift 2 ;;
    --instance-req) INSTANCE_REQS+=("$2"); shift 2 ;;
    --instance-image) INSTANCE_IMAGE="$2"; shift 2 ;;
    --with-build-images) WITH_BUILD_IMAGES=1; shift ;;
    --pip-index) PIP_INDEX="$2"; shift 2 ;;
    --npm-registry) NPM_REGISTRY="$2"; shift 2 ;;
    -h|--help) sed -n '2,28p' "$0"; exit 0 ;;
    *) echo "未知参数: $1(--help 查看用法)"; exit 1 ;;
  esac
done

info() { echo -e "\033[1;34m[fetch]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[  ok  ]\033[0m $*"; }
warn() { echo -e "\033[1;33m[ warn ]\033[0m $*"; }
die()  { echo -e "\033[1;31m[ fail ]\033[0m $*"; exit 1; }

want() {  # 该步骤是否要跑
  [[ -z "$ONLY" ]] && return 0
  [[ ",$ONLY," == *",$1,"* ]]
}

command -v docker >/dev/null 2>&1 || die "本机没有 docker(本脚本用容器来保证下载产物与目标环境的架构 / Python 版本一致)"
DOCKER="docker"
docker info >/dev/null 2>&1 || { sudo docker info >/dev/null 2>&1 && DOCKER="sudo docker" || die "Docker 服务未运行"; }

ARCH="$($DOCKER version --format '{{.Server.Arch}}' 2>/dev/null || uname -m)"
info "下载架构: $ARCH(内网服务器架构必须一致)"

OFF="$OUT_DIR/offline"
mkdir -p "$OFF"

# ============================================================ 1. 宿主机 Docker 安装包
if want docker; then
  PKG_DIR="$OFF/packages"
  mkdir -p "$PKG_DIR"

  if [[ -z "$OS_IMAGE" ]]; then
    # 没指定就按本机发行版猜;猜错了内网装不上,所以显式提醒
    if [[ -r /etc/os-release ]]; then
      . /etc/os-release
      case "${ID:-}" in
        ubuntu) OS_IMAGE="ubuntu:${VERSION_ID:-22.04}" ;;
        debian) OS_IMAGE="debian:${VERSION_ID:-12}" ;;
        centos|rhel|rocky|almalinux) OS_IMAGE="rockylinux:${VERSION_ID%%.*}" ;;
        *) OS_IMAGE="" ;;
      esac
    fi
    [[ -n "$OS_IMAGE" ]] || die "无法推断发行版,请用 --os 指定内网服务器的系统镜像,如 --os ubuntu:22.04"
    warn "未指定 --os,按本机发行版取 $OS_IMAGE。★ 内网服务器发行版/版本不同的话必须显式指定,否则装不上"
  fi
  info "下载 Docker 安装包(在 $OS_IMAGE 干净容器里解析依赖,保证依赖闭包完整)..."

  case "$OS_IMAGE" in
    ubuntu*|debian*)
      # -d/--download-only 只下载不安装;Dir::Cache::archives 指向挂载出来的目录(apt 要求存在 partial 子目录)
      $DOCKER run --rm -v "$PKG_DIR:/out" "$OS_IMAGE" bash -c '
        set -e
        export DEBIAN_FRONTEND=noninteractive
        mkdir -p /out/partial
        apt-get update -q
        apt-get install -y -q --no-install-recommends ca-certificates curl gnupg
        . /etc/os-release
        install -m 0755 -d /etc/apt/keyrings
        curl -fsSL "https://mirrors.aliyun.com/docker-ce/linux/${ID}/gpg" -o /etc/apt/keyrings/docker.asc
        chmod a+r /etc/apt/keyrings/docker.asc
        echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://mirrors.aliyun.com/docker-ce/linux/${ID} ${VERSION_CODENAME} stable" \
          > /etc/apt/sources.list.d/docker.list
        apt-get update -q
        apt-get install -y -q -d -o Dir::Cache::archives=/out \
          docker-ce docker-ce-cli containerd.io docker-compose-plugin docker-buildx-plugin
        rm -rf /out/partial /out/lock
        chmod -R a+r /out
      ' || die "下载 Docker deb 包失败"
      N=$(find "$PKG_DIR" -maxdepth 1 -name '*.deb' | wc -l)
      ;;
    *)
      $DOCKER run --rm -v "$PKG_DIR:/out" "$OS_IMAGE" bash -c '
        set -e
        (command -v dnf >/dev/null && PM=dnf) || PM=yum
        $PM install -y -q yum-utils
        yum-config-manager --add-repo https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
        $PM download --resolve --destdir=/out \
          docker-ce docker-ce-cli containerd.io docker-compose-plugin docker-buildx-plugin
        chmod -R a+r /out
      ' || die "下载 Docker rpm 包失败"
      N=$(find "$PKG_DIR" -maxdepth 1 -name '*.rpm' | wc -l)
      ;;
  esac

  # 内网侧的兜底手动安装脚本(install.sh 会自动做这件事,这个是给人工排查用的)
  cat >"$PKG_DIR/install-docker.sh" <<'PKGEOF'
#!/usr/bin/env bash
# 从本目录的离线包安装 Docker(deploy/install.sh 会自动调用同样的逻辑,这里供手工执行 / 排查用)
set -euo pipefail
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUDO=""; [[ $EUID -ne 0 ]] && SUDO=sudo
if compgen -G "$D"/*.deb >/dev/null; then
  # dpkg 不解析安装顺序,跑两遍可解决绝大多数依赖先后问题
  $SUDO dpkg -i "$D"/*.deb || $SUDO dpkg -i "$D"/*.deb
elif compgen -G "$D"/*.rpm >/dev/null; then
  $SUDO rpm -Uvh --replacepkgs "$D"/*.rpm
else
  echo "本目录没有 *.deb / *.rpm"; exit 1
fi
$SUDO systemctl enable --now docker
docker --version && docker compose version
PKGEOF
  chmod +x "$PKG_DIR/install-docker.sh"
  ok "Docker 安装包: ${N} 个($(du -sh "$PKG_DIR" | cut -f1),来自 $OS_IMAGE)"
  echo "$OS_IMAGE" >"$PKG_DIR/.source-os"
fi

# ============================================================ 2. pip wheel
# 关键:在**目标运行时镜像内**下载,wheel 的 Python 版本 / ABI / 架构才对得上。
fetch_wheels() {  # $1=镜像  $2=requirements 文件  $3=输出目录  $4=说明
  local img="$1" req="$2" dest="$3" label="$4"
  [[ -f "$req" ]] || { warn "找不到 $req,跳过($label)"; return 0; }
  mkdir -p "$dest"
  info "下载 $label 的 wheel(镜像 $img)..."
  $DOCKER image inspect "$img" >/dev/null 2>&1 || $DOCKER pull "$img" >/dev/null 2>&1 || die "拉取 $img 失败"
  # 用 root 跑(odoo 镜像默认用户无权写 /out);pip 有 wheel 就下 wheel,没有则下源码包
  $DOCKER run --rm -u 0:0 -v "$dest:/out" -v "$req:/req.txt:ro" "$img" \
    sh -c "python3 -m pip download -r /req.txt -d /out --no-cache-dir -i '$PIP_INDEX' && chmod -R a+rX /out" \
    || die "下载 $label 依赖失败(检查 requirements.txt 里的包名 / 版本是否存在)"
  ok "  $label: $(find "$dest" -maxdepth 1 -type f | wc -l) 个包,$(du -sh "$dest" | cut -f1)"
}

if want pip; then
  # 2a. 平台后端(只有内网要重新构建 odoosh/api 镜像才用得上;走"带成品镜像"路线可以不要)
  fetch_wheels "python:3.12-slim" "$REPO_DIR/backend/requirements.txt" "$OFF/pip/backend" "平台后端"

  # 2b. 客户 Odoo 模块的依赖 —— ★ 即使带成品镜像也需要:每次部署平台都会在实例里 pip install
  if [[ ${#INSTANCE_REQS[@]} -gt 0 ]]; then
    for req in "${INSTANCE_REQS[@]}"; do
      fetch_wheels "$INSTANCE_IMAGE" "$(cd "$(dirname "$req")" && pwd)/$(basename "$req")" \
        "$OFF/pip/instance" "客户模块 $(basename "$(dirname "$req")")"
    done
  else
    mkdir -p "$OFF/pip/instance"
    warn "未指定 --instance-req:客户模块的 Python 依赖没有下载。"
    warn "  每次部署平台都会在实例里跑 pip install -r requirements.txt,内网没有 PyPI 会失败并回退部署。"
    warn "  有客户模块仓库的话请加:--instance-req /path/to/repo/requirements.txt --instance-image $INSTANCE_IMAGE"
    warn "  确实没有额外依赖的话,装完在「系统设置」关掉「部署时自动安装依赖」即可。"
  fi
fi

# ============================================================ 3. npm 依赖(前端)
if want npm; then
  NPM_DIR="$OFF/npm"
  mkdir -p "$NPM_DIR"
  info "打包前端 node_modules(在 node:20-alpine 里 npm ci)..."
  $DOCKER run --rm -v "$REPO_DIR/frontend:/src:ro" -v "$NPM_DIR:/out" node:20-alpine sh -c "
    set -e
    cp /src/package.json /src/package-lock.json /tmp/
    cd /tmp && npm config set registry '$NPM_REGISTRY' && npm ci --no-audit --no-fund
    tar -czf /out/node_modules.tar.gz node_modules
    chmod -R a+r /out
  " || die "npm ci 失败"
  ok "  前端依赖: $(du -h "$NPM_DIR/node_modules.tar.gz" | cut -f1)"
fi

# ============================================================ 4. 构建用基础镜像
if want build-images && [[ $WITH_BUILD_IMAGES -eq 1 ]]; then
  IMG_DIR="$OFF/images"
  mkdir -p "$IMG_DIR"
  BUILD_IMAGES=(python:3.12-slim node:20-alpine nginx:1.27-alpine)
  info "导出构建用基础镜像:${BUILD_IMAGES[*]}"
  for img in "${BUILD_IMAGES[@]}"; do
    $DOCKER image inspect "$img" >/dev/null 2>&1 || $DOCKER pull "$img" >/dev/null 2>&1 \
      || { warn "拉取 $img 失败,跳过"; continue; }
  done
  $DOCKER save -o "$IMG_DIR/build-base.tar" "${BUILD_IMAGES[@]}" \
    && ok "  build-base.tar ($(du -h "$IMG_DIR/build-base.tar" | cut -f1))"
  warn "这些镜像只有在内网重新构建平台镜像时才需要;走「带成品镜像」路线可以不导。"
fi

# ============================================================ 汇总
{
  echo "OdooshCN 离线依赖包(fetch-offline-deps.sh 产出)"
  echo "下载时间 : $(date '+%Y-%m-%d %H:%M:%S %z')"
  echo "CPU 架构 : $ARCH"
  [[ -f "$OFF/packages/.source-os" ]] && echo "Docker 包 : 来自 $(cat "$OFF/packages/.source-os") ← 内网服务器发行版必须一致"
  echo
  echo "内容:"
  for d in packages pip/backend pip/instance npm images; do
    [[ -d "$OFF/$d" ]] && printf '  %-16s %8s  %s 个文件\n' "$d" \
      "$(du -sh "$OFF/$d" | cut -f1)" "$(find "$OFF/$d" -maxdepth 1 -type f | wc -l)"
  done
} >"$OUT_DIR/DEPS.txt"

echo
ok "下载完成: $OFF"
cat "$OUT_DIR/DEPS.txt" | sed 's/^/    /'
echo
echo "下一步:"
echo "  1) 再跑一次镜像导出(同一个 --out,产物会合并):"
echo "       bash deploy/export-offline.sh --out $OUT_DIR --odoo 19"
echo "  2) 把整个 $OUT_DIR/offline/ 拷到内网服务器的 <数据目录>/ 下(默认 /var/lib/odoosh/)"
echo "  3) 内网执行 deploy/install.sh —— 会自动用 offline/packages 装 Docker、用 offline/images 导镜像"
