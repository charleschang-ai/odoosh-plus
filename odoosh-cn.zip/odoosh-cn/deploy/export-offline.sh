#!/usr/bin/env bash
# OdooshCN 离线资源导出 —— 在「有外网、已正常跑起来 OdooshCN」的机器上执行。
#
# 为什么要在跑着的机器上导出:平台镜像 odoosh/api、odoosh/web 里已经装好了 pip / npm 依赖。
# 直接把构建好的镜像打包带走,内网就不必再 pip install / npm install(内网也装不了)。
#
# 产出结构(offline/ 整个拷到内网服务器的数据目录下即可,装完后仍是平台的资源补给目录):
#   <输出目录>/
#     ├── offline/
#     │   ├── images/*.tar          所有镜像:平台自身 + PostgreSQL + Odoo
#     │   └── enterprise/<版本>/    企业版代码(--with-enterprise 时)
#     ├── MANIFEST.txt              架构 / 源码版本 / 镜像清单 / sha256 校验值
#     └── README.txt                内网侧的安装步骤
#
# 用法:
#   bash deploy/export-offline.sh --odoo 19,18       # 常用:指定 Odoo 版本(本地没有则自动 pull)
#   bash deploy/export-offline.sh --odoo 19 --build  # 本机还没构建过平台镜像时,就地构建再导出
#   bash deploy/export-offline.sh --with-enterprise  # 连企业版代码一起打包
#   bash deploy/export-offline.sh --out /data/bundle --pack
#
# 参数:
#   --odoo 19,18        要带哪些 Odoo 版本(不写则用本机已有的;一个都没有会报错)
#   --build             缺 odoosh/api|web 镜像时就地 docker compose build(本机没装过平台时用)
#   --with-enterprise   把本机的企业版代码目录一并打包
#   --out DIR           输出目录(默认 ./odoosh-offline)
#   --pack              额外打成单个 tar,方便 U 盘 / scp 传输
#   --no-pull           只用本机已有镜像,缺什么都不联网拉
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"

OUT_DIR="$PWD/odoosh-offline"
ODOO_VERSIONS=""        # 空 = 用本机已有的 odoo:* 镜像
WITH_ENTERPRISE=0
PACK=0
NO_PULL=0
BUILD=0                 # 1 = 平台镜像缺失时就地构建(而不是要求先跑 install.sh)

while [[ $# -gt 0 ]]; do
  case "$1" in
    --out) OUT_DIR="$2"; shift 2 ;;
    --odoo) ODOO_VERSIONS="$2"; shift 2 ;;
    --with-enterprise) WITH_ENTERPRISE=1; shift ;;
    --pack) PACK=1; shift ;;
    --no-pull) NO_PULL=1; shift ;;
    --build) BUILD=1; shift ;;
    -h|--help) sed -n '2,32p' "$0"; exit 0 ;;
    *) echo "未知参数: $1(--help 查看用法)"; exit 1 ;;
  esac
done
[[ $BUILD -eq 1 && $NO_PULL -eq 1 ]] && { echo "--build 与 --no-pull 冲突(构建需要联网装 pip / npm 依赖)"; exit 1; }

info() { echo -e "\033[1;34m[export]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[  ok  ]\033[0m $*"; }
warn() { echo -e "\033[1;33m[ warn ]\033[0m $*"; }
die()  { echo -e "\033[1;31m[ fail ]\033[0m $*"; exit 1; }

# ---------- Docker ----------
command -v docker >/dev/null 2>&1 || die "本机没有 docker"
DOCKER="docker"
docker info >/dev/null 2>&1 || { sudo docker info >/dev/null 2>&1 && DOCKER="sudo docker" || die "Docker 服务未运行"; }

ARCH="$($DOCKER version --format '{{.Server.Arch}}' 2>/dev/null || uname -m)"
info "导出架构: $ARCH(内网服务器架构必须一致,x86_64 的包不能给 ARM 机器用)"

# ---------- 需要导出的镜像清单 ----------
# 平台自建镜像:本机 docker build 的产物,registry 上没有,只能本地取(见 ensure_image 的 local 分支)
PLATFORM_LOCAL_IMAGES=(odoosh/api:dev odoosh/web:dev)
# 平台依赖的公共镜像:缺了自动 pull
PLATFORM_PULL_IMAGES=(postgres:16)
# 运行时:创建租户实例要用
RUNTIME_IMAGES=(pgvector/pgvector:pg16)
# 可选:控制台「重构并重启」用;内网通常用不到,缺了不影响平台运行
OPTIONAL_IMAGES=(docker:27-cli)

# Odoo 镜像:指定了版本就按版本,否则收集本机已有的
ODOO_IMAGES=()
if [[ -n "$ODOO_VERSIONS" ]]; then
  IFS=',' read -ra _vs <<<"$ODOO_VERSIONS"
  for v in "${_vs[@]}"; do
    v="$(echo "$v" | tr -d ' ')"
    [[ -n "$v" ]] && ODOO_IMAGES+=("odoo:$v")
  done
else
  while IFS= read -r line; do
    [[ -n "$line" ]] && ODOO_IMAGES+=("$line")
  done < <($DOCKER images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null | grep -E '^odoo:[0-9]+(\.[0-9]+)?$' | sort -Vr | uniq)
  if [[ ${#ODOO_IMAGES[@]} -eq 0 ]]; then
    # 没有 Odoo 镜像的资源包是废的:内网既拉不到镜像,也无法从源码自建(要联网 clone + pip)。
    # 与其产出一个到现场才发现不能用的包,不如现在就停下来。
    die "本机没有任何 odoo:<版本> 镜像,导出的资源包到了内网也建不了实例。请指定要带哪些版本(脚本会自动下载):
      bash deploy/export-offline.sh --odoo 19,18   (其余参数同本次)
    或先自行 docker pull odoo:19 再重跑。"
  fi
fi
# 自建基础镜像 odoosh-base:<版本> 若本机有,也一并带上(内网无法自建)
while IFS= read -r line; do
  [[ -n "$line" ]] && ODOO_IMAGES+=("$line")
done < <($DOCKER images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null | grep -E '^odoosh-base:[0-9]+' | sort -Vr | uniq)

# ---------- 确保镜像在本地(缺的就拉) ----------
have_image() { $DOCKER image inspect "$1" >/dev/null 2>&1; }

ensure_image() {  # $1=镜像  $2=required | optional | local(只认本地,绝不联网拉)
  local img="$1" kind="$2"
  if have_image "$img"; then return 0; fi
  # local:平台自建镜像(odoosh/api、odoosh/web)。这些名字在 registry 上并不属于我们,
  # 一旦被人抢注,pull 会默默拉来一个陌生镜像并打进资源包送进客户内网 —— 所以只认本地构建产物。
  if [[ "$kind" == "local" ]]; then
    die "本地没有平台镜像 $img,且它只能由本机构建、不能从网上拉取。二选一:
      1) 加 --build 让本脚本就地构建:  bash deploy/export-offline.sh --build (其余参数同本次)
      2) 先把平台装起来再导出:        bash deploy/install.sh"
  fi
  if [[ $NO_PULL -eq 1 ]]; then
    [[ "$kind" == "required" ]] && die "本地缺少必需镜像 $img,且指定了 --no-pull"
    warn "本地没有 $img,跳过(--no-pull)"; return 1
  fi
  info "本地没有 $img,尝试拉取..."
  if $DOCKER pull "$img" >/dev/null 2>&1; then
    ok "已拉取 $img"; return 0
  fi
  if [[ "$kind" == "required" ]]; then
    die "拉取必需镜像 $img 失败(网络不通或该 tag 不存在):$img"
  fi
  warn "拉取 $img 失败,跳过(该镜像可选,不影响平台运行)"
  return 1
}

# ---------- 输出目录 ----------
IMG_DIR="$OUT_DIR/offline/images"
ENT_DIR="$OUT_DIR/offline/enterprise"
mkdir -p "$IMG_DIR"
info "输出目录: $OUT_DIR"

SAVED=()   # "文件名|镜像1,镜像2"

save_group() {  # $1=输出文件名(不含 .tar)  $2..=镜像
  local name="$1"; shift
  local imgs=("$@")
  [[ ${#imgs[@]} -gt 0 ]] || return 0
  local f="$IMG_DIR/$name.tar"
  info "导出 $name.tar ← ${imgs[*]}"
  $DOCKER save -o "$f" "${imgs[@]}" || die "docker save $name 失败"
  SAVED+=("$name.tar|$(IFS=,; echo "${imgs[*]}")")
  ok "  $(du -h "$f" | cut -f1)  $name.tar"
}

# 平台自建镜像缺失时:--build 就地构建(导出机总是联网的,构建没问题);否则由 ensure_image 报错
MISSING_LOCAL=()
for img in "${PLATFORM_LOCAL_IMAGES[@]}"; do
  have_image "$img" || MISSING_LOCAL+=("$img")
done
if [[ ${#MISSING_LOCAL[@]} -gt 0 && $BUILD -eq 1 ]]; then
  info "缺少平台镜像 ${MISSING_LOCAL[*]},就地构建(首次约 3~10 分钟,要联网装 pip / npm 依赖)..."
  COMPOSE_ENV=()
  [[ -f "$ENV_FILE" ]] && COMPOSE_ENV=(--env-file "$ENV_FILE")
  # 只构建 api / web 两个服务,不启动任何容器(不碰这台机器上已有的平台)
  $DOCKER compose -f "$SCRIPT_DIR/docker-compose.yml" "${COMPOSE_ENV[@]}" build api web \
    || die "构建平台镜像失败。常见原因是 pip / npm 源不通;可先手动跑通 bash deploy/install.sh 再导出。"
  ok "平台镜像构建完成"
fi

# 平台三件套:装机时一起 load,打成一个包
PLAT_OK=()
for img in "${PLATFORM_LOCAL_IMAGES[@]}"; do
  ensure_image "$img" local && PLAT_OK+=("$img")     # 只认本地构建产物,绝不联网拉
done
for img in "${PLATFORM_PULL_IMAGES[@]}"; do
  ensure_image "$img" required && PLAT_OK+=("$img")  # 公共镜像,缺了自动拉
done
save_group "odoosh-platform" "${PLAT_OK[@]}"

# 租户数据库镜像
RT_OK=()
for img in "${RUNTIME_IMAGES[@]}"; do
  ensure_image "$img" required && RT_OK+=("$img")
done
save_group "pgvector-pg16" "${RT_OK[@]}"

# Odoo 镜像:一个版本一个包(内网可按需只导入用得到的,也方便装完后单独删)
for img in "${ODOO_IMAGES[@]}"; do
  ensure_image "$img" required || continue
  save_group "$(echo "$img" | tr ':/' '-')" "$img"
done

# 可选镜像
OPT_OK=()
for img in "${OPTIONAL_IMAGES[@]}"; do
  ensure_image "$img" optional && OPT_OK+=("$img")
done
[[ ${#OPT_OK[@]} -gt 0 ]] && save_group "docker-cli" "${OPT_OK[@]}"

# ---------- 企业版代码 ----------
if [[ $WITH_ENTERPRISE -eq 1 ]]; then
  SRC_ENT=""
  if [[ -f "$ENV_FILE" ]]; then
    _dd=$(grep -E '^ODOOSH_DATA_DIR=' "$ENV_FILE" | cut -d= -f2- || true)
    [[ -n "$_dd" && -d "$_dd/offline/enterprise" ]] && SRC_ENT="$_dd/offline/enterprise"
  fi
  [[ -z "$SRC_ENT" && -d /var/lib/odoosh/offline/enterprise ]] && SRC_ENT=/var/lib/odoosh/offline/enterprise
  if [[ -n "$SRC_ENT" ]] && [[ -n "$(ls -A "$SRC_ENT" 2>/dev/null)" ]]; then
    info "打包企业版代码 $SRC_ENT ..."
    mkdir -p "$ENT_DIR"
    cp -a "$SRC_ENT"/. "$ENT_DIR"/
    ok "企业版代码: $(du -sh "$ENT_DIR" | cut -f1)($(ls "$ENT_DIR" | tr '\n' ' '))"
  else
    warn "没找到企业版代码目录(或为空),跳过。企业版代码需组织自行持有合法授权。"
  fi
fi

# ---------- 校验文件 ----------
# 放在 images/ 里、用标准 sha256sum 格式,内网可直接 cd 过去 sha256sum -c SHA256SUMS。
# 平台扫描只认 *.tar / *.tar.gz / *.tgz,这个文件不会被当成镜像包。
(cd "$IMG_DIR" && sha256sum ./*.tar | sed 's|\./||' >SHA256SUMS)
ok "已生成校验文件 offline/images/SHA256SUMS"

# ---------- MANIFEST ----------
GIT_SHA="$(cd "$REPO_DIR" && git rev-parse --short HEAD 2>/dev/null || echo unknown)"
GIT_DIRTY=""
(cd "$REPO_DIR" && git diff --quiet 2>/dev/null) || GIT_DIRTY=" (工作区有未提交改动)"
MAN="$OUT_DIR/MANIFEST.txt"
{
  echo "OdooshCN 离线资源包"
  echo "导出时间   : $(date '+%Y-%m-%d %H:%M:%S %z')"
  echo "导出主机   : $(hostname)"
  echo "CPU 架构   : $ARCH   ← 内网服务器必须相同架构"
  echo "Docker     : $($DOCKER version --format '{{.Server.Version}}' 2>/dev/null || echo ?)"
  echo "平台源码   : $GIT_SHA$GIT_DIRTY"
  echo "            (内网服务器上的源码应为同一版本,否则「重构并重启」会与镜像不一致)"
  echo
  echo "镜像包清单:"
  for row in "${SAVED[@]}"; do
    f="${row%%|*}"; imgs="${row#*|}"
    printf '  %-28s %8s  %s\n' "$f" "$(du -h "$IMG_DIR/$f" | cut -f1)" "$imgs"
  done
  echo
  echo "完整性校验(拷到内网后执行,确认传输途中没损坏):"
  echo "  cd <数据目录>/offline/images && sha256sum -c SHA256SUMS"
  echo
  cat "$IMG_DIR/SHA256SUMS"
} >"$MAN"

cat >"$OUT_DIR/README.txt" <<'EOF'
OdooshCN 离线安装步骤(内网服务器上执行)
=========================================
更完整的清单与运维手册见平台源码 docs/offline-checklist.md。


〇、动手前先确认(任何一条不满足都会在现场卡住)
------------------------------------------------
1. Docker ≥ 24 + docker compose 插件(v2)。验证: docker compose version
   没装的话:如果本资源包里有 offline/packages/(由 deploy/fetch-offline-deps.sh 下载),
   install.sh 会自动用里面的 deb/rpm 装好,无需外网;
   否则请先用系统镜像源装 docker-ce docker-ce-cli containerd.io docker-compose-plugin。
   ★ offline/packages/ 里的包是为某个发行版下的(见 packages/.source-os),
     与内网服务器的发行版 / 版本必须一致,否则装不上。
2. CPU 架构与 MANIFEST.txt 里记录的一致(amd64 的包不能给 ARM 机器用)。
3. 磁盘按本资源包体积的 2 倍预留(tar 文件 + docker load 后的镜像层),
   加上实例数据与备份,建议数据盘 ≥ 60GB。内存 ≥ 4GB。
4. 防火墙放行 80(控制台)与 10001-10020(端口直连模式的实例端口池):
     sudo ufw allow 80/tcp && sudo ufw allow 10001:10020/tcp
5. ★ Docker 地址池:安装脚本会写 default-address-pools = 10.200.0.0/16 size 26。
   平台给每个实例建一个独立 bridge 网络,size 决定实例数量上限:
       size 24 -> 256 个网络(老版本脚本的值)   size 26 -> 1024 个   <- 现在的默认
   到上限后新实例容器起不来。已建的网络不会自动迁移,必须在大量建实例前定好。
   两点要检查:
     a) 如果贵司内网 / VPN 已经在用 10.200.x.x,会路由冲突、访问内网其它系统中断;
     b) 老版本装过的机器仍是 size 24,重跑脚本会提示但不会自动改
        (手工:sudo sed -i 's/"size": 24/"size": 26/' /etc/docker/daemon.json && systemctl restart docker)
   要换网段的话先手工写好 /etc/docker/daemon.json,再带 --skip-docker-config 安装:

     sudo tee /etc/docker/daemon.json >/dev/null <<'JSON'
     {
       "log-driver": "json-file",
       "log-opts": { "max-size": "20m", "max-file": "3" },
       "default-address-pools": [ { "base": "172.30.0.0/16", "size": 26 } ]
     }
     JSON
     sudo systemctl restart docker

6. 时间与时区正确(内网常无 NTP;自动备份、闲置休眠按此计算):
     sudo timedatectl set-timezone Asia/Shanghai && timedatectl


一、把平台源码拷到服务器
------------------------
与 MANIFEST.txt 记的 git 版本一致,例如 /opt/odoosh-cn


二、把资源包里的 offline/ 整个目录拷到数据目录下
------------------------------------------------
     sudo mkdir -p /var/lib/odoosh
     sudo cp -a offline /var/lib/odoosh/

   拷完应该是这样(带 ☆ 的由 deploy/fetch-offline-deps.sh 产出,没跑过就没有,不影响装机):
     /var/lib/odoosh/offline/images/*.tar          ← 镜像
     /var/lib/odoosh/offline/enterprise/<版本>/    ← 企业版代码(如有)
     /var/lib/odoosh/offline/packages/*.deb|rpm   ☆ 宿主机 Docker 安装包,install.sh 自动使用
     /var/lib/odoosh/offline/pip/instance/*.whl   ☆ 客户模块的 Python 依赖,部署实例时自动使用
     /var/lib/odoosh/offline/pip/backend/*.whl    ☆ 平台后端依赖(仅内网要重建平台镜像时用)
     /var/lib/odoosh/offline/npm/node_modules.tar.gz  ☆ 前端依赖(同上)

   先校验传输有没有损坏(GB 级文件走 U 盘 / 内网传输容易出问题):
     cd /var/lib/odoosh/offline/images && sha256sum -c SHA256SUMS


三、跑安装脚本
--------------
脚本发现 offline/images 里有 tar 就自动进入离线模式
(自动 docker load、跳过所有联网步骤、不重新构建镜像):

     sudo bash deploy/install.sh --base-domain localhost

常用参数: --port 8080(80 被占用)  --data-dir /data/odoosh(数据盘)
          --admin-password xxx(否则随机生成并在末尾打印)
          --skip-docker-config(自己管理 daemon.json,见第〇节第 5 条)

脚本可重复执行:已有 .env 会沿用,只重新导入镜像并拉起容器。


四、装完必做的三件事
--------------------
1. 登录平台 →「系统设置 → 平台 → 实例访问模式」改为「端口」。
   内网没有公网 DNS,域名分流模式用不了;端口模式每个实例分配一个端口直连。
   (若内网 DNS 能做泛解析 *.odoo.内网域名 → 服务器IP,也可继续用域名模式,
    重跑安装时加 --base-domain odoo.内网域名)

2. ★ 处理 pip 源。系统设置「部署时自动安装依赖」默认开启,每次部署会在实例容器里
   执行 pip install -r requirements.txt。内网没有 PyPI 源,这一步会失败并回退整次部署。
   三选一:
     a) ☆ 推荐:offline/pip/instance/ 里放好 wheel(在有网机器上跑
        deploy/fetch-offline-deps.sh --only pip --instance-req <客户模块的 requirements.txt>)。
        平台检测到该目录有包,部署时会自动把它只读挂到实例的 /mnt/offline-pip,
        用 pip install --no-index --find-links 装,全程不访问 PyPI。
        日后客户模块加了新依赖,回有网机器重跑一次、把新 wheel 拷进该目录即可。
     b) 仓库里不需要额外 Python 依赖 → 到「系统设置」把该开关关掉;
     c) 有内网 PyPI(nexus / devpi)→ 保持开启,并给实例配好 pip 源(写进持久卷):
        docker exec -u odoo odoo-<租户>-<实例> sh -c \
          'mkdir -p ~/.config/pip && printf "[global]\nindex-url = http://内网pypi/simple\ntrusted-host = 内网pypi\n" > ~/.config/pip/pip.conf'

3. 企业版(如使用):确认「系统设置」里 odoo.enterprise_dir 指向
   /var/lib/odoosh/offline/enterprise,版本子目录里能看到模块数量。


五、常用运维命令
----------------
以下假设源码在 /opt/odoosh-cn、数据目录 /var/lib/odoosh。
容器名固定:odoosh-api-1(后端)、odoosh-web-1(前端 nginx)、odoosh-db-1(平台库)。
实例相关:odoo-<租户>-<实例>(Odoo 容器)、odoosh-pg-<租户>(该租户的 PG 容器)。

  # --- 平台服务 ---
  cd /opt/odoosh-cn/deploy
  docker compose --env-file .env ps                   # 看状态
  docker compose --env-file .env up -d --no-build     # 启动 / 重新拉起
  docker compose --env-file .env restart api          # 只重启后端
  docker compose --env-file .env restart web          # 只重启前端 nginx
  docker compose --env-file .env down                 # 停止并删容器(数据不丢)
  ★ 离线环境永远加 --no-build;不加的话镜像缺失时 compose 会尝试联网构建,必然失败。

  # --- 日志 ---
  docker compose --env-file .env logs -f api          # 后端日志(最常用)
  docker compose --env-file .env logs --tail 200 api
  docker logs -f --tail 100 odoo-<租户>-<实例>         # 某个 Odoo 实例
  tail -f /var/lib/odoosh/nginx-logs/<租户>-<实例>.log # 实例访问日志

  # --- 进容器 / 体检 ---
  docker exec -it odoosh-api-1 bash
  docker exec -it odoo-<租户>-<实例> bash
  curl -fsS http://127.0.0.1/api/health               # 平台健康检查
  docker stats --no-stream                            # 各容器资源占用

  # --- 镜像 ---
  docker images | grep -E 'odoo|odoosh|pgvector|postgres'
  docker load -i /var/lib/odoosh/offline/images/odoo-18.tar   # 手工导入
  ★ 千万不要执行 docker system prune -a / docker image prune -a —— 会删掉没在跑的
    odoo、pgvector 等镜像,内网拉不回来!清理只用 docker container prune 或
    docker builder prune。

  # --- 数据库 ---
  docker exec -it odoosh-db-1 psql -U odoosh -d odoosh              # 平台库
  docker exec -it odoosh-pg-<租户> psql -U postgres -c '\l+'         # 租户库列表
  docker exec odoosh-db-1 pg_dump -U odoosh -Fc odoosh \
    > /var/lib/odoosh/backups/platform-$(date +%F).pgc              # 手工备份平台库
  (实例的备份 / 恢复请用平台页面,会一并处理 filestore;文件在 backups/<租户>/<实例>/)

  # --- nginx / 实例访问 ---
  ls /var/lib/odoosh/nginx/                           # 平台自动生成的 server 配置
  docker exec odoosh-web-1 nginx -t                   # 语法检查
  docker exec odoosh-web-1 nginx -s reload            # 重载

  # --- 磁盘 ---
  df -h /var/lib/odoosh && du -sh /var/lib/odoosh/*
  docker system df

  # --- 卸载 ---
  bash /opt/odoosh-cn/deploy/uninstall.sh             # 删容器与平台镜像,保留数据
  bash /opt/odoosh-cn/deploy/uninstall.sh --purge     # 连数据目录一起删(不可恢复!)


六、离线升级平台
----------------
内网不能用控制台的「重构并重启」(要联网 pip / npm)。流程:
  【有网机器】 git pull → bash deploy/install.sh(重新构建)
               → bash deploy/export-offline.sh --out ./upgrade-$(date +%F) --pack
  【内网机器】 先备份平台库(见上)→ 更新源码 → docker load 新的 odoosh-platform.tar
               → cd deploy && docker compose --env-file .env up -d --no-build
               → docker compose --env-file .env logs -f api 确认迁移完成


说明
----
* /var/lib/odoosh/offline/ 装完后依然生效:以后要加新的 Odoo 版本,
  把镜像 tar 丢进 offline/images/,在平台「基础镜像」页点扫描即可导入
  (也可以直接在网页上传 tar)。创建实例时缺镜像,平台还会自动来这里找并导入。
* offline/images/ 里的 tar 导入后可以删(平台页面上就能删)以释放磁盘。
* offline/enterprise/ 不能删 —— 实例容器直接只读挂载它。
* 离线环境用不了的功能:HTTPS 自动签发(deploy/ssl-ip.sh 要访问 Let's Encrypt)、
  AI 助手(需 LLM 服务)、源码自建基础镜像(要 clone + pip)、平台「重构并重启」。
  客户模块要么接内网 Git 服务(GitLab / Gitea),要么用无仓库实例的定制代码通道
  (页面上传 zip,或把模块拷进 tenants/<租户>/envs/<实例>/addons/ 后扫描)。
EOF

echo
ok "导出完成: $OUT_DIR"
du -sh "$OUT_DIR" | awk '{print "    总大小: " $1}'
echo "    清单:   $MAN"

# ---------- 依赖包(fetch-offline-deps.sh 的产出)是否已就位 ----------
# 两个脚本用同一个 --out 目录就会合并成一个完整资源包;这里只做提示,不代跑。
OFF_ROOT="$OUT_DIR/offline"
DEPS_MISSING=()
if ! compgen -G "$OFF_ROOT/packages"/*.deb >/dev/null 2>&1 && ! compgen -G "$OFF_ROOT/packages"/*.rpm >/dev/null 2>&1; then
  DEPS_MISSING+=("宿主机 Docker 安装包")
fi
if ! compgen -G "$OFF_ROOT/pip/instance"/*.whl >/dev/null 2>&1; then
  DEPS_MISSING+=("客户模块 Python 依赖(部署实例时要用)")
fi
if [[ ${#DEPS_MISSING[@]} -gt 0 ]]; then
  echo
  warn "本包只含镜像,以下内网也拿不到的东西还没准备:"
  for m in "${DEPS_MISSING[@]}"; do echo "        - $m"; done
  echo "    需要的话用同一个 --out 目录补一次(产物会并进本包):"
  echo "        bash deploy/fetch-offline-deps.sh --out $OUT_DIR --os <内网服务器系统,如 ubuntu:22.04> \\"
  echo "             --instance-req <客户模块的 requirements.txt>"
fi

if [[ $PACK -eq 1 ]]; then
  TARBALL="$OUT_DIR.tar"
  info "打包成单个文件(镜像层已压缩过,这里不再 gzip,只是打包)..."
  tar -cf "$TARBALL" -C "$(dirname "$OUT_DIR")" "$(basename "$OUT_DIR")"
  ok "已打包: $TARBALL ($(du -h "$TARBALL" | cut -f1))"
fi

echo
echo "下一步:把整个 $OUT_DIR 拷到内网服务器,按里面的 README.txt 操作。"
