#!/usr/bin/env bash
# OdooshCN 一键安装脚本(Ubuntu/Debian 优先;其它发行版需先自行安装 Docker)
# 用法:  bash deploy/install.sh [--port 80] [--data-dir /var/lib/odoosh] [--admin-password xxx]
#                               [--base-domain auto|odoo.example.com|localhost] [--tz Asia/Shanghai]
#                               [--registry-mirror https://xxxx.mirror.aliyuncs.com] [--skip-checks] [--skip-docker-config] [--skip-sysctl]
#                               [--offline | --online] [--offline-dir /var/lib/odoosh/offline/images]
#                               [--https-port 443] [--acme-port 8088] [--env-port-range 10001-10020]
# compose 会无条件绑 4 组端口:--port(控制台 HTTP)、--https-port、--acme-port(证书续期)、
# --env-port-range(端口直连模式的实例端口池)。装了宝塔 / 已有 nginx 的机器 80、443 常被占,
# 脚本第 3 步会逐个预检并告诉你该加哪个参数。
# 建议云服务器加 --registry-mirror 指向厂商自己的加速器(阿里云:容器镜像服务 → 镜像加速器;腾讯云 mirror.ccs.tencentyun.com),
# 公共加速站(xuanyuan / unsee 等)经常 429 限流。
# 重复执行是安全的:已装 Docker 会复用,已有 .env 会沿用,只重新构建并启动平台容器。
#
# 联网 / 内网只有这一个脚本,自动判断,不用挑:
#   1) 先看 <数据目录>/offline/ 里有没有现成资源(镜像 tar、Docker 安装包 deb/rpm、pip wheel),有就直接用;
#   2) 缺什么再探测外网 —— 通就联网补(Docker 用阿里云源、镜像走加速站),不通就明确告诉你缺哪个、去哪补。
# 所以:内网机器把资源包拷到 <数据目录>/offline/ 下直接跑;联网机器什么都不用准备也能跑。
#   --offline  跳过外网探测,强制走本地资源(内网现场用,省 6 秒探测)
#   --online   忽略本地资源包全部联网(资源包过期、想按当前源码重建平台镜像时用)
# 资源包由有网机器上的 deploy/fetch-offline-deps.sh(Docker 安装包 / pip / npm)
# 与 deploy/export-offline.sh(镜像 / 企业版代码)生成,详见 docs/offline-checklist.md。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"
HTTP_PORT=80
HTTPS_PORT=443          # compose 无条件绑它;宝塔 / 已有 nginx 常占用 → 可用 --https-port 换
ACME_PORT=8088          # Let's Encrypt 只认 80,主端口挪走时靠它保住续期链路
ENV_PORT_RANGE=10001-10020   # 端口直连模式的实例端口池(与 compose 的端口映射一致)
SELINUX_OPT=""          # 第 1 步探测:RHEL 系 Enforcing → label:disable
DATA_DIR=/var/lib/odoosh
ADMIN_PASSWORD=""
BASE_DOMAIN=""          # 空 = 交互式/按环境推断(见第 4 步)
TZ_NAME="Asia/Shanghai"
REGISTRY_MIRROR=""      # 自定义镜像加速地址,会排在内置加速站之前
SKIP_CHECKS=0
SKIP_DOCKER_CONFIG=0   # 1 = 不碰 /etc/docker/daemon.json(自己管理镜像加速 / 地址池时用)
SKIP_SYSCTL=0          # 1 = 不碰 /etc/sysctl.d(自己管理内核参数时用;实例多了要自行调大 inotify 配额)
FORCE_MODE=""          # ""=自动(推荐);offline=强制不碰外网;online=忽略本地资源包全部联网
OFFLINE=0              # 运行时结论:1 = 本次不访问外网(由 --offline 或外网探测决定)
OFFLINE_DIR=""         # 镜像 tar 所在目录;留空则自动探测
DATA_DIR_SET=0         # 用户是否显式给了 --data-dir(与已有 .env 冲突时才需要提醒)
PORT_SET=0             # 同上,--port

while [[ $# -gt 0 ]]; do
  case "$1" in
    --port) HTTP_PORT="$2"; PORT_SET=1; shift 2 ;;
    --https-port) HTTPS_PORT="$2"; shift 2 ;;
    --acme-port) ACME_PORT="$2"; shift 2 ;;
    --env-port-range) ENV_PORT_RANGE="$2"; shift 2 ;;
    --data-dir) DATA_DIR="$2"; DATA_DIR_SET=1; shift 2 ;;
    --admin-password) ADMIN_PASSWORD="$2"; shift 2 ;;
    --base-domain) BASE_DOMAIN="$2"; shift 2 ;;
    --tz) TZ_NAME="$2"; shift 2 ;;
    --registry-mirror) REGISTRY_MIRROR="$2"; shift 2 ;;
    --skip-checks) SKIP_CHECKS=1; shift ;;
    --skip-docker-config) SKIP_DOCKER_CONFIG=1; shift ;;
    --skip-sysctl) SKIP_SYSCTL=1; shift ;;
    --offline) FORCE_MODE=offline; shift ;;
    --online) FORCE_MODE=online; shift ;;
    --offline-dir) OFFLINE_DIR="$2"; FORCE_MODE=offline; shift 2 ;;
    -h|--help) sed -n '2,21p' "$0"; exit 0 ;;
    *) echo "未知参数: $1(--help 查看用法)"; exit 1 ;;
  esac
done

info() { echo -e "\033[1;34m[odoosh]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[  ok  ]\033[0m $*"; }
warn() { echo -e "\033[1;33m[ warn ]\033[0m $*"; }
die()  { echo -e "\033[1;31m[ fail ]\033[0m $*"; exit 1; }

# 从 .env 取一个键的值(取不到就是空串,绝不因 grep 无匹配而中断脚本)。
# 用 sed 而非 grep|cut:值里含 = 时也能完整取出;
# 末尾 tr -d '\r':.env 若被 Windows 编辑器改过会带 CRLF,残留的 \r 会让路径 / 端口变成非法值。
env_get() { [[ -f "$ENV_FILE" ]] && sed -n "s/^$1=//p" "$ENV_FILE" | head -n1 | tr -d '\r' || true; }

# 已有 .env 时它说了算:数据目录与端口都写死在里面,compose 用的也是它。
# 命令行给了不同的值只警告、不改写 —— 否则会出现「目录建在 A、容器却挂载 B」的错位。
if [[ -f "$ENV_FILE" ]]; then
  _env_data_dir="$(env_get ODOOSH_DATA_DIR)"
  _env_port="$(env_get ODOOSH_HTTP_PORT)"
  if [[ -n "$_env_data_dir" && "$_env_data_dir" != "$DATA_DIR" ]]; then
    if [[ ! -d "$_env_data_dir" ]]; then
      # .env 里写的目录在本机根本不存在 —— 十有八九是把源码(连同 deploy/.env)从别的机器整个拷过来的。
      # 离线交付很容易这样:有网机器装过一次,打包源码时把 .env 也带上了。
      warn "$ENV_FILE 里的 ODOOSH_DATA_DIR=$_env_data_dir 在本机不存在,这份 .env 多半是从别的机器拷来的。"
      if [[ $DATA_DIR_SET -eq 1 ]]; then
        warn "  本次按命令行的 --data-dir $DATA_DIR 走,并同步改写 .env"
        # 删行再追加,而不是 sed 替换 —— 路径里若含 & 或 \,sed 的替换串会把它当特殊字符
        sed -i '/^ODOOSH_DATA_DIR=/d' "$ENV_FILE"
        echo "ODOOSH_DATA_DIR=$DATA_DIR" >>"$ENV_FILE"
      else
        warn "  将按 .env 在本机新建 $_env_data_dir;若不是你要的路径,请删掉 $ENV_FILE 后重跑
    (注意:删 .env 会重新生成数据库密码与管理员密码,只适用于全新安装)"
        DATA_DIR="$_env_data_dir"
      fi
    else
      [[ $DATA_DIR_SET -eq 1 ]] && warn "沿用已有 $ENV_FILE 里的 ODOOSH_DATA_DIR=$_env_data_dir,本次 --data-dir $DATA_DIR 忽略
    (要换数据目录:先 bash deploy/uninstall.sh,或手工改 .env 并把数据搬过去)"
      DATA_DIR="$_env_data_dir"
    fi
  fi
  if [[ -n "$_env_port" && "$_env_port" != "$HTTP_PORT" ]]; then
    [[ $PORT_SET -eq 1 ]] && warn "沿用已有 $ENV_FILE 里的 ODOOSH_HTTP_PORT=$_env_port,本次 --port $HTTP_PORT 忽略(要换端口请直接改 .env 后重跑)"
    HTTP_PORT="$_env_port"
  fi
  # 另外三个端口同理:.env 说了算,否则下面的端口占用预检会去查错的端口
  _v="$(env_get ODOOSH_HTTPS_PORT)";      if [[ -n "$_v" ]]; then HTTPS_PORT="$_v"; fi
  _v="$(env_get ODOOSH_ACME_PORT)";       if [[ -n "$_v" ]]; then ACME_PORT="$_v"; fi
  _v="$(env_get ODOOSH_ENV_PORT_RANGE)";  if [[ -n "$_v" ]]; then ENV_PORT_RANGE="$_v"; fi
fi

SUDO=""
if [[ $EUID -ne 0 ]]; then
  command -v sudo >/dev/null || die "需要 root 或 sudo"
  SUDO="sudo"
  # 提前验证一次 sudo(需要密码就在这里输),避免后面在管道 / heredoc 里卡住看不见提示。
  # 只有真的会用到 sudo 时才要:要装 Docker / 要改 daemon.json / 数据目录不可写
  if ! command -v docker >/dev/null 2>&1 || [[ $SKIP_DOCKER_CONFIG -eq 0 ]] || { [[ ! -d "$DATA_DIR" || ! -w "$DATA_DIR" ]] && [[ ! -w "$(dirname "$DATA_DIR")" ]]; }; then
    sudo -n true 2>/dev/null || { echo "[odoosh] 安装需要 sudo 权限(安装 / 配置 Docker、创建数据目录),请输入密码:"; sudo -v || die "无法获得 sudo 权限"; }
  fi
fi

# tr 从 /dev/urandom 无限读,head 取够即关管道,tr 收到 SIGPIPE 退 141;在 set -euo pipefail 下会杀死整个脚本 → || true 吞掉
rand() { (tr -dc 'A-Za-z0-9' </dev/urandom 2>/dev/null || true) | head -c "${1:-24}"; }
# 版本比较:ver_ge 20.10 19.03 → 真
ver_ge() { [[ "$(printf '%s\n%s\n' "$2" "$1" | sort -V | head -n1)" == "$2" ]]; }

# ---------- 0. 资源探测与联网判定 ----------
# 本脚本是「组合式」的,只有这一个入口:先用本地资源,缺什么再看外网能不能补。
#   默认(自动)  本地有就用本地;缺的且外网通 → 联网拉;缺的且外网不通 → 明确报错说缺什么
#   --offline    强制不碰外网(内网现场用,省掉探测等待)
#   --online     忽略本地资源包,全部联网(资源包过期、想重新拉最新时用)
# 约定目录(装完后依然生效,日后补资源不用改脚本):
#   <数据目录>/offline/images/       镜像 tar        ← 平台「基础镜像」页扫描的也是它
#   <数据目录>/offline/enterprise/   企业版代码
#   <数据目录>/offline/packages/     宿主机 Docker 安装包(deb/rpm)
#   <数据目录>/offline/pip/          pip wheel(实例部署时用 offline/pip/instance)
# docker load 认未压缩 tar 与 gzip 压缩包;与平台「基础镜像」页扫描的后缀保持一致
has_tar() {
  [[ -d "$1" ]] || return 1
  compgen -G "$1"/*.tar >/dev/null 2>&1 || compgen -G "$1"/*.tar.gz >/dev/null 2>&1 || compgen -G "$1"/*.tgz >/dev/null 2>&1
}
[[ "$FORCE_MODE" == online ]] && OFFLINE_DIR=""   # 强制联网:本地镜像包一律不看
if [[ -z "$OFFLINE_DIR" && "$FORCE_MODE" != online ]]; then
  for d in "$DATA_DIR/offline/images" "$SCRIPT_DIR/offline/images" "$SCRIPT_DIR/../offline/images"; do
    if has_tar "$d"; then OFFLINE_DIR="$(cd "$d" && pwd)"; break; fi
  done
fi
HAVE_TARS=0
if [[ -n "$OFFLINE_DIR" ]]; then
  # --offline-dir 可能给的是相对路径,而后面 cd 到 deploy/ 之后再展开就找不到了:统一转绝对路径
  [[ -d "$OFFLINE_DIR" ]] || die "--offline-dir 指定的目录不存在: $OFFLINE_DIR"
  OFFLINE_DIR="$(cd "$OFFLINE_DIR" && pwd)"
  has_tar "$OFFLINE_DIR" && HAVE_TARS=1 || true
fi

# 外网可达性:只探一次并缓存。--offline 直接当作不通,--online 直接当作通(不浪费 6 秒)。
NET_STATE=""
net_ok() {
  case "$FORCE_MODE" in
    offline) return 1 ;;
    online)  return 0 ;;
  esac
  if [[ -z "$NET_STATE" ]]; then
    # 探 aliyun 镜像站:装 Docker、拉基础镜像都要用它,比 ping 8.8.8.8 更能代表"这台机器能不能装东西"
    if command -v curl >/dev/null 2>&1; then
      if curl -fsS -m 6 -o /dev/null https://mirrors.aliyun.com/ 2>/dev/null; then NET_STATE=yes; else NET_STATE=no; fi
    elif (exec 3<>/dev/tcp/mirrors.aliyun.com/443) 2>/dev/null; then
      NET_STATE=yes   # 没有 curl 时的兜底探测(子 shell 里开的 fd 随子 shell 一起关掉)
    else
      NET_STATE=no
    fi
  fi
  [[ "$NET_STATE" == yes ]]
}
if net_ok; then OFFLINE=0; else OFFLINE=1; fi

if [[ $OFFLINE -eq 1 ]]; then
  if [[ "$FORCE_MODE" == offline ]]; then info "离线模式(--offline):全程不访问外网"
  else info "外网不可达 → 自动转入离线安装(全程不访问外网)"; fi
  [[ $HAVE_TARS -eq 1 ]] && info "  镜像来源: $OFFLINE_DIR" \
    || warn "  没找到本地镜像包($DATA_DIR/offline/images/ 下无 *.tar);若镜像已导入过本机可继续,否则会在第 6b 步失败"
elif [[ $HAVE_TARS -eq 1 ]]; then
  info "外网可达 + 检测到本地镜像包 → 优先用本地资源,缺的再联网补($OFFLINE_DIR)"
else
  info "外网可达 → 联网安装"
fi

# 离线依赖包目录(deploy/fetch-offline-deps.sh 的产出):宿主机 Docker 安装包 / pip wheel / npm 依赖。
# 与镜像目录同级,即 <数据目录>/offline/{packages,pip,npm};没有也不影响,只是少一层兜底。
OFFLINE_ROOT=""
if [[ -n "$OFFLINE_DIR" ]]; then
  OFFLINE_ROOT="$(cd "$OFFLINE_DIR/.." && pwd)"
else
  for d in "$DATA_DIR/offline" "$SCRIPT_DIR/offline" "$SCRIPT_DIR/../offline"; do
    [[ -d "$d" ]] && { OFFLINE_ROOT="$(cd "$d" && pwd)"; break; }
  done
fi
PKG_DIR=""
if [[ "$FORCE_MODE" != online && -n "$OFFLINE_ROOT" && -d "$OFFLINE_ROOT/packages" ]]; then
  if compgen -G "$OFFLINE_ROOT/packages"/*.deb >/dev/null 2>&1 || compgen -G "$OFFLINE_ROOT/packages"/*.rpm >/dev/null 2>&1; then
    PKG_DIR="$OFFLINE_ROOT/packages"
  fi
fi

# ---------- 1. 操作系统与硬件预检 ----------
[[ "$(uname -s)" == "Linux" ]] || die "仅支持 Linux(Windows 请在 WSL2 中运行)"
[[ -r /etc/os-release ]] || die "读不到 /etc/os-release,无法判断发行版。请手工装好 Docker + compose 插件后加 --skip-docker-config 重跑"
. /etc/os-release
# set -u 下未定义变量会直接终止脚本,而精简 / 非主流发行版未必有这几个字段,统一给默认值
OS_NAME="${PRETTY_NAME:-${NAME:-${ID:-unknown}}}"
OS_CODENAME="${VERSION_CODENAME:-${UBUNTU_CODENAME:-}}"
info "系统: $OS_NAME($(uname -m))"
case "$(uname -m)" in
  x86_64|aarch64|arm64) ;;
  *) warn "未在 $(uname -m) 架构上验证过,Odoo 官方镜像仅提供 amd64/arm64" ;;
esac

# SELinux:RHEL 系(Rocky / Alma / CentOS / Alibaba Cloud Linux / OpenCloudOS / 麒麟)默认 Enforcing。
# 平台容器要读写 /var/run/docker.sock 和数据目录,不做处理会被拒绝(EACCES)——
# 现象是平台起得来、页面能打开,但建实例 / 看日志全失败,报错还很难和 SELinux 联系起来。
# 处理方式是给平台容器加 security_opt: label:disable,而不是给挂载点加 :z:
#   :z 会把 docker.sock 重新打成共享标签,等于对所有容器开放,反而更不安全;
#   而且数据目录动辄几十 GB,递归重打标签又慢又会波及租户数据。
# label:disable 只对平台自己的三个容器生效(它们本来就持有 docker.sock = 宿主机 root 等价权限)。
if command -v getenforce >/dev/null 2>&1 && [[ "$(getenforce 2>/dev/null || echo Disabled)" == "Enforcing" ]]; then
  SELINUX_OPT="label:disable"
  warn "SELinux 处于 Enforcing:平台容器将以 label:disable 运行,否则访问 docker.sock / 数据目录会被拒绝"
else
  SELINUX_OPT="no-new-privileges:false"   # 占位值(Docker 默认值,等于什么都不做)
fi

if [[ $SKIP_CHECKS -eq 0 ]]; then
  MEM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
  CPUS=$(nproc 2>/dev/null || echo 1)
  DISK_GB=$(df -BG --output=avail "$(dirname "$DATA_DIR")" 2>/dev/null | tail -1 | tr -dc '0-9' || echo 0)
  [[ ${MEM_MB:-0} -lt 3500 ]] && warn "内存仅 ${MEM_MB}MB:平台本身约占 1.5GB,每个 Odoo 实例默认 1GB,建议 ≥ 4GB(并开启 swap)"
  [[ ${CPUS:-1} -lt 2 ]] && warn "CPU 仅 ${CPUS} 核:源码自建镜像会很慢,建议 ≥ 2 核"
  [[ ${DISK_GB:-0} -lt 20 ]] && warn "数据盘可用空间仅 ${DISK_GB}GB($(dirname "$DATA_DIR")):镜像 + 实例 + 备份很快会吃满,建议 ≥ 40GB 或用 --data-dir 指到数据盘"
  ok "硬件: ${CPUS} 核 / ${MEM_MB}MB 内存 / 可用磁盘 ${DISK_GB}GB"
fi

# ---------- 2. Docker ----------
# 2a. 资源包里带了 Docker 安装包(fetch-offline-deps.sh 下的 deb/rpm)→ 直接本地装,内网无需外网源
if ! command -v docker >/dev/null 2>&1 && [[ -n "$PKG_DIR" ]]; then
  SRC_OS="$(cat "$PKG_DIR/.source-os" 2>/dev/null || echo '?')"
  info "未检测到 Docker,使用离线安装包 $PKG_DIR(下载自 $SRC_OS)..."
  if compgen -G "$PKG_DIR"/*.deb >/dev/null 2>&1; then
    # dpkg 不解析安装顺序,跑两遍可解决绝大多数"依赖尚未配置"的先后问题
    $SUDO dpkg -i "$PKG_DIR"/*.deb >/dev/null 2>&1 || $SUDO dpkg -i "$PKG_DIR"/*.deb || true
  else
    $SUDO rpm -Uvh --replacepkgs "$PKG_DIR"/*.rpm || true
  fi
  if command -v docker >/dev/null 2>&1; then
    $SUDO systemctl enable --now docker 2>/dev/null || true
    ok "Docker 已从离线包安装: $(docker --version)"
  else
    warn "离线包安装 Docker 未成功(常见原因:包是为 $SRC_OS 下载的,与本机 $OS_NAME 不匹配)"
  fi
fi
if ! command -v docker >/dev/null 2>&1 && [[ $OFFLINE -eq 1 ]]; then
  die "未检测到 Docker,而离线模式无法联网安装。三选一:
    1) 在有网机器上执行 bash deploy/fetch-offline-deps.sh --os <内网服务器的系统镜像,如 ubuntu:22.04>
       把产出的 offline/packages/ 一并拷到 $DATA_DIR/offline/ 下,重跑本脚本即可自动安装
    2) 用系统自带源:  sudo apt-get install -y docker.io docker-compose-plugin
    3) 从内网源装:    docker-ce docker-ce-cli containerd.io docker-compose-plugin
                      (RHEL 系用 yum install,包名相同)"
fi
if ! command -v docker >/dev/null 2>&1; then
  info "未检测到 Docker,开始安装(使用阿里云镜像源)..."
  case "${ID:-}" in
    ubuntu|debian)
      # 没有 codename 就拼不出 apt 源地址,与其写出一行坏源不如现在说清楚
      [[ -n "$OS_CODENAME" ]] || die "/etc/os-release 里没有 VERSION_CODENAME,无法拼出 Docker apt 源。
    请手工安装后重跑: sudo apt-get install -y docker.io docker-compose-plugin"
      $SUDO apt-get update -q
      $SUDO apt-get install -y -q ca-certificates curl gnupg
      $SUDO install -m 0755 -d /etc/apt/keyrings
      curl -fsSL "https://mirrors.aliyun.com/docker-ce/linux/${ID}/gpg" | $SUDO tee /etc/apt/keyrings/docker.asc >/dev/null
      $SUDO chmod a+r /etc/apt/keyrings/docker.asc
      echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://mirrors.aliyun.com/docker-ce/linux/${ID} ${OS_CODENAME} stable" \
        | $SUDO tee /etc/apt/sources.list.d/docker.list >/dev/null
      $SUDO apt-get update -q
      $SUDO apt-get install -y -q docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
      ;;
    *)
      warn "非 Ubuntu/Debian(${ID:-?}),尝试 Docker 官方脚本(阿里云镜像);若失败请按发行版文档手动安装 docker-ce + docker-compose-plugin 后重跑本脚本"
      curl -fsSL https://get.docker.com | $SUDO bash -s -- --mirror Aliyun || die "Docker 自动安装失败(Alibaba Cloud Linux / OpenCloudOS 等请参考厂商文档手动安装)"
      ;;
  esac
  $SUDO systemctl enable --now docker
  ok "Docker 安装完成"
else
  ok "Docker 已安装: $(docker --version)"
fi

# Docker 服务与版本
DOCKER="docker"
if ! docker info >/dev/null 2>&1; then
  if $SUDO docker info >/dev/null 2>&1; then
    warn "当前用户无 docker 权限,本次使用 sudo(可执行: sudo usermod -aG docker \$USER 后重新登录)"
    DOCKER="$SUDO docker"
  else
    $SUDO systemctl start docker 2>/dev/null || true
    $SUDO docker info >/dev/null 2>&1 && DOCKER="$SUDO docker" || die "Docker 服务未运行(systemctl status docker 查看原因)"
  fi
fi
DOCKER_VER=$($DOCKER version --format '{{.Server.Version}}' 2>/dev/null || echo 0)
ver_ge "$DOCKER_VER" "20.10" || warn "Docker 版本 $DOCKER_VER 过旧(建议 ≥ 24),compose v2 / buildx 可能不可用;如出错请先升级 Docker"
if ! $DOCKER compose version >/dev/null 2>&1; then
  case "${ID:-}" in
    ubuntu|debian) die "缺少 docker compose 插件,请执行: sudo apt-get install -y docker-compose-plugin docker-buildx-plugin 后重跑" ;;
    centos|rhel|rocky|almalinux|fedora|alinux|opencloudos|openEuler|tencentos) die "缺少 docker compose 插件,请执行: sudo yum install -y docker-compose-plugin docker-buildx-plugin 后重跑(老的 docker-compose v1 不支持)" ;;
    *) die "缺少 docker compose 插件(docker compose version 失败),请安装 docker-compose-plugin 后重跑" ;;
  esac
fi

# ---------- 2b. /etc/docker/daemon.json:镜像加速 + 日志轮转 + 网络地址池(合并,不覆盖已有配置) ----------
# - registry-mirrors:没配才写(云厂商预装的 Docker 往往没配,拉 python/node/nginx/postgres 基础镜像会卡死)
# - log-opts:没配才写,否则容器 stdout 日志无限增长
# - default-address-pools:平台给每个实例建一个独立 bridge 网络,Docker 默认地址池只够 ~30 个网络。
#   改成 10.200.0.0/16 按 /26 切 = 1024 个网络,每网段 62 个可用 IP(一个实例只有 odoo + pg 两个容器,绰绰有余)。
#   为什么不是 /24:/24 只能切出 256 个网络,到第 257 个实例容器就起不来(地址池耗尽),
#   而这个值一旦有实例跑起来就不好改了 —— 已建的网络不会自动迁移。宁可一开始就给够。
#   仅在未配置时写入;若与你的云内网 / VPN 网段冲突,请先手动配置好再运行本脚本(已配置则不动)
if [[ $SKIP_DOCKER_CONFIG -eq 1 ]]; then
  info "--skip-docker-config:不修改 /etc/docker/daemon.json"
elif command -v python3 >/dev/null 2>&1; then
  # 地址池冲突预检:下面会给 Docker 写 default-address-pools = 10.200.0.0/16,写完还要重启 Docker。
  # 服务器如果已经在用这个网段(VPC / 专线 / VPN),重启后新建的容器网桥会和内网路由打架 ——
  # 轻则访问不到内网其它系统,重则把你正连着的 SSH 打断。先把本机网段收集起来交给 python 判重叠。
  # 排除 docker 自己的 docker0 / br-* / veth:那是本脚本(或上次安装)造出来的,不算冲突。
  HOST_CIDRS="$(
    { ip -4 -o addr show 2>/dev/null | awk '$2 !~ /^(lo|docker|br-|veth)/ {print $4}'
      ip -4 route show 2>/dev/null | awk '$0 !~ / dev (docker|br-|veth)/ {print $1}'
    } | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+(/[0-9]+)?$' | sort -u || true
  )"
  set +e
  $SUDO env ODOOSH_MIRROR="$REGISTRY_MIRROR" ODOOSH_OFFLINE="$OFFLINE" ODOOSH_HOST_CIDRS="$HOST_CIDRS" python3 - <<'EOF'
import json, os, sys
p = "/etc/docker/daemon.json"
my = os.environ.get("ODOOSH_MIRROR", "").strip().rstrip("/")
offline = os.environ.get("ODOOSH_OFFLINE") == "1"
try:
    cfg = json.load(open(p)) if os.path.exists(p) and os.path.getsize(p) > 0 else {}
except Exception:
    sys.exit(2)
changed = []
DEFAULTS = ["https://docker.1ms.run", "https://docker.m.daocloud.io", "https://docker-0.unsee.tech", "https://docker.hlmirror.com"]
OLD_BUILTIN = {"https://docker.xuanyuan.me"}  # 曾经的内置站,429 限流严重,升级时剔除
# 离线安装不写镜像加速:内网连不上这些站,写了只会让每次镜像操作先去撞超时。
# 日志轮转与网络地址池不依赖外网,离线同样要配。
if not offline:
    # 显式的空列表 = 有意直连:上一次安装体检发现加速站拉不动、脚本自动摘掉的,
    # 或者管理员自己设的。绝不能再把默认加速站塞回去 —— 否则每次重跑都退回「卡住不动」,
    # 用户还得记得加 --skip-docker-config 才保得住修好的配置。
    if cfg.get("registry-mirrors") == [] and not my:
        pass
    else:
        mirrors = list(cfg.get("registry-mirrors") or [])
        if not mirrors:
            mirrors = list(DEFAULTS)
            changed.append("registry-mirrors")
        elif set(mirrors) <= (OLD_BUILTIN | set(DEFAULTS)) and mirrors != DEFAULTS:
            # 列表里全是本脚本写入过的内置站(用户没自己加过):升级为当前默认列表
            mirrors = list(DEFAULTS)
            changed.append("registry-mirrors(update)")
        if my:
            if not my.startswith("http"):
                my = "https://" + my
            if mirrors[:1] != [my]:
                mirrors = [my] + [m for m in mirrors if m != my]  # 自定义加速器排最前
                changed.append("registry-mirror(first)=" + my)
        cfg["registry-mirrors"] = mirrors
if cfg.get("log-driver", "json-file") == "json-file" and not cfg.get("log-opts", {}).get("max-size"):
    cfg["log-driver"] = "json-file"
    cfg["log-opts"] = {"max-size": "20m", "max-file": "3"}
    changed.append("log-opts")
POOL_OLD = [{"base": "10.200.0.0/16", "size": 24}]   # 本脚本旧版本写过的值,只够 256 个实例
POOL_NEW = [{"base": "10.200.0.0/16", "size": 26}]   # 1024 个 /26 网络,每个 62 个可用 IP
pools = cfg.get("default-address-pools")
if not pools:
    # 与本机现有网段重叠就绝不写:写了再重启 Docker,新建网桥会和内网路由冲突,可能当场断 SSH。
    # 宁可不配(实例网络上限退回 Docker 默认的约 30 个),也不能把机器搞失联。
    import ipaddress
    want = ipaddress.ip_network(POOL_NEW[0]["base"])
    hit = []
    for c in (os.environ.get("ODOOSH_HOST_CIDRS") or "").split():
        try:
            n = ipaddress.ip_network(c, strict=False)
        except ValueError:
            continue
        if n.overlaps(want):
            hit.append(c)
    if hit:
        w = chr(27) + "[1;33m[ warn ]" + chr(27) + "[0m "
        for line in [
            w + "本机网段 " + ",".join(hit) + " 与 Docker 默认地址池 " + POOL_NEW[0]["base"] + " 重叠,已跳过写入 default-address-pools。",
            "         直接写入并重启 Docker,新建的容器网桥会和内网路由冲突 —— 可能当场断开你正连着的 SSH。",
            "         不写也能装,只是实例网络上限退回 Docker 默认的约 30 个。要支持更多实例,",
            "         请自己挑一个不冲突的网段写进 /etc/docker/daemon.json 的 default-address-pools",
            "         (例如 base 172.30.0.0/16、size 26),然后 systemctl restart docker。",
            "         已经配置过的话本脚本不会再改动它。",
        ]:
            print(line, file=sys.stderr)
    else:
        cfg["default-address-pools"] = POOL_NEW
        changed.append("default-address-pools")
elif pools == POOL_OLD:
    # 不自动改:已建的实例网络是从旧的 /24 池分出来的,和新的 /26 池同处一个 /16,
    # 换池后 Docker 要在两者间避让,风险不值得脚本自作主张。交给管理员按实例规模决定。
    print("\033[1;33m[ warn ]\033[0m /etc/docker/daemon.json 里的 default-address-pools 还是旧的 size 24,"
          "最多只能建 256 个实例网络。\n"
          "         实例数会超过 200 的话,趁早改成 size 26(1024 个):编辑该文件把 \"size\": 24 改成 26,\n"
          "         然后 systemctl restart docker。已建好的实例网络不会自动迁移,所以越早改越好。",
          file=sys.stderr)
if not changed:
    sys.exit(0)
os.makedirs("/etc/docker", exist_ok=True)
json.dump(cfg, open(p, "w"), indent=2, ensure_ascii=False)
print(",".join(changed))
sys.exit(3)  # 3 = 已修改,需要重启 docker
EOF
  rc=$?
  set -e
  if [[ $rc -eq 3 ]]; then
    info "已合并写入 /etc/docker/daemon.json(镜像加速 / 日志轮转 / 网络地址池),重启 Docker 生效(已运行的容器会自动拉起)..."
    $SUDO systemctl restart docker || warn "重启 Docker 失败,请手动执行 systemctl restart docker"
    sleep 3
  elif [[ $rc -eq 2 ]]; then
    warn "/etc/docker/daemon.json 不是合法 JSON,未改动。请手动确认已配置 registry-mirrors / log-opts(max-size) / default-address-pools"
  fi
else
  warn "系统没有 python3,跳过 daemon.json 自动配置。请手动确认 /etc/docker/daemon.json 含 registry-mirrors、log-opts(max-size)、default-address-pools"
fi
# ---------- 2c. 拉取体检:加速站不通就自动改直连 ----------
# 内置的公共加速站经常整站挂掉 / 限流 / 要鉴权。它们一旦不通,后面每次拉镜像都要先把它们撞一遍超时,
# 表现就是「卡在那儿不动」—— 而脚本里的 pull 大多是静默的,根本看不出在等什么。
# 所以这里实测一次;拉不动就把 registry-mirrors 摘成空列表、重启 Docker 再试直连。
# 摘成空列表(而不是删掉这个键)是有意的:上面的配置逻辑认这个空列表,重跑时不会再把加速站塞回来。
# 探针镜像用 alpine(约 3.5MB)而不是 hello-world(只有 25KB)——
# 25KB 再慢的加速站也能吐出来,测不出「能连上但只有 0.2MB/s」这种最要命的情况:
# 体检过了,后面 600MB 的 pgvector 却要拉四十分钟,还是静默的,看着就像死机。
PROBE_IMAGE=alpine
# 「慢」和「坏」必须分开处理,它们的对策完全相反:
#   坏(拉不动 / 超时 / 0 字节)→ 加速站整站挂了,换直连是对的;
#   慢(能拉,就是慢)          → 这是国内服务器不挂代理时的常态。此时换直连只会更糟
#                              (Docker Hub 在国内更慢甚至不通),白重启两次 Docker 再还原。
# 所以下面只有「坏」才动 daemon.json;「慢」仅提示改用离线资源包。
PROBE_SLOW_SEC=25         # 探针约 4MB;超过这个秒数只是"慢",不改配置,只提醒用离线包
# 本机原本有没有这个镜像,决定了这次体检能测出什么:
#   没有 → pull 会真的下载 3.5MB,耗时能反映真实速度,快慢都测得出;
#   有   → pull 只校验 manifest、一个层都不下载,秒回 —— 这时只能判断"registry 通不通",
#          判断不了"快不快"。服务器上 alpine 是极常见的基础镜像,这种情况很普遍。
PROBE_PREEXISTING=0
$DOCKER image inspect "$PROBE_IMAGE" >/dev/null 2>&1 && PROBE_PREEXISTING=1
# 只判断"拉得动 / 拉不动"。超时给到 120 秒:真的很慢但能用的链路(0.05MB/s)也要让它拉完,
# 否则会被误判成"坏"而去换直连 —— 那才是灾难。
probe_pull() {            # 拉得动返回 0;耗时写进 PROBE_SEC,由调用方判断快慢
  local t0 t1 rc
  t0=$(date +%s)
  timeout 120 $DOCKER pull "$PROBE_IMAGE" >/dev/null 2>&1; rc=$?
  t1=$(date +%s)
  PROBE_SEC=$(( t1 - t0 ))
  return $rc
}
probe_is_slow() {         # 拉得动但很慢?(镜像本来就在时不下载任何层,计时无意义,一律不算慢)
  [[ $PROBE_PREEXISTING -eq 0 && $PROBE_SEC -gt $PROBE_SLOW_SEC ]]
}
set_registry_mirrors() {  # $1=逗号分隔的地址,空串=改直连(写空列表)。改动了才返回 0
  command -v python3 >/dev/null 2>&1 || return 1
  $SUDO env ODOOSH_SET_MIRRORS="${1:-}" python3 - <<'MIRROREOF'
import json, os, sys
p = "/etc/docker/daemon.json"
try:
    cfg = json.load(open(p)) if os.path.exists(p) and os.path.getsize(p) > 0 else {}
except Exception:
    sys.exit(1)
want = [x.strip() for x in (os.environ.get("ODOOSH_SET_MIRRORS") or "").split(",") if x.strip()]
old = cfg.get("registry-mirrors")
if old == want:
    sys.exit(1)                      # 没变化
if not want and not old:
    sys.exit(1)                      # 本来就没配加速站,没得摘
cfg["registry-mirrors"] = want       # 空列表 = 有意直连,上面的配置逻辑认它,重跑不会塞回来
json.dump(cfg, open(p, "w"), indent=2, ensure_ascii=False)
print(", ".join(old or []))
sys.exit(0)
MIRROREOF
}
if [[ $OFFLINE -eq 0 ]]; then
  info "体检:实测拉取速度(${PROBE_IMAGE},超过 ${PROBE_MAX_SEC} 秒就认为太慢)..."
  if probe_pull; then
    if probe_is_slow; then
      warn "镜像能拉但很慢(约 4MB 用了 ${PROBE_SEC} 秒,折合 $(( 4000 / (PROBE_SEC>0?PROBE_SEC:1) )) KB/s)。
      这在国内服务器不挂代理时是常态,不是故障,所以【不会】改动镜像加速配置 ——
      换直连只会更慢。但要有心理准备:后面拉 Odoo 镜像(每个 700MB 上下)会很久。
      更快的办法是用离线资源包:在有网机器上跑 deploy/export-offline.sh,
      把产出的 offline/ 拷到 $DATA_DIR/ 下再装,镜像直接 docker load,不走网络。"
    else
      ok "镜像拉取正常(${PROBE_SEC} 秒)"
    fi
  elif [[ $SKIP_DOCKER_CONFIG -eq 1 ]]; then
    warn "拉不动探针镜像(${PROBE_SEC} 秒后仍失败),但指定了 --skip-docker-config,不自动调整。
      请自行确认 registry-mirrors 可用,或把它设成 [] 改直连,然后 systemctl restart docker"
  elif DROPPED="$(set_registry_mirrors '')"; then
    warn "经加速站【完全拉不动】镜像(${PROBE_SEC} 秒后失败)—— 已自动摘掉加速站改直连,重试中...
      摘掉的是: $DROPPED
      (公共加速站经常整站挂 / 限流;改直连后重跑本脚本也不会再把它们塞回来)"
    $SUDO systemctl restart docker || warn "重启 Docker 失败,请手动 systemctl restart docker"
    sleep 3
    if probe_pull; then
      ok "直连 Docker Hub 正常(${PROBE_SEC} 秒),本次不使用镜像加速"
    else
      # 直连也不行:把原来的加速站还原回去,别把机器改得比原来更糟
      set_registry_mirrors "$DROPPED" >/dev/null 2>&1 || true
      $SUDO systemctl restart docker 2>/dev/null || true
      warn "直连同样拉不动(${PROBE_SEC} 秒)—— 这是真的网络问题,不是加速站的锅,已还原原有配置。
      后面拉基础镜像 / Odoo 镜像大概率会失败。请检查网络或代理,
      或把你确认可用的加速地址填进 /etc/docker/daemon.json 的 registry-mirrors
      (阿里云: 容器镜像服务 → 镜像加速器),然后 systemctl restart docker 再重跑本脚本"
    fi
  else
    warn "拉不动探针镜像(${PROBE_SEC} 秒后仍失败),而本机并没有配置镜像加速可摘。
      请检查网络 / 代理;纯内网的话请备好离线资源包(见 bash deploy/install.sh --help)"
  fi
  # 探针镜像是我们为体检拉的,用完删掉:既不给交付的服务器留垃圾,
  # 更重要的是下次重跑时 pull 会真的下载,体检才依然有效(留着就变成秒回的假通过)。
  # 本机原本就有的不动 —— 那是用户自己的镜像。
  if [[ $PROBE_PREEXISTING -eq 0 ]]; then
    $DOCKER rmi "$PROBE_IMAGE" >/dev/null 2>&1 || true
  fi
fi

# ---------- 2d. 内核参数:inotify 配额 + 多网络邻居表 ----------
# 这不是预防性调优,是踩过的坑:
# 1) inotify —— 开发档位实例带 --dev=reload(改代码免重启,教学场景刚需),Odoo 用 watchdog
#    递归监视全部 addons 目录:光 Odoo 自带 addons 就上万个子目录,每个占一个 inotify watch。
#    而配额是按宿主机 uid 计的、所有容器共用一份,默认 8192 只够跑 1~2 个实例。
#    超限时 Odoo 抛 OSError: [Errno 28] inotify watch limit reached、退出码 1 反复重启;
#    平台侧只看得到 409 Conflict(健康探测 exec 撞上容器重启)和「Odoo 未就绪」,
#    不翻容器日志极难定位 —— 所以宁可在安装时就调好。
# 2) 邻居表 —— 每个实例一个 bridge 网络,一个班的规模下 ARP 条目会超过默认的 1024 上限。
# 取值:每个 watch 内核约占 1KB,按「inotify 至多占总内存 1/8」折算 = MEM_MB x 128,
#      再夹到 [524288, 8388608](约合 50 ~ 800 个在线实例)。只升不降:已有更大的值原样保留。
#      上限给到 800 万是因为一台大内存机器跑 300+ 在线实例时,209 万(旧上限)会不够;
#      watch 由内核按实际用量分配,设高只是抬上限、不预占内存。
SYSCTL_FILE=/etc/sysctl.d/99-odoosh.conf
if [[ $SKIP_SYSCTL -eq 1 ]]; then
  info "--skip-sysctl:不修改内核参数(实例多了需自行调大 fs.inotify.max_user_watches)"
elif [[ ! -d /etc/sysctl.d ]]; then
  warn "没有 /etc/sysctl.d(容器内 / 精简系统?):跳过内核参数;实例多了会撞 inotify 上限"
else
  want_watches=$(( ${MEM_MB:-4096} * 128 ))
  [[ $want_watches -lt 524288 ]] && want_watches=524288
  [[ $want_watches -gt 8388608 ]] && want_watches=8388608
  cur_watches=$(cat /proc/sys/fs/inotify/max_user_watches 2>/dev/null || echo 0)
  [[ ${cur_watches:-0} -gt $want_watches ]] && want_watches=$cur_watches
  want_inst=8192
  cur_inst=$(cat /proc/sys/fs/inotify/max_user_instances 2>/dev/null || echo 0)
  [[ ${cur_inst:-0} -gt $want_inst ]] && want_inst=$cur_inst
  SYSCTL_BODY=$(cat <<EOF
# odoosh:多 Odoo 实例所需的内核参数(deploy/install.sh 生成;可手工调大,重跑安装不会调小)
# 每个开发档位实例的 --dev=reload 用 watchdog 递归监视 addons,约需 1 万个 watch
fs.inotify.max_user_watches = $want_watches
fs.inotify.max_user_instances = $want_inst
# 每实例一个 bridge 网络:邻居(ARP)表默认上限 1024,班级规模下不够
net.ipv4.neigh.default.gc_thresh1 = 1024
net.ipv4.neigh.default.gc_thresh2 = 4096
net.ipv4.neigh.default.gc_thresh3 = 8192
EOF
)
  if printf '%s
' "$SYSCTL_BODY" | $SUDO tee "$SYSCTL_FILE" >/dev/null 2>&1; then
    $SUDO sysctl -p "$SYSCTL_FILE" >/dev/null 2>&1 || true
    ok "内核参数: inotify watches=$want_watches / instances=$want_inst(约可支撑 $(( want_watches / 10000 )) 个实例)"
  else
    warn "写 $SYSCTL_FILE 失败(权限?):实例超过 1~2 个就会撞 inotify 上限,请手工设置 fs.inotify.max_user_watches"
  fi
fi

# ---------- 3. 端口占用检查 ----------
# 要查的不止 --port:compose 无条件绑 4 组端口(见 docker-compose.yml 的 web.ports)——
# HTTP、HTTPS(443)、ACME(8088)、以及端口直连模式的实例端口池。
# 只查一组的话,现场会在第 7 步以 "port is already allocated" 失败,
# 而那里的报错文案讲的是镜像加速限流 —— 排查方向被完全带偏(国内服务器装了宝塔,80/443 被占是常态)。
port_user() {  # 打印占用 $1 端口的监听行;没被占用则输出空
  if command -v ss >/dev/null 2>&1; then ss -ltnp 2>/dev/null | awk -v p=":$1" '$4 ~ p"$" {print; exit}'
  elif command -v netstat >/dev/null 2>&1; then netstat -ltnp 2>/dev/null | awk -v p=":$1" '$4 ~ p"$" {print; exit}'; fi
}
if [[ $SKIP_CHECKS -eq 0 ]]; then
  # 已经是我们自己的 web 容器占着,那是重复执行,不算冲突
  OURS=$(cd "$SCRIPT_DIR" && $DOCKER compose ps -q web 2>/dev/null || true)
  if [[ -z "$OURS" ]]; then
    if ! command -v ss >/dev/null 2>&1 && ! command -v netstat >/dev/null 2>&1; then
      warn "本机没有 ss / netstat,跳过端口占用预检;若第 7 步报 port is already allocated 即为端口冲突"
    fi
    PORT_CONFLICT=0
    _lo="${ENV_PORT_RANGE%%-*}"; _hi="${ENV_PORT_RANGE##*-}"
    for _spec in "${HTTP_PORT}|控制台 HTTP|--port"                  "${HTTPS_PORT}|控制台 HTTPS|--https-port"                  "${ACME_PORT}|ACME 证书签发/续期|--acme-port"                  "${_lo}|实例端口池起点|--env-port-range"                  "${_hi}|实例端口池终点|--env-port-range"; do
      _p="${_spec%%|*}"; _rest="${_spec#*|}"; _label="${_rest%%|*}"; _flag="${_rest##*|}"
      [[ -n "$_p" ]] || continue
      _l="$(port_user "$_p")"
      if [[ -n "$_l" ]]; then
        PORT_CONFLICT=1
        echo "    端口 ${_p}(${_label})已被占用:"
        echo "      $_l"
        echo "      → 停掉占用它的程序,或安装时加 ${_flag} 换一个"
      fi
    done
    if [[ $PORT_CONFLICT -eq 1 ]]; then
      die "上述端口被占用,compose 起不来(宝塔 / nginx / Apache 常占 80、443)。
    换端口示例: bash deploy/install.sh --port 8080 --https-port 8443 --acme-port 8089(其余参数同本次)
    注意:挪走 HTTP 主端口后通常要由宿主机 nginx 反代(需泛域名 server_name + WebSocket Upgrade 透传);
          ACME 端口是给 Let's Encrypt 续期用的,证书签发只认外部 80,反代时要把 /.well-known 转到它上面"
    fi
  fi
fi

# ---------- 4. 基础域名 ----------
# localhost = 只本机浏览器可访问;auto = <本机IP>.nip.io(依赖公网 DNS,国内解析不稳定,仅临时用);
# 正式环境请用自己的域名并做泛解析:*.odoo.example.com → 服务器公网 IP
if [[ -z "$BASE_DOMAIN" ]]; then
  if [[ -f "$ENV_FILE" ]]; then
    BASE_DOMAIN="$(env_get ODOOSH_BASE_DOMAIN)"
  fi
  if [[ -z "$BASE_DOMAIN" ]]; then
    if [[ $OFFLINE -eq 1 ]]; then
      # 内网没有公网 DNS:auto(<IP>.nip.io)解析不了,只能用内网域名或端口直连模式
      BASE_DOMAIN=localhost
      warn "离线安装未指定 --base-domain,暂用「localhost」。内网请二选一:
      a) 装完在「系统设置 → 平台 → 实例访问模式」改为「端口」,每个实例分配独立端口直连(内网推荐)
      b) 内网 DNS 上做泛解析 *.odoo.example.com → 本机 IP,重跑时加 --base-domain odoo.example.com"
    else
      # WSL / 本机开发用 localhost;云服务器(有 systemd-detect-virt 且非 wsl)默认 auto 并提醒换成正式域名
      if grep -qi microsoft /proc/version 2>/dev/null; then BASE_DOMAIN=localhost; else BASE_DOMAIN=auto; fi
      warn "未指定 --base-domain,本次使用「${BASE_DOMAIN}」。正式环境请用: --base-domain odoo.example.com(需泛解析 *.odoo.example.com);装好后也可在「系统设置 → 平台 → 基础域名」修改"
    fi
  fi
fi

# ---------- 5. 数据目录 ----------
# offline/:内网资源目录(镜像 tar + 企业版代码)。联网安装也建出来,方便日后往里放资源
SUBDIRS=(platform-db tenants repos builds backups enterprise nginx nginx-logs certs
         offline/images offline/enterprise offline/packages offline/pip/instance offline/pip/backend offline/npm)
if mkdir -p "$DATA_DIR" 2>/dev/null && [[ -w "$DATA_DIR" ]]; then
  for d in "${SUBDIRS[@]}"; do mkdir -p "$DATA_DIR/$d"; done
else
  [[ -n "$SUDO" ]] && warn "需要 sudo 权限创建 / 修正 $DATA_DIR"
  $SUDO mkdir -p "$DATA_DIR"
  for d in "${SUBDIRS[@]}"; do $SUDO mkdir -p "$DATA_DIR/$d"; done
  # 属主修正:platform-db 一旦初始化过就归容器内的 postgres(uid 999)所有,
  # 递归 chown 会让 PG 下次启动直接报 "data directory has wrong ownership"。
  # 所以只有全新的空目录才递归;已有数据时仅把本次新建的空目录归过来。
  if [[ -z "$(ls -A "$DATA_DIR/platform-db" 2>/dev/null)" ]]; then
    $SUDO chown -R "$(id -u):$(id -g)" "$DATA_DIR"
  else
    warn "$DATA_DIR 里已有平台数据:跳过递归 chown(避免破坏 platform-db 的属主),只修正新建的空目录"
    $SUDO chown "$(id -u):$(id -g)" "$DATA_DIR"
    for d in "${SUBDIRS[@]}"; do
      [[ "$d" == platform-db || "$d" == tenants ]] && continue
      $SUDO chown "$(id -u):$(id -g)" "$DATA_DIR/$d" 2>/dev/null || true
    done
  fi
fi
ok "数据目录: $DATA_DIR"

# ---------- 5b. 项目下的离线资源 → 同步到数据目录 ----------
# 资源包放项目下(<项目根>/offline 或 deploy/offline)也能装,但分两类:
#   · 镜像 tar、Docker 安装包 —— 只有本脚本(宿主机侧)读,放哪都行;
#   · 企业版代码、实例 pip wheel —— 是 api / 实例容器在运行期读的,而容器只挂了数据目录
#     (见 docker-compose.yml 的 volumes),项目目录对容器不可见 → 必须落到 <数据目录>/offline/ 下。
# 所以这里把后两类自动搬过去,省得现场发现"企业版模块识别不到""部署时还是去连 PyPI"。
DATA_OFFLINE="$(cd "$DATA_DIR/offline" 2>/dev/null && pwd || echo "$DATA_DIR/offline")"
if [[ -n "$OFFLINE_ROOT" && "$OFFLINE_ROOT" != "$DATA_OFFLINE" ]]; then
  for sub in enterprise pip; do
    src="$OFFLINE_ROOT/$sub"
    [[ -d "$src" && -n "$(ls -A "$src" 2>/dev/null)" ]] || continue
    info "同步 $sub($(du -sh "$src" 2>/dev/null | cut -f1)):$src → $DATA_OFFLINE/$sub"
    echo "       (容器只看得到数据目录,这两类资源必须放在那儿)"
    mkdir -p "$DATA_OFFLINE/$sub"
    cp -a -u "$src"/. "$DATA_OFFLINE/$sub"/ 2>/dev/null \
      || cp -a "$src"/. "$DATA_OFFLINE/$sub"/ \
      || warn "  同步 $sub 失败,请手工执行: cp -a $src/. $DATA_OFFLINE/$sub/"
  done
fi

# ---------- 6. 生成 .env ----------
# 先拦一种很容易踩、现象又极难懂的情况:数据目录里已经有平台库,但 deploy/.env 没了
# (换源码目录 / 重新 clone / 只把数据盘搬过来 / 拷贝源码时漏了这个被 .gitignore 的文件)。
# 这时脚本会生成一套全新的随机密码,而 PostgreSQL 的数据目录非空就不会重新初始化 ——
# 新密码根本不生效,api 永远连不上库;就算连上,ODOOSH_SECRET_KEY 也变了,
# 库里加密保存的凭据(Git token、AI key、远程备份密钥)会全部解不开。
if [[ ! -f "$ENV_FILE" && -n "$(ls -A "$DATA_DIR/platform-db" 2>/dev/null)" ]]; then
  die "$DATA_DIR/platform-db 里已经有平台数据库,却找不到 $ENV_FILE。
    直接装下去会生成一套新的数据库密码和 ODOOSH_SECRET_KEY,但 PostgreSQL 数据目录非空时
    不会用新密码重新初始化 —— 结果是 api 永远连不上库,且库里加密保存的凭据全部失效。
    三选一:
      1) 找回原来的 deploy/.env 放回去再重跑(推荐)。
         迁移 / 换源码目录 / 打包交付时务必带上它 —— 它被 .gitignore 忽略,最容易漏。
      2) 数据不要了,从头开始:  bash deploy/uninstall.sh --purge  然后重跑本脚本
      3) 只丢弃平台库、保留租户数据:先备份,再删掉 $DATA_DIR/platform-db 后重跑
         (注意:平台库存着实例 / 租户 / 仓库 / 用户等全部元数据,删了等于平台重装,
          租户的 Odoo 数据虽在但需要重新登记)"
fi

# .env 里没有该键就补上(不覆盖用户改过的值)
env_ensure() {
  grep -q "^$1=" "$ENV_FILE" 2>/dev/null || { echo "$1=$2" >>"$ENV_FILE"; info "已补充 $1=$2 到 .env"; }
}

if [[ -f "$ENV_FILE" ]]; then
  ok "沿用已有配置 $ENV_FILE"
  # 老版本 .env 没有 TZ:补上(不改其它项)
  grep -q '^TZ=' "$ENV_FILE" || { echo "TZ=$TZ_NAME" >>"$ENV_FILE"; info "已补充 TZ=$TZ_NAME 到 .env"; }
  # 老版本 .env 里没有这几个端口键(以前靠 compose 的默认值兜底):显式写出来,
  # 端口预检、防火墙提示、以及日后手工改端口才有据可依
  env_ensure ODOOSH_HTTPS_PORT "$HTTPS_PORT"
  env_ensure ODOOSH_ACME_PORT "$ACME_PORT"
  env_ensure ODOOSH_ENV_PORT_RANGE "$ENV_PORT_RANGE"
  env_ensure ODOOSH_SELINUX_OPT "$SELINUX_OPT"
  # SELinux 是后来才开启的(或这份 .env 来自非 SELinux 机器):必须改成 label:disable,否则容器读不到数据目录
  if [[ "$SELINUX_OPT" == "label:disable" && "$(env_get ODOOSH_SELINUX_OPT)" != "label:disable" ]]; then
    sed -i '/^ODOOSH_SELINUX_OPT=/d' "$ENV_FILE"
    echo "ODOOSH_SELINUX_OPT=label:disable" >>"$ENV_FILE"
    info "本机 SELinux 为 Enforcing,已把 .env 的 ODOOSH_SELINUX_OPT 改为 label:disable"
  fi
  # 源码路径对齐:仓库换过位置(离线交付常见 —— 有网机器打包 → 内网 /opt/odoosh-cn)后,
  # .env 里的旧路径会让控制台「重启 / 更新平台」找不到源码
  _cur_src="$(cd "$SCRIPT_DIR/.." && pwd)"
  if [[ "$(env_get ODOOSH_SRC_DIR)" != "$_cur_src" ]]; then
    sed -i '/^ODOOSH_SRC_DIR=/d' "$ENV_FILE"       # 删行再追加,避免路径里的 & / \ 被 sed 当特殊字符
    echo "ODOOSH_SRC_DIR=$_cur_src" >>"$ENV_FILE"
    info "已把 .env 的 ODOOSH_SRC_DIR 对齐到当前源码路径 $_cur_src"
  fi
else
  ADMIN_PASSWORD="${ADMIN_PASSWORD:-$(rand 12)}"   # 未指定则随机生成(安装完成后会打印),不再默认 admin/admin
  cat >"$ENV_FILE" <<EOF
ODOOSH_HTTP_PORT=$HTTP_PORT
# 以下三组端口 compose 会无条件绑定;改了要同步安全组 / 防火墙,并重建 web 容器
ODOOSH_HTTPS_PORT=$HTTPS_PORT
ODOOSH_ACME_PORT=$ACME_PORT
ODOOSH_ENV_PORT_RANGE=$ENV_PORT_RANGE
ODOOSH_DATA_DIR=$DATA_DIR
# 平台源码仓库路径(控制台「重启/更新平台」用它执行 git pull / 重新构建)
ODOOSH_SRC_DIR=$(cd "$SCRIPT_DIR/.." && pwd)
# 环境域名后缀:<环境>.<租户>.<基础域名>
#   localhost = 只本机浏览器可访问;auto = 自动用 <本机IP>.nip.io(局域网/公网可访问,需能解析公网 DNS);
#   有自己的域名时填域名(如 odoo.example.com,DNS 需泛解析 *.odoo.example.com → 本机 IP)
ODOOSH_BASE_DOMAIN=$BASE_DOMAIN
# 平台容器时区:自动备份「每天几点」、闲置休眠等按此时区计算
TZ=$TZ_NAME
# SELinux(RHEL 系):Enforcing 时必须是 label:disable,否则平台容器读不到 docker.sock 与数据目录;
# 非 SELinux 系统是 no-new-privileges:false —— Docker 的默认值,等于什么都不做
ODOOSH_SELINUX_OPT=$SELINUX_OPT

POSTGRES_USER=odoosh
POSTGRES_PASSWORD=$(rand 24)
POSTGRES_DB=odoosh

ODOOSH_SECRET_KEY=$(rand 48)
ODOOSH_ADMIN_USER=admin
ODOOSH_ADMIN_PASSWORD=$ADMIN_PASSWORD

PIP_INDEX_URL=https://pypi.tuna.tsinghua.edu.cn/simple
NPM_REGISTRY=https://registry.npmmirror.com
EOF
  chmod 600 "$ENV_FILE"
  ok "已生成 $ENV_FILE"
fi

# ---------- 6b. 镜像就位:本地包优先,缺的再联网补 ----------
# 本机镜像盘点(下面多处要用,统一算一次)
have_img() { $DOCKER image inspect "$1" >/dev/null 2>&1; }
count_odoo() { $DOCKER images --format '{{.Repository}}:{{.Tag}}' | grep -cE '^(odoo|odoosh-base):[0-9]+' || true; }
ALL_PRESENT=1
for img in odoosh/api:dev odoosh/web:dev postgres:16 pgvector/pgvector:pg16; do
  have_img "$img" || { ALL_PRESENT=0; break; }
done
[[ "$(count_odoo)" -gt 0 ]] || ALL_PRESENT=0

# 有本地镜像包就全部导入(不管在不在线 —— 本地有就用,省下载)。
# 重复执行时不该再 load 一遍几 GB 的 tar,但也不能简单地"镜像齐了就跳过":
# 往目录里新丢一个 odoo-20.tar 时必须能导进来。所以用「tar 清单指纹」判断:
# 清单(文件名+大小+mtime)与上次导入时一致、且关键镜像都还在本机 → 才跳过。
IMPORT_STAMP=""
TAR_FINGERPRINT=""
if [[ $HAVE_TARS -eq 1 ]]; then
  [[ -n "$OFFLINE_ROOT" ]] && IMPORT_STAMP="$OFFLINE_ROOT/.imported"
  TAR_FINGERPRINT="$(cd "$OFFLINE_DIR" && stat -c '%n %s %Y' -- *.tar *.tar.gz *.tgz 2>/dev/null | sort || true)"
fi
SKIP_LOAD=0
if [[ $HAVE_TARS -eq 1 && $ALL_PRESENT -eq 1 && -n "$IMPORT_STAMP" && -f "$IMPORT_STAMP" ]]; then
  [[ "$TAR_FINGERPRINT" == "$(cat "$IMPORT_STAMP" 2>/dev/null || true)" ]] && SKIP_LOAD=1
fi
if [[ $HAVE_TARS -eq 1 && $SKIP_LOAD -eq 1 ]]; then
  info "镜像包与上次导入时一致且镜像都在本机,跳过重复导入(往 $OFFLINE_DIR 放新 tar 后会自动重新导入)"
elif [[ $HAVE_TARS -eq 1 ]]; then
  shopt -s nullglob
  TARS=("$OFFLINE_DIR"/*.tar "$OFFLINE_DIR"/*.tar.gz "$OFFLINE_DIR"/*.tgz)
  shopt -u nullglob
  info "导入本地镜像包(共 ${#TARS[@]} 个,GB 级的包每个约需 1~3 分钟)..."
  for t in "${TARS[@]}"; do
    echo "    load $(basename "$t")  ($(du -h "$t" 2>/dev/null | cut -f1))"
    $DOCKER load -i "$t" >/dev/null || die "导入 $t 失败。文件可能在拷贝途中损坏,可校验一下:
    cd $OFFLINE_DIR && sha256sum -c SHA256SUMS"
  done
  ok "镜像导入完成"
  # 记下这批 tar 的指纹,下次同样的包就不再重复导入(写不进去也无所谓,大不了下次再导一遍)
  [[ -n "$IMPORT_STAMP" ]] && { printf '%s\n' "$TAR_FINGERPRINT" >"$IMPORT_STAMP" 2>/dev/null || true; }
fi

# 平台三件套:odoosh/api、odoosh/web 是本地构建产物(registry 上没有),postgres:16 联网时 compose 会自己拉
MISSING=""
for img in odoosh/api:dev odoosh/web:dev postgres:16; do
  $DOCKER image inspect "$img" >/dev/null 2>&1 || MISSING="$MISSING $img"
done
if [[ -n "$MISSING" ]]; then
  if [[ $OFFLINE -eq 1 ]]; then
    die "离线安装缺少平台必需镜像:$MISSING
    odoosh/api、odoosh/web 是本地构建产物,registry 上拉不到,只能从资源包导入。
    请在有网机器上先跑一次 bash deploy/install.sh 构建出镜像,再执行 bash deploy/export-offline.sh
    生成资源包,把 offline/ 拷到 $DATA_DIR/ 后重跑本脚本。"
  else
    info "以下镜像本地还没有,稍后由构建 / compose 联网获取:$MISSING"
  fi
fi

# 租户数据库镜像:创建实例时才用,但那时现场拉容易超时,装机阶段就备好
if ! $DOCKER image inspect pgvector/pgvector:pg16 >/dev/null 2>&1; then
  if net_ok; then
    info "本地没有租户数据库镜像,联网拉取 pgvector/pgvector:pg16 ..."
    timeout 600 $DOCKER pull pgvector/pgvector:pg16 \
      && ok "  已拉取 pgvector/pgvector:pg16" \
      || warn "拉取 pgvector/pgvector:pg16 失败(不影响本次安装,但【创建实例会失败】);网络恢复后补: docker pull pgvector/pgvector:pg16"
  else
    warn "缺少租户数据库镜像 pgvector/pgvector:pg16 —— 平台能启动,但创建实例时会因拉不到镜像而失败。
      请在有网机器上 docker save pgvector/pgvector:pg16 -o pgvector.tar,放进 $DATA_DIR/offline/images/ 后重跑本脚本"
  fi
fi

# Odoo 镜像:联网时平台会在创建实例时按需拉取(装机阶段不预拉,省几 GB);离线则必须提前备好
ODOO_N=$(count_odoo)
if [[ ${ODOO_N:-0} -gt 0 ]]; then
  ok "已就绪的 Odoo 镜像: $($DOCKER images --format '{{.Repository}}:{{.Tag}}' | grep -E '^(odoo|odoosh-base):[0-9]+' | tr '\n' ' ')"
elif [[ $OFFLINE -eq 1 ]]; then
  warn "没有任何 Odoo 镜像 —— 内网无法从源码自建(要联网 clone + pip),创建实例会失败。
      请在有网机器上 docker pull odoo:19 && docker save odoo:19 -o odoo-19.tar,
      把 tar 放进 $DATA_DIR/offline/images/ 后重跑本脚本(或在平台「基础镜像」页导入)"
else
  info "本机还没有 Odoo 镜像;创建实例时平台会自动拉取,也可装完后在「基础镜像」页预先拉好"
fi

# ---------- 7. 构建并启动 ----------
cd "$SCRIPT_DIR"
BUILD_OK=0
# 用现成镜像还是重新构建:离线必然用现成的;联网时若本次从资源包导入了平台镜像,也按"本地有就用"跳过构建
# (纯联网安装 —— 没有资源包 —— 仍然每次 --build,重复执行会应用最新源码,与原有行为一致)
USE_PREBUILT=0
if [[ $OFFLINE -eq 1 ]]; then
  USE_PREBUILT=1
elif [[ $HAVE_TARS -eq 1 ]] && $DOCKER image inspect odoosh/api:dev >/dev/null 2>&1 \
     && $DOCKER image inspect odoosh/web:dev >/dev/null 2>&1; then
  USE_PREBUILT=1
  warn "检测到本地资源包里的平台镜像,本次【跳过构建】,直接用现成镜像启动。
      改过源码要按当前代码重建的话,加 --online 重跑;或把 $OFFLINE_DIR 下的
      odoosh-platform.tar 挪走(只要数据目录里还有镜像 tar,以后每次都会跳过构建)。"
fi
# compose 的输出留一份,失败时用来分辨「端口被占」和「镜像拉不下来」——
# 这两种失败的处置办法完全相反,报错指错方向会让现场白查很久。
BUILD_LOG="$(mktemp -t odoosh-up.XXXXXX)"
trap 'rm -f "$BUILD_LOG"' EXIT
# 端口冲突:重试多少次都没用,而且和镜像 / 网络毫无关系 —— 单独识别出来
port_bind_failed() {
  grep -qiE 'port is already allocated|address already in use|failed to bind|Bind for .* failed' "$BUILD_LOG" 2>/dev/null || return 1
  echo
  warn "启动失败的原因是【端口被占用】,不是网络或镜像问题(上面的日志里有 port is already allocated)。"
  echo "    compose 要绑这几个端口: ${HTTP_PORT}(HTTP) ${HTTPS_PORT}(HTTPS) ${ACME_PORT}(ACME) ${ENV_PORT_RANGE}(实例端口池)"
  echo "    看谁占着:  sudo ss -ltnp | grep -E ':(${HTTP_PORT}|${HTTPS_PORT}|${ACME_PORT})'"
  echo "    换端口重跑: bash deploy/install.sh --port 8080 --https-port 8443 --acme-port 8089(其余参数同本次)"
  echo "    注意:.env 已经生成,端口以 .env 为准 —— 换端口请直接改 $ENV_FILE 里的 ODOOSH_*_PORT 再重跑"
  return 0
}
if [[ $USE_PREBUILT -eq 1 ]]; then
  # --no-build 让「镜像不存在」立刻报错,而不是退化成联网构建
  # (内网构建必然卡在 pip / npm 上,错误信息还很难懂)
  info "平台镜像已就位,跳过构建,直接启动..."
  $DOCKER compose --env-file "$ENV_FILE" up -d --no-build 2>&1 | tee "$BUILD_LOG" && BUILD_OK=1
  if [[ $BUILD_OK -ne 1 ]]; then
    port_bind_failed && die "端口冲突,见上。"
    die "启动失败。请看上面的报错,以及: $DOCKER compose --env-file $ENV_FILE logs"
  fi
else
  info "构建镜像并启动(首次需拉取 python / node / nginx / postgres 基础镜像并安装依赖,约 3~10 分钟,请耐心等待)..."
  # 公共镜像加速站经常 429 限流 / 瞬断:失败自动重试 3 次(基础镜像一旦拉下来就会命中本地缓存)
  PORT_FAIL=0
  for attempt in 1 2 3; do
    if $DOCKER compose --env-file "$ENV_FILE" up -d --build 2>&1 | tee "$BUILD_LOG"; then BUILD_OK=1; break; fi
    if port_bind_failed; then PORT_FAIL=1; break; fi   # 端口冲突重试无意义,立刻跳出
    warn "构建 / 启动失败(第 ${attempt} 次),15 秒后重试..."; sleep 15
  done
  if [[ $BUILD_OK -ne 1 ]]; then
    [[ $PORT_FAIL -eq 1 ]] && die "端口冲突,见上。换端口后重跑即可,与镜像 / 网络无关。"
    echo
    die "镜像构建失败。常见原因是拉取基础镜像被加速站限流(429)或网络不通:
    1) 用云厂商自己的加速器重跑:  bash deploy/install.sh --registry-mirror https://<你的ID>.mirror.aliyuncs.com(其余参数同本次)
    2) 或手动编辑 /etc/docker/daemon.json 的 registry-mirrors 后 systemctl restart docker,再重跑本脚本
    3) 纯内网 / 无外网:改用离线安装,见 bash deploy/install.sh --help"
  fi
fi

# ---------- 7b. 预拉「平台更新助手」镜像(控制台「重构并重启」用;首次点击时现场拉会超时) ----------
if ! $DOCKER image inspect docker:27-cli >/dev/null 2>&1; then
  if [[ $OFFLINE -eq 1 ]]; then
    warn "缺少 docker:27-cli(控制台「重构并重启」用),离线环境不影响平台其它功能"
  else
    info "预拉平台更新助手镜像 docker:27-cli ..."
    timeout 180 $DOCKER pull docker:27-cli >/dev/null 2>&1 || warn "拉取 docker:27-cli 失败(不影响安装);首次使用「重构并重启」前请手动执行: docker pull docker:27-cli"
  fi
fi

# ---------- 8. 等待就绪 ----------
PORT="$(env_get ODOOSH_HTTP_PORT)"; PORT="${PORT:-$HTTP_PORT}"
# 健康检查不能只认 curl:很多最小化系统 / 云镜像没装它,那样会白等 2 分钟再假报"未就绪"。
# 依次尝试 curl → wget → 平台 web 容器内的 wget(nginx:alpine 自带)。
health_ok() {
  local url="http://127.0.0.1:${PORT}/api/health"
  if command -v curl >/dev/null 2>&1; then
    curl -fsS "$url" >/dev/null 2>&1
  elif command -v wget >/dev/null 2>&1; then
    wget -q -O /dev/null "$url" 2>/dev/null
  else
    $DOCKER compose --env-file "$ENV_FILE" exec -T web wget -q -O /dev/null http://api:8000/api/health 2>/dev/null
  fi
}
if ! command -v curl >/dev/null 2>&1 && ! command -v wget >/dev/null 2>&1; then
  info "本机没有 curl / wget,改用 web 容器内部探测健康状态"
fi
info "等待服务就绪..."
for i in $(seq 1 60); do
  if health_ok; then
    ADMIN_USER="$(env_get ODOOSH_ADMIN_USER)"
    ADMIN_PW="$(env_get ODOOSH_ADMIN_PASSWORD)"
    DOMAIN="$(env_get ODOOSH_BASE_DOMAIN)"
    IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    PUB_IP=""
    if [[ $OFFLINE -eq 0 ]] && command -v curl >/dev/null 2>&1; then
      PUB_IP=$(curl -fsS -m 3 https://myip.ipip.net 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | head -1 || true)
    fi
    echo
    ok "OdooshCN 已启动!"
    echo "    访问地址:  http://localhost:${PORT}   (内网 http://${IP}:${PORT}${PUB_IP:+;公网 http://${PUB_IP}:${PORT}})"
    echo "    管理员:    ${ADMIN_USER} / ${ADMIN_PW}   (请登录后立即修改)"
    # 终端一刷就过去了,而这个密码是随机生成的 —— 必须告诉用户日后去哪儿查,否则只能重装
    echo "               忘了密码可随时查看: grep ADMIN_PASSWORD ${ENV_FILE}"
    echo "    API 文档:  http://localhost:${PORT}/docs"
    SHOW_DOMAIN="$DOMAIN"; [[ "$DOMAIN" == "auto" ]] && SHOW_DOMAIN="${IP}.nip.io(auto)"
    echo "    基础域名:  ${SHOW_DOMAIN}   (实例地址 = <实例>.<公司>.${SHOW_DOMAIN%%(*};可在「系统设置 → 平台」修改)"
    echo "    停止:      docker compose -f $SCRIPT_DIR/docker-compose.yml --env-file $ENV_FILE down"
    echo "    查看日志:  docker compose -f $SCRIPT_DIR/docker-compose.yml --env-file $ENV_FILE logs -f"
    echo
    # 本机防火墙:云安全组之外还有这一层,而健康检查走的是 127.0.0.1,防火墙拦不住 ——
    # 所以「脚本说装好了、浏览器却打不开」绝大多数就是这里。主动探一次,把命令直接给出来。
    _fw=""
    if command -v firewall-cmd >/dev/null 2>&1 && [[ "$($SUDO firewall-cmd --state 2>/dev/null || true)" == running ]]; then
      _fw=firewalld
    elif command -v ufw >/dev/null 2>&1 && $SUDO ufw status 2>/dev/null | head -1 | grep -qi active; then
      _fw=ufw
    fi
    case "$_fw" in
      firewalld)
        warn "检测到 firewalld 正在运行 —— 默认会拦掉外部访问。放行命令:"
        echo "      sudo firewall-cmd --permanent --add-port=${PORT}/tcp --add-port=${HTTPS_PORT}/tcp --add-port=${ENV_PORT_RANGE}/tcp"
        echo "      sudo firewall-cmd --reload" ;;
      ufw)
        warn "检测到 ufw 已启用 —— 默认会拦掉外部访问。放行命令:"
        echo "      sudo ufw allow ${PORT}/tcp && sudo ufw allow ${HTTPS_PORT}/tcp && sudo ufw allow ${ENV_PORT_RANGE//-/:}/tcp" ;;
      *)
        echo "    本机没有启用 firewalld / ufw;云服务器请在【安全组】放行 TCP ${PORT}、${HTTPS_PORT}(端口直连模式还要 ${ENV_PORT_RANGE})" ;;
    esac
    [[ "$DOMAIN" == "auto" ]] && echo "    当前基础域名为 auto(nip.io),国内 DNS 解析不稳定,仅适合临时体验;正式使用请改为自己的泛解析域名"
    # WSL2 专属提示:这几条都不是平台的问题,但不说清楚会让人以为服务不稳定。
    # (脚本前面已用同样的方式判断过 WSL,那里用来把 base-domain 默认成 localhost)
    if grep -qi microsoft /proc/version 2>/dev/null; then
      _d="${WSL_DISTRO_NAME:-<发行版>}"
      echo
      echo "    == 检测到 WSL2,有三件事要知道 =="
      echo "    1) WSL 空闲时会把整个发行版关掉 —— 表现是浏览器时常连不上,而容器日志一切正常。"
      echo "       让一个客户端一直连着即可,在 Windows 侧执行(二选一):"
      echo "         wsl -d ${_d}                       # 开个窗口挂着"
      echo "         Start-Process -WindowStyle Hidden wsl.exe -ArgumentList '-d','${_d}','-u','root','--','sleep','infinity'"
      echo "       (.wslconfig 里的 vmIdleTimeout 不解决这个问题,实测无效)"
      echo "    2) 镜像网络下 Windows 的 System 进程通常占着 [::]:80,所以别用默认端口,本次是 ${PORT}。"
      echo "    3) vhdx 只涨不缩(WSL 2.7 已禁用 sparseVhd);df 显示的 1TB 是虚拟上限,"
      echo "       真实上限是 vhdx 所在 Windows 盘的剩余空间。"
      echo "    详见源码 docs/wsl2.md"
    fi
    if [[ "$DOMAIN" == "localhost" && $OFFLINE -eq 0 ]]; then
      echo "    当前基础域名为 localhost:实例只能在本机浏览器访问;服务器部署请改为 auto 或自己的泛解析域名"
    fi
    if [[ $OFFLINE -eq 1 ]]; then
      echo
      echo "    == 离线安装,请再做三件事 =="
      echo "    1) 登录后到「系统设置 → 平台 → 实例访问模式」改为「端口」"
      echo "       内网没有公网 DNS,域名分流用不了;端口模式给每个实例分配 ${ODOOSH_ENV_PORT_RANGE:-10001-10020} 里的独立端口"
      echo "       (改完需放行该端口段:sudo ufw allow 10001:10020/tcp)"
      if compgen -G "${DATA_DIR}/offline/pip/instance"/*.whl >/dev/null 2>&1 || compgen -G "${DATA_DIR}/offline/pip/instance"/*.tar.gz >/dev/null 2>&1; then
        echo "    2) 客户模块的 Python 依赖已就绪(${DATA_DIR}/offline/pip/instance/),"
        echo "       部署实例时平台会自动挂载该目录并用本地 wheel 安装,无需内网 PyPI。"
        echo "       日后新增依赖:在有网机器上 bash deploy/fetch-offline-deps.sh --only pip --instance-req <requirements.txt>"
      else
        echo "    2) 「系统设置 → 部署」里关掉「部署时自动安装依赖」—— 该开关默认开启,会在实例里"
        echo "       pip install -r requirements.txt;内网没有 PyPI 源会导致部署失败并回退。"
        echo "       (或在有网机器上跑 deploy/fetch-offline-deps.sh --only pip --instance-req <客户模块的 requirements.txt>,"
        echo "        把产出的 offline/pip/instance/ 拷到 ${DATA_DIR}/offline/pip/instance/,平台会自动用本地 wheel)"
      fi
      if [[ $HAVE_TARS -eq 1 ]]; then
        echo "    3) 镜像 tar 已导入 Docker,${OFFLINE_DIR} 里的文件可在「基础镜像」页确认后删除以释放磁盘"
      else
        echo "    3) 日后要补镜像:把 tar 丢进 ${DATA_DIR}/offline/images/,在「基础镜像」页点扫描导入"
      fi
      echo "       企业版代码目录 ${DATA_DIR}/offline/enterprise/ 不能删 —— 实例容器直接挂载它"
      echo
      echo "    日后补充资源:新镜像 tar 丢进 ${DATA_DIR}/offline/images/,在「基础镜像」页点扫描即可导入"
      echo "    ⚠ 内网镜像拉不回来:清理磁盘时不要执行 docker system prune -a / docker image prune -a"
      echo "    运维命令与排障速查:见源码 docs/offline-checklist.md"
    fi
    exit 0
  fi
  sleep 2
done
warn "服务未在预期时间内就绪,查看日志:"
$DOCKER compose --env-file "$ENV_FILE" logs --tail 50
exit 1
