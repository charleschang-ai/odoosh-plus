# Odoo 升级功能调研与计划（2026-08-25）

## 一、OpenUpgrade 到底做了什么

OpenUpgrade（OCA 维护，AGPL-3）**不是一个独立的迁移引擎**，它只是利用 Odoo 自带的
migration manager 机制，为官方社区版模块补上了官方不开源的那部分迁移脚本。

### 1. Odoo 自带的迁移机制（OpenUpgrade 的地基）

- 每个模块可以有 `migrations/<版本号>/` 目录，放 `pre-*.py` / `post-*.py` / `end-*.py`，
  各含一个 `migrate(cr, version)` 函数。
- 执行 `odoo -u <module>` 时，如果数据库里记录的模块版本低于目录版本号，脚本自动触发：
  - **pre**：模块 ORM 加载前（纯 SQL 阶段，改表结构、改名最安全的时机）
  - **post**：该模块加载后（可以用 ORM）
  - **end**：所有模块加载完之后（Odoo 9+，跨模块的收尾工作）
- 这套机制是 Odoo 核心自带的，官方 upgrade.odoo.com 和 OpenUpgrade 用的是同一个底座。

### 2. OpenUpgrade 仓库结构（14.0 之后的新架构）

14.0 起 OpenUpgrade **不再是 odoo/odoo 的 fork**，变成两个普通 addon：

| 组件 | 作用 |
|---|---|
| `openupgrade_framework` | server-wide 模块，monkey-patch 掉升级时会碍事的行为（约束检查、noupdate 覆盖、record 删除保护等） |
| `openupgrade_scripts` | 每个官方模块的 `migrations/` 脚本 + `openupgrade_analysis.txt`（两版 schema diff 分析文件） |
| `openupgradelib`（独立仓库，pip 装） | 脚本用的工具函数库：`rename_fields`、`merge_records`、`map_values`、`logged_query` 等 |

分支按目标版本组织：19.0 分支负责 18.0→19.0，18.0 分支负责 17.0→18.0，以此类推。

### 3. 标准运行流程

```bash
# 1. 新版本 Odoo 源码 + 对应分支的 OpenUpgrade 放进 addons_path
pip install git+https://github.com/OCA/openupgradelib.git@master

# 2. 对【旧版本数据库的副本】执行：
odoo -d <db_copy> \
     --update all --stop-after-init \
     --load=base,web,openupgrade_framework \
     --upgrade-path=/path/to/openupgrade_scripts/scripts

# 3. 看日志 → 修问题 → 恢复副本重跑，循环到干净通过
```

自定义模块改名/合并用环境变量声明：
`OPENUPGRADE_RENAMED_MODULES='{"old":"new"}'`、`OPENUPGRADE_MERGED_MODULES='{"old":"base"}'`。

### 4. 脚本是怎么写出来的（分析工具链）

`openupgrade_records` 在新旧两个版本各导出 模型/字段/XML 记录，diff 出
`openupgrade_analysis.txt`（哪些字段改名/删除/类型变化、哪些 noupdate 数据变了），
贡献者拿着这份分析文件手写迁移脚本。**这条工具链对任何模块通用**——以后要给
企业版或第三方模块写脚本，走的也是这条路。

## 二、坑清单（按严重程度排序）

1. **只能逐版本升级**。15→18 必须 15→16→17→18 跑三轮，每轮换一套
   Odoo 源码 + OpenUpgrade 分支 + Python 环境。工作量、出错面线性乘三。

2. **覆盖率有缺口，且新版本滞后**。以 18.0→19.0 为例（2026-08 查证）：
   约 800 个官方模块中 ~150 Done、~250 Nothing to do、**~400 尚无脚本**
   （多数是 l10n_* 本地化和小胶水模块，但必须逐个核对）。
   核心模块 account/stock/sale/mrp/mail 均为 Done。
   → **升级前必须拿 `ir_module_module` 已装清单对照 coverage 页逐个检查**，
   缺脚本的模块要么等社区、要么自己写、要么升级前卸载。

3. **第三方/OCA 模块脚本不在这个仓库**。OCA 各模块的迁移脚本在各自仓库的
   对应版本分支里；纯第三方（App Store 买的）大概率什么都没有。
   模块在目标版本没有对应版本 = 升级失败的最大单一来源。

4. **企业版模块完全不覆盖**（法律原因 OCA 不能做）。库里装了企业模块直接跑会坏。

5. **旧表旧列不会删**。OpenUpgrade 策略保守，旧列改名为 `openupgrade_legacy_*`
   留在库里。升级稳定后要用 OCA `database_cleanup` 模块清理 + VACUUM，
   否则将来版本重用同名列时会出诡异冲突。

6. **升级过程中的库是"带电作业"**。framework 会禁掉部分约束和保护，中途
   状态的库不可用于业务；必须 `--stop-after-init`，且绝不对生产库直接跑。

7. **cron / 外发邮件要先掐掉**（neutralize）：升级副本时 ir_cron、
   ir_mail_server、fetchmail 必须禁用，否则测试库会真发邮件、真跑定时任务。

8. **迁移脚本对"全新安装"也会触发**。写自定义脚本时要检查 `version` 参数
   并做好幂等，防止装新库时误执行。

9. **大库耗时与磁盘**。--update all 全量重载 + 脚本执行，几十 GB 的库单轮
   可能数小时；重试是常态，副本恢复要快（平台的备份恢复能力正好用上）。

10. **Python/PG 版本矩阵**。每个 Odoo 大版本要求的 Python 和 PostgreSQL
    最低版本不同，逐版本升级时中间版本的运行环境也得备齐（容器化正好解）。

## 三、升级计划

### Phase 0 — 可行性盘点（1~2 天）
- [ ] 选定试点库，跑清单 SQL：
  `SELECT name, latest_version FROM ir_module_module WHERE state='installed' ORDER BY name;`
- [ ] 按「官方 CE / 企业版 / OCA / 纯第三方」四类给模块分桶
- [ ] 对照目标版本 coverage 页，产出《缺口清单》：每个缺脚本模块标注
  处置方式（等社区 / 自写 / 升级前卸载 / 换 OCA 替代）
- [ ] 确定升级路径（源版本→目标版本，几轮）

### Phase 1 — 手动跑通一次（1~2 周，试点库）
- [ ] 每轮版本准备一个升级容器镜像：目标版 Odoo + OpenUpgrade 对应分支
  + openupgradelib + 对应 Python/PG client
- [ ] 克隆试点库 + filestore 到 staging，neutralize（禁 cron/mail）
- [ ] 跑第一轮升级，记录全部报错和修复动作（这份记录就是平台化的需求清单）
- [ ] 自定义模块：改代码适配 + 写 migrations/ 脚本（用 openupgradelib）
- [ ] 业务验证：登录、关键流程、会计试算平衡对比旧库
- [ ] database_cleanup + VACUUM，收尾

### Phase 2 — 平台化（odoosh-cn 内建功能）
- [ ] 升级镜像矩阵化管理（每个版本对一个镜像，随 OpenUpgrade 分支更新重建）
- [ ] 编排流水线：克隆生产库→neutralize→逐版本跑→日志入库→成功/失败判定→报告
- [ ] 升级前置检查器：自动分桶模块清单 + 对照 coverage 数据，给用户出
  「可升 / 有风险 / 不可升」预检报告（这是对用户最有价值的一步）
- [ ] 失败自动回滚（丢弃副本即可，生产库始终不动）
- [ ] UI：升级向导 + 日志查看 + 验证清单

### Phase 3 — 扩展（可选）
- [ ] 企业版库：只做编排（引导走官方 upgrade.odoo.com，平台负责备份/neutralize/回传验证）
- [ ] 自有企业库（有订阅、自用）：用 openupgrade_records 工具链对已装企业模块
  做 diff → 自写脚本，仅内部使用不分发

## 参考
- 仓库: https://github.com/OCA/OpenUpgrade / https://github.com/OCA/openupgradelib
- 文档: https://oca.github.io/OpenUpgrade/ （040 运行、030 覆盖率、060 迁移机制、080 脚本开发）
- 官方工具: https://github.com/odoo/upgrade-util
