# OdooshCN 离线（内网 / 断网）部署清单与运维手册

适用场景:目标服务器**完全没有外网**(政务/国企内网、隔离机房)。

整体思路:在一台**有外网、且已经正常跑起来 OdooshCN** 的机器上执行 `deploy/export-offline.sh`,
把所有镜像 `docker save` 成 tar 打包带走;内网机器上 `deploy/install.sh` 检测到镜像包会**自动进入离线模式**
(docker load 导入 → 跳过全部联网步骤 → 不重新构建镜像)。

> 为什么必须在"跑起来过"的机器上导出:`odoosh/api:dev`、`odoosh/web:dev` 是本地构建产物,
> 镜像里已经装好 pip / npm 依赖,任何 registry 都拉不到。

## 脚本一览

| 脚本 | 在哪跑 | 干什么 |
|---|---|---|
| `deploy/fetch-offline-deps.sh` | **有网机器** | 下载镜像之外的东西:Docker 安装包(deb/rpm)、pip wheel、npm 依赖 |
| `deploy/export-offline.sh` | **有网机器**(已跑起平台) | 导出镜像 tar + 企业版代码,生成 `MANIFEST.txt` / `README.txt` |
| `deploy/install.sh` | 目标服务器 | **唯一的安装入口,联网和内网都用它**,自动判断 |

**没有"联网版"和"内网版"两个安装脚本** —— `install.sh` 是组合式的,每一类资源都走同一套逻辑:

```
本地 <数据目录>/offline/ 里有? ──有──→ 直接用(docker load / dpkg -i / --find-links)
         │
         没有
         ↓
    外网通不通? ──通──→ 联网补(阿里云源装 Docker、加速站拉镜像、PyPI 装依赖)
         │
        不通
         ↓
    明确报错:缺哪个镜像 / 哪个包,去哪儿补,而不是卡住或超时
```

| 资源 | 本地来源 | 联网回退 |
|---|---|---|
| Docker 引擎 | `offline/packages/*.deb\|rpm` | 阿里云 docker-ce 源 |
| 平台镜像 `odoosh/api`、`odoosh/web` | `offline/images/*.tar` | 按源码构建(`--build`) |
| `postgres:16`、`pgvector:pg16` | `offline/images/*.tar` | 镜像加速站拉取 |
| `odoo:<版本>` | `offline/images/*.tar` | 创建实例时平台自动拉 |
| 客户模块 Python 依赖 | `offline/pip/instance/*.whl` | `PIP_INDEX_URL`(清华 / 内网 PyPI) |
| 企业版代码 | `offline/enterprise/<版本>/` | 配置的 Git 仓库 |

所以:**内网机器**把资源包拷进 `<数据目录>/offline/` 直接跑;**联网机器**什么都不用准备也能跑;
**混合场景**(带了部分资源包、外网又通)会本地优先、缺的联网补。

### 资源包放哪儿

`install.sh` 按下面的顺序找,**放项目下也能装**(三个位置里的 `offline/` 结构完全一样):

| 顺序 | 路径 | 说明 |
|---|---|---|
| 1 | `<数据目录>/offline/` | 默认 `/var/lib/odoosh/offline/`,**推荐** |
| 2 | `deploy/offline/` | 项目下 |
| 3 | `<项目根>/offline/` | 项目下 |

后两个已加进 `.gitignore`(`/offline/`、`/deploy/offline/`,连同导出脚本的默认输出目录
`/odoosh-offline/`、`/bundle/`),几 GB 的 tar 不会被提交。

⚠️ 但**资源分两类**,放项目下时要注意:

| 资源 | 谁在读 | 放项目下行不行 |
|---|---|---|
| `images/*.tar`、`packages/*.deb` | `install.sh`(宿主机侧) | ✅ 行 |
| `enterprise/`、`pip/instance/` | **api / 实例容器**(运行期) | ❌ 容器只挂载了数据目录(见 `docker-compose.yml` 的 volumes),项目目录对容器不可见 |

`install.sh` 第 5b 步会**自动把 `enterprise/` 和 `pip/` 从项目下同步到 `<数据目录>/offline/`**,
所以放项目下也能正常工作,只是企业版代码会在磁盘上存两份(1GB 左右)。

另外,镜像 tar 放项目下时,平台「基础镜像」页扫描不到它们(那个页面只扫数据目录),
创建实例缺镜像时也不会自动导入 —— 装机能用,但少了这层运行期兜底。
**想省事就直接放 `<数据目录>/offline/`。**

两个强制开关(平时不用):

- `--offline` 跳过外网探测,强制只用本地资源(内网现场省 6 秒探测)
- `--online` 忽略本地资源包全部联网(资源包过期,或想按当前源码重建平台镜像)

---

## 一、内网服务器预检清单

安装前逐项确认,任何一项不满足都会在现场卡住。

### 1.1 Docker(离线包救不了,必须先装好)

`install.sh` 在离线模式下检测不到 docker 会直接终止。需要:

| 组件 | 要求 | 备注 |
|---|---|---|
| `docker-ce` / `docker-ce-cli` / `containerd.io` | ≥ 24(最低 20.10) | 低于 20.10 脚本会告警 |
| `docker-compose-plugin` | v2 | 老的 `docker-compose` v1 **不支持**,脚本会拦 |
| `docker-buildx-plugin` | 可选 | 离线不构建镜像,可不装 |

准备方式(三选一,推荐第一种):

**① 用 `deploy/fetch-offline-deps.sh` 预下载**(在有网机器上,产物进资源包,`install.sh` 会自动安装):

```bash
bash deploy/fetch-offline-deps.sh --only docker --os ubuntu:22.04
```

`--os` 必须填**内网服务器的发行版镜像**(`ubuntu:22.04` / `debian:12` / `rockylinux:9` …)。
脚本在该系统的干净容器里解析依赖闭包,所以下下来的 deb/rpm 是完整的、能在最小化安装的机器上装上。
产物落在 `offline/packages/`,拷到内网后 `install.sh` 检测到就自动 `dpkg -i` / `rpm -Uvh` 并 `systemctl enable --now docker`。

**②** 内网 apt / yum 源里已有 docker-ce
**③** 发行版自带源:`apt-get install docker.io docker-compose-plugin`(版本偏老,能用)

验证:

```bash
docker --version && docker compose version && sudo systemctl is-active docker
```

### 1.2 系统命令

脚本硬依赖,基本都是系统自带,但精简(minimal)安装可能缺:

| 命令 | 用途 | 缺了会怎样 |
|---|---|---|
| `bash` | 跑脚本 | 无法安装 |
| `python3` | 合并写 `/etc/docker/daemon.json` | 只告警并跳过,需手工配 |
| `curl` | 安装末尾的健康检查 | 检查不到,误判"未就绪" |
| `tar` / `sha256sum` | 解包与校验 | 无法校验完整性 |
| `ss` 或 `netstat` | 端口占用检查 | 跳过检查(也可 `--skip-checks`) |
| `sudo` 或 root | 创建目录、配置 Docker | 无法安装 |

### 1.3 硬件与容量

- **CPU 架构必须与导出机一致**。amd64 导出的 tar 不能给 ARM 机器用(`MANIFEST.txt` 里记录了架构)。
- 内存 ≥ 4GB(平台自身约 1.5GB + 每个 Odoo 实例默认 1GB)
- CPU ≥ 2 核
- **磁盘按 tar 体积的 2 倍算**:tar 文件本身 + `docker load` 之后的镜像层,导入并确认后才能删 tar。

  大致体积(仅供估算,以实际 `MANIFEST.txt` 为准):

  | 包 | 约 |
  |---|---|
  | 平台三件套(`odoosh/api` + `odoosh/web` + `postgres:16`) | 1.5 GB |
  | `pgvector/pgvector:pg16` | 0.6 GB |
  | 每个 `odoo:<版本>` | 2.5 ~ 3 GB |
  | `docker:27-cli`(可选) | 0.1 GB |

  带两个 Odoo 版本的资源包约 8GB → 服务器数据盘建议预留 **60GB 以上**(还要放实例数据与备份)。

### 1.4 网络与端口

需要在防火墙 / 安全组放行(内网也常有主机防火墙):

| 端口 | 用途 |
|---|---|
| 80(或 `--port` 指定的) | 平台控制台 + 域名分流模式下的实例访问 |
| 443 | HTTPS(配了证书才用) |
| 8088 | ACME 续期端口,内网用不到但会占用,可在 `.env` 改 `ODOOSH_ACME_PORT` |
| **10001-10020** | **端口直连模式的实例端口池**(内网必用),可在 `.env` 改 `ODOOSH_ENV_PORT_RANGE` |

```bash
sudo ufw allow 80/tcp && sudo ufw allow 10001:10020/tcp
```

```bash
sudo firewall-cmd --permanent --add-port=80/tcp --add-port=10001-10020/tcp && sudo firewall-cmd --reload
```

### 1.5 ⚠️ Docker 网络地址池 —— 决定了最多能建多少实例

`install.sh` 会往 `/etc/docker/daemon.json` 写 `default-address-pools: 10.200.0.0/16 (size 26)`
—— 平台给**每个实例建一个独立 bridge 网络**,Docker 默认地址池只够约 30 个,不改会用完。

`size` 直接决定实例数量上限:

| size | 切出的网络数 | 每网段可用 IP | 最多实例数 |
|---|---|---|---|
| 24 | 256 | 254 | **256**(老版本脚本写的值)|
| **26** | **1024** | 62 | **1024** ← 当前默认 |

一个实例只有 odoo + pg 两个容器,62 个 IP 绰绰有余。到上限后新实例容器直接起不来,报地址池耗尽。

> **已建好的网络不会自动迁移,所以这个值必须在大量建实例之前定好。**
> 老版本装的机器重跑新脚本时会提示改,但不会自动改(旧 `/24` 网络和新 `/26` 池同在一个 `/16` 里,自动换池有风险)。手工改:
> ```bash
> sudo sed -i 's/"size": 24/"size": 26/' /etc/docker/daemon.json && sudo systemctl restart docker
> ```
> 要超过 1024 个实例,把 base 换成更大的段,例如 `10.0.0.0/8` + size 26。

**如果内网已经在用 10.200.x.x 网段(企业内网 / VPN 常见),会造成路由冲突,访问内网其它系统会断。**

冲突时:先手工把 `daemon.json` 配成不冲突的段,再带 `--skip-docker-config` 安装。

```bash
sudo tee /etc/docker/daemon.json >/dev/null <<'JSON'
{
  "log-driver": "json-file",
  "log-opts": { "max-size": "20m", "max-file": "3" },
  "default-address-pools": [ { "base": "172.30.0.0/16", "size": 26 } ]
}
JSON
```

```bash
sudo systemctl restart docker && sudo bash deploy/install.sh --skip-docker-config --base-domain localhost
```

> 离线模式下脚本**不会**写 `registry-mirrors`(内网连不上加速站,写了只会让每次镜像操作先撞超时)。

### 1.6 时间与时区

内网常没有 NTP。时间偏差会影响自动备份、闲置休眠、登录令牌有效期:

```bash
sudo timedatectl set-timezone Asia/Shanghai && timedatectl
```

---

## 二、资源包里必须带的东西

### 2.1 镜像(`export-offline.sh` 已覆盖,注意分级)

| 类别 | 镜像 | 缺了会怎样 |
|---|---|---|
| **平台必需** | `odoosh/api:dev`、`odoosh/web:dev`、`postgres:16` | 平台起不来,`install.sh` 直接报错退出 |
| **建实例必需** | `pgvector/pgvector:pg16` | 平台能起,创建实例失败 |
| **建实例必需** | `odoo:19` / `odoo:18` …(你要用的每个版本) | 创建实例失败,且内网**无法源码自建** |
| 可选 | `docker:27-cli` | 只影响控制台"重构并重启" |

⚠️ **基础镜像模式必须提前决定**:源码自建模式(`odoosh-base:<版本>`)要 clone GitHub / Gitee 的
Odoo 源码 + pip 装依赖,**内网完全走不通**。二选一:

- 全部用官方 `odoo:<版本>` 镜像(推荐),或
- 在有网机器上先把 `odoosh-base:19` 构建出来,`export-offline.sh` 会自动一并导出

### 2.2 平台源码

拷到内网服务器(如 `/opt/odoosh-cn`),**git 版本要与 `MANIFEST.txt` 记录的一致**,
否则源码与镜像不匹配。

### 2.3 企业版代码(如使用企业版)

放到 `<数据目录>/offline/enterprise/<版本>/`,实例容器直接**只读挂载**。
`export-offline.sh --with-enterprise` 会打包。授权由组织自行持有,平台不分发代码。
**这个目录装完后不能删。**

### 2.4 客户自己的 Odoo 模块

内网没有 GitHub / Gitee,两条路:

- **内网 Git 服务器**(GitLab / Gitea 私服):平台按现有 Git 接入流程使用,分支部署、自动部署都正常
- **无仓库实例 + 定制代码通道**(内网更现实):在实例页上传模块 zip,或直接把模块拷进宿主机
  `<数据目录>/tenants/<租户>/envs/<实例>/addons/`,然后在页面上扫描 + 重启实例

### 2.5 ⚠️ 私有 PyPI(容易踩的坑)

系统设置 `deploy.install_requirements` **默认开启**:每次部署会在实例容器里执行
`pip install --user -r requirements.txt`。**内网没有 PyPI 源,这一步会失败并回退整次部署。**

三种处理方式,推荐第一种:

**① 预下载 wheel 放进 `offline/pip/instance/`(平台会自动使用)**

在有网机器上,用**实例实际使用的 Odoo 镜像**下载(保证 Python 版本 / ABI / 架构一致):

```bash
bash deploy/fetch-offline-deps.sh --only pip --instance-req /path/to/客户模块/requirements.txt --instance-image odoo:19
```

把产物 `offline/pip/instance/` 拷到 `<数据目录>/offline/pip/instance/`。
之后平台每次部署会检测到该目录有包,自动把它只读挂到实例容器的 `/mnt/offline-pip`,
用 `pip install --no-index --find-links /mnt/offline-pip` 安装,**全程不访问 PyPI**
(实现见 [deploy.py](../backend/app/services/deploy.py) 的 `offline_wheels_dir`)。
客户模块日后新增依赖,回有网机器重跑一次、把新 wheel 拷进该目录即可。

**②** 仓库里没有 `requirements.txt` 或不需要额外依赖 → 到「系统设置」**关掉"部署时自动安装依赖"**

**③** 有内网 PyPI(nexus / devpi)→ 保持开启,并在实例里配好 pip 源(写进持久卷,重建容器后仍在):

```bash
docker exec -u odoo odoo-<租户>-<实例> sh -c 'mkdir -p ~/.config/pip && printf "[global]\nindex-url = http://内网pypi/simple\ntrusted-host = 内网pypi\n" > ~/.config/pip/pip.conf'
```

> 注意:`offline/pip/instance/` 里有包时走 `--no-index`,**内网 PyPI 就不会被使用**。
> 两种方式二选一,不要同时配。

---

## 三、安装步骤

### 3.1 导出侧(有网机器,已跑起 OdooshCN)

**两个脚本、同一个 `--out` 目录**,产物自动合并成一个完整资源包:

```bash
docker pull odoo:19 && docker pull pgvector/pgvector:pg16
```

第一步:下载镜像之外的东西(Docker 安装包、pip wheel、npm 依赖):

```bash
bash deploy/fetch-offline-deps.sh --out ./bundle --os ubuntu:22.04 --instance-req /path/to/客户模块/requirements.txt
```

第二步:导出镜像与企业版代码:

```bash
bash deploy/export-offline.sh --out ./bundle --odoo 19 --with-enterprise --pack
```

产出 `bundle/`(或 `--pack` 的单个 tar):

```
bundle/
├── offline/
│   ├── images/*.tar + SHA256SUMS   镜像(平台 / PostgreSQL / Odoo)
│   ├── enterprise/<版本>/          企业版代码
│   ├── packages/*.deb|rpm          宿主机 Docker 安装包   ← install.sh 自动使用
│   ├── pip/instance/*.whl          客户模块 Python 依赖   ← 部署实例时自动使用
│   ├── pip/backend/*.whl           平台后端依赖(仅重建平台镜像时用)
│   └── npm/node_modules.tar.gz     前端依赖(仅重建平台镜像时用)
├── MANIFEST.txt                    架构 / 源码版本 / 镜像清单 / sha256
├── DEPS.txt                        依赖包清单
└── README.txt                      内网侧操作步骤
```

`fetch-offline-deps.sh` 的常用参数:`--only docker|pip|npm`(只跑其中一步)、
`--instance-image odoo:18`(实例用哪个 Odoo 镜像,决定 wheel 的 Python 版本)、
`--with-build-images`(连 `python:3.12-slim` / `node:20-alpine` / `nginx:1.27-alpine` 一起导,
仅在内网要重新构建平台镜像时才需要)。

### 3.2 内网侧

```bash
sudo mkdir -p /opt && sudo cp -a odoosh-cn /opt/
```

```bash
sudo mkdir -p /var/lib/odoosh && sudo cp -a offline /var/lib/odoosh/
```

```bash
cd /var/lib/odoosh/offline/images && sha256sum -c SHA256SUMS
```

```bash
sudo bash /opt/odoosh-cn/deploy/install.sh --base-domain localhost
```

常用参数:`--port 8080`(80 被占用)、`--data-dir /data/odoosh`(数据盘)、
`--admin-password xxx`(指定管理员密码,否则随机生成并在末尾打印)、`--skip-docker-config`(见 1.5)。

脚本可重复执行:已有 `.env` 会沿用,只重新导入镜像并拉起容器。

### 3.3 装完必做的三件事

1. **「系统设置 → 平台 → 实例访问模式」改为「端口」** —— 内网没有公网 DNS,域名分流用不了。
   改完记得放行 `10001-10020` 端口段。
   (若内网 DNS 能做泛解析 `*.odoo.内网域名 → 服务器IP`,也可以继续用域名模式,重跑安装时加
   `--base-domain odoo.内网域名`)
2. **处理 pip 源**(见 2.5):
   带了 `offline/pip/instance/` 的话**不用做任何事** —— 平台会自动用本地 wheel(安装脚本末尾会提示"已就绪")。
   没带就关掉「部署时自动安装依赖」,或配好内网 PyPI。
3. **确认企业版目录**:「系统设置」里 `odoo.enterprise_dir` 指向 `<数据目录>/offline/enterprise`,
   版本子目录里能看到模块数量。

---

## 四、离线环境的功能取舍

| 功能 | 离线状态 | 对策 |
|---|---|---|
| 实例访问(域名分流 / nip.io) | 不可用 | 改**端口模式**,或内网 DNS 泛解析 |
| HTTPS `deploy/ssl-ip.sh` | **不可用**(acme.sh 要 clone、Let's Encrypt 要外网) | 内网 CA 或自签证书,放 `<数据目录>/certs/` |
| AI 助手 | 不可用(需访问 DashScope / OpenAI 兼容端点) | 有内网 LLM 网关(OpenAI 兼容协议)可以接 |
| Git 接入 / 轮询 / webhook 自动部署 | 依赖内网 Git 服务 | 内网 GitLab / Gitea,或走定制代码通道 |
| 源码自建基础镜像 | **不可用** | 用官方 `odoo:<版本>` 镜像 |
| 平台"重构并重启" / 自更新 | **不可用**(要 pip / npm 重新构建) | 走 6.8 的离线升级流程 |
| 公网 IP 探测 | 会周期性超时 | 无害,日志里有噪音 |
| 备份 / 恢复 / 模板库 / Web Shell / 监控 | 正常 | —— |

---

## 五、日后补充资源

`<数据目录>/offline/` 装完后**依然生效**,是平台长期的资源补给目录:

- **新增 Odoo 版本**:有网机器 `docker save odoo:18 -o odoo-18.tar` → 拷到
  `<数据目录>/offline/images/` → 平台「基础镜像」页点扫描 → 导入。也支持在网页上直接上传 tar。
- 创建实例时若本地缺镜像,平台会**自动**在该目录里找匹配的包并导入,无需手工操作。
- **客户模块新增了 Python 依赖**:有网机器上
  `bash deploy/fetch-offline-deps.sh --only pip --instance-req <新的 requirements.txt>`,
  把新 wheel 拷进 `<数据目录>/offline/pip/instance/` 即可,下次部署自动生效。
- `offline/images/` 里的 tar 导入后可以删(平台页面上就能删)以释放磁盘。
- `offline/packages/` 装完 Docker 后可以删。
- **`offline/enterprise/` 和 `offline/pip/instance/` 不能删** —— 前者被实例容器挂载,
  后者每次部署都要用。

---

## 六、常用运维命令

以下假设:平台源码在 `/opt/odoosh-cn`,数据目录 `/var/lib/odoosh`,compose 项目名 `odoosh`。
把 `<租户>` / `<实例>` 换成实际的 slug 和实例名(如 `acme` / `production`)。

嫌命令长可以先设个别名:

```bash
echo "alias dc='docker compose -f /opt/odoosh-cn/deploy/docker-compose.yml --env-file /opt/odoosh-cn/deploy/.env'" >> ~/.bashrc && source ~/.bashrc
```

### 6.1 平台服务(api / web / db)

```bash
cd /opt/odoosh-cn/deploy && docker compose --env-file .env ps
```

```bash
docker compose --env-file .env up -d --no-build
```

```bash
docker compose --env-file .env restart api
```

```bash
docker compose --env-file .env restart web
```

```bash
docker compose --env-file .env down
```

> **离线环境永远加 `--no-build`**。不加的话 compose 一旦发现镜像不在就会尝试联网构建,
> 必然卡在 pip / npm 上,报错还很难懂。
> `down` 只删容器,数据都在数据目录里,不会丢。

容器名固定为 `odoosh-api-1`、`odoosh-web-1`、`odoosh-db-1`。

### 6.2 日志

```bash
cd /opt/odoosh-cn/deploy && docker compose --env-file .env logs -f api
```

```bash
docker compose --env-file .env logs --tail 200 api
```

```bash
docker logs -f --tail 100 odoo-<租户>-<实例>
```

```bash
tail -f /var/lib/odoosh/nginx-logs/<租户>-<实例>.log
```

日志已配轮转(单文件 20MB × 3),不会无限增长。实例访问日志是平台判断"开发实例闲置 → 休眠"的依据。

### 6.3 进容器 / 健康检查

```bash
docker exec -it odoosh-api-1 bash
```

```bash
docker exec -it odoosh-web-1 sh
```

```bash
docker exec -it odoo-<租户>-<实例> bash
```

```bash
curl -fsS http://127.0.0.1/api/health && echo
```

```bash
docker stats --no-stream
```

### 6.4 镜像管理

```bash
docker images | grep -E 'odoo|odoosh|pgvector|postgres'
```

```bash
docker load -i /var/lib/odoosh/offline/images/odoo-18.tar
```

```bash
du -sh /var/lib/odoosh/offline/images/
```

> ⚠️ **离线环境绝对不要执行 `docker system prune -a` 或 `docker image prune -a`。**
> 它们会删掉所有"当前没有容器在用"的镜像 —— 包括辛辛苦苦拷进来的 `odoo:19`、`pgvector`,
> 而内网**拉不回来**,只能重新从有网机器导出一趟。
> 要清理只用 `docker container prune`(删已停止的容器)或 `docker builder prune`(删构建缓存)。

### 6.5 租户实例(Odoo)

命名规则:

| 对象 | 名字 |
|---|---|
| Odoo 容器 | `odoo-<租户>-<实例>` |
| 租户 PG 容器 | `odoosh-pg-<租户>`(该租户所有实例共用) |
| Docker 网络 | `odoosh-<租户>-<实例>` |
| 实例数据目录 | `/var/lib/odoosh/tenants/<租户>/envs/<实例>/` |
| 定制模块目录 | `/var/lib/odoosh/tenants/<租户>/envs/<实例>/addons/` |

```bash
docker ps --filter name=odoo- --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
```

```bash
docker restart odoo-<租户>-<实例>
```

> 优先在平台页面上做启停 / 部署 —— 平台会同步状态并重新生成 nginx 配置。
> 直接 `docker` 操作只在平台本身出问题时用来救急。

### 6.6 数据库

```bash
docker exec -it odoosh-db-1 psql -U odoosh -d odoosh
```

```bash
docker exec -it odoosh-pg-<租户> psql -U postgres -c '\l+'
```

```bash
docker exec -it odoosh-pg-<租户> psql -U postgres -d <库名>
```

手工导出平台库(升级 / 迁移前建议做一次):

```bash
docker exec odoosh-db-1 pg_dump -U odoosh -Fc odoosh > /var/lib/odoosh/backups/platform-$(date +%F).pgc
```

手工导出某个租户库:

```bash
docker exec odoosh-pg-<租户> pg_dump -U postgres -Fc <库名> > /var/lib/odoosh/backups/<库名>-$(date +%F).pgc
```

> 实例的备份 / 恢复优先用平台页面(会一并处理 filestore,产出 Odoo 官方 zip 格式,可在任意 Odoo 里恢复)。
> 备份文件在 `/var/lib/odoosh/backups/<租户>/<实例>/`。

### 6.7 nginx / 实例访问

```bash
ls /var/lib/odoosh/nginx/
```

```bash
docker exec odoosh-web-1 nginx -t
```

```bash
docker exec odoosh-web-1 nginx -s reload
```

> 配置由平台自动生成并 reload,一般不需要手动改;手改的内容会在下次部署时被覆盖。

### 6.8 离线升级平台

内网不能用控制台的"重构并重启"(要 pip / npm)。升级流程:

**有网机器**——更新源码、重新构建、重新导出:

```bash
cd odoosh-cn && git pull && bash deploy/install.sh && bash deploy/export-offline.sh --out ./upgrade-$(date +%F) --pack
```

**内网机器**——先备份,再换源码 + 导入新镜像 + 重启:

```bash
docker exec odoosh-db-1 pg_dump -U odoosh -Fc odoosh > /var/lib/odoosh/backups/platform-before-upgrade.pgc
```

```bash
cd /opt/odoosh-cn && git pull
```

```bash
docker load -i /path/to/offline/images/odoosh-platform.tar
```

```bash
cd /opt/odoosh-cn/deploy && docker compose --env-file .env up -d --no-build && docker compose --env-file .env logs -f api
```

看到 api 日志里数据库迁移完成、`/api/health` 正常即可。

### 6.9 磁盘与清理

```bash
df -h /var/lib/odoosh && du -sh /var/lib/odoosh/*
```

```bash
docker system df
```

```bash
docker container prune && docker builder prune
```

数据目录结构:

```
/var/lib/odoosh/
├── platform-db/          平台 PostgreSQL 数据(不可删)
├── tenants/              各租户实例数据 + filestore + 定制 addons(不可删)
├── repos/                Git 仓库缓存
├── builds/               构建产物
├── backups/              备份 zip(按保留策略清理)
├── enterprise/           Git 方式接入的企业版镜像仓库
├── nginx/  nginx-logs/   实例 nginx 配置与访问日志
├── certs/                HTTPS 证书
└── offline/
    ├── images/           离线镜像 tar(导入后可删)
    ├── enterprise/       离线企业版代码(不可删,实例挂载中)
    ├── packages/         宿主机 Docker 安装包(装完可删)
    ├── pip/instance/     客户模块 Python 依赖(不可删,每次部署都要用)
    ├── pip/backend/      平台后端依赖(仅重建平台镜像时用)
    └── npm/              前端依赖(仅重建平台镜像时用)
```

### 6.10 卸载

```bash
bash /opt/odoosh-cn/deploy/uninstall.sh
```

```bash
bash /opt/odoosh-cn/deploy/uninstall.sh --purge
```

前者删平台容器与镜像、保留数据目录(重跑 `install.sh` 可恢复);`--purge` 连数据目录一起删,**不可恢复**。

---

## 七、故障速查

| 症状 | 排查 |
|---|---|
| 安装脚本报"缺少平台必需镜像" | 资源包不全,回有网机器重跑 `export-offline.sh` |
| `docker load` 失败 | 文件损坏,`sha256sum -c SHA256SUMS` 核对后重传 |
| 平台起来了但打不开 | `docker compose --env-file .env logs web`;确认防火墙放行、端口没被宝塔 / nginx 占用 |
| 创建实例失败,提示拉镜像 | 缺 `odoo:<版本>` 或 `pgvector/pgvector:pg16`,补 tar 到 `offline/images/` 后在「基础镜像」页导入 |
| 部署卡在装依赖 / 失败回退 | 内网无 PyPI。部署日志会提示当前用的是本地 wheel 仓库还是 PyPI;缺包就回有网机器补下载,见 2.5 |
| 实例访问不了 | 确认已切「端口」模式;`docker ps` 看端口映射;放行 10001-10020 |
| 装完后访问内网其它系统断了 | Docker 地址池与内网网段冲突,见 1.5 |
| 容器无法启动、报网络地址用尽 | `default-address-pools` 没配好,见 1.5 |
| 定时备份 / 休眠时间不对 | `timedatectl` 确认时区,与 `.env` 里的 `TZ` 一致 |
| 误删了镜像,实例起不来 | 内网拉不回来;从 `offline/images/` 重新 `docker load`,或回有网机器重新导出 |
