# 企业版仓库 GitHub 加速与离线降级(2026-08-24)

## 背景

国内服务器直连 github.com 时通时断:创建企业版实例时探测(ls-remote,15s 超时无重试)与
`fetch --depth 1` 频繁失败(Receiving objects 中途低速中止),后台轮询也反复在仓库卡片上刷
「轮询失败:连接仓库失败」。

## 方案:本地优先 + 三级下载回退

选仓库/取代码的顺序:**本地已有代码(解出目录或镜像分支,秒级、不联网)→ 联网探测(own → tenant → platform)**;
需要联网下载时按 **加速代理 → 直连** 依次尝试。创建实例不追远端最新 commit,更新代码走
「Git 仓库 → 手动导入代码 → 在线更新」(`POST /api/enterprise/repos/{id}/pull?version=19`,后台
`ensure_code(prefer_local=False)`)。

1. **系统设置 `git.github_proxy`**(设置页 → Git 平台):gh-proxy 类加速前缀,逗号分隔多个,
   按顺序尝试,全部失败回退直连;只对 github.com 的仓库生效。分支查询(`git.ls_remote`)、
   企业版拉代码(`enterprise.ensure_code` 的 fetch)、后台轮询都走同一逻辑。
   - 实测可用(2026-08):`https://gh.llkk.cc`(约 2MB/s)、`https://ghproxy.net`(约 0.5MB/s)。
     公共站寿命不可控,挂了换前缀即可;也可自建 hunshcn/gh-proxy(CF Workers 免费版够用)。
   - 注意:私有仓库的访问令牌会经过代理方。建议用只读、仅授权企业版仓库的细粒度令牌,或自建代理。
2. **本地降级**:探测失败(含 OAuth 令牌刷新失败、远端缺版本分支)时:
   - 优先用该版本最近一次完整解出的本地目录(`local_fallback`,以 `.odoosh-commit` 为完成标记);
   - 否则用 `mirror.git` 里已有的 `<版本>.0` 分支头(`mirror_branch_head`)——这就是**手动导入**入口。
   `resolve_repo` 全部候选探测失败时同样按此降级;`describe_failure` 的报错里附手动导入命令。

## 手动导入代码(完全离线可建实例)

每个企业版仓库在宿主机上有一个标准裸仓库:`<数据目录>/enterprise/<仓库ID>/mirror.git`。
把版本分支弄进去即可,平台探测失败时会自动采用:

```bash
# 首次(目录不存在时)
git init --bare /var/lib/odoosh/enterprise/<ID>/mirror.git
# 方式 A:服务器上能临时走代理时
git --git-dir /var/lib/odoosh/enterprise/<ID>/mirror.git fetch --depth 1 \
    https://<加速前缀>/https://github.com/<owner>/enterprise.git '+refs/heads/19.0:refs/heads/19.0'
# 方式 B:在能访问 GitHub 的电脑上浅克隆后,scp 到服务器,再从本地路径 fetch
git clone --depth 1 -b 19.0 https://github.com/<owner>/enterprise.git ent19 && scp -r ent19 服务器:/tmp/
git --git-dir /var/lib/odoosh/enterprise/<ID>/mirror.git fetch /tmp/ent19 '+refs/heads/19.0:refs/heads/19.0'
```

## 界面入口

「Git 仓库」页 → 企业版仓库行 →「更多」→「手动导入代码」(仅超管可见):弹窗展示镜像宿主机路径、
镜像中已有的版本分支、可复制的导入命令(方式 A 服务器直接拉 / 方式 B 别处克隆后拷入)。
后端 `GET /api/enterprise/repos/{id}/import-info`。

## 改动文件

- `backend/app/services/git.py`:`github_proxies()` / `github_url_candidates()`;`ls_remote` 多候选重构
- `backend/app/services/enterprise.py`:fetch 多下载源;`local_fallback` / `mirror_branch_head` 降级;失败提示附导入命令
- `backend/app/routers/settings.py`:默认值 `git.github_proxy`
- `frontend/src/views/Settings.vue`:设置项 UI
- `backend/tests/test_enterprise_resolve.py`:两条降级路径的测试

遗留:`backend/tests/test_git_service.py` 有 5 个改动前就失败的坏测试(mock 过时),待修。
`images.py` 拉社区版源码的硬编码加速站列表可考虑并入 `git.github_proxy` 设置(未做)。
