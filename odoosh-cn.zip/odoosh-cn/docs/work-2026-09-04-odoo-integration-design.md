# 第三方系统接入 OdooshCN 对接设计

日期：2026-09-04　　状态：**已实现**（OdooshCN 侧与接入方模块均已落地，见文末「实现状态」）
首个接入方：某学校的 Odoo 18 课程系统

## 0. 通用性边界（本设计的第一原则）

OdooshCN 要长期服务多种接入场景，不只是这一所学校。因此划一条硬线：

**OdooshCN 提供机制，接入方提供策略。**

| OdooshCN 知道 | OdooshCN 不知道 |
|---|---|
| 有一个外部系统，用某个标识指代某个人 | 那个人是学生、员工还是客户 |
| 调用方要求把此人放进某组织、给某角色、给某配额 | 为什么是这个角色、这个配额 |
| 调用方要求为此人开一个实例，参数如下 | 开课、入职还是试用 |
| 这把令牌最多能授予到什么权限 | 调用方内部怎么分组 |

判断准则：**任何一个字段，如果它的名字里带有「学生」「班级」「课程」这类只属于某个接入方的概念，它就不该出现在 OdooshCN 里。** 本设计中所有此类语义一律落在接入方模块。

代价是接入方要多传几个字段，多写几十行策略代码。收益是 OdooshCN 接第二家、第三家时不用改一行。

## 1. 目标与角色分工

学生在学校的 Odoo 课程系统里点开一个菜单，看到自己的实验环境并直接使用，不需要知道 OdooshCN 的存在，也不需要第二套账号密码。

| 系统 | 职责 |
|---|---|
| 接入方（学校 Odoo 18） | 主入口、主数据。决定谁该有环境、给什么权限、开什么规格。负责同步的触发、重试与对账 |
| OdooshCN | 按指令建账号、建实例、管权限，提供免登入口与状态查询。不判断业务含义 |

身份单向从接入方流向 OdooshCN，实例状态单向从 OdooshCN 流回接入方。OdooshCN 不写接入方的任何数据。

## 2. 四个关键决策

### 2.1 域名与嵌入

先分清两件互不相干的事。**接口调用不受任何跨域限制**，服务端对服务端的 HTTP 请求能连通就能用，本节讨论的全部约束只针对浏览器里的 iframe 嵌入。

嵌入分两种对象，限制完全不同：

| 嵌入对象 | 认证方式 | 跨站 iframe 内 |
|---|---|---|
| OdooshCN 控制台 | 登录令牌存 localStorage，走 `Authorization` 头 | 可行。存储被浏览器分区但仍然可用，不受第三方 cookie 拦截影响 |
| 实例的 Odoo 界面 | `session_id` cookie，`SameSite=Lax` | 不可行。跨站 iframe 内浏览器不发送该 cookie，页面恒为未登录 |

实测的响应头（运行中的实例）：

```
X-Frame-Options: SAMEORIGIN
Content-Security-Policy: frame-ancestors 'self'
Set-Cookie: session_id=...; HttpOnly; Path=/        # SameSite 缺省即 Lax
```

响应头可以通过配置放开，cookie 的第三方限制不能。Safari 默认拦截第三方 cookie，Firefox 做分区，这是浏览器为反跟踪定下的规则，服务端无法绕过。

因此有两种部署选择：

**首选：同域部署。** 让两边同属一个可注册域，浏览器不再视作第三方，控制台与实例都能嵌入。

| 位置 | 域名 |
|---|---|
| 接入方 Odoo | `course.school.edu.cn` |
| OdooshCN 控制台 | `lab.school.edu.cn` |
| 学生实例 | `<实例>-<组织>.lab.school.edu.cn` |

三者的可注册域都是 `school.edu.cn`。部署时把 `ODOOSH_BASE_DOMAIN` 设为 `lab.school.edu.cn`，申请 `*.lab.school.edu.cn` 泛解析与泛证书。

**次选：不同域。** 只嵌控制台，学生在框内看实例列表、写代码、看日志；点「打开 Odoo」时用 `target="_blank"` 跳出到新标签页。需要放开控制台的 `frame-ancestors`，并在 Safari 上实测一次分区存储是否正常。

两种方案下接口都不受影响，一期成果不受影响。此项须在二期开工前确认。

### 2.2 令牌粒度

**结论：接入方服务端持有一把系统令牌，不给每个用户单独发 API key。**

理由：接入方服务端已经能代表任何用户换取入口，给每人一把 key 并不缩小权限面，反而带来 N 份密钥的存储、轮换与吊销负担。

用户实际持有的凭据是免登换来的**平台登录令牌**，短期、每人一份、存在自己浏览器里，与密码登录得到的完全相同。这已经满足「每个用户有自己的权限」。

职责从「换地址」扩展到「写用户」，令牌须引入权限范围：

| scope | 用途 |
|---|---|
| `handoff` | 换免登地址 |
| `users:write` | 创建、更新、停用用户 |
| `envs:read` | 查询用户的实例 |
| `envs:write` | 为用户开通实例 |

### 2.3 令牌的安全上限

令牌能写用户之后，泄露的后果从「替某人进他自己的实例」变成「批量造账号」。约束方式是给令牌设**上限**，而不是给它设「模板」。

上限是 OdooshCN 的安全机制，与业务无关：

| 上限项 | 含义 | 越界时 |
|---|---|---|
| `tenant_id` | 绑定组织，未开下一项时所有写入只能落在这一个组织 | 拒绝 |
| `allow_any_tenant` | 是否允许请求里指定别的组织（默认关） | 拒绝 |
| `max_grant_role` | 最多能授予的组织角色，如 `developer` | 拒绝 |
| `allow_admin_role` | 是否允许把用户设为平台管理员（默认关，后果最重） | 拒绝 |
| `max_envs_per_user` | 单个用户最多能被开通几个实例 | 拒绝 |
| `allow_create_user` | 是否允许创建新用户（关掉则只能更新已存在的） | 拒绝 |
| `allow_delete_user` | 是否允许删除用户（默认关，不可恢复） | 拒绝 |

调用方在上限之内自由决定具体值。OdooshCN 只校验不越界，不关心为什么是这个值。

两条不可配置的硬约束：同步创建的用户密码随机生成且不返回，只能走免登入口；未开 `allow_admin_role` 的令牌无权修改任何已是平台管理员的账号。

未开 `allow_any_tenant` 时，请求里指定组织一律返回 403，不区分该组织是否存在 —— 否则调用方能靠 404 与 403 的差别枚举出平台上有哪些组织。

### 2.4 用户对应关系

**结论：新增 `external_source` + `external_id` 两列，作为通用的外部身份映射。**

原设计里 OdooshCN 用户名直接等于对方标识，做同步后有两个问题。一是用户名规则为 `^[A-Za-z0-9][A-Za-z0-9_.-]{1,63}$`，不接受 `@`，而 Odoo 的 login 通常是邮箱。二是 login 可被修改，改后两边失联。

| 字段 | 取值 | 说明 |
|---|---|---|
| `external_source` | 令牌上配置的来源标识，如 `school-a` | 支持接入多个系统 |
| `external_id` | 接入方的稳定主键 | 永不变化，唯一匹配键 |
| `username` | 接入方传入，OdooshCN 校验格式与查重 | 供管理员在界面辨认 |
| `display_name` | 接入方传入 | 每次同步刷新 |

联合唯一索引建在 `(external_source, external_id)`。用户名由接入方决定，OdooshCN 只保证合法与不重复，冲突时在响应里明确报错，由接入方决定改名策略。

## 3. OdooshCN 需暴露的接口

全部位于 `/api/ext/`，认证 `Authorization: Bearer <令牌>`，按 scope 与上限校验。所有接口与具体行业无关。

### 3.0 连通性探测

```
GET /api/ext/ping            任意有效令牌即可，不要求 scope
```

接入方「测试连接」用。只验证地址与令牌，不依赖任何已同步的用户，无副作用。回显令牌的来源、绑定组织、权限范围与上限，接入方据此在设置页提示「令牌缺少同步用户权限」之类的问题，而不是等到学生点进去才发现。

```json
{"ok": true, "token_name": "学校课程系统", "source": "school",
 "tenant_id": 1, "tenant_slug": "cls-2024-ai1", "tenant_name": "2024 级人工智能 1 班",
 "scopes": ["envs:read", "envs:write", "handoff", "users:write"],
 "limits": {"max_grant_role": "owner", "max_envs_per_user": 1, "allow_create_user": true,
            "allow_admin_role": false, "allow_any_tenant": false},
 "expires_at": "2027-09-03T15:44:40+08:00", "server_time": "...", "version": "..."}
```

设计上不用 `handoff` 当探测：它要求目标用户已存在，首次配置时还没同步任何人，必然 404，会误导管理员以为连接有问题。

### 3.1 用户写入

```
POST /api/ext/users          scope: users:write
```

按 `(external_source, external_id)` 幂等**创建或更新**（upsert）。不拆成两个接口：接入方无法可靠判断某人在 OdooshCN 是否已存在（首次同步、失败重试、平台从备份恢复，都会让状态错位），拆开会逼着接入方自己维护一份状态并处理「已存在」错误。一个幂等接口，调多少次结果都一样，重试逻辑因此变得简单。

请求：

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| external_id | string | 是 | 接入方的稳定主键 |
| username | string | 是 | OdooshCN 用户名，须合法且唯一 |
| display_name | string | 否 | 显示名 |
| role | string | 否 | 平台角色：`member`（默认）或 `admin`。设为 `admin` 须令牌开启「允许设为平台管理员」 |
| tenant | string / int | 否 | 组织，按 slug 或 id。省略 = 令牌绑定组织；指定别的组织须令牌开启「允许指定其他组织」 |
| tenant_role | string | 否 | 组织内角色：`tester` / `developer`（默认）/ `owner`，不得超过令牌的最高可授予角色 |
| active | boolean | 否 | 默认 true |
| shell_enabled | boolean | 否 | Web Shell 开关 |
| can_use_enterprise | boolean | 否 | 企业版实例开关 |
| quota | object | 否 | 配额 `{"max_envs": 1, "max_dbs": 2}`，值为 `null` 表示不限 |
| menus | object | 否 | 菜单可见性 `{"dashboard": false, "repos": false, "ai": true, "backups": false, "settings": false, "upgrade": false, "databases": false}`。前四个是侧栏菜单（新用户默认开）；`settings` / `upgrade` / `databases` 是实例详情页的「设置」「升级」「数据库」Tab（新用户默认关，须显式传 true 才打开；更新时未提及保持原值，平台里手动打开的不会被同步关回去） |
| provision | object | 否 | 传了且该用户尚无实例时，一并排队开通。字段同 3.2 的开通接口 |

未提及的可选字段保持原值不变，接入方可以只传变化的部分。

响应回显实际生效的平台角色与组织：

```json
{"user_id": 57, "username": "s2024010233", "created": true, "role": "member",
 "tenant_id": 1, "tenant_slug": "cls-2024-ai1", "tenant_role": "developer",
 "active": true, "env_id": 88, "env_status": "provisioning"}
```

带上 `provision` 后，接入方每个用户只需调这一个接口，账号与实例一次办完。

```
POST /api/ext/users/deactivate      scope: users:write
```

请求 `{"external_id": "...", "stop_envs": true}`。停用账号并使其已签发的登录令牌全部失效。**永不删除用户、实例或代码。** 是否同时停机由 `stop_envs` 决定，默认 true，由接入方判断。

```
POST /api/ext/users/delete          scope: users:write + 令牌开启「允许删除用户」
```

请求 `{"external_id": "...", "purge_envs": false}`。**彻底删除平台账号，不可恢复。**

删除是唯一一个需要在令牌上单独开关的动作，默认关闭。关闭时接口返回 403 与 `delete_not_allowed`，接入方据此退回「只停用」。

该用户的实例默认移入平台回收站：容器停掉、域名摘除，数据按平台的回收站保留天数留存，期间可恢复。传 `purge_envs: true` 才连同数据立即销毁。平台管理员账号一律拒绝删除，接入方不该有能力删掉运维账号。

```
POST /api/ext/users/reconcile       scope: users:write
```

请求 `{"external_ids": [...], "stop_envs": true}`，传当前全量有效名单。OdooshCN 把该来源下不在名单里的账号停用，返回差异摘要。供接入方定期对账，弥补实时推送的漏发。

**注意**：此接口按来源全量比对，传空数组会停用该来源下所有账号。接入方须在自己一侧确保名单完整才调用，OdooshCN 会在名单为空或差异超过一定比例时拒绝并要求显式确认。

### 3.2 实例查询与开通

```
GET  /api/ext/envs?external_id=...  scope: envs:read
```

返回该用户在令牌组织下的实例：

```json
{"envs": [{"id": 88, "name": "test1", "kind": "dev", "status": "sleeping",
           "odoo_version": "18", "url": "https://test1-apache.lab.school.edu.cn",
           "created_at": "2026-09-01T10:00:00+08:00"}]}
```

```
POST /api/ext/envs                  scope: envs:write
```

请求：

| 字段 | 必填 | 说明 |
|---|---|---|
| external_id | 是 | 实例的拥有者 |
| name | 是 | 实例名 |
| odoo_version | 否 | 默认取平台设置 |
| edition | 否 | `community` / `enterprise` |
| lang | 否 | 初始语言 |
| mem_mb / cpus | 否 | 资源上限 |
| sleep_idle_hours | 否 | 闲置休眠小时数 |

返回作业 id，实例异步创建。规格由接入方决定，OdooshCN 只校验是否超出令牌上限与平台配额。

### 3.3 免登入口（已实现，需扩展）

```
POST /api/ext/handoff               scope: handoff
```

`uid` 字段扩展为同时接受用户名与 `external_id`，按令牌的来源标识解析。其余不变。

新增可选参数 `menu`（仅 `target=console` 生效）：`false` = 本次免登隐藏控制台左侧菜单（嵌入 iframe 时接入方自带导航，不需要两套），`true` = 显示，不传 = 用令牌上的「免登默认隐藏左侧菜单」开关。纯展示层设置，只作用于本次打开的标签页，不影响该用户用账号密码正常登录。

### 3.4 错误约定（决定接入方的重试策略）

响应体统一带一个稳定的 `code` 字段，接入方的队列据此判断是重试还是转人工，不靠解析中文文案。

| HTTP | code | 含义 | 接入方应对 |
|---|---|---|---|
| 200 | — | 成功 | 标记完成 |
| 400 | `invalid_username` 等 | 参数不合法 | 不重试，转人工 |
| 401 | `token_invalid` / `token_expired` / `token_revoked` | 令牌问题 | 不重试，告警 |
| 403 | `exceeds_token_limit` | 超出令牌上限 | 不重试，转人工 |
| 409 | `username_taken` | 用户名被别人占用 | 不重试，由接入方改名后再来 |
| 429 | `rate_limited` | 限流 | 退避后重试 |
| 5xx | `internal` | 平台故障 | 退避后重试 |

判断准则：4xx 是调用方的问题，重试无用；429 与 5xx 是暂时性的，值得重试。

### 3.4.1 令牌管理（平台管理员）

| 接口 | 说明 |
|---|---|
| `GET /api/tokens` | 列表，含权限范围、上限、最近使用 |
| `POST /api/tokens/verify-identity` | 输当前密码换 5 分钟身份确认凭据（创建与编辑都要） |
| `POST /api/tokens` | 创建，明文只返回一次 |
| `PUT /api/tokens/{id}` | **编辑权限范围、上限、名称、有效期。令牌明文不变，接入方不用重新粘贴，对下一次请求立即生效。** 来源与绑定组织不可改 |
| `DELETE /api/tokens/{id}` | 吊销 |

联调时最常见的问题是令牌权限不够（只勾了免登）。以前只能重建令牌再去接入方重新粘贴，现在在列表里点「编辑」补勾即可。

### 3.5 不影响既有业务的保证

新增能力全部走新路径，既有代码零改动：

| 项 | 做法 |
|---|---|
| 路由 | 全部新增在 `/api/ext/` 前缀下的独立文件，不修改 `routers/users.py`、`routers/environments.py` 等既有路由 |
| 认证 | 令牌走独立的依赖，与登录令牌是两条互不相通的路径（登录令牌校验已强制 `typ=access`，令牌无法冒充，反之亦然） |
| 数据表 | 只在 `users` 表加两个可空列，由既有的自动加列迁移处理；存量用户的 `external_id` 为空，永远不会被同步逻辑匹配到 |
| 权限模型 | 不改 `authz.py` 的任何矩阵。同步进来的用户就是普通成员，走的是与手工建号完全相同的判定路径 |
| 回归 | 既有测试全部保持通过，新增能力自带测试 |

### 3.6 平台设置：允许嵌入的来源

新增一项平台设置「允许嵌入本平台的来源」，填写一个来源白名单。为空时保持现状，不允许任何跨源嵌入。设置后由 nginx 配置生成逻辑写入 `frame-ancestors`，控制台与实例两处同时生效。

这是通用能力，不写死任何接入方地址。

## 4. 接入方模块设计（学校 Odoo 18）

模块名 `odoosh_connector`，依赖 `base`。**所有学校特有的策略都在这里。**

### 4.1 配置

设置页，`base.group_system` 可见：

| 参数 | 说明 |
|---|---|
| `odoosh.base_url` | OdooshCN 地址 |
| `odoosh.token` | 接入令牌，只在服务端读取 |
| `odoosh.enabled` | 总开关，出问题时一键停掉同步 |
| `odoosh.scope_mode` | 同步范围：`all`（默认，所有内部用户，新建即同步）或 `groups`（仅指定用户组） |
| `odoosh.student_group_id` | `groups` 模式下的学生用户组 |
| `odoosh.teacher_group_id` | 老师用户组（可选）：成员在平台上是组织管理员，其余人按学生处理 |
| `odoosh.tenant` | 目标组织 slug，留空 = 令牌绑定组织 |

### 4.2 策略：谁该有环境、给什么

这段代码是学校独有的，写在模块里：

```python
def _odoosh_payload(self):
    """把 Odoo 的用户翻译成 OdooshCN 的用户属性。学校策略全在这里。"""
    self.ensure_one()
    is_teacher = self.has_group("odoosh_connector.group_teacher")
    number = self.employee_number or self.login.split("@")[0]
    return {
        "external_id": str(self.id),
        "username": re.sub(r"[^A-Za-z0-9_.-]", "", f"s{number}")[:64],
        "display_name": self.name,
        "tenant_role": "owner" if is_teacher else "developer",
        "active": self.active,
        "quota": {"max_envs": None if is_teacher else 1},
        "menus": {"dashboard": is_teacher, "repos": is_teacher,
                  "ai": True, "backups": is_teacher},
        "shell_enabled": True,
    }
```

要调整学生权限，改这一个函数，不动 OdooshCN。

实例规格同理，单独一个函数返回 `POST /api/ext/envs` 的参数，学校想给学生开 18 还是 19、给多少内存，都在这里定。

### 4.3 同步队列

不在 `create` / `write` 里直接发 HTTP 请求。发请求会让 OdooshCN 的可用性直接变成 Odoo 建账号的可用性，网络一抖就建不了用户。

新增模型 `odoosh.sync.queue`：

| 字段 | 说明 |
|---|---|
| user_id | 关联的 res.users |
| operation | `upsert` / `deactivate` |
| state | `pending` / `done` / `failed` |
| attempts | 已尝试次数 |
| next_retry_at | 下次重试时间，指数退避 |
| last_error | 最后一次错误，便于排查 |

`ir.cron` 每分钟取一批处理，失败按 1、5、15、60 分钟退避，超过 5 次转 `failed` 留后台等人工处理。另一个每日 `ir.cron` 调 `reconcile` 做全量对账。

不引入 OCA 的 `queue_job`，避免给学校的部署增加模块依赖。

### 4.4 钩子

覆写 `res.users` 三个方法，只入队，不做网络请求：

```python
WATCHED = {"login", "name", "active", "groups_id"}

def create(self, vals_list):
    users = super().create(vals_list)
    users._odoosh_enqueue("upsert")
    return users

def write(self, vals):
    res = super().write(vals)
    if WATCHED & set(vals):          # 改头像、改偏好不触发
        self._odoosh_enqueue("upsert" if vals.get("active", True) else "deactivate")
    return res

def unlink(self):
    self._odoosh_enqueue("deactivate")   # 转成停用,不是删除
    return super().unlink()
```

`_odoosh_enqueue` 做三件事：判断总开关；判断该用户是否落在学生组或老师组，不在则跳过；用 `sudo` 写队列。入队必须 `sudo`，触发者可能是用户本人修改自己的资料。

归档是真正的退课场景，`unlink` 实际很少发生，但仍要覆盖，一律转成停用。

### 4.5 界面

顶级菜单「实验环境」：

**我的环境**：`ir.actions.client`，渲染占满内容区的 iframe。控制器 `/odoosh/embed` 在服务端调 `handoff` 换取入口地址作为 `src`。

嵌入的是 OdooshCN 控制台而非实例本身。学生在控制台里能看实例列表、写代码、看日志、重置环境，再从控制台进实例的 Odoo。直接嵌实例会丢掉教学要用的开发功能，而且形成 Odoo 套 Odoo，两套顶栏和快捷键互相打架。

**环境状态**（可选）：看板视图，数据来自 `GET /api/ext/envs`。控制台本身已是卡片式列表，不想维护第二套视图可省略。

老师额外可见「同步队列」，查看失败记录并手动重试。

### 4.6 安全约束

写进模块的硬性要求：

1. 令牌只在 `sudo` 下读取，任何返回前端的数据不得包含它。
2. 传给 OdooshCN 的身份一律取自 `request.env.user`，**绝不接受来自请求参数的用户标识**。否则学生改一个参数就进了同学的环境。
3. 控制器 `auth="user"`，不用 `public`。
4. 入口地址取到后立即用于 iframe，不落库、不写日志。

## 5. 分期

| 期 | OdooshCN 侧 | 接入方侧 | 依赖 |
|---|---|---|---|
| 一 | 令牌 scope 与上限；users 表加 external 两列；users 写入三接口 | 配置、策略函数、队列、钩子 | 无 |
| 二 | 嵌入来源白名单设置与 nginx 生成 | iframe 菜单 | 同域名 |
| 三 | envs 查询与开通接口 | 状态看板、批量开课 | 一、二 |

一期做完，用户已能用自己的账号在 OdooshCN 工作，只是新标签页打开。二期收进接入方系统。三期补齐管理能力。

## 6. 风险

| 风险 | 应对 |
|---|---|
| 接入方不能提供同域，嵌入不成立 | 开工前确认；退回新标签页，一期成果不受影响 |
| `users:write` 令牌泄露可批量造账号 | 令牌上限限死组织、角色、配额；创建的用户恒为 member、随机密码；可随时吊销；记录调用来源 IP |
| `reconcile` 名单不完整导致误停用 | 名单为空或差异超阈值时拒绝，要求显式确认 |
| 接入方主键变化导致失联 | 提供按用户名重新绑定 `external_id` 的运维接口 |
| 集中上课时实例同时唤醒 | 按人数实测内存；课前批量唤醒 |
| 接入方顾虑改核心模型 `res.users` | 钩子只入队不发请求，失败不影响建账号；提供总开关 |


---

## 6.1 接入方模块的简化（2026-09-07）

联调后按使用反馈把接入方模块改成「装上填好参数就能用」：

| 原设计 | 现状 |
|---|---|
| 用户须先加入学生 / 教师用户组才同步 | 所有内部用户自动同步；新建即同步并自动开启该用户的同步开关 |
| 学生 / 教师策略写在代码的 `_odoosh_payload()` 里 | 平台角色、组织、组织内角色、Shell、企业版、自动开通、配额、四个菜单开关全部是 `res.users` 上的字段，在用户表单「实验环境」页签里改，改了就同步 |
| 设置页要选同步范围与两个用户组 | 设置页只剩总开关、地址、令牌、默认组织与实验环境规格 |
| 「实验环境」菜单要加组才可见 | 所有内部用户可见，控制器按同步开关放行 |

规则只剩三条：新建即同步；修改时开关开着就同步、关着就不管；归档 / 删除时开关开着就停用平台账号，恢复归档重新启用。永远不同步的只有门户用户与 Odoo 内置账号（OdooBot、public、模板用户、Administrator、default_user）。

平台侧未改：这些字段正好一一对应 `POST /api/ext/users` 的参数，通用边界不受影响。

## 6.2 语言与删除语义（2026-09-07）

**删除对应删除。** 原先接入方删除用户只在平台上停用，现在改为真删：平台新增 `POST /api/ext/users/delete`，需要令牌单独开启「允许删除用户」。被删用户的实例先进平台回收站，数据在保留期内仍可恢复，账号本身不可恢复。归档仍然只是停用，恢复归档重新启用。

**模块改为英文 + 中文翻译包。** 接入方模块的代码、注释、字段标签、视图文案、通知消息全部改为英文，中文以标准的 `i18n/zh_CN.po` 提供（209 条，由 Odoo 导出的模板生成，带正确的引用行）。这样模块可以直接交给不使用中文的开发者，也符合 Odoo 生态的惯例。

版本升到 `18.0.2.0.0`，并带一个迁移脚本：定时任务、用户组、模块分类是 `noupdate` 数据，升级不会覆盖，迁移脚本把它们的旧中文名改成英文，并删掉已废弃的学生用户组。

## 7. 实现状态（2026-09-04）

### OdooshCN 侧

| 文件 | 内容 |
|---|---|
| `backend/app/models.py` | `users` 新增 `external_source`、`external_id` 两列 |
| `backend/app/main.py` | 联合唯一索引 `uq_users_external`；`/api/ext/*` 的错误码响应处理器 |
| `backend/app/models_token.py` | 令牌新增 `scopes`、`source` 与三项安全上限 |
| `backend/app/services/extsync.py` | upsert / 停用 / 对账 / 实例开通，全部与业务语义无关 |
| `backend/app/routers/ext.py` | 六个接口，参数与错误码见第 3 节 |
| `backend/app/routers/tokens.py` | 令牌创建支持 scope、来源标识与上限 |
| `frontend/src/components/ApiTokensDialog.vue` | 令牌管理界面加上权限范围与上限 |
| `backend/tests/test_ext_sync.py` | 服务层回归：幂等、上限、对账保护 |
| `backend/tests/test_ext_api.py` | HTTP 契约：认证、scope、错误码、幂等 |

测试结果：85 通过。另有 5 个 `test_git_service.py` 的失败，在未含本次改动的 HEAD 上同样存在，与本次无关。

### 接入方模块

位置 `D:\odoo_project\odoo18-2\odoo\custom_project\school-python\odoosh_connector`。

| 文件 | 内容 |
|---|---|
| `models/odoosh_client.py` | 与平台通信的唯一出口；令牌只在此读取；区分可重试与永久失败 |
| `models/odoosh_sync_log.py` | 同步队列：入队、退避重试、对账、人工重试 |
| `models/res_users.py` | **学校策略的唯一落点**：`_odoosh_payload` 与 `_odoosh_env_spec` |
| `models/res_config_settings.py` | 设置页；令牌只回显掩码与尾 4 位 |
| `controllers/main.py` | 学生入口；身份只取自会话，不接受请求参数 |
| `static/src/js/odoosh_embed.js` | 「我的实验环境」看板 |

### 与原设计的偏差

**不做 iframe 嵌入。** 原设计第 2.3 节主张把控制台嵌进课程系统。实际实现改为在课程系统里放原生看板，点按钮新标签页全屏打开。原因是嵌入会形成三层导航栏，而学生的真实节奏是控制台与实例来回切换，嵌任何一个都在给最高频的动作加摩擦。副作用是第 2.1 节的同域名前置条件不再是必须项，接口与看板在任何部署下都能用。

若日后仍要嵌入，第 2.1 节的结论依然成立：同域可嵌控制台与实例，跨域只能嵌控制台。
