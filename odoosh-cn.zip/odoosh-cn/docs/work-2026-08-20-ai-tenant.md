# 非超管用户的 AI(公司级智能助手 `assist` 模式)— 2026-08-20

> **已实现并部署 + 隔离测试通过(2026-08-20)**。
> 后端:`models_ai.AiConversation.tenant_id` 新列;`ToolCtx.tenant_id`;`tools/registry` 加 `scope`/`assist` 标记 + 改写 `available_tools`;
> `tools/instance._authorize()`(非超管每次操作跑 `check_env`,先 tenant 匹配再矩阵判定)+ 各工具按对应动作授权;`list_envs` 按 `env_roles_bulk` 过滤;
> 平台工具与 SQL/exec 标记 `assist=False`(assist 完全不注册);`prompts.assist_prompt`;`loop` 按 mode+tenant 组装 ctx;`routers/ai` 默认 mode=assist、创建时校验公司成员。
> 前端:`AiChatPanel` 新增 assist 模式(徽章「智能助手」、诊断快捷问题、发起会话带 currentTenantId);`Layout` 上下文感知对所有用户生效。
> **隔离测试(实测通过)**:①Beta 用户对 Acme 实例任何工具→拒;②同公司但无该实例权限(非拥有者/未在 ACL)→拒「不在授权名单内」;
> ③有权(拥有者/ACL)→放行且按矩阵动作;④`list_envs` 只返回可见实例;⑤创建会话 pin 到非本人公司→403;⑥assist 工具集无 SQL/exec/平台工具。
> 待用户自测:非超管填自己的 key 后跑一次诊断 + 一次重启确认卡。


> **定稿(2026-08-20)**:作用域=公司级全局助手;能力=诊断 + 受控修复(按矩阵动作 + 确认卡);
> **完全不碰业务数据 → 租户 AI 不注册 `env_sql`/`env_sql_write`/`container_exec`,也不给任何平台级工具**。
> 用户核心诉求:让用户「了解功能 + 解决实例内的问题」,但**极怕越权**。
> 越权防线的根本:LLM 从不持有权限,每次工具调用后端都用与网页按钮同一个 `check_env(真实用户, env, 动作)` 授权;
> 再砍掉最危险的 SQL/exec 工具 → 可越的权本就不存在。
>
> **最终工具集(assist)**:只读 env_info/env_logs/env_metrics/env_health/deploy_history/list_envs;
> 修复 env_start/env_stop/env_restart/env_wake/env_redeploy。无 SQL、无 exec、无平台工具。
> 前置:超管 ops 模式 + 全套工具 + MCP 已上线(见 `work-2026-08-20-ai.md`)。本稿只涉及**非超管**用户。

## 一、核心原则:AI 权限 = 用户手点权限,一分不多

不新造权限体系,直接复用 `authz.py` 的 `ENV_MATRIX` + `check_env(db, user, env, action)`。
**每个 AI 工具执行前,调用与「用户自己点按钮」完全相同的那次 `check_env`**:

- 变更工具查它对应的既有动作(`env_restart`→`restart`、`env_redeploy`→`deploy`、`env_stop`→`stop`…)。
- 只读工具查对应读动作(`env_logs`→`logs`、`env_metrics`→`stats`、`env_info`→`view`)。

推论(全部自动成立,几乎不用新写判定):
- 开发者可让 AI 重启/部署 **非生产**实例(矩阵 `NONPROD`),对生产实例自动被拒。
- tester 矩阵里只有 `view`+`open`(无 `logs`/`stats`)→ AI 对他查不出日志监控 → 自然退化为纯问答。
- 可访问成员(viewer)有 `logs`/`stats` → 可只读诊断,但任何变更被拒。
- 移出公司 / 公司停用 → `env_role` 立即返回 None → AI 全部失效(已有逻辑)。

## 二、作用域:公司级全局助手(tenant-scoped)

- 会话绑定一个公司:`AiConversation` 增列 `tenant_id`(可空;`assist` 模式必填,`ops`/`help` 为空)。
- 创建 assist 会话时,后端用 `require_tenant_role(db, user, tenant_id)` 校验该用户确属这家公司;前端传当前公司 `currentTenantId`。
- 多公司用户:一个会话钉在一家公司;切公司 = 新会话(或全局 AI 页按当前公司起会话)。
- **AI 的一切实例操作被双重钉死**:①工具只在 `conversation.tenant_id` 内找实例;②再对每个 env 跑 `check_env`。绝不跨公司。

## 三、模式收敛

| 模式 | 谁 | 工具 | 知识库 |
|---|---|---|---|
| `ops` | 超管 | 平台级 + 全实例(所有工具) | 无 |
| `assist` | 非超管 | **仅实例级**,按 `check_env` 逐次授权;平台级工具永不暴露 | 含 help_kb(既能答「怎么用」又能诊断「为什么挂」) |
| `help` | 保留:无实例访问权的人(assist 工具解析为空时等价) | 无 | 有 |

建议:非超管统一走 `assist`——它内含 help 知识库,能查得动就诊断、查不动就退化成问答,**不用让用户在「问答」和「诊断」之间选模式**。`help` 作为特例保留即可。

## 四、工具 → 权限映射表(assist 模式)

平台级工具(`platform_overview`/`platform_service_logs`/`docker_ps`/`docker_events`/`host_resources`/`nginx_status`/`platform_service_restart`/`prune_resources`/`nginx_reload`):**super-only,assist 不暴露**。

实例级工具:

| 工具 | 类型 | 检查动作 | 备注 |
|---|---|---|---|
| `list_envs` | 只读 | 作用域过滤 | 仅返回 `conversation.tenant_id` 下、`env_roles_bulk` 非 None 的实例;**绝不泄露他公司** |
| `env_info` | 只读 | `view` | |
| `env_logs` | 只读 | `logs` | |
| `env_metrics` | 只读 | `stats` | |
| `env_health` | 只读 | `logs` | 读容器状态 + 探测 |
| `deploy_history` | 只读 | `logs` | |
| `env_sql`(只读) | 只读 | `shell` | **仅有 Shell 权限者**(用户定);能读全库数据≈Shell |
| `read_spill` | 只读 | — | 会话内落盘回读 |
| `env_start` | 变更 | `start` | 确认卡 |
| `env_stop` | 变更 | `stop` | 确认卡 |
| `env_restart` | 变更 | `restart` | 确认卡 |
| `env_wake` | 变更 | `start` | 唤醒≈启动 |
| `env_redeploy` | 变更 | `deploy` | 确认卡;自带回滚 |
| `env_sql_write` | 变更 | `shell` | 确认卡;高危,或保守起见 super-only(见开放问题) |
| `container_exec` | 变更 | `shell` | 确认卡;灾难命令即使确认也拒(已有 guards) |

> Shell 工具额外叠加用户级开关:`authz.shell_allowed()` = 用户 `shell_enabled`(超管设置)× 矩阵 `shell`。即「有 Shell 权限」= 这个组合,与手点 Web Shell 完全一致。

## 五、需要的架构改动(评估:中等,不伤筋动骨)

1. **`ToolCtx` 带真实 User + 作用域**:现在只有 `user_id`。加 `user: User`(跑 `check_env`)、`tenant_id: int | None`(assist 的公司;super 为 None=全域)、`is_shell_user`(缓存 shell 开关)。
2. **新授权入口 `authorize_env(ctx, env, action)`**(registry 或 tools 公共处):
   - super → 放行;
   - 否则先 `env.tenant_id == ctx.tenant_id` 再 `check_env(db, ctx.user, env, action)`;拒绝抛 `ToolError`(AI 能看到「无权…」并转而说明)。
   - 实例级工具把现有第一行 `_require_super` 换成 `authorize_env`;平台级工具保留 `_require_super`。
3. **`list_envs` 分支**:assist 模式走 `env_roles_bulk` + 限 `conversation.tenant_id`;super 保持现状。
4. **`available_tools(is_super, mode)`**:assist → 仅实例级工具集;super+ops → 全集;help → 空。
   (SQL/exec 类工具是否在 assist 里对无 shell 用户直接隐藏,还是列出但运行时拒——见开放问题。)
5. **`AiConversation.tenant_id` 列** + 路由 `create_conversation` 接收并校验 tenant;`run_message` 把 tenant_id 传进 `ToolCtx`。
6. **prompt**:新增 `assist_prompt(kb)`——身份=「公司内的运维助手」、注入边界、纪律(反假绿、先证据后结论)、**明确只在授权范围内操作、越权会被系统拒绝**、含 help_kb。
7. 前端:非超管的 dock/整页面板 mode 显示「智能助手」;会话绑定当前公司(已有 `currentTenantId`);上下文感知在实例页预填「诊断当前实例」对 assist 同样生效。

## 六、安全红线(逐条对应实现检查项)

1. **租户隔离**:每个实例工具「先 load env → `authorize_env`(含 tenant 匹配)」;`list_envs` 严格过滤。→ 需专门测试:A 公司用户对 B 公司 env_id 的任何工具都返回「无权」。
2. **越权提权**:变更工具查精确动作;开发者拿不到生产、viewer 拿不到任何变更。
3. **数据外泄**:原始 SQL 仅 shell;工具输出脱敏(已有);实例日志=不可信输入(注入边界已有)。
4. **确认卡 + 审计**:变更走确认;`AiToolRun` 记录非超管 user_id + 批准渠道(问责链完整)。
5. **成本**:每人每日 token 上限(已有);assist 也受限。
6. **MCP**:保持 super-only,不对租户开放。

## 七、实施分期(设计通过后)

- **P1 — assist 只读**:`tenant_id` 列 + `ToolCtx` 改造 + `authorize_env` + 只读工具(view/logs/stats/health/deploy_history)+ `list_envs` 过滤 + assist prompt + 前端 mode。**最小可用,先验证隔离正确**。
- **P2 — 修复**:开放变更工具(按矩阵动作 + 确认卡)。
- **P3 — SQL / exec**:`env_sql`(只读,shell 门)、`env_sql_write` / `container_exec`(shell 门 + 确认)。

## 八、开放问题(请你定)

1. **`env_sql_write` / `container_exec`**:按「shell 门 + 确认卡」开放给有 shell 的租户用户,还是**保守起见仅超管**?(读 SQL 已定 shell 门;写 SQL / 任意 exec 破坏力更大。)
2. **无 shell 用户的工具可见性**:SQL/exec 工具在 assist 里**直接不列出**(干净),还是**列出但运行时拒**(AI 会撞一次「无权」再换路)?倾向直接不列出。
3. **tester 是否彻底只给问答**:按矩阵他本就查不出日志,assist 会自动退化;要不要连 dock 里的诊断入口都对纯 tester 隐藏,只留问答?
4. **P1 是否也顺带把 help 合并进 assist**(一个助手既问答又诊断),还是保留两种模式并存?倾向合并。
