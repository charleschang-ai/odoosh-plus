# 在 WSL2 上跑 OdooshCN

平台本身只面向 Linux 服务器;Windows 上开发 / 试用请在 WSL2 里跑。
下面这些坑与平台代码无关,全是 WSL2 自身的行为,但不处理会让你以为"服务不稳定"。

## 1. `.wslconfig`(最重要)

这个文件在 **Windows 主机**上(`C:\Users\<你>\.wslconfig`),不在 Linux 里,
所以 `deploy/install.sh` 够不着它 —— 必须手工配。改完要 `wsl --shutdown` 才生效。

推荐内容(内存 / 核数按自己机器调):

```ini
[wsl2]
# 镜像网络:WSL 与 Windows 共用网卡和 IP,局域网可直接访问 WSL 里的端口
networkingMode=mirrored
memory=6GB
processors=6
swap=4GB
swapFile=D:\wsl\swap.vhdx
nestedVirtualization=true

[experimental]
hostAddressLoopback=true
autoMemoryReclaim=gradual
```

WSL 2.7 起,以下三个键**已失效**,写了只会每条命令刷一遍告警:

| 键 | 情况 |
| --- | --- |
| `pageReporting` | 已移除,报"未知键" |
| `localhostForwarding` | 镜像网络模式下无效 |
| `sparseVhd` | 因数据损坏风险被全局禁用,vhdx 只涨不缩 |

## 2. 空闲时整个发行版会被关掉 ← 最容易误判成"服务坏了"

WSL 在没有活动会话时会把整个虚拟机停掉。表现是:

- 浏览器打开 `http://localhost:8080` 十次有八次连不上;
- 进去一看容器却是 `Up 6 seconds`、`RestartCount=0`、没有 OOM —— 服务其实每次都正常启动,
  只是你访问的那一刻它刚好是关的,或者刚开机还没就绪。

`.wslconfig` 里的 `vmIdleTimeout` **不解决这个问题**(实测 `-1` 无效)。
可靠办法是让一个客户端一直连着:

```powershell
# 办法 A:开一个 WSL 窗口挂着别关(最简单)
wsl -d odoosh

# 办法 B:后台挂一个占位进程(不占窗口),可放进开机启动
Start-Process -WindowStyle Hidden wsl.exe -ArgumentList '-d','odoosh','-u','root','--','sleep','infinity'
```

停掉办法 B:`wsl --terminate odoosh`(或结束对应的 wsl.exe 进程)。

## 3. 端口:别用默认的 80

镜像网络模式下 WSL 与 Windows 共用端口空间,而 Windows 的 `System`(http.sys)
通常占着 `[::]:80`。装的时候明确指定:

```bash
bash deploy/install.sh --port 8080 --base-domain localhost
```

compose 还会绑 443、8088(ACME)、10001-10020(实例端口池),被占的话
用 `--https-port` / `--acme-port` / `--env-port-range` 换掉(第 3 步会逐个预检并提示)。

## 4. systemd 必须开着

Docker 以 systemd 服务运行。新版 Ubuntu 的 WSL 镜像默认已开启,确认一下:

```bash
wsl -d odoosh -- bash -c "ps -p 1 -o comm="   # 应输出 systemd
```

不是 `systemd` 的话,在发行版内写 `/etc/wsl.conf`:

```ini
[boot]
systemd=true
```

然后 `wsl --terminate <发行版>` 重进。

## 5. 磁盘只涨不缩

`sparseVhd` 已失效,删掉的数据不会还给 Windows。手工压缩(先关机):

```powershell
wsl --shutdown
wsl --manage odoosh --set-sparse true --allow-unsafe
```

注意 `--allow-unsafe` —— WSL 官方把稀疏磁盘标记为有数据损坏风险,自行权衡。
另外注意:WSL 里 `df` 显示的 1TB 是虚拟上限,**真实上限是 vhdx 所在盘的剩余空间**。

## 6. 跨系统访问代码

Windows 侧用 `\wsl$\<发行版>\home\<用户>\projects\odoosh-cn` 访问
(注销重装同名发行版后,`\wsl.localhost\` 可能因缓存失效,`\wsl$\` 仍可用)。

三个注意:

- **行尾**:Windows 侧写入的文件是 CRLF,`.sh` 脚本带 `\r` 会 `bad interpreter` 起不来。
  编辑器设成 LF,或在仓库加 `.gitattributes`(`*.sh text eol=lf`)。
- **可执行位**:Windows 侧新建的文件没有 `x`,复制脚本后要 `chmod +x`。
- **git**:Windows 侧默认 `core.autocrlf=true`,会改行尾;要在那边提交请先
  `git config core.autocrlf false`。

大量文件操作(git clone / npm install)建议在 WSL 侧做,9p 跨系统很慢。
