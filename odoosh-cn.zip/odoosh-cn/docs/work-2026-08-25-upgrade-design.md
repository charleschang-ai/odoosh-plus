# Odoo 升级功能设计（2026-08-25，仅设计不开发）

调研结论见 work-2026-08-25-upgrade.md。本文回答两个问题：**如何升级**（产品流程 + 技术流水线）
和**需要哪些字段**（数据模型）。风格对齐现有代码：模型独立成 `models_upgrade.py`，
作业走 `jobs.spawn`，日志走 `joblog`，镜像沿用 `odoosh-base` 的命名与构建惯例。

## 一、产品形态：两种模式

仿 odoo.sh 的思路，升级分两步走，**测试升级不动生产，正式升级必须先测过**：

### 模式 A：测试升级（mode=test）——随时可做、可丢弃
```
选择实例 → 预检报告 → 备份生产库+filestore
  → 创建目标版本的新 staging 实例（挂同一 project_id）
  → 恢复副本并 neutralize（禁 cron/邮件）
  → 逐版本跑 OpenUpgrade
  → 成功：用户登录 staging 实例人工验证；失败：留日志，实例可弃
```
产物是一个普通 staging 实例（result_env_id），用户像用任何 staging 一样验证业务。

### 模式 B：正式升级（mode=production）——有前置条件
前置：预检绿灯 + 该实例 30 天内存在同路径 **成功的 test 升级**（可由超管豁免）。
```
锁实例(status=upgrading) → pre_upgrade 备份 → 停 Odoo 容器
  → 逐版本跑 OpenUpgrade（不 neutralize）
  → 换 env.odoo_version / 基础镜像 → 重新 provision → 启动 → 健康检查
  → 成功：done；失败：自动恢复 pre_upgrade 备份 + 恢复原版本容器 → rolled_back
```

### 自定义代码的处理（关键，容易漏）
数据升级只解决数据库；`Environment.repo_url/branch` 指向的自定义模块代码必须
有目标版本的分支。因此：
- 预检项之一：要求用户填「目标版本代码分支」（`options.target_branch`），
  没有自定义代码的实例跳过；
- test 模式建 staging 实例时直接检出目标分支；
- production 模式收尾时把 env.branch 切到目标分支再 provision。
自定义模块自身的 `migrations/` 脚本是用户的责任，平台文档引导用 openupgradelib。

## 二、技术流水线（一次 hop 的执行）

每个 hop（如 16→17）在**一次性升级容器**里执行，容器用完即删：

```
镜像:   odoosh-upgrade:<to_version>
        = 目标版 Odoo 源码 + OpenUpgrade <to>.0 分支 + openupgradelib + 匹配的 Python
挂载:   该实例的 filestore 卷（同现有编排）
网络:   接入租户网络，连租户 PG
命令:   odoo -d <db> --db_host=... \
          --update all --stop-after-init \
          --load=base,web,openupgrade_framework \
          --upgrade-path=/opt/openupgrade/openupgrade_scripts/scripts
环境:   OPENUPGRADE_TARGET_VERSION=<to>.0
        OPENUPGRADE_RENAMED_MODULES / OPENUPGRADE_MERGED_MODULES（来自 options）
判定:   exit code == 0 且日志无 CRITICAL/Traceback 收尾 → hop 成功
日志:   docker logs 流式写 joblog（复用部署日志的展示通道）
超时:   settings upgrade.hop_timeout_hours（默认 6h）强杀 → failed
```

hop 之间不换库：同一个库连续被各版本容器处理。全部 hop 完成后才算 running → verifying。

预检（同步、秒级）在旧库上执行：
```sql
SELECT name, latest_version FROM ir_module_module WHERE state='installed';
```
分桶规则：官方 CE 模块名单（按版本内置）→ core；env.edition=enterprise 或命中企业模块
名单 → enterprise（红灯，只能走官方服务）；OCA 已知仓库清单 → oca；其余 → third_party。
core 桶再对照 OpenUpgrade coverage 数据（随升级镜像发布时快照成 JSON 存平台）标
done / nothing / missing。输出三色结论：全绿可升；有 missing/third_party 黄灯（列出
建议：卸载/自写脚本/等社区）；有 enterprise 红灯。

## 三、数据模型（models_upgrade.py）

### UpgradeJob —— 一次升级（贯穿多个 hop）

| 字段 | 类型 | 说明 |
|---|---|---|
| id | int PK | |
| tenant_id | FK tenants, index | |
| environment_id | FK environments SET NULL, index | 实例删除后记录保留 |
| tenant_slug / env_name | str 快照 | 同 Backup 的做法，目标没了记录仍可读 |
| database_id | int nullable | 附加库升级预留；None=主库 |
| db_name | str | 快照 |
| mode | str(16) | test \| production |
| edition | str(16) | 快照自 env.edition；enterprise 在创建时即拒绝 |
| source_version / target_version | str(8) | 如 "16" / "18" |
| path | Text JSON | 计划的 hop 列表 `["16→17","17→18"]`，创建时算好存死 |
| status | str(16) index | 见下方状态机 |
| current_hop | int default 0 | 正在跑第几个 hop（0 起） |
| progress | int 0-100 | 粗粒度：按阶段+hop 数折算，前端进度条 |
| precheck_report | Text JSON | 模块分桶+coverage 结果+结论色；创建时生成 |
| precheck_color | str(8) | green \| yellow \| red（列表页不解析 JSON） |
| options | Text JSON | target_branch、renamed/merged modules、待卸载模块清单、超时覆盖 |
| backup_id | FK backups SET NULL | pre_upgrade 备份（production 模式必有；test 模式=克隆用的备份） |
| result_env_id | int nullable | test 模式产出的 staging 实例 id |
| test_job_id | int nullable | production 模式引用的那次成功 test 升级（豁免时 None） |
| neutralized | bool | test=true / production=false，留痕 |
| message | str(512) | 最后一条状态说明（同 Environment.status_message 用法） |
| log | Text deferred | 汇总日志（分 hop 明细在 UpgradeStep.log） |
| created_by / created_by_id | str / int | 同 BulkJob |
| idempotency_key | str(64) unique nullable | 防双击 |
| created_at / started_at / finished_at | datetime | |

状态机：
```
pending → prechecking → precheck_failed(终)
        ↘ backing_up → cloning(仅test) → running → verifying → finalizing → done(终)
任何阶段 → failed(终, production 先尝试回滚) → rolled_back(终)
pending/running 可 → cancelling → cancelled(终, production 同样先回滚)
```

### UpgradeStep —— 一个 hop 的一次执行（重试留痕，同 BulkJobItem 思路）

| 字段 | 类型 | 说明 |
|---|---|---|
| id | int PK | |
| job_id | FK upgrade_jobs CASCADE, index | |
| hop_index | int | 0 起；重试产生同 hop_index 的新行 |
| from_version / to_version | str(8) | |
| attempt | int default 1 | |
| image_tag | str(128) | 实际用的 odoosh-upgrade 镜像（含构建日期 tag），复现用 |
| container_name | str(128) | 跑挂了便于人工排查 |
| status | str(16) | pending \| running \| success \| failed \| skipped |
| message | str(512) | 失败摘要（日志最后的异常行） |
| log | Text deferred | 该 hop 完整 odoo 日志 |
| stats | Text JSON | 耗时、警告数、legacy 列数等，报告页展示 |
| started_at / finished_at | datetime | |

### UpgradeImage —— 升级工具镜像注册表

| 字段 | 类型 | 说明 |
|---|---|---|
| id | int PK | |
| target_version | str(8) unique | 一个目标版本一行 |
| image_tag | str(128) | odoosh-upgrade:<ver>-<yyyymmdd> |
| openupgrade_commit | str(64) | 构建时 OpenUpgrade 分支的 commit（脚本随社区更新，重建有意义） |
| openupgradelib_ref | str(64) | |
| coverage_json | Text deferred | 该版本 coverage 快照（构建时从 analysis 目录扫描生成），预检用 |
| status | str(16) | building \| ready \| failed |
| message / log | | 构建日志，同 images 服务惯例 |
| built_at / created_at | datetime | |

（构建走现有 `services/images.py` 的源码探测/加速逻辑；OpenUpgrade 仓库地址同样过
github_proxy 加速链路。）

### 复用/微调现有表（不新增字段到 Environment）

- `Backup.kind` 增加合法值 `pre_upgrade`（表结构不变，仅常量）；
- `Environment.status` 增加过渡态 `upgrading`（正式升级期间锁操作，编排器已有同类处理）；
- test 模式产出的实例就是普通 Environment（kind=staging、project_id=生产实例的项目、
  expires_at 可设自动过期），不需要新字段；
- 升级成功后更新 `Environment.odoo_version / image_tag / branch`，全是已有字段。

### 平台设置（Setting 表新 key，不建表）

| key | 默认 | 说明 |
|---|---|---|
| upgrade.enabled | false | 功能总开关（灰度） |
| upgrade.hop_timeout_hours | 6 | 单 hop 超时 |
| upgrade.require_test | true | production 是否强制先有成功 test |
| upgrade.test_env_expire_days | 14 | test 实例自动过期天数（0=不过期） |
| upgrade.openupgrade_repo | auto | OpenUpgrade 源码地址（同 odoo 源探测机制） |

## 四、API 草案（routers/upgrades.py）

```
GET  /environments/{id}/upgrade/precheck?target=18   预检（同步，秒级，可反复点）
POST /environments/{id}/upgrade                      创建 job {mode, target_version, options}
GET  /upgrades?environment_id=&status=               列表
GET  /upgrades/{id}                                  详情（含 steps、precheck_report）
GET  /upgrades/{id}/log?step_id=                     日志（复用 logstream 轮询通道）
POST /upgrades/{id}/cancel                           取消（running 时下一 hop 边界生效）
POST /upgrades/{id}/retry                            failed 的 test job 从失败 hop 重试
管理端：
GET/POST /admin/upgrade-images                       镜像列表/触发构建
```
权限：预检 view 即可；发起 test 需 operate；发起 production 需 manage；镜像管理仅超管。

## 五、UI 向导（实例详情页新增「升级」Tab）

1. **选目标版本** → 自动显示路径（16→17→18，两轮）；
2. **预检报告**：三色结论 + 模块分桶表（每个 missing/third_party 模块给处置建议）；
   红灯（企业版）直接终止并引导官方服务说明页；
3. **代码分支**：有 repo 的实例必填目标版本分支（校验分支存在）；
4. **确认页**：test 模式说明会新建 staging 实例；production 模式显示前置检查
   （成功 test 记录 + 停机提示 + 备份确认）；
5. **执行页**：hop 进度 + 实时日志（复用部署日志组件）；
6. **完成页**：test → 跳转新实例 + 验证清单（登录/关键流程/试算平衡）；
   production → 健康检查结果 + 「稳定后可执行 database_cleanup」提示（单独按钮，
   默认不自动清）。

## 六、明确不做 / 后置

- 企业版数据升级：不做脚本，预检红灯 + 文档引导官方 upgrade.odoo.com（Phase 3 再考虑编排）；
- database_cleanup / VACUUM 自动化：首版只做提示 + 手动按钮；
- 附加库升级：字段已预留（database_id），首版仅支持主库；
- 跨大版本一键（如 15→18 自动三连跳）：机制天然支持（path 多 hop），但首版 UI 限制
  最多 2 hop，降低单次风险面；
- OpenUpgrade coverage 数据的自动刷新：随镜像重建更新，不做独立同步任务。

## 七、开发切分（对齐并行会话惯例）

| 模块 | 文件 | 内容 |
|---|---|---|
| 模型+schema | models_upgrade.py / schemas_upgrade.py | 三张表 |
| 预检 | services/upgrade_precheck.py | 模块清单 SQL + 分桶 + coverage 对照 |
| 流水线 | services/upgrade.py | 状态机 + hop 执行 + 回滚（复用 backup/restore/orchestrator） |
| 镜像 | services/upgrade_images.py | Dockerfile 模板 + 构建（仿 images.py） |
| 路由 | routers/upgrades.py | 上述 API |
| 前端 | Upgrade.vue（实例详情 Tab）+ admin 镜像页 | 向导五步 |
