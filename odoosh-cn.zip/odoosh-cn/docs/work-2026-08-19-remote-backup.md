# 远程备份目标(S3 / SFTP / WebDAV)+ 实例级备份配置 — 2026-08-19/20 已完成

## 做了什么
用户可添加「自己的」远程备份目标(S3 兼容 / SFTP / WebDAV),每个实例自选推送到哪些目标;
自动备份支持「实例级覆盖」(沿用公司策略 / 本实例自定义 / 关闭)。目标只有创建者本人 + 超管可见可改。

## 后端
- models_backup.py:BackupTarget / EnvironmentBackupConfig / BackupReplica(密钥字段 Fernet 加密)
- services/remote.py:S3Driver(boto3)/SftpDriver(paramiko)/WebdavDriver(requests);
  test/put/get/delete;schedule_push(备份完成后按实例配置逐目标推,流式+sha256);pull(本地丢失时拉回并校验);
  prune_remote(按目标 keep_days 清远端);retry_pending;on_local_delete(仅 delete_with_local 同步删)
- services/backup.py:备份完成→remote.schedule_push;删除→remote.on_local_delete;恢复本地缺失→remote.pull;
  调度线程 每10分钟 remote.retry_pending、每小时 remote.prune_remote;
  run_auto_backups 重写为「实例级生效策略」(env_effective_policy:custom/off 覆盖公司;新增 env_id 参数=只备份本实例);
  prune_old_backups 增加 env_id 参数,公司级清理跳过实例级自定义保留天数的实例
- routers/backup_targets.py:/api/backup-targets CRUD+/test+/test(unsaved);
  /api/environments/{id}/backup-config GET/PUT/run-now;/api/backups/{bid}/replicas/{tid}/push
- schemas_backup.py:BackupTargetOut/In、EnvBackupConfigOut/In、ReplicaBrief;BackupOut.replicas
- requirements.txt:+paramiko +requests

## 前端
- components/BackupTargets.vue:目标列表 + 新建/编辑/测试(S3/SFTP/WebDAV 分类型表单)
- components/EnvBackupConfig.vue:实例备份设置(远程目标多选 + 自动备份 inherit/custom/off)
- views/Backups.vue:顶部「远程备份目标」折叠区;「实例备份设置」按钮(选中实例时);列表「远程副本」列(每目标一个标签,失败点击重推)
- components/project/TabBackups.vue:「备份设置」按钮展开 EnvBackupConfig

## 验证(MinIO / atmoz-sftp / bytemark-webdav 三容器实测)
- 三种目标 test 连接 OK;绑定 env17 → 手动备份 → 三目标全部 done,sha256 一致
- MinIO 手动重推 OK;删本地文件后 remote.pull 从 SFTP 拉回并校验通过
- 实例级 custom 覆盖(auto_hour/keep_days/include_extra_dbs)、run-now、inherit 回退均 OK
- 前端页面渲染正确(目标卡片、每备份的远程副本标签、仅本地标记)
- 测试目标与测试容器已清理

## 备注
- 与旧「平台级 S3 副本」(replica.py,超管全局)并存,互不影响
- 未 commit

## 追加(2026-08-20):新建备份弹窗增加「备份位置」
- Backup 新增列 push_target_ids(nullable):None=沿用实例配置(自动备份);"[]"=仅本地;"[id,...]"=手动指定目标。启动时 _auto_add_columns 自动补列。
- schemas BackupCreate 增加 location(local|remote,默认 local)+ target_ids;create_backup 校验目标归属(须本人、同公司、启用)并存 push_target_ids;remote.schedule_push 优先读 push_target_ids override。
- 前端两个入口都加了「备份位置」单选(默认仅本地)+ 远程时的目标多选(默认预勾实例已配置的目标):
  components/project/TabBackups.vue(实例「新建备份」,现总是弹窗)、views/Backups.vue(全局「新建备份」)。
- 验证:local→无推送;remote+指定目标→只推该目标;remote+无目标→400;前端 e19 选「推送到远程」自动预选其配置的 测试SFTP。

## 健壮性加固(2026-08-20)
针对远程/自动备份的异常场景做了 6 项加固(services/remote.py、services/backup.py):
1. 并发暴涨 → 固定大小工作线程池 + 队列去重(backup.remote_concurrency,默认 3);push_async/retry/schedule_push 全部改为入队。实测 10 并发只跑 3。
2. SFTP 传输中途卡住永久挂线程 → SFTP channel settimeout(600)+ S3 connect/read 超时(30/300s)。实测不可达目标 19s 失败、线程池存活。
3. 上传被截断但服务端回 2xx → push 后校验已传字节数 == 本地文件大小,不符则判失败等重试。实测少传 100 字节被拦下。
4. 进程 kill 后 pending 卡死 → retry_pending 同时捞 pending/failed(failed 优先),配合队列去重。
5. 单实例「立即备份一轮」误清整公司过期备份 → env_id 指定时不做公司级 prune。
6. 夜间批量中单个实例出错会中断整轮 → 每实例 try/except,失败只解锁+记日志,继续其余实例。
均已 rebuild + 实测通过;导入冒烟 + 活体端点正常。

## 进程/容器隔离性排查(2026-08-20)
- 其他容器(Odoo/PG):远程备份仅在 API 容器内 读本地zip+走网络,不发 docker 命令、不碰其它容器 → 零影响。
- 主进程不被拖垮:
  * 所有远程网络 I/O(push + delete)统一走 3 线程工作池;on_local_delete / prune_remote 改为「入队即返回」,不在请求线程/调度线程上同步走网络。
  * 逐层兜异常:worker 循环、push()、调度循环、逐实例自动备份、备份线程都 try/except,异常不外抛不崩进程;worker 抛错也不死。
  * 流式读(1MB)、线程数固定、句柄 finally 关闭、各驱动均有超时 → 不 OOM、不挂死。
- 实测:对不可达目标 prune_remote 0.34s 返回(非阻塞);worker 删除超时失败后仍存活并继续处理新任务;全程 API 保持响应。
- 残留(低风险、可接受):test_target 为让用户即时看到结果,同步跑在请求线程(受超时限,最坏 SFTP ~20-90s 占一个线程池线程);超管「全部公司立即备份」同步做 DB+本地清理(无远程网络 I/O)。二者都不会崩进程,最坏是单次 HTTP 响应慢。

## 自动备份派发改为有界工作池(2026-08-20)
- 问题:run_auto_backups 原来「每实例 spawn 一个 daemon 线程」,大量实例时会同时存在成百上千个阻塞线程(真正备份由 _concurrency_gate 限流,其余线程都 sem.acquire 阻塞)。原本就有,非本轮引入,当前规模无害,属未来规模化保险。
- 改法(约 30 行,单文件 services/backup.py):新增 _dispatch_q + 固定 N 个 worker(N = backup.max_concurrent);把第 1215 行的 Thread(...).start() 换成 _dispatch_backup(ids, e.id)。真正的备份并发仍由 run_backup 内的 _concurrency_gate 控制,worker 只把「同时存在的派发线程数」封顶。unlock 幂等,dispatch 循环兜底再解锁。
- 实测:30 个实例入队 → 最大并发 2(=max_concurrent)、30 个全部完成、队列清空、API 健康;真实 run-now(env17 custom)产出 auto 备份 #31 done,派发链路正常。
- 注:改 backup.max_concurrent 后派发线程数需重启生效(与信号量动态重建略有差异,可接受)。

## Shell / 实例容器 安全加固(2026-08-20)
审查发现:实例容器零加固(PidsLimit=nil、SecurityOpt=[]、CapDrop=[]),Shell 里可 fork 炸弹拖垮宿主机;同公司实例共用 PG 集群,PUBLIC 默认可跨库 CONNECT。修复(services/orchestrator.py):
- container_hardening():所有 Odoo 容器加 pids_limit(limits.env_pids,默认 512)+ no-new-privileges + cap_drop ALL + init=True(tini 回收僵尸)。经 run_main_container / run_oneoff 生效,覆盖正式容器、一次性任务、黄金模板。
- harden_db_access():建库后 REVOKE CONNECT ON DATABASE FROM PUBLIC + GRANT 给库主;实例(重)启时对存量库幂等收紧。阻止同公司其它实例的 db_user 跨库连接。
- restart 改为「重建容器」(经 run_main_container),使存量实例一次重启即套用加固/新资源上限;失败回退原地重启;重建后 nginx 重连网络 + reload。
实测:pids_limit=512 挡住 fork 炸弹且仅限本容器(其它实例/PG/API 全程正常,宿主机未受影响);tini 回收僵尸,fork 风暴后 pids.current 回落、容器自愈不卡死;PUBLIC CONNECT 已收回,acme_demo2 角色对 acme_e19 CONNECT=false;加固后 Odoo 正常(HTTP 303)、Shell 正常、nginx 路由 200。
未加固的存量运行实例:下次重启/部署自动套用(restart 现在即重建)。评估更正:/mnt/extra-addons 是按「单仓库」挂载,跨实例只暴露同一 git 仓库的其它 commit(开发者本就有 git 权限),跨项目已隔离,不改。

## requirements.txt 自动安装(2026-08-20)
问题:Shell 帮助里写着「依赖建议放到仓库 requirements.txt」,但 deploy() 里从未实现 —— 用户按提示做会 ImportError(空头支票)。
实现(services/deploy.py install_requirements + models.py requirements_sha + settings deploy.install_requirements):
- 部署时若检出根目录有 requirements.txt → 用 run_oneoff 一次性容器执行 pip install --user(HOME=/var/lib/odoo),
  装到 ~/.local = 实例独有的 filestore 卷 → 每实例隔离、容器重建后仍在;走 settings.pip_index_url 国内镜像。
- 插在「软链切换后、停容器/模块升级前」:被升级的模块可能在加载时 import 新依赖。
- 按文件内容 sha256 记在 environments.requirements_sha,未变则跳过(避免每次部署跑 pip)。
- 安装失败 → 抛异常 → 走既有回退(恢复上一版代码并拉起),日志输出 pip 尾部;平台可用 deploy.install_requirements=0 关闭。
- 同步修正 Shell 帮助文案(现在名副其实)。
实测(env2 demo2):首次安装成功(humanize 4.16.0)、二次调用正确跳过、装进 demo2 自己的 filestore 而 e19 没有(实例隔离)、
Odoo 运行时可 import、不存在的包正确抛出异常触发回退;测试包与临时文件已清理。
隔离粒度结论:每实例/每分支 = 独立容器+独立 ~/.local(独立依赖);同实例的附加库共用容器 → 共用依赖环境(设计如此)。

## 存量实例批量套用加固(2026-08-20)
- 串行重启 5 个运行中实例(demo2/ent19/v19-enterprise/v19-enterprise-2/v18-demo)+ 之前的 e19:全部 Pids=512 Cap=[ALL] Init=true no-new-privileges,Odoo 内部 303、经 nginx 外部 200。
- 发现并修补:唤醒走 services/sleep.py wake() 而非 orchestrator.start(),两处都是 c.start() 复用旧容器 → 休眠实例醒来仍未加固。
  新增 orchestrator.needs_rebuild(c)(比对 PidsLimit/SecurityOpt/CapDrop/Init),start() 与 wake() 在「缺加固」时重建一次再启动,已加固的直接 start(唤醒仍快)。
  实测:dev(#25) 唤醒日志出现「应用安全加固:重建容器后启动」且容器带加固;c17 重启后加固。
- c17/dev 测试后已恢复为 sleeping(与原状态一致);dev2 仍休眠,下次唤醒会自动重建加固。
- 现状:9 个实例中 8 个容器已加固,仅 dev2(休眠中、从未启动过)待唤醒时自动套用。
