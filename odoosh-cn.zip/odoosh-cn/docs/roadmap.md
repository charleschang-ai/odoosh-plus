# OdooshCN 开发路线图(2026-08 定稿)

模型对齐 odoo.sh:**公司 → Git 仓库(项目)→ 分支 = 环境(生产 / 预发 / 开发)**。
「实例」总览页保留(跨公司看板);「项目页」是按仓库/分支组织的第二视角。

## 已完成
- 平台骨架、安装/卸载脚本、公司/用户/角色(超管 + 公司管理员/开发者/测试者 + 实例动作矩阵)
- 实例编排(官方镜像 / 源码自建,17/18/19,社区/企业版),进度、通知、过期自动删除,nginx 动态域名
- 企业版代码:标记的 Git 仓库(公司自有 > 平台共享),按需 shallow clone、只读挂载、复用
- 备份/恢复、Git 仓库接入(GitHub/Gitee OAuth/令牌、分支同步、Webhook)
- 平台自身重启/更新(超管)

## 阶段 1:代码部署管线(地基)
- [x] 仓库镜像 `repos/<仓库id>/mirror.git`(凭据 fetch;节流刷新)
- [x] 按提交检出 `repos/<仓库id>/<分支>@<commit>`,挂载 `/mnt/extra-addons`(生产只读)
- [x] 部署动作:拉取 commit → 换挂载(重建容器)→ 重启 / -u 模块 / -u all → 健康检查 → 失败回退
- [x] `deployments` 表 + 提交历史接口(标注当前/曾部署)
- [x] 创建实例绑定仓库+分支时内含首次部署;卡片显示 branch@commit + 「部署」+ 部署历史;编辑框内绑定与默认动作
- [x] webhook 触发部署(`services/project.register_hooks` → 预发/开发自动部署;生产只标「待部署」)

## 阶段 2:项目页(odoo.sh 详情页)—— 2026-08-16 完成
- [x] 实例详情页 `/environments/<实例id>?branch=…`(每个实例 = 一个独立项目:根实例 + 从详情页派生的环境 `project_id`);实例卡片「详情」直达;返回 → 实例列表
- [x] 左栏分支按档位分组(生产/预发/开发/未分配,未分配来自镜像 for-each-ref)、状态、搜索、同步
- [x] 拖拽 = 创建 / 改档位 / 删除(每个动作也有按钮);生产相关操作需输分支名确认
- [x] 右栏:头部动作;Tab 历史(git log × 部署记录、部署此提交、待部署)、日志、备份(+从生产刷新)、升级(企业版一键升级;大版本升级说明 + 导出备份)、Shell(占位)、设置(档位/版本/域名/过期/部署默认/自动部署/每实例资源上限)
- 后端:`services/project.py` + `routers/projects.py`(`/api/projects/<实例id>`);`Environment.project_id/mem_mb/cpus`;过渡态 `cloning`;一键登录 `services/sso.py`(实例域名 `/odoosh/sso` → 平台 API 种 Odoo session)

## 阶段 3:分支 ↔ 环境联动
- [x] 仓库唯一生产分支(项目接口 + 实例新建/编辑接口均校验)
- [x] push → 预发/开发自动部署(实例 + 仓库两级开关);生产标「待部署」
- [ ] 分支↔环境一对一强约束;远端删分支 → 销毁开发/预发环境
- [ ] 新分支自动建开发环境(仓库级开关);部署结果通知

## 阶段 4:环境成熟度
- [x] 预发从生产库克隆 + 中性化(租户 PG 内 pg_dump | psql + 复制 filestore);一键刷新;开发→预发改档位时重建库
- [x] 拖到预发 / 新建预发时弹窗选择:从生产克隆并中和(推荐)/ 保留当前库(可选仍中和)/ 新建空库(2026-08-16)
- [x] 开发环境闲置休眠 / 唤醒:nginx 每实例访问日志判定闲置(全局 `sleep.idle_hours`,每实例可覆盖),休眠为 `sleeping`;访问域名经 `@down` → `/api/wake` 落地页自动唤醒;控制台唤醒/休眠按钮(2026-08-16)
- [x] 黄金模板库:同租户 PG 内按 (版本/类型/镜像模式/镜像 id) 维护已装 base 的模板,新实例 CREATE DATABASE TEMPLATE 秒级建库(`env.use_template_db`)(2026-08-16)
- [x] 部署提速:代码挂载改 repos/<key> 根 + env-<id> 软链,部署只切软链 + 重启;update_all 用 git diff 只 -u 变更模块(2026-08-16)
- [x] 2026-09-03 改回只挂本环境检出目录(`repos/<key>/<分支>@<sha>` → `/mnt/extra-addons` 只读),部署/回退=换 code_path + 重建容器;软链布局废弃。原因:容器里能看到镜像和其它环境的检出,AI 编程模块目录选择器一片混乱,且路径随 sha 变。每实例另有读写的 `/mnt/custom-addons`(定制代码目录)
- [x] 2026-09-03 定制代码接入部署流程:「部署最新」update_all 一并 -u 定制目录里改过且已安装的模块(内容指纹快照 `env_dir/.odoosh-deployed.json`);重启 / 部署 / 启动后自动 update_list 把新模块登记进「应用」列表;启动 / 唤醒发现旧挂载布局自动重建
- [ ] pip 依赖 hash volume;apt.txt 派生镜像
- [ ] 生产分支保护;企业版可升级标记

## 阶段 5:运维与交付
- [x] Monitor Tab:后台每 10s 采样(env_metrics,7 天),CPU / 内存 / 网络 / 磁盘 IO 曲线 + filestore / 数据库大小(2026-08-16)
- [x] 日志 SSE 实时流(容器 + 编排 + 部署日志);历史 Tab 构建时间线(2026-08-16)
- [x] 安全加固:凭据加密存储、SSRF 防护、原子状态抢占、JWT 改密失效等(见 docs/work-2026-08-16.md)(2026-08-16)
- [x] Shell:xterm ⇄ WebSocket ⇄ docker exec(容器内 odoo 用户);用户级开关(超管在「用户」里开)× 角色矩阵;票据 60s、空闲 30min、每实例 3 会话;`shell_sessions` 审计(生产录输入);容器内 odoo.sh 风格命令 odoo-bin shell / odoo-update / odoo-install / odoosh-restart / odoosh-storage / odoosh-sql-access / odoosh-pip
- [x] 日志过滤/搜索/着色/下载;备份 Tab 导入备份;一键登录 SSO
- [ ] 监控告警、审计日志页面(shell-sessions 接口已就绪)
- [ ] HTTPS(certbot / DNS 验证)、真域名、install.sh 多发行版与镜像站自动探测
- [ ] Alembic 迁移;VPS 真机验证
