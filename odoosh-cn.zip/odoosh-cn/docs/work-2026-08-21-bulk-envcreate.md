# 批量创建实例 设计(2026-08-21)

承接 `docs/work-2026-08-21-bulk.md` §5.1,按三条硬约束收敛并把「安全 / 快速」落到实处。
这是**第一个走异步作业模型的批量**(用户类是秒级同步的快通道;实例编排动辄几分钟,必须排队 + 限流)。

## 0. 三条硬约束(用户已定)

1. **权限**:只有 **超级管理员** 和 **公司管理员(membership.role == owner)** 能看到 / 使用批量按钮与接口。
   开发者 / 测试者即使能单个建实例(非生产),也**没有**批量入口。
2. **配额**:严格执行 `User.max_envs`——批量一次校验总数(`check_env_quota(db, owner, adding=N)`),
   不允许「先建 3 个,第 4 个撞上限」留下半批。
3. **无 Git 仓库**:批量建的实例一律 `repo_url=None / branch=None / base_mode=official`,
   即官方镜像 + 空库(黄金模板秒建)。这一步砍掉了绝大多数复杂度与风险(下条)。

## 1. 「无 Git」带来的简化(=安全面收窄)

单个创建(`create_env`)里那些复杂校验,批量因为无仓库**全部不适用**,直接不做:

- 无 `_find_repo_root` 归入他人项目 → 无「填别人仓库地址把自己写进授权名单」的提权面。
- 无「一分支一环境」「一项目一生产」跨环境约束 → 每个批量实例都是**独立根项目**(`project_id=None`)。
- 无代码检出 / `pip install` / requirements → 无任意仓库拉取与执行,provision 路径最短。
- 冲突判定只剩一条:**同公司同名**(与单建一致)+ **批内重名**。

**edition/kind 收窄(v1)**:

- 只建 **community + official**(enterprise 需平台企业版代码,留 v2)。
- **不建 production**:无仓库的生产=空壳,且生产是需要慎重的单次动作。批量只允许 **dev / staging**
  (默认 dev)。这条同时也是安全默认:批量不可能一键铺出一堆生产实例。

## 2. 权限实现

新增判定(super 或该公司 owner):

```python
def require_env_batch(db, user, tenant_id):
    if authz.is_superadmin(user):
        return
    if authz.tenant_role(db, user, tenant_id) != "owner":
        raise HTTPException(403, "只有超级管理员或公司管理员可批量创建实例")
```

- **owner(公司管理员)** 只能对**自己是 owner 的公司**批量;域名 / 自定义过期仍**仅超管**可设(与单建一致)。
- 前端:`isSuper || 该公司 currentRole==='owner'` 才渲染「批量新建」按钮;否则不显示。

## 3. 拥有者与配额(约束 2 的落点)

批量必须指定**目标拥有者**(默认 = 操作者本人),两种模式:

- **统一拥有者**(主):整批归一个 user(默认自己)。配额一次校验:
  `check_env_quota(db, owner, adding=N)`;owner 是超管则不限。
- **每人一个**(可选,直接对应「考虑每个用户的限制实例」):选 M 个公司成员,
  每人建 1 个(或每人 k 个)实例,**逐个 owner 各自校验 max_envs**,某人配额不足→**其条目预检即失败**,
  不影响其他人。适合「给团队每人开一个沙箱」。

owner 必须是该公司成员(super 除外);owner=创建者时即回到单建的语义。

## 4. 作业模型(通用 BulkJob,首个动作 env.create)

落 `docs/work-2026-08-21-bulk.md` §1 的通用表(以后 start/stop/deploy 复用):

```
BulkJob(id, kind="env.create", scope="environment", tenant_id, payload(JSON 计划),
        status: queued|running|done|cancelling|cancelled,
        total/succeeded/failed/skipped, created_by/created_by_id, idempotency_key, 时间戳)
BulkJobItem(id, job_id, target_type="environment", target_id(建成后回填 env.id),
        label(实例名快照), status: pending|running|success|failed|skipped|cancelled,
        message, started_at, finished_at)
```

**进度不用另造轮子**:每个实例本身就有 `status/progress/status_message`,前端实例列表已有进度条与轮询。
批量作业只记「排队 / 建成 / 失败」聚合与 env_id 指针;实时构建进度看实例卡片自己的进度条。
BulkJobItem 的存在价值 = 分组 + 失败重试 + 「批量里哪些还没建」。

## 5. 执行:两段式 + 先热后扇出(=快速的落点)

**Phase 1 — 同步建记录(请求内,秒级)**
预检通过后,在**一个事务**里:配额按 N 原子校验 → 生成 N 条 `Environment`(status="created",
owner 填好,repo 全空)→ 建 BulkJob + N 个 pending item → commit。请求立刻返回作业 + 实例列表,
用户马上在实例板上看到 N 张「已创建 / 排队中」卡片。**建记录是全或无**(配额 / 命名批前已判定)。

**Phase 2 — 后台限流 provision(partial-success)**
`jobs.spawn(run_env_batch, job_id)` 一个总线程:

- **先热后扇出**:先**串行**跑第 1 个 `orchestrator.provision`(它会 `ensure_tenant_pg` 建好租户 PG、
  拉好基础镜像、灌好黄金模板)——把**共享的重资源(PG 容器 + 基础镜像 + 模板库)预热一次**;
  成功后再用 `ThreadPoolExecutor(max_workers = bulk.provision_concurrency, 默认 2)` 并行余下的。
  这样避免 N 个并发同时构建同一个基础镜像 / 初始化同一个 PG 的风暴,且后续实例几乎都是「模板秒建 + 起容器」。
- **同公司再加信号量**(默认 2):同一租户 PG 上并行建库不超过 2,防单公司拖垮。
- 每项:`try_claim(env,"provisioning")` 抢占(防与手动操作并发)→ `orchestrator.provision(env_id)`
  同步跑到底 → 成功 item=success,异常 item=failed(env 落 `failed`,可用现成「重试创建」)。
- **失败隔离**:单个失败不阻断其余;第 1 个「预热」实例若失败,则**整批暂停并标记**
  (共享资源没就绪,继续只会连环失败),提示用户查看该实例日志后重试。

## 6. 命名(无仓库,名字是唯一标识)

复用批量用户的两种入口,规则用 `EnvironmentCreate._norm_name`(小写、`a-z0-9-`、字母/数字开头):

- **序列**:前缀 + 补零编号,如 `dev01…dev10`。
- **名称清单**:粘贴一列名字。

预检:逐名跑规范化(非法→标错)、**批内去重**、**同公司已存在**(查一次 `Environment.name`)。

## 7. 预检(确认弹窗前必调)

`POST /api/environments/bulk/preflight`,只读、不占位:

```jsonc
{ "tenant_id":3, "kind":"dev", "count":10, "names":["dev01",...],
  "owner_mode":"single", "owner_user_id":8, /* 或 per_user: user_ids[] */
  "base":{ "odoo_version":"18","edition":"community","lang":"zh_CN","mem_mb":null,"cpus":null,
           "sleep_idle_hours":null,"acl":[...] } }
```

返回:每名 `ok/reason`(非法 / 重名 / 已存在)、**配额小结**(`owner 现有 X / 上限 Y / 本批 +N → 是否超`)、
资源估算(`N × mem_mb` 合计,提示是否可能超宿主机)、`warnings`。真正提交时再复检一次,以执行时判定为准。

## 8. API

```
POST /api/environments/bulk/preflight     预检(super / owner)
POST /api/environments/bulk               建 N 记录 + 入队 provision → BulkJob(+ 带 idempotency_key 防双击)
GET  /api/environments/bulk/{id}          作业 + 逐项(item 指向 env_id 与其实时状态)
POST /api/environments/bulk/{id}/retry    仅对 failed 项重新 provision
POST /api/environments/bulk/{id}/cancel   取消尚未开始的项(其 env 保持 "created",可手动建/删)
GET  /api/environments/bulk?mine=1        作业列表(super 看全部;owner 看自己发起的)
```

## 9. 前端

- 入口:`Environments.vue` 顶栏「批量新建」按钮(仅 super / owner 可见),旁边不放配额角标(配额在弹窗里算)。
- `components/environment/EnvBatchDialog.vue`:
  1. 目标公司 + 拥有者(单一 / 每人一个);
  2. 命名(序列 / 清单),实时展开预览名字;
  3. 共享配置(Odoo 版本 / dev·staging / 语言 / 内存·CPU〔非超管受 `limits.*` 上限〕/ 休眠 / 过期〔仅超管〕/ 初始授权名单);
  4. 「保存后立即创建并启动」开关(关=只建记录,像单建那样稍后手动 provision);
  5. 预检小结(配额、冲突、资源)→ 确认 → 提交。
- 提交后关弹窗,用户在实例板看 N 张卡片各自的进度;顶栏出现一个「批量:3/10 完成」的角标(轮询 job)。
- 复用批量用户已有的结果弹窗组件展示失败项 + 「重试失败项」。

## 10. 设置项(并入 §8 的 bulk.* 分组)

| key | 默认 | 说明 |
|---|---|---|
| `bulk.max_create` | 20 | 单批实例数上限(与用户创建共用) |
| `bulk.provision_concurrency` | 2 | 全局并行 provision 数 |
| `bulk.tenant_provision_concurrency` | 2 | 同公司并行建库数 |

## 11. 安全清单(逐条对应「保证安全」)

- 入口权限:仅 super / 公司 owner(§2);developer/tester 无按钮无接口。
- 配额:N 原子校验,per-user 模式逐人校验(§3),不放松、不超发。
- 无生产、无仓库、无代码执行:攻击面最小(§1);域名 / 过期仍仅超管。
- 并发有闸门:全局 + 同公司信号量;先热后扇出防资源风暴(§5)。
- 抢占用现成 `try_claim`,不发明新锁;单项失败隔离 + 可重试。
- 建记录全或无(配额/命名批前定),provision 部分成功——不产生「配额已扣但实例没建」的错账。
- 每次提交写一条结构化平台日志(who / tenant / kind / N / owner_mode)。

## 11.5 已实现(2026-08-21)

按用户拍板落地 v1:**统一拥有者(默认自己,含超管可选)/ 仅 dev·staging / 无 Git / 立即启动 / 仅 community**。

后端:
- `models_bulk.py`(`BulkJob` + `BulkJobItem`,首个使用者);`main.py` 注册 + create_all + 挂 `routers/bulk.py`。
- `schemas_bulk.py`:计划 / 预检 / 作业输出。
- `services/bulk_env.py`:`require_env_batch`(super 或公司 owner)、`preflight`、`submit`
  (Phase 1 同步建 N 记录 + 配额原子校验 + 建 job/items,幂等 key 防双击)、
  `run_env_batch`(Phase 2 **先热后扇出**:串行第 1 个预热 PG/镜像/模板,失败则整批暂停;其余
  `ThreadPoolExecutor(min(provision, tenant_provision))` 并行;`try_claim` 抢占;单项失败隔离)、`retry`/`cancel`。
- 端点:`/api/bulk/env-create/preflight`、`/api/bulk/env-create`、`GET /api/bulk[/{id}]`、`{id}/retry`、`{id}/cancel`。
  作业的看 / 重试 / 取消限发起者或超管。

前端:
- `components/environment/EnvBatchDialog.vue`:公司 / 拥有者(自己 + 本公司成员,走 `/tenants/{id}/members`)/
  类型(dev·staging)/ 命名(序列 · 清单)/ 版本 · 语言 / 资源 / 休眠 / 过期(仅超管)/ 立即启动;
  预检小结(配额 / 冲突 / 资源估算)→ 创建 → 进度阶段(轮询 job,逐项状态 + 取消 + 重试失败项)。
- `Environments.vue`:「批量新建」按钮仅 `isSuper || roleOf(t)==='owner'` 可见。

验证:TestClient + SQLite + provision 打桩,权限 / 生产拒绝 / 重名去重 / 配额拦截 / 幂等 / 先热后扇出 /
失败隔离 / 重试全通过;前端 node:20 构建通过。

设置项(懒读取,无迁移):`bulk.max_create`(20)、`bulk.provision_concurrency`(2)、`bulk.tenant_provision_concurrency`(2);
登录验证码 `auth.captcha=0` 供测试关。

## 11.6 已实现:实例批量操作(start/stop/restart/trash,2026-08-21)

复用同一套 BulkJob 引擎。与「创建」不同:目标是**已存在实例**,按每个实例的**角色矩阵逐项鉴权**(部分成功),
不限超管 / owner——谁能单个启停,就能批量启停;逐项跳过无权 / 状态不符的。

- `services/bulk_env.py` 追加:`OPS` 注册表(action / 忙碌态 / 终态 / 是否 owner / 是否重活)、
  `_precheck_op`(与单项同判定:角色矩阵 + owner〔trash〕+ 忙碌 + 状态前置)、`preflight_ops`、`submit_ops`
  (无权 / 状态不符的项直接落 skipped;全跳过→400)、`run_ops`(线程池;**重活 start/restart 按公司信号量限流**,
  轻活 stop/trash 走 `bulk.op_concurrency` 默认 6;`try_claim` 抢占;执行前复检权限;单项失败隔离)。
  `retry` 按 `job.kind` 派发到 `run_env_batch` 或 `run_ops`。
- 端点:`/api/bulk/env-ops/preflight`、`/api/bulk/env-ops`(登录即可,逐项鉴权)。
- 前端:`components/environment/EnvBulkOpsDialog.vue`(预检确认 → 执行进度 → 取消 / 重试失败项;删除走 danger 提示);
  `Environments.vue` 列表视图加多选列 + 操作条(启动 / 停止 / 重启 / 删除)。看板视图多选留后续。
- trash = 移入回收站(仅拥有者,其余跳过)。

**追加(2026-08-21b)**:
- `env.purge`(彻底删除,仅回收站里的):加入 OPS,`run_ops` 里先 `环境路由._detach_children` 再 `orchestrator.destroy`;
  成功判定 = 记录已删。前端回收站视图多选 → 「彻底删除」;并有「清空回收站(彻底删除 N 个)」一键(传全部回收站 id,非本人拥有的自动跳过)。
- 进度条:创建 / 克隆的进度色由品牌蓝改**绿**(`labels.js` OP_COLOR provisioning/cloning = `var(--ok)`)。
- 刷新:实例板本就有 `usePolling`(忙碌时 2s)自动刷新;批量对话框 `@done` 每次轮询也回调 `load`,进度结束即刷新状态。
- 看板视图批量:`EnvCard` 加选择复选框(hover / 选中显示)+ `selected` 高亮;列表与看板共用一条操作条(按当前视图取选择)。

**追加(2026-08-22,企业版批量)**:原定 v2,应用户要求提前做。
- 放开 community-only 限制,edition 可 community / enterprise;env 记录按 `plan.base.edition` 建。
- 预检时对企业版**联网探测**企业版仓库可用性(`enterprise.resolve_repo(..., probe_remote=True)`,按所选 Odoo 版本查 `<v>.0` 分支):
  返回 `enterprise:{required,available,reason,source}`;不可用则提交 400 拦截、前端禁用「创建」并显示原因。
- 企业版代码来自平台 / 公司接入的企业版仓库(与用户自有 Git 仓库无关),故仍满足「无 Git(repo_url 空)」;
  provision 复用单建的企业版拉取逻辑。前端 `EnvBatchDialog` 加「版本类型」社区 / 企业单选 + 预检可用性提示。
- 验证:无企业仓库→预检 available:false + 提交 400;打桩 resolve_repo 可用→建出 2 个 edition=enterprise 实例;社区版不受影响。
- 验证:TestClient + SQLite + orchestrator 打桩——预检状态跳过 / 生产矩阵 / 无权全跳过→400 /
  启停重启 / 失败隔离 / owner-gated trash / 取消已结束作业 409,全通过;前端构建通过。

## 11.7 权限审计 + 修复(2026-08-22)

逐条过了批量各路径的鉴权(与单项接口对齐):
- 创建:`env-create[/preflight]` 均经 `require_env_batch`(super / 公司 owner);拥有者必须是本公司成员(不跨公司);
  域名 / 过期仅超管;资源上限非超管受平台默认约束;ACL 被授权人须为本公司成员。✓
- 操作:`env-ops` 逐项 `authz.env_role + env_allowed`(trash/purge 另需 `is_env_owner`);提交与执行**各查一次**(队列期间权限变化也拦得住)。✓
- 作业查看 / 重试 / 取消:限发起者或超管。✓
- **修复的漏洞(信息泄露)**:`env-ops` 预检 / 提交此前会对**不可见实例**回显 `env.name`,且用「实例不存在 / 无权」不同措辞区分——
  可被登录用户枚举 id 探测他人公司实例名与存在性。现改为:`env_role is None` 或不存在一律回显裸 id + 统一措辞
  「无权访问该实例或实例不存在」,并不计入 tenant 分组。已加测试验证(跨公司用户拿不到名、无法区分存在性、提交 400)。

## 11.8 更多批量操作(2026-08-22)

`bulk_env.py` 的 OPS 引擎扩到 13 个动作,新增带 payload 与「按项目根去重 / 串行执行」的元数据类:

- **env.sleep / env.wake**(开发实例)— 映射 stop/start 动作矩阵;sleep 走 `sleepsvc.put_to_sleep`,wake 走 `sleepsvc.wake`。
- **env.restore**(回收站多选恢复)— `orchestrator.untrash` + 恢复前配额校验(`check_env_quota`)+ 同名冲突预检。
- **env.backup**(批量备份)— `_do_backup`:`try_lock` → `new_backup_record` → **同步 `run_backup`**,成功判定看备份记录 status。
- **env.edit**(批量改设置)— payload `{fields}`,只改传了的项(mem/cpu/log_level/sleep_idle_hours/expire_days);非超管受 `limits.*` 上限、expire 仅超管;串行。
- **env.transfer**(转让拥有者)— payload `{new_owner_user_id}`,**按项目根去重**,连带分支环境转移 + 新拥有者配额校验 + 原拥有者降「可管理」;串行。
- **acl.grant / acl.revoke**(加/减协作者)— payload `{entries}` / `{user_ids}`,**挂项目根、按根去重**,增量改(不整体替换);串行。
- payload 存 `BulkJob.payload`(JSON),`run_ops` 读取并透传;`serial` 类 `workers=1` 避免配额/名单竞争;`root` 类在 `_resolve_targets` 按 `acl_root_id` 去重。
- **批量删除备份**(实例详情):`routers/backups.py` 加 `POST /backups/bulk-delete`(部分成功,逐条复用单删的权限 / 占用 / 生产限制;不可见统一措辞防枚举)。

前端:
- `EnvBulkOpsDialog` 增加「参数配置」阶段(edit 的 opt-in 字段 / transfer 的新拥有者选择 / acl 的成员多选+级别);transfer/acl 需选同一公司(否则提示)。
- `Environments.vue` 操作条:启停重启 + **「更多」下拉**(休眠/唤醒/备份/改设置/转让/协作者)+ 删除;回收站条加「恢复」;传入选中项的公共 tenant 作为上下文。
- `components/project/TabBackups.vue`:备份列表多选 + 「批量删除」条(running 不可选)。
- 验证:edit / transfer(去重+配额) / acl / sleep / wake / restore / 批量删备份 全测过;原有 ops 无回归;前端构建通过。

## 12. 待拍板

1. **拥有者模式**:v1 先做「统一拥有者(默认自己)」,还是直接把「每人一个」也一起做?
   (「每人一个」最贴你说的『每个用户的限制实例』,但 UI 多一块选人。)
2. **kind 范围**:确认批量只放 dev / staging、不放 production?
3. **立即启动**:默认「建完即 provision」,还是默认只建记录、让用户挑时机批量启动?
   (只建记录最省资源,但多一步操作。)
4. enterprise 版批量放 v2 可以吗?
