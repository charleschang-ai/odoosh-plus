# 多库(附加库)功能 — 2026-08-19

用户决定:三期一起做。模型:**一个分支 = 一个实例(容器);一个实例 = 1 个主库 + N 个附加库;所有库共用实例代码。**

## 规则(已实现)
- 主库 = `Environment.db_name`(不变);附加库 = 新表 `environment_databases`(只存附加库,不存主库;域名不落库,按 `<name>.<实例域名>` 动态拼)。
- 附加库名 `[a-z0-9]{1,20}`,库名 `<主库>_<name>`,不能等于实例名 / 实例域名首段;fuzzy 模式下不能包含实例名的全部字符(见下)。
- 只有社区版可建;企业版禁止;未绑仓库的普通实例受设置 `db.allow_plain_env` 控制(默认 0)。
- 配额:设置 `db.max_extra_per_env`(默认 3,0=关闭)→ `Tenant.max_dbs_per_env` → `Environment.max_dbs`;租户总量 `Tenant.max_dbs_total`。
- **dbfilter 路由必须互斥**(`services/databases.routing()`):
  - exact(实例名不含 -,自动域名):`^acme_%d$|^acme_dev_%d$`
  - fuzzy(实例名含 -):`^acme_(?=[%d_]{N}$)feature_x$|^acme_feature_x_%d$`(字符集 + 长度近似;附加库名验证防误判)
  - none(超管自定义域名,首段与库名对不上):`^acme_dev$`,不支持附加库(feature_state.reason 提示)
  - 另一层保险:db_user 只拥有本实例的库,Odoo list_dbs 只列自己拥有的库。
- odoo.conf:去掉 `db_name`(否则 prefork cron 只跑 db_name 列表),注释 `; odoosh_primary_db = <主库>` 供 Shell 读取,`db_maxconn` 按库数 +4/库。
- nginx:`server_name <域名> *.<域名>`。新实例加库/删库不重启不 reload;**老实例(旧 conf)首次加库时自动重写 conf 并重启一次容器**(`conf_is_legacy`)。
- SSO:容器内 curl 认证必须带 `Host: <该库域名>`(Odoo 用 dbfilter 校验 db 参数);票据带 `db`。
- 备份 / 恢复 / 中性化按库(`EnvDb` 视图透传 Environment 属性,只覆盖 db_name/admin_password/domain/url);恢复附加库不停容器、不改实例状态。
- 部署 `-u` 逐库(默认全部,DeployDialog 可勾选);主库失败 → 整次失败回退;附加库失败 → `Deployment.db_results` 记录,不阻断。
- 删附加库前默认自动备份(`db.backup_before_drop`);删实例连带删附加库(先于 DROP ROLE)。
- 自动备份策略 `include_extra_dbs`(平台 `backup.auto_extra_dbs`)。附加库可单独过期(`db.extra_expire_days`,`databases.start_scheduler`)。
- Shell:ticket 可带 `database_id`,容器内 helper 按 `ODOOSH_DB` 选库(bashrc 按库分文件)。

## 2026-08-19 追加:新建数据库改成 Odoo 原生表单
- 用户反馈原来的对话框看不懂 → 上半部分与 Odoo 自带「创建数据库」一致:数据库名 / 邮箱(登录名)/ 密码 / 手机 / 语言 / 国家 / 演示数据;下半「平台选项」:数据来源(新建空库 / 克隆本实例的库 / 从备份恢复)、中性化、过期。
- 后端 source=empty 改为在一次性容器里直接调 `odoo.service.db.exp_create_database`(与数据库管理器同一段代码;进程内临时 `list_db=True`,因为 /jsonrpc 那条路被 check_db_management_enabled 挡住)。语言 / 国家列表由 `GET /environments/{id}/databases/options` 从运行中的 Odoo 拿(list_lang 免密;list_countries 需 master password 作第一个参数)。
- 新增列 `environment_databases.admin_login`;SSO / 重置密码按该库登录名(`sso._login_of`)。
- 验证:env 25 建 crm(boss@acme.com / zh_CN / cn / 手机)15s 完成,SSO 以 boss@acme.com 登录,lang/国家/手机均生效。模板库路径后端仍在,但 UI 不再提供。

## 2026-08-19 追加:用户级配额
- `User.max_dbs`(None 不限 / 0 不能创建;超管不受限),按 `environment_databases.created_by` 跨实例计数;`authz.db_quota_state / check_db_quota`;建库 API 校验,`GET …/databases` 返回 `user_limit / user_used` 并并入 allowed_now/reason。
- 用户管理:列表「附加库」列 + 编辑框「附加库配额」;`/auth/me` 与用户列表带 `db_count`。验证脚本 deploy/.dbtest3.sh。

## 2026-08-19 追加:创建实例选语言(默认简体中文)
- `Environment.lang`(默认 zh_CN),EnvFormDialog 新增「语言」下拉(静态常用列表);`orchestrator.apply_db_language()`:模板库建库后跑一次 `--load-language`(-i base 路径直接带参数),再 SQL 激活语言、把现有用户 lang 与 ir.default(res.partner.lang)设为该语言。克隆 / 恢复来的库不适用。`reset_to_empty_db` 也套用。附加库对话框默认语言跟实例。
- 验证:langtest 实例(模板路径)zh_CN 激活、菜单翻译已加载、admin 与新用户默认 zh_CN。

## 文件
- 后端新增:`models_db.py`、`schemas_db.py`、`services/databases.py`、`routers/databases.py`
- 后端改动:orchestrator(write_odoo_conf/destroy)、nginx(通配)、shell(+router)、sso(+router)、deploy(多库 -u)、backup(+router:database_id、run_restore 参数、自动备份附加库)、project(reset_to_empty_db 只清主库 filestore;enterprise_upgrade 多库)、metrics(附加库大小)、schemas/models/settings/main/环境&租户&项目路由
- 前端新增:`components/environment/TabDatabases.vue`(项目页 Tab + 实例总览抽屉共用)
- 前端改动:Project.vue(Tab/徽标/头部)、Environments.vue(抽屉)、EnvCard.vue、DeployDialog.vue(勾选库)、TabBackups.vue(按库备份/恢复)、TabHistory.vue(各库结果)、TabShell.vue(选库)、TabSettings.vue(max_dbs)、Settings.vue(附加数据库分组)、Tenants.vue(配额)、BackupPolicy.vue、utils/openEnv.js

## 验证(WSL 平台重建后,API 级)
- env 25 dev(普通实例,开 allow_plain_env):template 建 shop(2s,首次自动重启容器加载新 dbfilter)→ 路由 shop/test1/主库 各自落到对应库(get_session_info 验证)→ 备份 shop → 恢复到 test1(容器不停)→ 删 test1(先自动备份)→ 库/filestore/记录全清。
- env 22 v19-enterprise(含 - 的分支环境,fuzzy 路由):建 qa → 路由正确 → 部署 `-u base` 两库均 success(db_results)。
- 新建实例 mdb:conf 一开始就是新格式,加库 1s 即可访问,不重启;purge 后附加库 / 角色 / 记录全部删除。
- 前端:构建通过;登录页无控制台错误。**UI 交互(数据库 Tab / 抽屉 / 部署勾选 / 备份选库)待用户登录后过一遍。**
- 未 commit(按项目惯例待用户看过 UI 后一起提交)。测试脚本 deploy/.dbtest.sh、.dbtest2.sh(gitignore)。

## 已知取舍
- 首次给**老实例**加库会重启一次实例(几十秒);新实例不需要。
- 超管自定义域名(首段 ≠ 实例名)的实例不支持附加库(regex 无法互斥),界面提示原因。
- 恢复主库仍停容器(原逻辑);恢复附加库不停。
