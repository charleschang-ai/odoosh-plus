// 全局会话状态:当前用户、成员关系、当前组织、实例权限矩阵;以及组织列表 / 平台默认值的缓存加载器
import { computed, reactive, ref } from 'vue'
import api from './api'

export const session = reactive({
  me: null,            // {id, username, is_superadmin, memberships:[{tenant_id, tenant_name, tenant_slug, role}]}
  perms: {},           // {tenant_id: {role, by_kind:{kind:{action:bool}}}}
  currentTenantId: Number(localStorage.getItem('currentTenantId')) || null,
  loaded: false,
})

export const ROLE_LABEL = { owner: '组织管理员', developer: '开发者', tester: '测试者' }

export const isSuper = computed(() => !!session.me?.is_superadmin)
export const memberships = computed(() => session.me?.memberships || [])
export const currentTenant = computed(() => memberships.value.find((m) => m.tenant_id === session.currentTenantId) || memberships.value[0] || null)
export const currentRole = computed(() => (isSuper.value ? 'owner' : currentTenant.value?.role || null))
export const isOwner = computed(() => isSuper.value || currentRole.value === 'owner')
export const isDeveloper = computed(() => isSuper.value || ['owner', 'developer'].includes(currentRole.value))
export const isTester = computed(() => !isSuper.value && currentRole.value === 'tester')

/** 菜单可见性(每用户 boolean 开关:menu_dashboard/menu_repos/menu_ai/menu_backups;超管不受限) */
export const menuVisible = (key) => isSuper.value || session.me?.[`menu_${key}`] !== false

/** 实例详情页 Tab 开关(menu_settings/menu_upgrade;超管恒可见)。与 menuVisible 相反:默认关,字段缺失(旧后端)也视为关 */
export const tabEnabled = (key) => isSuper.value || session.me?.[`menu_${key}`] === true

/** 该用户在某组织的角色 */
export function roleOf(tenantId) {
  if (isSuper.value) return 'owner'
  return memberships.value.find((m) => m.tenant_id === tenantId)?.role || null
}
/** 是否允许对某实例执行某动作(前端隐藏用;后端仍会校验) */
export function can(env, action) {
  if (!env) return false
  // 实例级角色(创建者 / 授权名单)优先:后端在列表 / 详情里给出 my_role,按角色矩阵查表
  if (env.my_role !== undefined && env.my_role !== null) {
    const m = session.perms._matrix?.[env.my_role]
    return !!m?.[env.kind]?.[action]
  }
  if (env.my_role === null) return false
  const p = session.perms[String(env.tenant_id)]
  if (!p) return false
  return !!p.by_kind?.[env.kind]?.[action]
}
/** 当前用户是否是该实例的拥有者(创建者)或超管 */
export function isEnvOwner(env) {
  return !!env && (isSuper.value || (env.owner_user_id != null && env.owner_user_id === session.me?.id))
}
/** 是否允许在某组织创建某类型实例 */
export function canCreate(tenantId, kind) {
  const p = session.perms[String(tenantId)]
  return !!p?.by_kind?.[kind]?.create
}

/** 实例配额(按拥有者计数;超管不限):{ max, used, left, exhausted, text } */
export const envQuota = computed(() => {
  const me = session.me
  const max = me?.max_envs
  if (!me || isSuper.value || max == null) return { max: null, used: me?.env_count || 0, left: Infinity, exhausted: false, text: '' }
  const used = me.env_count || 0
  return { max, used, left: Math.max(0, max - used), exhausted: used >= max, text: max <= 0 ? '未被允许创建实例(配额为 0)' : `实例配额 ${used}/${max}` }
})
/** 静默刷新当前用户(创建 / 删除实例后同步 env_count) */
export async function refreshMe() {
  try { const me = await api.get('/auth/me', { silent: true }); if (session.me) Object.assign(session.me, me) } catch {}
}

export function setCurrentTenant(id) {
  session.currentTenantId = id
  if (id) localStorage.setItem('currentTenantId', String(id))
  else localStorage.removeItem('currentTenantId')
}

export async function loadSession() {
  const me = await api.get('/auth/me')
  session.me = me
  try { session.perms = await api.get('/environments/permissions', { silent: true }) } catch { session.perms = {} }
  if (!me.memberships.find((m) => m.tenant_id === session.currentTenantId)) setCurrentTenant(me.memberships[0]?.tenant_id || null)
  session.loaded = true
  return me
}

export function clearSession() {
  session.me = null; session.perms = {}; session.loaded = false
  tenants.value = []; tenantsLoadedAt = 0; defaults.loaded = false
  localStorage.removeItem('token')
}

// ---------- 缓存:组织列表 ----------
export const tenants = ref([])
let tenantsLoadedAt = 0; let tenantsPromise = null
const TENANTS_TTL = 60 * 1000
/**
 * 组织列表(缓存 60s;force 强制刷新)。多个页面同时调用只发一次请求。
 * @returns {Promise<Array<{id,name,slug,...}>>}
 */
export function loadTenants(force = false) {
  if (!force && tenants.value.length && Date.now() - tenantsLoadedAt < TENANTS_TTL) return Promise.resolve(tenants.value)
  if (tenantsPromise) return tenantsPromise
  tenantsPromise = api.get('/tenants').then((list) => { tenants.value = list || []; tenantsLoadedAt = Date.now(); return tenants.value })
    .catch(() => tenants.value)
    .finally(() => { tenantsPromise = null })
  return tenantsPromise
}
/** 组件里直接用:返回响应式列表并触发一次加载 */
export function useTenants(force = false) { loadTenants(force); return tenants }
export const tenantName = (id) => tenants.value.find((t) => t.id === id)?.name || (id ? `#${id}` : '')

// ---------- 缓存:平台默认值(GET /environments/defaults) ----------
export const defaults = reactive({ loaded: false, base_domain: '', expire_days_default: 3, odoo_versions: ['19', '18', '17', '16', '15', '14', '13', '12'], default_version: '', enterprise_dir: '', sleep_idle_hours: null, git_enabled: true, can_use_enterprise: true, env_memory_mb: null, env_cpus: null })
let defaultsPromise = null
export function loadDefaults(force = false) {
  if (!force && defaults.loaded) return Promise.resolve(defaults)
  if (defaultsPromise) return defaultsPromise
  defaultsPromise = api.get('/environments/defaults', { silent: true }).then((d) => {
    if (d) {
      if (d.base_domain) defaults.base_domain = d.base_domain
      if (d.expire_days_default !== undefined && d.expire_days_default !== null) defaults.expire_days_default = Number(d.expire_days_default)
      if (d.odoo_versions?.length) defaults.odoo_versions = d.odoo_versions.map(String)
      if (d.default_version) defaults.default_version = String(d.default_version)
      if (d.enterprise_dir) defaults.enterprise_dir = d.enterprise_dir
      if (d.sleep_idle_hours !== undefined && d.sleep_idle_hours !== null) defaults.sleep_idle_hours = Number(d.sleep_idle_hours)
      if (d.git_enabled !== undefined) defaults.git_enabled = !!d.git_enabled
      if (d.can_use_enterprise !== undefined) defaults.can_use_enterprise = !!d.can_use_enterprise
      if (d.env_memory_mb) defaults.env_memory_mb = Number(d.env_memory_mb)   // 实例设置页「资源上限」显示的全局默认
      if (d.env_cpus) defaults.env_cpus = Number(d.env_cpus)
    }
    defaults.loaded = true
    return defaults
  }).catch(() => defaults).finally(() => { defaultsPromise = null })
  return defaultsPromise
}
