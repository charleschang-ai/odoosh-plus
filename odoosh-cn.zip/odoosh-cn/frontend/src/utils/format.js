// 通用格式化工具:日期 / 大小 / 相对时间 / 头像缩写 / 正则转义
const pad = (n) => String(n).padStart(2, '0')

/** 2026-08-16 12:30(无效或空 → '—') */
export function fmtDate(d, empty = '—') {
  if (!d) return empty
  const t = new Date(d)
  if (isNaN(t.getTime())) return empty
  return `${t.getFullYear()}-${pad(t.getMonth() + 1)}-${pad(t.getDate())} ${pad(t.getHours())}:${pad(t.getMinutes())}`
}
/** 2026-08-16 12:30:05 */
export function fmtDateTime(d, empty = '—') {
  if (!d) return empty
  const t = new Date(d)
  if (isNaN(t.getTime())) return empty
  return `${fmtDate(t)}:${pad(t.getSeconds())}`
}
/** 浏览器本地化的完整时间(用于 title 提示) */
export const fmtLocal = (d) => (d ? new Date(d).toLocaleString() : '')

/** 字节 → 人类可读;空值 → '-';0 → '0 B' */
export function fmtSize(b, empty = '-') {
  if (b === null || b === undefined || b === '' || isNaN(Number(b))) return empty
  let n = Number(b)
  const u = ['B', 'KB', 'MB', 'GB', 'TB']
  let i = 0
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++ }
  return `${n.toFixed(i >= 2 ? 1 : 0)} ${u[i]}`
}
export const fmtBytes = fmtSize
export const fmtMB = (b) => `${(Number(b || 0) / 1048576).toFixed(0)} MB`

/** 相对时间:刚刚 / 5 分钟前 / 3 小时前 / 2 天前 / 日期 */
export function ago(d) {
  if (!d) return ''
  const s = Math.max(0, (Date.now() - new Date(d).getTime()) / 1000)
  if (s < 60) return '刚刚'
  if (s < 3600) return `${Math.floor(s / 60)} 分钟前`
  if (s < 86400) return `${Math.floor(s / 3600)} 小时前`
  if (s < 86400 * 30) return `${Math.floor(s / 86400)} 天前`
  return fmtDate(d).slice(0, 10)
}
export const relativeTime = ago
/** 是否在最近 N 小时内(默认 24h) */
export const within = (d, hours = 24) => !!d && Date.now() - new Date(d).getTime() < hours * 3600000

/** 已运行时长:3天 4小时 / 2小时 5分 / 12 分钟 */
export function uptime(started) {
  if (!started) return '—'
  const s = Math.max(0, (Date.now() - new Date(started).getTime()) / 1000)
  return duration(s)
}
/** 秒 → 时长文本 */
export function duration(sec) {
  if (sec === null || sec === undefined || isNaN(sec)) return '—'
  const s = Math.max(0, Number(sec))
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60)
  if (d) return `${d}天 ${h}小时`
  if (h) return `${h}小时 ${m}分`
  if (m) return `${m} 分钟`
  return `${Math.round(s)} 秒`
}
/** 部署耗时的紧凑写法:45s / 3m12s */
export function shortDuration(sec) {
  if (sec === null || sec === undefined || isNaN(sec)) return '—'
  const s = Math.round(Number(sec))
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60), r = s % 60
  if (m < 60) return r ? `${m}m${r}s` : `${m}m`
  const h = Math.floor(m / 60)
  return `${h}h${m % 60}m`
}

/** 头像缩写:ASCII 名取前两位大写,中文取首字 */
export function initials(name) {
  const n = (name || '?').toString().trim() || '?'
  return /^[\x00-\x7f]+$/.test(n) ? n.slice(0, 2).toUpperCase() : n.slice(0, 1)
}

/** 正则特殊字符转义 */
export const escapeRegExp = (s) => String(s ?? '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

/** HTML 转义(日志高亮用) */
export const escapeHtml = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]))

/** 去掉 URL 协议前缀 */
export const stripProto = (u) => (u || '').replace(/^https?:\/\//, '')

/** 短 SHA */
export const shortSha = (sha, n = 7) => (sha ? String(sha).slice(0, n) : '—')
