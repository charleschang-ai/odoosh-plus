// 统一的危险操作确认框(删除实例 / 仓库 / 备份 / 用户 / 组织 …)
// 用法:
//   if (!(await confirmDanger({ title: '删除实例', message: '…不可恢复' }))) return
//   if (!(await confirmDanger({ title: '删除生产实例', message: '…', requireText: env.name }))) return  // 需输入名称确认
import { ElMessageBox } from 'element-plus'
import { escapeRegExp } from './format'

/**
 * @param {object} o
 * @param {string} o.title 标题
 * @param {string} o.message 说明文字
 * @param {string} [o.requireText] 需用户原样输入的文本(实例名 / 分支名);给了就弹 prompt
 * @param {string} [o.confirmText='删除'] 确认按钮文字
 * @param {string} [o.cancelText='取消']
 * @param {'warning'|'error'|'info'} [o.type='warning']
 * @param {boolean} [o.danger=true] 确认按钮是否红色
 * @returns {Promise<boolean>} 用户是否确认
 */
export async function confirmDanger({ title, message, requireText, confirmText = '删除', cancelText = '取消', type = 'warning', danger = true, inputLabel } = {}) {
  const common = { confirmButtonText: confirmText, cancelButtonText: cancelText, type, confirmButtonClass: danger ? 'el-button--danger' : '', closeOnClickModal: false }
  try {
    if (requireText) {
      await ElMessageBox.prompt(`${message ? message + '\n' : ''}${inputLabel || `请输入「${requireText}」以确认:`}`, title, {
        ...common,
        inputPattern: new RegExp('^' + escapeRegExp(requireText) + '$'),
        inputErrorMessage: '输入不匹配',
        inputPlaceholder: requireText,
      })
    } else {
      await ElMessageBox.confirm(message || '', title, common)
    }
    return true
  } catch { return false }
}

/** 普通确认(非破坏性),返回 boolean */
export async function confirmAction({ title, message, confirmText = '确定', cancelText = '取消', type = 'info' } = {}) {
  try { await ElMessageBox.confirm(message || '', title, { confirmButtonText: confirmText, cancelButtonText: cancelText, type }); return true } catch { return false }
}
