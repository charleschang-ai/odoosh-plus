// 极简 Markdown 渲染(无第三方依赖):先转义 HTML,再套用有限的格式,防 XSS。
// 支持:```代码块```、`行内代码`、**粗体**、*斜体*、# 标题、- / 1. 列表、> 引用、--- 分隔、段落与换行。
function esc(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

export function renderMarkdown(src) {
  if (!src) return ''
  const text = String(src).replace(/\r\n/g, '\n')
  const out = []
  const parts = text.split(/```/)
  // 奇数段是代码块(``` 之间)
  parts.forEach((seg, i) => {
    if (i % 2 === 1) {
      const nl = seg.indexOf('\n')
      const lang = nl > 0 && !seg.slice(0, nl).includes(' ') ? seg.slice(0, nl) : ''
      const code = lang ? seg.slice(nl + 1) : seg
      out.push(`<pre class="md-code"><code>${esc(code.replace(/\n$/, ''))}</code></pre>`)
    } else {
      out.push(renderInlineBlock(seg))
    }
  })
  return out.join('')
}

function inline(s) {
  return esc(s)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')
}

function renderInlineBlock(block) {
  const lines = block.split('\n')
  const html = []
  let list = null // 'ul' | 'ol'
  const closeList = () => { if (list) { html.push(`</${list}>`); list = null } }
  for (let raw of lines) {
    const line = raw.replace(/\s+$/, '')
    if (!line.trim()) { closeList(); continue }
    if (/^---+$/.test(line.trim())) { closeList(); html.push('<hr>'); continue }
    let m
    if ((m = line.match(/^(#{1,4})\s+(.*)$/))) { closeList(); const lv = m[1].length + 2; html.push(`<h${lv} class="md-h">${inline(m[2])}</h${lv}>`); continue }
    if ((m = line.match(/^\s*[-*]\s+(.*)$/))) { if (list !== 'ul') { closeList(); html.push('<ul class="md-ul">'); list = 'ul' } html.push(`<li>${inline(m[1])}</li>`); continue }
    if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) { if (list !== 'ol') { closeList(); html.push('<ol class="md-ol">'); list = 'ol' } html.push(`<li>${inline(m[1])}</li>`); continue }
    if ((m = line.match(/^\s*>\s?(.*)$/))) { closeList(); html.push(`<blockquote class="md-q">${inline(m[1])}</blockquote>`); continue }
    closeList()
    html.push(`<p class="md-p">${inline(line)}</p>`)
  }
  closeList()
  return html.join('')
}
