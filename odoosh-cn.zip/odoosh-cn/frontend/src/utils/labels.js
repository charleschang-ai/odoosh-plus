// 全站统一的枚举 → 中文标签 / 颜色映射(实例类型、状态、部署、备份等)
// 任何页面都从这里取,不要再各自复制一份

// ---------- 实例类型 ----------
export const KINDS = ['production', 'staging', 'dev']
const KIND_LABEL = { production: '生产', staging: '测试', dev: '开发' }
const KIND_TYPE = { production: 'danger', staging: 'warning', dev: 'primary' }
export const kindLabel = (k) => KIND_LABEL[k] || k || ''
export const kindType = (k) => KIND_TYPE[k] || 'info'
export const KIND_ORDER = { production: 0, staging: 1, dev: 2 }

// ---------- 实例状态 ----------
/** 过渡态(有进度条 / 禁用操作 / 快轮询) */
export const BUSY = ['provisioning', 'destroying', 'starting', 'stopping', 'restarting', 'deploying', 'cloning', 'waking', 'restoring']
export const isBusy = (row) => !!row && BUSY.includes(row.status)

const STATUS_LABEL = {
  created: '未创建', provisioning: '创建中', running: '运行中', stopped: '已停止', failed: '失败', destroying: '删除中',
  starting: '启动中', stopping: '停止中', restarting: '重启中', deploying: '部署中', cloning: '克隆数据', restoring: '恢复备份', sleeping: '休眠中', waking: '唤醒中', deleted: '已删除',
}
export const statusLabel = (s) => STATUS_LABEL[s] || s || ''
/** el-tag 的 type */
export function statusType(s) {
  if (s === 'running') return 'success'
  if (s === 'failed') return 'danger'
  if (BUSY.includes(s)) return 'warning'
  return 'info' // stopped / created / sleeping
}
/** 卡片状态胶囊 / 状态点的语义类:running | busy | failed | sleeping | stopped */
export function statusTone(s) {
  if (s === 'running') return 'running'
  if (s === 'failed') return 'failed'
  if (s === 'provisioning' || s === 'cloning') return 'creating'  // 创建 / 克隆:绿色进行中(区别于停止 / 删除等橙色过渡态)
  if (BUSY.includes(s)) return 'busy'
  if (s === 'sleeping') return 'sleeping'
  if (s === 'deleted') return 'deleted'
  return 'stopped'
}
/** 过渡态动作名(用于「XX中:...」进度文案) */
const OP_LABEL = { provisioning: '创建中', destroying: '删除中', starting: '启动中', stopping: '停止中', restarting: '重启中', deploying: '部署中', cloning: '克隆数据中', waking: '唤醒中', restoring: '恢复备份中' }
export const opLabel = (s) => OP_LABEL[s] || '处理中'
/** 过渡态完成后的动作名(通知用:「创建成功」「部署失败」) */
const OP_DONE = { provisioning: '创建', starting: '启动', stopping: '停止', restarting: '重启', deploying: '部署', cloning: '数据克隆', waking: '唤醒', destroying: '删除', restoring: '备份恢复' }
export const opDoneLabel = (s) => OP_DONE[s] || '操作'
/** 进度条颜色(CSS 变量,见 style.css) */
const OP_COLOR = { provisioning: 'var(--ok)', destroying: 'var(--danger)', starting: 'var(--ok)', stopping: 'var(--warn)', restarting: 'var(--info)', deploying: 'var(--violet)', cloning: 'var(--ok)', waking: 'var(--ok)', restoring: 'var(--warn)' }
export const opColor = (s) => OP_COLOR[s] || 'var(--brand)'
export const STATUS_ORDER = { running: 0, provisioning: 1, starting: 1, restarting: 1, deploying: 1, cloning: 1, waking: 1, restoring: 1, stopping: 2, sleeping: 3, stopped: 3, created: 4, failed: 5, destroying: 6, deleted: 7 }

// ---------- 版本 / 镜像 ----------
export const editionLabel = (e) => (e === 'enterprise' ? '企业版' : '社区版')

// ---------- 部署 ----------
const DEP_LABEL = { success: '部署成功', failed: '部署失败', running: '部署中', queued: '排队中' }
const DEP_SHORT = { success: '成功', failed: '失败', running: '进行中', queued: '排队' }
const DEP_TYPE = { success: 'success', failed: 'danger', running: 'warning', queued: 'info' }
export const depLabel = (s) => DEP_LABEL[s] || s || ''
export const depShortLabel = (s) => DEP_SHORT[s] || s || ''
export const depType = (s) => DEP_TYPE[s] || 'info'
const TRIGGER_LABEL = { create: '创建', manual: '手动', push: '推送', rollback: '回退', upgrade: '升级' }
export const triggerLabel = (t) => TRIGGER_LABEL[t] || t || ''
export const DEPLOY_ACTIONS = [{ value: 'restart', label: '仅重启' }, { value: 'update', label: '升级指定模块' }, { value: 'update_all', label: '升级全部模块' }]
export const actionLabel = (a, modules) => ({ restart: '仅重启', update: `升级模块 ${modules || ''}`.trim(), update_all: '升级全部模块' })[a] || a || ''
export const actionShort = (a, modules) => ({ restart: '重启', update: `-u ${modules || ''}`.trim(), update_all: '-u all' })[a] || a || ''

// ---------- 备份 ----------
const BK_KIND_LABEL = { manual: '手动', auto: '自动', pre_restore: '恢复前', upload: '上传' }
const BK_KIND_TYPE = { manual: 'primary', auto: 'success', pre_restore: 'warning', upload: 'info' }
const BK_STATUS_LABEL = { running: '进行中', done: '完成', failed: '失败' }
const BK_STATUS_TYPE = { running: 'primary', done: 'success', failed: 'danger' }
export const backupKindLabel = (k) => BK_KIND_LABEL[k] || k || ''
export const backupKindType = (k) => BK_KIND_TYPE[k] || 'info'
export const backupStatusLabel = (s) => BK_STATUS_LABEL[s] || s || ''
export const backupStatusType = (s) => BK_STATUS_TYPE[s] || 'info'

// ---------- Git ----------
const PROVIDER_LABEL = { github: 'GitHub', gitee: 'Gitee', gitlab: 'GitLab', generic: '通用' }
const PROVIDER_TYPE = { github: 'primary', gitee: 'danger', gitlab: 'warning', generic: 'info' }
export const providerLabel = (p) => PROVIDER_LABEL[p] || p || ''
export const providerType = (p) => PROVIDER_TYPE[p] || 'info'

// ---------- 过期 ----------
/** 过期文案(完整):永不过期 / 3 天 2 小时后过期 / 已到期,待清理 */
export function expireText(e) {
  if (!e?.expires_at) return '永不过期'
  const ms = new Date(e.expires_at).getTime() - Date.now()
  if (ms <= 0) return '已到期,待清理'
  const d = Math.floor(ms / 86400000), h = Math.floor((ms % 86400000) / 3600000)
  return (d >= 1 ? `${d} 天 ${h} 小时` : h >= 1 ? `${h} 小时` : `${Math.max(1, Math.floor(ms / 60000))} 分钟`) + '后过期'
}
/** 过期文案(短,卡片「过期」字段用):永不 / 3 天 2 小时后 */
export function expireShort(e) {
  if (!e?.expires_at) return '永不'
  const ms = new Date(e.expires_at).getTime() - Date.now()
  if (ms <= 0) return '已到期,待清理'
  const d = Math.floor(ms / 86400000), h = Math.floor((ms % 86400000) / 3600000)
  return d >= 1 ? `${d} 天 ${h} 小时后` : h >= 1 ? `${h} 小时后` : `${Math.max(1, Math.floor(ms / 60000))} 分钟后`
}
export const expireSoon = (e) => !!e?.expires_at && new Date(e.expires_at).getTime() - Date.now() < 86400000
export const EXPIRE_CHOICES = [
  { label: '保持不变', value: 'keep' }, { label: '1 天后', value: '1' }, { label: '3 天后', value: '3' },
  { label: '7 天后', value: '7' }, { label: '30 天后', value: '30' }, { label: '永不过期', value: '0' },
]

/** 资源占用条颜色 */
export const barColor = (p) => { p = p || 0; return p < 60 ? 'var(--ok)' : p < 85 ? 'var(--warn)' : 'var(--danger)' }
