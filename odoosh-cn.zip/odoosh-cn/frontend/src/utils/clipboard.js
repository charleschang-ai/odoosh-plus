// 复制到剪贴板(带提示;http 环境下 navigator.clipboard 不可用时回退 execCommand)
import { ElMessage } from 'element-plus'

export async function copyText(text, okMsg = '已复制') {
  const s = String(text ?? '')
  try {
    if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(s)
    else {
      const ta = document.createElement('textarea'); ta.value = s; ta.style.position = 'fixed'; ta.style.opacity = '0'
      document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove()
    }
    if (okMsg) ElMessage.success(okMsg)
    return true
  } catch { ElMessage.warning('复制失败,请手动选择'); return false }
}
