// 「打开」实例 = 一键免密登录进入 Odoo。
// 休眠 / 唤醒中的实例:先在点击事件里开一个空白窗口(避免被拦截),触发唤醒并让该窗口先显示实例的
// 「唤醒中」落地页,后台轮询状态,就绪后再把窗口跳到一次性 SSO 地址。
import { ElMessage } from 'element-plus'
import api from '../api'

const OPENABLE = ['running', 'sleeping', 'waking', 'starting']

export const canOpenNow = (env) => !!env && OPENABLE.includes(env.status)

// databaseId:打开该实例的附加库(null = 主库);url:该库的地址(唤醒中先落到它的域名)
export async function openEnv(env, { onStatus, databaseId = null, url = null } = {}) {
  if (!env) return
  const w = window.open('', '_blank')
  const go = (u) => { if (w && !w.closed) w.location = u; else window.open(u, '_blank') }
  const landing = url || env.url
  const params = databaseId ? { database_id: databaseId } : {}
  try {
    if (env.status === 'running') {
      const r = await api.post(`/environments/${env.id}/sso-url`, null, { params })
      go(r.url); return
    }
    // 休眠 / 唤醒中 / 启动中:触发唤醒(已在唤醒中会返回 409,忽略),窗口先显示落地页
    if (env.status === 'sleeping') {
      try { await api.post(`/environments/${env.id}/wake`, {}, { silent: true }) } catch {}
    }
    ElMessage.info({ message: '实例正在唤醒,就绪后会自动进入(约 10~30 秒)', duration: 4000 })
    if (landing) go(landing)
    const deadline = Date.now() + 120000
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 2000))
      let cur
      try { cur = await api.get(`/environments/${env.id}`, { silent: true }) } catch { continue }
      onStatus?.(cur)
      if (cur.status === 'running') {
        try { const r = await api.post(`/environments/${env.id}/sso-url`, null, { params }); go(r.url) } catch { if (landing) go(landing) }
        return
      }
      if (cur.status === 'failed' || w?.closed) { if (cur.status === 'failed') ElMessage.error(cur.status_message || '唤醒失败'); return }
    }
    ElMessage.warning('等待实例就绪超时,请稍后重试')
  } catch {
    if (landing) go(landing)
  }
}
