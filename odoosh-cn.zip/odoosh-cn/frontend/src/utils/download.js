// 触发浏览器下载(Blob / 文本)
export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename || 'download'
  document.body.appendChild(a); a.click(); a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 10000)
}
export function downloadText(text, filename, type = 'text/plain;charset=utf-8') {
  downloadBlob(new Blob([text], { type }), filename)
}

/** 备份直链下载:先向后端要一张 5 分钟票据,再用 <a href> 让浏览器自己流式下载(带原生进度、可断点续传;
 *  以前 axios responseType=blob 会把几 GB 整个读进标签页内存)。api 为 api.js 默认导出。 */
export async function downloadBackup(api, backupId) {
  const t = await api.post(`/backups/${backupId}/download-ticket`)
  const base = (api.defaults?.baseURL || '/api').replace(/\/$/, '')
  const a = document.createElement('a')
  a.href = `${base}/backups/${backupId}/download?t=${encodeURIComponent(t.ticket)}`
  a.download = t.filename || `backup-${backupId}.zip`
  document.body.appendChild(a); a.click(); a.remove()
}
