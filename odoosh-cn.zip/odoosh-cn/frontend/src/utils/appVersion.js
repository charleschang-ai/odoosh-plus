// 前端是否已重新构建:比较当前页面加载的入口脚本(/assets/index-xxxx.js)与服务器上最新 index.html 引用的是否一致。
// 平台自更新 / 重建 web 镜像后,旧标签页里跑的仍是旧 JS,只靠组件重挂载不会拿到新代码,需要整页 reload。
let current = null
function currentEntry() {
  if (current) return current
  const el = document.querySelector('script[type="module"][src*="/assets/"]')
  current = el ? el.getAttribute('src').replace(/^.*\/assets\//, '') : null
  return current
}
/** 返回 true 表示服务器上的前端已更新(入口脚本 hash 与当前不同);拿不到时返回 false */
export async function appUpdated() {
  const cur = currentEntry()
  if (!cur) return false
  try {
    const html = await fetch(`/index.html?_=${Date.now()}`, { cache: 'no-store' }).then((r) => (r.ok ? r.text() : ''))
    const m = html.match(/\/assets\/(index-[^"']+\.js)/)
    return !!m && m[1] !== cur
  } catch { return false }
}
