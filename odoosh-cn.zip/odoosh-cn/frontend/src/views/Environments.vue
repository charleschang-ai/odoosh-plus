<template>
  <div class="page envs">
    <!-- 顶部一行:范围切换 + 状态概览 ……… 筛选 / 视图 / 分组 / 新建(页面标题在顶栏,这里不再重复) -->
    <div class="topbar">
      <div class="scope-tabs">
        <button class="scope" :class="{ on: !showTrash }" @click="setTrash(false)"><el-icon><Box /></el-icon>实例列表</button>
        <button class="scope trash" :class="{ on: showTrash }" @click="setTrash(true)"><el-icon><Delete /></el-icon>回收站<span v-if="trashCount" class="cnt">{{ trashCount }}</span></button>
      </div>
      <div v-if="!showTrash" class="summary">
        <span class="chip run"><i class="dot" />运行中 {{ count('running') }}</span>
        <span class="chip stop"><i class="dot" />已停止 {{ count('stopped') }}</span>
        <span class="chip sleep" v-if="count('sleeping')"><i class="dot" />休眠 {{ count('sleeping') }}</span>
        <span class="chip busy" v-if="busyCount"><i class="dot" />处理中 {{ busyCount }}</span>
        <span class="chip fail" v-if="count('failed')"><i class="dot" />失败 {{ count('failed') }}</span>
      </div>
      <div class="tools">
        <el-select v-if="tenants.length > 1" v-model="filterTenant" placeholder="全部组织" clearable style="width: 150px" @change="load()">
          <el-option v-for="t in tenants" :key="t.id" :label="t.name" :value="t.id" />
        </el-select>
        <el-input v-model="keyword" placeholder="搜索实例 / 域名 / 分支" clearable style="width: 180px" :prefix-icon="Search" />
        <el-segmented v-model="view" :options="viewOptions" @change="saveView">
          <template #default="{ item }">
            <el-icon><component :is="item.icon" /></el-icon>
          </template>
        </el-segmented>
        <!-- 看板分组(类似 odoo 的 Group By) -->
        <el-dropdown v-if="view === 'card'" trigger="click" @command="setGroupBy">
          <el-button :type="groupBy ? 'primary' : 'default'" :plain="!!groupBy" class="group-btn">
            <el-icon><Operation /></el-icon><span>{{ groupBy ? `按${GROUP_OPTIONS.find((o) => o.value === groupBy)?.label}` : '分组' }}</span><el-icon class="el-icon--right"><ArrowDown /></el-icon>
          </el-button>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item v-for="o in GROUP_OPTIONS" :key="o.value" :command="o.value" :class="{ 'is-current': groupBy === o.value }">
                <el-icon><component :is="o.icon" /></el-icon>{{ o.label }}<el-icon v-if="groupBy === o.value" class="chk"><Check /></el-icon>
              </el-dropdown-item>
              <el-dropdown-item command="" divided :disabled="!groupBy">取消分组</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
        <el-button :icon="Refresh" circle title="刷新" @click="load()" />
        <el-button v-if="batchTenants.length && !showTrash" type="success" plain :icon="Files" @click="openBatch">批量新建</el-button>
        <el-tooltip v-if="creatableTenants.length && !showTrash" :disabled="!envQuota.text" :content="envQuota.exhausted ? `${envQuota.text},已达上限;彻底删除不用的实例或联系超级管理员调整` : envQuota.text" placement="bottom">
          <el-button type="primary" :icon="Plus" :disabled="envQuota.exhausted" @click="openCreate">新建实例<span v-if="envQuota.max != null && envQuota.max > 0" class="quota-n">{{ envQuota.used }}/{{ envQuota.max }}</span></el-button>
        </el-tooltip>
      </div>
    </div>
    <el-alert v-if="showTrash" type="warning" :closable="false" show-icon class="trash-tip" title="回收站里的实例已停止并摘除域名,数据库与文件仍保留;可「恢复」或「彻底删除」。到期(系统设置 → 回收站保留天数)会自动彻底清理。" />

    <!-- 回收站工具条:清空回收站 -->
    <div v-if="showTrash && filtered.length" class="trash-tools">
      <el-button size="small" type="danger" plain :icon="Delete" @click="emptyTrash">清空回收站(彻底删除 {{ filtered.length }} 个)</el-button>
      <span class="mut">彻底删除不可恢复;非本人拥有的实例会自动跳过</span>
    </div>

    <!-- 批量操作条(两种视图共用) -->
    <transition name="obar">
      <div v-if="selCount" class="ops-bar">
        <span class="cnt">已选 <b>{{ selCount }}</b> 个实例</span>
        <span class="sep" />
        <template v-if="!showTrash">
          <el-button size="small" type="success" plain :icon="VideoPlay" @click="openOps('env.start')">启动</el-button>
          <el-button size="small" type="warning" plain :icon="VideoPause" @click="openOps('env.stop')">停止</el-button>
          <el-button size="small" type="primary" plain :icon="RefreshRight" @click="openOps('env.restart')">重启</el-button>
          <el-dropdown size="small" trigger="click" @command="openOps">
            <el-button size="small" plain>更多<el-icon class="el-icon--right"><ArrowDown /></el-icon></el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="env.sleep"><el-icon><MoonNight /></el-icon>休眠</el-dropdown-item>
                <el-dropdown-item command="env.wake"><el-icon><Sunny /></el-icon>唤醒</el-dropdown-item>
                <el-dropdown-item command="env.backup" divided><el-icon><Download /></el-icon>备份</el-dropdown-item>
                <el-dropdown-item command="env.edit"><el-icon><Setting /></el-icon>修改设置</el-dropdown-item>
                <el-dropdown-item command="env.transfer"><el-icon><User /></el-icon>转让拥有者</el-dropdown-item>
                <el-dropdown-item command="acl.grant"><el-icon><UserFilled /></el-icon>添加协作者</el-dropdown-item>
                <el-dropdown-item command="acl.revoke"><el-icon><Remove /></el-icon>移除协作者</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
          <el-button size="small" type="danger" plain :icon="Delete" @click="openOps('env.trash')">删除</el-button>
        </template>
        <template v-else>
          <el-button size="small" type="success" plain :icon="RefreshRight" @click="openOps('env.restore')">恢复</el-button>
          <el-button size="small" type="danger" plain :icon="Delete" @click="openOps('env.purge')">彻底删除</el-button>
        </template>
        <span class="grow" />
        <el-button size="small" text @click="clearOpsSel">取消选择</el-button>
      </div>
    </transition>

    <!-- 看板视图 -->
    <div v-if="view === 'card'" class="board" :class="{ grouped: !!groupBy }" v-loading="loading">
      <section v-for="g in grouped" :key="g.key" class="group-sec" :class="{ collapsed: collapsedGroups[g.key] }">
        <div v-if="groupBy" class="group-head" @click="toggleGroup(g.key)">
          <el-icon class="arrow"><ArrowRight /></el-icon>
          <span class="g-icon" v-if="g.icon" :class="g.iconClass"><span class="ver">{{ g.icon }}</span></span>
          <span class="g-title">{{ g.label }}</span>
          <span class="g-count">{{ g.rows.length }}</span>
          <span class="g-stats">
            <span v-if="g.running" class="s run"><i />{{ g.running }} 运行中</span>
            <span v-if="g.rows.length - g.running" class="s stop"><i />{{ g.rows.length - g.running }} 其他</span>
          </span>
        </div>
        <div class="grid" v-show="!collapsedGroups[g.key]">
          <EnvCard v-for="row in g.rows" :key="row.id" :row="row" :stats="st(row)" :tenant-label="tenantName(row.tenant_id)" :has-project="projectOf(row)" :children="childrenOf(row)"
            :selected="boardSel.includes(row.id)" @select="(v) => toggleBoardSel(row.id, v)"
            @open="open" @act="act" @logs="openLogs" @deploy="openDeploy" @project="openProject" @more="onMore" />
          <!-- 新建卡片(未分组时放在最后一格) -->
          <div v-if="creatableTenants.length && !groupBy && !showTrash" class="card new" :class="{ off: envQuota.exhausted }" @click="!envQuota.exhausted && openCreate()">
            <el-icon :size="34"><Plus /></el-icon>
            <div>新建实例</div>
            <div class="muted" style="font-size: 12px">{{ envQuota.exhausted ? `${envQuota.text},已达上限` : '选择组织 / Odoo 版本,一键创建' }}</div>
          </div>
        </div>
      </section>
      <EmptyState v-if="!loading && !filtered.length" :variant="keyword ? 'search' : 'envs'" :title="keyword ? '没有匹配的实例' : showTrash ? '回收站是空的' : !tenants.length ? '先创建组织' : '还没有实例'"
        :desc="keyword ? '换个关键词,或清空搜索与组织筛选' : !tenants.length && !showTrash ? (isSuper ? '实例挂在组织之下:先在「组织与成员」里创建一个组织,回来就能新建实例' : '你还不属于任何组织,请联系平台管理员把你加入组织后再创建实例') : '选择组织与 Odoo 版本,一键创建生产 / 测试 / 开发实例'">
        <el-button v-if="creatableTenants.length && !keyword && !showTrash" type="primary" :icon="Plus" :disabled="envQuota.exhausted" @click="openCreate">{{ envQuota.exhausted ? envQuota.text : '新建实例' }}</el-button>
        <el-button v-else-if="!tenants.length && !keyword && !showTrash && isSuper" type="primary" :icon="Plus" @click="router.push('/tenants')">去创建组织</el-button>
      </EmptyState>
    </div>

    <!-- 列表视图 -->
    <el-card v-else shadow="never" class="list-card">
      <el-table ref="opsTable" :data="filtered" v-loading="loading" stripe class="actions-table" :row-key="(r) => r.id" @selection-change="onOpsSel">
        <el-table-column type="selection" width="42" reserve-selection />
        <el-table-column label="实例" min-width="200">
          <template #default="{ row }">
            <div class="row-name">
              <div class="app-icon sm" :class="`v${row.odoo_version}`"><span class="ver">{{ row.odoo_version }}</span></div>
              <div><div class="name">{{ row.name }}</div><div class="sub">{{ tenantName(row.tenant_id) }}</div></div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="类型" width="90"><template #default="{ row }"><el-tag size="small" :type="kindType(row.kind)">{{ kindLabel(row.kind) }}</el-tag></template></el-table-column>
        <el-table-column label="状态" width="120">
          <template #default="{ row }"><div class="status-pill inline" :class="statusTone(row.status)"><i class="pulse" />{{ statusLabel(row.status) }}</div></template>
        </el-table-column>
        <el-table-column label="CPU / 内存" width="200">
          <template #default="{ row }">
            <template v-if="row.status === 'running' && can(row, 'stats') && st(row).cpu_percent !== undefined">
              <div class="mini"><span>CPU {{ st(row).cpu_percent }}%</span><div class="bar"><i :style="{ width: st(row).cpu_percent + '%', background: barColor(st(row).cpu_percent) }" /></div></div>
              <div class="mini"><span>{{ fmtSize(st(row).mem_usage) }} / {{ fmtSize(st(row).mem_limit) }}</span><div class="bar"><i :style="{ width: st(row).mem_percent + '%', background: barColor(st(row).mem_percent) }" /></div></div>
            </template>
            <span v-else class="muted">—</span>
          </template>
        </el-table-column>
        <el-table-column label="访问地址 / 进度" min-width="240">
          <template #default="{ row }">
            <div v-if="isBusy(row)" class="mini-progress">
              <span class="muted">{{ opLabel(row.status) }}:{{ row.status_message }}</span>
              <el-progress :percentage="row.progress || 0" :stroke-width="6" :striped="true" :striped-flow="true" :color="opColor(row.status)" />
            </div>
            <a v-else-if="row.url && row.status === 'running'" :href="row.url" target="_blank" rel="noopener">{{ row.url }}</a>
            <span v-else class="muted">{{ row.status_message || row.url || '—' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="创建时间" width="150"><template #default="{ row }"><span :title="fmtLocal(row.created_at)">{{ fmtDate(row.created_at) }}</span></template></el-table-column>
        <el-table-column label="过期" width="120"><template #default="{ row }"><span :class="expireSoon(row) ? 'exp-soon' : row.expires_at ? '' : 'muted'">{{ expireShort(row) }}</span></template></el-table-column>
        <el-table-column prop="branch" label="分支" width="120" show-overflow-tooltip />
        <el-table-column label="操作" :width="isMobile ? 64 : 290" fixed="right" align="right">
          <template #default="{ row }">
            <!-- 桌面:平铺按钮 -->
            <div v-if="!isMobile" class="row-actions">
              <el-button v-if="row.url && canOpenNow(row) && can(row, 'open')" link @click="open(row)">{{ row.status === 'running' ? '打开' : '唤醒并打开' }}</el-button>
              <el-button v-if="can(row, 'create') && (!row.container_name || row.status === 'failed')" link type="primary" :disabled="isBusy(row)" @click="act(row, 'provision')">{{ row.container_name ? '重试' : '创建并启动' }}</el-button>
              <el-button v-if="row.container_name && ((row.status === 'stopped' && can(row, 'start')) || (row.status === 'sleeping' && can(row, 'open')))" link type="success" @click="act(row, 'start')">{{ row.status === 'sleeping' ? '唤醒' : '启动' }}</el-button>
              <el-button v-if="can(row, 'stop') && row.status === 'running'" link type="warning" @click="act(row, 'stop')">停止</el-button>
              <el-button v-if="can(row, 'restart') && row.status === 'running'" link @click="act(row, 'restart')">重启</el-button>
              <el-button v-if="can(row, 'logs')" link @click="openLogs(row)">日志</el-button>
              <el-button v-if="row.repo_url && row.branch && row.container_name && can(row, 'deploy')" link type="primary" :disabled="isBusy(row)" @click="openDeploy(row)">部署</el-button>
              <el-button v-if="projectOf(row)" link type="primary" @click="openProject(row)">详情</el-button>
              <el-button v-if="can(row, 'edit')" link type="primary" :disabled="isBusy(row)" @click="openEdit(row)">编辑</el-button>
              <el-button v-if="row.status === 'deleted' && can(row, 'delete') && isEnvOwner(row)" link type="primary" @click="act(row, 'untrash')">恢复</el-button>
              <el-button v-if="can(row, 'delete') && isEnvOwner(row)" link type="danger" :disabled="isBusy(row)" @click="onMore('delete', row)">{{ row.status === 'deleted' ? '彻底删除' : '删除' }}</el-button>
            </div>
            <!-- 手机:折叠成菜单 -->
            <el-dropdown v-else trigger="click" @command="(c) => onRowMenu(c, row)">
              <el-button circle size="small"><el-icon><MoreFilled /></el-icon></el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item v-if="row.url && canOpenNow(row) && can(row, 'open')" command="open">{{ row.status === 'running' ? '打开' : '唤醒并打开' }}</el-dropdown-item>
                  <el-dropdown-item v-if="can(row, 'create') && (!row.container_name || row.status === 'failed')" command="provision" :disabled="isBusy(row)">{{ row.container_name ? '重试创建' : '创建并启动' }}</el-dropdown-item>
                  <el-dropdown-item v-if="row.container_name && ((row.status === 'stopped' && can(row, 'start')) || (row.status === 'sleeping' && can(row, 'open')))" command="start">{{ row.status === 'sleeping' ? '唤醒' : '启动' }}</el-dropdown-item>
                  <el-dropdown-item v-if="can(row, 'stop') && row.status === 'running'" command="stop">停止</el-dropdown-item>
                  <el-dropdown-item v-if="can(row, 'restart') && row.status === 'running'" command="restart">重启</el-dropdown-item>
                  <el-dropdown-item v-if="can(row, 'logs')" command="logs">日志</el-dropdown-item>
                  <el-dropdown-item v-if="row.repo_url && row.branch && row.container_name && can(row, 'deploy')" command="deploy" :disabled="isBusy(row)">部署</el-dropdown-item>
                  <el-dropdown-item v-if="projectOf(row)" command="project">详情</el-dropdown-item>
                  <el-dropdown-item v-if="can(row, 'edit')" command="edit" :disabled="isBusy(row)">编辑</el-dropdown-item>
                  <el-dropdown-item v-if="can(row, 'delete')" command="delete" :disabled="isBusy(row)" divided><span style="color: var(--danger)">删除</span></el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <DeleteEnvDialog ref="delDlg" :keep-days-default="trashDays.normal" :keep-days-prod="trashDays.prod" @done="load()" />
    <el-dialog v-model="aclDlg" :title="`访问权限 — ${aclEnv?.name || ''}`" width="560px" destroy-on-close>
      <AclEditor v-if="aclEnv" :env-id="aclEnv.id" :tenant-id="aclEnv.tenant_id" @changed="load(true)" />
      <template #footer><el-button @click="aclDlg = false">关闭</el-button></template>
    </el-dialog>
    <EnvFormDialog ref="formDlg" @saved="load()" />
    <EnvBatchDialog ref="batchDlg" @saved="load()" />
    <EnvBulkOpsDialog ref="opsDlg" @done="afterOps" />
    <DeployDialog v-model="depDlg" :env="depEnv" :pick-commit="true" @deployed="load(true)" />
    <DeployHistoryDrawer v-model="histDlg" :env="histEnv" />
    <LogsDrawer v-model="logDlg" :env="logEnv" />
    <!-- 数据库(附加库)管理:普通实例没有项目页,这里用抽屉复用同一组件 -->
    <el-drawer v-model="dbDlg" :title="`数据库 — ${dbEnv?.name || ''}`" size="min(100vw, 960px)" destroy-on-close>
      <TabDatabases v-if="dbDlg && dbEnv" :env="dbEnv" :active="dbDlg" @changed="load(true)" />
    </el-drawer>
    <!-- 无 git 实例的定制代码上传(普通实例没有项目页,走弹窗) -->
    <CustomCodeDialog v-model="ccDlg" :env="ccEnv" @changed="load(true)" />
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage, ElNotification } from 'element-plus'
import { Plus, Refresh, Search, Grid, List, Operation, ArrowDown, ArrowRight, Check, OfficeBuilding, Box, Medal, CircleCheck, Sort, MoreFilled, Delete, Files, VideoPlay, VideoPause, RefreshRight, MoonNight, Sunny, Download, Setting, User, UserFilled, Remove } from '@element-plus/icons-vue'
import { useRoute, useRouter } from 'vue-router'
import api from '../api'
import EmptyState from '../components/EmptyState.vue'
import { openEnv, canOpenNow } from '../utils/openEnv'
import { currentTenant, isSuper, can, isEnvOwner, canCreate, roleOf, tenants, loadTenants, tenantName, envQuota, refreshMe, defaults, loadDefaults } from '../store'
import { usePolling } from '../composables/usePolling'
import { useIsMobile } from '../composables/useMedia'
import { confirmDanger } from '../utils/confirm'
import { kindLabel, kindType, statusLabel, statusTone, opLabel, opColor, opDoneLabel, isBusy, BUSY, KIND_ORDER, STATUS_ORDER, expireShort, expireSoon, barColor } from '../utils/labels'
import { fmtDate, fmtLocal, fmtSize } from '../utils/format'
import EnvCard from '../components/environment/EnvCard.vue'
import EnvFormDialog from '../components/environment/EnvFormDialog.vue'
import EnvBatchDialog from '../components/environment/EnvBatchDialog.vue'
import EnvBulkOpsDialog from '../components/environment/EnvBulkOpsDialog.vue'
import DeployDialog from '../components/environment/DeployDialog.vue'
import DeployHistoryDrawer from '../components/environment/DeployHistoryDrawer.vue'
import LogsDrawer from '../components/environment/LogsDrawer.vue'
import TabDatabases from '../components/environment/TabDatabases.vue'
import CustomCodeDialog from '../components/environment/CustomCodeDialog.vue'
import DeleteEnvDialog from '../components/environment/DeleteEnvDialog.vue'
import AclEditor from '../components/environment/AclEditor.vue'

const rows = ref([]); const loading = ref(false); const statsMap = ref({})
// ---- 回收站 ----
const showTrash = ref(false)
const trashCount = ref(0)
const trashDays = reactive({ normal: 7, prod: 30 })
function setTrash(v) { if (showTrash.value === v) return; showTrash.value = v; router.replace({ query: v ? { trash: 1 } : {} }); load() }
async function loadTrashCount() { try { const params = filterTenant.value ? { tenant_id: filterTenant.value, trash: 1 } : { trash: 1 }; trashCount.value = (await api.get('/environments', { params, silent: true })).length } catch {} }
const delDlg = ref(null)
// 实例(项目根)自身是生产,或项目里有生产分支 → 只能进回收站
const projectHasProd = (row) => row.kind === 'production' || rows.value.some((r) => r.project_id === row.id && r.kind === 'production')
const aclDlg = ref(false); const aclEnv = ref(null)
function openAcl(row) { aclEnv.value = row; aclDlg.value = true }
const isMobile = useIsMobile()
// 详情入口:实例绑定了仓库 + 分支 → 卡片显示「详情」(每个实例就是一个项目;从详情页派生的环境跳到其根实例并选中该分支)
const router = useRouter(); const route = useRoute()
if (route.query.trash === '1') showTrash.value = true
// 详情页入口:有仓库分支的走项目视图;无仓库实例走单实例详情(日志/监控/备份/数据库/Shell/设置 + 定制代码)
const projectOf = (row) => !!row.my_role && (row.repo_url ? !!row.branch : true)
const openProject = (row) => router.push({ path: `/environments/${row.project_id || row.id}`, query: row.project_id ? { branch: row.branch } : {} })
const filterTenant = ref(null); const keyword = ref(route.query.q ? String(route.query.q) : '')  // ?q= 来自顶栏「跳转到实例」
watch(() => route.query.q, (q) => { if (q) { keyword.value = String(q); if (showTrash.value) setTrash(false) } })
const view = ref(localStorage.getItem('envView') || 'card')
const viewOptions = [{ label: '看板', value: 'card', icon: Grid }, { label: '列表', value: 'list', icon: List }]
const saveView = (v) => localStorage.setItem('envView', v)
// ---- 看板分组 ----
const GROUP_OPTIONS = [
  { value: 'tenant', label: '组织', icon: OfficeBuilding },
  { value: 'kind', label: '类型', icon: Box },
  { value: 'version', label: 'Odoo 版本', icon: Sort },
  { value: 'edition', label: '社区版 / 企业版', icon: Medal },
  { value: 'status', label: '状态', icon: CircleCheck },
]
const groupBy = ref(localStorage.getItem('envGroupBy') || '')
const collapsedGroups = reactive({})
const setGroupBy = (v) => { groupBy.value = v || ''; localStorage.setItem('envGroupBy', groupBy.value); Object.keys(collapsedGroups).forEach((k) => delete collapsedGroups[k]) }
const toggleGroup = (k) => { collapsedGroups[k] = !collapsedGroups[k] }
/** 分组后的看板数据:[{key,label,icon,iconClass,rows,running}];未分组时只有一组 */
const grouped = computed(() => {
  const list = filtered.value
  if (!groupBy.value) return [{ key: 'all', label: '', rows: list, running: 0 }]
  const map = new Map()
  const put = (key, label, row, extra = {}) => { if (!map.has(key)) map.set(key, { key: String(key), label, rows: [], running: 0, ...extra }); const g = map.get(key); g.rows.push(row); if (row.status === 'running') g.running++ }
  for (const r of list) {
    if (groupBy.value === 'tenant') put(`t${r.tenant_id}`, tenantName(r.tenant_id), r)
    else if (groupBy.value === 'kind') put(r.kind, kindLabel(r.kind), r, { order: KIND_ORDER[r.kind] ?? 9 })
    else if (groupBy.value === 'version') put(`v${r.odoo_version}`, `Odoo ${r.odoo_version}`, r, { icon: r.odoo_version, iconClass: `v${r.odoo_version}`, order: -Number(r.odoo_version) })
    else if (groupBy.value === 'edition') put(r.edition, r.edition === 'enterprise' ? '企业版' : '社区版', r, { order: r.edition === 'enterprise' ? 0 : 1 })
    else if (groupBy.value === 'status') put(r.status, statusLabel(r.status), r, { order: STATUS_ORDER[r.status] ?? 9 })
  }
  return [...map.values()].sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || a.label.localeCompare(b.label, 'zh'))
})

// ---- 过渡态完成提示 ----
const prevStatus = new Map() // id -> {status, name}
let loadSeq = 0 // load() 请求序号:轮询与 open()/弹窗回调等会并发调用 load,乱序返回的陈旧列表会把 prevStatus 退回忙碌态,导致完成提示重复弹出
function notifyTransitions(list) {
  const seen = new Set()
  for (const r of list) {
    seen.add(r.id)
    const p = prevStatus.get(r.id)
    if (p && BUSY.includes(p.status) && !BUSY.includes(r.status)) {
      const done = opDoneLabel(p.status)
      if (r.status === 'failed') ElNotification.error({ title: `实例「${r.name}」${done}失败`, message: r.status_message || '请查看日志', duration: 8000 })
      else if (p.status === 'stopping') ElNotification.success({ title: `实例「${r.name}」已停止`, duration: 4000 })
      else ElNotification.success({ title: `实例「${r.name}」${done}成功`, message: r.url ? `访问 ${r.url}` : '', duration: 5000 })
    }
    prevStatus.set(r.id, { status: r.status, name: r.name })
  }
  for (const [id, p] of prevStatus) {
    if (!seen.has(id)) {
      if (p.status === 'destroying') ElNotification.success({ title: `实例「${p.name}」已删除`, duration: 4000 })
      prevStatus.delete(id)
    }
  }
}

const creatableTenants = computed(() => tenants.value.filter((t) => ['production', 'staging', 'dev'].some((k) => canCreate(t.id, k))))
const batchTenants = computed(() => tenants.value.filter((t) => isSuper.value || roleOf(t.id) === 'owner'))
const st = (row) => statsMap.value[row.id] || {}
// 实例列表只显示“项目根实例”:从详情页按分支派生的环境(project_id 指向根)属于该实例内部,不单独成卡(回收站视图例外:分支环境也可能单独被删)
const topRows = computed(() => { if (showTrash.value) return rows.value; const ids = new Set(rows.value.map((r) => r.id)); return rows.value.filter((r) => !r.project_id || !ids.has(r.project_id)) })
const childrenOf = (row) => rows.value.filter((r) => r.project_id === row.id)
const count = (s) => topRows.value.filter((r) => r.status === s).length
const busyCount = computed(() => topRows.value.filter(isBusy).length)
const filtered = computed(() => {
  const k = keyword.value.trim().toLowerCase()
  if (!k) return topRows.value
  // 搜索时也匹配分支环境的名称/分支,命中则显示其所属根实例
  const hitIds = new Set(rows.value.filter((r) => [r.name, r.url, r.domain, r.branch, tenantName(r.tenant_id)].some((x) => (x || '').toString().toLowerCase().includes(k))).map((r) => r.project_id || r.id))
  return topRows.value.filter((r) => hitIds.has(r.id))
})

async function load(silent = false) {
  if (!silent) loading.value = true
  const mySeq = ++loadSeq
  try {
    const params = filterTenant.value ? { tenant_id: filterTenant.value } : {}
    if (showTrash.value) params.trash = 1
    const list = await api.get('/environments', { params, silent })
    if (mySeq !== loadSeq) return  // 已有更晚发起的 load,丢弃这次陈旧响应(否则 prevStatus 被旧数据回退,完成提示会重复弹)
    notifyTransitions(list)
    rows.value = list
    if (showTrash.value) trashCount.value = list.length
    else if (!silent) loadTrashCount()
    if (!silent) refreshMe()  // 同步配额计数
    if (!silent) loadStats()
  } catch {} finally { if (mySeq === loadSeq) loading.value = false }
}
// 资源占用来自后端每 10s 一次的采集缓存,单独 10s 轮询即可(以前跟着列表 2s 一起打,白白翻倍请求)
async function loadStats() {
  if (!rows.value.some((r) => r.status === 'running')) return
  const params = filterTenant.value ? { tenant_id: filterTenant.value } : {}
  try { statsMap.value = await api.get('/environments/stats', { params, silent: true }) } catch {}
}
// 有过渡态实例时 2s 刷一次(进度条流畅),否则 6s;没有运行中/过渡态实例时也慢刷(状态可能被别人改)
const poll = usePolling(() => load(true), { intervalFn: () => (rows.value.some(isBusy) ? 2000 : 6000), immediate: false })
const statsPoll = usePolling(loadStats, { interval: 10000, immediate: false })

// 「打开」= 一键登录:先开空白窗口(避免被拦截),再向平台要一次性登录地址,直达 Odoo 首页
async function open(row) { await openEnv(row, { onStatus: () => load(true) }) }
const formDlg = ref(null)
const batchDlg = ref(null)
const opsDlg = ref(null); const opsTable = ref(null); const opsSel = ref([]); const boardSel = ref([])
function onOpsSel(rows) { opsSel.value = rows }
function toggleBoardSel(id, on) { boardSel.value = on ? [...new Set([...boardSel.value, id])] : boardSel.value.filter((x) => x !== id) }
const selRows = computed(() => (view.value === 'card' ? filtered.value.filter((e) => boardSel.value.includes(e.id)) : opsSel.value))
const selIds = computed(() => (view.value === 'card' ? boardSel.value : opsSel.value.map((e) => e.id)))
const selCount = computed(() => selIds.value.length)
const selTenantId = computed(() => { const ts = new Set(selRows.value.map((e) => e.tenant_id)); return ts.size === 1 ? [...ts][0] : null })
function clearOpsSel() { opsTable.value?.clearSelection(); opsSel.value = []; boardSel.value = [] }
// 注意:el-dropdown 的 @command 会把「下拉项实例」作为第二个参数传进来,故这里只接受数组形式的 ids,否则退回当前选择
function openOps(kind, ids) { opsDlg.value?.open(kind, Array.isArray(ids) ? ids : selIds.value, { tenantId: selTenantId.value }) }
function afterOps() { clearOpsSel(); load(true) }
function emptyTrash() { openOps('env.purge', filtered.value.map((e) => e.id)) }
watch([showTrash, view], () => clearOpsSel())
function openBatch() { batchDlg.value?.open(filterTenant.value || currentTenant.value?.tenant_id || null) }
function openCreate() { formDlg.value?.openCreate(filterTenant.value || currentTenant.value?.tenant_id || null) }
function openEdit(row) { formDlg.value?.openEdit(row) }
function onMore(cmd, row) {
  if (cmd === 'edit') openEdit(row)
  if (cmd === 'deployments') openHistory(row)
  if (cmd === 'delete') row.status === 'deleted' ? purge(row) : delDlg.value?.open(row, { allowPurge: !projectHasProd(row) })
  if (cmd === 'acl') openAcl(row)
  if (cmd === 'purge') purge(row)
  if (cmd === 'databases') { dbEnv.value = row; dbDlg.value = true }
  if (cmd === 'customcode') { ccEnv.value = row; ccDlg.value = true }
}
const dbDlg = ref(false); const dbEnv = ref(null)
const ccDlg = ref(false); const ccEnv = ref(null)
// 抽屉里的实例对象跟随列表刷新(状态 / 附加库数变化)
watch(() => rows.value, (list) => { if (dbEnv.value) { const cur = list.find((r) => r.id === dbEnv.value.id); if (cur) dbEnv.value = cur } })
function onRowMenu(cmd, row) {
  if (['provision', 'start', 'stop', 'restart'].includes(cmd)) return act(row, cmd)
  if (cmd === 'open') return open(row)
  if (cmd === 'logs') return openLogs(row)
  if (cmd === 'deploy') return openDeploy(row)
  if (cmd === 'project') return openProject(row)
  return onMore(cmd, row)
}
async function purge(row) {
  const ok = await confirmDanger({ title: '彻底删除实例', message: `将永久删除「${row.name}」的容器、数据库与全部文件,不可恢复。`, requireText: row.name, inputLabel: `请输入实例名「${row.name}」以确认:`, confirmText: '彻底删除' })
  if (!ok) return
  try { await api.delete(`/environments/${row.id}/purge`); ElMessage.success('开始彻底删除'); load(true) } catch {}
}
async function act(row, action) {
  if (row.kind === 'production' && action === 'stop') {
    if (!(await confirmDanger({ title: '停止生产实例', message: '停止后该生产实例的用户将无法访问。', requireText: row.name, inputLabel: `请输入实例名「${row.name}」以确认:`, confirmText: '停止' }))) return
  }
  try {
    if (action === 'untrash') { await api.post(`/environments/${row.id}/restore`); ElMessage.success('正在从回收站恢复'); setTrash(false); return }
    // 休眠实例的「启动」= 唤醒(只需 open 权限)
    await api.post(`/environments/${row.id}/${action === 'start' && row.status === 'sleeping' ? 'wake' : action}`)
    ElMessage.success({ provision: '开始创建,完成后会提示', start: row.status === 'sleeping' ? '唤醒中,请稍候' : '启动中,请稍候', stop: '停止中', restart: '重启中,约 15~30 秒' }[action])
    load(true)
  } catch {}
}
// ---- 部署 / 历史 / 日志 ----
const depDlg = ref(false); const depEnv = ref(null)
function openDeploy(row) { depEnv.value = row; depDlg.value = true }
const histDlg = ref(false); const histEnv = ref(null)
function openHistory(row) { histEnv.value = row; histDlg.value = true }
const logDlg = ref(false); const logEnv = ref(null)
function openLogs(row) { logEnv.value = row; logDlg.value = true }

onMounted(async () => {
  try { await loadTenants() } catch {}
  loadDefaults()  // 填充 defaults.git_enabled 等(列表里的部署入口据此显隐)
  api.get('/environments/defaults', { silent: true }).then((d) => { if (d.trash_keep_days != null) trashDays.normal = Number(d.trash_keep_days); if (d.trash_keep_days_production != null) trashDays.prod = Number(d.trash_keep_days_production) }).catch(() => {})
  if (!isSuper.value && currentTenant.value && tenants.value.length > 1) filterTenant.value = currentTenant.value.tenant_id
  await load(); poll.start(); statsPoll.start()
})
</script>

<style scoped>
.envs { padding: 12px 24px 28px; }
/* 一行:范围切换 | 状态概览 ………… 工具;放不下时工具整体换到第二行 */
.topbar { display: flex; align-items: center; margin-bottom: 12px; gap: 8px 14px; flex-wrap: wrap; }
.summary { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
.scope-tabs { display: inline-flex; gap: 2px; background: #eceef2; padding: 3px; border-radius: 9px; }
.scope { display: inline-flex; align-items: center; gap: 6px; border: none; background: transparent; padding: 4px 11px; border-radius: 7px; font: inherit; font-size: 13px; font-weight: 600; color: var(--text-2); cursor: pointer; line-height: 18px; }
.scope:hover { color: var(--text); }
.scope.on { background: #fff; color: var(--text); box-shadow: 0 1px 2px rgba(20, 28, 42, .08); }
.scope.trash.on { color: #b91c1c; }
.scope .cnt { font-size: 11px; font-weight: 700; background: #fee2e2; color: #b91c1c; border-radius: 999px; padding: 0 6px; line-height: 16px; }
.chip { display: inline-flex; align-items: center; gap: 5px; font-size: 12px; padding: 2px 9px; border-radius: 999px; background: #f1f5f9; color: #475569; line-height: 18px; }
.chip .dot { width: 7px; height: 7px; border-radius: 50%; background: #94a3b8; }
.chip.run { background: var(--ok-bg); color: #047857; } .chip.run .dot { background: var(--ok); }
.chip.stop { background: #f1f5f9; color: #475569; }
.chip.sleep { background: var(--sleep-bg); color: var(--sleep); } .chip.sleep .dot { background: var(--sleep); }
.chip.busy { background: var(--warn-bg); color: #b45309; } .chip.busy .dot { background: var(--warn); }
.chip.fail { background: var(--danger-bg); color: #b91c1c; } .chip.fail .dot { background: var(--danger); }
.tools { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-left: auto; }
.tools .el-button + .el-button { margin-left: 0; }

.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(330px, 1fr)); gap: 14px; }
/* 分组看板 */
.board.grouped { display: flex; flex-direction: column; gap: 16px; }
.group-btn { display: inline-flex; align-items: center; gap: 6px; }
.group-btn > span { display: inline-flex; align-items: center; gap: 6px; }
.chk { margin-left: auto; color: var(--el-color-primary); }
.group-head { display: flex; align-items: center; gap: 10px; padding: 6px 12px; margin-bottom: 10px; border-radius: 10px; background: var(--surface); border: 1px solid var(--line); cursor: pointer; user-select: none; position: sticky; top: 0; z-index: 2; }
.group-head:hover { border-color: #cfd5de; }
.group-head .arrow { color: var(--text-3); transition: transform .15s; transform: rotate(90deg); }
.group-sec.collapsed .group-head .arrow { transform: none; }
.group-sec.collapsed .group-head { margin-bottom: 0; }
.group-head .g-icon { width: 24px; height: 24px; border-radius: 6px; color: #fff; font-weight: 800; font-size: 11px; display: inline-flex; align-items: center; justify-content: center; }
.group-head .g-icon.v19, .app-icon.v19 { background: linear-gradient(135deg, #714b67, #a24689); }
.group-head .g-icon.v18, .app-icon.v18 { background: linear-gradient(135deg, #017e84, #21b799); }
.group-head .g-icon.v17, .app-icon.v17 { background: linear-gradient(135deg, #875a7b, #e46f78); }
.group-head .g-title { font-size: 15px; font-weight: 700; color: var(--text); }
.group-head .g-count { font-size: 12px; font-weight: 700; color: var(--text-2); background: var(--line-2); border-radius: 999px; padding: 1px 8px; min-width: 22px; text-align: center; }
.group-head .g-stats { margin-left: auto; display: flex; gap: 12px; font-size: 12px; color: #64748b; }
.group-head .s { display: inline-flex; align-items: center; gap: 5px; }
.group-head .s i { width: 7px; height: 7px; border-radius: 50%; background: #b6bec9; }
.group-head .s.run { color: #047857; font-weight: 600; } .group-head .s.run i { background: var(--ok); }
.card.new { background: var(--surface-2); border-radius: 12px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; border: 2px dashed #d5dbe3; color: #64748b; min-height: 200px; cursor: pointer; transition: border-color .15s, color .15s, background .15s; }
.card.new:hover { border-color: var(--brand); color: var(--brand); background: var(--surface); }
.card.new.off { cursor: not-allowed; opacity: .6; } .card.new.off:hover { border-color: #d5dbe3; color: #64748b; background: var(--surface-2); }
.quota-n { margin-left: 6px; font-size: 11px; opacity: .85; font-variant-numeric: tabular-nums; }

/* 列表视图 */
.app-icon { width: 34px; height: 34px; border-radius: 9px; display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 800; flex: none; box-shadow: inset 0 -2px 0 rgba(0,0,0,.15); }
.app-icon .ver { font-size: 12px; letter-spacing: -.5px; }
.row-name { display: flex; align-items: center; gap: 10px; }
.row-name .name { font-size: 14px; font-weight: 700; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.row-name .sub { font-size: 12px; color: var(--text-3); margin-top: 2px; }
.mini-progress { display: flex; flex-direction: column; gap: 2px; font-size: 12px; }
.exp-soon { color: var(--danger) !important; font-weight: 600; }
.bar { height: 6px; border-radius: 999px; background: var(--line-2); overflow: hidden; }
.bar i { display: block; height: 100%; border-radius: 999px; transition: width .6s ease; }
.mini { display: flex; align-items: center; gap: 8px; font-size: 12px; color: #475569; }
.mini .bar { flex: 1; height: 5px; }
.list-card { border-radius: 14px; }
.trash-tools { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
.trash-tools .mut { color: var(--text-3); font-size: 12.5px; }
.ops-bar { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; padding: 8px 14px; background: var(--brand-50, var(--surface-2)); border: 1px solid var(--brand-200, var(--line-2)); border-radius: 10px; }
.ops-bar .cnt { font-size: 13px; } .ops-bar .cnt b { color: var(--brand-600); }
.ops-bar .sep { width: 1px; height: 16px; background: var(--line-2); }
.ops-bar .grow { flex: 1; }
.obar-enter-active, .obar-leave-active { transition: opacity .18s, transform .18s; }
.obar-enter-from, .obar-leave-to { opacity: 0; transform: translateY(-6px); }
.trash-tip { margin-bottom: 14px; }
</style>
