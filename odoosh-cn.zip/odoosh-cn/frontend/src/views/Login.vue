<template>
  <div class="login">
    <!-- 左侧品牌区(手机端隐藏) -->
    <section class="side">
      <div class="side-inner">
        <div class="brand"><BrandLogo :size="34" /><span>{{ BRAND.name }}<span v-if="BRAND.badge" class="badge">{{ BRAND.badge }}</span></span></div>
        <h1>{{ BRAND.tagline }}</h1>
        <p>一键创建生产 / 测试 / 开发实例,连接 Git 仓库自动部署,备份恢复与资源监控集中管理。</p>
        <ul class="points">
          <li><el-icon><Box /></el-icon>多版本 Odoo 实例,社区版 / 企业版可选</li>
          <li><el-icon><Connection /></el-icon>GitHub / Gitee 分支推送即部署</li>
          <li><el-icon><FolderChecked /></el-icon>每日自动备份,任意时点恢复</li>
        </ul>
      </div>
      <div class="side-foot">© {{ year }} {{ brandFull }}<template v-if="BRAND.icp"> · <a class="icp" href="https://beian.miit.gov.cn/" target="_blank" rel="noopener">{{ BRAND.icp }}</a></template></div>
    </section>

    <!-- 右侧登录表单 -->
    <section class="form-wrap">
      <div class="form-box">
        <div class="brand mobile-only"><BrandLogo :size="34" /><span>{{ BRAND.name }}<span v-if="BRAND.badge" class="badge">{{ BRAND.badge }}</span></span></div>
        <h2>登录</h2>
        <p class="sub">使用平台账号登录控制台</p>
        <el-form :model="form" @submit.prevent="submit" label-position="top" size="large">
          <el-form-item label="用户名">
            <el-input v-model="form.username" autofocus autocomplete="username" :prefix-icon="User" />
          </el-form-item>
          <el-form-item label="密码">
            <el-input v-model="form.password" type="password" show-password autocomplete="current-password" :prefix-icon="Lock" @keyup.enter="submit" />
          </el-form-item>
          <el-form-item v-if="captcha.enabled" label="验证码">
            <div class="captcha-row">
              <el-input v-model="form.captcha_code" maxlength="4" autocomplete="off" :prefix-icon="Key" placeholder="图中 4 个字符" class="captcha-input" @keyup.enter="submit" />
              <button type="button" class="captcha-img" :class="{ loading: captcha.loading }" title="看不清?点击换一张" @click="refreshCaptcha">
                <img v-if="captcha.image" :src="captcha.image" alt="验证码" />
                <span v-else class="muted">{{ captcha.loading ? '加载中…' : '点击获取' }}</span>
              </button>
            </div>
          </el-form-item>
          <el-button type="primary" size="large" class="submit" :loading="loading" :disabled="!canSubmit" @click="submit">登 录</el-button>
        </el-form>
        <div class="tip muted">忘记密码请联系平台管理员重置</div>
        <!-- 备案号：窄屏时左侧品牌区(含 © 与备案号)整体隐藏，这里补一份，保证任何屏宽都看得到 -->
        <div v-if="BRAND.icp" class="tip icp-sm"><a class="icp" href="https://beian.miit.gov.cn/" target="_blank" rel="noopener">{{ BRAND.icp }}</a></div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { User, Lock, Key, Box, Connection, FolderChecked } from '@element-plus/icons-vue'
import api from '../api'
import { loadSession } from '../store'
import { BRAND, applyBrand, brandFull } from '../brand'
import BrandLogo from '../components/BrandLogo.vue'

const router = useRouter(); const route = useRoute()
const form = reactive({ username: '', password: '', captcha_code: '' })
const loading = ref(false)
const year = new Date().getFullYear()
// 图形验证码(平台设置 auth.captcha 控制是否启用;一次性,提交失败后自动换一张)
const captcha = reactive({ enabled: false, id: null, image: '', loading: false })
async function refreshCaptcha() {
  if (!captcha.enabled || captcha.loading) return
  captcha.loading = true; form.captcha_code = ''
  try { const r = await api.get('/auth/captcha', { silent: true }); captcha.id = r.id; captcha.image = r.image } catch { captcha.image = '' } finally { captcha.loading = false }
}
onMounted(async () => {
  try {
    const c = await api.get('/auth/config', { silent: true })
    captcha.enabled = !!c.captcha
    applyBrand(c.brand)  // 品牌名同接口带回(登录页未登录,只能走公开接口)
  } catch { captcha.enabled = false }
  if (captcha.enabled) refreshCaptcha()
})
const canSubmit = computed(() => form.username && form.password && (!captcha.enabled || (form.captcha_code && captcha.id)))

async function submit() {
  if (!canSubmit.value) return
  loading.value = true
  try {
    const payload = { username: form.username, password: form.password }
    if (captcha.enabled) { payload.captcha_id = captcha.id; payload.captcha_code = form.captcha_code }
    const res = await api.post('/auth/login', payload)
    localStorage.setItem('token', res.access_token)
    await loadSession()
    // 只允许站内相对路径(禁止 //evil.com 这类协议相对地址)
    const rd = route.query.redirect
    const to = typeof rd === 'string' && rd.startsWith('/') && !rd.startsWith('//') && !rd.startsWith('/login') ? rd : '/environments'
    router.replace(to)
  } catch {
    /* 拦截器已提示;验证码一次性,失败后换一张 */
    if (captcha.enabled) refreshCaptcha()
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login { height: 100%; display: flex; background: #fff; }
.side { flex: 0 0 46%; max-width: 560px; background: #1b2230; color: #fff; display: flex; flex-direction: column; justify-content: space-between; padding: 44px 52px; position: relative; overflow: hidden; }
.side::after { content: ''; position: absolute; right: -120px; bottom: -160px; width: 420px; height: 420px; border-radius: 50%; background: radial-gradient(closest-side, rgba(113, 75, 103, .45), transparent); pointer-events: none; }
.side-inner { position: relative; }
.brand { display: flex; align-items: center; gap: 10px; font-size: 17px; font-weight: 650; }
.brand > span { display: inline-flex; align-items: center; gap: 7px; }
.badge { font-size: 10.5px; font-weight: 700; letter-spacing: .06em; line-height: 1; padding: 3px 6px; border-radius: 5px; background: rgba(201, 165, 190, .18); color: #d9b8cf; border: 1px solid rgba(201, 165, 190, .35); }
.mobile-only .badge { background: var(--brand-50); color: var(--brand); border-color: var(--brand-100); }
.logo { width: 34px; height: 34px; border-radius: 9px; background: var(--brand); color: #fff; font-weight: 700; font-size: 17px; display: flex; align-items: center; justify-content: center; }
.side h1 { font-size: 30px; font-weight: 650; letter-spacing: -.02em; margin: 56px 0 14px; line-height: 1.25; }
.side p { color: #aab4c3; font-size: 14.5px; line-height: 1.7; margin: 0 0 32px; max-width: 380px; }
.points { list-style: none; padding: 0; margin: 0; display: grid; gap: 14px; color: #d6dbe3; font-size: 14px; }
.points li { display: flex; align-items: center; gap: 12px; }
.points .el-icon { width: 30px; height: 30px; border-radius: 8px; background: rgba(255, 255, 255, .07); color: #c9a5be; font-size: 16px; display: inline-flex; align-items: center; justify-content: center; }
.side-foot { color: #667385; font-size: 12px; position: relative; }
.side-foot .icp { color: inherit; text-decoration: none; }
.side-foot .icp:hover { color: #aab4c3; text-decoration: underline; }

.form-wrap { flex: 1; display: flex; align-items: center; justify-content: center; padding: 32px 24px; background: var(--bg); }
.form-box { width: 100%; max-width: 380px; background: #fff; border: 1px solid var(--line); border-radius: 16px; padding: 34px 34px 28px; box-shadow: var(--shadow); }
.form-box h2 { margin: 0; font-size: 22px; font-weight: 650; letter-spacing: -.01em; }
.form-box .sub { margin: 4px 0 24px; color: var(--text-3); font-size: 13.5px; }
.submit { width: 100%; margin-top: 4px; font-size: 15px; letter-spacing: .1em; }
.tip { text-align: center; font-size: 12.5px; margin-top: 18px; }
.captcha-row { display: flex; gap: 10px; width: 100%; align-items: stretch; }
.captcha-input { flex: 1; min-width: 0; }
.captcha-img { flex: none; width: 120px; height: 40px; padding: 0; border: 1px solid var(--line); border-radius: 8px; background: #fff; cursor: pointer; overflow: hidden; display: inline-flex; align-items: center; justify-content: center; font-size: 12px; }
.captcha-img img { width: 100%; height: 100%; object-fit: cover; display: block; }
.captcha-img:hover { border-color: var(--brand); }
.captcha-img.loading { opacity: .6; }
.mobile-only { display: none; }
.icp-sm { display: none; margin-top: 8px; }
.icp-sm .icp { color: var(--text-3); text-decoration: none; }
.icp-sm .icp:hover { text-decoration: underline; }
@media (max-width: 900px) {
  .side { display: none; }
  .mobile-only { display: flex; justify-content: center; margin-bottom: 22px; color: var(--text); }
  .icp-sm { display: block; }
  .form-box { padding: 28px 22px 22px; }
  .form-box h2, .form-box .sub { text-align: center; }
}
</style>
