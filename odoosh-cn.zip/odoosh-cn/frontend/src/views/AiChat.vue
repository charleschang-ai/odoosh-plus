<template>
  <div class="ai-full">
    <AiChatPanel :dense="isNarrow" :active="true" />
  </div>
</template>

<script setup>
import AiChatPanel from '../components/ai/AiChatPanel.vue'
import { useIsNarrow } from '../composables/useMedia'

const isNarrow = useIsNarrow()  // 手机端整页也用紧凑布局(会话列表改用顶部下拉)
</script>

<style scoped>
.ai-full { height: 100%; }
</style>
