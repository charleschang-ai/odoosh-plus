<template>
  <div class="page settings" v-loading="loading">
    <div class="page-header">
      <div>
        <h2>系统设置</h2>
        <div class="desc">修改后点击右上角「保存」生效;标记 <i class="dot" /> 的项已修改未保存</div>
      </div>
      <PageTools>
        <el-input v-model="q" placeholder="搜索设置项" clearable :prefix-icon="Search" class="search" />
        <el-button :disabled="!dirtyKeys.length" @click="reset">放弃修改</el-button>
        <el-button type="primary" :loading="saving" :disabled="!dirtyKeys.length" @click="save">保存<span v-if="dirtyKeys.length">({{ dirtyKeys.length }})</span></el-button>
      </PageTools>
    </div>

    <!-- 左侧分组导航(桌面) -->
    <div class="layout">
      <nav class="toc">
        <a v-for="g in visibleGroups" :key="g.title" :href="`#g-${g.id}`" :class="[{ active: activeId === g.id }, `tone-${g.id}`]" @click.prevent="scrollTo(g.id)">
          <span class="toc-ic"><el-icon><component :is="g.icon" /></el-icon></span>{{ g.title }}
          <span v-if="dirtyIn(g)" class="dot" />
        </a>
        <a v-if="visibleLinks.length" href="#g-links" :class="[{ active: activeId === 'links' }, 'tone-links']" @click.prevent="scrollTo('links')">
          <span class="toc-ic"><el-icon><Link /></el-icon></span>常用链接
        </a>
      </nav>

      <div class="groups">
        <el-card v-for="g in visibleGroups" :key="g.title" :id="`g-${g.id}`" shadow="never" class="group" :class="`tone-${g.id}`">
          <template #header>
            <div class="g-head">
              <span class="g-icon"><el-icon><component :is="g.icon" /></el-icon></span>
              <div><div class="g-title">{{ g.title }}</div><div class="g-desc muted">{{ g.desc }}</div></div>
            </div>
          </template>
          <div class="fields">
            <div v-for="f in g.fields" :key="f.key" class="field" :class="{ dirty: isDirty(f.key) }">
              <div class="f-label">
                <div class="f-name">{{ f.label }}<i v-if="isDirty(f.key)" class="dot" /></div>
                <div class="f-help muted" v-if="f.help">{{ f.help }}</div>
                <code class="f-key" v-if="f.type !== 'button'">{{ f.key }}</code>
              </div>
              <div class="f-ctrl">
                <el-switch v-if="f.type === 'bool'" :model-value="values[f.key] === '1'" @change="(v) => (values[f.key] = v ? '1' : '0')" inline-prompt active-text="开" inactive-text="关" />
                <el-input-number v-else-if="f.type === 'number'" :model-value="toNum(values[f.key])" :min="f.min ?? 0" :max="f.max" :precision="f.key === 'limits.env_cpus' ? 1 : 0" :step="f.key === 'limits.env_cpus' ? 0.5 : 1" controls-position="right" class="num" @update:model-value="(v) => (values[f.key] = v == null ? '' : String(v))" />
                <el-select v-else-if="f.type === 'multi'" :model-value="split(values[f.key])" multiple collapse-tags collapse-tags-tooltip class="wide" @change="(v) => (values[f.key] = v.join(','))">
                  <el-option v-for="o in f.options" :key="o.value" :label="o.label" :value="o.value" />
                </el-select>
                <el-button v-else-if="f.type === 'button'" :loading="acting === f.key" @click="runAction(f)">{{ f.text }}</el-button>
                <el-select v-else-if="f.type === 'select'" v-model="values[f.key]" class="num">
                  <el-option v-for="o in f.options" :key="o.value" :label="o.label" :value="o.value" />
                </el-select>
                <el-input v-else-if="f.type === 'tags'" v-model="values[f.key]" class="wide" :placeholder="f.placeholder">
                  <template #append>逗号分隔</template>
                </el-input>
                <el-input v-else-if="f.type === 'textarea'" v-model="values[f.key]" type="textarea" :rows="6" class="wide mono-ta" spellcheck="false" :placeholder="f.placeholder" />
                <el-input v-else-if="f.secret" v-model="values[f.key]" type="password" show-password :placeholder="saved[f.key] === MASKED ? '已设置(留空保持不变;输入新值覆盖)' : (f.placeholder || '未设置')" class="wide" />
                <el-input v-else v-model="values[f.key]" :placeholder="f.placeholder" class="wide" />
              </div>
            </div>
          </div>
        </el-card>
        <!-- 常用链接(只读;搜索也会匹配) -->
        <el-card v-if="visibleLinks.length" id="g-links" shadow="never" class="group tone-links">
          <template #header>
            <div class="g-head">
              <span class="g-icon"><el-icon><Link /></el-icon></span>
              <div><div class="g-title">常用链接</div><div class="g-desc muted">平台自身接口文档与 Odoo / Docker / Git 相关的官方资源,新窗口打开</div></div>
            </div>
          </template>
          <div class="links">
            <template v-for="grp in visibleLinks" :key="grp.title">
              <div class="links-h muted">{{ grp.title }}</div>
              <a v-for="l in grp.items" :key="l.url" class="link" :href="l.url" target="_blank" rel="noopener">
                <span class="link-name">{{ l.name }}<el-icon class="ext"><TopRight /></el-icon></span>
                <span class="link-desc muted">{{ l.desc }}</span>
                <code class="link-url">{{ l.url }}</code>
              </a>
            </template>
          </div>
        </el-card>
        <EmptyState v-if="!visibleGroups.length && !visibleLinks.length" variant="search" title="没有匹配的设置项" desc="换个关键词试试,或清空搜索框" :width="130" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref, onBeforeUnmount } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Platform, Box, Cpu, Grid, Connection, FolderChecked, Document, UploadFilled, Coin, Link, TopRight } from '@element-plus/icons-vue'
import { onBeforeRouteLeave } from 'vue-router'
import api, { MASKED } from '../api'
import EmptyState from '../components/EmptyState.vue'
import PageTools from '../components/PageTools.vue'
import { loadDefaults, loadTenants, refreshMe } from '../store'
import { loadBrand } from '../brand'

const values = reactive({})
const acting = ref('')
async function runAction(f) {
  acting.value = f.key
  try {
    if (f.action === 'replicaTest') {
      const r = await api.post('/backups/replica/test')
      if (r.ok) ElMessage.success('连接成功:bucket 可读写')
      else ElMessage.error({ message: `连接失败:${r.error}`, duration: 8000 })
    }
  } catch {} finally { acting.value = '' }
}
const saved = reactive({})
const loading = ref(false); const saving = ref(false); const q = ref('')

// type: text(默认) | bool(0/1) | number | tags(逗号分隔文本) | multi(逗号分隔多选)
const groups = [
  { id: 'platform', title: '平台', icon: Platform, desc: '名称、域名、数据存放位置与登录安全', fields: [
    { key: 'platform.brand_name', label: '平台名称', help: '侧栏左上角与浏览器标题显示的名称。可填部署方自己的名字(企业 / 学校 / 工厂皆可),留空则用内置默认 OdooSh。保存后本人立即生效,其他人下次打开页面生效', placeholder: 'OdooSh' },
    { key: 'platform.brand_badge', label: '名称后缀', help: '平台名称后的小胶囊,如「中国版」「实训平台」;留空则不显示后缀', placeholder: '留空则不显示' },
    { key: 'platform.brand_tagline', label: '登录页副标题', help: '登录页左侧品牌区的大标题', placeholder: 'Odoo 环境托管平台' },
    { key: 'platform.icp_number', label: 'ICP 备案号', help: '填了则侧栏底部显示备案号(可点开工信部备案系统)而不是版本号;留空则仍显示版本号。版本号任何时候鼠标悬停都看得到', placeholder: '如 京ICP备12345678号-1' },
    { key: 'platform.base_domain', label: '基础域名', help: '实例域名 = <实例>.<组织>.<基础域名>。可填:auto(自动用 <本机IP>.nip.io,局域网/公网可访问)| 自己的域名(如 odoo.example.com,DNS 需泛解析 *.odoo.example.com → 服务器 IP)| localhost(仅本机)。留空 = 跟随 deploy/.env 的 ODOOSH_BASE_DOMAIN。保存后立即生效并自动同步所有实例域名', placeholder: '留空跟随 .env;或填 auto / odoo.example.com' },
    { key: 'platform.access_mode', label: '实例访问模式', type: 'select', options: [{ label: '域名分流(默认)', value: 'domain' }, { label: '端口直连(无备案云服务器 / 纯内网)', value: 'port' }], help: '域名分流:实例地址 = http://<实例>.<组织>.<基础域名>,要求域名可正常解析且服务器允许该域名(国内云服务器域名未备案会被拦截)。端口直连:每个实例分配一个专属端口,地址 = http://<IP>:<端口>(端口池默认 10001-10020,.env 的 ODOOSH_ENV_PORT_RANGE 可调,云服务器需安全组放行同段);不依赖域名与备案,适合备案期间或纯内网部署。限制:端口直连下附加库不可用;切换模式后已运行实例需重启一次以更新数据库路由(dbfilter)。保存后所有实例地址自动重写' },
    { key: 'platform.git_enabled', label: '启用 Git', type: 'bool', help: '开=实例可关联 Git 仓库/分支并按推送部署(默认)。关=全系统不用 Git:创建实例只选版本/社区版或企业版,隐藏实例的 Git 操作与详情里 Git 相关内容(不影响「Git 仓库」页本身)。内网无法访问 GitHub 等外网时可关闭,改用「定制代码上传」' },
    { key: 'platform.public_url', label: '平台对外地址', help: 'Git webhook 回调、OAuth 回调用的平台地址,如 http://192.168.1.10:8080 或 https://sh.example.com;留空按请求头推断', placeholder: 'http://<IP或域名>:8080' },
    { key: 'platform.data_dir', label: '数据目录', help: '实例文件、数据库卷、备份的根目录' },
    { key: 'auth.captcha', label: '登录图形验证码', type: 'bool', help: '开 = 登录必须输入图形验证码(防脚本暴力破解);纯内网自用可关。另有同用户名 / 同 IP 连续失败锁定 3 分钟与 nginx 请求限速兜底' },
    { key: 'auth.max_failures', label: '登录失败锁定阈值', type: 'number', min: 1, max: 50, help: '同一用户名 10 分钟内连续失败达到此次数,锁定该用户名 3 分钟(同一 IP 的阈值为其 4 倍,NAT 后多人共用也不易误伤)' },
  ] },
  { id: 'env', title: '实例', icon: Box, desc: '实例默认生命周期', fields: [
    { key: 'env.expire_days_default', label: '默认过期天数', type: 'number', max: 3650, help: '新实例到期后自动删除(含数据);0 = 永不过期。每个实例可单独设置' },
    { key: 'env.expire_apply_production', label: '生产实例也默认过期', type: 'bool', help: '默认生产实例永不过期,需手动设置' },
    { key: 'sleep.idle_hours', label: '开发实例闲置休眠(小时)', type: 'number', max: 8760, help: '开发实例无人访问超过该小时数自动休眠省资源,访问域名或点「打开」会自动唤醒(约 10 秒);0 = 不休眠。仅开发实例,生产/测试永不休眠;组织管理员可在「组织设置」按组织覆盖,每个实例还可单独设置' },
    { key: 'sleep.max_running_per_project', label: '每项目同时在线开发环境上限', type: 'number', max: 100, help: '同一实例(项目)内最多同时运行几个开发分支环境;超出时自动把最久未访问的休眠(库与文件保留,访问即唤醒)。生产 / 测试不计入也不会被休眠;0 = 不限' },
    { key: 'env.use_template_db', label: '新实例用模板库秒级建库', type: 'bool', help: '同版本/类型的实例首次创建时先建「黄金模板库」,之后同类实例数秒即可创建;关闭则每次都安装 base' },
    { key: 'env.trash_keep_days', label: '回收站保留天数(测试 / 开发)', type: 'number', max: 3650, help: '删除的实例先进回收站(停容器、摘域名、保留数据),期间可一键恢复;到期自动彻底清理。0 = 永久保留直到手动彻底删除' },
    { key: 'env.trash_keep_days_production', label: '回收站保留天数(生产)', type: 'number', max: 3650, help: '生产实例进回收站后的保留天数' },
  ] },
  { id: 'databases', title: '附加数据库', icon: Coin, desc: '一个社区版实例可在同一容器里挂多个数据库(主库 + 附加库,共用实例代码,各有子域名 <库名>.<实例域名>);企业版按许可证按库授权,不支持', fields: [
    { key: 'db.max_extra_per_env', label: '每实例附加库上限(默认)', type: 'number', max: 100, help: '每个社区版实例最多可建几个附加库;0 = 关闭附加库功能。组织(组织管理页)与实例(设置 Tab)可分别覆盖' },
    { key: 'db.allow_plain_env', label: '普通实例也可建附加库', type: 'bool', help: '默认只有绑定了 Git 仓库的分支环境可建;开启后未绑仓库的普通实例(官方镜像代码)也可以' },
    { key: 'db.extra_expire_days', label: '附加库默认过期天数', type: 'number', max: 3650, help: '新建附加库默认多少天后自动删除;0 = 跟随实例(不单独过期)。新建时可改' },
    { key: 'db.backup_before_drop', label: '删除附加库前自动备份', type: 'bool', help: '删除附加库时先做一份备份到备份列表(受备份配额约束)' },
    { key: 'backup.auto_extra_dbs', label: '每日自动备份包含附加库', type: 'bool', help: '开启后自动备份除主库外也逐个备份附加库(同一实例串行);组织备份策略可覆盖' },
  ] },
  { id: 'docker', title: 'Docker', icon: Cpu, desc: '镜像拉取与单实例资源上限', fields: [
    { key: 'docker.registry_mirror', label: '镜像加速地址', placeholder: 'https://…', help: '国内环境建议配置' },
    { key: 'limits.env_memory_mb', label: '单实例内存上限', type: 'number', max: 1048576, help: '单位 MB' },
    { key: 'limits.env_cpus', label: '单实例 CPU 上限', type: 'number', max: 1024, help: '核数' },
    { key: 'limits.tenant_pg_memory_mb', label: '组织数据库容器内存', type: 'number', min: 512, max: 1048576, help: '单位 MB;每个组织一个 PostgreSQL 容器,所有实例共享。shared_buffers 等参数按此推导,新建容器时生效' },
  ] },
  { id: 'odoo', title: 'Odoo', icon: Grid, desc: '可用版本与企业版代码', fields: [
    { key: 'odoo.versions', label: '可用版本', type: 'tags', placeholder: '17,18,19' },
    { key: 'odoo.default_version', label: '默认版本' },
    { key: 'odoo.enterprise_dir', label: '企业版代码目录', help: '统一的企业版代码目录(需组织自持合法授权)。按版本分子目录,标准布局 <该目录>/19/enterprise/<模块>(把 clone 的仓库文件夹整个放进版本目录;模块直接放版本目录下也能识别)。超管在「Git 仓库」页底部「离线企业版代码」卡片上传,或有服务器权限的人直接拷进去。新建企业版实例按版本共享这一套代码' },
    { key: 'odoo.log_level', label: '实例日志等级(默认)', type: 'select', options: [{ label: 'debug(最详细)', value: 'debug' }, { label: 'info', value: 'info' }, { label: 'warn(更省日志)', value: 'warn' }, { label: 'error', value: 'error' }], help: '写入每个实例 odoo.conf 的 log_level,实例重启后生效;每个实例可在「设置 → 资源上限」单独覆盖。容器日志由 Docker 按每容器 20MB×3 自动轮转,等级越低滚得越快' },
    { key: 'odoo.extra_conf', label: 'odoo.conf 全局附加项', type: 'textarea', placeholder: 'unaccent = True\nlimit_time_real = 3600\n\n[queue_job]\nchannels = root:2', help: '仿 odoo.sh:实例的 odoo.conf 由平台生成,这里的 key = value(每行一条,可含第三方 [section])追加到所有实例;实例设置里的同名键会覆盖。平台契约项(db_* / dbfilter / addons_path / workers / 内存 / 端口 / admin_passwd 等)任何人都不能写,保存时会校验。实例重启后生效' },
    { key: 'odoo.extra_conf_env_enabled', label: '允许实例级附加项', type: 'bool', help: '开 = 有实例编辑权的用户可在「实例设置 → odoo.conf 附加项」填白名单内的键(server_wide_modules / limit_time_* / smtp_* / unaccent 等);关 = 只有上面的全局附加项生效(超级管理员仍可改实例级)' },
    { key: 'odoo.extra_conf_extra_keys', label: '额外放行的键', type: 'tags', placeholder: 'osv_memory_age_limit,screencasts', help: '在内置白名单之外再放行给普通用户的 odoo.conf 键(逗号分隔);黑名单键填了也无效。超级管理员本身不受白名单限制' },
  ] },
  { id: 'git', title: 'Git 平台', icon: Connection, desc: '平台级访问令牌(用户也可在「Git 仓库」页自行连接账号)', fields: [
    { key: 'git.github_token', label: 'GitHub Token', secret: true },
    { key: 'git.gitee_token', label: 'Gitee Token', secret: true },
    { key: 'git.github_proxy', label: 'GitHub 加速代理', placeholder: 'https://gh.llkk.cc, https://ghproxy.net', help: '国内服务器连不上 GitHub 时配置。gh-proxy 类加速前缀,逗号分隔多个,按顺序尝试,全部失败后回退直连;分支查询与企业版代码拉取都会走它。注意:私有仓库的访问令牌会经过代理方,建议使用只读、仅授权所需仓库的细粒度令牌,或自建 gh-proxy' },
  ] },
  { id: 'backup', title: '备份', icon: FolderChecked, desc: '自动备份策略与保留周期', fields: [
    { key: 'backup.dir', label: '备份目录', help: '须位于数据目录之内' },
    { key: 'backup.keep_days', label: '保留天数', type: 'number', max: 3650, help: '仅清理自动备份与恢复前备份;手动/上传的见下一项' },
    { key: 'backup.keep_days_manual', label: '手动/上传备份保留天数', type: 'number', max: 3650, help: '0 = 永久保留' },
    { key: 'backup.quota_mb', label: '每组织备份总量上限', type: 'number', max: 104857600, help: '单位 MB,0 = 不限。超出时先删最旧的自动/恢复前备份,再删最旧的手动/上传;新备份放不下会被拒绝' },
    { key: 'backup.max_concurrent', label: '同时进行的备份数', type: 'number', min: 1, max: 16, help: '手动 + 自动备份一起算,超出的排队等待;备份在平台容器内打包,数值越大越吃 IO / CPU' },
    { key: 'backup.restore_jobs', label: '恢复并行度 (pg_restore -j)', type: 'number', min: 0, max: 16, help: '平台自己的备份自带 dump.pgc(自定义格式),恢复时用 pg_restore 多进程并行导入;0 = 自动(CPU 数一半,最多 4)。上传的 Odoo 官方 zip 只有 dump.sql,仍走单线程 psql' },
    { key: 'backup.auto_enabled', label: '每日自动备份', type: 'bool' },
    { key: 'backup.auto_hour', label: '自动备份时刻', type: 'number', min: 0, max: 23, help: '服务器本地时间小时数,0-23' },
    { key: 'backup.auto_kinds', label: '自动备份实例类型', type: 'multi', options: [{ label: '生产', value: 'production' }, { label: '测试', value: 'staging' }, { label: '开发', value: 'dev' }] },
  ] },
  { id: 'replica', title: '备份异地副本', icon: UploadFilled, desc: '备份完成后异步推送到 S3 兼容对象存储(阿里云 OSS / 腾讯云 COS / MinIO / AWS S3);本地备份文件丢失时恢复会自动从副本拉回并校验 sha256。备份与实例数据在同一块盘上时,这是唯一能扛住磁盘 / 主机故障的保障', fields: [
    { key: 'backup.replica_enabled', label: '启用异地副本', type: 'bool', help: '开启后每个新备份完成即推送;历史备份由调度器每 10 分钟补推(每次最多 3 个)。删除备份时远端对象一并删除' },
    { key: 'backup.replica_endpoint', label: 'Endpoint', placeholder: 'https://oss-cn-hangzhou.aliyuncs.com / http://minio:9000', help: 'S3 兼容地址;AWS S3 可留空。阿里云 OSS 用外网/内网 endpoint 均可;腾讯云 COS 如 https://cos.ap-guangzhou.myqcloud.com' },
    { key: 'backup.replica_bucket', label: 'Bucket', placeholder: 'my-odoosh-backups' },
    { key: 'backup.replica_region', label: 'Region', placeholder: '可留空;AWS 如 us-east-1,COS 如 ap-guangzhou' },
    { key: 'backup.replica_access_key', label: 'Access Key' },
    { key: 'backup.replica_secret', label: 'Secret Key', secret: true },
    { key: 'backup.replica_prefix', label: '对象前缀', placeholder: 'odoosh/', help: '对象 key = 前缀 + 组织/实例/文件名' },
    { key: '_replica_test', label: '测试连接', type: 'button', text: '测试连接(先保存设置)', action: 'replicaTest', help: 'HeadBucket + 写读删一个小对象,验证地址 / 凭据 / 权限' },
  ] },
  { id: 'history', title: '历史记录与日志', icon: Document, desc: '平台库里的部署 / 恢复 / Shell / 推送记录保留期(每 6 小时清理一次)。实例容器日志由 Docker 自动轮转(每容器 20MB × 3),不在此处', fields: [
    { key: 'history.keep_days', label: '部署 / 恢复记录保留天数', type: 'number', max: 3650, help: '已结束的记录超过该天数:先清空日志正文,再删除超出「每实例保留条数」的记录;0 = 永久' },
    { key: 'history.keep_per_env', label: '每实例至少保留部署记录', type: 'number', max: 10000, help: '无论多旧,每个实例最近 N 条部署记录不删(回滚 / 追溯用)' },
    { key: 'history.shell_keep_days', label: 'Shell 会话审计保留天数', type: 'number', max: 3650, help: '含生产实例的键盘输入记录;0 = 永久' },
    { key: 'history.push_keep_days', label: 'Git 推送事件保留天数', type: 'number', max: 3650, help: '0 = 永久' },
  ] },
]

const toNum = (s) => (s === '' || s == null || isNaN(Number(s)) ? undefined : Number(s))
const split = (s) => (s ? String(s).split(',').map((x) => x.trim()).filter(Boolean) : [])
const visibleGroups = computed(() => {
  const k = q.value.trim().toLowerCase()
  if (!k) return groups
  return groups.map((g) => ({ ...g, fields: g.fields.filter((f) => [f.label, f.key, f.help].some((x) => (x || '').toLowerCase().includes(k))) })).filter((g) => g.fields.length)
})
// 常用链接(只读)。平台 API 文档随当前访问地址变化
const origin = typeof window !== 'undefined' ? window.location.origin : ''
const LINKS = [
  { title: '本平台', items: [
    { name: '平台 API 文档(Swagger)', url: `${origin}/docs`, desc: '后端 FastAPI 自动生成的接口文档,可直接在线调试;需先登录拿 JWT' },
    { name: 'ReDoc 版接口文档', url: `${origin}/redoc`, desc: '同一份 OpenAPI,阅读排版更友好' },
  ] },
  { title: 'Odoo', items: [
    { name: 'Odoo 官方 Docker 镜像(GitHub)', url: 'https://github.com/odoo/docker', desc: '官方 library/odoo 镜像的 Dockerfile 与 entrypoint,平台「官方镜像」模式拉取的就是它' },
    { name: 'Docker Hub · library/odoo', url: 'https://hub.docker.com/_/odoo', desc: '各版本标签(12~19)、镜像说明与环境变量' },
    { name: 'Odoo 源码(GitHub)', url: 'https://github.com/odoo/odoo', desc: '「源码自建」模式按分支拉取的仓库(社区版);企业版代码需自备' },
    { name: 'Odoo.sh 官方文档', url: 'https://www.odoo.com/documentation/18.0/administration/odoo_sh.html', desc: '本平台仿照的对象:分支 / 构建 / 备份 / 设置的官方说明' },
    { name: 'odoo.conf 配置项参考(CLI)', url: 'https://www.odoo.com/documentation/18.0/developer/reference/cli.html', desc: '全部配置键含义;「odoo.conf 附加项」可写哪些见本页 Odoo 分组' },
    { name: 'Odoo 版本维护与升级说明', url: 'https://www.odoo.com/documentation/18.0/administration/supported_versions.html', desc: '各版本支持周期,决定哪些版本值得继续托管' },
    { name: 'OCA 社区模块(GitHub)', url: 'https://github.com/OCA', desc: 'queue_job、server-tools 等常用第三方模块来源' },
    { name: 'Odoo 应用商店', url: 'https://apps.odoo.com', desc: '第三方付费 / 免费模块' },
  ] },
  { title: 'Docker', items: [
    { name: 'Docker 官方文档', url: 'https://docs.docker.com', desc: 'Engine / Compose 参考;平台通过 Docker Engine API 编排容器' },
    { name: 'Docker Compose 文件参考', url: 'https://docs.docker.com/reference/compose-file/', desc: 'deploy/docker-compose.yml 用到的语法' },
    { name: 'PostgreSQL 官方镜像', url: 'https://hub.docker.com/_/postgres', desc: '每个组织一个 PG 容器(postgres:16)所用镜像' },
    { name: '国内镜像加速站(轩辕镜像)', url: 'https://docker.xuanyuan.me', desc: '「Docker → 镜像加速」默认值;不可用时可换 docker-0.unsee.tech / docker.hlmirror.com' },
  ] },
  { title: 'Git 平台', items: [
    { name: 'GitHub OAuth Apps', url: 'https://github.com/settings/developers', desc: '创建 OAuth App 获取 client_id / secret,填到「Git 平台」分组以启用一键连接账号' },
    { name: 'GitHub Personal Access Token', url: 'https://github.com/settings/tokens', desc: '平台级访问令牌(私有仓库拉取 / webhook)' },
    { name: 'Gitee 第三方应用', url: 'https://gitee.com/oauth/applications', desc: 'Gitee OAuth 应用管理' },
    { name: 'Gitee 私人令牌', url: 'https://gitee.com/profile/personal_access_tokens', desc: 'Gitee 访问令牌' },
    { name: 'Gitee 帮助中心', url: 'https://gitee.com/help', desc: 'Webhook、SSH 公钥等操作说明' },
  ] },
]
const visibleLinks = computed(() => {
  const k = q.value.trim().toLowerCase()
  if (!k) return LINKS
  return LINKS.map((g) => ({ ...g, items: g.items.filter((l) => [l.name, l.url, l.desc, g.title].some((x) => (x || '').toLowerCase().includes(k))) })).filter((g) => g.items.length)
})
const SECRET_KEYS = new Set(groups.flatMap((g) => g.fields.filter((f) => f.secret).map((f) => f.key)))
// 密钥项:后端返回脱敏占位 MASKED 表示「已设置」;显示为空 + 占位提示,只有用户输入了新值才算改动并发送
const isDirty = (key) => {
  if (SECRET_KEYS.has(key)) return (values[key] ?? '') !== ''
  return String(values[key] ?? '') !== String(saved[key] ?? '')
}
const dirtyKeys = computed(() => Object.keys(values).filter(isDirty))
const dirtyIn = (g) => g.fields.some((f) => isDirty(f.key))

// 分组滚动定位
const activeId = ref(groups[0].id)
function scrollTo(id) { document.getElementById(`g-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); activeId.value = id }
let observer = null; let alive = true
function observe() {
  observer?.disconnect(); if (!alive) return
  observer = new IntersectionObserver((es) => { const hit = es.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0]; if (hit) activeId.value = hit.target.id.replace('g-', '') }, { rootMargin: '-56px 0px -60% 0px', threshold: 0 })
  ;[...groups.map((g) => g.id), 'links'].forEach((id) => { const el = document.getElementById(`g-${id}`); if (el) observer.observe(el) })
}

function fill(src) {
  Object.keys(saved).forEach((k) => delete saved[k]); Object.assign(saved, src)
  Object.keys(values).forEach((k) => delete values[k])
  for (const [k, v] of Object.entries(src)) values[k] = SECRET_KEYS.has(k) ? '' : v
}
async function load() {
  loading.value = true
  try { fill({ ...(await api.get('/settings')).values }) } catch {} finally { loading.value = false; setTimeout(observe, 50) }
}
async function save() {
  saving.value = true
  try {
    // 密钥项只在用户输入了新值时发送;其余项按当前值全量发送
    const body = {}
    for (const [k, v] of Object.entries(values)) { if (SECRET_KEYS.has(k)) { if (v) body[k] = v } else body[k] = v }
    const r = await api.put('/settings', { values: body })
    fill({ ...(r?.values || { ...saved, ...body }) })
    for (const k of SECRET_KEYS) if (body[k]) saved[k] = MASKED
    // 让其他页面立刻看到新值(创建实例表单的可用版本 / 默认过期 / 基础域名等走 store 缓存)
    loadDefaults(true).catch(() => {}); loadTenants(true).catch(() => {}); refreshMe()
    loadBrand(api)  // 平台名 / 名称后缀 / ICP 备案号:改完本人立即看到,不用刷新页面
    ElMessage.success('已保存')
  } catch {} finally { saving.value = false }
}
function reset() { fill({ ...saved }) }
onBeforeRouteLeave(async () => {
  if (!dirtyKeys.value.length) return true
  try { await ElMessageBox.confirm('有未保存的修改,离开将丢失。确定离开?', '未保存', { type: 'warning', confirmButtonText: '离开', cancelButtonText: '留在本页' }); return true } catch { return false }
})
onMounted(load)
onBeforeUnmount(() => { alive = false; observer?.disconnect(); observer = null })
</script>

<style scoped>
.tools { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.search { width: 220px; }
.dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; background: var(--warn); margin-left: 6px; vertical-align: middle; }
.layout { display: grid; grid-template-columns: 168px 1fr; gap: 20px; align-items: start; }
.toc { position: sticky; top: 16px; display: flex; flex-direction: column; gap: 2px; }
.toc a { display: flex; align-items: center; gap: 8px; padding: 8px 10px; border-radius: 8px; color: var(--text-2); font-size: 13.5px; font-weight: 500; text-decoration: none; }
.toc a:hover { background: #ecedf1; }
.toc a.active { background: #fff; color: var(--tone); box-shadow: 0 0 0 1px var(--line); }
.toc a.active .toc-ic { background: var(--tone); color: #fff; }
.toc-ic { width: 22px; height: 22px; border-radius: 6px; display: inline-flex; align-items: center; justify-content: center; font-size: 13px; background: var(--tone-bg); color: var(--tone); }
.groups { display: grid; gap: 14px; min-width: 0; }
/* 每个分组一个色调:左侧色条 + 表头淡色带 + 图标 */
.group { scroll-margin-top: 16px; border-left: 3px solid var(--tone); }
.group :deep(.el-card__header) { background: linear-gradient(90deg, var(--tone-bg), #fff 70%); }
.g-head { display: flex; align-items: center; gap: 12px; }
.g-icon { width: 32px; height: 32px; border-radius: 8px; background: var(--tone); color: #fff; display: inline-flex; align-items: center; justify-content: center; font-size: 16px; box-shadow: 0 3px 8px -3px var(--tone); }
.tone-platform { --tone: #714b67; --tone-bg: #f5eff3; }
.tone-env      { --tone: #2563eb; --tone-bg: #eef4ff; }
.tone-docker   { --tone: #4f46e5; --tone-bg: #eef2ff; }
.tone-odoo     { --tone: #0d9488; --tone-bg: #ecfdf8; }
.tone-git      { --tone: #ea580c; --tone-bg: #fff4ec; }
.tone-backup   { --tone: #16a34a; --tone-bg: #eefbf2; }
.tone-links    { --tone: #64748b; --tone-bg: #f1f5f9; }
.g-title { font-weight: 600; font-size: 14.5px; }
.g-desc { font-size: 12px; font-weight: 400; margin-top: 1px; }
.fields { display: flex; flex-direction: column; }
.field { display: grid; grid-template-columns: minmax(0, 1fr) 360px; gap: 24px; align-items: center; padding: 14px 0; border-bottom: 1px solid var(--line-2); }
.field:first-child { padding-top: 2px; }
.field:last-child { border-bottom: none; padding-bottom: 2px; }
.field.dirty .f-name { color: var(--warn); }
.f-name { font-weight: 500; font-size: 14px; }
.f-help { font-size: 12.5px; margin-top: 2px; line-height: 1.5; }
.f-key { display: inline-block; margin-top: 6px; font-size: 11px; color: var(--text-3); background: transparent; border-color: var(--line-2); }
.f-ctrl { display: flex; justify-content: flex-end; }
.wide { width: 100%; }
.num { width: 180px; }
.links { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 10px; padding: 4px 0 6px; }
.links-h { grid-column: 1 / -1; font-size: 12px; font-weight: 600; letter-spacing: .04em; text-transform: uppercase; margin-top: 8px; }
.links-h:first-child { margin-top: 0; }
.link { display: flex; flex-direction: column; gap: 3px; padding: 10px 12px; border: 1px solid var(--line-2); border-radius: 10px; text-decoration: none; color: var(--text); background: #fff; transition: border-color .15s, box-shadow .15s; min-width: 0; }
.link:hover { border-color: var(--tone); box-shadow: 0 4px 14px -8px var(--tone); }
.link-name { font-weight: 600; font-size: 13.5px; display: inline-flex; align-items: center; gap: 4px; }
.link-name .ext { font-size: 12px; color: var(--text-3); }
.link-desc { font-size: 12px; line-height: 1.5; }
.link-url { font-size: 11px; color: var(--text-3); background: transparent; border: none; padding: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.mono-ta :deep(textarea) { font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 12.5px; line-height: 1.5; }
.field:has(.mono-ta) { grid-template-columns: minmax(0, 1fr) 460px; align-items: start; }
@media (max-width: 1000px) { .layout { grid-template-columns: 1fr; } .toc { position: static; flex-direction: row; flex-wrap: wrap; } .toc a { padding: 6px 10px; } }
@media (max-width: 640px) {
  .field { grid-template-columns: 1fr; gap: 8px; }
  .f-ctrl { justify-content: flex-start; }
  .num { width: 100%; }
  .search { width: 100%; }
}
</style>
