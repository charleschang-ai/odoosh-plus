<template>
  <div class="page">
    <!-- 账号连接 + 定时轮询 -->
    <GitAccountsBar v-model:accounts="accounts" @changed="load" />

    <div class="page-header">
      <h2>Git 仓库</h2>
      <PageTools>
        <el-select v-model="filterTenant" placeholder="全部组织" clearable style="width: 180px" @change="load">
          <el-option v-for="t in visibleTenants" :key="t.id" :label="t.name" :value="t.id" />
        </el-select>
        <el-button :icon="Refresh" @click="load">刷新</el-button>
        <el-button v-if="canCreateRepo" type="primary" :icon="Plus" @click="formDlg?.openCreate(filterTenant)">接入仓库</el-button>
      </PageTools>
    </div>

    <!-- 手机端:卡片列表(桌面端为表格) -->
    <div v-if="isMobile" class="mlist" v-loading="loading">
      <div v-for="row in rows" :key="row.id" class="mcard">
        <div class="mc-head">
          <span class="ic prov" :class="row.provider">{{ providerLabel(row.provider).slice(0, 1) }}</span>
          <div class="mc-title">
            <a :href="webUrl(row)" target="_blank" rel="noopener" class="repo-link" :class="{ masked: hideNames }">{{ repoLabel(row) }}</a><el-tooltip :content="hideNames ? '显示仓库名' : '隐藏仓库名(演示 / 截图时用)'" placement="top" :show-after="400"><button type="button" class="eye" @click.stop="toggleHide"><el-icon><component :is="hideNames ? View : Hide" /></el-icon></button></el-tooltip>
            <div class="s muted">{{ hideNames ? '••••' : row.name }}<span v-if="row.scope !== 'platform'"> · {{ tenantName(row.tenant_id) }}</span> · <span class="mono">{{ row.default_branch || '—' }}</span></div>
          </div>
          <el-dropdown trigger="click" @command="(c) => onRowMenu(c, row)">
            <el-button circle size="small"><el-icon><MoreFilled /></el-icon></el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="branches">分支</el-dropdown-item>
                <el-dropdown-item command="events">推送记录</el-dropdown-item>
                <el-dropdown-item command="webhook">Webhook</el-dropdown-item>
                <el-dropdown-item command="poll">检查更新</el-dropdown-item>
                <el-dropdown-item command="test">测试</el-dropdown-item>
                <el-dropdown-item v-if="canManage(row)" command="edit">编辑</el-dropdown-item>
                <el-dropdown-item v-if="canManage(row)" command="remove" divided><span style="color: var(--danger)">移除</span></el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
        <div class="chips">
          <el-tag v-if="row.is_enterprise" size="small" type="danger" effect="plain">企业版</el-tag>
          <el-tag v-if="row.scope === 'platform'" size="small" type="warning" effect="plain">平台共享</el-tag>
          <span class="chip-i" :class="row.account_login || row.has_token ? 'ok' : 'off'"><el-icon><Key /></el-icon>{{ row.account_login ? row.account_login : row.has_token ? '令牌' : '公开' }}</span>
          <span class="chip-i" :class="row.webhook_id ? 'ok' : 'warn'"><el-icon><Connection /></el-icon>{{ row.webhook_id ? 'Webhook' : '手动 Hook' }}</span>
          <span class="chip-i" :class="row.auto_deploy ? 'ok' : 'off'"><el-icon><Promotion /></el-icon>{{ row.auto_deploy ? '自动部署' : '手动部署' }}</span>
        </div>
        <div class="mc-foot">
          <span v-if="row.last_error" class="err"><el-icon><WarningFilled /></el-icon> {{ row.last_error }}</span>
          <span v-else-if="row.branches_synced_at" class="muted"><el-icon class="ok-ic"><CircleCheck /></el-icon> 同步于 {{ fmtDate(row.branches_synced_at) }}</span>
          <span v-else class="muted">尚未同步</span>
        </div>
      </div>
      <EmptyState v-if="!loading && !rows.length" variant="repos" title="还没有接入仓库" :desc="canCreateRepo ? '接入 GitHub / Gitee 仓库后,可按分支创建环境并在推送时自动部署' : '请联系组织管理员接入仓库'">
        <el-button v-if="canCreateRepo" type="primary" :icon="Plus" @click="formDlg?.openCreate(filterTenant)">接入仓库</el-button>
      </EmptyState>
    </div>

    <el-card v-else shadow="never">
      <el-table :data="rows" v-loading="loading" stripe>
        <el-table-column label="仓库" min-width="300">
          <template #default="{ row }">
            <div class="cell-id">
              <span class="ic prov" :class="row.provider">{{ providerLabel(row.provider).slice(0, 1) }}</span>
              <div style="min-width: 0">
                <div class="t"><a :href="webUrl(row)" target="_blank" rel="noopener" class="repo-link" :class="{ masked: hideNames }">{{ repoLabel(row) }}</a><el-tooltip :content="hideNames ? '显示仓库名' : '隐藏仓库名(演示 / 截图时用)'" placement="top" :show-after="400"><button type="button" class="eye" @click.stop="toggleHide"><el-icon><component :is="hideNames ? View : Hide" /></el-icon></button></el-tooltip>
                  <el-tag v-if="row.is_enterprise" size="small" type="danger" effect="plain" class="ml">企业版</el-tag>
                  <el-tag v-if="row.scope === 'platform'" size="small" type="warning" effect="plain" class="ml">平台共享</el-tag>
                </div>
                <div class="s">{{ hideNames ? '••••' : row.name }}<span v-if="row.scope !== 'platform'"> · {{ tenantName(row.tenant_id) }}</span><span v-if="row.created_by_name"> · 接入者 {{ row.created_by_name }}</span> · #{{ row.id }}</div>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="默认分支" width="130"><template #default="{ row }"><span class="mono">{{ row.default_branch || '—' }}</span></template></el-table-column>
        <el-table-column label="接入" min-width="250">
          <template #default="{ row }">
            <div class="chips">
              <el-tooltip :content="row.account_login ? `使用已连接账号 ${row.account_login} 的凭据` : row.has_token ? '使用个人访问令牌' : '未配置凭据,仅能访问公开仓库'" :show-after="300">
                <span class="chip-i" :class="row.account_login || row.has_token ? 'ok' : 'off'"><el-icon><Key /></el-icon>{{ row.account_login ? row.account_login : row.has_token ? '令牌' : '公开' }}</span>
              </el-tooltip>
              <el-tooltip :content="row.webhook_id ? 'Webhook 已自动创建,推送会实时通知平台' : '需在 Git 平台手动配置 Webhook(点「Webhook」查看地址)'" :show-after="300">
                <span class="chip-i" :class="row.webhook_id ? 'ok' : 'warn'"><el-icon><Connection /></el-icon>{{ row.webhook_id ? 'Webhook' : '手动 Hook' }}</span>
              </el-tooltip>
              <el-tooltip :content="row.auto_deploy ? '收到分支推送后自动重新部署绑定的环境' : '推送后不会自动部署,需手动部署'" :show-after="300">
                <span class="chip-i" :class="row.auto_deploy ? 'ok' : 'off'"><el-icon><Promotion /></el-icon>{{ row.auto_deploy ? '自动部署' : '手动部署' }}</span>
              </el-tooltip>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="同步状态" min-width="170" show-overflow-tooltip>
          <template #default="{ row }">
            <span v-if="row.last_error" class="err"><el-icon><WarningFilled /></el-icon> {{ row.last_error }}</span>
            <span v-else-if="row.branches_synced_at" class="muted"><el-icon class="ok-ic"><CircleCheck /></el-icon> {{ fmtDate(row.branches_synced_at) }}</span>
            <span v-else class="muted">尚未同步</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" :width="isMobile ? 64 : 200" fixed="right" align="right">
          <template #default="{ row }">
            <div v-if="!isMobile" class="row-actions">
              <el-button link type="primary" @click="openBranches(row)">分支</el-button>
              <el-button link @click="openEvents(row)">推送记录</el-button>
              <el-dropdown trigger="click" @command="(c) => onRowMenu(c, row)">
                <el-button link class="more">更多<el-icon class="el-icon--right"><ArrowDown /></el-icon></el-button>
                <template #dropdown>
                  <el-dropdown-menu>
                    <el-dropdown-item command="webhook">Webhook 配置</el-dropdown-item>
                    <el-dropdown-item command="poll">检查更新</el-dropdown-item>
                    <el-dropdown-item command="test">测试连接</el-dropdown-item>
                    <el-dropdown-item v-if="row.is_enterprise && isSuper" command="import">手动导入代码</el-dropdown-item>
                    <el-dropdown-item v-if="canManage(row)" command="edit" divided>编辑</el-dropdown-item>
                    <el-dropdown-item v-if="canManage(row)" command="remove"><span style="color: var(--danger)">移除仓库</span></el-dropdown-item>
                  </el-dropdown-menu>
                </template>
              </el-dropdown>
            </div>
            <el-dropdown v-else trigger="click" @command="(c) => onRowMenu(c, row)">
              <el-button circle size="small"><el-icon><MoreFilled /></el-icon></el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item command="branches">分支</el-dropdown-item>
                  <el-dropdown-item command="events">推送记录</el-dropdown-item>
                  <el-dropdown-item command="webhook">Webhook</el-dropdown-item>
                  <el-dropdown-item command="poll">检查更新</el-dropdown-item>
                  <el-dropdown-item command="test">测试</el-dropdown-item>
                  <el-dropdown-item v-if="row.is_enterprise && isSuper" command="import">手动导入</el-dropdown-item>
                  <el-dropdown-item v-if="canManage(row)" command="edit">编辑</el-dropdown-item>
                  <el-dropdown-item v-if="canManage(row)" command="remove" divided><span style="color: var(--danger)">移除</span></el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
        </el-table-column>
        <template #empty><EmptyState variant="repos" title="还没有接入仓库" :desc="canCreateRepo ? '接入 GitHub / Gitee 仓库后,可按分支创建环境并在推送时自动部署' : '请联系组织管理员接入仓库'"><el-button v-if="canCreateRepo" type="primary" :icon="Plus" @click="formDlg?.openCreate(filterTenant)">接入仓库</el-button></EmptyState></template>
      </el-table>
    </el-card>

    <!-- 离线企业版代码(仅超管;统一目录,新建企业版实例按版本共享一套)。放页面最底部 -->
    <OfflineEnterpriseCard v-if="isSuper" class="ent-card-bottom" />

    <RepoFormDialog ref="formDlg" :accounts="accounts" :platform-ent="platformEnt" @saved="load" />
    <BranchesDrawer v-model="brDlg" :repo="cur" :can-write="canWrite(cur)" @changed="load" />
    <WebhookDialog v-model="whDlg" :repo="cur" :can-write="canWrite(cur)" @changed="load" />

    <!-- 推送记录 -->
    <el-drawer v-model="evDlg" :title="`推送记录 — ${cur?.name || ''}`" size="60%">
      <el-table :data="events" v-loading="evLoading" size="small" stripe>
        <el-table-column label="时间" width="160"><template #default="{ row }">{{ fmtDate(row.received_at) }}</template></el-table-column>
        <el-table-column prop="branch" label="分支" width="140" />
        <el-table-column label="提交" min-width="240" show-overflow-tooltip>
          <template #default="{ row }">
            <el-tag v-if="row.deleted" size="small" type="danger">分支已删除</el-tag>
            <template v-else><code class="sha">{{ shortSha(row.commit_sha) }}</code> {{ row.commit_message }}</template>
            <div class="muted">{{ row.author || row.pusher }}</div>
          </template>
        </el-table-column>
        <el-table-column label="环境" width="90"><template #default="{ row }">{{ row.matched_env_ids ? row.matched_env_ids.split(',').length + ' 个' : '-' }}</template></el-table-column>
        <el-table-column prop="result" label="结果" min-width="180" show-overflow-tooltip />
      </el-table>
      <el-empty v-if="!evLoading && !events.length" description="尚未收到推送。请先在 Git 平台配置 Webhook。" />
    </el-drawer>

    <!-- 企业版代码手动导入(超管):加速与直连都失败时的兜底,导入后离线也能创建实例 -->
    <el-dialog v-model="impDlg" :title="`手动导入企业版代码 — ${cur?.name || ''}`" :width="isMobile ? '95%' : '760px'">
      <div v-loading="impLoading">
        <template v-if="impInfo">
          <p class="muted" style="margin-top: 0">
            服务器连不上 GitHub(加速代理也失败)时,可把版本分支手动导入宿主机上的镜像仓库;
            平台探测失败会自动使用已导入的代码,完全离线也能创建实例。导入后可用「测试连接」查看。
          </p>
          <div class="imp-kv"><b>镜像路径(宿主机)</b><code>{{ impInfo.mirror_path }}</code>
            <el-tag size="small" :type="impInfo.exists ? 'success' : 'info'">{{ impInfo.exists ? '已存在' : '不存在,需先初始化' }}</el-tag>
          </div>
          <div class="imp-kv"><b>镜像中已有版本</b>
            <span v-if="Object.keys(impInfo.mirror_versions || {}).length">
              <el-tag v-for="(sha, v) in impInfo.mirror_versions" :key="v" size="small" class="ml">{{ v }}.0@{{ sha }}</el-tag>
            </span>
            <span v-else class="muted">无</span>
          </div>
          <div class="imp-kv"><b>在线更新</b>
            <el-input v-model="pullVer" size="small" style="width: 80px" placeholder="19" />
            <el-button size="small" type="primary" :loading="pulling" @click="pullLatest">拉取该版本最新代码</el-button>
            <span class="muted">走加速代理后台拉取;创建实例默认直接用本地已有代码,不自动追最新</span>
          </div>
          <div v-for="c in impInfo.commands" :key="c.title" class="imp-cmd">
            <div class="imp-title">{{ c.title }}
              <el-button link type="primary" size="small" @click="copyCmd(c.cmd)">复制</el-button>
            </div>
            <pre>{{ c.cmd }}</pre>
          </div>
          <p class="muted">命令中的 <code>&lt;版本&gt;</code> 换成 Odoo 大版本号(如 19);导入不影响已运行的实例。</p>
        </template>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Refresh, MoreFilled, ArrowDown, Key, Connection, Promotion, WarningFilled, CircleCheck, View, Hide } from '@element-plus/icons-vue'
import api from '../api'
import { session, isSuper, roleOf, tenants, loadTenants, tenantName } from '../store'
import { useIsMobile } from '../composables/useMedia'
import { confirmDanger } from '../utils/confirm'
import { providerLabel, providerType } from '../utils/labels'
import { fmtDate, shortSha } from '../utils/format'
import GitAccountsBar from '../components/repo/GitAccountsBar.vue'
import OfflineEnterpriseCard from '../components/repo/OfflineEnterpriseCard.vue'
import RepoFormDialog from '../components/repo/RepoFormDialog.vue'
import BranchesDrawer from '../components/repo/BranchesDrawer.vue'
import WebhookDialog from '../components/repo/WebhookDialog.vue'
import EmptyState from '../components/EmptyState.vue'
import PageTools from '../components/PageTools.vue'

const isMobile = useIsMobile()
// 仅列出当前用户为开发者及以上的组织(测试者不可见 Git)
const canWriteTenant = (id) => ['owner', 'developer'].includes(roleOf(id))
const visibleTenants = computed(() => tenants.value.filter((t) => canWriteTenant(t.id)))
const rows = ref([]); const loading = ref(false); const filterTenant = ref(null)
const accounts = ref([])
const platformEnt = computed(() => rows.value.find((r) => r.scope === 'platform' && r.is_enterprise) || null)
const formDlg = ref(null)
const cur = ref(null)
const brDlg = ref(false); const whDlg = ref(false)
const evDlg = ref(false); const evLoading = ref(false); const events = ref([])
const impDlg = ref(false); const impLoading = ref(false); const impInfo = ref(null)
const pullVer = ref(''); const pulling = ref(false)

const webUrl = (row) => row.url.replace(/\.git$/, '')
// 隐藏仓库名(演示 / 截图时不暴露 owner/repo);本机记住选择
const hideNames = ref(localStorage.getItem('repos.hideNames') === '1')
function toggleHide() { hideNames.value = !hideNames.value; localStorage.setItem('repos.hideNames', hideNames.value ? '1' : '0') }
const repoLabel = (row) => (hideNames.value ? '••••/••••' : `${row.owner}/${row.repo}`)
// 仓库属于接入者本人:可管(编辑/移除/建分支/Webhook)= 后端返回的 can_manage(接入者本人 / 超管;旧记录由组织管理员接管)
const canManage = (r) => !!r && !!r.can_manage
// 接入仓库:任一组织的开发者及以上(接入的是自己的仓库)
const canCreateRepo = computed(() => isSuper.value || (session.me?.memberships || []).some((m) => ['owner', 'developer'].includes(m.role)))
const canWrite = (r) => !!r && canManage(r) && ['github', 'gitee'].includes(r.provider) && !!(r.account_login || r.has_token)

async function load() {
  loading.value = true
  try { rows.value = await api.get('/repos', { params: filterTenant.value ? { tenant_id: filterTenant.value } : {} }) } catch {} finally { loading.value = false }
}
async function remove(row) {
  if (!(await confirmDanger({ title: '移除仓库', message: `移除仓库「${row.name}」?不影响已创建的环境,只是平台不再跟踪它。`, confirmText: '移除' }))) return
  try { await api.delete(`/repos/${row.id}`); ElMessage.success('已移除'); load() } catch {}
}
async function pollRepo(row) {
  try {
    const r = await api.post(`/repos/${row.id}/poll`)
    if (r.count) ElMessage.success(`发现 ${r.count} 处更新:${r.events.map((e) => e.branch).join('、')}`)
    else ElMessage.info('远端没有新提交')
    load()
  } catch {}
}
async function testRepo(row) {
  try {
    if (row.is_enterprise) {
      const r = await api.post(`/enterprise/repos/${row.id}/probe`)
      const vs = Object.keys(r.versions).sort().map((v) => `${v}.0`).join(', ') || '无'
      const local = r.local.map((x) => `${x.version}.0@${x.commit}`).join(', ') || '尚未拉取'
      ElMessageBox.alert(`可用版本分支:${vs}\n本地已拉取:${local}`, '企业版仓库')
      return
    }
    const r = await api.post(`/repos/${row.id}/test`)
    r.ok ? ElMessage.success(r.message) : ElMessage.error(r.message)
    load()
  } catch {}
}
function openBranches(row) { cur.value = row; brDlg.value = true }
function openWebhook(row) { cur.value = row; whDlg.value = true }
async function openEvents(row) {
  cur.value = row; evDlg.value = true; evLoading.value = true
  try { events.value = await api.get(`/repos/${row.id}/events`) } catch { events.value = [] } finally { evLoading.value = false }
}
async function openImport(row) {
  cur.value = row; impDlg.value = true; impLoading.value = true; impInfo.value = null
  try { impInfo.value = await api.get(`/enterprise/repos/${row.id}/import-info`) } catch { impDlg.value = false } finally { impLoading.value = false }
}
async function pullLatest() {
  const v = (pullVer.value || '').trim()
  if (!/^\d{2}$/.test(v)) { ElMessage.warning('版本号应形如 19'); return }
  pulling.value = true
  try {
    const r = await api.post(`/enterprise/repos/${cur.value.id}/pull`, null, { params: { version: v } })
    ElMessage.success(r.message || '已开始后台拉取')
  } catch {} finally { pulling.value = false }
}
async function copyCmd(text) {
  try { await navigator.clipboard.writeText(text); ElMessage.success('已复制') } catch { ElMessage.error('复制失败,请手动选择复制') }
}
function onRowMenu(cmd, row) {
  ({ branches: openBranches, events: openEvents, webhook: openWebhook, poll: pollRepo, test: testRepo, import: openImport, edit: (r) => formDlg.value?.openEdit(r), remove })[cmd]?.(row)
}
onMounted(async () => {
  try { await loadTenants() } catch {}
  await load()
})
</script>

<style scoped>
.tools { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.err { color: var(--danger); font-size: 12px; display: inline-flex; align-items: center; gap: 4px; }
.ok-ic { color: var(--ok); vertical-align: -2px; }
.prov { color: #fff; }
.prov.github { background: #24292f; }
.prov.gitee { background: #c71d23; }
.prov.gitlab { background: #e24329; }
.prov.other, .prov.custom { background: var(--text-3); }
.repo-link { color: var(--text); font-weight: 650; }
.repo-link:hover { color: var(--brand); }
.repo-link.masked { letter-spacing: 1px; color: var(--text-3); }
.eye { margin-left: 4px; padding: 0 3px; border: none; background: transparent; color: var(--text-3); cursor: pointer; vertical-align: -1px; font-size: 13px; line-height: 1; border-radius: 4px; opacity: .55; }
.eye:hover { opacity: 1; color: var(--brand); background: var(--surface-2); }
.ml { margin-left: 6px; vertical-align: 1px; }
.chips { display: flex; gap: 6px; flex-wrap: wrap; }
.row-actions { display: inline-flex; align-items: center; gap: 4px; }
.row-actions .el-button + .el-button, .row-actions .el-button + .el-dropdown { margin-left: 8px; }
.more { color: var(--text-2); }
.sha { background: var(--surface-2); padding: 1px 5px; border-radius: 3px; font-size: 12px; margin-right: 6px; }
.imp-kv { margin: 6px 0; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.imp-kv code { background: var(--surface-2); padding: 1px 6px; border-radius: 3px; font-size: 12px; word-break: break-all; }
.imp-cmd { margin: 12px 0; }
.imp-title { font-weight: 600; margin-bottom: 4px; }
.imp-cmd pre { background: var(--surface-2); border-radius: 6px; padding: 10px 12px; font-size: 12px; line-height: 1.6; overflow-x: auto; white-space: pre-wrap; word-break: break-all; margin: 0; }
</style>
