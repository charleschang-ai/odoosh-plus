<template>
  <!-- Docker 中心:两页合一 —— 「容器与镜像」(原 Docker 页)+「基础镜像」(原 Images 页),各自内容原样复用 -->
  <div class="page docker-center">
    <el-tabs v-model="tab" class="dc-tabs" @tab-change="onTab">
      <el-tab-pane label="容器与镜像" name="docker"><Docker v-if="tab === 'docker'" /></el-tab-pane>
      <el-tab-pane label="基础镜像" name="images"><Images v-if="tab === 'images'" /></el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import Docker from './Docker.vue'
import Images from './Images.vue'

const route = useRoute(); const router = useRouter()
const tab = ref(route.query.tab === 'images' ? 'images' : 'docker')
watch(() => route.query.tab, (t) => { tab.value = t === 'images' ? 'images' : 'docker' })
function onTab(t) { router.replace({ query: { ...route.query, tab: t } }) }
</script>

<style scoped>
.docker-center :deep(.page) { padding: 0; }
.docker-center :deep(.page-header h2) { display: none; }
.dc-tabs :deep(.el-tabs__header) { margin-bottom: 18px; }
.dc-tabs :deep(.el-tabs__item) { font-weight: 600; font-size: 14.5px; height: 44px; }
.dc-tabs :deep(.el-tabs__item.is-active) { font-weight: 800; }
</style>
