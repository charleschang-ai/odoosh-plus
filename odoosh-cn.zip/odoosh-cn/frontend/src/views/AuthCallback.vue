<template>
  <div class="wrap">
    <div class="card">
      <template v-if="!error">
        <div class="spin" />
        <div class="t">正在进入 {{ BRAND.name }}…</div>
      </template>
      <template v-else>
        <div class="t err">无法进入</div>
        <p class="msg">{{ error }}</p>
        <p class="msg dim">请返回课程系统重新点击进入;如果反复失败,请联系老师。</p>
        <router-link to="/login" class="link">使用账号密码登录</router-link>
      </template>
    </div>
  </div>
</template>

<script setup>
// 第三方免登回调:/auth/callback?code=<一次性 code>&next=/environments/4
// code 由 POST /api/ext/handoff(target=console)签发,60 秒一次性;换到的登录令牌与密码登录完全相同。
import { onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import api from '../api'
import { BRAND } from '../brand'
import { clearSession, loadSession, setCurrentTenant } from '../store'

const route = useRoute()
const router = useRouter()
const error = ref('')

onMounted(async () => {
  const code = route.query.code
  if (typeof code !== 'string' || !code) { error.value = '缺少登录凭据'; return }
  try {
    clearSession()  // 覆盖浏览器里可能残留的其他账号登录态
    const res = await api.post('/ext/exchange', { code }, { silent: true })
    localStorage.setItem('token', res.access_token)
    await loadSession()
    if (res.tenant_id) setCurrentTenant(res.tenant_id)  // 切到令牌绑定的组织
    sessionStorage.setItem('sidebarCollapsed', '1')  // 免登(多为嵌入)会话默认收起侧栏;之后的手动展开只记在本标签页,不影响正常登录
    // menu=0:本次免登隐藏整个左侧菜单(来自 handoff 的 menu 参数或令牌的「免登默认隐藏侧栏」开关)
    if (route.query.menu === '0') sessionStorage.setItem('navHidden', '1')
    else sessionStorage.removeItem('navHidden')

    // 只允许站内相对路径(禁止 //evil.com 这类协议相对地址)
    const nx = route.query.next
    const to = typeof nx === 'string' && nx.startsWith('/') && !nx.startsWith('//') && !nx.startsWith('/login') ? nx : '/environments'
    router.replace(to)
  } catch (e) {
    error.value = e?.detail || '登录凭据无效或已过期'
  }
})
</script>

<style scoped>
.wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: var(--bg, #f8fafc); padding: 24px; }
.card { width: 100%; max-width: 420px; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 36px 32px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.spin { width: 28px; height: 28px; margin: 0 auto 16px; border: 3px solid #e2e8f0; border-top-color: var(--brand, #3b82f6); border-radius: 50%; animation: r .8s linear infinite; }
@keyframes r { to { transform: rotate(360deg); } }
.t { font-size: 16px; font-weight: 600; color: #0f172a; }
.t.err { color: #dc2626; margin-bottom: 8px; }
.msg { color: #475569; line-height: 1.7; margin: 0 0 6px; }
.dim { color: #94a3b8; font-size: 13px; }
.link { display: inline-block; margin-top: 12px; color: var(--brand, #3b82f6); }
</style>
