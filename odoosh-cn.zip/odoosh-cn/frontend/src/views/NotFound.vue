<template>
  <div class="page nf">
    <div class="box">
      <div class="code">404</div>
      <h2>页面不存在</h2>
      <p class="muted">没有找到 <code>{{ route.fullPath }}</code>,它可能已被移动或删除。</p>
      <div class="acts">
        <el-button type="primary" @click="router.replace('/environments')">返回实例列表</el-button>
        <el-button @click="router.back()">返回上一页</el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRoute, useRouter } from 'vue-router'
const route = useRoute(); const router = useRouter()
</script>

<style scoped>
.nf { display: flex; align-items: center; justify-content: center; min-height: 60vh; }
.box { text-align: center; max-width: 420px; }
.code { font-size: 96px; font-weight: 800; letter-spacing: -.04em; line-height: 1; background: linear-gradient(135deg, var(--brand), #2563eb); -webkit-background-clip: text; background-clip: text; color: transparent; }
h2 { margin: 12px 0 6px; font-size: 20px; font-weight: 650; }
p { margin: 0 0 22px; font-size: 13.5px; }
.acts { display: flex; gap: 8px; justify-content: center; }
</style>
