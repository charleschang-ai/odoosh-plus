<template>
  <div class="page">
    <div class="page-header">
      <div>
        <h2>用户</h2>
        <div class="desc">共 {{ rows.length }} 人 · 超级管理员 {{ rows.filter((r) => r.role === 'admin').length }}</div>
      </div>
      <PageTools>
        <el-input v-model="q" placeholder="搜索用户名 / 显示名 / 组织" clearable :prefix-icon="Search" class="search" />
        <el-select v-model="roleFilter" clearable placeholder="全部角色" class="role-filter">
          <el-option label="超级管理员" value="admin" />
          <el-option label="普通用户" value="member" />
        </el-select>
        <el-button :icon="Refresh" @click="load">刷新</el-button>
        <el-button type="success" plain :icon="Files" @click="importDlg = true">批量新建</el-button>
        <el-button type="primary" :icon="Plus" @click="openCreate">新建用户</el-button>
      </PageTools>
    </div>

    <!-- 批量操作条:选中后出现 -->
    <transition name="bulk">
      <div v-if="selected.length" class="bulk-bar">
        <span class="cnt">已选 <b>{{ selected.length }}</b> 个用户</span>
        <span class="sep" />
        <el-button size="small" type="success" plain :icon="CircleCheck" @click="quickActive(true)">启用</el-button>
        <el-button size="small" type="warning" plain :icon="CircleClose" @click="quickActive(false)">停用</el-button>
        <el-button size="small" type="primary" :icon="Edit" @click="bulkDlg = true">批量修改…</el-button>
        <el-button size="small" type="danger" plain :icon="Delete" @click="bulkDelete">删除</el-button>
        <span class="grow" />
        <el-button size="small" text @click="clearSel">取消选择</el-button>
      </div>
    </transition>

    <el-card shadow="never">
      <el-table ref="table" :data="filtered" v-loading="loading" stripe :row-key="(r) => r.id" @selection-change="onSel">
        <el-table-column type="selection" width="44" :selectable="(r) => !r.is_root" reserve-selection />
        <el-table-column label="用户" min-width="200">
          <template #default="{ row }">
            <div class="who">
              <span class="avatar" :class="{ off: !row.is_active, admin: row.role === 'admin' }">{{ initials(row) }}</span>
              <div><div class="n">{{ row.display_name || row.username }}</div><div class="s muted mono">{{ row.username }} · #{{ row.id }}</div></div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="平台角色" width="120"><template #default="{ row }"><el-tag size="small" effect="plain" :type="row.role === 'admin' ? 'danger' : 'info'">{{ roleLabel(row.role) }}</el-tag><el-tooltip v-if="row.is_root" content="内置超级管理员:任何人都不能删除、停用或降级" :show-after="200"><el-tag size="small" type="warning" effect="plain" style="margin-left: 4px">内置</el-tag></el-tooltip></template></el-table-column>
        <el-table-column label="实例" width="90"><template #default="{ row }"><span v-if="row.role === 'admin'" class="muted">{{ row.env_count || 0 }} / ∞</span><span v-else :class="{ 'quota-full': row.max_envs != null && (row.env_count || 0) >= row.max_envs }">{{ row.env_count || 0 }} / {{ row.max_envs == null ? '∞' : row.max_envs }}</span></template></el-table-column>
        <el-table-column label="附加库" width="90"><template #default="{ row }"><span v-if="row.role === 'admin'" class="muted">{{ row.db_count || 0 }} / ∞</span><span v-else :class="{ 'quota-full': row.max_dbs != null && (row.db_count || 0) >= row.max_dbs }">{{ row.db_count || 0 }} / {{ row.max_dbs == null ? '∞' : row.max_dbs }}</span></template></el-table-column>
        <el-table-column label="Shell" width="80"><template #default="{ row }"><el-tag size="small" effect="plain" :type="row.role === 'admin' || row.shell_enabled ? 'success' : 'info'">{{ row.role === 'admin' || row.shell_enabled ? '可用' : '关' }}</el-tag></template></el-table-column>
        <el-table-column label="所属组织 / 角色" min-width="280">
          <template #default="{ row }">
            <span v-if="row.role === 'admin'" class="muted">全部组织</span>
            <template v-else-if="row.memberships?.length">
              <span v-for="m in row.memberships" :key="m.tenant_id" class="mem"><b>{{ m.tenant_name }}</b><span class="muted"> · {{ ROLE_LABEL[m.role] }}</span></span>
            </template>
            <span v-else class="muted">未加入任何组织</span>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="90">
          <template #default="{ row }"><el-tag size="small" effect="plain" :type="row.is_active ? 'success' : 'info'">{{ row.is_active ? '启用' : '停用' }}</el-tag></template>
        </el-table-column>
        <el-table-column label="操作" :width="isMobile ? 64 : 130" fixed="right" align="right">
          <template #default="{ row }">
            <div v-if="!isMobile">
              <el-button link type="primary" @click="openEdit(row)">编辑</el-button>
              <el-button v-if="!row.is_root" link type="danger" @click="remove(row)">删除</el-button>
            </div>
            <el-dropdown v-else trigger="click" @command="(c) => (c === 'edit' ? openEdit(row) : remove(row))">
              <el-button circle size="small"><el-icon><MoreFilled /></el-icon></el-button>
              <template #dropdown><el-dropdown-menu><el-dropdown-item command="edit">编辑</el-dropdown-item><el-dropdown-item v-if="!row.is_root" command="remove" divided><span style="color: var(--danger)">删除</span></el-dropdown-item></el-dropdown-menu></template>
            </el-dropdown>
          </template>
        </el-table-column>
        <template #empty><EmptyState :variant="q || roleFilter ? 'search' : 'generic'" :title="q || roleFilter ? '没有匹配的用户' : '还没有用户'" :width="130" /></template>
      </el-table>
    </el-card>

    <el-dialog v-model="dlg" :title="form.id ? '编辑用户' : '新建用户'" width="560px" class="user-dlg">
      <el-form :model="form" label-width="104px" class="user-form">
        <el-form-item label="用户名" required><el-input v-model="form.username" :disabled="!!form.id" /></el-form-item>
        <el-form-item :label="form.id ? '新密码' : '密码'" :required="!form.id">
          <el-input v-model="form.password" type="password" show-password :placeholder="form.id ? '留空则不修改' : '至少 4 位'" :disabled="form.is_root && form.id !== session.me?.id" />
          <div v-if="form.is_root && form.id !== session.me?.id" class="form-tip">内置超级管理员的密码只能由本人修改</div>
        </el-form-item>
        <el-form-item label="显示名"><el-input v-model="form.display_name" placeholder="可选" /></el-form-item>
        <el-form-item label="角色">
          <el-radio-group v-model="form.role" :disabled="form.is_root">
            <el-radio-button value="member">普通用户</el-radio-button>
            <el-radio-button value="admin">超级管理员</el-radio-button>
          </el-radio-group>
          <div class="form-tip">{{ form.role === 'admin' ? '拥有平台及所有组织的全部权限;实例配额与 Shell 不受限' : '权限由下方各组织的成员角色决定' }}</div>
        </el-form-item>
        <template v-if="form.role === 'member'">
          <el-form-item>
            <template #label>组织权限<HelpTip text="组织管理员:一切权限 · 开发者:开发/测试实例与部署,生产只读 · 测试者:仅打开开发/测试实例" /></template>
            <div class="mem-list">
              <div v-for="(m, i) in form.memberships" :key="i" class="mem-row">
                <el-select v-model="m.tenant_id" placeholder="选择组织" class="mem-tenant">
                  <el-option v-for="t in tenants" :key="t.id" :label="t.name" :value="t.id" :disabled="form.memberships.some((x, j) => j !== i && x.tenant_id === t.id)" />
                </el-select>
                <el-select v-model="m.role" class="mem-role">
                  <el-option v-for="(label, r) in ROLE_LABEL" :key="r" :value="r" :label="label" />
                </el-select>
                <el-button circle :icon="Delete" title="移除" @click="form.memberships.splice(i, 1)" />
              </div>
              <el-button link type="primary" :icon="Plus" @click="form.memberships.push({ tenant_id: null, role: 'developer' })">添加组织</el-button>
            </div>
          </el-form-item>
          <el-form-item>
            <template #label>实例配额<HelpTip text="该用户作为「拥有者」最多可有多少个实例(按创建者 / 拥有者计数,不按有权访问的实例计数;回收站里的不占用)。创建、从回收站恢复、转让给他、在他的项目里派生分支环境时都会校验。" /></template>
            <div class="inline-ctrl">
              <el-input-number v-model="form.max_envs" :min="0" :max="10000" :step="1" controls-position="right" placeholder="不限" class="num" />
              <span class="form-tip inline">{{ form.max_envs == null ? '留空 = 不限' : form.max_envs === 0 ? '0 = 不能创建实例' : `最多 ${form.max_envs} 个` }}<template v-if="form.id"> · 现有 {{ form.env_count || 0 }} 个</template></span>
            </div>
          </el-form-item>
          <el-form-item>
            <template #label>附加库配额<HelpTip text="该用户最多可创建多少个附加数据库(社区版实例里的第二、第三个库;按创建者计数,跨实例累计)。0 = 不能创建附加库;留空 = 不限。实例 / 组织自身的上限仍同时生效。" /></template>
            <div class="inline-ctrl">
              <el-input-number v-model="form.max_dbs" :min="0" :max="10000" :step="1" controls-position="right" placeholder="不限" class="num" />
              <span class="form-tip inline">{{ form.max_dbs == null ? '留空 = 不限' : form.max_dbs === 0 ? '0 = 不能创建附加库' : `最多 ${form.max_dbs} 个` }}<template v-if="form.id"> · 已创建 {{ form.db_count || 0 }} 个</template></span>
            </div>
          </el-form-item>
          <el-form-item>
            <template #label>实例 Shell<HelpTip text="开启后该用户在有权限的实例详情页可见「Shell」Tab(开发者:开发/测试实例;组织管理员:含生产)。" /></template>
            <div class="inline-ctrl">
              <el-switch v-model="form.shell_enabled" inline-prompt active-text="开" inactive-text="关" />
              <span class="form-tip inline">{{ form.shell_enabled ? '可在实例详情页使用 Web 终端' : '不显示 Shell Tab' }}</span>
            </div>
          </el-form-item>
          <el-form-item>
            <template #label>企业版<HelpTip text="开启后该用户创建实例时可选「企业版」(需组织已备好企业版代码或离线企业版目录)。关闭则只能创建社区版。" /></template>
            <div class="inline-ctrl">
              <el-switch v-model="form.can_use_enterprise" inline-prompt active-text="开" inactive-text="关" />
              <span class="form-tip inline">{{ form.can_use_enterprise ? '创建实例时可选企业版' : '不能创建企业版实例' }}</span>
            </div>
          </el-form-item>
          <el-form-item>
            <template #label>菜单可见<HelpTip text="前四个控制侧栏菜单:关闭后侧栏不显示,直接访问其地址也会跳回实例列表。「实例设置 / 实例升级 / 实例数据库」控制实例详情页对应 Tab,默认关闭,需要的用户按人打开。只控制入口可见性,不改变已有数据。" /></template>
            <div class="menu-switches">
              <span class="menu-sw"><el-switch v-model="form.menu_dashboard" inline-prompt active-text="开" inactive-text="关" />总览</span>
              <span class="menu-sw"><el-switch v-model="form.menu_repos" inline-prompt active-text="开" inactive-text="关" />Git 仓库</span>
              <span class="menu-sw"><el-switch v-model="form.menu_ai" inline-prompt active-text="开" inactive-text="关" />AI 助手</span>
              <span class="menu-sw"><el-switch v-model="form.menu_backups" inline-prompt active-text="开" inactive-text="关" />备份与恢复</span>
              <span class="menu-sw"><el-switch v-model="form.menu_settings" inline-prompt active-text="开" inactive-text="关" />实例设置</span>
              <span class="menu-sw"><el-switch v-model="form.menu_upgrade" inline-prompt active-text="开" inactive-text="关" />实例升级</span>
              <span class="menu-sw"><el-switch v-model="form.menu_databases" inline-prompt active-text="开" inactive-text="关" />实例数据库</span>
            </div>
          </el-form-item>
        </template>
        <el-form-item label="启用" v-if="form.id">
          <div class="inline-ctrl">
            <el-switch v-model="form.is_active" :disabled="form.is_root" inline-prompt active-text="开" inactive-text="关" />
            <span v-if="form.is_root" class="form-tip inline">内置超级管理员账号受保护,不能停用 / 删除 / 降级</span>
            <span v-else-if="!form.is_active" class="form-tip inline">停用后该用户立即无法登录,已签发的登录令牌失效</span>
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dlg = false">取消</el-button>
        <el-button type="primary" :loading="saving" :disabled="!form.username || (!form.id && !form.password)" @click="save">保存</el-button>
      </template>
    </el-dialog>

    <UserImportDialog v-model="importDlg" @done="load" />
    <UserBulkDialog v-model="bulkDlg" :user-ids="selected.map((u) => u.id)" @done="afterBulk" />
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Delete, Refresh, Search, MoreFilled, Edit, Files, CircleCheck, CircleClose } from '@element-plus/icons-vue'
import api from '../api'
import EmptyState from '../components/EmptyState.vue'
import PageTools from '../components/PageTools.vue'
import HelpTip from '../components/HelpTip.vue'
import UserImportDialog from '../components/UserImportDialog.vue'
import UserBulkDialog from '../components/UserBulkDialog.vue'
import { ROLE_LABEL, tenants, loadTenants, session } from '../store'
import { useIsMobile } from '../composables/useMedia'
import { confirmDanger } from '../utils/confirm'
import { initials as initialsOf } from '../utils/format'

const isMobile = useIsMobile()
const rows = ref([]); const loading = ref(false)
const dlg = ref(false); const saving = ref(false); const q = ref(''); const roleFilter = ref('')
const importDlg = ref(false); const bulkDlg = ref(false)
const table = ref(null); const selected = ref([])
const blank = { id: null, username: '', password: '', display_name: '', role: 'member', is_active: true, shell_enabled: false, can_use_enterprise: true, menu_dashboard: true, menu_repos: true, menu_ai: true, menu_backups: true, menu_settings: false, menu_upgrade: false, menu_databases: false, max_envs: null, max_dbs: null, is_root: false, memberships: [] }
const form = reactive({ ...blank, memberships: [] })
const roleLabel = (r) => ({ admin: '超级管理员', member: '普通用户', tenant_admin: '普通用户' })[r] || r
const initials = (r) => initialsOf(r.display_name || r.username)
const filtered = computed(() => {
  const k = q.value.trim().toLowerCase()
  return rows.value.filter((r) => (!roleFilter.value || r.role === roleFilter.value) && (!k || [r.username, r.display_name, ...(r.memberships || []).map((m) => m.tenant_name)].some((x) => (x || '').toLowerCase().includes(k))))
})

async function load() { loading.value = true; try { rows.value = await api.get('/users') } catch {} finally { loading.value = false } }
function openCreate() { Object.assign(form, blank, { memberships: [{ tenant_id: tenants.value[0]?.id || null, role: 'developer' }] }); dlg.value = true }
function openEdit(row) { Object.assign(form, blank, row, { password: '', memberships: (row.memberships || []).map((m) => ({ tenant_id: m.tenant_id, role: m.role })) }); dlg.value = true }
async function save() {
  saving.value = true
  try {
    const memberships = form.role === 'member' ? form.memberships.filter((m) => m.tenant_id) : []
    const payload = { display_name: form.display_name, role: form.role, is_active: form.is_active, shell_enabled: form.shell_enabled, can_use_enterprise: form.can_use_enterprise, menu_dashboard: form.menu_dashboard, menu_repos: form.menu_repos, menu_ai: form.menu_ai, menu_backups: form.menu_backups, menu_settings: form.menu_settings, menu_upgrade: form.menu_upgrade, menu_databases: form.menu_databases, max_envs: form.max_envs === '' || form.max_envs == null ? null : Number(form.max_envs), max_dbs: form.max_dbs === '' || form.max_dbs == null ? null : Number(form.max_dbs), memberships }
    if (form.password) payload.password = form.password
    if (form.id) await api.put(`/users/${form.id}`, payload)
    else await api.post('/users', { ...payload, username: form.username, password: form.password })
    ElMessage.success('已保存'); dlg.value = false; load()
  } catch {} finally { saving.value = false }
}
async function remove(row) {
  if (!(await confirmDanger({ title: '删除用户', message: `删除用户「${row.display_name || row.username}」?其所有组织成员关系一并移除,不可恢复;名下实例会移入回收站,数据在保留期内还能恢复。` }))) return
  try { await api.delete(`/users/${row.id}`); ElMessage.success('已删除'); load() } catch {}
}

function onSel(rows) { selected.value = rows }
function clearSel() { table.value?.clearSelection(); selected.value = [] }
function afterBulk() { clearSel(); load() }
/** 统一展示批量结果:有失败则弹逐条清单,否则一句 toast。 */
function reportBulk(r, title = '批量结果') {
  const bad = r.results.filter((x) => x.status !== 'success')
  if (r.failed) {
    ElMessageBox.alert(
      `<div>成功 ${r.succeeded} · 跳过 ${r.skipped} · 失败 ${r.failed}</div><ul style="margin:8px 0 0;padding-left:18px;max-height:220px;overflow:auto">` +
      bad.map((x) => `<li><b>${x.username}</b>:${x.status === 'failed' ? '❌' : '⤼'} ${x.message || ''}</li>`).join('') + '</ul>',
      title, { dangerouslyUseHTMLString: true, confirmButtonText: '知道了' })
  } else {
    ElMessage.success(`成功 ${r.succeeded}${r.skipped ? ` · 跳过 ${r.skipped}` : ''}`)
  }
}
async function quickActive(active) {
  const ids = selected.value.map((u) => u.id)
  if (!(await confirmDanger({ title: active ? '批量启用' : '批量停用', message: `将${active ? '启用' : '停用'}选中的 ${ids.length} 个用户${active ? '' : '(停用后立即无法登录)'}。内置超级管理员会自动跳过。`, type: active ? 'info' : 'warning', confirmText: active ? '启用' : '停用', danger: !active }))) return
  try { reportBulk(await api.post('/users/bulk-update', { user_ids: ids, is_active: active })); afterBulk() } catch {}
}
async function bulkDelete() {
  const ids = selected.value.map((u) => u.id)
  const names = selected.value.map((u) => u.display_name || u.username)
  if (!(await confirmDanger({ title: `批量删除 ${ids.length} 个用户`, message: `将永久删除:${names.slice(0, 8).join('、')}${names.length > 8 ? ` 等 ${names.length} 人` : ''}。\n其组织成员关系与实例授权一并移除,不可恢复。名下实例会移入回收站,数据在保留期内还能恢复。`, requireText: '删除', inputLabel: '请输入「删除」以确认:' }))) return
  try { reportBulk(await api.post('/users/bulk-delete', { user_ids: ids }), '批量删除结果'); afterBulk() } catch {}
}
onMounted(async () => { try { await loadTenants() } catch {} load() })
</script>

<style scoped>
.tools { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.bulk-bar { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; padding: 8px 14px; background: var(--brand-50, var(--surface-2)); border: 1px solid var(--brand-200, var(--line-2)); border-radius: 10px; }
.bulk-bar .cnt { font-size: 13px; }
.bulk-bar .cnt b { color: var(--brand-600); }
.bulk-bar .sep { width: 1px; height: 16px; background: var(--line-2); }
.bulk-bar .grow { flex: 1; }
.bulk-enter-active, .bulk-leave-active { transition: opacity .18s, transform .18s; }
.bulk-enter-from, .bulk-leave-to { opacity: 0; transform: translateY(-6px); }
.search { width: 240px; }
.role-filter { width: 130px; }
.quota-full { color: var(--danger); font-weight: 600; }
.who { display: flex; align-items: center; gap: 10px; }
.avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--brand-100); color: var(--brand-600); font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; justify-content: center; flex: none; }
.avatar.admin { background: var(--danger-bg); color: #b91c1c; }
.avatar.off { background: var(--surface-2); color: var(--text-3); }
.n { font-weight: 600; }
.s { font-size: 12px; }
.mem { display: inline-block; font-size: 12.5px; background: var(--surface-2); border: 1px solid var(--line-2); border-radius: 6px; padding: 1px 8px; margin: 2px 6px 2px 0; }
.mem b { font-weight: 600; }
.mem-list { width: 100%; }
.mem-row { display: flex; gap: 8px; margin-bottom: 8px; align-items: center; }
.mem-tenant { flex: 1; min-width: 0; }
.mem-role { width: 140px; flex: none; }
.inline-ctrl { display: flex; align-items: center; gap: 10px; width: 100%; min-width: 0; }
.menu-switches { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
.menu-sw { display: inline-flex; align-items: center; gap: 6px; font-size: 13px; }
.inline-ctrl .num { width: 150px; flex: none; }
.form-tip.inline { margin: 0; width: auto; flex: 1; min-width: 0; }
.user-form :deep(.el-form-item__label) { white-space: nowrap; }
@media (max-width: 640px) { .search, .role-filter { width: 100%; } .mem-row { flex-wrap: wrap; } .mem-role { width: 100%; } }
</style>
