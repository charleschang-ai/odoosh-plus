<template>
  <div class="page dash" v-loading="loading && !data">
    <div class="page-header">
      <div>
        <h2>总览</h2>
      </div>
      <PageTools>
        <span v-if="lastAt" class="muted" style="font-size: 12px; white-space: nowrap">更新于 {{ lastAt }}</span>
        <el-switch v-model="auto" inline-prompt active-text="自动" inactive-text="手动" />
        <el-button :icon="Refresh" :loading="loading" @click="load">刷新</el-button>
      </PageTools>
    </div>

    <!-- 指标卡 -->
    <div class="stats">
      <router-link v-for="c in cards" :key="c.label" :to="isSuper ? c.to : '/environments'" class="stat" :class="c.tone">
        <div class="stat-body">
          <div class="label">{{ c.label }}</div>
          <div class="value">{{ c.value }}</div>
          <div class="hint">{{ c.hint || ' ' }}</div>
        </div>
        <div class="stat-icon"><el-icon><component :is="c.icon" /></el-icon></div>
        <el-icon class="go"><ArrowRight /></el-icon>
      </router-link>
    </div>

    <div class="grid" v-if="data">
      <!-- 主机资源 -->
      <el-card shadow="never" class="host">
        <template #header>
          <div class="card-title"><span class="t-icon host"><el-icon><Monitor /></el-icon></span><span>主机资源</span><span class="muted sub">{{ data.host.hostname }} · {{ data.host.os }} · {{ data.host.cpu_count }} 核 · 已运行 {{ uptime }}</span></div>
        </template>
        <div class="gauges">
          <div class="gauge" v-for="g in gauges" :key="g.label">
            <el-progress type="dashboard" :percentage="Math.round(g.pct)" :width="118" :stroke-width="9" :color="colorOf(g.pct)">
              <template #default="{ percentage }"><span class="pct">{{ percentage }}<small>%</small></span></template>
            </el-progress>
            <div class="g-label">{{ g.label }}</div>
            <div class="g-sub muted">{{ g.sub }}</div>
          </div>
        </div>
      </el-card>

      <!-- Docker -->
      <el-card shadow="never">
        <template #header><div class="card-title"><span class="t-icon docker"><el-icon><Cpu /></el-icon></span><span>Docker</span><el-tag v-if="data.docker.ok" size="small" type="success" effect="plain">已连接</el-tag><el-tag v-else size="small" type="danger" effect="plain">未连接</el-tag></div></template>
        <el-result v-if="!data.docker.ok" icon="warning" title="无法连接 Docker" sub-title="请确认 docker.sock 已挂载且 Docker 服务运行中" />
        <template v-else>
          <div class="kv">
            <div><span class="k">版本</span><span class="v mono">{{ data.docker.version }}</span></div>
            <div><span class="k">容器</span><span class="v">运行中 <b>{{ data.docker.containers_running }}</b> / 共 {{ data.docker.containers_total }}</span></div>
            <div><span class="k">镜像</span><span class="v">{{ data.docker.images_total }} 个</span></div>
          </div>
          <div class="quick" v-if="isSuper">
            <el-button size="small" @click="$router.push('/docker')">容器与镜像</el-button>
            <el-button size="small" @click="$router.push('/images')">基础镜像</el-button>
            <el-button size="small" @click="$router.push('/environments')">实例列表</el-button>
          </div>
        </template>
      </el-card>

      <!-- HTTPS 证书:一张泛域名证书服务所有实例,过期 = 全部实例同时报错,故在总览常驻可见 -->
      <el-card shadow="never" v-if="isSuper && data.cert" class="cert">
        <template #header>
          <div class="card-title">
            <span class="t-icon cert"><el-icon><Lock /></el-icon></span><span>HTTPS 证书</span>
            <el-tag v-if="!data.cert.present" size="small" type="info" effect="plain">未配置</el-tag>
            <el-tag v-else-if="data.cert.warn" size="small" type="danger" effect="plain">需要处理</el-tag>
            <el-tag v-else size="small" type="success" effect="plain">自动续期中</el-tag>
          </div>
        </template>

        <!-- 未配置:实例走 HTTP,给出签发命令 -->
        <template v-if="!data.cert.present">
          <div class="cert-empty">
            <p class="muted">尚未配置泛域名证书,实例通过 <b class="mono">http://</b> 访问。配好域名泛解析后执行:</p>
            <pre class="cmd mono">sudo bash deploy/ssl-domain.sh --domain 你的域名 --email 你的邮箱 --dns dns_ali</pre>
            <p class="muted tip">一张 <span class="mono">*.域名</span> 证书覆盖全部实例,新建实例无需任何证书操作。</p>
          </div>
        </template>

        <template v-else>
          <div class="kv">
            <div>
              <span class="k">剩余</span>
              <span class="v">
                <b :class="daysTone">{{ data.cert.days_left }}</b> 天
                <span class="muted">· 到期 {{ fmtDate(data.cert.not_after) }}</span>
              </span>
            </div>
            <div><span class="k">上次续期</span><span class="v">{{ fmtDate(data.cert.renewed_at) || '未知' }}</span></div>
            <div>
              <span class="k">覆盖</span>
              <span class="v mono cert-domains">{{ data.cert.domains?.join('  ') || '—' }}</span>
            </div>
          </div>
          <el-alert v-if="data.cert.error" type="error" :closable="false" show-icon class="cert-alert"
                    title="读取证书失败" :description="data.cert.error" />
          <el-alert v-else-if="data.cert.warn" type="warning" :closable="false" show-icon class="cert-alert"
                    title="证书即将到期,自动续期可能已失效"
                    description="请在服务器上执行 acme.sh --list 确认续期任务仍在,并检查 DNS 服务商 API 凭据是否过期。80 端口保持可用,过期不会导致实例完全无法访问。" />
          <p v-else class="muted tip">由 acme.sh 每日检查、到期前自动续期并 reload nginx,无需人工干预。</p>
        </template>
      </el-card>
    </div>

    <!-- 最近活动 -->
    <el-card shadow="never" class="activity" v-if="data">
      <template #header>
        <div class="card-title">
          <span class="t-icon act"><el-icon><Clock /></el-icon></span><span>最近活动</span>
          <span class="muted sub">部署 · 备份 · 恢复 · 推送 · 创建实例</span>
          <span class="spacer" />
          <el-button link size="small" :loading="actLoading" @click="loadActivity">刷新</el-button>
        </div>
      </template>
      <ul v-if="activity.length" class="feed">
        <li v-for="(a, i) in activity" :key="i" class="fi" :class="[`t-${a.type}`, `s-${a.status}`]">
          <span class="fi-ic"><el-icon><component :is="ACT_ICON[a.type] || Clock" /></el-icon></span>
          <div class="fi-body">
            <div class="fi-l1">
              <router-link v-if="a.env_id" :to="`/environments/${a.env_id}`" class="fi-env">{{ a.env }}</router-link>
              <span v-else-if="a.env" class="fi-env">{{ a.env }}</span>
              <span class="fi-title">{{ a.title }}</span>
              <span class="fi-st" :class="stTone(a)">{{ stLabel(a) }}</span>
            </div>
            <div class="fi-l2 muted">
              <span v-if="a.detail" class="fi-detail" :title="a.detail">{{ a.detail }}</span>
              <span v-if="a.tenant" class="fi-meta">{{ a.tenant }}</span>
              <span v-if="a.by" class="fi-meta">{{ a.by }}</span>
            </div>
          </div>
          <span class="fi-time" :title="fmtDate(a.at)">{{ ago(a.at) }}</span>
        </li>
      </ul>
      <EmptyState v-else variant="generic" title="还没有活动记录" desc="部署、备份、恢复与推送发生后会显示在这里" :width="120" />
    </el-card>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { Refresh, OfficeBuilding, Box, User, Monitor, ArrowRight, Cpu, Clock, Promotion, FolderChecked, RefreshLeft, Upload, Plus, Lock } from '@element-plus/icons-vue'
import api from '../api'
import { isSuper } from '../store'
import { usePolling } from '../composables/usePolling'
import { fmtSize as fmt, duration, ago, fmtDate } from '../utils/format'
import EmptyState from '../components/EmptyState.vue'
import PageTools from '../components/PageTools.vue'

const data = ref(null)
const loading = ref(false)
const lastAt = ref('')
const auto = ref(localStorage.getItem('dashAuto') !== '0')

const cards = computed(() => [
  { label: '组织', value: data.value?.counts.tenants ?? '-', icon: OfficeBuilding, to: '/tenants', tone: 'a' },
  { label: '实例', value: data.value?.counts.environments ?? '-', icon: Box, to: '/environments', tone: 'b' },
  { label: '用户', value: data.value?.counts.users ?? '-', icon: User, to: '/users', tone: 'c' },
  { label: '运行中容器', value: data.value?.docker.containers_running ?? '-', hint: data.value?.docker.ok ? `共 ${data.value.docker.containers_total} 个` : 'Docker 未连接', icon: Monitor, to: '/docker', tone: 'd' },
])
const gauges = computed(() => {
  const h = data.value?.host || {}
  return [
    { label: 'CPU', pct: h.cpu_percent || 0, sub: `${h.cpu_count} 核` },
    { label: '内存', pct: h.mem_percent || 0, sub: `${fmt(h.mem_used)} / ${fmt(h.mem_total)}` },
    { label: '磁盘', pct: h.disk_percent || 0, sub: `${fmt(h.disk_used)} / ${fmt(h.disk_total)}` },
  ]
})

const uptime = computed(() => duration(data.value?.host.uptime_seconds ?? 0))
function colorOf(p) { return p < 60 ? 'var(--ok)' : p < 85 ? 'var(--warn)' : 'var(--danger)' }
// 证书剩余天数配色:acme.sh 在 90 天证书剩 30 天左右续期,故 >30 视为正常、<20(后端 warn 阈值)标红
const daysTone = computed(() => {
  const d = data.value?.cert?.days_left
  return d == null ? '' : d < 20 ? 'bad' : d < 30 ? 'warn' : 'ok'
})

async function load(silent = false) {
  loading.value = true
  try { data.value = await api.get('/system/overview', { silent }); lastAt.value = new Date().toLocaleTimeString() } catch {} finally { loading.value = false }
}
// ---- 最近活动 ----
const activity = ref([]); const actLoading = ref(false)
const ACT_ICON = { deploy: Promotion, backup: FolderChecked, restore: RefreshLeft, push: Upload, env: Plus }
const stLabel = (a) => ({ success: '成功', done: '完成', failed: '失败', running: '进行中', queued: '排队', ok: '', deleted: '分支已删' })[a.status] ?? (a.type === 'env' ? '' : a.status || '')
const stTone = (a) => (['success', 'done'].includes(a.status) ? 'ok' : a.status === 'failed' ? 'bad' : ['running', 'queued', 'provisioning'].includes(a.status) ? 'busy' : '')
async function loadActivity() { actLoading.value = true; try { activity.value = await api.get('/system/activity', { silent: true, params: { limit: 12 } }) } catch {} finally { actLoading.value = false } }
const poll = usePolling(() => Promise.all([load(true), loadActivity()]), { interval: 30000, immediate: false })
watch(auto, (v) => { localStorage.setItem('dashAuto', v ? '1' : '0'); v ? poll.start() : poll.stop() })
onMounted(() => { load(); loadActivity(); if (auto.value) poll.start() })
</script>

<style scoped>
.tools { display: flex; align-items: center; gap: 12px; }
.stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; margin-bottom: 16px; }
/* 指标卡:各自一组渐变底色 + 右侧大图标水印 */
.stat { position: relative; display: flex; align-items: center; justify-content: space-between; gap: 12px; border-radius: var(--radius-lg); padding: 18px 20px; color: #fff; text-decoration: none; overflow: hidden; background: linear-gradient(135deg, var(--g1), var(--g2)); box-shadow: 0 6px 18px -8px var(--g2); transition: transform .15s, box-shadow .15s; }
.stat::after { content: ''; position: absolute; inset: 0; background: radial-gradient(120px 80px at 100% 0%, rgba(255, 255, 255, .22), transparent 70%); pointer-events: none; }
.stat:hover { transform: translateY(-2px); box-shadow: 0 12px 24px -10px var(--g2); text-decoration: none; }
.stat.a { --g1: #6d4a63; --g2: #9b5b8c; }
.stat.b { --g1: #2b6cb0; --g2: #4f8fe0; }
.stat.c { --g1: #1f8a55; --g2: #34b374; }
.stat.d { --g1: #c2620a; --g2: #e8893a; }
.stat-body { position: relative; z-index: 1; min-width: 0; }
.stat .label { font-size: 12.5px; opacity: .85; }
.stat .value { font-size: 28px; font-weight: 650; letter-spacing: -.02em; line-height: 1.15; margin-top: 4px; font-variant-numeric: tabular-nums; }
.stat .hint { font-size: 12px; opacity: .8; margin-top: 3px; min-height: 16px; }
.stat-icon { position: relative; z-index: 1; width: 46px; height: 46px; border-radius: 12px; background: rgba(255, 255, 255, .18); display: flex; align-items: center; justify-content: center; font-size: 22px; flex: none; backdrop-filter: blur(2px); }
.stat .go { position: absolute; right: 12px; bottom: 10px; font-size: 13px; opacity: 0; transform: translateX(-4px); transition: opacity .15s, transform .15s; }
.stat:hover .go { opacity: .9; transform: none; }
.grid { display: grid; grid-template-columns: 3fr 2fr; gap: 14px; }
.card-title { display: flex; align-items: center; gap: 10px; }
.t-icon { width: 26px; height: 26px; border-radius: 7px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; }
.t-icon.host { background: #eef4ff; color: #2563eb; }
.t-icon.docker { background: #eef2ff; color: #4f46e5; }
.t-icon.cert { background: #ecfdf5; color: #059669; }
/* HTTPS 证书卡片:占满整行(域名列表较长,且它是全局性的基础设施状态) */
.cert { grid-column: 1 / -1; }
.cert .kv .v b.ok { color: var(--ok); }
.cert .kv .v b.warn { color: var(--warn); }
.cert .kv .v b.bad { color: var(--danger); }
.cert-domains { font-size: 12.5px; word-break: break-all; }
.cert-alert { margin-top: 10px; }
.cert .tip { font-size: 12.5px; margin: 10px 0 0; }
.cert-empty .cmd { margin: 8px 0; padding: 9px 11px; background: var(--fill, #f6f8fa); border: 1px solid var(--border, #e5e7eb); border-radius: 8px; font-size: 12px; white-space: pre-wrap; word-break: break-all; }
.t-icon.act { background: #fff4ec; color: #ea580c; }
.card-title .spacer { flex: 1; }
/* 最近活动 */
.activity { margin-top: 14px; }
.activity :deep(.el-card__body) { padding: 6px 20px 10px; }
.feed { list-style: none; margin: 0; padding: 0; }
.fi { display: flex; align-items: flex-start; gap: 12px; padding: 11px 0; border-bottom: 1px solid var(--line-2); }
.fi:last-child { border-bottom: none; }
.fi-ic { width: 30px; height: 30px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; font-size: 15px; flex: none; margin-top: 1px; background: var(--surface-2); color: var(--text-2); }
.fi.t-deploy .fi-ic { background: var(--brand-50); color: var(--brand); }
.fi.t-backup .fi-ic { background: #eefbf2; color: var(--ok); }
.fi.t-restore .fi-ic { background: #fff4ec; color: #ea580c; }
.fi.t-push .fi-ic { background: #eef4ff; color: var(--info); }
.fi.t-env .fi-ic { background: #eef2ff; color: #4f46e5; }
.fi.s-failed .fi-ic { background: var(--danger-bg); color: var(--danger); }
.fi-body { flex: 1; min-width: 0; }
.fi-l1 { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; font-size: 13.5px; }
.fi-env { font-weight: 650; color: var(--text); }
a.fi-env:hover { color: var(--brand); text-decoration: none; }
.fi-title { color: var(--text-2); }
.fi-st { font-size: 11.5px; font-weight: 600; padding: 1px 7px; border-radius: 999px; background: var(--surface-2); color: var(--text-3); }
.fi-st:empty { display: none; }
.fi-st.ok { background: var(--ok-bg); color: #047857; }
.fi-st.bad { background: var(--danger-bg); color: #b91c1c; }
.fi-st.busy { background: var(--warn-bg); color: #b45309; }
.fi-l2 { font-size: 12px; margin-top: 2px; display: flex; gap: 10px; min-width: 0; }
.fi-detail { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 60%; }
.fi-meta::before { content: '·'; margin-right: 10px; color: var(--line); }
.fi-time { font-size: 12px; color: var(--text-3); white-space: nowrap; margin-top: 2px; }
.card-title .sub { font-weight: 400; font-size: 12.5px; }
.gauges { display: flex; justify-content: space-around; padding: 6px 0 2px; flex-wrap: wrap; gap: 12px; }
.gauge { text-align: center; }
.pct { font-size: 20px; font-weight: 650; letter-spacing: -.02em; }
.pct small { font-size: 12px; font-weight: 500; color: var(--text-3); margin-left: 1px; }
.g-label { font-weight: 600; font-size: 13px; margin-top: -2px; }
.g-sub { font-size: 12px; margin-top: 2px; }
.kv { display: grid; gap: 10px; font-size: 13.5px; }
.kv > div { display: flex; justify-content: space-between; padding-bottom: 10px; border-bottom: 1px dashed var(--line-2); }
.kv .k { color: var(--text-3); }
.kv .v b { font-weight: 650; }
.quick { margin-top: 14px; display: flex; flex-wrap: wrap; gap: 8px; }
.quick .el-button + .el-button { margin-left: 0; }
@media (max-width: 1100px) { .stats { grid-template-columns: repeat(2, 1fr); } .grid { grid-template-columns: 1fr; } }
@media (max-width: 640px) { .stats { gap: 10px; } .stat { padding: 14px; gap: 8px; } .stat .value { font-size: 22px; } .stat-icon { width: 36px; height: 36px; font-size: 18px; border-radius: 9px; } }
</style>
