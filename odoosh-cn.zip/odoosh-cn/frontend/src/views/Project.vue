<template>
  <div class="project" v-loading="loading && !data">
    <template v-if="data">
      <!-- 顶栏(无 Git 实例的非超管走精简头部:此行整个不渲染,返回按钮挪进下方标题行) -->
      <div v-if="!slim" class="topbar">
        <div class="tb-left">
          <el-tooltip content="返回实例列表" placement="bottom" :show-after="400"><button class="back-btn" @click="router.push('/environments')"><el-icon><ArrowLeft /></el-icon></button></el-tooltip>
          <div class="repo-title">
            <span class="repo-name" :title="repo.name">{{ repo.name }}</span>
            <span class="repo-meta">
              <template v-if="!noGit">
                <span class="chip-i"><el-icon><Connection /></el-icon>{{ repo.branch }}</span>
                <a class="repo-url" :href="repo.web_url" target="_blank" :title="repo.web_url"><el-icon><Link /></el-icon>{{ (repo.web_url || '').replace(/^https?:\/\//, '') }}</a>
              </template>
              <span class="tenant-tag">{{ tenantName }}</span>
            </span>
          </div>
        </div>
        <div class="tb-right">
          <el-button-group class="tb-acts">
            <el-tooltip v-if="!noGit" content="同步分支" placement="bottom" :show-after="300"><el-button :icon="Refresh" :loading="syncing" @click="load(true, true)" /></el-tooltip>
            <el-tooltip v-if="repo.registered" content="仓库设置" placement="bottom" :show-after="300"><el-button :icon="Setting" @click="router.push('/repos')" /></el-tooltip>
          </el-button-group>
        </div>
      </div>

      <el-alert v-if="data.mirror_error" type="warning" show-icon :closable="false" class="mirror-err" :title="`仓库镜像同步失败:${data.mirror_error}(下方分支来自缓存快照)`" />

      <div class="body" :class="{ 'no-aside': noGit }">
        <!-- 左栏:分支按档位分组(无仓库实例没有分支概念,隐藏)-->
        <aside v-if="!noGit" class="branches" :class="{ dragging: !!drag }">
          <div v-for="g in groups" :key="g.kind" class="group" :class="[`g-${g.kind}`, { 'drop-ok': drag && canDrop(g.kind), 'drop-over': dragOver === g.kind && drag && canDrop(g.kind), 'drop-no': drag && !canDrop(g.kind) }]"
            @dragenter="onDragEnter($event, g.kind)" @dragover="onDragOver($event, g.kind)" @dragleave="onDragLeave($event, g.kind)" @drop="onDrop($event, g.kind)">
            <div class="g-head">
              <span class="g-dot" /><span class="g-title">{{ g.label }}</span><span class="g-count">{{ g.items.length }}</span>
              <span class="spacer" />
              <el-button v-if="g.kind === 'unassigned'" link size="small" :icon="Refresh" title="从镜像刷新分支列表" @click="load(true, true)" />
              <span v-else-if="drag && canDrop(g.kind)" class="g-hint">{{ dropHint(g.kind) }}</span>
            </div>
            <el-input v-if="g.kind === 'unassigned' && data.unassigned.length > 6" v-model="branchKw" size="small" placeholder="搜索分支" clearable :prefix-icon="Search" class="g-search" />
            <div v-if="!g.items.length" class="g-empty">{{ g.kind === 'unassigned' ? (branchKw ? '无匹配分支' : '所有分支都已建环境') : `暂无${g.label}环境,拖分支到这里创建` }}</div>
            <div v-for="it in g.items" :key="it.key" class="item" :class="[{ active: it.key === selectedKey, env: !!it.env, dragging: drag && drag.key === it.key }, it.env ? `k-${it.env.kind}` : 'k-none']" :draggable="canManage"
              @dragstart="onDragStart($event, it)" @dragend="onDragEnd" @click="select(it)">
              <template v-if="it.env">
                <i class="st" :class="statusTone(it.env.status)" :title="statusLabel(it.env.status)" />
                <span class="b-name" :title="it.branch">{{ it.branch || it.env.name }}</span>
                <span v-if="it.env.branch && it.env.name !== it.branch" class="b-env">{{ it.env.name }}</span>
                <span v-if="it.env.extra_db_count" class="b-badge db" :title="`${it.env.extra_db_count + 1} 个数据库(主库 + ${it.env.extra_db_count} 个附加库)`">⛁{{ it.env.extra_db_count + 1 }}</span>
                <span v-if="pendingDeploy(it.env)" class="b-badge warn" title="有新提交尚未部署">待部署</span>
                <span v-if="busy(it.env)" class="b-badge busy">{{ it.env.progress || 0 }}%</span>
              </template>
              <template v-else>
                <i class="st none" />
                <span class="b-name" :title="it.branch">{{ it.branch }}</span>
                <span v-if="within(it.head?.committed_at, 24)" class="b-badge new" title="24 小时内有新提交">新</span>
                <el-tag v-if="it.is_default" size="small" effect="plain" class="def">默认</el-tag>
                <span class="b-time">{{ ago(it.head?.committed_at) }}</span>
              </template>
            </div>
          </div>
          <div v-if="canManage" class="drag-tip muted"><el-icon><Rank /></el-icon> 拖动分支到目标分组即可创建 / 改档位 / 删除;也可用右侧「更多」按钮完成同样操作</div>
          <div v-else class="drag-tip muted"><el-icon><Lock /></el-icon> 你在本项目的权限为「{{ roleLabel }}」:{{ data.role === 'viewer' ? '只能查看与打开' : '可日常运维,不能新建 / 改档 / 删除环境' }}</div>
        </aside>

        <!-- 右栏 -->
        <section class="main">
          <div v-if="!selected" class="empty-main">
            <EmptyState variant="repos" title="在左侧选择一个分支" desc="点选分支查看历史与环境;拖动分支到分组即可创建环境" :width="140" />
          </div>
          <template v-else>
            <!-- 头部 -->
            <div class="head" :class="env ? `k-${env.kind}` : ''">
              <div class="head-l">
                <div class="h-title">
                  <el-tooltip v-if="slim" content="返回实例列表" placement="bottom" :show-after="400"><button class="back-btn" @click="router.push('/environments')"><el-icon><ArrowLeft /></el-icon></button></el-tooltip>
                  <span class="h-branch">{{ noGit ? (env?.name || selected.branch) : '分支 ' + selected.branch }}</span>
                  <template v-if="env">
                    <span class="status-pill" :class="[statusTone(env.status), { clickable: canOpenNow(env) && canEnv('open') }]" :title="canOpenNow(env) && canEnv('open') ? (env.status === 'running' ? '点击免密登录进入 Odoo' : '点击唤醒并进入 Odoo') : ''" @click="canOpenNow(env) && canEnv('open') && openUrl(env)"><i class="pulse" />{{ statusLabel(env.status) }}</span>
                    <el-tag size="small" :type="kindType(env.kind)" effect="dark" class="kind-tag">{{ kindLabel(env.kind) }}</el-tag>
                  </template>
                  <el-tag v-else size="small" type="info" effect="plain" class="kind-tag">未建环境</el-tag>
                </div>
                <!-- 地址 / 版本 / 过期等信息行:精简头部整行不给(客户要求对受限用户隐藏) -->
                <div class="h-sub" v-if="env && !slim">
                  <a v-if="env.url && canOpenNow(env)" :href="env.url" class="h-url" :title="env.status === 'running' ? '免密登录进入 Odoo' : '唤醒并进入 Odoo'" @click.prevent="openUrl(env)">{{ env.url.replace(/^https?:\/\//, '') }}</a>
                  <span v-else-if="env.url" class="muted">{{ env.url.replace(/^https?:\/\//, '') }}</span>
                  <span v-else class="muted">尚未分配域名</span>
                  <template v-if="!noGit">
                    <span class="dot-sep">·</span>
                    <span>当前 <span class="mono">{{ env.code_commit ? env.code_commit.slice(0, 7) : '—' }}</span></span>
                    <span v-if="pendingDeploy(env)" class="dot-sep">·</span>
                    <span v-if="pendingDeploy(env)" class="warn-text">最新 <span class="mono">{{ selected.head.sha.slice(0, 7) }}</span> 待部署</span>
                  </template>
                  <span class="dot-sep">·</span>
                  <span>Odoo {{ env.odoo_version }} {{ env.edition === 'enterprise' ? '企业版' : '社区版' }}</span>
                  <template v-if="env.extra_db_count && tabEnabled('databases')">
                    <span class="dot-sep">·</span>
                    <a href="#" class="h-dbs" title="查看本实例的全部数据库" @click.prevent="tab = 'databases'">⛁ {{ env.extra_db_count + 1 }} 个数据库</a>
                  </template>
                  <span class="dot-sep">·</span>
                  <span :class="{ 'warn-text': expireSoon(env) }">{{ expireText(env) }}</span>
                </div>
                <div class="h-sub" v-else-if="!env">
                  <span class="mono">{{ (selected.head?.sha || '').slice(0, 7) }}</span> {{ selected.head?.message }} <span class="muted">· {{ ago(selected.head?.committed_at) }}</span>
                </div>
                <div v-if="env && busy(env)" class="h-progress">
                  <el-icon class="is-loading"><Loading /></el-icon><span>{{ opLabel(env.status) }}:{{ env.status_message || '处理中...' }}</span>
                  <el-progress :percentage="env.progress || 0" :stroke-width="6" :show-text="false" striped striped-flow style="flex: 1" />
                  <b>{{ env.progress || 0 }}%</b>
                </div>
                <div v-else-if="env && env.status === 'failed'" class="h-progress fail"><el-icon><WarningFilled /></el-icon><span class="h-fail-msg">{{ env.status_message || '操作失败' }}</span><el-button v-if="env.repo_url" link type="danger" size="small" @click="openLastDeployLog">查看日志</el-button></div>
              </div>
              <div class="head-r">
                <template v-if="env">
                  <el-button v-if="canEnv('open')" :disabled="!canOpenNow(env)" @click="openUrl(env)"><el-icon><TopRight /></el-icon>{{ env.status === 'running' ? '打开' : '唤醒并打开' }}</el-button>
                  <el-button v-if="canEnv('create') && (!env.container_name || env.status === 'failed')" type="primary" :disabled="busy(env)" @click="act('provision')"><el-icon><VideoPlay /></el-icon>{{ env.container_name ? '重试创建' : '创建并启动' }}</el-button>
                  <el-button v-else-if="canEnv('deploy') && env.container_name && !noGit" type="primary" :disabled="busy(env)" @click="deployLatest()"><el-icon><Promotion /></el-icon>部署最新</el-button>
                  <el-button v-if="env.status === 'sleeping' && canEnv('open')" type="success" @click="act('wake')"><el-icon><Sunny /></el-icon>唤醒</el-button>
                  <el-button v-if="canEnv('restart') && env.container_name" :disabled="busy(env) || env.status !== 'running'" @click="act('restart')"><el-icon><RefreshRight /></el-icon>重启</el-button>
                  <el-dropdown v-if="hasMoreActions" trigger="click" @command="onMore">
                    <el-button>更多<el-icon class="el-icon--right"><ArrowDown /></el-icon></el-button>
                    <template #dropdown>
                      <el-dropdown-menu>
                        <el-dropdown-item v-if="canEnv('start') && env.container_name && env.status === 'stopped'" command="start">启动</el-dropdown-item>
                        <el-dropdown-item v-if="canEnv('stop') && env.status === 'running'" command="stop">停止</el-dropdown-item>
                        <el-dropdown-item v-if="canEnv('stop') && env.kind === 'dev' && env.status === 'running'" command="sleep">休眠(访问时自动唤醒)</el-dropdown-item>
                        <el-dropdown-item v-if="canEnv('restore') && env.kind !== 'production' && data.has_production && env.db_name" command="refresh" divided>从生产刷新数据</el-dropdown-item>
                        <el-dropdown-item v-if="env.edition === 'enterprise' && env.db_name" command="license" divided>企业版到期…</el-dropdown-item>
                        <!-- 改档位:无 Git 实例只留给超管(学校场景对学生隐藏);Git 项目照旧按权限矩阵 -->
                        <template v-for="k in KINDS" :key="k">
                          <el-dropdown-item v-if="(!noGit || isSuper) && k !== env.kind" :command="`kind:${k}`" :disabled="!canMoveEnv(env, k)" :divided="k === 'production'">改为{{ kindLabel(k) }}环境{{ moveNote(env, k) }}</el-dropdown-item>
                        </template>
                        <el-dropdown-item v-if="canEnv('delete') && isOwnerOf(env) && env.id !== data.root_id && env.kind !== 'production'" command="delete" divided><span style="color: var(--danger)">删除该分支的数据库(分支保留)</span></el-dropdown-item>
                      </el-dropdown-menu>
                    </template>
                  </el-dropdown>
                </template>
                <template v-else-if="canManage">
                  <el-button v-for="k in KINDS" :key="k" :type="k === 'dev' ? 'primary' : 'default'" :disabled="!canCreateKind(k)" @click="createEnv(selected.branch, k)">建{{ kindLabel(k) }}环境</el-button>
                </template>
                <span v-else class="muted" style="font-size: 12.5px">该分支尚未建环境;你在本项目里没有创建环境的权限</span>
              </div>
            </div>

            <!-- Tabs -->
            <!-- 权限有限(如测试者)时没有任何可见 tab:给个说明,避免看起来像空白 -->
            <el-empty v-if="env && !visibleTabs.length" :image-size="70" description="你对该实例的权限有限,暂无可查看的内容。如需更多请联系实例拥有者或管理员。" />
            <!-- Tabs:lazy 首次激活才渲染,之后保留各 Tab 状态(切换不丢滚动/过滤);日志 Tab 通过 active 控制流的启停 -->
            <el-tabs v-else v-model="tab" class="tabs">
              <el-tab-pane v-if="canEnv('deploy')" label="定制代码" name="custom" :disabled="!env" lazy><TabCustomCode v-if="env" :env="env" :active="tab === 'custom'" @changed="load(true)" /></el-tab-pane>
              <el-tab-pane v-if="!noGit" label="历史" name="history">
                <TabHistory :project-id="projectId" :branch="selected.branch" :env="env" :perms="perms" @changed="load(true)" @open="openUrl(env)" />
              </el-tab-pane>
              <el-tab-pane v-if="canEnv('logs')" label="日志" name="logs" :disabled="!env" lazy><TabLogs v-if="env" :env="env" :active="tab === 'logs'" /></el-tab-pane>
              <el-tab-pane v-if="canEnv('stats')" label="监控" name="monitor" :disabled="!env" lazy><TabMonitor v-if="env" :env="env" :active="tab === 'monitor'" /></el-tab-pane>
              <el-tab-pane v-if="canEnv('backup') || canEnv('restore')" label="备份" name="backups" :disabled="!env" lazy><TabBackups v-if="env" :env="env" :perms="perms" :has-production="data.has_production" :project-id="projectId" :active="tab === 'backups'" @changed="load(true)" /></el-tab-pane>
              <el-tab-pane v-if="canEnv('open') && tabEnabled('databases')" name="databases" :disabled="!env" lazy>
                <template #label>数据库<span v-if="env?.extra_db_count" class="tab-cnt">{{ env.extra_db_count + 1 }}</span></template>
                <TabDatabases v-if="env" ref="dbTab" :env="env" :perms="perms" :active="tab === 'databases'" @changed="load(true)" @shell="onShellDb" />
              </el-tab-pane>
              <el-tab-pane v-if="canEnv('deploy') && tabEnabled('upgrade')" label="升级" name="upgrade" :disabled="!env" lazy><TabUpgrade v-if="env" :env="env" :project-id="projectId" :perms="perms" @changed="load(true)" /></el-tab-pane>
              <el-tab-pane v-if="shellVisible" label="Shell" name="shell" :disabled="!env || !canEnv('shell')" lazy><TabShell v-if="env" :env="env" :database-id="shellDbId" @update:database-id="(v) => (shellDbId = v)" /></el-tab-pane>
              <el-tab-pane v-if="(canEnv('edit') || canEnv('deploy')) && tabEnabled('settings')" :label="canEnv('edit') ? '设置' : '设置(只读)'" name="settings" :disabled="!env" lazy><TabSettings v-if="env" :env="env" :project-id="projectId" :perms="perms" :has-production="data.has_production" @changed="load(true)" @kind="(k) => moveEnv(env, k)" /></el-tab-pane>
            </el-tabs>
            <el-dialog v-model="stg.open" :title="stg.mode === 'create' ? `创建测试环境 — ${stg.branch}` : `改为测试环境 — ${stg.branch}`" width="580px" @close="stgCancel">
              <p class="stg-lead">测试(预发)环境通常使用<strong>中和后的生产数据</strong>。请选择数据库来源,并决定是否中和:</p>
              <el-radio-group v-model="stg.choice" class="stg-opts">
                <el-radio value="clone" class="stg-opt">
                  <div class="stg-t">从生产克隆最新数据 <el-tag size="small" type="success" effect="plain">推荐</el-tag></div>
                  <div class="stg-d muted">{{ stg.mode === 'create' ? '新库 = 生产库快照(含 filestore)。' : '当前数据库与 filestore 将被生产快照覆盖;耗时取决于数据量。' }}</div>
                </el-radio>
                <el-radio :value="stg.mode === 'create' ? 'empty' : 'keep'" class="stg-opt">
                  <div class="stg-t">{{ stg.mode === 'create' ? '使用空库' : '保留当前数据库' }}</div>
                  <div class="stg-d muted">{{ stg.mode === 'create' ? '只安装 base,不含生产数据。' : '数据不变,只改档位并重建容器。' }}</div>
                </el-radio>
              </el-radio-group>
              <div class="neu-box" :class="{ off: stg.choice === 'empty' }">
                <el-checkbox v-model="stg.neutralize" :disabled="stg.choice === 'empty'" class="neu-cb">
                  <b>中和数据库</b>(Odoo 官方 neutralize)
                </el-checkbox>
                <div class="neu-d muted">停用定时任务、外发/收取邮件、支付服务商与第三方集成,并在 Odoo 界面顶部显示红色「中和数据库」横幅,避免测试库替生产发邮件、扣款。{{ stg.choice === 'empty' ? '空库没有生产数据,无需中和。' : '强烈建议保持勾选;只有明确需要在测试环境发真实邮件时才取消。' }}</div>
              </div>
              <template #footer>
                <el-button @click="stgCancel">取消</el-button>
                <el-button type="primary" @click="stgConfirm">{{ stg.mode === 'create' ? '创建' : '确认' }}</el-button>
              </template>
            </el-dialog>
            <el-dialog v-model="prod.open" :title="`升为生产环境 — ${prod.branch}`" width="560px" @close="prodCancel">
              <p class="stg-lead">升为生产后:过期改为<strong>永不</strong>、代码<strong>只读挂载</strong>、推送不再自动部署。请选择生产库如何来:</p>
              <el-radio-group v-model="prod.choice" class="stg-opts">
                <el-radio value="fresh" class="stg-opt">
                  <div class="stg-t">使用全新空数据库 <el-tag size="small" type="success" effect="plain">推荐</el-tag></div>
                  <div class="stg-d muted">丢弃当前的测试数据与 filestore,重新初始化一个只装 base 的干净库(通常几秒到 2 分钟);适合正式上线从零开始录入。</div>
                </el-radio>
                <el-radio value="keep" class="stg-opt">
                  <div class="stg-t">保留当前数据库</div>
                  <div class="stg-d muted">当前数据原样成为生产数据(测试期间录入的数据、配置都会带过去);只改档位并重建容器。</div>
                </el-radio>
              </el-radio-group>
              <div v-if="prod.choice === 'fresh'" class="prod-warn"><el-icon><WarningFilled /></el-icon>当前库将被删除且不可恢复;如需留底请先在「备份」Tab 做一次备份。请输入分支名 <code>{{ prod.branch }}</code> 确认:</div>
              <el-input v-if="prod.choice === 'fresh'" v-model="prod.typed" :placeholder="prod.branch" style="margin-top: 8px" />
              <template #footer>
                <el-button @click="prodCancel">取消</el-button>
                <el-button type="primary" :disabled="prod.choice === 'fresh' && prod.typed !== prod.branch" @click="prodConfirm">升为生产</el-button>
              </template>
            </el-dialog>
            <el-drawer v-model="depLogDlg" :title="`部署日志 — ${selected?.branch || ''}`" size="min(100vw, 720px)">
              <DeployLog v-if="depLogDlg && depLogDep && env" :env-id="env.id" :dep="depLogDep" @finished="load(true)" />
              <el-empty v-else-if="depLogDlg && !depLogDep" description="没有找到部署记录" />
            </el-drawer>
          </template>
        </section>
      </div>
    </template>
    <el-empty v-else-if="!loading" description="项目不存在或无权访问" />
    <DeleteEnvDialog ref="delDlg" @done="onDeleted" />
  </div>
</template>

<script setup>
import { computed, nextTick, onMounted, reactive, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox, ElNotification } from 'element-plus'
import { ArrowLeft, ArrowDown, Refresh, Setting, Search, Rank, Loading, WarningFilled, TopRight, VideoPlay, Promotion, RefreshRight, Sunny, Lock, Connection, Link } from '@element-plus/icons-vue'
import api from '../api'
import EmptyState from '../components/EmptyState.vue'
import DeleteEnvDialog from '../components/environment/DeleteEnvDialog.vue'
import { session, defaults, isSuper, loadDefaults, tabEnabled } from '../store'
import { usePolling } from '../composables/usePolling'
import { confirmDanger, confirmAction } from '../utils/confirm'
import TabHistory from '../components/project/TabHistory.vue'
import TabLogs from '../components/project/TabLogs.vue'
import TabMonitor from '../components/project/TabMonitor.vue'
import TabBackups from '../components/project/TabBackups.vue'
import TabUpgrade from '../components/project/TabUpgrade.vue'
import TabShell from '../components/project/TabShell.vue'
import TabDatabases from '../components/environment/TabDatabases.vue'
import TabSettings from '../components/project/TabSettings.vue'
import DeployLog from '../components/environment/DeployLog.vue'
import TabCustomCode from '../components/project/TabCustomCode.vue'
import { KINDS, kindLabel, kindType, statusLabel, statusTone, opLabel, opDoneLabel, BUSY, isBusy, expireText, expireSoon, actionLabel } from '../utils/labels'
import { ago, within } from '../utils/format'
import { openEnv, canOpenNow } from '../utils/openEnv'

const route = useRoute(); const router = useRouter()
const projectId = computed(() => Number(route.params.id))
const data = ref(null); const loading = ref(false); const syncing = ref(false)
const selectedKey = ref(null); const tab = ref('history'); const branchKw = ref('')
loadDefaults()
const repo = computed(() => data.value?.repo || {})
// 无仓库实例:单实例视图(无分支栏 / 历史,只有定制代码/日志/监控/备份/数据库/Shell/设置)
const noGit = computed(() => !!data.value && !repo.value.url)
// 精简头部:无 Git 实例的详情一律单行(超管也用)——去掉顶栏行、返回按钮并入标题行、隐藏地址/版本/过期信息行。
// 功能性的隐藏(如「更多」里的改档位)不看 slim,单独按超管判断
const slim = computed(() => noGit.value)
const perms = computed(() => data.value?.permissions || {})
const tenantName = computed(() => session.me?.memberships?.find((m) => m.tenant_id === repo.value.tenant_id)?.tenant_name || `组织 #${repo.value.tenant_id}`)
const busy = (e) => isBusy(e)
const canCreateKind = (k) => !!perms.value[k]?.create && !(k === 'production' && data.value?.has_production)
const canEnv = (action) => !!(env.value && perms.value[env.value.kind]?.[action])
// 删除 / 名单 / 转让:只有拥有者(创建者)或超管;「可管理」成员不行
const isOwnerOf = (e) => !!e && (session.me?.is_superadmin || (e.owner_user_id != null && e.owner_user_id === session.me?.id))
// tab 的可见性 / 权限兜底统一由下方 visibleTabs 处理(当前 tab 不可见 → 落到第一个可见 tab),不再写死回退 history
// 是否有“管理级”动作(建环境 / 改档 / 删除):决定左栏是否可拖拽、是否显示建环境按钮
const canManage = computed(() => KINDS.some((k) => perms.value[k]?.create || perms.value[k]?.delete))
const hasMoreActions = computed(() => canEnv('start') || canEnv('stop') || canEnv('restore') || (canEnv('delete') && isOwnerOf(env.value)) || (env.value?.edition === 'enterprise' && !!env.value?.db_name) || ((!noGit.value || isSuper.value) && KINDS.some((k) => env.value && k !== env.value.kind && canMoveEnv(env.value, k))))
const roleLabel = computed(() => ({ owner: '可管理', operator: '可操作', viewer: '可访问', developer: '开发者', tester: '测试者' })[data.value?.role] || data.value?.role || '')
// Shell Tab:用户级开关(超管在「用户」里开启;超管恒有)× 角色矩阵;未开启的用户看不到这个 Tab
const shellVisible = computed(() => !!(session.me?.is_superadmin || session.me?.shell_enabled))
const pendingDeploy = (e) => e.container_name && e.code_commit && itemOf(e)?.head?.sha && itemOf(e).head.sha !== e.code_commit

// ---- 左栏数据 ----
const items = computed(() => {
  if (!data.value) return []
  const out = data.value.environments.map((e) => ({ key: `env:${e.id}`, branch: e.branch || e.name, env: e, head: e.head, kind: e.kind }))
  const un = [...data.value.unassigned].sort((a, b) => new Date(b.committed_at || b.head?.committed_at || 0) - new Date(a.committed_at || a.head?.committed_at || 0))
  for (const b of un) out.push({ key: `br:${b.name}`, branch: b.name, env: null, head: b, kind: 'unassigned', is_default: b.is_default })
  return out
})
const itemOf = (e) => items.value.find((i) => i.env?.id === e.id)
const groups = computed(() => {
  const kw = branchKw.value.trim().toLowerCase()
  return [
    { kind: 'production', label: '生产', items: items.value.filter((i) => i.kind === 'production') },
    { kind: 'staging', label: '测试', items: items.value.filter((i) => i.kind === 'staging') },
    { kind: 'dev', label: '开发', items: items.value.filter((i) => i.kind === 'dev') },
    { kind: 'unassigned', label: '未分配', items: items.value.filter((i) => i.kind === 'unassigned' && (!kw || i.branch.toLowerCase().includes(kw))) },
  ]
})
const selected = computed(() => items.value.find((i) => i.key === selectedKey.value) || null)
const env = computed(() => selected.value?.env || null)

// 当前可见的 tab(顺序与模板一致);tab 落在不可见的页会导致主区空白,故在此兜底自动落到第一个可见 tab
const visibleTabs = computed(() => {
  if (!env.value) return []
  return [
    ['custom', noGit.value && canEnv('deploy')],
    ['history', !noGit.value],
    ['logs', canEnv('logs')],
    ['monitor', canEnv('stats')],
    ['backups', canEnv('backup') || canEnv('restore')],
    ['databases', canEnv('open') && tabEnabled('databases')],
    ['upgrade', canEnv('deploy') && tabEnabled('upgrade')],
    ['shell', shellVisible.value && canEnv('shell')],
    ['settings', (canEnv('edit') || canEnv('deploy')) && tabEnabled('settings')],
  ].filter(([, ok]) => ok).map(([k]) => k)
})
watch([visibleTabs, tab], () => { const tabs = visibleTabs.value; if (tabs.length && !tabs.includes(tab.value)) tab.value = tabs[0] }, { immediate: true })

function select(it) {
  selectedKey.value = it.key
  router.replace({ query: { ...route.query, branch: it.branch } })
  if (!it.env && tab.value !== 'history') tab.value = 'history'
}
function autoSelect() {
  if (selectedKey.value && items.value.some((i) => i.key === selectedKey.value)) return
  const want = route.query.branch
  const byBranch = want && items.value.find((i) => i.branch === want)
  const first = byBranch || items.value.find((i) => i.env?.id === data.value?.root_id) || items.value.find((i) => i.kind === 'production') || items.value.find((i) => i.env) || items.value[0]
  if (first) selectedKey.value = first.key
}

// ---- 加载 / 轮询 ----
const prev = new Map()
let loadSeq = 0 // 见 Environments.vue:并发/乱序返回的陈旧列表会把 prev 退回忙碌态,导致完成提示重复弹
async function load(silent = false, refresh = false) {
  if (!silent) loading.value = true
  if (refresh) syncing.value = true
  const mySeq = ++loadSeq
  try {
    const d = await api.get(`/projects/${projectId.value}`, { params: refresh ? { refresh: true } : {} })
    if (mySeq !== loadSeq) return  // 丢弃陈旧响应
    notify(d.environments)
    data.value = d
    autoSelect()
  } catch { if (!data.value) data.value = null } finally { if (mySeq === loadSeq) { loading.value = false; syncing.value = false } }
}
function notify(list) {
  const seen = new Set()
  for (const e of list) {
    seen.add(e.id)
    const p = prev.get(e.id)
    if (p && BUSY.includes(p.status) && !BUSY.includes(e.status)) {
      const done = opDoneLabel(p.status)
      if (e.status === 'failed') ElNotification.error({ title: `「${e.branch || e.name}」${done}失败`, message: e.status_message || '请查看日志', duration: 8000 })
      else ElNotification.success({ title: `「${e.branch || e.name}」${done}完成`, message: e.url ? `访问 ${e.url}` : '', duration: 5000 })
    }
    prev.set(e.id, { status: e.status, name: e.branch || e.name })
  }
  for (const [id, p] of prev) if (!seen.has(id)) { if (p.status === 'destroying') ElNotification.success({ title: `环境「${p.name}」已删除`, duration: 4000 }); prev.delete(id) }
}
const poll = usePolling(() => load(true), { intervalFn: () => ((data.value?.environments || []).some(busy) ? 2500 : 8000), immediate: false })
watch(projectId, () => { data.value = null; selectedKey.value = null; load() })
onMounted(() => { load(); poll.start() })

// ---- 最近一次部署日志(失败时头部「查看日志」) ----
const depLogDlg = ref(false); const depLogDep = ref(null)
async function openLastDeployLog() {
  const e = env.value; if (!e) return
  depLogDep.value = null; depLogDlg.value = true
  try { const list = await api.get(`/environments/${e.id}/deployments`, { params: { limit: 1 } }); depLogDep.value = list?.[0] || null } catch {}
}

// ---- 拖拽 ----
const drag = ref(null); const dragOver = ref(null)
function onDragStart(ev, it) {
  if (it.env && busy(it.env)) { ev.preventDefault(); return }
  drag.value = it
  ev.dataTransfer.effectAllowed = 'move'
  try { ev.dataTransfer.setData('text/plain', it.key) } catch {}
  try {
    // 自定义拖影:一张紧凑的“分支票”,比默认整行半透明截图清晰
    const ghost = document.createElement('div')
    ghost.className = 'drag-ghost'
    ghost.textContent = it.branch || it.env?.name || ''
    document.body.appendChild(ghost)
    ev.dataTransfer.setDragImage(ghost, 14, 16)
    setTimeout(() => ghost.remove(), 0)
  } catch {}
}
let dragDepth = 0
function onDragEnd() { drag.value = null; dragOver.value = null; dragDepth = 0 }
function onDragEnter(ev, kind) { if (!drag.value || !canDrop(kind)) return; ev.preventDefault(); if (dragOver.value !== kind) { dragOver.value = kind; dragDepth = 0 } dragDepth++ }
function onDragLeave(ev, kind) { if (dragOver.value !== kind) return; dragDepth--; if (dragDepth <= 0) { dragOver.value = null; dragDepth = 0 } }
function onDragOver(ev, kind) { if (drag.value && canDrop(kind)) { ev.preventDefault(); ev.dataTransfer.dropEffect = 'move'; if (dragOver.value !== kind) { dragOver.value = kind; dragDepth = 1 } } }
async function onDrop(ev, kind) {
  ev.preventDefault()
  const it = drag.value; onDragEnd()
  if (!it || !canDrop(kind, it)) return
  if (!it.env) { if (kind !== 'unassigned') await createEnv(it.branch, kind); return }
  if (kind === 'unassigned') await deleteEnv(it.env)
  else await moveEnv(it.env, kind)
}
function canDrop(kind, it = drag.value) {
  if (!it || it.kind === kind) return false
  if (!it.env) return kind !== 'unassigned' && canCreateKind(kind)
  if (kind === 'unassigned') return !!perms.value[it.env.kind]?.delete && isOwnerOf(it.env) && it.env.id !== data.value?.root_id && it.env.kind !== 'production'
  return canMoveEnv(it.env, kind)
}
function canMoveEnv(e, kind) {
  if (busy(e) || kind === e.kind) return false
  if (!perms.value[kind]?.create) return false
  if (e.kind === 'production' && !perms.value.production?.delete) return false
  if (kind === 'production' && data.value.environments.some((x) => x.kind === 'production' && x.id !== e.id)) return false
  return true
}
function moveNote(e, kind) {
  if (kind === 'production' && data.value.environments.some((x) => x.kind === 'production' && x.id !== e.id)) return '(已有生产,先拖走)'
  if (e.kind === 'dev' && kind === 'staging' && data.value.has_production && e.container_name) return '(库从生产重建)'
  if (e.kind === 'production') return '(需确认)'
  return ''
}
function dropHint(kind) {
  const it = drag.value
  if (!it) return ''
  if (!it.env) return kind === 'staging' && data.value.has_production ? '创建,库从生产克隆' : kind === 'production' ? '创建生产(永不过期)' : '创建开发环境'
  if (kind === 'unassigned') return '删除环境'
  return `改为${kindLabel(kind)}` + moveNote(it.env, kind)
}

// ---- 动作 ----
// ---- 拖到「测试(预发)」时的数据库选择弹窗 ----
const stg = reactive({ open: false, mode: 'move', branch: '', choice: 'clone', neutralize: true, resolve: null })
const prod = reactive({ open: false, branch: '', choice: 'fresh', typed: '', resolve: null })
function askProd(branch) { return new Promise((resolve) => { Object.assign(prod, { open: true, branch, choice: 'fresh', typed: '', resolve }) }) }
function prodConfirm() { const r = prod.resolve; prod.resolve = null; prod.open = false; r && r({ fresh: prod.choice === 'fresh' }) }
function prodCancel() { const r = prod.resolve; prod.resolve = null; prod.open = false; r && r(null) }
function askStaging(mode, branch) {
  return new Promise((resolve) => { Object.assign(stg, { open: true, mode, branch, choice: 'clone', neutralize: true, resolve }) })
}
function stgConfirm() { const r = stg.resolve; stg.resolve = null; stg.open = false; r && r({ choice: stg.choice, neutralize: stg.neutralize }) }
function stgCancel() { const r = stg.resolve; stg.resolve = null; stg.open = false; r && r(null) }

async function createEnv(branch, kind) {
  let clone_db = null; let neutralize = true
  if (kind === 'staging' && data.value.has_production) {
    const r = await askStaging('create', branch)
    if (!r) return
    clone_db = r.choice === 'clone'
    neutralize = r.neutralize
  } else {
    const tips = {
      dev: `以分支「${branch}」创建开发环境:空库、检出最新提交、套用默认过期。`,
      staging: `以分支「${branch}」创建测试环境(尚无生产环境,使用空库)。`,
      production: `以分支「${branch}」创建生产环境:空库、永不过期、代码只读挂载。`,
    }
    try { await ElMessageBox.confirm(tips[kind], `创建${kindLabel(kind)}环境`, { confirmButtonText: '创建', type: 'info' }) } catch { return }
  }
  try {
    const e = await api.post(`/projects/${projectId.value}/environments`, { branch, kind, clone_db, neutralize })
    ElNotification.info({ title: `开始创建「${branch}」的${kindLabel(kind)}环境`, message: '完成后会提示;可在「历史」/「日志」查看进度。', duration: 5000 })
    await load(true)
    selectedKey.value = `env:${e.id}`
  } catch {}
}
async function moveEnv(e, kind) {
  let confirm = null
  if (e.kind === 'production') {
    if (!(await confirmDanger({ title: '生产环境降级', message: `把生产环境「${e.branch}」降为${kindLabel(kind)}:库保留、代码改为可写挂载、之后可把别的分支拖进生产。`, requireText: e.branch, inputLabel: `请输入分支名「${e.branch}」以确认:`, confirmText: '确认' }))) return
    confirm = e.branch
  } else if (kind === 'staging' && data.value.has_production && e.container_name) {
    const r = await askStaging('move', e.branch)
    if (!r) return
    try { await api.post(`/projects/${projectId.value}/environments/${e.id}/kind`, { kind, confirm, clone_db: r.choice === 'clone', neutralize: r.neutralize }); ElMessage.success('开始变更,完成后会提示'); await load(true) } catch {}
    return
  } else if (kind === 'production' && e.container_name && e.db_name) {
    const r = await askProd(e.branch)
    if (!r) return
    try { await api.post(`/projects/${projectId.value}/environments/${e.id}/kind`, { kind, confirm, fresh_db: r.fresh }); ElMessage.success(r.fresh ? '开始升级:换全新库并重建容器,完成后会提示' : '开始变更,完成后会提示'); await load(true) } catch {}
    return
  } else {
    const msg = { staging: '改为测试环境:档位变更,容器重建。',
      production: '升为生产环境:过期改为永不、代码只读挂载,容器重建。',
      dev: '改为开发环境:档位下降,套用开发默认过期,容器重建。' }[kind]
    try { await ElMessageBox.confirm(msg, `改为${kindLabel(kind)}环境`, { confirmButtonText: '确认', type: kind === 'production' ? 'warning' : 'info' }) } catch { return }
  }
  try { await api.post(`/projects/${projectId.value}/environments/${e.id}/kind`, { kind, confirm }); ElMessage.success('开始变更,完成后会提示'); await load(true) } catch {}
}
const delDlg = ref(null)
async function deleteEnv(e) {
  if (e.id === data.value?.root_id) { ElMessage.warning('这是项目的根实例:要删除整个项目请到「实例」列表操作'); return }
  if (e.kind === 'production') { ElMessage.warning('生产分支的数据库不能在这里直接删除:请先把它拖到测试 / 开发降级,或到「实例」列表移入回收站'); return }
  delDlg.value?.open(e, { branch: true })
}
function onDeleted(e) {
  if (e.id === data.value?.root_id) { router.push('/environments'); return }
  if (selectedKey.value === `env:${e.id}`) selectedKey.value = null
  load(true)
}
async function act(action) {
  const e = env.value
  if (!e) return
  if (e.kind === 'production' && action === 'stop') {
    if (!(await confirmDanger({ title: '停止生产环境', message: '停止后该生产环境的用户将无法访问。', requireText: e.branch, inputLabel: `请输入分支名「${e.branch}」以确认:`, confirmText: '停止' }))) return
  }
  try { await api.post(`/environments/${e.id}/${action}`); ElMessage.success({ provision: '开始创建,完成后会提示', start: '启动中', stop: '停止中', restart: '重启中,约 15~30 秒', wake: '唤醒中,约 10~30 秒', sleep: '正在休眠;访问域名会自动唤醒' }[action]); load(true) } catch {}
}
async function deployLatest() {
  const e = env.value
  if (!(await confirmAction({ title: '部署最新', message: `部署分支「${e.branch}」最新提交,动作:${actionLabel(e.deploy_action || 'update_all', e.deploy_modules)}(可在「设置」修改)。「升级变更模块」同时会升级定制代码目录里改过且已安装的模块;新写的模块请先在 Odoo「应用」里安装。失败会自动回退。`, confirmText: '开始部署' }))) return
  try { await api.post(`/environments/${e.id}/deploy`, {}); ElMessage.success('开始部署,完成后会提示'); load(true) } catch {}
}
async function refreshFromProd() {
  const e = env.value
  try { await ElMessageBox.confirm(`用生产环境的数据覆盖「${e.branch}」的数据库与 filestore,并中性化;期间该环境短暂停机。`, '从生产刷新数据', { type: 'warning', confirmButtonText: '刷新' }) } catch { return }
  try { await api.post(`/projects/${projectId.value}/environments/${e.id}/refresh-from-production`); ElMessage.success('开始刷新,完成后会提示'); load(true) } catch {}
}
function onMore(cmd) {
  if (cmd.startsWith('kind:')) return moveEnv(env.value, cmd.slice(5))
  if (cmd === 'delete') return deleteEnv(env.value)
  if (cmd === 'refresh') return refreshFromProd()
  if (cmd === 'license') return openLicense()
  return act(cmd)
}
// 企业版到期:切到「数据库」Tab 并直接打开主库的续期弹窗(Tab 是 lazy 的,等它挂载好再调)
const dbTab = ref(null)
async function openLicense() {
  tab.value = 'databases'
  await nextTick()
  for (let i = 0; i < 20 && !dbTab.value?.openLicensePrimary; i++) await new Promise((r) => setTimeout(r, 50))
  dbTab.value?.openLicensePrimary?.()
}
// 「打开」= 一键登录:先开空白窗口(避免被拦截),再向平台要一次性登录地址,跳过 Odoo 登录页直达首页
async function openUrl(e) { await openEnv(e, { onStatus: () => load(true) }) }
// 数据库 Tab 里「在 Shell 中打开」某个附加库:切到 Shell Tab 并把目标库传过去
const shellDbId = ref(null)
function onShellDb(row) { shellDbId.value = row?.id || null; tab.value = 'shell' }
</script>

<style scoped>
.project { padding: 14px 24px 24px; display: flex; flex-direction: column; min-height: calc(100vh - var(--header-h)); box-sizing: border-box; }
/* 顶栏:单行 */
.topbar { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 12px; min-height: 40px; }
.tb-left { display: flex; align-items: center; gap: 10px; min-width: 0; flex: 1; }
.back-btn { width: 32px; height: 32px; border-radius: 8px; border: 1px solid var(--line); background: #fff; color: var(--text-2); display: inline-flex; align-items: center; justify-content: center; cursor: pointer; flex: none; font-size: 15px; }
.back-btn:hover { border-color: #cfd5de; color: var(--text); background: var(--surface-2); }
.repo-title { display: flex; align-items: center; gap: 12px; min-width: 0; }
.repo-name { font-size: 18px; font-weight: 750; color: var(--text); letter-spacing: -.01em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 40vw; }
.repo-meta { display: inline-flex; align-items: center; gap: 8px; min-width: 0; }
.repo-url { display: inline-flex; align-items: center; gap: 4px; font-size: 12.5px; color: var(--text-3); text-decoration: none; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 32vw; }
.repo-url:hover { color: var(--brand); }
.tenant-tag { font-size: 12px; color: var(--text-2); background: var(--surface-2); border: 1px solid var(--line-2); border-radius: 999px; padding: 2px 9px; white-space: nowrap; }
.tb-right { display: flex; gap: 8px; }
.tb-acts .el-button { padding: 8px 11px; }
.tb-acts .el-button + .el-button { margin-left: -1px; }
.mirror-err { margin-bottom: 12px; }
.body { display: grid; grid-template-columns: 280px minmax(0, 1fr); gap: 16px; flex: 1; align-items: start; }
.body.no-aside { grid-template-columns: 1fr; }

/* ---------- 左栏:分支分组 ---------- */
.branches { background: var(--surface); border: 1px solid var(--line); border-radius: var(--radius-lg); padding: 10px; position: sticky; top: 12px; }
.group { border-radius: 12px; padding: 8px; margin-bottom: 8px; border: 1px solid var(--g-line); background: var(--g-bg); transition: background .15s, border-color .15s, box-shadow .15s, transform .15s; }
.g-production { --g-bg: #fff7f7; --g-line: #fecaca; --g-c: #b91c1c; --g-ac: #ef4444; }
.g-staging { --g-bg: #fffbeb; --g-line: #fde68a; --g-c: #b45309; --g-ac: #f59e0b; }
.g-dev { --g-bg: #f3f7ff; --g-line: #bfdbfe; --g-c: #1d4ed8; --g-ac: #3b82f6; }
.g-unassigned { --g-bg: #f7f8fa; --g-line: #e2e6ec; --g-c: #475569; --g-ac: #94a3b8; }
.g-head { display: flex; align-items: center; gap: 8px; padding: 2px 4px 8px; font-size: 12.5px; font-weight: 750; color: var(--g-c); letter-spacing: .04em; }
.g-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--g-ac); box-shadow: 0 0 0 3px color-mix(in srgb, var(--g-ac) 18%, transparent); }
.g-count { font-weight: 700; color: var(--g-c); background: #fff; border: 1px solid var(--g-line); border-radius: 999px; padding: 0 7px; font-size: 11px; line-height: 17px; }
.g-hint { font-size: 11.5px; color: var(--brand); font-weight: 600; }
.g-search { margin: 0 2px 8px; }
.g-empty { font-size: 12px; color: var(--text-3); padding: 10px 10px 12px; border: 1px dashed var(--g-line); border-radius: 9px; background: rgba(255,255,255,.5); text-align: center; }
.spacer { flex: 1; }
/* 分支条目:每一条都有清晰边框(含未分配),左侧一条同色竖线 */
.item { position: relative; display: flex; align-items: center; gap: 8px; padding: 8px 10px 8px 12px; border-radius: 9px; cursor: pointer; font-size: 13.5px; color: var(--text); user-select: none; background: #fff; margin-bottom: 6px; border: 1px solid var(--line); box-shadow: 0 1px 1px rgba(20,28,42,.03); transition: border-color .12s, box-shadow .12s, transform .12s, opacity .12s; }
.item::before { content: ''; position: absolute; left: 0; top: 7px; bottom: 7px; width: 3px; border-radius: 0 3px 3px 0; background: var(--g-ac); opacity: .85; }
.item.k-none::before { background: #cbd5e1; }
.item:last-child { margin-bottom: 0; }
.item .b-name { font-weight: 600; }
.item:hover { border-color: var(--g-ac); box-shadow: 0 2px 8px -2px color-mix(in srgb, var(--g-ac) 35%, transparent); }
.item.active { border-color: var(--brand); box-shadow: 0 0 0 2px var(--brand-100), 0 2px 8px -2px rgba(113,75,103,.3); color: var(--brand-600); }
.item.active::before { background: var(--brand); }
.item.active .b-name { font-weight: 700; }
.item[draggable="true"] { cursor: grab; }
.item[draggable="true"]:active { cursor: grabbing; }
.item.dragging { opacity: .35; transform: scale(.98); border-style: dashed; }
.b-name { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.b-env { font-size: 11px; color: var(--text-3); font-weight: 400; }
.b-time { font-size: 11px; color: var(--text-3); font-weight: 400; white-space: nowrap; }
.b-badge { font-size: 10.5px; padding: 1px 6px; border-radius: 999px; font-weight: 600; }
.b-badge.warn { background: var(--warn-bg); color: var(--warn); }
.b-badge.busy { background: var(--info-bg); color: var(--info); font-variant-numeric: tabular-nums; }
.b-badge.new { background: var(--ok-bg); color: var(--ok); }
.b-badge.db { background: #f1f5f9; color: #475569; }
.h-dbs { color: var(--brand); text-decoration: none; }
.h-dbs:hover { text-decoration: underline; }
.tab-cnt { display: inline-block; min-width: 16px; padding: 0 5px; margin-left: 4px; border-radius: 999px; font-size: 10.5px; line-height: 16px; background: #f1f5f9; color: #475569; text-align: center; }
.def { transform: scale(.85); }
.st { width: 9px; height: 9px; border-radius: 50%; background: #cbd5e1; flex: none; box-sizing: border-box; }
.st.running { background: var(--ok); box-shadow: 0 0 0 3px rgba(22,163,74,.15); }
.st.stopped { background: transparent; border: 2px solid #94a3b8; }
.st.sleeping { background: var(--sleep); }
.st.failed { background: var(--danger); }
.st.deleted { background: #f87171; }
.st.none { background: transparent; border: 1.5px dashed #cbd5e1; }
.st.creating { background: linear-gradient(90deg, #10b981 50%, transparent 50%); border: 1.5px solid #10b981; animation: spin 1s linear infinite; }
.st.busy { background: linear-gradient(90deg, var(--warn) 50%, transparent 50%); border: 1.5px solid var(--warn); animation: spin 1s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
/* 拖拽中的分组反馈:可放 = 品牌色虚线;悬停 = 高亮 + 轻微放大;不可放 = 变淡 */
.branches.dragging .group.drop-ok { border-style: dashed; border-color: var(--brand); }
.branches.dragging .group.drop-over { background: var(--brand-50); border-style: solid; box-shadow: 0 0 0 3px var(--brand-100), 0 8px 20px -10px rgba(113,75,103,.5); transform: scale(1.015); }
.branches.dragging .group.drop-over .g-empty { border-color: var(--brand); color: var(--brand); background: #fff; }
.branches.dragging .group.drop-no { opacity: .45; filter: saturate(.6); }
.branches.dragging .item:not(.dragging) { pointer-events: none; }
.drag-tip { font-size: 11.5px; padding: 8px 8px 2px; display: flex; gap: 6px; align-items: flex-start; line-height: 1.4; }

/* ---------- 右栏 ---------- */
.main { background: var(--surface); border: 1px solid var(--line); border-radius: var(--radius-lg); min-height: 520px; display: flex; flex-direction: column; overflow: hidden; }
.empty-main { flex: 1; display: flex; align-items: center; justify-content: center; }
/* 头部:按档位着色的淡色带 */
.head { display: flex; justify-content: space-between; gap: 16px; padding: 18px 22px 16px; flex-wrap: wrap; background: linear-gradient(180deg, var(--h-bg, var(--surface-2)), #fff); border-bottom: 1px solid var(--line-2); }
.head.k-production { --h-bg: #fff5f5; }
.head.k-staging { --h-bg: #fffaeb; }
.head.k-dev { --h-bg: #f2f6ff; }
.head-l { min-width: 0; flex: 1; }
.head-r { display: flex; gap: 8px; align-items: flex-start; flex-wrap: wrap; }
.head-r .el-button { box-shadow: 0 1px 2px rgba(20,28,42,.06); }
.h-title { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.h-branch { font-size: 19px; font-weight: 800; letter-spacing: -.01em; display: inline-flex; align-items: center; gap: 8px; }
.h-branch::before { content: ''; width: 4px; height: 18px; border-radius: 3px; background: var(--brand); }
.h-sub { margin-top: 8px; font-size: 12.5px; color: var(--text-2); display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.h-url { color: var(--brand); font-weight: 600; text-decoration: none; }
.h-url:hover { text-decoration: underline; }
.dot-sep { color: var(--text-3); }
.warn-text { color: var(--warn); font-weight: 600; }
.h-progress { margin-top: 10px; display: flex; align-items: center; gap: 8px; font-size: 12.5px; color: var(--text-2); background: #fff; border: 1px solid var(--line-2); border-radius: 8px; padding: 6px 10px; }
.h-progress.fail { color: var(--danger); background: var(--danger-bg); border-color: transparent; }
.kind-tag { border: none; }
/* 页签:柔和渐变带 + 胶囊式选中态 */
.tabs { padding: 0 22px 22px; }
.tabs :deep(.el-tabs__header) { margin: 0 -22px 18px; padding: 8px 16px 0; background: linear-gradient(90deg, #f6f3f7 0%, #f3f6fb 55%, #f2f8f6 100%); border-bottom: 1px solid var(--line); }
.tabs :deep(.el-tabs__nav-wrap::after) { display: none; }
.tabs :deep(.el-tabs__item) { font-weight: 600; color: var(--text-2); height: 40px; padding: 0 16px; border-radius: 9px 9px 0 0; transition: background .15s, color .15s; }
.tabs :deep(.el-tabs__item:hover) { color: var(--text); background: rgba(255,255,255,.6); }
.tabs :deep(.el-tabs__item.is-active) { font-weight: 750; color: var(--brand-600); background: #fff; box-shadow: 0 -1px 0 var(--line) inset, 0 -6px 14px -10px rgba(20,28,42,.25); }
.tabs :deep(.el-tabs__active-bar) { height: 3px; border-radius: 3px 3px 0 0; background: linear-gradient(90deg, var(--brand), #a24689); }
.status-pill.clickable { cursor: pointer; }
.status-pill.clickable:hover { box-shadow: 0 0 0 2px #a7f3d0; }
.h-fail-msg { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.mono { font-family: ui-monospace, Menlo, Consolas, monospace; }
.stg-lead { margin: 0 0 12px; line-height: 1.7; color: var(--text-2); font-size: 13.5px; }
.stg-opts { display: flex; flex-direction: column; gap: 10px; width: 100%; }
.stg-opt { align-items: flex-start; height: auto; padding: 12px 14px; border: 1px solid var(--line); border-radius: 10px; margin: 0; width: 100%; white-space: normal; }
.stg-opt.is-checked { border-color: var(--brand); background: var(--brand-50); }
.stg-opt :deep(.el-radio__label) { padding-left: 10px; }
.stg-t { font-weight: 700; display: flex; gap: 8px; align-items: center; }
.stg-d { font-size: 12.5px; margin-top: 3px; line-height: 1.5; }
.stg-cb { margin-top: 8px; display: block; }
.neu-box { margin-top: 12px; padding: 10px 12px; border-radius: 10px; background: #fff7f7; border: 1px solid #fecaca; }
.neu-box.off { background: var(--surface-2); border-color: var(--line-2); }
.neu-cb { align-items: flex-start; }
.neu-cb :deep(.el-checkbox__label) { color: #991b1b; }
.neu-box.off .neu-cb :deep(.el-checkbox__label) { color: var(--text-3); }
.neu-d { font-size: 12px; margin: 4px 0 0 24px; line-height: 1.55; }
.prod-warn { margin-top: 12px; font-size: 12.5px; color: var(--danger); background: var(--danger-bg); border-radius: 8px; padding: 8px 10px; display: flex; gap: 6px; align-items: flex-start; line-height: 1.5; }
@media (max-width: 900px) {
  .project { padding: 12px; }
  .body { grid-template-columns: 1fr; }
  .branches { position: static; }
  .repo-name { max-width: 60vw; }
  .repo-url { display: none; }
}
</style>
<style>
/* 拖影(挂在 body 上,不能 scoped) */
.drag-ghost { position: fixed; top: -1000px; left: -1000px; padding: 7px 12px 7px 14px; border-radius: 9px; background: #fff; border: 1px solid var(--brand); box-shadow: 0 8px 20px -6px rgba(113,75,103,.45); font-size: 13px; font-weight: 700; color: var(--brand-600); white-space: nowrap; }
.drag-ghost::before { content: ''; position: absolute; left: 0; top: 6px; bottom: 6px; width: 3px; border-radius: 0 3px 3px 0; background: var(--brand); }
</style>
