<template>
  <div class="page">
    <div class="page-header">
      <div>
        <h2>组织与成员</h2>
        <div class="desc">共 {{ rows.length }} 家组织 · 启用 {{ rows.filter((r) => r.is_active).length }}</div>
      </div>
      <PageTools>
        <el-input v-model="q" placeholder="搜索名称 / 标识" clearable :prefix-icon="Search" class="search" />
        <el-button :icon="Refresh" @click="load">刷新</el-button>
        <el-button type="primary" :icon="Plus" @click="openCreate">新建组织</el-button>
      </PageTools>
    </div>
    <el-card shadow="never">
      <el-table :data="filtered" v-loading="loading" stripe>
        <el-table-column label="组织" min-width="220">
          <template #default="{ row }">
            <div class="row-name">
              <span class="badge" :class="{ off: !row.is_active }">{{ row.name.slice(0, 1) }}</span>
              <div class="names"><div class="n">{{ row.name }}</div><div class="s muted mono">{{ row.slug }} · #{{ row.id }}</div></div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="description" label="说明" min-width="200" show-overflow-tooltip><template #default="{ row }"><span v-if="row.description">{{ row.description }}</span><span v-else class="muted">—</span></template></el-table-column>
        <el-table-column label="状态" width="90">
          <template #default="{ row }"><el-tag :type="row.is_active ? 'success' : 'info'" size="small" effect="plain">{{ row.is_active ? '启用' : '停用' }}</el-tag></template>
        </el-table-column>
        <el-table-column label="创建时间" width="160"><template #default="{ row }"><span class="muted">{{ fmtDate(row.created_at) }}</span></template></el-table-column>
        <el-table-column label="操作" :width="isMobile ? 64 : 200" fixed="right" align="right">
          <template #default="{ row }">
            <div v-if="!isMobile">
              <el-button link type="primary" @click="openMembers(row)">成员</el-button>
              <el-button link @click="openEdit(row)">编辑</el-button>
              <el-button link type="danger" @click="remove(row)">删除</el-button>
            </div>
            <el-dropdown v-else trigger="click" @command="(c) => ({ members: openMembers, edit: openEdit, remove })[c]?.(row)">
              <el-button circle size="small"><el-icon><MoreFilled /></el-icon></el-button>
              <template #dropdown><el-dropdown-menu><el-dropdown-item command="members">成员</el-dropdown-item><el-dropdown-item command="edit">编辑</el-dropdown-item><el-dropdown-item command="remove" divided><span style="color: var(--danger)">删除</span></el-dropdown-item></el-dropdown-menu></template>
            </el-dropdown>
          </template>
        </el-table-column>
        <template #empty><EmptyState :variant="q ? 'search' : 'generic'" :title="q ? '没有匹配的组织' : '还没有组织'" :desc="q ? '换个关键词试试' : '点击右上角「新建组织」创建第一家组织'" :width="130" /></template>
      </el-table>
    </el-card>

    <el-drawer v-model="memberDlg" :title="`成员 — ${memberTenant?.name || ''}`" size="720px">
      <Members v-if="memberDlg" :tenant-id="memberTenant?.id" embedded />
    </el-drawer>

    <el-dialog v-model="dlg" :title="form.id ? '编辑组织' : '新建组织'" width="480px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="标识" required>
          <el-input v-model="form.slug" :disabled="!!form.id" placeholder="小写字母/数字/-,用于容器命名,如 acme"
                    @input="form.slug = normSlug($event)" />
          <div v-if="!form.id" class="muted" style="font-size: 12px; line-height: 1.5; margin-top: 2px">
            <span v-if="slugHint" style="color: var(--el-color-warning)">{{ slugHint }}</span>
            <span v-else-if="form.slug">将用于命名容器 odoo-{{ form.slug }}-&lt;实例&gt; 与访问地址 &lt;实例&gt;.{{ form.slug }}.&lt;基础域名&gt;</span>
            <span v-else>只能用小写字母、数字和中划线;大写、空格、下划线会自动转换,中文请用拼音,如 acme</span>
          </div>
        </el-form-item>
        <el-form-item label="名称" required><el-input v-model="form.name" /></el-form-item>
        <el-form-item label="说明"><el-input v-model="form.description" type="textarea" :rows="2" /></el-form-item>
        <el-form-item label="启用" v-if="form.id"><el-switch v-model="form.is_active" /></el-form-item>
        <template v-if="form.id">
          <el-form-item label="休眠时长">
            <el-input-number v-model="form.sleep_idle_hours" :min="0" :max="8760" :step="1" :precision="1" controls-position="right" placeholder="平台默认" style="width: 180px" />
            <span class="muted" style="margin-left: 8px; font-size: 12px">开发实例闲置多少小时自动休眠;留空 = 平台默认{{ defaults.sleep_idle_hours != null ? `(${defaults.sleep_idle_hours}h)` : '' }};0 = 不休眠</span>
          </el-form-item>
          <el-divider content-position="left"><span class="muted" style="font-size: 12px">附加数据库配额(社区版实例;留空 = 平台默认 / 不限)</span></el-divider>
          <el-form-item label="每实例上限"><el-input-number v-model="form.max_dbs_per_env" :min="0" :max="100" controls-position="right" placeholder="平台默认" style="width: 180px" /><span class="muted" style="margin-left: 8px; font-size: 12px">每个实例最多几个附加库</span></el-form-item>
          <el-form-item label="组织总量"><el-input-number v-model="form.max_dbs_total" :min="0" :max="10000" controls-position="right" placeholder="不限" style="width: 180px" /><span class="muted" style="margin-left: 8px; font-size: 12px">全组织附加库总数上限</span></el-form-item>
        </template>
        <template v-if="!form.id">
          <el-divider content-position="left"><span class="muted" style="font-size: 12px">首任组织管理员(可选,之后也可在「成员」里添加)</span></el-divider>
          <el-form-item label="用户名"><el-input v-model="form.owner_username" placeholder="已有用户名,或新用户名" /></el-form-item>
          <el-form-item label="初始密码"><el-input v-model="form.owner_password" type="password" show-password placeholder="新用户必填;已有用户留空" /></el-form-item>
          <el-form-item label="显示名"><el-input v-model="form.owner_display_name" /></el-form-item>
        </template>
      </el-form>
      <template #footer>
        <el-button @click="dlg = false">取消</el-button>
        <el-button type="primary" :loading="saving" :disabled="!form.name || (!form.id && (!form.slug || !!slugHint))" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus, Refresh, Search, MoreFilled } from '@element-plus/icons-vue'
import api from '../api'
import EmptyState from '../components/EmptyState.vue'
import PageTools from '../components/PageTools.vue'
import { loadTenants, defaults, loadDefaults } from '../store'
import { useIsMobile } from '../composables/useMedia'
import { confirmDanger } from '../utils/confirm'
import { fmtDate } from '../utils/format'
import Members from './Members.vue'

const isMobile = useIsMobile()

const rows = ref([])
const loading = ref(false)
const dlg = ref(false)
const q = ref('')
const memberDlg = ref(false); const memberTenant = ref(null)
function openMembers(row) { memberTenant.value = row; memberDlg.value = true }
const saving = ref(false)
const blank = { id: null, slug: '', name: '', description: '', is_active: true, owner_username: '', owner_password: '', owner_display_name: '', sleep_idle_hours: null, max_dbs_per_env: null, max_dbs_total: null }
const form = reactive({ ...blank })
const filtered = computed(() => { const k = q.value.trim().toLowerCase(); return k ? rows.value.filter((r) => [r.name, r.slug, r.description].some((x) => (x || '').toLowerCase().includes(k))) : rows.value })

async function load() {
  loading.value = true
  try { rows.value = await loadTenants(true); loadDefaults() } catch {} finally { loading.value = false }
}
// 组织标识要拼进容器名 / Docker 网络 / 访问域名,只认小写 ASCII。
// 能自动纠的边输边纠(大写转小写、空格与下划线转中划线、连续中划线合并、开头的中划线去掉);
// 纠不了的(中文等)由 slugHint 说清楚,而不是等提交后让后端报错。
function normSlug(v) {
  return String(v || '')
    .toLowerCase()
    .replace(/[\s_.]+/g, '-')
    .replace(/-{2,}/g, '-')
    .replace(/^-+/, '')
    .slice(0, 64)
}
const slugHint = computed(() => {
  if (form.id || !form.slug) return ''
  const bad = [...new Set(form.slug.match(/[^a-z0-9-]/g) || [])]
  if (bad.length) {
    const cjk = bad.some((c) => c >= '一' && c <= '鿿')
    return `不能包含「${bad.join('')}」${cjk ? ',中文请改用拼音,如 shanghai-keji' : ',只能用小写字母、数字和中划线'}`
  }
  if (form.slug.length < 2) return '至少 2 个字符'
  return ''
})

function openCreate() { Object.assign(form, blank); dlg.value = true }
function openEdit(row) { Object.assign(form, blank, row); dlg.value = true }
async function save() {
  saving.value = true
  try {
    if (form.id) await api.put(`/tenants/${form.id}`, { name: form.name, description: form.description, is_active: form.is_active, sleep_idle_hours: form.sleep_idle_hours ?? null, max_dbs_per_env: form.max_dbs_per_env ?? null, max_dbs_total: form.max_dbs_total ?? null })
    else await api.post('/tenants', { slug: form.slug, name: form.name, description: form.description, owner_username: form.owner_username || null, owner_password: form.owner_password || null, owner_display_name: form.owner_display_name || null })
    ElMessage.success('已保存'); dlg.value = false; load()
  } catch {} finally { saving.value = false }
}
async function remove(row) {
  if (!(await confirmDanger({ title: '删除组织', message: `删除组织「${row.name}」?其实例、仓库与成员关系将一并移除,不可恢复。`, requireText: row.slug, inputLabel: `请输入组织标识「${row.slug}」以确认:` }))) return
  try { await api.delete(`/tenants/${row.id}`); ElMessage.success('已删除'); load() } catch {}
}
onMounted(load)
</script>

<style scoped>
.tools { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.search { width: 220px; }
.row-name { display: flex; align-items: center; gap: 10px; }
.badge { width: 32px; height: 32px; border-radius: 8px; background: var(--brand-50); color: var(--brand); font-weight: 700; display: inline-flex; align-items: center; justify-content: center; flex: none; }
.badge.off { background: var(--surface-2); color: var(--text-3); }
.names .n { font-weight: 600; }
.names .s { font-size: 12px; }
@media (max-width: 640px) { .search { width: 100%; } }
</style>
