<template>
  <div class="page">
    <div class="page-header">
      <div>
        <h2>基础镜像</h2>
        <div class="desc">默认使用官方镜像 <code>odoo:&lt;版本&gt;</code>(经国内加速站拉取);企业版与自定义代码以目录挂载进入容器,与镜像解耦。需精确控制核心 commit 时可选「源码自建」。</div>
      </div>
      <el-button :icon="Refresh" @click="load">刷新</el-button>
    </div>
    <el-row :gutter="16">
      <el-col :span="11">
        <el-card shadow="never">
          <template #header>版本</template>
          <el-table :data="versions" size="small">
            <el-table-column prop="version" label="Odoo" width="70" />
            <el-table-column label="官方镜像">
              <template #default="{ row }">
                <div><el-tag v-if="row.official" type="success" size="small">odoo:{{ row.version }}</el-tag><el-tag v-else type="info" size="small">未拉取</el-tag>
                  <span class="muted" v-if="row.official"> {{ mb(row.official.size) }}</span></div>
                <el-button link type="primary" size="small" :loading="!!jobs['pull-' + row.version]" @click="pull(row.version)">{{ jobState['pull-' + row.version]?.ok === false ? '重试拉取' : row.official ? '更新' : '拉取' }}</el-button>
                <el-button link size="small" @click="watch('pull-' + row.version)">日志</el-button>
                <el-tag v-if="jobState['pull-' + row.version]?.ok === false" size="small" type="danger" effect="plain" style="margin-left: 4px">上次失败</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="源码自建">
              <template #default="{ row }">
                <div><el-tag v-if="row.custom" type="success" size="small">odoosh-base:{{ row.version }}</el-tag><el-tag v-else type="info" size="small">未构建</el-tag>
                  <span class="muted" v-if="row.custom"> {{ mb(row.custom.size) }}</span></div>
                <el-button link type="primary" size="small" :loading="!!jobs['build-base-' + row.version]" @click="build(row.version)">{{ jobState['build-base-' + row.version]?.ok === false ? '重试构建' : row.custom ? '重新构建' : '构建' }}</el-button>
                <el-button link size="small" @click="watch('build-base-' + row.version)">日志</el-button>
                <el-tag v-if="jobState['build-base-' + row.version]?.ok === false" size="small" type="danger" effect="plain" style="margin-left: 4px">上次失败</el-tag>
              </template>
            </el-table-column>
          </el-table>
        </el-card>

        <!-- 离线镜像包:内网/断网环境预下载 tar → docker load。两种入库(直接拷进目录 / 网页上传)进来后共用同一份列表与导入 -->
        <el-card shadow="never" class="offline-card">
          <template #header>
            <div class="off-head">
              <span>离线镜像包 <span class="muted" style="font-weight: 400; font-size: 12px">— 无外网时预先导入镜像</span></span>
              <div>
                <input ref="fileInput" type="file" accept=".tar,.gz,.tgz" style="display: none" @change="onPick" />
                <el-button size="small" :loading="uploading" @click="fileInput?.click()">上传镜像包</el-button>
                <el-button size="small" :icon="Refresh" @click="loadOffline">扫描</el-button>
              </div>
            </div>
          </template>
          <div class="muted off-hint">
            在有网机器上 <code>docker save odoo:19 -o odoo-19.tar</code>(建议**不压缩**,镜像层本身已压缩,再压 gz 省不了体积却拖慢导入),
            把 tar 放到服务器目录 <code>{{ offlineDir || '…' }}</code>(或用上方「上传镜像包」)。
            <b>创建实例时会自动导入所需版本,通常无需手动点「导入」</b>;手动导入仅用于提前准备或核验。大包(GB 级)建议用 scp / U 盘拷贝更稳。
          </div>
          <div v-if="uploading" class="up-prog"><el-progress :percentage="uploadPct" :stroke-width="6" /><span class="muted">上传中 {{ uploadName }}</span></div>
          <el-table :data="offlineFiles" size="small" v-if="offlineFiles.length">
            <el-table-column label="文件 / 镜像" min-width="220">
              <template #default="{ row }">
                <div class="mono">{{ row.name }} <span class="muted">{{ mb(row.size) }}</span></div>
                <div v-if="row.tags && row.tags.length"><el-tag v-for="t in row.tags" :key="t" size="small" :type="row.imported ? 'success' : 'info'" effect="plain" style="margin: 2px 4px 0 0">{{ t }}</el-tag></div>
                <div v-else-if="row.status === 'bad'" class="warn-txt">⚠ 可能损坏或不是镜像包(可尝试导入,失败看日志)</div>
                <div v-else-if="row.status === 'unknown'" class="muted" style="font-size: 12px">大压缩包未预读镜像名(建议改用未压缩 .tar);仍可导入</div>
                <div v-else class="muted" style="font-size: 12px">未打标签的镜像(仍可导入)</div>
              </template>
            </el-table-column>
            <el-table-column label="状态" width="86">
              <template #default="{ row }">
                <el-tag v-if="offlineJobs[row.name]?.running" size="small" type="warning" effect="plain">导入中</el-tag>
                <el-tag v-else-if="offlineJobs[row.name]?.ok === false" size="small" type="danger" effect="plain">上次失败</el-tag>
                <el-tag v-else-if="row.imported" size="small" type="success" effect="plain">已导入</el-tag>
                <el-tag v-else size="small" type="info" effect="plain">未导入</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="150" align="right">
              <template #default="{ row }">
                <el-button link type="primary" size="small" :loading="!!offlineJobs[row.name]?.running" @click="importOffline(row.name)">{{ row.imported ? '重新导入' : (offlineJobs[row.name]?.ok === false ? '重试' : '导入') }}</el-button>
                <el-button link size="small" @click="watch('offline-load-' + row.name)">日志</el-button>
                <el-button link type="danger" size="small" @click="removeOffline(row.name)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <el-empty v-else :image-size="60" description="目录里还没有镜像包" />
        </el-card>
      </el-col>
      <el-col :span="13">
        <el-card shadow="never">
          <template #header>任务日志 <span class="muted" v-if="watching">— {{ watching }}</span></template>
          <pre class="log" ref="logEl">{{ logText || '(点击某个版本的「日志」查看)' }}</pre>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { computed, nextTick, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import api from '../api'
import { usePolling } from '../composables/usePolling'
import { confirmDanger } from '../utils/confirm'
import { fmtMB as mb } from '../utils/format'

const supported = ref([]); const items = ref([]); const jobs = reactive({}); const jobState = ref({})
const watching = ref(''); const lines = ref([]); const offset = ref(0); const logEl = ref(null)
const logText = computed(() => lines.value.join('\n'))

// ---- 离线镜像包 ----
const offlineFiles = ref([]); const offlineJobs = reactive({}); const offlineDir = ref('')
const fileInput = ref(null); const uploading = ref(false); const uploadPct = ref(0); const uploadName = ref('')
async function loadOffline() {
  try {
    const r = await api.get('/images/offline')
    offlineFiles.value = r.files || []; offlineDir.value = r.host_dir || ''
    Object.keys(offlineJobs).forEach((k) => delete offlineJobs[k])
    Object.assign(offlineJobs, r.jobs || {})
  } catch {}
}
async function importOffline(name) {
  try { await api.post('/images/offline/import', { name }); offlineJobs[name] = { running: true }; ElMessage.success('开始导入'); watch('offline-load-' + name) } catch {}
}
async function removeOffline(name) {
  if (!(await confirmDanger({ title: '删除镜像包', message: `删除文件「${name}」?仅删除 tar 包,不影响已导入的镜像。` }))) return
  try { await api.delete(`/images/offline/${encodeURIComponent(name)}`); ElMessage.success('已删除'); loadOffline() } catch {}
}
function onPick(e) {
  const file = e.target.files?.[0]; e.target.value = ''
  if (file) uploadOffline(file)
}
async function uploadOffline(file) {
  uploading.value = true; uploadPct.value = 0; uploadName.value = file.name
  try {
    await api.put('/images/offline/upload', file, {
      params: { filename: file.name }, headers: { 'Content-Type': 'application/x-tar' }, timeout: 0,
      onUploadProgress: (ev) => { if (ev.total) uploadPct.value = Math.round(ev.loaded / ev.total * 100) },
    })
    ElMessage.success('上传完成'); loadOffline()
  } catch {} finally { uploading.value = false }
}
const versions = computed(() => supported.value.map((v) => ({
  version: v,
  official: items.value.find((i) => i.tags.includes(`odoo:${v}`)),
  custom: items.value.find((i) => i.tags.includes(`odoosh-base:${v}`)),
})))

async function load() {
  try {
    const r = await api.get('/images/base'); supported.value = r.supported; items.value = r.items; jobState.value = r.jobs || {}
    for (const [jid, st] of Object.entries(jobState.value)) if (st.running) jobs[jid] = true  // 页面刷新后也能看到「进行中」
  } catch {}
}
async function pull(v) { try { await api.post(`/images/official/${v}/pull`); jobs['pull-' + v] = true; ElMessage.success('开始拉取'); watch('pull-' + v) } catch {} }
async function build(v) { try { await api.post(`/images/base/${v}/build`); jobs['build-base-' + v] = true; ElMessage.success('开始构建'); watch('build-base-' + v) } catch {} }
function watch(job) { watching.value = job; lines.value = []; offset.value = 0; poll() }
async function poll() {
  if (!watching.value) return
  try {
    const r = await api.get(`/images/jobs/${watching.value}/log`, { params: { offset: offset.value }, silent: true })
    if (r.lines.length) { lines.value.push(...r.lines); offset.value = r.offset; await nextTick(); if (logEl.value) logEl.value.scrollTop = logEl.value.scrollHeight }
    const wasRunning = jobs[watching.value]
    jobs[watching.value] = r.exists && !r.done
    if (wasRunning && r.done) watching.value.startsWith('offline-load-') ? loadOffline() : load()
  } catch {}
}
const jobPoll = usePolling(poll, { interval: 2000, immediate: false, when: () => !!watching.value })
onMounted(() => { load(); loadOffline(); jobPoll.start() })
</script>

<style scoped>
.log { white-space: pre-wrap; word-break: break-all; height: 65vh; overflow: auto; margin: 0; }
.offline-card { margin-top: 16px; }
.off-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.off-hint { font-size: 12.5px; line-height: 1.7; margin-bottom: 10px; }
.off-hint code { word-break: break-all; }
.up-prog { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.up-prog :deep(.el-progress) { flex: 1; }
.mono { font-family: var(--mono, monospace); }
.warn-txt { font-size: 12px; color: var(--warning, #d97706); }
</style>
