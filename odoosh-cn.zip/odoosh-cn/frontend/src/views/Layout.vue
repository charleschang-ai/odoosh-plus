<template>
  <div class="shell" :class="{ collapsed, mobile: isMobile }">
    <!-- 桌面侧栏(菜单项在 components/NavMenu.vue 维护);navHidden = 免登入口要求整个隐藏(嵌入场景) -->
    <aside v-if="!isMobile && !navHidden" class="aside">
      <div class="brand" @click="router.push('/environments')">
        <BrandLogo :size="30" />
        <span class="brand-name">{{ BRAND.name }}<span v-if="BRAND.badge" class="brand-badge">{{ BRAND.badge }}</span></span>
      </div>
      <div class="aside-scroll"><NavMenu :collapse="collapsed" /></div>
      <div class="aside-foot" :title="`控制台 v${appVersion}${apiVersion ? ' · API v' + apiVersion : ''}`">
        <!-- 填了 ICP 备案号就显示备案号(工信部要求能点进备案系统),否则显示版本号;
             版本号不会丢 —— 两种情况下鼠标悬停的 title 里都有 -->
        <a v-if="!collapsed && BRAND.icp" class="icp" href="https://beian.miit.gov.cn/" target="_blank" rel="noopener">{{ BRAND.icp }}</a>
        <span v-else-if="!collapsed" class="ver">v{{ apiVersion || appVersion }}</span>
      </div>
    </aside>

    <!-- 手机端抽屉菜单 -->
    <el-drawer v-if="isMobile && !navHidden" v-model="drawer" direction="ltr" size="264px" :with-header="false" class="nav-drawer">
      <div class="brand"><BrandLogo :size="30" /><span class="brand-name">{{ BRAND.name }}<span v-if="BRAND.badge" class="brand-badge">{{ BRAND.badge }}</span></span></div>
      <NavMenu @navigate="drawer = false" />
    </el-drawer>

    <div class="main">
      <header class="header" :class="{ scrolled }">
        <div class="left">
          <button v-if="isMobile && !navHidden" class="icon-btn" @click="drawer = true"><el-icon :size="20"><Menu /></el-icon></button>
          <button v-else-if="!isMobile && !navHidden" class="icon-btn toggle" :title="collapsed ? '展开菜单' : '收起菜单'" @click="toggleCollapse"><el-icon :size="18"><component :is="collapsed ? Expand : Fold" /></el-icon></button>
          <span v-if="!isMobile && !navHidden" class="vsep" />
          <div class="crumb">
            <span class="crumb-title">{{ route.meta.title }}</span>
          </div>
          <!-- 组织切换器:属于多个组织时显示(切换是刚需);单组织的组织名胸牌仅超管可见 —— 嵌入课程系统等场景不暴露组织名 -->
          <el-select v-if="memberships.length > 1" :model-value="session.currentTenantId" size="small" class="tenant-select" @change="switchTenant">
            <template #prefix><el-icon><OfficeBuilding /></el-icon></template>
            <el-option v-for="m in memberships" :key="m.tenant_id" :value="m.tenant_id" :label="m.tenant_name">
              <span>{{ m.tenant_name }}</span><span class="muted opt-role">{{ ROLE_LABEL[m.role] }}</span>
            </el-option>
          </el-select>
          <span v-else-if="isSuper && currentTenant" class="tenant-pill"><el-icon><OfficeBuilding /></el-icon>{{ currentTenant.tenant_name }}</span>
        </div>
        <!-- 页面工具栏槽位:各页面用 <PageTools> 包住自己的筛选/按钮,宽屏时会传送到这里(见 components/PageTools.vue) -->
        <div id="hdr-tools" class="hdr-tools" />
        <div class="right">
          <!-- 跳转搜索仅超管:普通用户(尤其嵌入场景的单实例用户)用不上 -->
          <QuickJump v-if="!isMobile && isSuper" class="hdr-jump" />
          <span v-if="!isMobile && isSuper" class="vsep" />
          <button v-if="aiVisible" class="ai-launch" :class="{ on: aiOpen }" :title="aiOpen ? '收起 AI 助手' : '打开 AI 助手'" @click="toggleAi">
            <el-icon><MagicStick /></el-icon><span v-if="!isMobile" class="ai-label">AI 助手</span>
          </button>
          <button class="icon-btn" title="刷新当前页" @click="reload"><el-icon><Refresh /></el-icon></button>
          <button v-if="!isMobile" class="icon-btn" :title="fullscreen ? '退出全屏' : '全屏'" @click="toggleFullscreen"><el-icon><FullScreen /></el-icon></button>
          <el-dropdown trigger="click" @command="onCmd">
            <button class="user">
              <span class="avatar">{{ initials }}</span>
              <span class="user-name">{{ session.me?.display_name || session.me?.username }}</span>
              <el-icon class="caret"><ArrowDown /></el-icon>
            </button>
            <template #dropdown>
              <el-dropdown-menu class="user-menu">
                <div class="user-card">
                  <div class="avatar lg">{{ initials }}</div>
                  <div>
                    <div class="n">{{ session.me?.display_name || session.me?.username }}</div>
                    <div class="r">{{ isSuper ? '超级管理员' : (ROLE_LABEL[currentRole] || '无组织') }}<span v-if="!isSuper && currentTenant"> · {{ currentTenant.tenant_name }}</span></div>
                  </div>
                </div>
                <el-dropdown-item v-if="isSuper" command="maintenance" divided><el-icon><RefreshRight /></el-icon>重启 / 更新平台</el-dropdown-item>
                <el-dropdown-item v-if="isSuper" command="tokens"><el-icon><Key /></el-icon>接入令牌</el-dropdown-item>
                <el-dropdown-item command="password" :divided="!isSuper"><el-icon><Lock /></el-icon>修改密码</el-dropdown-item>
                <el-dropdown-item command="logout"><el-icon><SwitchButton /></el-icon>退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </header>
      <main class="content" ref="contentEl" @scroll.passive="onScroll">
        <router-view v-if="session.loaded" v-slot="{ Component }">
          <transition name="page" mode="out-in" :duration="{ enter: 180, leave: 120 }">
            <component :is="Component" :key="viewKey + route.path" />
          </transition>
        </router-view>
      </main>
    </div>

    <!-- 停靠式 AI 侧栏(桌面):把主内容挤开,并排常驻,可拖宽 -->
    <AiDock v-if="aiVisible && aiOpen && !isMobile" :open="aiOpen" :context-env="contextEnv"
            @close="aiOpen = false" @expand="expandAi" />
    <!-- 手机端:抽屉形式 -->
    <el-drawer v-if="isMobile" v-model="aiOpen" direction="rtl" size="88%" :with-header="false" class="ai-mobile-drawer" append-to-body>
      <div class="ai-mobile-head"><span><el-icon><MagicStick /></el-icon> AI 助手</span><button class="mini" @click="aiOpen = false"><el-icon><Close /></el-icon></button></div>
      <div class="ai-mobile-body"><AiChatPanel dense :active="aiOpen" :context-env="contextEnv" /></div>
    </el-drawer>

    <!-- 接入令牌(仅超管) -->
    <ApiTokensDialog v-if="isSuper" v-model="tokensDlg" />

    <!-- 修改密码 -->
    <el-dialog v-model="pwdDlg" title="修改密码" width="420px" @closed="Object.assign(pwd, { old: '', new1: '', new2: '' })">
      <el-form label-position="top" @submit.prevent="changePassword">
        <el-form-item label="当前密码"><el-input v-model="pwd.old" type="password" show-password autocomplete="current-password" /></el-form-item>
        <el-form-item label="新密码"><el-input v-model="pwd.new1" type="password" show-password autocomplete="new-password" placeholder="至少 6 位" /></el-form-item>
        <el-form-item label="确认新密码"><el-input v-model="pwd.new2" type="password" show-password autocomplete="new-password" @keyup.enter="changePassword" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="pwdDlg = false">取消</el-button>
        <el-button type="primary" :loading="pwdSaving" :disabled="!pwd.old || pwd.new1.length < 6 || pwd.new1 !== pwd.new2" @click="changePassword">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElNotification } from 'element-plus'
import { Expand, Fold, Menu, OfficeBuilding, Refresh, FullScreen, ArrowDown, RefreshRight, Lock, SwitchButton, MagicStick, Close, Key } from '@element-plus/icons-vue'
import api from '../api'
import NavMenu from '../components/NavMenu.vue'
import ApiTokensDialog from '../components/ApiTokensDialog.vue'
import QuickJump from '../components/QuickJump.vue'
import AiDock from '../components/ai/AiDock.vue'
import AiChatPanel from '../components/ai/AiChatPanel.vue'
import { BRAND, loadBrand } from '../brand'
import BrandLogo from '../components/BrandLogo.vue'
import { session, memberships, currentTenant, currentRole, isSuper, ROLE_LABEL, loadSession, clearSession, setCurrentTenant, loadTenants, loadDefaults, menuVisible } from '../store'
import { appUpdated } from '../utils/appVersion'
import { useIsNarrow } from '../composables/useMedia'
import { initials as initialsOf } from '../utils/format'

// 版本:构建时注入前端版本;后端 /health 返回 API 版本
const appVersion = typeof __APP_VERSION__ !== 'undefined' ? __APP_VERSION__ : ''
const apiVersion = ref('')

const route = useRoute()
const router = useRouter()

// 免登入口要求隐藏整个左侧菜单(AuthCallback 按 handoff 的 menu 参数 / 令牌默认写入;只在本标签页生效)
const navHidden = sessionStorage.getItem('navHidden') === '1'

// ---- 侧栏收缩(记忆到本地;第三方免登进来的会话由 AuthCallback 写 sessionStorage 默认收起,展开与否只记在那个标签页) ----
const collapsed = ref((sessionStorage.getItem('sidebarCollapsed') ?? localStorage.getItem('sidebarCollapsed')) === '1')
function toggleCollapse() {
  collapsed.value = !collapsed.value
  const store = sessionStorage.getItem('sidebarCollapsed') != null ? sessionStorage : localStorage
  store.setItem('sidebarCollapsed', collapsed.value ? '1' : '0')
}

// ---- 手机端 ----
const isMobile = useIsNarrow()
const drawer = ref(false)
watch(isMobile, (m) => { if (!m) drawer.value = false })

// ---- 头部动作 ----
const reloadTick = ref(0)
const scrolled = ref(false)
function onScroll(e) { scrolled.value = e.target.scrollTop > 4 }
const viewKey = computed(() => `${session.currentTenantId}-${reloadTick.value}`)
// 刷新当前页:前端已重建 → 整页 reload(拿新代码);否则重挂载路由组件 + 刷新全局缓存(当前用户 / 权限 / 组织列表 / 平台默认值),
// 保证「系统设置」里刚改的值(可用版本、默认过期等)在其他页面立刻生效,不用手动 F5
let updateNotified = false
async function reload() {
  if (await appUpdated()) { location.reload(); return }
  try { await Promise.all([loadSession(), loadTenants(true), loadDefaults(true)]) } catch {}
  reloadTick.value++
}
async function checkAppUpdate() {
  if (updateNotified || !(await appUpdated())) return
  updateNotified = true
  ElNotification.info({ title: '平台前端已更新', message: '点击此处或顶栏「刷新」加载新版本', duration: 0, onClick: () => location.reload() })
}
const fullscreen = ref(false)
function toggleFullscreen() {
  if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().then(() => (fullscreen.value = true)).catch(() => {})
  else document.exitFullscreen?.().then(() => (fullscreen.value = false)).catch(() => {})
}
const initials = computed(() => initialsOf(session.me?.display_name || session.me?.username))

onMounted(async () => {
  try { if (!session.loaded) await loadSession() } catch {}
  setInterval(checkAppUpdate, 5 * 60 * 1000)
  document.addEventListener('visibilitychange', () => { if (!document.hidden) checkAppUpdate() })
  api.get('/health', { silent: true }).then((h) => { if (h?.version) apiVersion.value = String(h.version) }).catch(() => {})
  api.get('/ai/config', { silent: true }).then((c) => { aiEnabled.value = !!c?.enabled }).catch(() => {})
  loadBrand(api)  // 校准品牌名(超管改过设置后,其他人下次进来即生效)
})

// ---- AI 停靠侧栏 ----
const aiEnabled = ref(false)
const aiVisible = computed(() => aiEnabled.value && menuVisible('ai'))  // 全局 ai.enabled × 每用户菜单开关
const aiOpen = ref(localStorage.getItem('aiDockOpen') === '1')
const contextEnv = ref(null)
watch(aiOpen, (v) => localStorage.setItem('aiDockOpen', v ? '1' : '0'))
function toggleAi() { aiOpen.value = !aiOpen.value }
function expandAi() { aiOpen.value = false; router.push('/ai') }
// 上下文感知:在实例详情页时,把当前实例带给 AI(仅超管的 ops 模式会用到)
watch(() => route.path, async () => {
  const m = route.path.match(/^\/environments\/(\d+)/)
  if (!m) { contextEnv.value = null; return }  // 任何用户在实例详情页都带上下文(AI 用时仍按权限授权)
  const id = Number(m[1])
  if (contextEnv.value?.id === id) return
  try { const e = await api.get(`/environments/${id}`, { silent: true }); contextEnv.value = { id, name: e?.name, kind: e?.kind } }
  catch { contextEnv.value = { id } }
}, { immediate: true })

function switchTenant(id) { setCurrentTenant(id) }
function onCmd(cmd) {
  if (cmd === 'logout') { clearSession(); router.replace('/login') }
  if (cmd === 'password') pwdDlg.value = true
  if (cmd === 'maintenance') router.push('/maintenance')
  if (cmd === 'tokens') tokensDlg.value = true
}

// ---- 接入令牌(仅超管) ----
const tokensDlg = ref(false)

// ---- 修改密码 ----
const pwdDlg = ref(false); const pwdSaving = ref(false)
const pwd = reactive({ old: '', new1: '', new2: '' })
async function changePassword() {
  if (!pwd.old || pwd.new1.length < 6 || pwd.new1 !== pwd.new2) return
  pwdSaving.value = true
  try {
    await api.post('/auth/password', { old_password: pwd.old, new_password: pwd.new1 })
    pwdDlg.value = false
    ElMessage.success('密码已修改,请用新密码重新登录')
    clearSession(); router.replace('/login')  // 改密后旧登录令牌已失效
  } catch {} finally { pwdSaving.value = false }
}
</script>

<style scoped>
.shell { height: 100%; display: flex; background: var(--bg); }

/* 侧栏 */
.aside { width: var(--sidebar-w); flex: none; background: #1b2230; color: #fff; display: flex; flex-direction: column; transition: width .18s ease; overflow: hidden; }
.collapsed .aside { width: var(--sidebar-w-collapsed); }
.brand { height: var(--header-h); display: flex; align-items: center; gap: 10px; padding: 0 20px; font-size: 16px; font-weight: 650; color: #fff; letter-spacing: -.01em; cursor: pointer; white-space: nowrap; flex: none; }
.collapsed .brand { padding: 0; justify-content: center; }
.collapsed .brand-name { display: none; }
.brand-name { display: inline-flex; align-items: center; gap: 7px; }
.brand-badge { font-size: 10.5px; font-weight: 700; letter-spacing: .06em; line-height: 1; padding: 3px 6px; border-radius: 5px; background: rgba(201, 165, 190, .18); color: #d9b8cf; border: 1px solid rgba(201, 165, 190, .35); }
.logo { width: 30px; height: 30px; border-radius: 8px; background: var(--brand); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 15px; flex: none; }
.aside-scroll { flex: 1; overflow-y: auto; overflow-x: hidden; padding-bottom: 12px; }
.aside-scroll::-webkit-scrollbar-thumb { background: rgba(255,255,255,.15); background-clip: content-box; border: 2px solid transparent; }
.aside-foot { border-top: 1px solid rgba(255, 255, 255, .07); padding: 10px 20px; font-size: 11px; color: #667385; min-height: 36px; }
.aside-foot .icp { color: inherit; text-decoration: none; }
.aside-foot .icp:hover { color: #aab4c3; text-decoration: underline; }
.collapsed .aside-foot { padding: 10px 0; }

/* 抽屉菜单 */
:global(.el-overlay .el-drawer.nav-drawer) { background: #1b2230 !important; width: 264px !important; max-width: 85vw; }
:global(.nav-drawer .el-drawer__body) { padding: 0 !important; }

/* 主区 */
.main { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.header { height: var(--header-h); flex: none; background: rgba(255, 255, 255, .92); backdrop-filter: saturate(1.4) blur(10px); border-bottom: 1px solid var(--line); display: flex; align-items: center; padding: 0 16px 0 20px; gap: 12px; position: sticky; top: 0; z-index: 20; }
.mobile .header { padding: 0 10px 0 6px; }
.left, .right { display: flex; align-items: center; gap: 10px; min-width: 0; flex: none; }
.right { gap: 4px; }
/* 页面工具槽:占据中间全部剩余空间,内容靠右;有内容时右侧加一条分隔线与全局按钮区分开 */
.hdr-tools { flex: 1; min-width: 0; display: flex; align-items: center; justify-content: flex-end; gap: 8px; overflow-x: auto; scrollbar-width: none; }
.hdr-tools::-webkit-scrollbar { display: none; }
.hdr-tools:has(*)::after { content: ''; width: 1px; height: 20px; background: var(--line); margin-left: 6px; flex: none; }
.crumb-title { font-weight: 700; font-size: 16px; white-space: nowrap; letter-spacing: -.01em; }
.tenant-select { width: 180px; }
.tenant-select :deep(.el-select__wrapper) { box-shadow: 0 0 0 1px var(--line-2) inset !important; background: var(--surface-2); border-radius: 999px; padding-left: 10px; }
.tenant-select :deep(.el-select__wrapper.is-focused) { box-shadow: 0 0 0 1px var(--brand) inset !important; }
.tenant-pill { display: inline-flex; align-items: center; gap: 6px; font-size: 12.5px; color: var(--text-2); background: var(--surface-2); border: 1px solid var(--line-2); padding: 3px 10px; border-radius: 999px; white-space: nowrap; }
.opt-role { float: right; font-size: 12px; }
.icon-btn { width: 34px; height: 34px; border: none; background: transparent; color: var(--text-2); border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; cursor: pointer; font-size: 17px; }
.icon-btn:hover { background: var(--surface-2); color: var(--text); }
.icon-btn.toggle { margin-left: -8px; }
/* AI 启动按钮:醒目的渐变胶囊 */
.ai-launch { display: inline-flex; align-items: center; gap: 6px; height: 34px; padding: 0 12px; border: none; border-radius: 999px; cursor: pointer; font-size: 13px; font-weight: 600; color: #fff; background: linear-gradient(135deg, #818cf8, #6366f1); box-shadow: 0 3px 12px -4px rgba(99,102,241,.7); transition: transform .12s, box-shadow .15s, filter .15s; }
.ai-launch:hover { transform: translateY(-1px); box-shadow: 0 6px 18px -5px rgba(99,102,241,.85); filter: brightness(1.05); }
.ai-launch.on { background: linear-gradient(135deg, #6366f1, #4f46e5); box-shadow: inset 0 2px 6px rgba(0,0,0,.2); }
.ai-launch .ai-label { line-height: 1; }
.mobile .ai-launch { padding: 0; width: 34px; justify-content: center; }
.ai-mobile-head { display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; border-bottom: 1px solid var(--line); font-weight: 650; }
.ai-mobile-head span { display: inline-flex; align-items: center; gap: 7px; }
.ai-mobile-head .mini { width: 32px; height: 32px; border: none; background: transparent; border-radius: 7px; cursor: pointer; color: var(--text-2); }
.ai-mobile-body { height: calc(100% - 49px); }
:global(.ai-mobile-drawer .el-drawer__body) { padding: 0 !important; }
.vsep { width: 1px; height: 18px; background: var(--line); margin: 0 2px 0 -2px; }
.user { display: inline-flex; align-items: center; gap: 8px; cursor: pointer; padding: 4px 8px 4px 4px; border-radius: 999px; border: none; background: transparent; font: inherit; color: var(--text); margin-left: 4px; }
.user:hover { background: var(--surface-2); }
.avatar { width: 28px; height: 28px; border-radius: 50%; background: var(--brand-100); color: var(--brand-600); font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; justify-content: center; flex: none; letter-spacing: 0; }
.avatar.lg { width: 38px; height: 38px; font-size: 14px; }
.user-name { font-size: 13.5px; font-weight: 500; max-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.caret { font-size: 12px; color: var(--text-3); }
.mobile .user-name, .mobile .caret { display: none; }
.user-menu { min-width: 220px; }
.user-card { display: flex; align-items: center; gap: 10px; padding: 8px 10px 10px; }
.user-card .n { font-weight: 600; font-size: 14px; }
.user-card .r { font-size: 12px; color: var(--text-3); margin-top: 1px; }
.content { flex: 1; overflow: auto; }
.header.scrolled { box-shadow: 0 4px 16px -8px rgba(20, 28, 42, .18); }
/* 页面切换过渡 */
.page-enter-active { transition: opacity .18s ease, transform .18s ease; }
.page-leave-active { transition: opacity .12s ease; }
.page-enter-from { opacity: 0; transform: translateY(6px); }
.page-leave-to { opacity: 0; }
@media (max-width: 640px) {
  .tenant-select { width: 140px; }
  .tenant-pill { max-width: 140px; overflow: hidden; text-overflow: ellipsis; display: inline-block; line-height: 20px; }
  .crumb-title { font-size: 14px; }
}
</style>
