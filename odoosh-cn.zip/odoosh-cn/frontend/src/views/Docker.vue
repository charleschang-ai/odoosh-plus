<template>
  <div class="page">
    <div class="page-header">
      <div>
        <h2>Docker</h2>
        <div class="desc" v-if="!error">容器 {{ containers.length }}(运行中 {{ containers.filter((c) => c.status === 'running').length }})· 镜像 {{ images.length }}</div>
      </div>
      <div class="tools">
        <el-input v-model="q" placeholder="搜索名称 / 镜像 / ID" clearable :prefix-icon="Search" class="search" />
        <el-button :icon="Refresh" :loading="loading" @click="load">刷新</el-button>
      </div>
    </div>
    <el-alert v-if="error" type="error" :title="error" :closable="false" show-icon style="margin-bottom: 12px" />
    <el-card shadow="never" class="tabs-card">
      <el-tabs v-model="tab">
        <el-tab-pane :label="`容器 (${filteredContainers.length})`" name="containers">
          <el-table :data="filteredContainers" v-loading="loading" stripe size="small">
            <el-table-column label="ID" width="120"><template #default="{ row }"><span class="mono muted">{{ row.id.slice(0, 12) }}</span></template></el-table-column>
            <el-table-column prop="name" label="名称" min-width="220" show-overflow-tooltip><template #default="{ row }"><span class="mono">{{ row.name }}</span></template></el-table-column>
            <el-table-column prop="image" label="镜像" min-width="200" show-overflow-tooltip />
            <el-table-column label="状态" width="110">
              <template #default="{ row }"><span class="st" :class="row.status"><i />{{ row.status }}</span></template>
            </el-table-column>
            <el-table-column label="创建时间" width="160"><template #default="{ row }"><span class="muted">{{ fmtDate(row.created) }}</span></template></el-table-column>
            <template #empty><EmptyState :variant="q ? 'search' : 'generic'" :title="q ? '没有匹配的容器' : '没有容器'" :width="120" /></template>
          </el-table>
        </el-tab-pane>
        <el-tab-pane :label="`镜像 (${filteredImages.length})`" name="images">
          <el-table :data="filteredImages" v-loading="loading" stripe size="small">
            <el-table-column label="ID" width="140"><template #default="{ row }"><span class="mono muted">{{ row.id.replace('sha256:', '').slice(0, 12) }}</span></template></el-table-column>
            <el-table-column label="标签" min-width="260"><template #default="{ row }"><template v-if="row.tags.length"><el-tag v-for="t in row.tags" :key="t" size="small" effect="plain" class="tag">{{ t }}</el-tag></template><span v-else class="muted">&lt;none&gt;</span></template></el-table-column>
            <el-table-column label="大小" width="110" align="right"><template #default="{ row }"><span class="mono">{{ fmtMB(row.size) }}</span></template></el-table-column>
            <el-table-column label="创建时间" width="160"><template #default="{ row }"><span class="muted">{{ fmtDate(row.created) }}</span></template></el-table-column>
            <template #empty><EmptyState :variant="q ? 'search' : 'generic'" :title="q ? '没有匹配的镜像' : '没有镜像'" :width="120" /></template>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </el-card>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { Refresh, Search } from '@element-plus/icons-vue'
import api from '../api'
import EmptyState from '../components/EmptyState.vue'
import { fmtDate, fmtMB } from '../utils/format'

const containers = ref([]); const images = ref([]); const loading = ref(false); const error = ref(''); const q = ref(''); const tab = ref('containers')
const kw = computed(() => q.value.trim().toLowerCase())
const filteredContainers = computed(() => containers.value.filter((c) => !kw.value || [c.name, c.image, c.id].some((x) => (x || '').toLowerCase().includes(kw.value))))
const filteredImages = computed(() => images.value.filter((i) => !kw.value || [i.id, ...(i.tags || [])].some((x) => (x || '').toLowerCase().includes(kw.value))))
async function load() {
  loading.value = true
  try {
    const [c, i] = await Promise.all([api.get('/system/docker/containers'), api.get('/system/docker/images')])
    containers.value = c.items; images.value = i.items
    error.value = c.ok ? '' : `无法连接 Docker:${c.error}`
  } catch {} finally { loading.value = false }
}
onMounted(load)
</script>

<style scoped>
.tools { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.search { width: 240px; }
.tabs-card :deep(.el-card__body) { padding-top: 6px; }
.tabs-card :deep(.el-tabs__header) { margin-bottom: 8px; }
.st { display: inline-flex; align-items: center; gap: 6px; font-size: 12.5px; color: var(--text-2); text-transform: capitalize; }
.st i { width: 7px; height: 7px; border-radius: 50%; background: #b6bec9; }
.st.running { color: #15803d; } .st.running i { background: var(--ok); }
.st.exited, .st.dead { color: var(--text-3); }
.st.paused, .st.restarting { color: var(--warn); } .st.paused i, .st.restarting i { background: var(--warn); }
.tag { margin: 2px 6px 2px 0; }
@media (max-width: 640px) { .search { width: 100%; } }
</style>
