<template>
  <div :class="embedded ? 'embedded' : 'page'">
    <div class="page-header">
      <div>
        <h2 v-if="!embedded">成员 <span class="muted" style="font-size: 14px; font-weight: 400">— {{ tenant?.tenant_name }}</span></h2>
        <div class="desc">{{ rows.length }} 位成员 · 组织管理员:一切权限 · 开发者:开发/测试实例与代码部署,生产只读 · 测试者:仅打开开发/测试实例</div>
      </div>
      <el-button type="primary" :icon="Plus" @click="openAdd">添加成员</el-button>
    </div>
    <el-card shadow="never">
      <el-table :data="rows" v-loading="loading" stripe>
        <el-table-column label="成员" min-width="200">
          <template #default="{ row }">
            <div class="who">
              <span class="avatar" :class="{ off: !row.is_active }">{{ initials(row) }}</span>
              <div><div class="n">{{ row.display_name || row.username }}<span v-if="row.user_id === session.me?.id" class="me">我</span></div><div class="s muted mono">{{ row.username }}</div></div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="角色" width="180">
          <template #default="{ row }">
            <el-select :model-value="row.role" size="small" style="width: 150px" @change="(r) => changeRole(row, r)" :disabled="row.user_id === session.me?.id && !isSuper">
              <el-option v-for="(label, r) in ROLE_LABEL" :key="r" :value="r" :label="label" />
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="90">
          <template #default="{ row }"><el-tag size="small" effect="plain" :type="row.is_active ? 'success' : 'info'">{{ row.is_active ? '启用' : '停用' }}</el-tag></template>
        </el-table-column>
        <el-table-column label="加入时间" width="160"><template #default="{ row }"><span class="muted">{{ fmtDate(row.created_at) }}</span></template></el-table-column>
        <el-table-column label="操作" width="90" align="right">
          <template #default="{ row }">
            <el-button link type="danger" :disabled="row.user_id === session.me?.id && !isSuper" @click="remove(row)">移除</el-button>
          </template>
        </el-table-column>
        <template #empty><EmptyState variant="generic" title="还没有成员" desc="点击右上角「添加成员」邀请同事加入" :width="120" /></template>
      </el-table>
    </el-card>

    <el-dialog v-model="dlg" title="添加成员" width="460px" append-to-body>
      <el-form :model="form" label-width="90px">
        <el-form-item label="用户名" required><el-input v-model="form.username" placeholder="已有用户名;不存在则按下面信息创建" /></el-form-item>
        <el-form-item label="角色">
          <el-select v-model="form.role" style="width: 100%">
            <el-option v-for="(label, r) in ROLE_LABEL" :key="r" :value="r" :label="label" />
          </el-select>
        </el-form-item>
        <el-divider content-position="left"><span class="muted" style="font-size: 12px">用户不存在时创建</span></el-divider>
        <el-form-item label="初始密码"><el-input v-model="form.password" type="password" show-password /></el-form-item>
        <el-form-item label="显示名"><el-input v-model="form.display_name" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dlg = false">取消</el-button>
        <el-button type="primary" :loading="saving" :disabled="!form.username" @click="save">添加</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import api from '../api'
import EmptyState from '../components/EmptyState.vue'
import { session, currentTenant, isSuper, ROLE_LABEL } from '../store'
import { confirmDanger } from '../utils/confirm'
import { fmtDate, initials as initialsOf } from '../utils/format'

const props = defineProps({ tenantId: { type: Number, default: null }, embedded: { type: Boolean, default: false } })
const tid = computed(() => props.tenantId || currentTenant.value?.tenant_id)
const tenant = computed(() => session.me?.memberships.find((m) => m.tenant_id === tid.value))
const rows = ref([]); const loading = ref(false); const dlg = ref(false); const saving = ref(false)
const form = reactive({ username: '', role: 'developer', password: '', display_name: '' })
const initials = (r) => initialsOf(r.display_name || r.username)

async function load() { if (!tid.value) return; loading.value = true; try { rows.value = await api.get(`/tenants/${tid.value}/members`) } catch {} finally { loading.value = false } }
function openAdd() { Object.assign(form, { username: '', role: 'developer', password: '', display_name: '' }); dlg.value = true }
async function save() {
  saving.value = true
  try { await api.post(`/tenants/${tid.value}/members`, { ...form, password: form.password || null, display_name: form.display_name || null }); ElMessage.success('已添加'); dlg.value = false; load() } catch {} finally { saving.value = false }
}
async function changeRole(row, role) { try { await api.put(`/tenants/${tid.value}/members/${row.id}`, { role }); ElMessage.success('已更新'); load() } catch {} }
async function remove(row) {
  if (!(await confirmDanger({ title: '移除成员', message: `将「${row.display_name || row.username}」移出本组织?不会删除用户账号。`, confirmText: '移除' }))) return
  try { await api.delete(`/tenants/${tid.value}/members/${row.id}`); ElMessage.success('已移除'); load() } catch {}
}
onMounted(load)
watch(tid, load)
</script>

<style scoped>
.embedded .page-header { margin-bottom: 12px; }
.embedded .desc { margin-top: 0; }
.who { display: flex; align-items: center; gap: 10px; }
.avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--brand-100); color: var(--brand-600); font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; justify-content: center; flex: none; }
.avatar.off { background: var(--surface-2); color: var(--text-3); }
.n { font-weight: 600; }
.s { font-size: 12px; }
.me { font-size: 11px; font-weight: 500; color: var(--brand); background: var(--brand-50); border-radius: 4px; padding: 0 5px; margin-left: 6px; vertical-align: 1px; }
</style>
