<template>
  <div class="page">
    <div class="page-header">
      <div>
        <h2>平台维护</h2>
        <div class="desc">重启 / 更新 OdooshCN 平台自身(不影响已运行的 Odoo 实例)</div>
      </div>
    </div>
    <PlatformUpdate />
  </div>
</template>

<script setup>
import PlatformUpdate from '../components/PlatformUpdate.vue'
</script>
