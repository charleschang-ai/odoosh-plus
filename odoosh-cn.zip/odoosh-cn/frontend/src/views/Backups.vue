<template>
  <div class="page">
    <div class="page-header">
      <h2>备份与恢复</h2>
      <div class="desc">共 {{ stats.total }} 份 · 占用 {{ fmtSize(stats.total_bytes || 0) }}</div>
      <!-- 工具较多,留在页面内(不传送到顶栏) -->
      <PageTools inline>
        <el-select v-if="isSuper" v-model="filterTenant" placeholder="全部组织" clearable style="width: 150px" @change="onTenantChange">
          <el-option v-for="t in tenants" :key="t.id" :label="t.name" :value="t.id" />
        </el-select>
        <el-select v-model="filterEnv" placeholder="全部环境" clearable filterable style="width: 190px" @change="load()">
          <el-option v-for="e in envOptions" :key="e.id" :label="envLabel(e)" :value="e.id" />
        </el-select>
        <el-button :icon="Refresh" circle title="刷新" @click="load()" />
        <el-tooltip content="已删除的实例在「实例 → 回收站」,可恢复或彻底删除" :show-after="300"><el-button :icon="Delete" @click="$router.push({ path: '/environments', query: { trash: 1 } })">实例回收站</el-button></el-tooltip>
        <el-tooltip v-if="filterEnv && envById(filterEnv) && can(envById(filterEnv), 'backup')" content="该实例的远程备份目标与自动备份设置" :show-after="300"><el-button :icon="Setting" @click="envCfgDlg = true">实例备份设置</el-button></el-tooltip>
        <el-button :icon="Upload" @click="openUpload">上传备份</el-button>
        <el-button v-if="backupableEnvs.length" type="primary" :icon="Plus" @click="openCreate">新建备份</el-button>
      </PageTools>
    </div>

    <!-- 统计 -->
    <el-row :gutter="12" style="margin-bottom: 12px">
      <el-col :span="6"><el-card shadow="never" class="stat-card tone-brand"><span class="stat-ic"><el-icon><FolderChecked /></el-icon></span><div class="label">备份总数</div><div class="value">{{ stats.total }}</div></el-card></el-col>
      <el-col :span="6"><el-card shadow="never" class="stat-card tone-blue"><span class="stat-ic"><el-icon><Coin /></el-icon></span><div class="label">占用空间</div><div class="value">{{ fmtSize(stats.total_bytes || 0) }}</div></el-card></el-col>
      <el-col :span="6"><el-card shadow="never" class="stat-card tone-orange"><span class="stat-ic"><el-icon><Loading /></el-icon></span><div class="label">进行中</div><div class="value">{{ stats.running }}</div></el-card></el-col>
      <el-col :span="6">
        <el-card shadow="never" class="stat-card tone-green"><span class="stat-ic"><el-icon><Timer /></el-icon></span>
          <div class="label">每日自动备份<span v-if="policyTenantId" class="muted"> · {{ tenantName(policyTenantId) }}</span><span v-else-if="isSuper" class="muted"> · 平台默认</span>
            <el-button v-if="canRunNow" link type="primary" size="small" style="margin-left: 6px" @click="runNow">立即执行</el-button>
          </div>
          <div class="value" style="font-size: 16px">
            <el-tag :type="stats.scheduler_enabled ? 'success' : 'info'" size="small">{{ stats.scheduler_enabled ? '已开启' : '未开启' }}</el-tag>
            <span class="muted" style="font-size: 12px; margin-left: 6px" v-if="stats.policy_mode === 'inherit'">(沿用平台默认)</span>
            <span class="muted" style="font-size: 12px; margin-left: 8px" v-if="stats.scheduler_enabled && stats.next_run">下次 {{ stats.next_run }}</span>
            <router-link v-if="policyTenantId && isOwnerOf(policyTenantId)" to="/tenant" class="muted" style="font-size: 12px; margin-left: 8px">去组织设置</router-link>
            <router-link v-else-if="!policyTenantId && isSuper" to="/settings" class="muted" style="font-size: 12px; margin-left: 8px">去系统设置</router-link>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <!-- 远程备份目标(用户自有 S3 / SFTP / WebDAV) -->
    <el-collapse v-model="targetsOpen" class="targets-collapse">
      <el-collapse-item name="t">
        <template #title><span style="font-weight: 600">远程备份目标</span><span class="muted" style="font-size: 12px; margin-left: 8px">把备份推送到你自己的服务器 / NAS / 对象存储;在各实例的「实例备份设置」里选择推送到哪些目标</span></template>
        <BackupTargets />
      </el-collapse-item>
    </el-collapse>

    <!-- 备份列表(手机端:卡片) -->
    <div v-if="isMobile" class="mlist" v-loading="loading">
      <div v-for="row in rows" :key="row.id" class="mcard">
        <div class="mc-head">
          <span class="ic" :class="`bk-${row.status}`"><el-icon v-if="row.status === 'running'" class="is-loading"><Loading /></el-icon><el-icon v-else><FolderChecked /></el-icon></span>
          <div class="mc-title">
            <div class="t">{{ row.env_name }} <span class="muted" style="font-weight: 400">/ {{ row.tenant_slug }}</span></div>
            <div class="s muted">{{ backupKindLabel(row.kind) }} · {{ fmtDate(row.created_at) }}<span v-if="row.created_by"> · {{ row.created_by }}</span></div>
          </div>
          <el-dropdown trigger="click" @command="(c) => ({ download, restore: openRestore, remove })[c]?.(row)">
            <el-button circle size="small"><el-icon><MoreFilled /></el-icon></el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item v-if="canDownload(row)" command="download" :disabled="row.status !== 'done'">下载</el-dropdown-item>
                <el-dropdown-item v-if="canRestoreAny(row)" command="restore" :disabled="row.status !== 'done'">恢复</el-dropdown-item>
                <el-dropdown-item v-if="canDeleteBackup(row)" command="remove" :disabled="row.status === 'running'" divided><span style="color: var(--danger)">删除</span></el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
        <div class="chips">
          <el-tag size="small" effect="dark" :type="backupStatusType(row.status)">{{ backupStatusLabel(row.status) }}</el-tag>
          <el-tag v-if="row.odoo_version" size="small" effect="plain" type="info">Odoo {{ row.odoo_version }}</el-tag>
          <el-tag size="small" effect="plain" type="info">{{ row.include_filestore ? '含 filestore' : '仅数据库' }}</el-tag>
          <el-tag v-if="row.status === 'done'" size="small" effect="plain" type="info">{{ fmtSize(row.size_bytes) }}</el-tag>
          <el-tag v-if="row.replica_status" size="small" effect="plain" :type="row.replica_status === 'done' ? 'success' : row.replica_status === 'failed' ? 'danger' : 'warning'">副本{{ row.replica_status === 'done' ? '已同步' : row.replica_status === 'failed' ? '失败' : '推送中' }}</el-tag>
          <el-tag v-for="r in row.replicas || []" :key="r.id" size="small" effect="plain" :type="r.status === 'done' ? 'success' : r.status === 'failed' ? 'danger' : r.status === 'pending' ? 'warning' : 'info'" @click="r.status === 'failed' && repush(row, r)">{{ r.target_name }}{{ r.status === 'done' ? '' : r.status === 'failed' ? ' 失败↻' : r.status === 'pending' ? ' 推送中' : '' }}</el-tag>
        </div>
        <div v-if="row.message || row.note" class="mc-foot"><span :style="row.status === 'failed' ? 'color: var(--danger)' : ''" class="muted">{{ row.status === 'done' ? (row.note || '') : row.message }}</span></div>
      </div>
      <EmptyState v-if="!loading && !rows.length" variant="backups" title="还没有备份" desc="可手动新建备份、上传已有备份文件,或在设置中开启每日自动备份">
        <el-button v-if="backupableEnvs.length" type="primary" :icon="Plus" @click="openCreate">新建备份</el-button>
      </EmptyState>
    </div>

    <!-- 备份列表 -->
    <el-card v-else shadow="never">
      <el-table :data="rows" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column label="组织 / 环境" min-width="160">
          <template #default="{ row }">
            <div>{{ row.tenant_slug }} / <b>{{ row.env_name }}</b></div>
            <div class="muted" style="font-size: 12px">{{ row.db_name || '' }}<span v-if="row.odoo_version"> · Odoo {{ row.odoo_version }}</span></div>
          </template>
        </el-table-column>
        <el-table-column label="类型" width="100">
          <template #default="{ row }"><el-tag size="small" :type="backupKindType(row.kind)" effect="plain">{{ backupKindLabel(row.kind) }}</el-tag></template>
        </el-table-column>
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag size="small" effect="dark" :type="backupStatusType(row.status)">
              <el-icon v-if="row.status === 'running'" class="is-loading" style="margin-right: 4px"><Loading /></el-icon>{{ backupStatusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="进度 / 备注" min-width="200" show-overflow-tooltip>
          <template #default="{ row }">
            <span v-if="row.status === 'running'" class="muted">{{ row.message }}</span>
            <span v-else-if="row.status === 'failed'" style="color: var(--danger)">{{ row.message }}</span>
            <span v-else>{{ row.note || '' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="大小" width="100"><template #default="{ row }">{{ row.status === 'done' ? fmtSize(row.size_bytes) : '-' }}</template></el-table-column>
        <el-table-column label="filestore" width="90"><template #default="{ row }">{{ row.include_filestore ? '含' : '不含' }}</template></el-table-column>
        <el-table-column label="远程副本" min-width="150">
          <template #default="{ row }">
            <template v-if="row.replicas && row.replicas.length">
              <el-tooltip v-for="r in row.replicas" :key="r.id" :show-after="200" :content="r.status === 'done' ? `${r.target_name}:已推送 ${fmtDate(r.pushed_at)}${r.sha256 ? ' · sha256 ' + r.sha256.slice(0, 12) + '…' : ''}` : r.status === 'failed' ? `${r.target_name}:推送失败(${r.attempts} 次):${r.error || ''}` : r.status === 'expired' ? `${r.target_name}:远端已按保留天数清理` : r.status === 'deleted' ? `${r.target_name}:远端已随本地删除` : `${r.target_name}:推送中 / 排队中`">
                <el-tag size="small" effect="plain" class="rtag" :type="r.status === 'done' ? 'success' : r.status === 'failed' ? 'danger' : r.status === 'pending' ? 'warning' : 'info'" @click="r.status === 'failed' && repush(row, r)">{{ r.target_name }}<span v-if="r.status === 'failed'"> ↻</span></el-tag>
              </el-tooltip>
            </template>
            <el-tooltip v-if="row.replica_status" :content="row.replica_status === 'done' ? `已推送 ${fmtDate(row.replica_at)}${row.sha256 ? ' · sha256 ' + row.sha256.slice(0, 12) + '…' : ''}` : row.replica_status === 'failed' ? `推送失败:${row.replica_error || ''}` : '推送中 / 排队中'" :show-after="200">
              <el-tag size="small" effect="plain" class="rtag" :type="row.replica_status === 'done' ? 'success' : row.replica_status === 'failed' ? 'danger' : 'warning'">平台副本{{ row.replica_status === 'done' ? '' : row.replica_status === 'failed' ? ' 失败' : ' 推送中' }}</el-tag>
            </el-tooltip>
            <span v-if="!row.replica_status && !(row.replicas && row.replicas.length)" class="muted">仅本地</span>
          </template>
        </el-table-column>
        <el-table-column prop="created_by" label="操作人" width="100" />
        <el-table-column label="时间" width="160"><template #default="{ row }">{{ fmtDate(row.created_at) }}</template></el-table-column>
        <el-table-column label="操作" :width="isMobile ? 64 : 200" fixed="right" align="right">
          <template #default="{ row }">
            <div v-if="!isMobile">
              <el-tooltip :disabled="canDownload(row)" content="下载需要该实例「可管理」权限或组织管理员(备份含数据库凭据)" :show-after="200"><span><el-button link type="primary" :disabled="row.status !== 'done' || !canDownload(row)" @click="download(row)">下载</el-button></span></el-tooltip>
              <el-button v-if="canRestoreAny(row)" link type="warning" :disabled="row.status !== 'done'" @click="openRestore(row)">恢复</el-button>
              <el-button v-if="canDeleteBackup(row)" link type="danger" :disabled="row.status === 'running'" @click="remove(row)">删除</el-button>
            </div>
            <el-dropdown v-else trigger="click" @command="(c) => ({ download, restore: openRestore, remove })[c]?.(row)">
              <el-button circle size="small"><el-icon><MoreFilled /></el-icon></el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item v-if="canDownload(row)" command="download" :disabled="row.status !== 'done'">下载</el-dropdown-item>
                  <el-dropdown-item v-if="canRestoreAny(row)" command="restore" :disabled="row.status !== 'done'">恢复</el-dropdown-item>
                  <el-dropdown-item v-if="canDeleteBackup(row)" command="remove" :disabled="row.status === 'running'" divided><span style="color: var(--danger)">删除</span></el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
        </el-table-column>
        <template #empty><EmptyState variant="backups" title="还没有备份" desc="可手动新建备份、上传已有备份文件,或在设置中开启每日自动备份"><el-button v-if="backupableEnvs.length" type="primary" :icon="Plus" @click="openCreate">新建备份</el-button></EmptyState></template>
      </el-table>
    </el-card>

    <!-- 恢复记录 -->
    <el-card shadow="never" style="margin-top: 16px">
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <span>最近恢复记录</span>
          <el-button link :icon="Refresh" @click="loadRestores">刷新</el-button>
        </div>
      </template>
      <el-table :data="restores" size="small" stripe empty-text="暂无恢复记录">
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column label="备份" width="80"><template #default="{ row }">#{{ row.backup_id ?? '-' }}</template></el-table-column>
        <el-table-column prop="env_name" label="目标环境" width="140" />
        <el-table-column label="中性化" width="80"><template #default="{ row }">{{ row.neutralize ? '是' : '否' }}</template></el-table-column>
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag size="small" effect="dark" :type="backupStatusType(row.status)">
              <el-icon v-if="row.status === 'running'" class="is-loading" style="margin-right: 4px"><Loading /></el-icon>{{ backupStatusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="message" label="说明" min-width="220" show-overflow-tooltip />
        <el-table-column prop="created_by" label="操作人" width="100" />
        <el-table-column label="时间" width="160"><template #default="{ row }">{{ fmtDate(row.created_at) }}</template></el-table-column>
        <el-table-column label="操作" width="80"><template #default="{ row }"><el-button link @click="openLog(row)">日志</el-button></template></el-table-column>
      </el-table>
    </el-card>

    <!-- 新建备份 -->
    <el-dialog v-model="createDlg" title="新建备份" width="520px">
      <el-form :model="createForm" label-width="100px">
        <el-form-item label="环境" required>
          <el-select v-model="createForm.environment_id" filterable style="width: 100%" placeholder="选择要备份的环境">
            <el-option v-for="e in backupableEnvs" :key="e.id" :label="envLabel(e)" :value="e.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="包含 filestore"><el-switch v-model="createForm.include_filestore" /><span class="muted" style="margin-left: 8px; font-size: 12px">附件文件;关闭则只备份数据库</span></el-form-item>
        <el-form-item label="备份位置">
          <el-radio-group v-model="createForm.location">
            <el-radio-button value="local">仅本地</el-radio-button>
            <el-radio-button value="remote">推送到远程</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item v-if="createForm.location === 'remote'" label="远程目标">
          <div style="width: 100%">
            <el-select v-if="createTargets.length" v-model="createForm.target_ids" multiple style="width: 100%" placeholder="选择要推送到的目标">
              <el-option v-for="t in createTargets" :key="t.id" :value="t.id" :label="`${t.name}(${({s3:'S3',sftp:'SFTP',webdav:'DAV'})[t.kind]||t.kind}) · ${t.describe}`" :disabled="!t.enabled" />
            </el-select>
            <div v-else class="muted" style="font-size: 12px">该环境所属组织下你还没有远程目标,先在下方「远程备份目标」里添加。</div>
            <div class="muted" style="font-size: 11.5px; margin-top: 4px">备份先落本地,完成后推送到所选目标。</div>
          </div>
        </el-form-item>
        <el-form-item label="备注"><el-input v-model="createForm.note" maxlength="256" placeholder="可选,如:上线前备份" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="createDlg = false">取消</el-button>
        <el-button type="primary" :loading="saving" :disabled="!createForm.environment_id || (createForm.location === 'remote' && !createForm.target_ids.length)" @click="doCreate">开始备份</el-button>
      </template>
    </el-dialog>

    <!-- 恢复 -->
    <el-dialog v-model="restoreDlg" title="恢复备份" width="560px">
      <el-alert type="warning" :closable="false" show-icon style="margin-bottom: 12px">
        恢复会<b>清空并覆盖</b>目标环境的数据库与 filestore,期间环境会短暂停机。请确认目标环境无误。
      </el-alert>
      <el-descriptions :column="1" size="small" border style="margin-bottom: 12px" v-if="restoreSrc">
        <el-descriptions-item label="备份">#{{ restoreSrc.id }} · {{ restoreSrc.tenant_slug }} / {{ restoreSrc.env_name }} · {{ fmtDate(restoreSrc.created_at) }}</el-descriptions-item>
        <el-descriptions-item label="来源版本">Odoo {{ restoreSrc.odoo_version || '未知' }} · {{ fmtSize(restoreSrc.size_bytes) }}</el-descriptions-item>
      </el-descriptions>
      <el-form :model="restoreForm" label-width="110px">
        <el-form-item label="恢复到环境" required>
          <el-select v-model="restoreForm.environment_id" filterable style="width: 100%" placeholder="选择目标环境(须已创建)">
            <el-option v-for="e in restoreTargets" :key="e.id" :label="envLabel(e) + (e.odoo_version !== restoreSrc?.odoo_version && restoreSrc?.odoo_version ? '  ⚠ 版本不同' : '')" :value="e.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="恢复前先备份"><el-switch v-model="restoreForm.backup_before" /><span class="muted" style="margin-left: 8px; font-size: 12px">先给目标环境做一次备份,便于回退</span></el-form-item>
        <el-form-item label="中性化">
          <el-switch v-model="restoreForm.neutralize" />
          <span class="muted" style="margin-left: 8px; font-size: 12px">停用定时任务 / 邮件 / 支付等并换掉数据库 uuid;恢复到测试/开发环境时建议开启</span>
        </el-form-item>
      </el-form>
      <el-alert v-if="restoreVersionMismatch" type="error" :closable="false" show-icon :title="`版本不一致:备份 Odoo ${restoreSrc?.odoo_version} → 目标 Odoo ${restoreTargetEnv?.odoo_version},点「确认恢复」后还需再确认一次`" />
      <el-alert v-else-if="restoreSrc && restoreSrc.include_filestore === false" type="info" :closable="false" show-icon title="该备份不含 filestore:只恢复数据库,目标环境现有附件文件保留" />
      <template #footer>
        <el-button @click="restoreDlg = false">取消</el-button>
        <el-button type="danger" :loading="saving" :disabled="!restoreForm.environment_id" @click="doRestore">确认恢复</el-button>
      </template>
    </el-dialog>

    <!-- 上传 -->
    <el-dialog v-model="uploadDlg" title="上传备份文件" width="520px">
      <el-form :model="uploadForm" label-width="100px">
        <el-form-item label="组织" required v-if="isSuper">
          <el-select v-model="uploadForm.tenant_id" style="width: 100%" @change="uploadForm.environment_id = null">
            <el-option v-for="t in tenants" :key="t.id" :label="t.name" :value="t.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="关联环境">
          <el-select v-model="uploadForm.environment_id" clearable filterable style="width: 100%" placeholder="可选,仅用于归档展示">
            <el-option v-for="e in envs.filter(x => x.tenant_id === uploadForm.tenant_id)" :key="e.id" :label="envLabel(e)" :value="e.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="备注"><el-input v-model="uploadForm.note" maxlength="256" /></el-form-item>
        <el-form-item label="文件" required>
          <el-upload ref="uploadRef" :auto-upload="false" :limit="1" accept=".zip" :on-change="onFileChange" :on-remove="() => (uploadFile = null)" drag style="width: 100%">
            <el-icon style="font-size: 32px; color: var(--text-3)"><UploadFilled /></el-icon>
            <div class="el-upload__text">拖拽或 <em>点击选择</em> Odoo 备份 zip</div>
            <template #tip><div class="el-upload__tip">须为 Odoo 数据库管理器导出的 zip(含 dump.sql、filestore/、manifest.json)</div></template>
          </el-upload>
          <el-progress v-if="uploadPct > 0 && uploadPct < 100" :percentage="uploadPct" style="width: 100%; margin-top: 8px" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="uploadDlg = false">取消</el-button>
        <el-button type="primary" :loading="saving" :disabled="!uploadFile || !uploadForm.tenant_id" @click="doUpload">上传</el-button>
      </template>
    </el-dialog>

    <!-- 实例备份设置(远程目标 + 自动备份覆盖) -->
    <el-dialog v-model="envCfgDlg" :title="`实例备份设置 — ${envById(filterEnv)?.name || ''}`" width="680px" destroy-on-close>
      <EnvBackupConfig v-if="envCfgDlg && envById(filterEnv)" :env="envById(filterEnv)" :editable="isSuper || can(envById(filterEnv), 'edit')" @saved="load(true)" />
      <template #footer><el-button @click="envCfgDlg = false">关闭</el-button></template>
    </el-dialog>

    <!-- 恢复日志 -->
    <el-dialog v-model="logDlg" :title="`恢复任务 #${logJob?.id || ''}`" width="760px" @closed="stopLogPoll">
      <div v-if="logJob" class="muted" style="font-size: 12px; margin-bottom: 8px">状态:<b :style="logJob.status === 'failed' ? 'color: var(--danger)' : logJob.status === 'done' ? 'color: var(--ok)' : ''">{{ logJob.status === 'running' ? '进行中' : logJob.status === 'done' ? '完成' : '失败' }}</b><span v-if="logJob.message"> · {{ logJob.message }}</span></div>
      <pre class="log">{{ logLines.length ? logLines.join(NL) : '(暂无日志)' }}</pre>
      <template #footer><el-button @click="logDlg = false">关闭</el-button></template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Plus, Refresh, Upload, UploadFilled, Loading, MoreFilled, FolderChecked, Coin, Timer, Delete, Setting } from '@element-plus/icons-vue'
import api from '../api'
import { currentTenant, isSuper, roleOf, can, tenants, loadTenants, tenantName } from '../store'
import { usePolling } from '../composables/usePolling'
import { useIsMobile } from '../composables/useMedia'
import { confirmDanger } from '../utils/confirm'
import { openLogStream } from '../composables/useLogStream'
import { backupKindLabel, backupKindType, backupStatusLabel, backupStatusType } from '../utils/labels'
import { fmtDate, fmtSize } from '../utils/format'
import { downloadBackup } from '../utils/download'
import EmptyState from '../components/EmptyState.vue'
import PageTools from '../components/PageTools.vue'
import BackupTargets from '../components/BackupTargets.vue'
import EnvBackupConfig from '../components/EnvBackupConfig.vue'

const route = useRoute()
const isMobile = useIsMobile()

const envs = ref([])
const rows = ref([])
const restores = ref([])
const stats = reactive({ total: 0, total_bytes: 0, running: 0, scheduler_enabled: false, next_run: null })
const loading = ref(false)
const saving = ref(false)
const filterTenant = ref(null)
const filterEnv = ref(null)

const envOptions = computed(() => envs.value.filter(e => !filterTenant.value || e.tenant_id === filterTenant.value))
// 统计卡片展示哪个组织的策略:非超管 = 当前组织;超管 = 筛选的组织(未选则平台默认)
const policyTenantId = computed(() => (isSuper.value ? filterTenant.value || null : currentTenant.value?.tenant_id || null))
const isOwnerOf = tid => isSuper.value || roleOf(tid) === 'owner'
const canRunNow = computed(() => (policyTenantId.value ? isOwnerOf(policyTenantId.value) : isSuper.value))
// 是否存在至少一个可恢复到的目标实例(决定「恢复」按钮显隐)
const canRestoreAny = row => envs.value.some(e => e.container_name && e.db_name && can(e, 'restore') && (isSuper.value || e.tenant_id === row.tenant_id))
const backupableEnvs = computed(() => envs.value.filter(e => e.db_name && can(e, 'backup')))
const envById = id => envs.value.find(e => e.id === id)
// 删除备份:组织管理员任意;开发者仅限非生产实例的备份
// 下载备份(整份数据库,含密码哈希 / 邮件 / API 凭据):实例「可管理」(my_role=owner)或组织管理员 / 超管
const canDownload = row => { const e = envById(row.environment_id); return isSuper.value || roleOf(row.tenant_id) === 'owner' || (!!e && e.my_role === 'owner') }
const canDeleteBackup = row => { const e = envById(row.environment_id); return isSuper.value || roleOf(row.tenant_id) === 'owner' || (!!e && e.kind !== 'production' && roleOf(row.tenant_id) === 'developer') }
const envLabel = e => `${tenantName(e.tenant_id)} / ${e.name}  (Odoo ${e.odoo_version} · ${e.kind})`

// ---- 加载 ----
async function load(silent = false) {
  if (!silent) loading.value = true
  try {
    const params = {}
    if (filterTenant.value) params.tenant_id = filterTenant.value
    if (filterEnv.value) params.environment_id = filterEnv.value
    const stParams = policyTenantId.value ? { tenant_id: policyTenantId.value } : {}
    const [list, st] = await Promise.all([api.get('/backups', { params, silent }), api.get('/backups/stats', { params: stParams, silent })])
    rows.value = list
    Object.assign(stats, st)
  } catch {} finally { loading.value = false }
}
async function loadRestores(silent = false) {
  try { restores.value = await api.get('/backups/restores/list', { params: { limit: 20, ...(filterTenant.value ? { tenant_id: filterTenant.value } : {}) }, silent }) } catch {}
}
async function loadEnvs() {
  try { envs.value = await api.get('/environments') } catch {}
}
function onTenantChange() { filterEnv.value = null; load(); loadRestores() }
const anyRunning = () => rows.value.some(r => r.status === 'running') || restores.value.some(r => r.status === 'running')
const poll = usePolling(async () => { await load(true); await loadRestores(true) }, { interval: 3000, immediate: false, when: anyRunning })

// ---- 远程目标 / 实例备份设置 ----
const targetsOpen = ref([])
const envCfgDlg = ref(false)
async function repush(row, r) {
  try { await api.post(`/backups/${row.id}/replicas/${r.target_id}/push`); ElMessage.success(`已重新推送到「${r.target_name}」`); setTimeout(() => load(true), 2500) } catch {}
}

// ---- 新建 ----
const createDlg = ref(false)
const createForm = reactive({ environment_id: null, include_filestore: true, note: '', location: 'local', target_ids: [] })
const createTargets = ref([])
async function loadCreateTargets() {
  createTargets.value = []
  const e = envById(createForm.environment_id)
  if (!e) return
  try { const c = await api.get(`/environments/${e.id}/backup-config`, { silent: true }); createTargets.value = (c.targets || []).filter(t => t.mine); createForm.target_ids = (c.target_ids || []).filter(id => createTargets.value.some(t => t.id === id)) } catch { createTargets.value = [] }
}
function openCreate() {
  Object.assign(createForm, { environment_id: filterEnv.value || null, include_filestore: true, note: '', location: 'local', target_ids: [] })
  createDlg.value = true
  if (createForm.environment_id) loadCreateTargets()
}
watch(() => createForm.environment_id, () => { if (createDlg.value) loadCreateTargets() })
watch(() => createForm.location, (v) => { if (v === 'remote') loadCreateTargets() })
async function doCreate() {
  saving.value = true
  try {
    await api.post('/backups', { environment_id: createForm.environment_id, include_filestore: createForm.include_filestore, note: createForm.note || null, location: createForm.location, target_ids: createForm.location === 'remote' ? createForm.target_ids : [] })
    ElMessage.success('备份已开始')
    createDlg.value = false
    await load(true)
  } catch {} finally { saving.value = false }
}

// ---- 恢复 ----
const restoreDlg = ref(false)
const restoreSrc = ref(null)
const restoreForm = reactive({ environment_id: null, neutralize: false, backup_before: true })
// 已创建完成的环境才能作为恢复目标;管理员可跨组织,普通用户仅限备份所属组织
const restoreTargets = computed(() => envs.value.filter(e =>
  e.container_name && e.db_name && can(e, 'restore') && (isSuper.value || e.tenant_id === restoreSrc.value?.tenant_id)))
function openRestore(row) {
  restoreSrc.value = row
  Object.assign(restoreForm, { environment_id: row.environment_id || null, neutralize: false, backup_before: true })
  restoreDlg.value = true
}
const restoreTargetEnv = computed(() => envs.value.find((e) => e.id === restoreForm.environment_id))
const restoreVersionMismatch = computed(() => !!(restoreSrc.value?.odoo_version && restoreTargetEnv.value && String(restoreTargetEnv.value.odoo_version) !== String(restoreSrc.value.odoo_version)))
async function doRestore() {
  let force = false
  if (restoreVersionMismatch.value) {
    // 大版本不同:后端默认拒绝,这里再要一次显式确认后带 force 放行
    const ok = await confirmDanger({ title: 'Odoo 版本不一致', message: `备份来自 Odoo ${restoreSrc.value.odoo_version},目标实例是 Odoo ${restoreTargetEnv.value.odoo_version}。跨大版本恢复后 Odoo 通常无法直接启动,需要另行升级数据库。确定仍要恢复?`, confirmText: '仍然恢复' })
    if (!ok) return
    force = true
  }
  saving.value = true
  try {
    const job = await api.post(`/backups/${restoreSrc.value.id}/restore`, { ...restoreForm, force })
    ElMessage.success('恢复已开始')
    restoreDlg.value = false
    await loadRestores(); await load(true)
    openLog(job)
  } catch {} finally { saving.value = false }
}

// ---- 上传 ----
const uploadDlg = ref(false)
const uploadRef = ref()
const uploadFile = ref(null)
const uploadPct = ref(0)
const uploadForm = reactive({ tenant_id: null, environment_id: null, note: '' })
function openUpload() {
  Object.assign(uploadForm, { tenant_id: isSuper.value ? (filterTenant.value || tenants.value[0]?.id || null) : currentTenant.value?.tenant_id, environment_id: null, note: '' })
  uploadFile.value = null; uploadPct.value = 0
  uploadDlg.value = true
}
function onFileChange(f) { uploadFile.value = f.raw }
async function doUpload() {
  saving.value = true
  try {
    // 直传:请求体就是文件本身(不经 multipart,后端边收边写盘,不再双写)
    const params = { tenant_id: uploadForm.tenant_id, filename: uploadFile.value.name }
    if (uploadForm.environment_id) params.environment_id = uploadForm.environment_id
    if (uploadForm.note) params.note = uploadForm.note
    await api.put('/backups/upload-stream', uploadFile.value, {
      params, headers: { 'Content-Type': 'application/zip' }, timeout: 0,
      onUploadProgress: ev => { if (ev.total) uploadPct.value = Math.round(ev.loaded * 100 / ev.total) },
    })
    ElMessage.success('上传成功')
    uploadDlg.value = false
    await load(true)
  } catch {} finally { saving.value = false }
}

// ---- 下载 / 删除 ----
async function download(row) {
  try {
    await downloadBackup(api, row.id)  // 直链 + 票据:浏览器原生流式下载,不占标签页内存
  } catch {}
}
async function remove(row) {
  if (!(await confirmDanger({ title: '删除备份', message: `删除备份 #${row.id}(${row.tenant_slug} / ${row.env_name},${fmtDate(row.created_at)})?文件将被移除,不可恢复。` }))) return
  try { await api.delete(`/backups/${row.id}`); ElMessage.success('已删除'); await load(true) } catch {}
}
async function runNow() {
  try {
    const url = policyTenantId.value ? `/backups/policy/${policyTenantId.value}/run-now` : '/backups/scheduler/run-now'
    const r = await api.post(url)
    ElMessage.success(r.started ? `已发起 ${r.started} 个实例的自动备份` : '没有符合策略的可备份实例')
    await load(true)
  } catch {}
}

// ---- 恢复日志 ----
const logDlg = ref(false)
const logJob = ref(null)
const logLines = ref([])
const NL = String.fromCharCode(10)
let logStream = null
// 恢复日志:优先 SSE(GET /backups/restores/{id}/log/stream),即时一行行推;SSE 不可用时回退 2 秒轮询
async function fetchLog() {
  if (!logJob.value) return
  try {
    logJob.value = await api.get(`/backups/restores/${logJob.value.id}`, { silent: true })
    logLines.value = (logJob.value.log || '').split(NL).filter(Boolean)
    if (logJob.value.status !== 'running') stopLogPoll()
  } catch { stopLogPoll() }
}
const logPoll = usePolling(fetchLog, { interval: 2000, immediate: true })
function openLog(job) {
  logJob.value = job; logLines.value = (job.log || '').split(NL).filter(Boolean); logDlg.value = true
  logStream?.close(); logStream = null
  let errs = 0
  logStream = openLogStream(`/backups/restores/${job.id}/log/stream`, {}, {
    onReset: () => { logLines.value = [] },
    onLine: (_k, text) => { logLines.value.push(text); if (logLines.value.length > 2000) logLines.value.splice(0, logLines.value.length - 2000) },
    onEnd: async () => { logStream = null; try { logJob.value = await api.get(`/backups/restores/${job.id}`, { silent: true }) } catch {}; await loadRestores(); await load(true) },
    onError: () => { if (logStream?.closed || ++errs >= 3) { logStream?.close(); logStream = null; logPoll.restart() } },  // 401/404 时 EventSource 直接 CLOSED,只回调一次,也要回退轮询
  })
}
function stopLogPoll() { logPoll.stop(); logStream?.close(); logStream = null }

onMounted(async () => {
  try { await loadTenants() } catch {}
  await loadEnvs()
  if (!isSuper.value) filterTenant.value = currentTenant.value?.tenant_id || null  // 非超管固定看当前组织
  if (route.query.env) {
    filterEnv.value = Number(route.query.env)
    const e = envs.value.find(x => x.id === filterEnv.value)
    if (e) filterTenant.value = e.tenant_id
  }
  await Promise.all([load(), loadRestores()])
  poll.start()
})
</script>

<style scoped>
.rtag { margin: 1px 4px 1px 0; cursor: default; }
.rtag.el-tag--danger { cursor: pointer; }
.targets-collapse { margin-bottom: 12px; border: none; }
.targets-collapse :deep(.el-collapse-item__header) { background: transparent; border: none; height: 36px; }
.targets-collapse :deep(.el-collapse-item__wrap) { border: none; background: transparent; }
.targets-collapse :deep(.el-collapse-item__content) { padding-bottom: 0; }
.log { max-height: 60vh; overflow: auto; white-space: pre-wrap; word-break: break-all; margin: 0; }
.mcard .ic { background: var(--ok-bg); color: var(--ok); }
.mcard .ic.bk-running { background: var(--warn-bg); color: var(--warn); }
.mcard .ic.bk-failed { background: var(--danger-bg); color: var(--danger); }
</style>
