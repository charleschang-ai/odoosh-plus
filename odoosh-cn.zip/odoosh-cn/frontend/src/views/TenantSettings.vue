<template>
  <div class="page" v-if="tenant">
    <div class="page-header">
      <div>
        <h2>组织设置</h2>
        <div class="desc">{{ tenant.tenant_name }} · <span class="mono">{{ tenant.tenant_slug }}</span></div>
      </div>
    </div>
    <div class="layout">
      <div class="col-l">
        <el-card shadow="never">
          <template #header>基本信息</template>
          <el-form :model="form" label-position="top">
            <el-form-item label="标识"><el-input :model-value="tenant.tenant_slug" disabled /><div class="muted help">用于容器与域名命名,创建后不可改</div></el-form-item>
            <el-form-item label="名称"><el-input v-model="form.name" /></el-form-item>
            <el-form-item label="说明"><el-input v-model="form.description" type="textarea" :rows="3" /></el-form-item>
            <el-form-item label="开发实例闲置休眠(小时)">
              <el-input-number v-model="form.sleep_idle_hours" :min="0" :max="8760" :step="1" :precision="1" controls-position="right" placeholder="平台默认" style="width: 200px" />
              <div class="muted help">本组织开发实例无人访问超过该小时数自动休眠;访问域名或点「打开」会自动唤醒(约 10 秒)。留空 = 平台默认{{ defaults.sleep_idle_hours != null ? `(${defaults.sleep_idle_hours} 小时)` : '' }};0 = 不休眠。每个实例还可在「设置」里单独覆盖。生产 / 测试实例永不休眠。</div>
            </el-form-item>
            <el-button type="primary" :loading="saving" :disabled="!dirty" @click="save">保存</el-button>
          </el-form>
        </el-card>
        <el-card shadow="never" class="domain-card">
          <template #header>实例域名</template>
          <div class="muted help" style="line-height: 1.8">
            本组织实例的默认域名格式:<br /><code>&lt;实例名&gt;.{{ tenant.tenant_slug }}.{{ defaults.base_domain || '<基础域名>' }}</code><br />
            如需自定义域名,可在实例的「编辑」中单独指定。
          </div>
        </el-card>
      </div>
      <div class="col-r">
        <el-card shadow="never">
          <template #header>成员</template>
          <Members :tenant-id="tenant.tenant_id" embedded />
        </el-card>
      </div>
    </div>
  </div>
  <el-empty v-else description="您尚未加入任何组织,请联系平台管理员" />
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../api'
import Members from './Members.vue'
import { currentTenant, loadSession, loadTenants, defaults, loadDefaults } from '../store'

const tenant = currentTenant
const form = reactive({ name: '', description: '', sleep_idle_hours: null })
let saved = { name: '', description: '', sleep_idle_hours: null }
const saving = ref(false)
const dirty = computed(() => form.name !== saved.name || form.description !== saved.description || (form.sleep_idle_hours ?? null) !== (saved.sleep_idle_hours ?? null))

async function load() {
  if (!tenant.value) return
  try {
    const list = await loadTenants(true)
    const t = list.find((x) => x.id === tenant.value.tenant_id)
    if (t) { saved = { name: t.name, description: t.description || '', sleep_idle_hours: t.sleep_idle_hours ?? null }; Object.assign(form, saved) }
  } catch {}
  loadDefaults()
}
async function save() {
  saving.value = true
  try { await api.put(`/tenants/${tenant.value.tenant_id}`, { name: form.name, description: form.description, sleep_idle_hours: form.sleep_idle_hours ?? null }); saved = { ...form }; ElMessage.success('已保存'); await loadSession(); loadTenants(true) } catch {} finally { saving.value = false }
}
onMounted(load)
watch(() => tenant.value?.tenant_id, load)
</script>

<style scoped>
.layout { display: grid; grid-template-columns: 360px minmax(0, 1fr); gap: 16px; align-items: start; }
.col-l { display: grid; gap: 16px; }
.help { font-size: 12.5px; margin-top: 4px; }
.domain-card :deep(.el-card__body) { padding-top: 14px; }
:deep(.embedded .el-card) { border: none; box-shadow: none; }
:deep(.embedded .el-card__body) { padding: 0; }
@media (max-width: 1000px) { .layout { grid-template-columns: 1fr; } }
</style>
