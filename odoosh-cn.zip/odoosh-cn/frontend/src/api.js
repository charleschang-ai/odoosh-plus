import axios from 'axios'
import { ElMessage } from 'element-plus'
// 不在模块顶层 import router:api ← router ← store ← api 会形成循环依赖,
// 某些打包/加载顺序下会触发「Cannot access X before initialization」TDZ 报错。
// router 只在 401 跳登录时才需要,改为按需动态引入,彻底断开这条环。

/** API 前缀的唯一来源:其他地方(SSE / WebSocket)请用 API_BASE 拼接,不要写死 '/api' */
export const API_BASE = '/api'
export const MASKED = '••••••••' // 后端返回的脱敏占位(密钥类设置项)
export const getToken = () => localStorage.getItem('token')

const api = axios.create({ baseURL: API_BASE, timeout: 15000 })

api.interceptors.request.use((cfg) => {
  const token = getToken()
  if (token) cfg.headers.Authorization = `Bearer ${token}`
  return cfg
})

let redirecting = false
function toLogin() {
  if (redirecting) return
  redirecting = true
  localStorage.removeItem('token')
  import('./router').then(({ default: router }) => {
    const cur = router.currentRoute.value
    if (cur.path === '/login') { redirecting = false; return }
    router.replace({ path: '/login', query: cur.fullPath && cur.fullPath !== '/' ? { redirect: cur.fullPath } : {} })
      .finally(() => { redirecting = false })
  }).catch(() => { redirecting = false })
}

/** 从错误响应里提取人话;blob 响应(下载失败)也尝试解析 JSON */
async function extractDetail(err) {
  const data = err.response?.data
  let msg = data?.detail
  if (data instanceof Blob) {
    try { const parsed = JSON.parse(await data.text()); msg = parsed?.detail || msg } catch {}
  }
  if (msg === undefined || msg === null) {
    if (!err.response) return err.code === 'ECONNABORTED' ? '请求超时,请稍后重试' : '网络异常或服务不可用'
    msg = err.response.status >= 500 ? `服务器错误(${err.response.status})` : err.message
  }
  // 422 校验错误是数组:只显示人话(去掉 "Value error, " 前缀),不显示原始 JSON
  if (typeof msg === 'string') return msg
  if (Array.isArray(msg)) return msg.map((e) => (e.msg || '').replace(/^Value error, /, '') || `${(e.loc || []).slice(-1)[0]} 格式不正确`).join(';')
  try { return JSON.stringify(msg) } catch { return String(msg) }
}

api.interceptors.response.use(
  (res) => res.data,
  async (err) => {
    if (axios.isCancel?.(err)) return Promise.reject(err)
    const status = err.response?.status
    const silent = !!err.config?.silent
    const isLogin = /\/auth\/login$/.test(err.config?.url || '')
    if (status === 401 && !isLogin) { toLogin(); return Promise.reject(err) } // 不提示,直接回登录页(登录接口本身的 401 要提示)
    const text = await extractDetail(err)
    err.detail = text
    if (!silent) ElMessage.error(text)
    return Promise.reject(err)
  },
)

export default api
