import { createRouter, createWebHistory } from 'vue-router'
import { session, loadSession, isSuper, isOwner, isDeveloper, menuVisible } from './store'
import { brandFull } from './brand'

// meta.need: 'super' | 'owner' | 'developer'(未标注 = 所有登录用户)
const routes = [
  { path: '/login', component: () => import('./views/Login.vue'), meta: { public: true, title: '登录' } },
  // 第三方系统免登回调:用 handoff(console)给的一次性 code 换登录态,再进实例列表 / 指定实例
  { path: '/auth/callback', component: () => import('./views/AuthCallback.vue'), meta: { public: true, title: '登录中' } },
  {
    path: '/',
    component: () => import('./views/Layout.vue'),
    children: [
      { path: '', redirect: '/environments' },
      { path: 'dashboard', component: () => import('./views/Dashboard.vue'), meta: { title: '总览', need: 'developer' } },
      { path: 'environments', component: () => import('./views/Environments.vue'), meta: { title: '实例' } },
      { path: 'ai', component: () => import('./views/AiChat.vue'), meta: { title: 'AI 助手' } },
      { path: 'environments/:id(\\d+)', component: () => import('./views/Project.vue'), meta: { title: '实例详情', need: 'developer' } },
      { path: 'projects/:id(\\d+)', redirect: (to) => `/environments/${to.params.id}` },
      { path: 'repos', component: () => import('./views/Repos.vue'), meta: { title: 'Git 仓库', need: 'developer' } },
      { path: 'backups', component: () => import('./views/Backups.vue'), meta: { title: '备份与恢复', need: 'developer' } },
      { path: 'tenant', component: () => import('./views/TenantSettings.vue'), meta: { title: '组织设置', need: 'owner' } },
      { path: 'members', redirect: '/tenant' },
      { path: 'tenants', component: () => import('./views/Tenants.vue'), meta: { title: '组织与成员', need: 'super' } },
      { path: 'users', component: () => import('./views/Users.vue'), meta: { title: '用户', need: 'super' } },
      { path: 'docker', component: () => import('./views/DockerCenter.vue'), meta: { title: 'Docker', need: 'super' } },
      { path: 'images', redirect: { path: '/docker', query: { tab: 'images' } } },
      { path: 'settings', component: () => import('./views/Settings.vue'), meta: { title: '系统设置', need: 'super' } },
      { path: 'maintenance', component: () => import('./views/Maintenance.vue'), meta: { title: '平台维护', need: 'super' } },
      { path: ':pathMatch(.*)*', component: () => import('./views/NotFound.vue'), meta: { title: '页面不存在' } },
    ],
  },
]

const router = createRouter({ history: createWebHistory(), routes })

router.beforeEach(async (to) => {
  if (to.meta.public) return true
  if (!localStorage.getItem('token')) return { path: '/login', query: to.fullPath && to.fullPath !== '/' ? { redirect: to.fullPath } : {} }
  if (!session.loaded) {
    try { await loadSession() } catch { return '/login' }
  }
  const need = to.meta.need
  if (need === 'super' && !isSuper.value) return '/environments'
  if (need === 'owner' && !isOwner.value) return '/environments'
  if (need === 'developer' && !isDeveloper.value) return '/environments'
  // 每用户菜单开关:被关掉的菜单直接输网址也进不去
  const menuKey = { '/dashboard': 'dashboard', '/repos': 'repos', '/ai': 'ai', '/backups': 'backups' }[to.path]
  if (menuKey && !menuVisible(menuKey)) return '/environments'
  return true
})
router.afterEach((to) => {
  document.title = to.meta?.title ? `${to.meta.title} · ${brandFull.value}` : brandFull.value
})

export default router
