<template>
  <!-- 侧栏导航:桌面侧栏与手机抽屉共用。新增菜单项请在此处添加(class 决定图标配色)。 -->
  <el-menu :default-active="route.path" router :collapse="collapse" :collapse-transition="false" class="nav" @select="$emit('navigate')">
    <div v-if="!collapse" class="group">工作台</div>
    <el-menu-item index="/dashboard" v-if="!isTester && menuVisible('dashboard')" class="c-violet"><el-icon><Odometer /></el-icon><template #title>总览</template></el-menu-item>
    <el-menu-item index="/environments" class="c-blue" :class="{ 'is-active': route.path.startsWith('/environments/') }"><el-icon><Box /></el-icon><template #title>实例</template></el-menu-item>
    <el-menu-item index="/ai" v-if="menuVisible('ai')" class="c-violet"><el-icon><MagicStick /></el-icon><template #title>AI 助手</template></el-menu-item>
    <el-menu-item index="/repos" v-if="isDeveloper && menuVisible('repos')" class="c-orange"><el-icon><Connection /></el-icon><template #title>Git 仓库</template></el-menu-item>
    <el-menu-item index="/backups" v-if="isDeveloper && menuVisible('backups')" class="c-green"><el-icon><FolderChecked /></el-icon><template #title>备份与恢复</template></el-menu-item>
    <!-- 组织设置:仅普通组织管理员的自助入口;超管改用下方「组织与成员」(全平台),避免两个组织菜单重复 -->
    <el-menu-item index="/tenant" v-if="isOwner && !isSuper && currentTenant" class="c-teal"><el-icon><OfficeBuilding /></el-icon><template #title>组织设置</template></el-menu-item>
    <template v-if="isSuper">
      <div class="group" :class="{ tight: collapse }"><span v-if="!collapse">平台管理</span></div>
      <el-menu-item index="/tenants" class="c-teal"><el-icon><OfficeBuilding /></el-icon><template #title>组织与成员</template></el-menu-item>
      <el-menu-item index="/users" class="c-pink"><el-icon><User /></el-icon><template #title>用户</template></el-menu-item>
      <el-menu-item index="/docker" class="c-indigo"><el-icon><Cpu /></el-icon><template #title>Docker</template></el-menu-item>
      <el-menu-item index="/settings" class="c-gray"><el-icon><Setting /></el-icon><template #title>系统设置</template></el-menu-item>
      <el-menu-item index="/maintenance" class="c-gray"><el-icon><RefreshRight /></el-icon><template #title>平台维护</template></el-menu-item>
    </template>
  </el-menu>
</template>

<script setup>
import { useRoute } from 'vue-router'
import { Odometer, Box, Connection, FolderChecked, OfficeBuilding, User, Cpu, Setting, RefreshRight, MagicStick } from '@element-plus/icons-vue'
import { currentTenant, isSuper, isOwner, isDeveloper, isTester, menuVisible } from '../store'

defineProps({ collapse: { type: Boolean, default: false } })
defineEmits(['navigate'])
const route = useRoute()
</script>

<style scoped>
.nav { border-right: none; background: transparent; padding: 0 10px; --el-menu-text-color: #aab4c3; --el-menu-active-color: #fff; --el-menu-hover-text-color: #fff; --el-menu-hover-bg-color: rgba(255, 255, 255, .06); --el-menu-item-height: 40px; --el-menu-base-level-padding: 10px; }
.nav.el-menu--collapse { width: 100%; padding: 0 12px; }
.group { font-size: 11px; color: #667385; letter-spacing: .08em; padding: 16px 12px 6px; text-transform: uppercase; }
.group.tight { padding: 8px 0 0; border-top: 1px solid rgba(255, 255, 255, .06); margin-top: 8px; }
.nav :deep(.el-menu-item) { border-radius: 8px; margin: 2px 0; font-size: 13.5px; font-weight: 500; position: relative; }
/* 图标:小色块 + 各自配色 */
.nav :deep(.el-menu-item .el-icon) { width: 26px; height: 26px; border-radius: 7px; font-size: 15px; margin-right: 10px; color: var(--ic); background: var(--ic-bg); transition: background-color .15s, color .15s; }
.nav :deep(.el-menu-item.is-active) { background: rgba(255, 255, 255, .1); color: #fff; }
.nav :deep(.el-menu-item.is-active .el-icon) { background: var(--ic); color: #fff; }
.nav :deep(.el-menu-item.is-active)::before { content: ''; position: absolute; left: -10px; top: 10px; bottom: 10px; width: 3px; border-radius: 0 3px 3px 0; background: var(--ic); }
.nav.el-menu--collapse :deep(.el-menu-item) { padding: 0 !important; justify-content: center; }
.nav.el-menu--collapse :deep(.el-menu-item.is-active)::before { left: -12px; }
.nav.el-menu--collapse :deep(.el-menu-item .el-icon) { margin: 0; }
.c-violet { --ic: #a78bfa; --ic-bg: rgba(167, 139, 250, .16); }
.c-blue   { --ic: #60a5fa; --ic-bg: rgba(96, 165, 250, .16); }
.c-orange { --ic: #fb923c; --ic-bg: rgba(251, 146, 60, .16); }
.c-green  { --ic: #4ade80; --ic-bg: rgba(74, 222, 128, .16); }
.c-teal   { --ic: #2dd4bf; --ic-bg: rgba(45, 212, 191, .16); }
.c-pink   { --ic: #f472b6; --ic-bg: rgba(244, 114, 182, .16); }
.c-sky    { --ic: #38bdf8; --ic-bg: rgba(56, 189, 248, .16); }
.c-indigo { --ic: #818cf8; --ic-bg: rgba(129, 140, 248, .16); }
.c-gray   { --ic: #cbd5e1; --ic-bg: rgba(203, 213, 225, .14); }
</style>
