<template>
  <!--
    实例授权名单编辑器(仿 odoo.sh 项目协作者):
    - 两种用法:① 绑定 envId → 直接读写 /environments/{id}/acl(编辑已存在实例);② 只给 tenantId + v-model → 纯前端收集(新建实例时)
    - 名单成员只能从该组织成员里选;拥有者与超管不需在名单里
  -->
  <div class="acl" v-loading="loading">
    <div class="owner-row" v-if="envId">
      <span class="k">拥有者</span>
      <span class="who"><span class="avatar">{{ initials(ownerName) }}</span>{{ ownerName || '(未指定,按组织角色)' }}<span v-if="ownerId === session.me?.id" class="me">我</span></span>
      <el-button v-if="canTransfer && candidates.length" link type="primary" size="small" @click="transferDlg = true">转让</el-button>
    </div>
    <div class="hint muted" v-if="!envId">你自己会成为拥有者(全部权限);还可以从组织成员里挑选协作者:</div>

    <div class="entries">
      <div v-for="e in list" :key="e.user_id" class="entry">
        <span class="avatar">{{ initials(e.display_name || e.username) }}</span>
        <div class="who-t"><div class="n">{{ e.display_name || e.username }}</div><div class="s muted mono">{{ e.username }}</div></div>
        <el-select :model-value="e.level" size="small" class="lv" :disabled="readonly" @change="(v) => setLevel(e, v)">
          <el-option v-for="o in LEVELS" :key="o.value" :value="o.value" :label="o.label"><span>{{ o.label }}</span><span class="muted opt-d">{{ o.desc }}</span></el-option>
        </el-select>
        <el-button v-if="!readonly" circle size="small" :icon="Close" @click="removeEntry(e)" />
      </div>
      <div v-if="!list.length" class="none muted">尚未添加协作者:除拥有者与超级管理员外,其他人看不到这个实例</div>
    </div>

    <div class="add" v-if="!readonly">
      <el-select v-model="pick" filterable placeholder="添加组织成员…" size="default" class="pick" :no-data-text="tenantId ? '没有可添加的成员(先在组织设置里添加)' : '请先选择组织'">
        <el-option v-for="c in available" :key="c.user_id" :value="c.user_id" :label="c.display_name ? `${c.display_name}(${c.username})` : c.username" />
      </el-select>
      <el-select v-model="pickLevel" size="default" class="pick-lv">
        <el-option v-for="o in LEVELS" :key="o.value" :value="o.value" :label="o.label" />
      </el-select>
      <el-button :disabled="!pick" @click="addPick">添加</el-button>
    </div>
    <div class="legend muted">
      <span><b>可访问</b>:打开 Odoo、看日志与监控</span><span><b>可操作</b>:再加启停 / 重启 / 部署 / 备份恢复 / Shell(生产实例只能启动、重启、备份);<b>不能</b>改设置、删除或改名单</span><span><b>可管理</b>:与拥有者同权——编辑设置、删除、修改本名单</span>
    </div>

    <el-dialog v-model="transferDlg" title="转让拥有者" width="420px" append-to-body>
      <p class="muted" style="margin: 0 0 12px; font-size: 13px">新拥有者获得全部权限;你会自动进入名单为「可管理」。</p>
      <el-select v-model="transferTo" filterable placeholder="选择新拥有者" style="width: 100%">
        <el-option v-for="c in candidates" :key="c.user_id" :value="c.user_id" :label="c.display_name ? `${c.display_name}(${c.username})` : c.username" />
      </el-select>
      <template #footer>
        <el-button @click="transferDlg = false">取消</el-button>
        <el-button type="primary" :disabled="!transferTo" :loading="saving" @click="transfer">转让</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { Close } from '@element-plus/icons-vue'
import api from '../../api'
import { session, isSuper } from '../../store'
import { initials } from '../../utils/format'

const props = defineProps({
  envId: { type: Number, default: null },
  tenantId: { type: Number, default: null },
  modelValue: { type: Array, default: () => [] }, // [{user_id, level}](新建模式)
  readonly: { type: Boolean, default: false },
  ownerUserId: { type: Number, default: null },
})
const emit = defineEmits(['update:modelValue', 'changed'])

const LEVELS = [
  { value: 'view', label: '可访问', desc: '打开 / 日志 / 监控' },
  { value: 'operate', label: '可操作', desc: '运维,不改设置' },
  { value: 'manage', label: '可管理', desc: '编辑 / 删除 / 名单' },
]
const loading = ref(false); const saving = ref(false)
const candidates = ref([])   // 组织成员(不含拥有者 / 超管)
const entries = ref([])      // 编辑模式:服务端名单
const ownerId = ref(null); const ownerName = ref('')
const pick = ref(null); const pickLevel = ref('view')
const transferDlg = ref(false); const transferTo = ref(null)

const canTransfer = computed(() => isSuper.value || (ownerId.value && ownerId.value === session.me?.id))
const list = computed(() => {
  if (props.envId) return entries.value
  const byId = Object.fromEntries(candidates.value.map((c) => [c.user_id, c]))
  return props.modelValue.map((m) => ({ ...(byId[m.user_id] || { user_id: m.user_id, username: `#${m.user_id}` }), level: m.level }))
})
const available = computed(() => { const used = new Set(list.value.map((e) => e.user_id)); return candidates.value.filter((c) => !used.has(c.user_id)) })

async function load() {
  if (props.envId) {
    loading.value = true
    try {
      const st = await api.get(`/environments/${props.envId}/acl`, { silent: true })
      entries.value = st.entries; candidates.value = st.candidates; ownerId.value = st.owner_user_id; ownerName.value = st.owner_username || ''
    } catch {} finally { loading.value = false }
  } else if (props.tenantId) {
    loading.value = true
    try {
      const rows = await api.get(`/tenants/${props.tenantId}/members`, { silent: true })
      candidates.value = rows.filter((r) => r.is_active && r.user_id !== session.me?.id).map((r) => ({ user_id: r.user_id, username: r.username, display_name: r.display_name }))
    } catch { candidates.value = [] } finally { loading.value = false }
  } else candidates.value = []
}
async function persist(next) {
  if (props.envId) {
    saving.value = true
    try { const st = await api.put(`/environments/${props.envId}/acl`, next.map((e) => ({ user_id: e.user_id, level: e.level }))); entries.value = st.entries; candidates.value = st.candidates; emit('changed') } catch {} finally { saving.value = false }
  } else emit('update:modelValue', next.map((e) => ({ user_id: e.user_id, level: e.level })))
}
function setLevel(e, v) { persist(list.value.map((x) => (x.user_id === e.user_id ? { ...x, level: v } : x))) }
function removeEntry(e) { persist(list.value.filter((x) => x.user_id !== e.user_id)) }
function addPick() { if (!pick.value) return; persist([...list.value, { user_id: pick.value, level: pickLevel.value }]); pick.value = null }
async function transfer() {
  saving.value = true
  try { const st = await api.put(`/environments/${props.envId}/owner`, { user_id: transferTo.value }); entries.value = st.entries; candidates.value = st.candidates; ownerId.value = st.owner_user_id; ownerName.value = st.owner_username || ''; transferDlg.value = false; transferTo.value = null; ElMessage.success('已转让'); emit('changed') } catch {} finally { saving.value = false }
}
onMounted(load)
watch(() => [props.envId, props.tenantId], load)
defineExpose({ reload: load })
</script>

<style scoped>
.acl { display: flex; flex-direction: column; gap: 10px; }
.owner-row { display: flex; align-items: center; gap: 10px; font-size: 13px; }
.owner-row .k { color: var(--text-3); }
.who { display: inline-flex; align-items: center; gap: 8px; font-weight: 600; }
.me { font-size: 11px; font-weight: 500; color: var(--brand); background: var(--brand-50); border-radius: 4px; padding: 0 5px; }
.hint { font-size: 12.5px; }
.entries { display: flex; flex-direction: column; gap: 6px; }
.entry { display: flex; align-items: center; gap: 10px; padding: 8px 10px; border: 1px solid var(--line-2); border-radius: 10px; background: var(--surface-2); }
.avatar { width: 28px; height: 28px; border-radius: 50%; background: var(--brand-100); color: var(--brand-600); font-size: 11px; font-weight: 700; display: inline-flex; align-items: center; justify-content: center; flex: none; }
.who-t { flex: 1; min-width: 0; }
.who-t .n { font-weight: 600; font-size: 13.5px; }
.who-t .s { font-size: 11.5px; }
.lv { width: 118px; }
.opt-d { float: right; font-size: 11.5px; margin-left: 12px; }
.none { font-size: 12.5px; padding: 6px 2px; }
.add { display: flex; gap: 8px; align-items: center; }
.pick { flex: 1; }
.pick-lv { width: 110px; }
.legend { font-size: 11.5px; display: flex; flex-direction: column; gap: 2px; line-height: 1.5; }
.legend b { font-weight: 600; color: var(--text-2); }
</style>
