<template>
  <!-- 部署历史抽屉:<DeployHistoryDrawer v-model="show" :env="env" /> -->
  <el-drawer v-model="visible" :title="`部署历史 — ${env?.name || ''}`" size="720px" @open="load">
    <el-table :data="history" size="small" v-loading="loading" highlight-current-row @row-click="(r) => (cur = r)">
      <el-table-column label="#" prop="id" width="60" />
      <el-table-column label="提交" width="90"><template #default="{ row }"><span class="mono">{{ shortSha(row.commit_sha) }}</span></template></el-table-column>
      <el-table-column label="信息" min-width="200" show-overflow-tooltip prop="commit_message" />
      <el-table-column label="触发" width="80"><template #default="{ row }">{{ triggerLabel(row.trigger) }}</template></el-table-column>
      <el-table-column label="动作" width="110"><template #default="{ row }">{{ actionShort(row.action, row.modules) }}</template></el-table-column>
      <el-table-column label="状态" width="90"><template #default="{ row }"><el-tag size="small" :type="depType(row.status)">{{ depShortLabel(row.status) }}</el-tag></template></el-table-column>
      <el-table-column label="耗时" width="80"><template #default="{ row }">{{ shortDuration(row.duration) }}</template></el-table-column>
      <el-table-column label="时间" width="150"><template #default="{ row }">{{ fmtDate(row.created_at) }}</template></el-table-column>
    </el-table>
    <div class="muted small" style="margin: 8px 0 4px">点击一行查看该次部署的日志</div>
    <DeployLog v-if="cur && env" :env-id="env.id" :dep="cur" @finished="load" />
  </el-drawer>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import api from '../../api'
import DeployLog from './DeployLog.vue'
import { triggerLabel, actionShort, depType, depShortLabel } from '../../utils/labels'
import { fmtDate, shortSha, shortDuration } from '../../utils/format'

const props = defineProps({ modelValue: Boolean, env: { type: Object, default: null } })
const emit = defineEmits(['update:modelValue'])
const visible = computed({ get: () => props.modelValue, set: (v) => emit('update:modelValue', v) })
const history = ref([]); const loading = ref(false); const cur = ref(null)
async function load() {
  if (!props.env) return
  loading.value = true
  try { history.value = await api.get(`/environments/${props.env.id}/deployments`) } catch {} finally { loading.value = false }
}
watch(() => props.env?.id, () => { history.value = []; cur.value = null })
</script>

<style scoped>
.small { font-size: 12px; }
</style>
