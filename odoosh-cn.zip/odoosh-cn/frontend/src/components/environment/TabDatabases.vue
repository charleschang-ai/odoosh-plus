<template>
  <!--
    数据库 Tab(项目页 / 实例总览抽屉共用):一个实例 = 1 个主库 + N 个附加库,全部共用实例代码。
    用法:<TabDatabases :env="env" :perms="perms" :active="tab === 'databases'" @changed="load(true)" />
    perms 为 {kind: {action: bool}} 时按 env.kind 取;不传则用 store.can(env, action)
  -->
  <div class="dbs">
    <div class="bar">
      <div class="code-line muted small">
        <el-icon><Connection /></el-icon>
        <span>本实例代码:<b>{{ data?.code_summary || '—' }}</b> — 所有数据库共用此代码</span>
        <el-tooltip content="附加库与主库跑在同一容器、同一份代码上;想要别的分支的库,请到该分支的实例里创建" placement="top"><el-icon class="help"><QuestionFilled /></el-icon></el-tooltip>
      </div>
      <span class="spacer" />
      <span v-if="data" class="quota" :class="{ full: data.enabled && !data.allowed_now }" :title="quotaTip">附加库 {{ data.used }}/{{ data.limit }}<template v-if="data.tenant_limit != null"> · 组织 {{ data.tenant_used }}/{{ data.tenant_limit }}</template><template v-if="data.user_limit != null"> · 我 {{ data.user_used }}/{{ data.user_limit }}</template></span>
      <el-button size="small" :icon="Refresh" @click="load()">刷新</el-button>
      <el-tooltip :disabled="!createDisabledReason" :content="createDisabledReason || ''" placement="top">
        <span><el-button type="primary" size="small" :icon="Plus" :disabled="!!createDisabledReason" @click="openCreate">新建数据库</el-button></span>
      </el-tooltip>
    </div>
    <el-alert v-if="data && !data.enabled" type="info" :closable="false" show-icon class="note" :title="data.reason || '本实例不支持附加数据库'" />

    <el-table :data="rows" v-loading="loading" size="small" stripe empty-text="暂无数据库">
      <el-table-column label="名称" min-width="140">
        <template #default="{ row }">
          <span class="name"><el-icon v-if="row.is_primary" class="star" title="主库(随实例创建,不可单独删除)"><StarFilled /></el-icon>{{ row.name }}</span>
          <div class="muted mono tiny">{{ row.db_name }}</div>
          <div v-if="!row.is_primary && row.admin_login && row.admin_login !== 'admin'" class="muted tiny">登录名 {{ row.admin_login }}</div>
        </template>
      </el-table-column>
      <el-table-column label="域名" min-width="220" show-overflow-tooltip>
        <template #default="{ row }">
          <a v-if="row.url && row.status === 'ready' && canOpen" href="#" class="link" @click.prevent="open(row)">{{ row.domain }}</a>
          <span v-else class="muted">{{ row.domain || '—' }}</span>
        </template>
      </el-table-column>
      <el-table-column label="大小" width="90"><template #default="{ row }">{{ row.size_bytes != null ? fmtSize(row.size_bytes) : '—' }}</template></el-table-column>
      <el-table-column label="状态" width="150">
        <template #default="{ row }">
          <template v-if="rowBusy(row)">
            <el-tag size="small" type="warning" effect="plain"><el-icon class="is-loading" style="margin-right: 3px"><Loading /></el-icon>{{ dbStatusLabel(row.status) }}</el-tag>
            <div class="tiny muted ell" :title="row.status_message">{{ row.status_message }}</div>
            <el-progress v-if="row.progress" :percentage="row.progress" :stroke-width="4" :show-text="false" style="margin-top: 2px" />
          </template>
          <el-tag v-else-if="row.status === 'failed'" size="small" type="danger" effect="plain" :title="row.status_message">失败</el-tag>
          <template v-else>
            <el-tag size="small" type="success" effect="plain">就绪</el-tag>
            <div v-if="row.status_message" class="tiny warn ell" :title="row.status_message">{{ row.status_message }}</div>
          </template>
        </template>
      </el-table-column>
      <el-table-column label="来源 / 创建" width="150">
        <template #default="{ row }">
          <template v-if="row.is_primary"><span class="muted">随实例创建</span></template>
          <template v-else>
            <div>{{ sourceLabel(row.source) }}<span v-if="row.source === 'clone' && row.source_ref" class="muted"> ← {{ row.source_ref }}</span></div>
            <div class="tiny muted">{{ row.created_by || '' }} · {{ fmtDate(row.created_at) }}</div>
          </template>
        </template>
      </el-table-column>
      <el-table-column label="过期" width="110">
        <template #default="{ row }">
          <span v-if="row.is_primary" class="muted">跟随实例</span>
          <span v-else-if="row.expires_at" :class="{ warn: within(row.expires_at, 48) }" :title="fmtDateTime(row.expires_at)">{{ fmtDate(row.expires_at) }}</span>
          <span v-else class="muted">不过期</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" :width="isEnt ? 360 : 230" fixed="right">
        <template #default="{ row }">
          <el-button v-if="canOpen" link type="primary" size="small" :disabled="row.status !== 'ready' || !openable || (!row.is_primary && !row.url)" :title="!row.is_primary && !row.url ? '端口直连访问模式下附加库无法按域名访问' : ''" @click="open(row)">打开</el-button>
          <el-button v-if="isEnt" link type="warning" size="small" :disabled="row.status !== 'ready'" :title="canRenew ? `查看 / 延长「${row.name}」(${row.db_name})的企业版到期时间` : `查看「${row.name}」(${row.db_name})的企业版到期时间(延长需要恢复权限)`" @click="openLicense(row)"><el-icon style="margin-right: 2px"><Timer /></el-icon>企业版到期</el-button>
          <el-button v-if="canDo('backup')" link size="small" :disabled="row.status !== 'ready' || envBusy" @click="backup(row)">备份</el-button>
          <el-button v-if="canDo('clone') && data?.allowed_now" link size="small" :disabled="row.status !== 'ready'" @click="openCreate({ source: 'clone', source_ref: row.db_name })">克隆</el-button>
          <el-dropdown trigger="click" @command="(c) => onMore(c, row)">
            <el-button link size="small">更多<el-icon class="el-icon--right"><ArrowDown /></el-icon></el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item v-if="canDo('restore') && !row.is_primary" command="restore" :disabled="row.status !== 'ready' && row.status !== 'failed'">恢复备份到此库…</el-dropdown-item>
                <el-dropdown-item v-if="canDo('restore') && !row.is_primary" command="neutralize" :disabled="row.status !== 'ready'">中性化(停 cron / 邮件 / 支付)</el-dropdown-item>
                <el-dropdown-item v-if="canDo('shell') && !row.is_primary && shellVisible" command="shell" :disabled="row.status !== 'ready'">在 Shell 中打开</el-dropdown-item>
                <el-dropdown-item v-if="canDo('secrets') && !row.is_primary" command="secrets" divided :disabled="row.status !== 'ready'">查看管理员密码</el-dropdown-item>
                <el-dropdown-item v-if="canDo('restore') && canDo('secrets') && !row.is_primary" command="reset" :disabled="row.status !== 'ready'">重置管理员密码</el-dropdown-item>
                <el-dropdown-item v-if="canDo('restore') && !row.is_primary" command="expire" :disabled="rowBusy(row)">设置过期…</el-dropdown-item>
                <el-dropdown-item v-if="canDo('clone') && row.status === 'failed'" command="retry" divided>重试创建</el-dropdown-item>
                <el-dropdown-item v-if="canDo('restore') && !row.is_primary" command="delete" divided :disabled="rowBusy(row)"><span style="color: var(--danger)">删除数据库</span></el-dropdown-item>
                <el-dropdown-item v-if="row.is_primary" disabled>主库随实例管理(备份 / 恢复见「备份」Tab)</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
    <div class="muted small tips">
      附加库 = 在本实例容器里多建一个 PostgreSQL 数据库,不多开容器;域名为 <code>&lt;名称&gt;.{{ env.domain || '实例域名' }}</code>。
      部署 / 重启 / 休眠作用于整个实例(所有库);备份 / 恢复 / 中性化 / 一键登录按库独立。删除附加库前默认自动备份一份。
    </div>

    <!-- 企业版到期时间(本地测试库临时续期) -->
    <el-dialog v-model="licDlg" :title="`企业版到期时间 — ${licRow?.name || ''}(${licRow?.db_name || ''})`" width="460px" :close-on-click-modal="false">
      <div v-loading="licLoading">
        <el-descriptions :column="1" size="small" border style="margin-bottom: 12px">
          <el-descriptions-item label="数据库"><code>{{ lic.db_name }}</code></el-descriptions-item>
          <el-descriptions-item label="创建时间">{{ lic.create_date || '—' }}</el-descriptions-item>
          <el-descriptions-item label="当前到期">
            <span :class="{ warn: lic.expired || (lic.expiration_date && within(lic.expiration_date, 72)) }">{{ lic.expiration_date || '未设置' }}</span>
            <el-tag v-if="lic.expired" size="small" type="danger" effect="plain" style="margin-left: 6px">已过期</el-tag>
            <el-tag v-else-if="lic.expiration_date" size="small" type="success" effect="plain" style="margin-left: 6px">有效</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="原因">{{ lic.expiration_reason || '—' }}</el-descriptions-item>
          <el-descriptions-item label="订阅码">{{ lic.enterprise_code || '未绑定' }}<el-tag v-if="lic.real_subscription" size="small" type="warning" effect="plain" style="margin-left: 6px">真实订阅,不可改</el-tag></el-descriptions-item>
          <el-descriptions-item label="UUID"><code class="tiny">{{ lic.uuid || '—' }}</code></el-descriptions-item>
        </el-descriptions>
        <el-alert v-if="!canRenew" type="info" :closable="false" show-icon style="margin-bottom: 10px"
                  title="你可以查看到期时间,但没有延长的权限(需要该实例的「恢复」权限,通常是组织管理员 / 实例拥有者)。" />
        <el-form label-width="80px" @submit.prevent>
          <el-form-item label="新到期日">
            <el-date-picker v-model="licDate" type="date" value-format="YYYY-MM-DD" :clearable="false" :disabled="!canRenew" :disabled-date="(d) => d.getTime() < Date.now() - 86400000" style="width: 180px" />
            <el-button link size="small" style="margin-left: 8px" :disabled="!canRenew" @click="licPlus(30)">+30 天</el-button>
            <el-button link size="small" :disabled="!canRenew" @click="licPlus(90)">+3 个月</el-button>
            <el-button link size="small" :disabled="!canRenew" @click="licPlus(180)">+6 个月</el-button>
            <el-button link size="small" :disabled="!canRenew" @click="licPlus(365)">+1 年</el-button>
          </el-form-item>
        </el-form>
        <div class="muted tiny">仅供本地测试库临时使用:确认后会把 <code>database.create_date</code> 设为今天、<code>database.expiration_date</code> 设为所选日期,并重新生成 <code>database.secret</code> / <code>database.uuid</code>(所有已登录会话会失效,需重新登录)。已绑定真实订阅码的库不会被修改。立即生效,无需重启。</div>
      </div>
      <template #footer>
        <el-button @click="licDlg = false">关闭</el-button>
        <el-button type="primary" :loading="saving" :disabled="!licDate || lic.real_subscription || !canRenew"
                   :title="!canRenew ? '没有延长权限' : lic.real_subscription ? '已绑定真实订阅码的库不可修改' : ''" @click="doLicense">确认续期</el-button>
      </template>
    </el-dialog>

    <!-- 新建:上半部分 = Odoo 原生「创建数据库」表单;下半部分 = 平台自己的选项 -->
    <el-dialog v-model="dlg" title="新建数据库" width="620px" :close-on-click-modal="false" @closed="resetForm">
      <el-form label-width="96px" @submit.prevent>
        <el-form-item label="数据库名" required>
          <el-input v-model="form.name" maxlength="20" placeholder="如 shop / test1 / demo" @input="form.name = form.name.toLowerCase().replace(/[^a-z0-9]/g, '')">
            <template #append>.{{ env.domain }}</template>
          </el-input>
        </el-form-item>
        <template v-if="form.source === 'empty'">
          <el-form-item label="邮箱"><el-input v-model="form.login" placeholder="admin" /><span class="hint">作为登录名;留空 = admin</span></el-form-item>
          <el-form-item label="密码">
            <el-input v-model="form.password" show-password placeholder="留空自动生成" style="width: 260px" />
            <el-button link size="small" style="margin-left: 8px" @click="form.password = genPwd()">随机生成</el-button>
          </el-form-item>
          <el-form-item label="手机号"><el-input v-model="form.phone" placeholder="可选" style="width: 260px" /></el-form-item>
          <el-form-item label="语言">
            <el-select v-model="form.lang" filterable style="width: 260px" :loading="optLoading">
              <el-option v-for="l in opts.langs" :key="l.code" :value="l.code" :label="l.name" />
            </el-select>
          </el-form-item>
          <el-form-item label="国家">
            <el-select v-model="form.country_code" filterable clearable style="width: 260px" :loading="optLoading">
              <el-option v-for="c in opts.countries" :key="c.code" :value="c.code" :label="c.name" />
            </el-select>
          </el-form-item>
          <el-form-item label="演示数据"><el-checkbox v-model="form.demo">加载演示数据</el-checkbox></el-form-item>
        </template>
        <el-divider content-position="left"><span class="muted small">平台选项</span></el-divider>
        <el-form-item label="数据来源">
          <el-radio-group v-model="form.source">
            <el-radio value="empty">新建空库</el-radio>
            <el-radio value="clone" :disabled="!cloneSources.length">克隆本实例的库</el-radio>
            <el-radio value="backup">从备份恢复</el-radio>
          </el-radio-group>
          <div class="hint block">{{ form.source === 'empty' ? '按上面填写的信息初始化(与 Odoo 自带的「创建数据库」一样)' : form.source === 'clone' ? '复制所选库的数据库与 filestore,登录信息与源库相同' : '用一份已完成的备份初始化,登录信息与备份相同' }}</div>
        </el-form-item>
        <el-form-item v-if="form.source === 'clone'" label="克隆源">
          <el-select v-model="form.source_ref" style="width: 100%">
            <el-option v-for="r in cloneSources" :key="r.db_name" :value="r.db_name" :label="`${r.name}(${r.db_name})`" />
          </el-select>
        </el-form-item>
        <el-form-item v-if="form.source === 'backup'" label="备份">
          <el-select v-model="form.backup_id" style="width: 100%" placeholder="选择备份" filterable :loading="bkLoading">
            <el-option v-for="b in backups" :key="b.id" :value="String(b.id)" :label="`#${b.id} ${b.db_name || ''} · ${fmtSize(b.size_bytes)} · ${fmtDate(b.created_at)}${b.note ? ' · ' + b.note : ''}`" />
          </el-select>
        </el-form-item>
        <el-form-item v-if="form.source !== 'empty'" label="中性化">
          <el-switch v-model="form.neutralize" /><span class="hint">停用定时任务 / 外发邮件 / 支付;克隆生产数据时建议开启</span>
        </el-form-item>
        <el-form-item label="过期">
          <el-select v-model="form.expire_days" style="width: 200px">
            <el-option :value="-1" label="平台默认" />
            <el-option :value="0" label="不过期" />
            <el-option v-for="d in [7, 14, 30, 90]" :key="d" :value="d" :label="`${d} 天后自动删除`" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="muted small foot">库名 <span class="mono">{{ env.db_name }}_{{ form.name || '…' }}</span>,共用本实例代码</span>
        <el-button @click="dlg = false">取消</el-button>
        <el-button type="primary" :loading="saving" :disabled="!form.name" @click="doCreate">创建</el-button>
      </template>
    </el-dialog>

    <!-- 恢复备份到附加库 -->
    <el-dialog v-model="rsDlg" :title="`恢复备份到 ${rsRow?.name || ''}`" width="560px">
      <el-select v-model="rsBackup" style="width: 100%" placeholder="选择备份" filterable :loading="bkLoading">
        <el-option v-for="b in backups" :key="b.id" :value="b.id" :label="`#${b.id} ${b.db_name || ''} · ${fmtSize(b.size_bytes)} · ${fmtDate(b.created_at)}${b.note ? ' · ' + b.note : ''}`" />
      </el-select>
      <el-form label-width="96px" style="margin-top: 12px">
        <el-form-item label="中性化"><el-switch v-model="rsNeutralize" /></el-form-item>
        <el-form-item label="恢复前备份"><el-switch v-model="rsBackupBefore" /><span class="hint">先给该库做一次备份再覆盖</span></el-form-item>
      </el-form>
      <div class="muted small">该库的数据与 filestore 将被覆盖;实例其他库不受影响、容器不停。</div>
      <template #footer>
        <el-button @click="rsDlg = false">取消</el-button>
        <el-button type="warning" :disabled="!rsBackup" :loading="saving" @click="doRestore">恢复</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage, ElMessageBox, ElNotification } from 'element-plus'
import { Refresh, Plus, Loading, ArrowDown, StarFilled, Connection, QuestionFilled, Timer } from '@element-plus/icons-vue'
import api from '../../api'
import { session, can as storeCan } from '../../store'
import { usePolling } from '../../composables/usePolling'
import { confirmDanger } from '../../utils/confirm'
import { isBusy } from '../../utils/labels'
import { fmtDate, fmtDateTime, fmtSize, within } from '../../utils/format'
import { openEnv, canOpenNow } from '../../utils/openEnv'

const props = defineProps({ env: Object, perms: { type: Object, default: null }, active: { type: Boolean, default: true } })
const emit = defineEmits(['changed', 'shell'])
const data = ref(null); const loading = ref(false)
const rows = computed(() => data.value?.items || [])
const envBusy = computed(() => isBusy(props.env))
const isEnt = computed(() => props.env.edition === 'enterprise')
const openable = computed(() => canOpenNow(props.env))
const shellVisible = computed(() => !!(session.me?.is_superadmin || session.me?.shell_enabled))
const canDo = (a) => (props.perms ? !!props.perms[props.env.kind]?.[a] : storeCan(props.env, a))
const canOpen = computed(() => canDo('open'))
// 「企业版到期」:只要是企业版实例就显示(查看用 view 权限);延长需要 restore 权限,无权限时只读
const canRenew = computed(() => canDo('restore'))
const DB_BUSY = ['creating', 'dropping', 'restoring']
const rowBusy = (r) => DB_BUSY.includes(r.status)
const dbStatusLabel = (s) => ({ creating: '创建中', dropping: '删除中', restoring: '恢复中', ready: '就绪', failed: '失败' })[s] || s
const sourceLabel = (s) => ({ empty: '空库', template: '模板库', clone: '克隆', backup: '备份恢复' })[s] || s || ''
const quotaTip = computed(() => data.value ? `本实例最多 ${data.value.limit} 个附加库${data.value.tenant_limit != null ? `;组织总量上限 ${data.value.tenant_limit}` : ''}${data.value.user_limit != null ? `;你的账号最多可创建 ${data.value.user_limit} 个` : ''}` : '')
const createDisabledReason = computed(() => {
  if (!data.value) return '加载中'
  if (!canDo('clone')) return '你没有在本实例创建数据库的权限'
  if (!data.value.enabled) return data.value.reason || '不支持'
  if (!data.value.allowed_now) return data.value.reason || '已达上限'
  if (!props.env.container_name || !props.env.db_name) return '实例尚未创建完成'
  if (envBusy.value) return '实例正忙,请稍候'
  return ''
})

async function load(silent = false) {
  if (!silent) loading.value = true
  try { data.value = await api.get(`/environments/${props.env.id}/databases`, { silent }) } catch {} finally { loading.value = false }
}
const prev = new Map()
watch(rows, (list) => {
  for (const r of list) {
    if (r.is_primary) continue
    const p = prev.get(r.id)
    if (p && DB_BUSY.includes(p) && !DB_BUSY.includes(r.status)) {
      if (r.status === 'failed') ElNotification.error({ title: `数据库「${r.name}」操作失败`, message: r.status_message || '', duration: 8000 })
      else ElNotification.success({ title: `数据库「${r.name}」已就绪`, message: r.url || '', duration: 5000 })
      emit('changed')
    }
    prev.set(r.id, r.status)
  }
})
const poll = usePolling(() => load(true), { intervalFn: () => (rows.value.some(rowBusy) ? 2500 : 15000), immediate: false, when: () => props.active })
watch(() => props.env.id, () => { data.value = null; load() })
onMounted(() => { load(); poll.start() })

// ---- 打开 / 备份 ----
function open(row) { openEnv(props.env, { databaseId: row.is_primary ? null : row.id, url: row.url }) }
async function backup(row) {
  let note = ''
  try { const r = await ElMessageBox.prompt('备注(可选)', `备份 — ${row.name}`, { confirmButtonText: '开始备份', inputPlaceholder: '如:改动前备份' }); note = r.value || '' } catch { return }
  try { await api.post('/backups', { environment_id: props.env.id, database_id: row.is_primary ? null : row.id, note: note || null, include_filestore: true }); ElMessage.success('备份已开始,可在「备份」Tab 查看') } catch {}
}

// ---- 新建(上半 Odoo 原生表单 + 下半平台选项)----
const dlg = ref(false); const saving = ref(false)
const BLANK = { name: '', login: '', password: '', phone: '', lang: 'zh_CN', country_code: 'cn', demo: false, source: 'empty', source_ref: '', backup_id: '', neutralize: true, expire_days: -1 }
const form = reactive({ ...BLANK })
const cloneSources = computed(() => rows.value.filter((r) => r.status === 'ready'))
const backups = ref([]); const bkLoading = ref(false)
const opts = ref({ langs: [], countries: [] }); const optLoading = ref(false)
function resetForm() { Object.assign(form, BLANK) }
function genPwd() { const a = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let s = ''; for (let i = 0; i < 12; i++) s += a[Math.floor(Math.random() * a.length)]; return s }
async function loadOptions() {
  if (opts.value.langs.length) return
  optLoading.value = true
  try { opts.value = await api.get(`/environments/${props.env.id}/databases/options`, { silent: true }) } catch {} finally { optLoading.value = false }
  if (props.env.lang && opts.value.langs.some((l) => l.code === props.env.lang)) form.lang = props.env.lang  // 默认跟实例主库同语言
  if (!opts.value.langs.some((l) => l.code === form.lang)) form.lang = opts.value.langs[0]?.code || 'en_US'
}
async function loadBackups() {
  bkLoading.value = true
  try { const list = await api.get('/backups', { params: { tenant_id: props.env.tenant_id, limit: 300 }, silent: true }); backups.value = (list || []).filter((b) => b.status === 'done' && (!b.odoo_version || String(b.odoo_version) === String(props.env.odoo_version))) } catch {} finally { bkLoading.value = false }
}
function openCreate(preset = null) {
  resetForm()
  if (preset) Object.assign(form, preset)
  if (!form.source_ref && cloneSources.value.length) form.source_ref = cloneSources.value[0].db_name
  dlg.value = true
  loadOptions()
  if (form.source === 'backup') loadBackups()
}
watch(() => form.source, (s) => { if (s === 'backup' && !backups.value.length) loadBackups() })
async function doCreate() {
  saving.value = true
  try {
    await api.post(`/environments/${props.env.id}/databases`, {
      name: form.name, source: form.source, source_ref: form.source === 'clone' ? form.source_ref : form.source === 'backup' ? form.backup_id : null,
      login: form.login || null, password: form.password || null, phone: form.phone || null, lang: form.lang || null, country_code: form.country_code || null, demo: form.demo,
      neutralize: form.neutralize, expire_days: form.expire_days < 0 ? null : form.expire_days,
    })
    ElMessage.success('开始创建,完成后会提示'); dlg.value = false; load(true); emit('changed')
  } catch {} finally { saving.value = false }
}

// ---- 更多 ----
const rsDlg = ref(false); const rsRow = ref(null); const rsBackup = ref(null); const rsNeutralize = ref(true); const rsBackupBefore = ref(true)
async function onMore(cmd, row) {
  const base = `/environments/${props.env.id}/databases/${row.id}`
  if (cmd === 'restore') { rsRow.value = row; rsBackup.value = null; rsNeutralize.value = props.env.kind !== 'production'; rsBackupBefore.value = true; rsDlg.value = true; loadBackups(); return }
  if (cmd === 'neutralize') {
    try { await ElMessageBox.confirm(`对数据库「${row.name}」执行中性化:停用定时任务、外发邮件、支付服务商与第三方集成,并打上中和标记。`, '中性化', { type: 'warning', confirmButtonText: '执行' }) } catch { return }
    try { await api.post(`${base}/neutralize`); ElMessage.success('已开始'); load(true) } catch {}
    return
  }
  if (cmd === 'shell') { emit('shell', row); return }
  if (cmd === 'secrets') {
    try { const r = await api.get(`${base}/secrets`); ElMessageBox.alert(`数据库:${r.db_name}
登录名:${r.login}
密码:${r.password}`, `管理员密码 — ${row.name}`, { confirmButtonText: '关闭', customClass: 'pre-alert' }) } catch {}
    return
  }
  if (cmd === 'reset') {
    if (!(await confirmDanger({ title: '重置管理员密码', message: `为数据库「${row.name}」的 Odoo admin 生成新的随机密码并写入,旧密码立即失效。`, confirmText: '重置', danger: false }))) return
    try { const r = await api.post(`${base}/reset-admin`); ElMessageBox.alert(`新密码:${r.password}`, '已重置', { confirmButtonText: '关闭', customClass: 'pre-alert' }) } catch {}
    return
  }
  if (cmd === 'expire') {
    try {
      const r = await ElMessageBox.prompt('多少天后自动删除该数据库?0 = 不过期', `设置过期 — ${row.name}`, { inputPattern: /^\d{1,4}$/, inputErrorMessage: '请输入 0~9999 的整数', inputValue: row.expires_at ? '' : '0' })
      await api.put(base, { expire_days: Number(r.value) }); ElMessage.success('已更新'); load(true)
    } catch {}
    return
  }
  if (cmd === 'retry') { try { await api.post(`${base}/retry`); ElMessage.success('已重新排队'); load(true) } catch {} return }
  if (cmd === 'delete') {
    if (!(await confirmDanger({ title: '删除数据库', message: `删除附加数据库「${row.name}」(${row.db_name})及其 filestore;删除前会自动备份一份到备份列表。实例其他库不受影响。`, requireText: row.name, inputLabel: `请输入数据库名「${row.name}」以确认:` }))) return
    try { await api.delete(base, { data: { confirm_name: row.name } }); ElMessage.success('开始删除'); load(true); emit('changed') } catch {}
  }
}
// ---- 企业版到期时间 ----
const licDlg = ref(false); const licRow = ref(null); const licLoading = ref(false); const lic = ref({}); const licDate = ref('')
function licBase(row) { return `/environments/${props.env.id}/databases/license` + (row.is_primary ? '' : `?database_id=${row.id}`) }
function licPlus(days) { const d = new Date(Date.now() + days * 86400000); licDate.value = d.toISOString().slice(0, 10) }
async function openLicense(row) {
  licRow.value = row; lic.value = {}; licDate.value = ''; licDlg.value = true; licLoading.value = true
  try { lic.value = await api.get(licBase(row)); licDate.value = (lic.value.expiration_date || '').slice(0, 10) } catch {} finally { licLoading.value = false }
  if (!licDate.value) licPlus(30)
}
async function doLicense() {
  if (!licRow.value || !licDate.value) return
  try { await ElMessageBox.confirm(`将数据库「${licRow.value.name}」的到期时间改为 ${licDate.value},创建时间改为今天,并重新生成 secret / uuid(当前登录会话会失效)。`, '确认续期', { type: 'warning', confirmButtonText: '确认' }) } catch { return }
  saving.value = true
  try {
    lic.value = await api.put(`/environments/${props.env.id}/databases/license`, { database_id: licRow.value.is_primary ? null : licRow.value.id, expiration_date: licDate.value })
    ElMessage.success(`已更新,新到期时间 ${lic.value.expiration_date}`)
  } catch {} finally { saving.value = false }
}
async function doRestore() {
  if (!rsRow.value || !rsBackup.value) return
  saving.value = true
  try {
    await api.post(`/backups/${rsBackup.value}/restore`, { environment_id: props.env.id, database_id: rsRow.value.id, neutralize: rsNeutralize.value, backup_before: rsBackupBefore.value })
    ElMessage.success('恢复已开始'); rsDlg.value = false; load(true)
  } catch {} finally { saving.value = false }
}
// openLicensePrimary:实例详情「更多 → 企业版到期」直接打开主库的弹窗(不必等表格数据加载)
function openLicensePrimary() {
  openLicense({ is_primary: true, name: '主库', db_name: props.env.db_name, status: 'ready' })
}
defineExpose({ load, openLicensePrimary })
</script>

<style scoped>
.bar { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
.spacer { flex: 1; }
.small { font-size: 12px; }
.tiny { font-size: 11.5px; line-height: 1.4; }
.code-line { display: inline-flex; align-items: center; gap: 6px; }
.code-line .help { color: var(--text-3); cursor: help; }
.quota { font-size: 12px; font-weight: 600; padding: 2px 9px; border-radius: 999px; background: #f1f5f9; color: #475569; }
.quota.full { background: #fef2f2; color: #b91c1c; }
.note { margin-bottom: 10px; }
.name { display: inline-flex; align-items: center; gap: 4px; font-weight: 600; }
.star { color: #f59e0b; }
.link { color: var(--brand); text-decoration: none; }
.link:hover { text-decoration: underline; }
.warn { color: #b45309; }
.ell { max-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tips { margin-top: 10px; line-height: 1.7; }
.hint { font-size: 12px; color: var(--text-3); margin-left: 8px; }
.hint.block { margin-left: 0; display: block; line-height: 1.5; }
.foot { flex: 1; text-align: left; align-self: center; }
</style>
