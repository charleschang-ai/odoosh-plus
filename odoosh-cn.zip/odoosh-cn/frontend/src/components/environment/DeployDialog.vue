<template>
  <!--
    部署对话框(实例卡片 / 项目页历史共用)。
    用法:<DeployDialog v-model="show" :env="env" :commit="sha|null" :pick-commit="true" @deployed="load" />
    - pick-commit=true:显示提交列表可选(不选 = 分支最新);false:只显示动作表单,部署 props.commit(或最新)
  -->
  <el-dialog v-model="visible" :title="title" :width="pickCommit ? '720px' : '480px'" @open="onOpen">
    <template v-if="pickCommit">
      <div class="dep-head muted">仓库 {{ env?.repo_url }} · 当前 <span class="mono">{{ shortSha(env?.code_commit) }}</span>
        <el-button link size="small" :loading="loading" @click="loadCommits(true)">从远端刷新</el-button></div>
      <el-table :data="commits" v-loading="loading" size="small" max-height="320" highlight-current-row @current-change="(r) => (form.commit = r?.sha || null)" class="commit-table">
        <el-table-column width="36"><template #default="{ row }"><el-radio v-model="form.commit" :value="row.sha"><span /></el-radio></template></el-table-column>
        <el-table-column label="提交" width="90"><template #default="{ row }"><span class="mono">{{ shortSha(row.sha) }}</span></template></el-table-column>
        <el-table-column label="信息" min-width="240" show-overflow-tooltip><template #default="{ row }">{{ row.message }}</template></el-table-column>
        <el-table-column label="作者" width="110" show-overflow-tooltip prop="author" />
        <el-table-column label="时间" width="150"><template #default="{ row }">{{ fmtDate(row.committed_at) }}</template></el-table-column>
        <el-table-column label="状态" width="120">
          <template #default="{ row }">
            <el-tag v-if="row.is_current" size="small" type="success" effect="dark">当前</el-tag>
            <el-tag v-else-if="row.deployment" size="small" :type="depType(row.deployment.status)" effect="plain">{{ row.deployment.status === 'success' ? '曾部署' : depLabel(row.deployment.status) }}</el-tag>
            <span v-else class="muted">未部署</span>
          </template>
        </el-table-column>
      </el-table>
      <div v-if="error" class="muted" style="font-size: 12px; margin-top: 6px; color: var(--danger)">{{ error }}</div>
    </template>
    <el-form label-width="90px" :style="pickCommit ? 'margin-top: 14px' : ''">
      <el-form-item label="部署动作">
        <el-radio-group v-model="form.action">
          <el-radio-button v-for="a in DEPLOY_ACTIONS" :key="a.value" :value="a.value">{{ a.label }}</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item v-if="form.action === 'update'" label="模块"><el-input v-model="form.modules" placeholder="模块名,逗号分隔" /></el-form-item>
      <el-form-item v-if="form.action !== 'restart' && dbs.length > 1" label="升级数据库">
        <el-checkbox-group v-model="form.databases" class="db-cbs">
          <el-checkbox v-for="d in dbs" :key="d.db_name" :value="d.db_name">{{ d.is_primary ? '主库' : d.name }}<span class="muted mono tiny"> {{ d.db_name }}</span></el-checkbox>
        </el-checkbox-group>
        <div class="muted tiny">代码切换对所有库生效;这里只决定对哪些库执行 -u。未勾选的库只换代码不跑升级,请自行处理。</div>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="muted foot-tip">{{ form.commit ? `将部署 ${shortSha(form.commit)}` : '将部署分支最新提交' }};失败会自动回退到当前版本</span>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" :loading="saving" @click="doDeploy">开始部署</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../../api'
import { DEPLOY_ACTIONS, depType, depLabel } from '../../utils/labels'
import { fmtDate, shortSha } from '../../utils/format'

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  env: { type: Object, default: null },
  commit: { type: String, default: null }, // 预选提交(null = 最新)
  pickCommit: { type: Boolean, default: true },
})
const emit = defineEmits(['update:modelValue', 'deployed'])
const visible = computed({ get: () => props.modelValue, set: (v) => emit('update:modelValue', v) })
const title = computed(() => `部署 — ${props.env?.branch || props.env?.name || ''}${props.pickCommit ? '' : (form.commit ? ' @ ' + shortSha(form.commit) : '(最新)')}`)
const commits = ref([]); const loading = ref(false); const saving = ref(false); const error = ref('')
const form = reactive({ commit: null, action: 'update_all', modules: '', databases: [] })
const dbs = ref([])  // 实例的全部库(主库 + 附加库);多库时可勾选 -u 的目标

async function loadDbs() {
  dbs.value = []
  if (!props.env?.extra_db_count) return
  try { const r = await api.get(`/environments/${props.env.id}/databases`, { silent: true }); dbs.value = (r.items || []).filter((d) => d.status === 'ready'); form.databases = dbs.value.map((d) => d.db_name) } catch {}
}
function onOpen() {
  error.value = ''
  Object.assign(form, { commit: props.commit || null, action: props.env?.deploy_action || 'update_all', modules: props.env?.deploy_modules || '', databases: [] })
  if (props.pickCommit) loadCommits(false)
  loadDbs()
}
async function loadCommits(refresh) {
  if (!props.env) return
  loading.value = true
  try { const r = await api.get(`/environments/${props.env.id}/commits`, { params: { limit: 30, refresh } }); commits.value = r.items || []; error.value = r.error || '' } catch {} finally { loading.value = false }
}
async function doDeploy() {
  if (!props.env) return
  saving.value = true
  try {
    const all = dbs.value.length && form.databases.length === dbs.value.length
    await api.post(`/environments/${props.env.id}/deploy`, { commit: form.commit, action: form.action, modules: form.action === 'update' ? form.modules : null, databases: dbs.value.length > 1 && !all ? form.databases : null })
    ElMessage.success('开始部署,完成后会提示'); visible.value = false; emit('deployed')
  } catch {} finally { saving.value = false }
}
</script>

<style scoped>
.dep-head { font-size: 12.5px; margin-bottom: 8px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
.commit-table :deep(.el-radio__label) { display: none; }
.foot-tip { flex: 1; text-align: left; font-size: 12px; align-self: center; }
.db-cbs { display: flex; flex-direction: column; align-items: flex-start; }
.tiny { font-size: 11.5px; }
</style>
