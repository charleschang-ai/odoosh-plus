<template>
  <!-- 实例日志抽屉:复用项目页的日志 Tab(SSE 实时流 / 级别过滤 / 搜索) -->
  <el-drawer v-model="visible" :title="`日志 — ${env?.name || ''}`" size="min(100vw, 960px)" destroy-on-close>
    <TabLogs v-if="env" :env="env" :active="visible" height="calc(100vh - 170px)" />
  </el-drawer>
</template>

<script setup>
import { computed } from 'vue'
import TabLogs from '../project/TabLogs.vue'

const props = defineProps({ modelValue: Boolean, env: { type: Object, default: null } })
const emit = defineEmits(['update:modelValue'])
const visible = computed({ get: () => props.modelValue, set: (v) => emit('update:modelValue', v) })
</script>
