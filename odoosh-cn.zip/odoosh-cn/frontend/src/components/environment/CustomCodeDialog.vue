<template>
  <!-- 无 git 实例的定制代码:上传 zip(按模块合并:新增/更新,其余保留)→ 自动重启使 Odoo 认到。 -->
  <el-dialog :model-value="modelValue" @update:model-value="$emit('update:modelValue', $event)"
             :title="`定制代码 — ${env?.name || ''}`" width="560px" @open="load">
    <div class="muted hint">
      上传含 Odoo 模块的 <b>zip</b>:压缩包里的<b>新模块会新增</b>,<b>同名模块会更新覆盖</b>,其余模块保留不动。
      上传后自动重启,并把新模块登记进 Odoo「应用」列表;<b>安装 / 升级请在 Odoo「应用」里操作</b>(和本地开发一致)。
    </div>
    <div class="host muted">
      也可让有服务器权限的人直接把模块拷到宿主机目录 <code>{{ info.host_dir || '…' }}</code>,再点
      <el-button link type="primary" size="small" :loading="reloading" @click="reload">重启使生效</el-button>
    </div>

    <input ref="fileInput" type="file" accept=".zip,application/zip" style="display: none" @change="onPick" />
    <div class="acts">
      <el-button type="primary" :icon="UploadFilled" :loading="uploading" @click="fileInput?.click()">上传代码包(zip)</el-button>
      <el-button :icon="Download" :loading="downloading" @click="download">下载当前代码</el-button>
    </div>
    <div v-if="uploading" class="prog"><el-progress :percentage="pct" :stroke-width="6" /><span class="muted">上传中 {{ pickedName }}</span></div>
    <el-alert v-if="lastResult" type="success" :closable="false" class="res"
              :title="`已上传:新增 ${lastResult.new.length ? lastResult.new.join('、') : '无'};更新 ${lastResult.updated.length ? lastResult.updated.join('、') : '无'}。正在重启使生效…`" />

    <template #footer><el-button @click="$emit('update:modelValue', false)">关闭</el-button></template>
  </el-dialog>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { UploadFilled, Download } from '@element-plus/icons-vue'
import api from '../../api'

const props = defineProps({ modelValue: Boolean, env: { type: Object, default: null } })
const emit = defineEmits(['update:modelValue', 'changed'])

const info = reactive({ host_dir: '' })
const fileInput = ref(null)
const uploading = ref(false); const downloading = ref(false); const reloading = ref(false)
const pct = ref(0); const pickedName = ref(''); const lastResult = ref(null)

async function load() {
  lastResult.value = null
  if (!props.env) return
  try { const r = await api.get(`/environments/${props.env.id}/custom-code`); info.host_dir = r.host_dir || '' } catch {}
}
function onPick(e) {
  const file = e.target.files?.[0]; e.target.value = ''
  if (file) upload(file)
}
async function upload(file) {
  uploading.value = true; pct.value = 0; pickedName.value = file.name; lastResult.value = null
  try {
    const r = await api.put(`/environments/${props.env.id}/custom-code/upload`, file, {
      params: { filename: file.name }, headers: { 'Content-Type': 'application/zip' }, timeout: 0,
      onUploadProgress: (ev) => { if (ev.total) pct.value = Math.round(ev.loaded / ev.total * 100) },
    })
    lastResult.value = { new: r.new || [], updated: r.updated || [] }
    ElMessage.success('已上传,正在重启使生效')
    emit('changed')
  } catch {} finally { uploading.value = false }
}
async function download() {
  downloading.value = true
  try {
    const blob = await api.get(`/environments/${props.env.id}/custom-code/download`, { responseType: 'blob' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = `${props.env.name}-addons.zip`; a.click()
    URL.revokeObjectURL(url)
  } catch {} finally { downloading.value = false }
}
async function reload() {
  reloading.value = true
  try { await api.post(`/environments/${props.env.id}/custom-code/reload`); ElMessage.success('正在重启使生效'); emit('changed') } catch {} finally { reloading.value = false }
}
</script>

<style scoped>
.hint { font-size: 12.5px; line-height: 1.7; margin-bottom: 10px; }
.host { font-size: 12.5px; line-height: 1.9; margin-bottom: 12px; }
.host code { word-break: break-all; }
.acts { display: flex; gap: 10px; }
.prog { display: flex; align-items: center; gap: 10px; margin-top: 12px; }
.prog :deep(.el-progress) { flex: 1; }
.res { margin-top: 12px; }
</style>
