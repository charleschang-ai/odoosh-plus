<template>
  <!-- 新建 / 编辑实例对话框。用法:<EnvFormDialog ref="dlg" @saved="load" />;dlg.openCreate(tenantId?) / dlg.openEdit(row) -->
  <el-dialog v-model="visible" :title="form.id ? '编辑实例' : '新建实例'" width="580px" @closed="onClosed">
    <el-form :model="form" label-width="100px">
      <el-form-item label="组织" required>
        <el-select v-model="form.tenant_id" :disabled="!!form.id" style="width: 100%">
          <el-option v-for="t in (form.id ? tenants : creatableTenants)" :key="t.id" :label="t.name" :value="t.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="实例名" required><el-input :model-value="form.name" :disabled="!!form.id" placeholder="小写字母/数字/-,如 demo、staging、feature-x" @update:model-value="form.name = $event.toLowerCase().replace(/[^a-z0-9-]/g, '-')" /></el-form-item>
      <el-form-item label="类型">
        <el-radio-group v-model="form.kind">
          <el-radio-button value="production" :disabled="!canCreate(form.tenant_id, 'production')">生产</el-radio-button>
          <el-radio-button value="staging">测试</el-radio-button>
          <el-radio-button value="dev">开发</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="Odoo 版本">
        <el-radio-group v-model="form.odoo_version" :disabled="!!form.container_name">
          <el-radio-button v-for="v in defaults.odoo_versions" :key="v" :value="v">Odoo {{ v }}</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item>
        <template #label>语言<HelpTip text="主库初始化后加载该语言并设为管理员 / 新用户的默认语言(与 Odoo 原生建库选语言效果一致)。测试环境从生产克隆、恢复备份等场景沿用数据自带的语言。实例创建后不可改,进 Odoo 设置里改。" /></template>
        <el-select v-model="form.lang" :disabled="!!form.container_name" filterable style="width: 260px">
          <el-option v-for="l in LANGS" :key="l.code" :value="l.code" :label="l.name" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <template #label>版本类型<HelpTip text="企业版代码按需从企业版仓库拉取、只读挂载并优先加载;同来源同版本的实例共享一份,删除实例不删除代码。" /></template>
        <el-radio-group v-model="form.edition" :disabled="!!form.container_name">
          <el-radio-button value="community">社区版</el-radio-button>
          <el-radio-button v-if="canUseEnterprise || form.edition === 'enterprise'" value="enterprise">企业版</el-radio-button>
        </el-radio-group>
        <!-- 企业版:新实例统一走离线企业版目录(超管上传/放置,按版本共享一套) -->
        <div v-if="form.edition === 'enterprise'" style="width: 100%; margin-top: 6px">
          <el-alert v-if="ent.loading" type="info" :closable="false" title="正在检查企业版代码…" />
          <el-alert v-else-if="ent.offline" type="success" :closable="false" show-icon :title="`企业版代码已就绪(版本 ${form.odoo_version}),创建时只读挂载`" />
          <el-alert v-else type="error" :closable="false" show-icon
            :title="ent.error || `未找到 ${form.odoo_version} 版本的企业版代码,请超级管理员先在「离线企业版代码」里上传该版本`" />
        </div>
      </el-form-item>
      <!-- 基础镜像:关 Git 时隐藏(源码自建需 git clone Odoo 源码,离线不可用;统一用官方/离线镜像) -->
      <el-form-item v-if="defaults.git_enabled" label="基础镜像">
        <el-radio-group v-model="form.base_mode" :disabled="!!form.container_name">
          <el-radio-button value="official">官方镜像 odoo:{{ form.odoo_version }}</el-radio-button>
          <el-radio-button value="custom">源码自建</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <!-- Git 仓库/分支:仅当该组织已接入仓库(或该实例已绑定仓库)时显示;否则默认只创建实例 -->
      <el-form-item v-show="gitVisible" label="Git 仓库 / 分支">
        <RepoBranchPicker :tenant-id="form.tenant_id" :exclude-env-id="form.id" v-model:repo-url="form.repo_url" v-model:branch="form.branch" @update:has-repos="hasRepos = $event" />
      </el-form-item>
      <template v-if="form.repo_url && form.branch">
        <el-form-item>
          <template #label>部署动作<HelpTip text="部署新代码后执行的动作;分支推送触发的自动部署也用它。" /></template>
          <el-radio-group v-model="form.deploy_action">
            <el-radio-button v-for="a in DEPLOY_ACTIONS" :key="a.value" :value="a.value">{{ a.label }}</el-radio-button>
          </el-radio-group>
          <el-input v-if="form.deploy_action === 'update'" v-model="form.deploy_modules" placeholder="模块名,逗号分隔,如 sale_custom,stock_ext" style="margin-top: 6px" />
        </el-form-item>
        <el-form-item v-if="form.kind !== 'production'">
          <template #label>自动部署<HelpTip text="收到该分支的推送后自动部署;生产实例始终手动部署。" /></template>
          <el-switch v-model="form.auto_deploy" />
        </el-form-item>
        <el-form-item v-if="form.kind === 'dev'">
          <template #label>闲置休眠<HelpTip :text="`无人访问超过该时长(小时)自动休眠,访问即唤醒。留空 = 组织 / 平台默认${defaults.sleep_idle_hours != null ? `(平台 ${defaults.sleep_idle_hours} 小时)` : ''},0 = 不休眠。`" /></template>
          <el-input-number v-model="form.sleep_idle_hours" :min="0" :max="8760" :step="1" :precision="1" controls-position="right" placeholder="默认" style="width: 160px" /><span class="form-tip" style="width: auto; margin: 0 0 0 8px">小时</span>
        </el-form-item>
      </template>
      <!-- 域名 / 过期:仅超级管理员可在「编辑实例」(或项目页「设置」)中调整;新建时使用自动域名 + 全局默认过期 -->
      <template v-if="form.id && isSuper">
        <el-divider content-position="left"><span class="muted" style="font-size: 12px">平台管理员设置</span></el-divider>
        <el-form-item>
          <template #label>域名<HelpTip text="留空则自动生成 <实例>.<组织>.<基础域名>;修改后需重启实例以重写 nginx 路由。" /></template>
          <el-input v-model="form.domain" placeholder="留空自动生成:<实例>.<组织>.<基础域名>" />
        </el-form-item>
        <el-form-item>
          <template #label>过期删除<HelpTip text="到期后自动删除实例(含数据)。" /></template>
          <el-select v-model="form.expire_choice" style="width: 200px">
            <el-option v-for="c in EXPIRE_CHOICES" :key="c.value" :label="c.label" :value="c.value" />
          </el-select>
          <span class="form-tip" style="width: auto; margin: 0 0 0 10px">当前:{{ expireText(form) }}</span>
        </el-form-item>
      </template>
      <el-form-item v-if="!form.id">
        <template #label>访问权限<HelpTip text="默认只有你(拥有者)和超级管理员能看到这个实例;可在这里或创建后随时添加协作者。" /></template>
        <AclEditor :tenant-id="form.tenant_id" v-model="acl" style="width: 100%" />
      </el-form-item>
      <el-form-item v-if="!form.id">
        <el-checkbox v-model="provisionNow">保存后立即创建并启动</el-checkbox>
        <span class="form-tip" style="width: auto; margin: 0 0 0 12px">域名 <span class="mono">&lt;实例&gt;.&lt;组织&gt;.{{ defaults.base_domain || '<基础域名>' }}</span> · {{ form.kind === 'production' ? '永不过期' : `${defaults.expire_days_default} 天后自动删除` }}<HelpTip text="新建实例使用自动域名与全局默认过期时间;如需调整请联系平台管理员在「编辑实例」中修改。" /></span>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" :loading="saving" :disabled="entBlocked" @click="save">保存</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { ElMessage, ElNotification } from 'element-plus'
import api from '../../api'
import { isSuper, canCreate, roleOf, tenants, loadTenants, defaults, loadDefaults } from '../../store'
import { DEPLOY_ACTIONS, EXPIRE_CHOICES, expireText } from '../../utils/labels'
import RepoBranchPicker from '../RepoBranchPicker.vue'
import HelpTip from '../HelpTip.vue'
import AclEditor from './AclEditor.vue'

const emit = defineEmits(['saved'])
const visible = ref(false); const saving = ref(false); const provisionNow = ref(true)
const creatableTenants = computed(() => tenants.value.filter((t) => ['production', 'staging', 'dev'].some((k) => canCreate(t.id, k))))
const LANGS = [
  { code: 'zh_CN', name: '简体中文 (zh_CN)' }, { code: 'zh_TW', name: '繁體中文 (zh_TW)' }, { code: 'en_US', name: 'English (en_US)' },
  { code: 'ja_JP', name: '日本語 (ja_JP)' }, { code: 'ko_KR', name: '한국어 (ko_KR)' }, { code: 'vi_VN', name: 'Tiếng Việt (vi_VN)' }, { code: 'th_TH', name: 'ไทย (th_TH)' },
  { code: 'de_DE', name: 'Deutsch (de_DE)' }, { code: 'fr_FR', name: 'Français (fr_FR)' }, { code: 'es_ES', name: 'Español (es_ES)' }, { code: 'ru_RU', name: 'Русский (ru_RU)' },
]
const blank = { id: null, tenant_id: null, name: '', kind: 'dev', odoo_version: '19', base_mode: 'official', edition: 'community', lang: 'zh_CN', repo_url: '', branch: '', domain: '', container_name: null, expire_choice: 'default', deploy_action: 'update_all', deploy_modules: '', auto_deploy: true, sleep_idle_hours: null }
const form = reactive({ ...blank })
const acl = ref([])  // 新建时的初始授权名单 [{user_id, level}]
const hasRepos = ref(false)
// 全系统关 Git 时隐藏仓库/分支;否则仅当该组织已接入仓库(或本实例已绑定)且角色够时显示
const gitVisible = computed(() => defaults.git_enabled && (hasRepos.value || !!form.repo_url) && ['owner', 'developer'].includes(roleOf(form.tenant_id)))
// 是否可选企业版:超管或被授权的用户(defaults.can_use_enterprise 已含超管判断)
const canUseEnterprise = computed(() => defaults.can_use_enterprise)

// 企业版来源检查(对话框内实时)
// 后端按 own(自己接入)→ tenant(本组织旧仓库)→ platform(超管共享)逐个探测,取第一个连通且含 <版本>.0 分支的仓库
const ent = reactive({ loading: false, repo: null, source: '', versions: null, error: null, local: [], tried: [], platform_available: false, offline: false })
const srcLabel = (s) => ({ own: '您接入的仓库', tenant: '本组织仓库', platform: '平台共享仓库' })[s] || s
let entSeq = 0
async function checkEnterprise() {
  if (form.edition !== 'enterprise' || !form.tenant_id) return
  const seq = ++entSeq
  ent.loading = true
  try {
    const r = await api.get('/enterprise/source', { params: { tenant_id: form.tenant_id, probe: true, version: form.odoo_version } })
    if (seq !== entSeq) return
    Object.assign(ent, { repo: r.repo, source: r.source, versions: r.versions, error: r.error, local: r.local || [], tried: r.tried || [], platform_available: !!r.platform_available, offline: !!r.offline })
  } catch { if (seq === entSeq) Object.assign(ent, { repo: null, versions: null, error: null, tried: [], offline: false }) } finally { if (seq === entSeq) ent.loading = false }
}
watch(() => [form.edition, form.tenant_id, form.odoo_version, visible.value], () => { if (visible.value && form.edition === 'enterprise' && !form.id) checkEnterprise() })
const entLocal = computed(() => { const v = ent.versions?.[form.odoo_version]; return !!v && ent.local.some((l) => l.version === form.odoo_version && v.startsWith(l.commit)) })
// 新建企业版:该版本代码就绪(离线目录有)才能建,否则挡住并提示上传
const entBlocked = computed(() => !form.id && form.edition === 'enterprise' && (ent.loading || !ent.offline))

function defaultVersion() {
  // 默认用版本列表的第一个(最新,一般是 Odoo 19);管理员显式配置了默认版本则优先用它
  const vs = defaults.odoo_versions || []
  return (defaults.default_version && vs.includes(defaults.default_version)) ? defaults.default_version : (vs[0] || '19')
}
/** 打开新建;preferTenantId:优先选中的组织 */
async function openCreate(preferTenantId = null) {
  await Promise.all([loadTenants(), loadDefaults()])
  const first = creatableTenants.value.find((t) => t.id === preferTenantId) || creatableTenants.value[0]
  Object.assign(form, blank, { tenant_id: first?.id || null, expire_choice: 'default', odoo_version: defaultVersion() })
  if (!defaults.git_enabled) form.base_mode = 'official'  // 关 Git 时源码自建不可用,统一官方/离线镜像
  acl.value = []
  if (!canCreate(form.tenant_id, form.kind)) form.kind = 'dev'
  provisionNow.value = true; visible.value = true
}
async function openEdit(row) {
  await Promise.all([loadTenants(), loadDefaults()])
  Object.assign(form, blank, row, { odoo_version: String(row.odoo_version), expire_choice: 'keep' })
  visible.value = true
}
function onClosed() { entSeq++; ent.loading = false }
async function save() {
  saving.value = true
  try {
    // 注意:不发送 status(后端不再接受)
    const payload = { kind: form.kind, odoo_version: form.odoo_version, base_mode: form.base_mode, edition: form.edition, lang: form.lang || 'zh_CN', repo_url: form.repo_url || null, branch: form.branch || null, deploy_action: form.deploy_action, deploy_modules: form.deploy_modules || null, auto_deploy: form.auto_deploy, sleep_idle_hours: form.sleep_idle_hours ?? null }
    const c = form.expire_choice
    if (form.id) {
      if (isSuper.value) {
        payload.domain = form.domain || null
        if (c !== 'keep') payload.expire_days = Number(c)
      }
      await api.put(`/environments/${form.id}`, payload)
      ElMessage.success('已保存')
    } else {
      // 域名 / 过期由平台管理员在实例设置里调整;新建走自动域名 + 全局默认过期
      const env = await api.post('/environments', { ...payload, tenant_id: form.tenant_id, name: form.name, acl: acl.value })
      if (provisionNow.value) {
        await api.post(`/environments/${env.id}/provision`)
        ElNotification.info({ title: `开始创建实例「${env.name}」`, message: '首次约 10~15 分钟(需下载镜像),之后约 2 分钟;完成后会提示。', duration: 6000 })
      } else ElMessage.success('已保存')
    }
    visible.value = false; emit('saved')
  } catch {} finally { saving.value = false }
}
defineExpose({ openCreate, openEdit })
</script>
