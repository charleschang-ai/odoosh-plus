<template>
  <!-- 删除实例(进回收站)确认框:说明 + 删除前备份勾选 + 生产实例需输入名称 -->
  <el-dialog v-model="visible" :title="env?.kind === 'production' ? '删除生产实例' : '删除实例'" width="480px" :close-on-click-modal="false" @closed="reset">
    <div class="lead" :class="{ prod: env?.kind === 'production' }">
      <el-icon class="lead-ic"><WarningFilled /></el-icon>
      <div>
        <div class="lead-t" v-if="branchMode">删除分支「<b>{{ env?.branch }}</b>」的{{ kindLabel(env?.kind) }}环境</div>
        <div class="lead-t" v-else>删除实例「<b>{{ env?.name }}</b>」</div>
        <div class="lead-d">
          <template v-if="branchMode">只删除这个分支的环境(容器 + 数据库 + filestore),<b>分支与代码保留</b>,之后可以再从「未分配」拖出来重建。</template>
          <template v-else>删除该实例的容器、数据库与文件。</template>
          <span v-if="env?.kind === 'production'">这是<b>生产环境</b>,请再次确认。</span>
        </div>
      </div>
    </div>
    <!-- 分支模式(详情页):本质是删这个分支的数据库,直接删除;实例模式:含生产 → 只能回收站,否则二选一 -->
    <div v-if="branchMode" class="branch-note muted">这是<b>直接删除</b>(不进回收站):该分支的数据库与文件立即清除;分支代码不受影响。</div>
    <div v-else class="modes">
      <label class="mode" :class="{ on: mode === 'trash' }"><input type="radio" v-model="mode" value="trash" /><div><div class="m-t">移入回收站 <span class="muted">(推荐)</span></div><div class="m-d muted">停容器、摘域名;数据保留 <b>{{ keepDays }} 天</b>,期间可在「实例 → 回收站」一键恢复,到期自动清理。</div></div></label>
      <label v-if="allowPurge" class="mode danger" :class="{ on: mode === 'purge' }"><input type="radio" v-model="mode" value="purge" /><div><div class="m-t">直接彻底删除</div><div class="m-d muted">立即删除容器、数据库与文件,<b>不可恢复</b>。</div></div></label>
      <div v-else class="mode locked"><el-icon><Lock /></el-icon><div class="m-d muted">该实例{{ env?.kind === 'production' ? '是生产环境' : '的项目里有生产分支' }},只能移入回收站,不能直接彻底删除(如确需彻底删除,请先把生产分支降级)。</div></div>
    </div>
    <div class="opts">
      <el-checkbox v-model="backup" :disabled="!env?.db_name">
        删除前先做一次完整备份(数据库 + filestore)
        <span class="muted">— 即使回收站过期也能从备份恢复</span>
      </el-checkbox>
    </div>
    <div v-if="env?.kind === 'production' || mode === 'purge'" class="confirm-in">
      <div class="muted">请输入{{ branchMode ? '分支名' : '实例名' }} <code>{{ confirmText }}</code> 以确认:</div>
      <el-input v-model="typed" :placeholder="confirmText" @keyup.enter="submit" />
    </div>
    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="danger" :loading="busy" :disabled="needConfirm && typed !== confirmText" @click="submit">{{ mode === 'purge' ? '彻底删除' : '移入回收站' }}</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { WarningFilled, Lock } from '@element-plus/icons-vue'
import api from '../../api'
import { kindLabel } from '../../utils/labels'

const props = defineProps({ keepDaysDefault: { type: Number, default: 7 }, keepDaysProd: { type: Number, default: 30 } })
const emit = defineEmits(['done'])
const visible = ref(false); const env = ref(null); const backup = ref(true); const typed = ref(''); const busy = ref(false)
const keepDays = ref(7); const mode = ref('trash'); const branchMode = ref(false); const allowPurge = ref(true)
const confirmText = computed(() => (branchMode.value ? env.value?.branch : env.value?.name) || '')
// 生产始终要输名字;实例模式选“彻底删除”要输名字;分支模式(直接删)测试分支要输名字,开发分支不用
const needConfirm = computed(() => env.value?.kind === 'production' || (!branchMode.value && mode.value === 'purge') || (branchMode.value && env.value?.kind === 'staging'))

/** open(row, { branch, allowPurge }):branch=true 项目详情页删“某分支的数据库/环境”(直接删);allowPurge=false 实例含生产,只能回收站 */
function open(row, opts = {}) {
  env.value = row
  branchMode.value = !!opts.branch
  allowPurge.value = opts.allowPurge !== false && row.kind !== 'production'
  mode.value = branchMode.value ? 'purge' : 'trash'
  backup.value = !!row.db_name && row.kind !== 'dev'
  keepDays.value = row.kind === 'production' ? props.keepDaysProd : props.keepDaysDefault
  visible.value = true
}
function reset() { typed.value = ''; env.value = null; busy.value = false }
async function submit() {
  if (!env.value) return
  if (needConfirm.value && typed.value !== confirmText.value) return
  busy.value = true
  try {
    const r = await api.delete(`/environments/${env.value.id}`, { params: { backup: backup.value ? 1 : 0, purge: mode.value === 'purge' ? 1 : 0 } })
    ElMessage.success(mode.value === 'purge' ? (backup.value ? '备份完成后将彻底删除' : '正在彻底删除') : r?.purged ? '已删除' : backup.value ? '备份完成后将移入回收站' : '正在移入回收站')
    visible.value = false
    emit('done', env.value)
  } catch {} finally { busy.value = false }
}
watch(visible, (v) => { if (!v) busy.value = false })
defineExpose({ open })
</script>

<style scoped>
.lead { display: flex; gap: 12px; align-items: flex-start; padding: 12px 14px; border-radius: 10px; background: var(--warn-bg); border: 1px solid #fde68a; }
.lead.prod { background: var(--danger-bg); border-color: #fecaca; }
.lead-ic { font-size: 20px; color: var(--warn); margin-top: 2px; }
.lead.prod .lead-ic { color: var(--danger); }
.lead-t { font-weight: 600; }
.lead-d { font-size: 12.5px; color: var(--text-2); margin-top: 3px; line-height: 1.6; }
.modes { display: grid; gap: 8px; margin-top: 12px; }
.mode { display: flex; gap: 10px; align-items: flex-start; padding: 10px 12px; border: 1px solid var(--line); border-radius: 10px; cursor: pointer; }
.mode input { margin-top: 3px; accent-color: var(--brand); }
.mode.on { border-color: var(--brand); background: var(--brand-50); }
.mode.danger.on { border-color: var(--danger); background: var(--danger-bg); }
.m-t { font-weight: 600; font-size: 13.5px; }
.m-d { font-size: 12px; margin-top: 2px; line-height: 1.5; }
.mode.locked { cursor: default; background: var(--surface-2); border-style: dashed; color: var(--text-3); align-items: center; }
.branch-note { margin-top: 12px; font-size: 12.5px; padding: 8px 12px; border-radius: 8px; background: var(--danger-bg); color: #991b1b; }
.branch-note b { color: #991b1b; }
.opts { margin-top: 12px; }
.opts .muted { font-size: 12px; }
.confirm-in { margin-top: 14px; display: grid; gap: 6px; font-size: 13px; }
</style>
