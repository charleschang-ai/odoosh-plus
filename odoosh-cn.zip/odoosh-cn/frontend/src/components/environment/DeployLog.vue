<template>
  <!-- 单次部署的编排日志:进行中走 SSE 流(失败回退轮询),结束后取完整日志 -->
  <div class="dlog">
    <div class="dlog-bar" v-if="!compact">
      <span class="muted small">
        部署 #{{ dep?.id }}<template v-if="detail"> · <el-tag size="small" :type="depType(detail.status)" effect="plain">{{ depLabel(detail.status) }}</el-tag>
          <span v-if="detail.duration != null"> · 耗时 {{ shortDuration(detail.duration) }}</span></template>
        <span v-if="live" class="live"><i />实时</span>
      </span>
      <span class="spacer" />
      <el-button link size="small" :icon="Refresh" :loading="loading" @click="fetchDetail">刷新</el-button>
    </div>
    <pre ref="box" class="log">{{ text || (loading ? '加载中…' : '(暂无日志)') }}</pre>
  </div>
</template>

<script setup>
import { nextTick, onBeforeUnmount, ref, watch } from 'vue'
import { Refresh } from '@element-plus/icons-vue'
import api from '../../api'
import { openLogStream } from '../../composables/useLogStream'
import { usePolling } from '../../composables/usePolling'
import { depType, depLabel } from '../../utils/labels'
import { shortDuration } from '../../utils/format'

const props = defineProps({
  envId: { type: Number, required: true },
  dep: { type: Object, default: null }, // {id, status}
  compact: { type: Boolean, default: false },
})
const emit = defineEmits(['finished'])
const detail = ref(null); const text = ref(''); const loading = ref(false); const live = ref(false); const box = ref(null)
let stream = null; let lines = []
const RUNNING = (s) => s === 'running' || s === 'queued'

function scrollBottom() { nextTick(() => { if (box.value) box.value.scrollTop = box.value.scrollHeight }) }
async function fetchDetail() {
  if (!props.dep?.id) return
  loading.value = true
  try {
    const d = await api.get(`/environments/${props.envId}/deployments/${props.dep.id}`, { silent: true })
    const wasRunning = detail.value ? RUNNING(detail.value.status) : RUNNING(props.dep.status)
    detail.value = d
    if (!live.value || !RUNNING(d.status)) { text.value = d.log || ''; lines = text.value ? text.value.split('\n') : [] }
    if (!RUNNING(d.status)) { stopStream(); poll.stop(); if (wasRunning) emit('finished', d) }
    scrollBottom()
  } catch {} finally { loading.value = false }
}
const poll = usePolling(fetchDetail, { interval: 3000, immediate: false })
function stopStream() { if (stream) { stream.close(); stream = null } live.value = false }
function startStream() {
  stopStream()
  let errors = 0
  stream = openLogStream(`/environments/${props.envId}/deployments/${props.dep.id}/log/stream`, {}, {
    onOpen: () => { live.value = true; errors = 0 },
    onLine: (_k, t) => { lines.push(t); if (lines.length > 5000) lines = lines.slice(-5000); text.value = lines.join('\n'); scrollBottom() },
    onReset: () => { lines = []; text.value = '' },
    onEnd: () => { live.value = false; stream = null; fetchDetail() },
    onError: () => { errors++; if (!stream || stream.closed || errors >= 3) { stopStream(); poll.start() } },
  })
}
async function init() {
  stopStream(); poll.stop(); detail.value = null; text.value = ''; lines = []
  if (!props.dep?.id) return
  await fetchDetail()
  if (RUNNING(detail.value?.status ?? props.dep.status)) startStream()
}
watch(() => [props.envId, props.dep?.id], init, { immediate: true })
// 父组件轮询把状态从 running 改成 success/failed 时补拉一次完整日志
watch(() => props.dep?.status, (s, old) => { if (old && RUNNING(old) && !RUNNING(s)) fetchDetail() })
onBeforeUnmount(() => { stopStream(); poll.stop() })
defineExpose({ refresh: fetchDetail })
</script>

<style scoped>
.dlog-bar { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.spacer { flex: 1; }
.small { font-size: 12px; }
.live { display: inline-flex; align-items: center; gap: 4px; margin-left: 8px; color: var(--ok); font-weight: 600; }
.live i { width: 7px; height: 7px; border-radius: 50%; background: var(--ok); animation: blink 1.2s infinite; }
@keyframes blink { 50% { opacity: .3; } }
.log { white-space: pre-wrap; word-break: break-all; max-height: 60vh; overflow: auto; margin: 0; }
</style>
