<template>
  <el-dialog v-model="visible" title="批量创建实例" width="720px" :close-on-click-modal="false" class="env-batch" @closed="onClosed">
    <!-- 阶段一:表单 + 预检 -->
    <template v-if="phase === 'form'">
      <div class="hint">批量创建的实例<b>不连接 Git 仓库</b>(官方镜像 + 空库),仅限开发 / 测试。只有超级管理员和组织管理员可用。</div>
      <el-form label-width="96px" class="bf">
        <el-form-item label="组织">
          <el-select v-model="form.tenant_id" style="width: 280px" @change="onTenant">
            <el-option v-for="t in batchTenants" :key="t.id" :label="t.name" :value="t.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="拥有者">
          <el-select v-model="form.owner_user_id" style="width: 280px" filterable>
            <el-option v-for="o in ownerOptions" :key="o.id" :label="o.label" :value="o.id" />
          </el-select>
          <HelpTip text="这批实例都归此人所有(默认你自己),并计入其实例配额。可选本组织任意成员;你自己(含超管)始终可选。" />
        </el-form-item>
        <el-form-item label="类型">
          <el-radio-group v-model="form.kind">
            <el-radio-button value="dev">开发</el-radio-button>
            <el-radio-button value="staging">测试</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="版本类型">
          <el-radio-group v-model="form.edition" @change="preflight = null">
            <el-radio-button value="community">社区版</el-radio-button>
            <el-radio-button v-if="defaults.can_use_enterprise || form.edition === 'enterprise'" value="enterprise">企业版</el-radio-button>
          </el-radio-group>
          <span v-if="form.edition === 'enterprise'" class="mut sm">企业版代码来自平台统一企业版目录,创建时按所选 Odoo 版本只读挂载</span>
        </el-form-item>
        <el-form-item label="命名方式">
          <el-segmented v-model="nameMode" :options="[{ label: '序列生成', value: 'seq' }, { label: '名称清单', value: 'list' }]" @change="preflight = null" />
        </el-form-item>
        <template v-if="nameMode === 'seq'">
          <el-form-item label="序列">
            <div class="seq-line">
              <el-input v-model="seq.prefix" placeholder="前缀 dev" style="width: 130px" />
              <span class="mut">起</span><el-input-number v-model="seq.start" :min="0" :max="99999" controls-position="right" style="width: 110px" />
              <span class="mut">共</span><el-input-number v-model="seq.count" :min="1" :max="maxCreate" controls-position="right" style="width: 110px" />
              <span class="mut">补零</span><el-input-number v-model="seq.pad" :min="1" :max="6" controls-position="right" style="width: 92px" />
            </div>
          </el-form-item>
          <el-form-item label=" ">
            <div v-if="seqNames.length" class="preview-names">将创建 <b>{{ seqNames.length }}</b> 个:<span class="mono">{{ seqNames.slice(0, 6).join('、') }}{{ seqNames.length > 6 ? ` …… ${seqNames[seqNames.length - 1]}` : '' }}</span></div>
          </el-form-item>
        </template>
        <el-form-item v-else label="名称清单">
          <el-input v-model="listText" type="textarea" :rows="4" placeholder="每行一个,如&#10;shop-a&#10;shop-b" />
        </el-form-item>
        <el-form-item label="Odoo 版本">
          <el-select v-model="form.odoo_version" style="width: 130px"><el-option v-for="v in versions" :key="v" :label="`Odoo ${v}`" :value="v" /></el-select>
          <el-select v-model="form.lang" filterable style="width: 200px; margin-left: 10px"><el-option v-for="l in LANGS" :key="l.code" :value="l.code" :label="l.name" /></el-select>
        </el-form-item>
        <el-form-item label="资源上限">
          <el-input-number v-model="form.mem_mb" :min="256" :max="65536" :step="256" controls-position="right" placeholder="内存 MB" style="width: 150px" />
          <el-input-number v-model="form.cpus" :min="0.25" :max="64" :step="0.25" controls-position="right" placeholder="CPU 核" style="width: 140px; margin-left: 10px" />
          <span class="mut sm">留空 = 平台默认</span>
        </el-form-item>
        <el-form-item label="闲置休眠">
          <el-input-number v-model="form.sleep_idle_hours" :min="0" :max="720" :step="1" controls-position="right" placeholder="小时" style="width: 150px" />
          <span class="mut sm">留空 = 组织 / 平台默认;0 = 不休眠</span>
        </el-form-item>
        <el-form-item v-if="isSuper" label="过期删除">
          <el-input-number v-model="form.expire_days" :min="0" :max="3650" controls-position="right" placeholder="天" style="width: 150px" />
          <span class="mut sm">留空 = 默认;0 = 永不(仅超管可设)</span>
        </el-form-item>
        <el-form-item label="立即启动">
          <el-switch v-model="form.provision" inline-prompt active-text="是" inactive-text="否" />
          <span class="mut sm">开:建完立即创建并启动;关:只建记录,稍后手动启动</span>
        </el-form-item>
      </el-form>

      <!-- 预检结果 -->
      <template v-if="preflight">
        <div class="pf">
          <div class="pf-row">
            <el-tag :type="preflight.quota.ok ? 'success' : 'danger'" effect="plain">
              配额 {{ preflight.quota.owner }}:{{ preflight.quota.used }} + {{ preflight.quota.adding }}{{ preflight.quota.limit == null ? ' / ∞' : ` / ${preflight.quota.limit}` }}{{ preflight.quota.ok ? '' : ' 超限' }}
            </el-tag>
            <el-tag type="info" effect="plain">可创建 {{ preflight.ok_count }}</el-tag>
            <el-tag v-if="preflight.items.length - preflight.ok_count" type="warning" effect="plain">跳过 {{ preflight.items.length - preflight.ok_count }}</el-tag>
            <el-tag type="info" effect="plain">预计内存 {{ (preflight.est_mem_mb / 1024).toFixed(1) }} GB</el-tag>
          </div>
          <div v-if="!preflight.quota.ok" class="pf-err">{{ preflight.quota.reason }}</div>
          <div v-if="preflight.enterprise?.required && !preflight.enterprise.available" class="pf-err">✗ {{ preflight.enterprise.reason }}</div>
          <div v-else-if="preflight.enterprise?.required" class="pf-ok">✓ 企业版代码已就绪({{ preflight.enterprise.source }}),创建时只读挂载</div>
          <div v-for="w in preflight.warnings" :key="w" class="pf-warn">⚠ {{ w }}</div>
          <el-table v-if="badItems.length" :data="badItems" size="small" max-height="160" class="pf-table">
            <el-table-column label="名称" prop="name" width="160" />
            <el-table-column label="跳过原因"><template #default="{ row }"><span class="pf-err">{{ row.reason }}</span></template></el-table-column>
          </el-table>
        </div>
      </template>
    </template>

    <!-- 阶段二:执行进度 -->
    <template v-else>
      <div class="run-head">
        <el-progress type="dashboard" :width="90" :percentage="donePct" :status="job.failed ? 'warning' : 'success'" />
        <div class="run-stat">
          <div class="rs"><b>{{ job.total }}</b> 个实例</div>
          <div class="rs"><span class="ok">成功 {{ job.succeeded }}</span> · <span class="fail">失败 {{ job.failed }}</span> · <span class="skip">跳过 {{ job.skipped }}</span></div>
          <div class="rs mut">{{ statusText }}</div>
        </div>
      </div>
      <el-table :data="job.items" size="small" max-height="260" class="run-table">
        <el-table-column label="实例" prop="label" width="180" />
        <el-table-column label="状态" width="110"><template #default="{ row }"><el-tag size="small" :type="itemTone(row.status)" effect="plain">{{ itemLabel(row.status) }}</el-tag></template></el-table-column>
        <el-table-column label="说明"><template #default="{ row }"><span :class="{ 'pf-err': row.status === 'failed' }">{{ row.message || '' }}</span></template></el-table-column>
      </el-table>
    </template>

    <template #footer>
      <template v-if="phase === 'form'">
        <el-button @click="visible = false">取消</el-button>
        <el-button :loading="checking" @click="doPreflight">预检</el-button>
        <el-button type="primary" :loading="submitting" :disabled="!canSubmit" @click="submit">创建 {{ preflight ? preflight.ok_count : '' }} 个</el-button>
      </template>
      <template v-else>
        <el-button v-if="jobRunning" type="warning" plain :loading="cancelling" @click="cancel">取消未开始</el-button>
        <el-button v-if="!jobRunning && job.failed" type="primary" plain @click="retry">重试失败项</el-button>
        <el-button @click="visible = false">{{ jobRunning ? '后台运行(关闭)' : '完成' }}</el-button>
      </template>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, reactive, ref } from 'vue'
import api from '../../api'
import HelpTip from '../HelpTip.vue'
import { isSuper, roleOf, tenants, session, defaults, loadDefaults } from '../../store'

const emit = defineEmits(['saved'])

const LANGS = [
  { code: 'zh_CN', name: '简体中文' }, { code: 'zh_TW', name: '繁體中文' }, { code: 'en_US', name: 'English' },
  { code: 'ja_JP', name: '日本語' }, { code: 'ko_KR', name: '한국어' }, { code: 'fr_FR', name: 'Français' },
  { code: 'de_DE', name: 'Deutsch' }, { code: 'es_ES', name: 'Español' }, { code: 'ru_RU', name: 'Русский' },
]

const visible = ref(false)
const phase = ref('form')
const checking = ref(false); const submitting = ref(false); const cancelling = ref(false)
const preflight = ref(null)
const members = ref([])
const job = ref(null)
let timer = null

const nameMode = ref('seq')
const seq = reactive({ prefix: 'dev', start: 1, count: 5, pad: 2 })
const listText = ref('')
const blank = () => ({ tenant_id: null, owner_user_id: session.me?.id || null, kind: 'dev', edition: 'community', odoo_version: (defaults.odoo_versions || [])[0] || '19', lang: 'zh_CN', mem_mb: null, cpus: null, sleep_idle_hours: null, expire_days: null, provision: true })
const form = reactive(blank())

const batchTenants = computed(() => tenants.value.filter((t) => isSuper.value || roleOf(t.id) === 'owner'))
const versions = computed(() => defaults.odoo_versions || ['18', '17', '16'])
const maxCreate = 20
const ownerOptions = computed(() => {
  const me = session.me
  const opts = me ? [{ id: me.id, label: `${me.display_name || me.username}(我)` }] : []
  for (const m of members.value) if (m.user_id !== me?.id && m.is_active) opts.push({ id: m.user_id, label: `${m.display_name || m.username}` })
  return opts
})
const seqNames = computed(() => {
  const p = (seq.prefix || '').trim().toLowerCase()
  if (!p || !seq.count) return []
  return Array.from({ length: seq.count }, (_, i) => p + String(seq.start + i).padStart(seq.pad, '0'))
})
const badItems = computed(() => (preflight.value?.items || []).filter((i) => !i.ok))
const canSubmit = computed(() => preflight.value && preflight.value.ok_count > 0 && preflight.value.quota.ok && !(preflight.value.enterprise?.required && !preflight.value.enterprise.available))
const jobRunning = computed(() => job.value && ['queued', 'running', 'cancelling'].includes(job.value.status))
const donePct = computed(() => (job.value?.total ? Math.round(((job.value.succeeded + job.value.failed + job.value.skipped) / job.value.total) * 100) : 0))
const statusText = computed(() => ({ queued: '排队中', running: '创建中(先预热一个,再并行其余)', cancelling: '取消中', done: '已完成', cancelled: '已取消' }[job.value?.status] || ''))

function planPayload() {
  const base = { odoo_version: form.odoo_version, edition: form.edition, lang: form.lang, mem_mb: form.mem_mb || null, cpus: form.cpus || null, sleep_idle_hours: form.sleep_idle_hours ?? null, expire_days: isSuper.value ? (form.expire_days ?? null) : null, acl: [] }
  const p = { tenant_id: form.tenant_id, kind: form.kind, owner_user_id: form.owner_user_id, provision: form.provision, base }
  if (nameMode.value === 'seq') Object.assign(p, { prefix: seq.prefix, start: seq.start, count: seq.count, pad: seq.pad })
  else p.names = listText.value.split('\n').map((s) => s.trim()).filter(Boolean)
  return { plan: p }
}

async function onTenant() {
  preflight.value = null; members.value = []
  if (!form.tenant_id) return
  try { members.value = await api.get(`/tenants/${form.tenant_id}/members`, { silent: true }) } catch {}
}
async function doPreflight() {
  checking.value = true
  try { preflight.value = await api.post('/bulk/env-create/preflight', planPayload()) } catch {} finally { checking.value = false }
}
async function submit() {
  submitting.value = true
  try {
    const key = `env-${form.tenant_id}-${Date.now()}`
    const j = await api.post('/bulk/env-create', { ...planPayload(), idempotency_key: key })
    job.value = j; phase.value = 'running'; emit('saved')
    if (jobRunning.value) startPoll()
  } catch {} finally { submitting.value = false }
}
function startPoll() {
  stopPoll()
  timer = setInterval(async () => {
    try {
      job.value = await api.get(`/bulk/${job.value.id}`, { silent: true })
      emit('saved')
      if (!jobRunning.value) stopPoll()
    } catch {}
  }, 1500)
}
function stopPoll() { if (timer) { clearInterval(timer); timer = null } }
async function cancel() {
  cancelling.value = true
  try { job.value = await api.post(`/bulk/${job.value.id}/cancel`) } catch {} finally { cancelling.value = false }
}
async function retry() {
  try { job.value = await api.post(`/bulk/${job.value.id}/retry`); startPoll() } catch {}
}
function onClosed() { stopPoll(); if (!jobRunning.value) emit('saved') }

function itemTone(s) { return { success: 'success', failed: 'danger', running: 'primary', skipped: 'warning', cancelled: 'info', pending: 'info' }[s] || 'info' }
function itemLabel(s) { return { success: '成功', failed: '失败', running: '进行中', skipped: '跳过', cancelled: '已取消', pending: '排队中' }[s] || s }

function open(tenantId) {
  Object.assign(form, blank())
  phase.value = 'form'; preflight.value = null; job.value = null; nameMode.value = 'seq'
  Object.assign(seq, { prefix: 'dev', start: 1, count: 5, pad: 2 }); listText.value = ''
  loadDefaults().catch(() => {})
  const pick = batchTenants.value.find((t) => t.id === tenantId) || batchTenants.value[0]
  form.tenant_id = pick?.id || null
  form.odoo_version = (defaults.odoo_versions || [])[0] || '19'
  visible.value = true
  onTenant()
}
defineExpose({ open })
</script>

<style scoped>
.hint { font-size: 12.5px; color: var(--text-3); line-height: 1.7; margin-bottom: 12px; }
.bf :deep(.el-form-item) { margin-bottom: 14px; }
.seq-line { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.mut { color: var(--text-3); font-size: 13px; }
.mut.sm { font-size: 12px; margin-left: 8px; }
.preview-names { font-size: 13px; background: var(--surface-2); border: 1px solid var(--line-2); border-radius: 8px; padding: 6px 10px; }
.mono { font-family: var(--mono, monospace); }
.pf { border-top: 1px solid var(--line-2); margin-top: 6px; padding-top: 12px; }
.pf-row { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px; }
.pf-err { color: var(--danger); font-size: 12.5px; }
.pf-ok { color: var(--success); font-size: 12.5px; }
.pf-warn { color: var(--warning, #b45309); font-size: 12.5px; margin: 2px 0; }
.pf-table { margin-top: 8px; }
.run-head { display: flex; align-items: center; gap: 20px; margin-bottom: 14px; }
.run-stat .rs { font-size: 13px; margin: 2px 0; }
.run-stat .ok { color: var(--success); } .run-stat .fail { color: var(--danger); } .run-stat .skip { color: var(--warning, #b45309); }
.run-table :deep(.pf-err) { color: var(--danger); }
</style>
