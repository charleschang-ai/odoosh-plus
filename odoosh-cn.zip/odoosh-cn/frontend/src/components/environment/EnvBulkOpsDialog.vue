<template>
  <el-dialog v-model="visible" :title="title" width="640px" :close-on-click-modal="false" @closed="onClosed">
    <!-- 阶段零:参数配置(编辑 / 转让 / 协作者) -->
    <template v-if="phase === 'config'">
      <div class="tip">将对选中的 <b>{{ ids.length }}</b> 个实例{{ needRoot ? '(按项目去重)' : '' }}统一{{ verb }}。</div>

      <!-- 批量编辑设置 -->
      <div v-if="kind === 'env.edit'" class="cfg">
        <div class="tip mut">只改勾选的项;未勾选的保持不变。改内存 / CPU / 日志等级后需重启生效。</div>
        <div class="grp"><el-checkbox v-model="on.mem">内存上限</el-checkbox><div v-if="on.mem" class="ctrl"><el-input-number v-model="f.mem_mb" :min="256" :max="65536" :step="256" controls-position="right" style="width:150px" placeholder="MB" /><span class="mut">MB(留空=默认)</span></div></div>
        <div class="grp"><el-checkbox v-model="on.cpu">CPU 上限</el-checkbox><div v-if="on.cpu" class="ctrl"><el-input-number v-model="f.cpus" :min="0.25" :max="64" :step="0.25" controls-position="right" style="width:150px" placeholder="核" /><span class="mut">核</span></div></div>
        <div class="grp"><el-checkbox v-model="on.log">日志等级</el-checkbox><div v-if="on.log" class="ctrl"><el-select v-model="f.log_level" style="width:150px"><el-option v-for="l in LOG_LEVELS" :key="l" :value="l" :label="l" /></el-select></div></div>
        <div class="grp"><el-checkbox v-model="on.sleep">闲置休眠</el-checkbox><div v-if="on.sleep" class="ctrl"><el-input-number v-model="f.sleep_idle_hours" :min="0" :max="720" controls-position="right" style="width:150px" placeholder="小时" /><span class="mut">小时(0=不休眠;留空=默认)</span></div></div>
        <div v-if="isSuper" class="grp"><el-checkbox v-model="on.expire">过期删除</el-checkbox><div v-if="on.expire" class="ctrl"><el-input-number v-model="f.expire_days" :min="0" :max="3650" controls-position="right" style="width:150px" placeholder="天" /><span class="mut">天(0=永不;仅超管)</span></div></div>
      </div>

      <!-- 批量转让拥有者 -->
      <div v-else-if="kind === 'env.transfer'" class="cfg">
        <div v-if="!oneTenant" class="warn">批量转让需选择同一组织的实例。</div>
        <template v-else>
          <div class="tip mut">整批(含项目内分支环境)转给此人,连带占用其实例配额;原拥有者降为「可管理」。</div>
          <el-select v-model="newOwner" filterable placeholder="选择新拥有者" style="width:300px">
            <el-option v-for="m in members" :key="m.user_id" :label="`${m.display_name || m.username}`" :value="m.user_id" />
          </el-select>
        </template>
      </div>

      <!-- 批量加 / 减协作者 -->
      <div v-else-if="kind === 'acl.grant' || kind === 'acl.revoke'" class="cfg">
        <div v-if="!oneTenant" class="warn">批量改授权名单需选择同一组织的实例。</div>
        <template v-else>
          <div class="tip mut">名单挂在项目上,选中同一项目的多个环境只改一次。</div>
          <el-select v-model="aclUsers" multiple filterable :placeholder="kind === 'acl.grant' ? '选择要添加的成员' : '选择要移除的成员'" style="width:100%">
            <el-option v-for="m in members" :key="m.user_id" :label="`${m.display_name || m.username}`" :value="m.user_id" />
          </el-select>
          <div v-if="kind === 'acl.grant'" class="ctrl" style="margin-top:10px">
            <span class="mut">权限级别</span>
            <el-radio-group v-model="aclLevel"><el-radio-button value="view">可访问</el-radio-button><el-radio-button value="operate">可操作</el-radio-button><el-radio-button value="manage">可管理</el-radio-button></el-radio-group>
          </div>
        </template>
      </div>
    </template>

    <!-- 阶段一:预检确认 -->
    <template v-else-if="phase === 'confirm'">
      <div v-loading="checking">
        <div v-if="preflight" class="sum">
          <el-tag :type="danger ? 'danger' : 'info'" effect="plain">共 {{ preflight.items.length }}</el-tag>
          <el-tag type="success" effect="plain">可{{ preflight.verb }} {{ preflight.ok_count }}</el-tag>
          <el-tag v-if="skipCount" type="warning" effect="plain">跳过 {{ skipCount }}</el-tag>
        </div>
        <div v-if="kind === 'env.trash'" class="danger-tip">⚠ 删除会把实例移入回收站(数据保留可恢复);仅拥有者可删,其余跳过。</div>
        <div v-else-if="kind === 'env.purge'" class="danger-tip">⚠ 彻底删除将销毁容器、数据库与文件,<b>不可恢复</b>;仅拥有者可删,其余跳过。</div>
        <el-table v-if="preflight" :data="preflight.items" size="small" max-height="280">
          <el-table-column label="实例" prop="label" width="200" />
          <el-table-column label="状态" width="80"><template #default="{ row }"><el-icon v-if="row.ok" color="var(--success)"><CircleCheckFilled /></el-icon><el-icon v-else color="var(--text-3)"><RemoveFilled /></el-icon></template></el-table-column>
          <el-table-column label="说明"><template #default="{ row }"><span :class="{ mut: row.ok }">{{ row.ok ? `将${preflight.verb}` : row.reason }}</span></template></el-table-column>
        </el-table>
      </div>
    </template>

    <!-- 阶段二:执行进度 -->
    <template v-else>
      <div class="run-head">
        <el-progress type="dashboard" :width="88" :percentage="donePct" :status="job.failed ? 'warning' : 'success'" />
        <div class="run-stat">
          <div class="rs"><b>{{ job.total }}</b> 项</div>
          <div class="rs"><span class="ok">成功 {{ job.succeeded }}</span> · <span class="fail">失败 {{ job.failed }}</span> · <span class="skip">跳过 {{ job.skipped }}</span></div>
          <div class="rs mut">{{ statusText }}</div>
        </div>
      </div>
      <el-table :data="job.items" size="small" max-height="260">
        <el-table-column label="实例" prop="label" width="180" />
        <el-table-column label="状态" width="100"><template #default="{ row }"><el-tag size="small" :type="itemTone(row.status)" effect="plain">{{ itemLabel(row.status) }}</el-tag></template></el-table-column>
        <el-table-column label="说明"><template #default="{ row }"><span :class="{ fail: row.status === 'failed' }">{{ row.message || '' }}</span></template></el-table-column>
      </el-table>
    </template>

    <template #footer>
      <template v-if="phase === 'config'">
        <el-button @click="visible = false">取消</el-button>
        <el-button type="primary" :disabled="!configValid" @click="toConfirm">下一步</el-button>
      </template>
      <template v-else-if="phase === 'confirm'">
        <el-button @click="visible = false">取消</el-button>
        <el-button :type="danger ? 'danger' : 'primary'" :loading="submitting" :disabled="!preflight || preflight.ok_count === 0" @click="submit">
          {{ preflight ? `${preflight.verb} ${preflight.ok_count} 个` : '…' }}
        </el-button>
      </template>
      <template v-else>
        <el-button v-if="jobRunning" type="warning" plain :loading="cancelling" @click="cancel">取消未开始</el-button>
        <el-button v-if="!jobRunning && job.failed" type="primary" plain @click="retry">重试失败项</el-button>
        <el-button @click="visible = false">{{ jobRunning ? '后台运行(关闭)' : '完成' }}</el-button>
      </template>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, reactive, ref } from 'vue'
import { CircleCheckFilled, RemoveFilled } from '@element-plus/icons-vue'
import api from '../../api'
import { isSuper } from '../../store'

const emit = defineEmits(['done'])

const VERB = { 'env.start': '启动', 'env.stop': '停止', 'env.restart': '重启', 'env.trash': '删除', 'env.purge': '彻底删除', 'env.restore': '恢复', 'env.sleep': '休眠', 'env.wake': '唤醒', 'env.backup': '备份', 'env.edit': '修改设置', 'env.transfer': '转让拥有者', 'acl.grant': '添加协作者', 'acl.revoke': '移除协作者' }
const LOG_LEVELS = ['critical', 'error', 'warn', 'info', 'debug']
const CONFIG_KINDS = ['env.edit', 'env.transfer', 'acl.grant', 'acl.revoke']
const ROOT_KINDS = ['env.transfer', 'acl.grant', 'acl.revoke']

const visible = ref(false)
const phase = ref('confirm')
const kind = ref('env.start')
const ids = ref([])
const ctxTenantId = ref(null)
const preflight = ref(null)
const job = ref(null)
const members = ref([])
const checking = ref(false); const submitting = ref(false); const cancelling = ref(false)
let timer = null

// config state
const on = reactive({ mem: false, cpu: false, log: false, sleep: false, expire: false })
const f = reactive({ mem_mb: null, cpus: null, log_level: 'info', sleep_idle_hours: null, expire_days: null })
const newOwner = ref(null)
const aclUsers = ref([]); const aclLevel = ref('operate')

const title = computed(() => `批量${VERB[kind.value] || ''}实例`)
const verb = computed(() => VERB[kind.value] || '')
const danger = computed(() => kind.value === 'env.trash' || kind.value === 'env.purge')
const needRoot = computed(() => ROOT_KINDS.includes(kind.value))
const oneTenant = computed(() => ctxTenantId.value != null)
const skipCount = computed(() => (preflight.value ? preflight.value.items.length - preflight.value.ok_count : 0))
const jobRunning = computed(() => job.value && ['queued', 'running', 'cancelling'].includes(job.value.status))
const donePct = computed(() => (job.value?.total ? Math.round(((job.value.succeeded + job.value.failed + job.value.skipped) / job.value.total) * 100) : 0))
const statusText = computed(() => ({ queued: '排队中', running: '执行中', cancelling: '取消中', done: '已完成', cancelled: '已取消' }[job.value?.status] || ''))
const configValid = computed(() => {
  if (kind.value === 'env.edit') return Object.values(on).some(Boolean)
  if (kind.value === 'env.transfer') return oneTenant.value && !!newOwner.value
  if (kind.value === 'acl.grant' || kind.value === 'acl.revoke') return oneTenant.value && aclUsers.value.length > 0
  return true
})

function buildPayload() {
  if (kind.value === 'env.edit') {
    const fields = {}
    if (on.mem) fields.mem_mb = f.mem_mb || null
    if (on.cpu) fields.cpus = f.cpus || null
    if (on.log) fields.log_level = f.log_level
    if (on.sleep) fields.sleep_idle_hours = f.sleep_idle_hours ?? null
    if (on.expire) fields.expire_days = f.expire_days ?? null
    return { fields }
  }
  if (kind.value === 'env.transfer') return { new_owner_user_id: newOwner.value }
  if (kind.value === 'acl.grant') return { entries: aclUsers.value.map((u) => ({ user_id: u, level: aclLevel.value })) }
  if (kind.value === 'acl.revoke') return { user_ids: aclUsers.value }
  return null
}

async function open(k, targetIds, ctx = {}) {
  kind.value = k; ids.value = [...targetIds]; job.value = null; preflight.value = null
  ctxTenantId.value = ctx.tenantId ?? null
  Object.keys(on).forEach((x) => (on[x] = false))
  Object.assign(f, { mem_mb: null, cpus: null, log_level: 'info', sleep_idle_hours: null, expire_days: null })
  newOwner.value = null; aclUsers.value = []; aclLevel.value = 'operate'; members.value = []
  visible.value = true
  if (CONFIG_KINDS.includes(k)) {
    phase.value = 'config'
    if (ROOT_KINDS.includes(k) && ctxTenantId.value != null) {
      try { members.value = await api.get(`/tenants/${ctxTenantId.value}/members`, { silent: true }) } catch {}
    }
  } else {
    await runPreflight()
  }
}
async function runPreflight() {
  phase.value = 'confirm'; checking.value = true
  try { preflight.value = await api.post('/bulk/env-ops/preflight', { kind: kind.value, target_ids: ids.value }) } catch {} finally { checking.value = false }
}
function toConfirm() { runPreflight() }
async function submit() {
  submitting.value = true
  try {
    const body = { kind: kind.value, target_ids: ids.value, idempotency_key: `op-${kind.value}-${Date.now()}` }
    if (CONFIG_KINDS.includes(kind.value)) body.payload = buildPayload()
    const j = await api.post('/bulk/env-ops', body)
    job.value = j; phase.value = 'running'; emit('done')
    if (jobRunning.value) startPoll()
  } catch {} finally { submitting.value = false }
}
function startPoll() {
  stopPoll()
  timer = setInterval(async () => {
    try { job.value = await api.get(`/bulk/${job.value.id}`, { silent: true }); emit('done'); if (!jobRunning.value) stopPoll() } catch {}
  }, 1500)
}
function stopPoll() { if (timer) { clearInterval(timer); timer = null } }
async function cancel() { cancelling.value = true; try { job.value = await api.post(`/bulk/${job.value.id}/cancel`) } catch {} finally { cancelling.value = false } }
async function retry() { try { job.value = await api.post(`/bulk/${job.value.id}/retry`); startPoll() } catch {} }
function onClosed() { stopPoll(); emit('done') }
function itemTone(s) { return { success: 'success', failed: 'danger', running: 'primary', skipped: 'warning', cancelled: 'info', pending: 'info' }[s] || 'info' }
function itemLabel(s) { return { success: '成功', failed: '失败', running: '进行中', skipped: '跳过', cancelled: '已取消', pending: '排队中' }[s] || s }
defineExpose({ open })
</script>

<style scoped>
.tip { font-size: 12.5px; margin-bottom: 10px; line-height: 1.6; }
.tip.mut, .mut { color: var(--text-3); }
.warn { color: var(--warning, #b45309); font-size: 13px; padding: 8px 0; }
.cfg .grp { border: 1px solid var(--line-2); border-radius: 8px; padding: 10px 12px; margin-bottom: 6px; }
.ctrl { display: flex; align-items: center; gap: 10px; margin-top: 8px; }
.sum { display: flex; gap: 8px; margin-bottom: 10px; }
.danger-tip { color: var(--warning, #b45309); font-size: 12.5px; margin-bottom: 10px; line-height: 1.6; }
.fail { color: var(--danger); }
.run-head { display: flex; align-items: center; gap: 18px; margin-bottom: 12px; }
.run-stat .rs { font-size: 13px; margin: 2px 0; }
.run-stat .ok { color: var(--success); } .run-stat .fail { color: var(--danger); } .run-stat .skip { color: var(--warning, #b45309); }
</style>
