<template>
  <!-- 实例看板卡片:头(版本图标 / 名称 / 状态)+ 体(域名 / 进度 / 资源 / 元信息)+ 脚(操作) -->
  <div class="card" :class="[`kind-${row.kind}`, `st-${row.status}`, `tone-${tone}`, { selected }]">
    <el-checkbox class="card-sel" :model-value="selected" size="large" @change="$emit('select', $event)" @click.stop />
    <div class="card-head">
      <div class="app-icon" :class="`v${row.odoo_version}`"><span class="ver">{{ row.odoo_version }}</span></div>
      <div class="names">
        <div class="name" :title="row.name">{{ row.name }}</div>
        <div class="sub"><span class="tn">{{ tenantLabel }}</span><span class="badge kind" :class="`k-${row.kind}`">{{ kindLabel(row.kind) }}</span><span class="badge ver">Odoo {{ row.odoo_version }}</span><span class="badge ed" :class="row.edition === 'enterprise' ? 'ent' : 'com'">{{ editionLabel(row.edition) }}</span></div>
      </div>
      <div class="status-pill" :class="tone"><i class="pulse" />{{ statusLabel(row.status) }}</div>
    </div>

    <div class="card-body">
      <div class="domain" v-if="row.url">
        <el-icon><Link /></el-icon>
        <a v-if="row.status === 'running'" :href="row.url" target="_blank" rel="noopener">{{ stripProto(row.url) }}</a>
        <span v-else class="muted">{{ stripProto(row.url) }}</span>
      </div>
      <div class="domain" v-else><el-icon><Link /></el-icon><span class="muted">尚未分配域名</span></div>

      <div v-if="busy" class="progress-box">
        <div class="progress-msg"><el-icon class="is-loading"><Loading /></el-icon><span>{{ opLabel(row.status) }}:{{ row.status_message || '处理中...' }}</span><b>{{ row.progress || 0 }}%</b></div>
        <el-progress :percentage="row.progress || 0" :stroke-width="8" :show-text="false" :striped="true" :striped-flow="true" :color="opColor(row.status)" />
      </div>
      <div v-else-if="row.status === 'failed'" class="progress-line fail">
        <el-icon><WarningFilled /></el-icon><span>{{ row.status_message || '创建失败' }}</span>
      </div>
      <div v-else-if="row.status === 'sleeping'" class="progress-line sleep">
        <el-icon><MoonNight /></el-icon><span>{{ row.status_message || '长时间无访问已休眠,访问时自动唤醒' }}</span>
      </div>

      <div class="metrics" v-if="row.status === 'running' && canStats">
        <div class="metric">
          <div class="metric-h"><span>CPU</span><b>{{ stats.cpu_percent ?? '-' }}%</b></div>
          <div class="bar"><i :style="{ width: (stats.cpu_percent || 0) + '%', background: barColor(stats.cpu_percent) }" /></div>
        </div>
        <div class="metric">
          <div class="metric-h"><span>内存</span><b>{{ fmtSize(stats.mem_usage) }} <span class="muted">/ {{ fmtSize(stats.mem_limit) }}</span></b></div>
          <div class="bar"><i :style="{ width: (stats.mem_percent || 0) + '%', background: barColor(stats.mem_percent) }" /></div>
        </div>
      </div>

      <div class="meta">
        <div><span class="k">镜像</span><span class="v">{{ imageText }}<span v-if="row.edition === 'enterprise' && row.enterprise_commit" class="muted"> · 企业版 {{ row.enterprise_commit.slice(0, 8) }}</span></span></div>
        <div><span class="k">分支</span><span class="v">{{ row.branch || '—' }}<span v-if="row.code_commit" class="muted mono"> @{{ shortSha(row.code_commit) }}</span></span></div>
        <div><span class="k">数据库</span><span class="v">{{ row.db_name || '—' }}<a v-if="row.extra_db_count && can(row, 'open')" href="#" class="db-more" :title="`共 ${row.extra_db_count + 1} 个数据库(主库 + ${row.extra_db_count} 个附加库),点击管理`" @click.prevent="$emit('more', 'databases', row)"> ⛁ +{{ row.extra_db_count }}</a></span></div>
        <div><span class="k">运行</span><span class="v">{{ row.status === 'running' ? uptime(stats.started_at) : '—' }}</span></div>
        <div><span class="k">创建</span><span class="v" :title="fmtLocal(row.created_at)">{{ fmtDate(row.created_at) }}</span></div>
        <div><span class="k">过期</span>
          <span class="v" :class="expireSoon(row) ? 'exp-soon' : row.expires_at ? '' : 'muted'"><el-icon v-if="row.expires_at" style="vertical-align: -2px"><Timer /></el-icon> {{ expireShort(row) }}</span>
        </div>
      </div>
    </div>

    <!-- 回收站里的实例:只有恢复 / 彻底删除 -->
    <!-- 分支环境汇总:点击进入详情 -->
    <div v-if="children.length" class="branches-sum" @click.stop="$emit('project', row)" title="查看分支环境">
      <span class="bs-title"><el-icon><Collection /></el-icon>分支环境 {{ children.length }}</span>
      <span v-for="c in children.slice(0, 4)" :key="c.id" class="bs-item" :class="[`k-${c.kind}`]"><i class="dot" :class="statusTone(c.status)" />{{ c.branch || c.name }}<span class="bs-k">{{ kindLabel(c.kind) }}</span></span>
      <span v-if="children.length > 4" class="bs-more muted">+{{ children.length - 4 }}</span>
    </div>
    <div v-if="row.status === 'deleted'" class="card-foot trash-foot">
      <span class="trash-note muted"><el-icon><Delete /></el-icon>{{ trashNote }}</span>
      <span class="spacer" />
      <el-button v-if="can(row, 'delete') && isEnvOwner(row)" size="small" type="primary" plain :disabled="busy" @click="$emit('act', row, 'untrash')"><el-icon><RefreshLeft /></el-icon>恢复</el-button>
      <el-button v-if="can(row, 'delete') && isEnvOwner(row)" size="small" type="danger" plain :disabled="busy" @click="$emit('more', 'purge', row)">彻底删除</el-button>
    </div>
    <div v-else class="card-foot">
      <el-button circle size="small" :title="row.status === 'running' ? '打开实例' : '唤醒并打开'" :disabled="!canOpenNow(row) || !can(row, 'open')" @click="$emit('open', row)"><el-icon><TopRight /></el-icon></el-button>
      <el-button v-if="can(row, 'create') && (!row.container_name || row.status === 'failed')" circle size="small" type="primary" :title="row.container_name ? '重试创建' : '创建并启动'" :disabled="busy" @click="$emit('act', row, 'provision')"><el-icon><VideoPlay /></el-icon></el-button>
      <el-button v-else-if="row.status === 'stopped' && can(row, 'start')" circle size="small" type="success" title="启动" @click="$emit('act', row, 'start')"><el-icon><VideoPlay /></el-icon></el-button>
      <el-button v-else-if="row.status === 'sleeping' && can(row, 'open')" circle size="small" type="success" title="唤醒" @click="$emit('act', row, 'start')"><el-icon><Sunny /></el-icon></el-button>
      <el-button v-else-if="row.status === 'running' && can(row, 'stop')" circle size="small" type="warning" title="停止" @click="$emit('act', row, 'stop')"><el-icon><VideoPause /></el-icon></el-button>
      <el-button v-if="can(row, 'restart')" circle size="small" title="重启" :disabled="row.status !== 'running'" @click="$emit('act', row, 'restart')"><el-icon><RefreshRight /></el-icon></el-button>
      <el-button v-if="can(row, 'logs')" circle size="small" title="日志" @click="$emit('logs', row)"><el-icon><Document /></el-icon></el-button>
      <el-button v-if="deployable" circle size="small" type="primary" plain title="部署代码" :disabled="busy" @click="$emit('deploy', row)"><el-icon><Promotion /></el-icon></el-button>
      <span class="spacer" />
      <el-button v-if="hasProject" size="small" type="primary" plain class="detail-btn" @click="$emit('project', row)"><el-icon><Collection /></el-icon>详情</el-button>
      <el-dropdown v-if="can(row, 'edit') || can(row, 'delete') || (row.repo_url && can(row, 'view'))" trigger="click" @command="(c) => $emit('more', c, row)">
        <el-button circle size="small" title="更多"><el-icon><MoreFilled /></el-icon></el-button>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item v-if="row.repo_url && can(row, 'view')" command="deployments">部署历史</el-dropdown-item>
            <el-dropdown-item v-if="row.db_name && can(row, 'open')" command="databases">数据库{{ row.extra_db_count ? `(${row.extra_db_count + 1})` : '' }}…</el-dropdown-item>
            <el-dropdown-item v-if="!row.repo_url && row.container_name && can(row, 'deploy')" command="customcode">定制代码…</el-dropdown-item>
            <el-dropdown-item v-if="can(row, 'edit')" command="edit" :disabled="busy">编辑</el-dropdown-item>
            <el-dropdown-item v-if="isEnvOwner(row)" command="acl">访问权限…</el-dropdown-item>
            <el-dropdown-item v-if="can(row, 'delete') && isEnvOwner(row)" command="delete" :disabled="busy" divided><span style="color: var(--danger)">删除实例</span></el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<script setup>
import { canOpenNow } from '../../utils/openEnv'
import { computed } from 'vue'
import { Link, Loading, WarningFilled, Timer, TopRight, VideoPlay, VideoPause, RefreshRight, Document, Promotion, Collection, MoreFilled, MoonNight, Sunny, Delete, RefreshLeft } from '@element-plus/icons-vue'
import { can, isEnvOwner, defaults } from '../../store'
import { kindLabel, statusLabel, statusTone, opLabel, opColor, isBusy, editionLabel, expireShort, expireSoon, barColor } from '../../utils/labels'
import { fmtDate, fmtLocal, fmtSize, uptime, stripProto, shortSha } from '../../utils/format'

const props = defineProps({
  row: { type: Object, required: true },
  stats: { type: Object, default: () => ({}) },
  tenantLabel: { type: String, default: '' },
  hasProject: { type: Boolean, default: false },
  children: { type: Array, default: () => [] },  // 本实例(项目)内按分支派生的环境,在卡片里汇总显示,不单独成卡
  selected: { type: Boolean, default: false },  // 批量选择
})
defineEmits(['open', 'act', 'logs', 'deploy', 'project', 'more', 'select'])
const trashNote = computed(() => {
  if (!props.row.deleted_at) return '在回收站中'
  const d = new Date(props.row.deleted_at)
  return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')} 移入回收站,数据保留中`
})
const busy = computed(() => isBusy(props.row))
const tone = computed(() => statusTone(props.row.status))
const canStats = computed(() => can(props.row, 'stats'))
const deployable = computed(() => !!(props.row.repo_url && props.row.branch && props.row.container_name && can(props.row, 'deploy')))
const imageText = computed(() => props.row.image_tag || (props.row.base_mode === 'official' ? `odoo:${props.row.odoo_version}` : `odoosh-base:${props.row.odoo_version}`))
</script>

<style scoped>
.card { background: var(--surface); border-radius: 12px; border: 1px solid var(--line); box-shadow: var(--shadow-sm); display: flex; flex-direction: column; overflow: hidden; position: relative; transition: transform .18s ease, box-shadow .18s ease, border-color .18s; }
.card::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px; background: var(--text-3); }
.card.selected { border-color: var(--brand); box-shadow: 0 0 0 2px var(--brand-200, rgba(64, 128, 255, .25)); }
.card-sel { position: absolute; top: 8px; left: 10px; z-index: 3; opacity: 0; padding: 2px; background: var(--surface); border-radius: 5px; box-shadow: var(--shadow-sm); transition: opacity .15s; height: auto; }
.card:hover .card-sel, .card.selected .card-sel { opacity: 1; }
.card.kind-production::before { background: linear-gradient(180deg, #ef4444, #f97316); }
.card.kind-staging::before { background: linear-gradient(180deg, #f59e0b, #fbbf24); }
.card.kind-dev::before { background: linear-gradient(180deg, #3b82f6, #06b6d4); }
.card:hover { transform: translateY(-3px); box-shadow: 0 12px 28px rgba(16, 24, 40, 0.10); border-color: #dde3ea; }
.card.tone-stopped, .card.tone-sleeping { opacity: .9; }
.card.tone-busy { border-color: #fde68a; }
.card.tone-creating { border-color: #a7f3d0; }
.card.tone-failed { border-color: #fecaca; }

.card-head { display: flex; align-items: center; gap: 10px; padding: 12px 14px 6px 16px; }
.app-icon { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 800; flex: none; box-shadow: inset 0 -2px 0 rgba(0,0,0,.15); }
.app-icon .ver { font-size: 13px; letter-spacing: -.5px; }
.app-icon.v19 { background: linear-gradient(135deg, #714b67, #a24689); }
.app-icon.v18 { background: linear-gradient(135deg, #017e84, #21b799); }
.app-icon.v17 { background: linear-gradient(135deg, #875a7b, #e46f78); }
.ed-ent { color: var(--warn); font-weight: 600; }
/* 副标题徽章:类型 / 版本 / 版本类型 */
.sub { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.sub .tn { color: var(--text-2); font-weight: 500; margin-right: 2px; }
.badge { display: inline-flex; align-items: center; height: 18px; padding: 0 7px; border-radius: 5px; font-size: 11px; font-weight: 700; line-height: 1; letter-spacing: .01em; white-space: nowrap; }
.badge.kind { background: #f1f5f9; color: #475569; }
.badge.k-production { background: #fee2e2; color: #b91c1c; }
.badge.k-staging { background: #fef3c7; color: #b45309; }
.badge.k-dev { background: #dbeafe; color: #1d4ed8; }
.badge.ver { background: var(--brand-50); color: var(--brand-600); border: 1px solid var(--brand-100); }
.badge.ed.ent { background: linear-gradient(135deg, #f59e0b, #d97706); color: #fff; box-shadow: 0 1px 3px rgba(217, 119, 6, .35); }
.badge.ed.com { background: #ecfdf5; color: #047857; }
.names { min-width: 0; flex: 1; }
.names .name { font-size: 16px; font-weight: 700; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.names .sub { font-size: 12px; color: var(--text-3); margin-top: 2px; }

.card-body { padding: 2px 14px 8px 16px; flex: 1; display: flex; flex-direction: column; gap: 8px; }
.domain { display: flex; align-items: center; gap: 6px; font-size: 13px; color: var(--text-2); min-width: 0; }
.domain a { color: var(--brand); text-decoration: none; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; } .domain a:hover { text-decoration: underline; }
.progress-line { display: flex; align-items: center; gap: 8px; font-size: 12.5px; color: var(--warn); background: var(--warn-bg); padding: 8px 10px; border-radius: 8px; }
.progress-line.fail { color: var(--danger); background: var(--danger-bg); }
.progress-line.sleep { color: var(--sleep); background: var(--sleep-bg); }
.progress-line span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.progress-box { background: var(--surface-2); border: 1px solid var(--line-2); border-radius: 10px; padding: 8px 10px 10px; }
.progress-msg { display: flex; align-items: center; gap: 8px; font-size: 12.5px; color: var(--text-2); margin-bottom: 6px; }
.progress-msg span { flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.progress-msg b { font-variant-numeric: tabular-nums; }
.exp-soon { color: var(--danger) !important; font-weight: 600; }
.metrics { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.metric-h { display: flex; justify-content: space-between; font-size: 12px; color: var(--text-3); margin-bottom: 4px; }
.metric-h b { color: var(--text); font-weight: 600; }
.bar { height: 6px; border-radius: 999px; background: var(--line-2); overflow: hidden; }
.bar i { display: block; height: 100%; border-radius: 999px; transition: width .6s ease; }
.meta { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 12px; font-size: 12px; margin-top: 0; }
.meta > div { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.meta .k { color: var(--text-3); margin-right: 6px; }
.meta .v { color: var(--text-2); font-weight: 500; }
/* 底栏:左侧一排等大的圆形图标按钮(打开 / 启停 / 重启 / 日志 / 部署),右侧「详情」+ 更多 */
.card-foot { display: flex; align-items: center; gap: 6px; padding: 8px 10px 8px 16px; border-top: 1px solid var(--line-2); flex-wrap: nowrap; background: var(--surface-2); }
.card-foot .spacer { flex: 1; }
.card-foot :deep(.el-button + .el-button) { margin-left: 0; }
.card-foot :deep(.el-button.is-circle) { width: 28px; height: 28px; }
.card-foot .detail-btn { height: 28px; padding: 0 10px; }
.card-foot .detail-btn .el-icon { margin-right: 3px; }
.trash-foot { background: var(--danger-bg); }
.trash-note { display: inline-flex; align-items: center; gap: 6px; font-size: 12px; }
.card.st-deleted { opacity: .92; }
.card.st-deleted .card-body { filter: grayscale(.4); }
.branches-sum { display: flex; align-items: center; flex-wrap: wrap; gap: 6px; padding: 6px 12px 6px 16px; border-top: 1px dashed var(--line-2); font-size: 12px; cursor: pointer; background: var(--surface-2); }
.branches-sum:hover { background: #f3f4f7; }
.bs-title { display: inline-flex; align-items: center; gap: 4px; font-weight: 650; color: var(--text-2); margin-right: 2px; }
.bs-item { display: inline-flex; align-items: center; gap: 5px; padding: 1px 8px 1px 6px; border-radius: 999px; background: #fff; border: 1px solid var(--line); font-weight: 600; color: var(--text); max-width: 160px; }
.bs-item > span:first-child, .bs-item { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bs-item .dot { width: 7px; height: 7px; border-radius: 50%; background: #cbd5e1; flex: none; }
.bs-item .dot.running { background: var(--ok); } .bs-item .dot.creating { background: #10b981; } .bs-item .dot.busy { background: var(--warn); } .bs-item .dot.failed { background: var(--danger); } .bs-item .dot.sleeping { background: var(--sleep); }
.bs-k { font-size: 10.5px; font-weight: 600; padding: 0 5px; border-radius: 4px; background: #f1f5f9; color: #475569; }
.bs-item.k-production .bs-k { background: #fee2e2; color: #b91c1c; } .bs-item.k-staging .bs-k { background: #fef3c7; color: #b45309; } .bs-item.k-dev .bs-k { background: #dbeafe; color: #1d4ed8; }
</style>
