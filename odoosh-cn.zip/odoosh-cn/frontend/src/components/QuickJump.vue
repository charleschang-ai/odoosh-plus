<template>
  <!-- 顶栏「跳转到实例」:所有页面可用的公共入口。首次展开时拉一次实例列表(静默),按名称 / 域名 / 分支 / 组织过滤;
       选中后:绑定了仓库的实例进详情页,否则回实例列表并带上搜索词 -->
  <el-select :model-value="null" filterable remote reserve-keyword :remote-method="filter" :loading="loading" placeholder="跳转到实例…"
    class="quick-jump" size="default" :teleported="true" popper-class="quick-jump-pop" @visible-change="onVisible" @change="go">
    <template #prefix><el-icon><Search /></el-icon></template>
    <el-option v-for="e in shown" :key="e.id" :value="e.id" :label="e.name">
      <div class="qj-row">
        <span class="qj-dot" :class="statusTone(e.status)" />
        <span class="qj-name">{{ e.name }}</span>
        <span class="qj-sub">{{ tenantName(e.tenant_id) }}<span v-if="e.branch"> · {{ e.branch }}</span></span>
        <span class="qj-kind" :class="`k-${e.kind}`">{{ kindLabel(e.kind) }}</span>
      </div>
    </el-option>
    <template #empty><div class="qj-empty">{{ loading ? '加载中…' : (all.length ? '没有匹配的实例' : '暂无实例') }}</div></template>
  </el-select>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { Search } from '@element-plus/icons-vue'
import api from '../api'
import { tenantName, loadTenants } from '../store'
import { kindLabel, statusTone } from '../utils/labels'

const router = useRouter()
const all = ref([]); const shown = ref([]); const loading = ref(false)
let loadedAt = 0
async function onVisible(v) {
  if (!v) return
  if (Date.now() - loadedAt < 30000 && all.value.length) { shown.value = all.value.slice(0, 30); return }
  loading.value = true
  try {
    const [list] = await Promise.all([api.get('/environments', { silent: true }), loadTenants().catch(() => {})])
    all.value = (list || []).filter((e) => e.status !== 'deleted')
    loadedAt = Date.now(); shown.value = all.value.slice(0, 30)
  } catch {} finally { loading.value = false }
}
function filter(q) {
  const k = (q || '').trim().toLowerCase()
  shown.value = (k ? all.value.filter((e) => [e.name, e.url, e.domain, e.branch, tenantName(e.tenant_id)].some((x) => (x || '').toString().toLowerCase().includes(k))) : all.value).slice(0, 30)
}
function go(id) {
  const e = all.value.find((x) => x.id === id)
  if (!e) return
  if (e.repo_url && e.branch && e.my_role) router.push({ path: `/environments/${e.project_id || e.id}`, query: e.project_id ? { branch: e.branch } : {} })
  else router.push({ path: '/environments', query: { q: e.name } })
}
</script>

<style scoped>
.quick-jump { width: 190px; }
.quick-jump :deep(.el-select__wrapper) { box-shadow: 0 0 0 1px var(--line-2) inset !important; background: var(--surface-2); border-radius: 999px; padding-left: 10px; }
.quick-jump :deep(.el-select__wrapper.is-focused) { box-shadow: 0 0 0 1px var(--brand) inset !important; background: #fff; }
</style>
<style>
.quick-jump-pop { min-width: 320px !important; }
.quick-jump-pop .el-select-dropdown__item { height: auto; line-height: 1.3; padding: 6px 12px; }
.qj-row { display: flex; align-items: center; gap: 8px; min-width: 0; }
.qj-dot { width: 8px; height: 8px; border-radius: 50%; background: #94a3b8; flex: none; }
.qj-dot.running { background: var(--ok); } .qj-dot.creating { background: #10b981; } .qj-dot.busy { background: var(--warn); } .qj-dot.failed { background: var(--danger); } .qj-dot.sleeping { background: var(--sleep); }
.qj-name { font-weight: 600; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.qj-sub { font-size: 12px; color: var(--text-3); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; }
.qj-kind { font-size: 10.5px; font-weight: 700; padding: 1px 6px; border-radius: 4px; background: #f1f5f9; color: #475569; flex: none; }
.qj-kind.k-production { background: #fee2e2; color: #b91c1c; } .qj-kind.k-staging { background: #fef3c7; color: #b45309; } .qj-kind.k-dev { background: #dbeafe; color: #1d4ed8; }
.qj-empty { padding: 10px; font-size: 12.5px; color: var(--text-3); text-align: center; }
</style>
