<template>
  <div class="ai-panel" :class="{ dense }">
    <!-- 会话列表(整页版;可收起) -->
    <aside v-if="!dense && !convCollapsed" class="conv-list">
      <div class="cl-head">
        <span class="cl-title">会话</span>
        <button class="mini-btn" title="收起" @click="setConvCollapsed(true)"><el-icon><Fold /></el-icon></button>
      </div>
      <button class="new-btn" @click="newConv"><el-icon><Plus /></el-icon>新会话</button>
      <div class="convs">
        <div v-for="c in conversations" :key="c.id" class="conv" :class="{ active: c.id === activeId }" @click="openConv(c.id)">
          <el-icon class="ci"><ChatDotRound /></el-icon>
          <span class="ct">{{ c.title || '新会话' }}</span>
          <el-icon class="del" title="删除" @click.stop="removeConv(c)"><Delete /></el-icon>
        </div>
        <div v-if="!conversations.length" class="empty-conv">还没有会话</div>
      </div>
    </aside>

    <section class="chat">
      <header class="chat-head">
        <div class="title">
          <button v-if="!dense && convCollapsed" class="mini-btn expand" title="展开会话列表" @click="setConvCollapsed(false)"><el-icon><Expand /></el-icon></button>
          <span class="mode-badge" :class="mode"><el-icon><MagicStick /></el-icon>{{ modeLabel }}</span>
          <span v-if="!dense" class="hint">{{ modeHint }}</span>
          <el-select v-if="dense && conversations.length" :model-value="activeId" size="small" class="conv-switch" placeholder="切换会话" @change="openConv">
            <el-option v-for="c in conversations" :key="c.id" :value="c.id" :label="c.title || '新会话'" />
          </el-select>
        </div>
        <div class="head-actions">
          <button v-if="dense" class="mini-btn" title="新会话" @click="newConv"><el-icon><Plus /></el-icon></button>
          <button class="mini-btn" title="接入配置" @click="openCfg"><el-icon><Setting /></el-icon></button>
        </div>
      </header>

      <div v-if="cfg && !cfg.key_set" class="need-cfg">
        <el-icon><WarningFilled /></el-icon>
        <span>还没配置模型 API key,<a @click="openCfg">点此配置</a>(仅你可见)后即可使用。</span>
      </div>

      <div v-if="hasTools && contextEnv && contextEnv.id" class="ctx-bar">
        <el-icon><Aim /></el-icon>
        <span class="ctx-txt">当前实例 <b>{{ contextEnv.name || ('#' + contextEnv.id) }}</b></span>
        <el-button size="small" text type="primary" :disabled="running" @click="diagnoseContext">诊断这个实例</el-button>
      </div>

      <div ref="scrollEl" class="messages">
        <div v-if="!renderItems.length && !running" class="welcome">
          <div class="wl-orb"><el-icon :size="26"><MagicStick /></el-icon></div>
          <p>{{ welcomeText }}</p>
          <div v-if="hasTools" class="quick-tips">
            <button v-for="q in tips" :key="q" class="tip" @click="sendText(q)">{{ q }}</button>
          </div>
        </div>
        <div v-for="(it, i) in renderItems" :key="i" class="row" :class="it.cls">
          <template v-if="it.kind === 'user'">
            <div class="bubble user">{{ it.text }}</div>
          </template>
          <template v-else-if="it.kind === 'assistant'">
            <div class="avatar ai"><el-icon><MagicStick /></el-icon></div>
            <div class="bubble assistant">
              <div v-if="it.text" class="md" v-html="renderMarkdown(it.text)"></div>
              <div v-else-if="it.streaming" class="typing"><span></span><span></span><span></span></div>
            </div>
          </template>
          <ToolCard v-else-if="it.kind === 'tool'" :name="it.name" :args="it.args" :status="it.status" :result="it.result" class="row-tool" />
          <div v-else-if="it.kind === 'confirm'" class="confirm-card">
            <div class="cc-head"><el-icon><WarnTriangleFilled /></el-icon> AI 请求执行变更操作</div>
            <div class="cc-body"><code>{{ it.summary }}</code></div>
            <div class="cc-act">
              <el-button size="small" @click="resolveConfirm(it.id, false)">拒绝</el-button>
              <el-button size="small" type="primary" @click="resolveConfirm(it.id, true)">确认执行</el-button>
            </div>
          </div>
          <div v-else-if="it.kind === 'notice'" class="notice">{{ it.text }}</div>
          <div v-else-if="it.kind === 'error'" class="err-line"><el-icon><CircleCloseFilled /></el-icon>{{ it.text }}</div>
        </div>
      </div>

      <footer class="composer">
        <div class="composer-box">
          <el-input v-model="draft" type="textarea" :autosize="{ minRows: 1, maxRows: 6 }" resize="none"
                    :placeholder="running ? 'AI 正在处理…' : (mode === 'ops' ? '描述要排查的问题…' : '问我系统怎么用…')"
                    @keydown.enter.exact.prevent="onSend" />
          <button v-if="!running" class="send" :disabled="!draft.trim() || (cfg && !cfg.key_set)" @click="onSend" title="发送(Enter)"><el-icon><Promotion /></el-icon></button>
          <button v-else class="send stop" @click="onAbort" title="停止"><el-icon><VideoPause /></el-icon></button>
        </div>
        <div class="composer-tip">Enter 发送 · Shift+Enter 换行</div>
      </footer>
    </section>

    <el-dialog v-model="cfgDlg" title="AI 接入配置(仅你可见)" width="500px" append-to-body class="ai-cfg-dlg">
      <el-form label-position="top">
        <el-form-item label="服务商">
          <el-select v-model="cfgForm.provider" @change="onProvider">
            <el-option v-for="p in presets" :key="p.key" :value="p.key" :label="p.label" />
          </el-select>
        </el-form-item>
        <el-form-item label="接口地址(base_url,OpenAI 兼容)">
          <el-input v-model="cfgForm.base_url" placeholder="如 https://api.deepseek.com/v1" />
        </el-form-item>
        <el-form-item label="模型">
          <el-input v-model="cfgForm.model" placeholder="如 deepseek-chat" />
        </el-form-item>
        <el-form-item label="API Key">
          <el-input v-model="cfgForm.api_key" type="password" show-password
                    :placeholder="cfg && cfg.key_set ? `已设置 ••••${cfg.key_tail || ''}(留空则不修改)` : '粘贴你的 API key'" />
        </el-form-item>
        <el-form-item label="每日 token 上限(可选,0 = 按平台默认)">
          <el-input v-model.number="cfgForm.max_daily_tokens" type="number" placeholder="0" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="cfgDlg = false">取消</el-button>
        <el-button type="primary" :loading="cfgSaving" @click="saveCfg">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, reactive, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, ChatDotRound, Delete, Setting, WarningFilled, WarnTriangleFilled, CircleCloseFilled, Promotion, VideoPause, MagicStick, Aim, Fold, Expand } from '@element-plus/icons-vue'
import api from '../../api'
import { session } from '../../store'
import { openAiStream } from '../../composables/useAiStream'
import { renderMarkdown } from '../../utils/md'
import ToolCard from './ToolCard.vue'

const props = defineProps({
  dense: { type: Boolean, default: false },
  active: { type: Boolean, default: true },
  contextEnv: { type: Object, default: null },
})

const OPS_TIPS = ['平台整体状态如何?', '有没有实例异常或最近崩溃?', '磁盘和内存还够吗?']
const ASSIST_TIPS = ['我的实例为什么打不开?', '帮我看看最近的部署有没有失败', '怎么从生产克隆一个预发环境?']

const conversations = ref([])
const activeId = ref(null)
const persisted = ref([])
const stream = reactive({ items: [], text: '', textActive: false })
const running = ref(false)
const draft = ref('')
const cfg = ref(null)
const presets = ref([])
const mode = ref('help')
const convCollapsed = ref(localStorage.getItem('aiConvCollapsed') === '1')
let es = null
let inited = false
const scrollEl = ref(null)

function setConvCollapsed(v) { convCollapsed.value = v; localStorage.setItem('aiConvCollapsed', v ? '1' : '0') }

const renderItems = computed(() => {
  const out = []
  for (const m of persisted.value) {
    if (m.role === 'user') out.push({ kind: 'user', cls: 'right', text: m.content })
    else if (m.role === 'assistant') {
      if (m.content) out.push({ kind: 'assistant', cls: 'left', text: m.content })
      for (const tc of m.tool_calls || []) out.push({ kind: 'tool', cls: 'left', name: tc.name, args: tc.arguments, status: 'done', result: null })
    } else if (m.role === 'tool') {
      const card = [...out].reverse().find((x) => x.kind === 'tool' && x.name === m.name && x.result === null)
      if (card) { card.result = m.content; card.status = (m.meta && m.meta.status) || 'ok' }
      else out.push({ kind: 'tool', cls: 'left', name: m.name, args: null, status: (m.meta && m.meta.status) || 'ok', result: m.content })
    }
  }
  for (const it of stream.items) out.push(it)
  if (stream.textActive) out.push({ kind: 'assistant', cls: 'left', text: stream.text, streaming: true })
  return out
})

const hasTools = computed(() => mode.value === 'ops' || mode.value === 'assist')
const tips = computed(() => (mode.value === 'ops' ? OPS_TIPS : ASSIST_TIPS))
const welcomeText = computed(() => (mode.value === 'ops'
  ? '描述要排查的问题,我会自动查日志、指标、健康与部署记录,变更操作会先征求你确认。'
  : mode.value === 'assist'
    ? '我可以解答系统怎么用,也能诊断你有权限的实例(查日志/监控/健康/部署),需要重启或重部署时会先征求你确认。'
    : '问我这个系统怎么用,例如「怎么从生产克隆一个预发环境?」'))
const modeLabel = computed(() => (mode.value === 'ops' ? '运维诊断' : mode.value === 'assist' ? '智能助手' : '功能助手'))
const modeHint = computed(() => (mode.value === 'ops' ? '检测与修复平台及所有实例问题(变更需你确认)'
  : mode.value === 'assist' ? '解答功能 + 诊断/修复你有权限的实例(变更需你确认)' : '解答系统功能与使用问题'))
function convBody() { return { mode: mode.value, tenant_id: session.currentTenantId } }

function scrollDown() { nextTick(() => { const el = scrollEl.value; if (el) el.scrollTop = el.scrollHeight }) }

async function init() {
  if (inited) return
  inited = true
  await Promise.all([loadConfig(), loadProviders(), loadConvs()])
  if (conversations.value.length) await openConv(conversations.value[0].id)
}
async function loadConfig() { cfg.value = await api.get('/ai/config', { silent: true }); mode.value = cfg.value.default_mode || 'help' }
async function loadProviders() { const r = await api.get('/ai/providers', { silent: true }); presets.value = r.presets || [] }
async function loadConvs() { conversations.value = await api.get('/ai/conversations', { silent: true }) }

async function openConv(id) {
  closeStream()
  activeId.value = id
  const r = await api.get(`/ai/conversations/${id}/messages`, { silent: true })
  persisted.value = r.messages
  const c = conversations.value.find((x) => x.id === id)
  if (c) mode.value = c.mode
  resetStream()
  scrollDown()
  if (r.running) { running.value = true; attachStream(id) }
}

async function newConv() {
  const c = await api.post('/ai/conversations', convBody())
  conversations.value.unshift(c)
  await openConv(c.id)
}

async function removeConv(c) {
  try { await ElMessageBox.confirm(`删除会话「${c.title || '新会话'}」?`, '确认', { type: 'warning' }) } catch { return }
  await api.delete(`/ai/conversations/${c.id}`)
  conversations.value = conversations.value.filter((x) => x.id !== c.id)
  if (activeId.value === c.id) { activeId.value = null; persisted.value = []; resetStream() }
}

function resetStream() { stream.items = []; stream.text = ''; stream.textActive = false }

async function ensureConv() {
  if (activeId.value) return activeId.value
  const c = await api.post('/ai/conversations', convBody())
  conversations.value.unshift(c)
  activeId.value = c.id
  persisted.value = []
  return c.id
}

async function sendText(text) {
  if (!text || running.value) return
  if (cfg.value && !cfg.value.key_set) { openCfg(); return }
  const id = await ensureConv()
  persisted.value.push({ role: 'user', content: text })
  resetStream()
  running.value = true
  scrollDown()
  try {
    await api.post(`/ai/conversations/${id}/send`, { content: text })
    attachStream(id)
  } catch (e) {
    running.value = false
    persisted.value.push({ role: 'assistant', content: `发送失败:${e.detail || e.message || ''}` })
  }
}

function onSend() { const t = draft.value.trim(); if (!t) return; draft.value = ''; sendText(t) }

function diagnoseContext() {
  const e = props.contextEnv
  if (!e || !e.id) return
  sendText(`请诊断实例 #${e.id}${e.name ? `(${e.name}${e.kind ? '、' + e.kind : ''})` : ''}:检查容器状态、健康探测、最近日志与部署记录,给出结论与建议。`)
}

function attachStream(id) { closeStream(); es = openAiStream(id, onEvent, {}) }
function flushText() { if (stream.textActive && stream.text) stream.items.push({ kind: 'assistant', cls: 'left', text: stream.text }); stream.text = ''; stream.textActive = false }

function onEvent(type, data) {
  if (type === 'text') { stream.textActive = true; stream.text += data.delta || ''; scrollDown() }
  else if (type === 'stream_reset') { stream.text = ''; stream.textActive = false }
  else if (type === 'tool_call') { flushText(); stream.items.push({ kind: 'tool', cls: 'left', id: data.id, name: data.name, args: data.arguments, status: 'running', result: null }) }
  else if (type === 'tool_result') { const c = stream.items.find((x) => x.kind === 'tool' && x.id === data.id); if (c) { c.result = data.content; c.status = data.status } scrollDown() }
  else if (type === 'confirm_request') { flushText(); stream.items.push({ kind: 'confirm', cls: 'left', id: data.id, tool: data.tool, summary: data.summary }); scrollDown() }
  else if (type === 'confirm_result') { const c = stream.items.find((x) => x.kind === 'confirm' && x.id === data.id); if (c) { c.kind = 'notice'; c.text = data.approved ? `已确认执行 ${c.tool}` : '已拒绝该操作' } }
  else if (type === 'notice') { stream.items.push({ kind: 'notice', cls: 'left', text: data.text }) }
  else if (type === 'error') { flushText(); stream.items.push({ kind: 'error', cls: 'left', text: data.message || '出错了' }) }
  else if (type === 'end') { onRunEnd() }
}

async function onRunEnd() {
  running.value = false
  const id = activeId.value
  closeStream()
  if (!id) return
  try { const r = await api.get(`/ai/conversations/${id}/messages`, { silent: true }); persisted.value = r.messages; resetStream() } catch {}
  loadConvs().catch(() => {})
  scrollDown()
}

async function resolveConfirm(callId, approved) { try { await api.post(`/ai/conversations/${activeId.value}/confirm`, { call_id: callId, approved }) } catch {} }
async function onAbort() { try { await api.post(`/ai/conversations/${activeId.value}/abort`) } catch {}; running.value = false; closeStream(); onRunEnd() }
function closeStream() { if (es) { es.close(); es = null } }

const cfgDlg = ref(false); const cfgSaving = ref(false)
const cfgForm = reactive({ provider: 'deepseek', base_url: '', model: '', api_key: '', max_daily_tokens: null })
function openCfg() {
  cfgForm.provider = cfg.value?.provider || 'deepseek'
  cfgForm.base_url = cfg.value?.base_url || presets.value.find((p) => p.key === cfgForm.provider)?.base_url || ''
  cfgForm.model = cfg.value?.model || presets.value.find((p) => p.key === cfgForm.provider)?.model || ''
  cfgForm.api_key = ''
  cfgForm.max_daily_tokens = cfg.value?.max_daily_tokens ?? null
  cfgDlg.value = true
}
function onProvider(key) { const p = presets.value.find((x) => x.key === key); if (p) { if (p.base_url) cfgForm.base_url = p.base_url; if (p.model) cfgForm.model = p.model } }
async function saveCfg() {
  cfgSaving.value = true
  try {
    const body = { provider: cfgForm.provider, base_url: cfgForm.base_url, model: cfgForm.model, max_daily_tokens: cfgForm.max_daily_tokens || 0 }
    if (cfgForm.api_key) body.api_key = cfgForm.api_key
    cfg.value = await api.put('/ai/config', body)
    cfgDlg.value = false
    ElMessage.success('已保存')
  } catch {} finally { cfgSaving.value = false }
}

watch(() => props.active, (a) => { if (a) init() }, { immediate: true })
onBeforeUnmount(closeStream)
defineExpose({ diagnoseContext, newConv })
</script>

<style scoped>
.ai-panel {
  display: flex; height: 100%; min-height: 0;
  /* 渐变背景:靛蓝(AI)在右上、品牌紫在左下,底色近白 —— 柔和有层次,不压过气泡可读性 */
  background:
    radial-gradient(1100px 420px at 100% 0%, rgba(99, 102, 241, .08), transparent 58%),
    radial-gradient(900px 520px at 0% 100%, rgba(113, 75, 103, .06), transparent 55%),
    linear-gradient(165deg, #eef1fb 0%, #f5f6f8 46%, #f4eef4 100%);
}

/* 会话列表 */
.conv-list { width: 220px; flex: none; border-right: 1px solid var(--line); display: flex; flex-direction: column; background: var(--surface); }
.cl-head { display: flex; align-items: center; justify-content: space-between; padding: 12px 12px 4px; }
.cl-title { font-size: 12px; font-weight: 700; letter-spacing: .06em; color: var(--text-3); }
.new-btn { margin: 8px 12px; height: 36px; border: 1px dashed var(--line-2); border-radius: 9px; background: transparent; color: var(--text-2); cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; font-size: 13px; transition: all .15s; }
.new-btn:hover { border-color: var(--brand); color: var(--brand); background: var(--brand-100); }
.convs { flex: 1; overflow-y: auto; padding: 0 8px 12px; }
.conv { display: flex; align-items: center; gap: 8px; padding: 9px 10px; border-radius: 9px; cursor: pointer; color: var(--text-2); font-size: 13.5px; }
.conv:hover { background: var(--surface-2); }
.conv.active { background: var(--brand-100); color: var(--brand-600); font-weight: 600; }
.conv .ci { flex: none; }
.conv .ct { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.conv .del { flex: none; opacity: 0; color: var(--text-3); }
.conv:hover .del { opacity: 1; }
.conv .del:hover { color: var(--danger, #f56c6c); }
.empty-conv { color: var(--text-3); font-size: 13px; text-align: center; padding: 24px 0; }

/* 头部 */
.chat { flex: 1; min-width: 0; display: flex; flex-direction: column; min-height: 0; }
.chat-head { flex: none; border-bottom: 1px solid var(--line); display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; gap: 8px; background: rgba(255, 255, 255, .5); backdrop-filter: saturate(1.3) blur(8px); }
.title { display: flex; align-items: center; gap: 8px; min-width: 0; flex: 1; }
.mode-badge { display: inline-flex; align-items: center; gap: 5px; font-size: 12px; font-weight: 700; padding: 4px 10px; border-radius: 999px; flex: none; }
.mode-badge.ops { background: linear-gradient(135deg, rgba(129,140,248,.18), rgba(99,102,241,.14)); color: #6366f1; }
.mode-badge.assist { background: linear-gradient(135deg, rgba(129,140,248,.18), rgba(45,212,191,.14)); color: #4f46e5; }
.mode-badge.help { background: linear-gradient(135deg, rgba(45,212,191,.18), rgba(13,148,136,.14)); color: #0d9488; }
.hint { font-size: 12.5px; color: var(--text-3); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.conv-switch { max-width: 180px; }
.head-actions { display: flex; gap: 2px; flex: none; }
.mini-btn { width: 30px; height: 30px; border: none; background: transparent; color: var(--text-2); border-radius: 8px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; }
.mini-btn:hover { background: var(--surface-2); color: var(--text); }
.mini-btn.expand { background: var(--surface-2); }

.need-cfg { margin: 10px 12px 0; padding: 9px 12px; background: rgba(230,162,60,.1); border: 1px solid rgba(230,162,60,.3); border-radius: 10px; color: #b88230; font-size: 12.5px; display: flex; align-items: center; gap: 8px; }
.need-cfg a { color: var(--brand); cursor: pointer; text-decoration: underline; }
.ctx-bar { margin: 10px 12px 0; padding: 7px 12px; background: linear-gradient(135deg, var(--brand-100), transparent); border: 1px solid var(--brand-100); border-radius: 10px; display: flex; align-items: center; gap: 8px; font-size: 12.5px; color: var(--brand-600); }
.ctx-txt { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* 消息区 */
.messages { flex: 1; overflow-y: auto; padding: 18px 16px; display: flex; flex-direction: column; gap: 14px; min-height: 0; }
.welcome { margin: auto; text-align: center; color: var(--text-3); max-width: 340px; display: flex; flex-direction: column; align-items: center; }
.wl-orb { width: 52px; height: 52px; border-radius: 16px; display: flex; align-items: center; justify-content: center; color: #fff; background: linear-gradient(135deg, #818cf8, #6366f1); box-shadow: 0 8px 24px -8px rgba(99,102,241,.6); margin-bottom: 14px; }
.welcome p { font-size: 13.5px; line-height: 1.7; }
.quick-tips { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; margin-top: 14px; }
.tip { border: 1px solid var(--line-2); background: var(--surface); color: var(--text-2); border-radius: 999px; padding: 6px 12px; font-size: 12.5px; cursor: pointer; transition: all .15s; }
.tip:hover { border-color: var(--brand); color: var(--brand); background: var(--brand-100); }

.row { display: flex; align-items: flex-start; gap: 9px; }
.row.right { justify-content: flex-end; }
.row.left { justify-content: flex-start; }
.avatar { width: 30px; height: 30px; border-radius: 9px; flex: none; display: inline-flex; align-items: center; justify-content: center; color: #fff; font-size: 15px; }
.avatar.ai { background: linear-gradient(135deg, #818cf8, #6366f1); box-shadow: 0 3px 10px -3px rgba(99,102,241,.55); }
.bubble { max-width: 80%; padding: 10px 14px; border-radius: 14px; font-size: 13.5px; line-height: 1.65; }
.bubble.user { background: var(--brand); color: #fff; border-top-right-radius: 4px; white-space: pre-wrap; word-break: break-word; box-shadow: 0 2px 8px -3px var(--brand); }
.bubble.assistant {
  /* 每条 AI 回复:淡靛蓝渐变 + 同色系描边 + 柔和投影(不再是纯白) */
  background: linear-gradient(135deg, #ffffff 0%, #f3f4fe 55%, #eef0fd 100%);
  border: 1px solid rgba(99, 102, 241, .16);
  border-top-left-radius: 4px;
  color: var(--text);
  box-shadow: 0 4px 14px -6px rgba(99, 102, 241, .22);
}
.row-tool { margin-left: 39px; }
.typing { display: flex; gap: 4px; padding: 4px 0; }
.typing span { width: 6px; height: 6px; border-radius: 50%; background: var(--text-3); animation: blink 1.2s infinite; }
.typing span:nth-child(2) { animation-delay: .2s; }
.typing span:nth-child(3) { animation-delay: .4s; }
@keyframes blink { 0%, 60%, 100% { opacity: .25; } 30% { opacity: 1; } }

/* Markdown */
.md :deep(.md-p) { margin: 0 0 8px; }
.md :deep(.md-p:last-child) { margin-bottom: 0; }
.md :deep(.md-h) { margin: 10px 0 6px; font-size: 14px; font-weight: 700; }
.md :deep(.md-ul), .md :deep(.md-ol) { margin: 4px 0 8px; padding-left: 20px; }
.md :deep(li) { margin: 3px 0; }
.md :deep(code) { background: var(--surface-2); padding: 1px 5px; border-radius: 5px; font-family: var(--font-mono, monospace); font-size: 12.5px; }
.md :deep(.md-code) { background: #1b2230; color: #e6edf3; padding: 10px 12px; border-radius: 10px; overflow-x: auto; margin: 8px 0; }
.md :deep(.md-code code) { background: none; padding: 0; color: inherit; font-size: 12.5px; line-height: 1.5; }
.md :deep(.md-q) { border-left: 3px solid var(--line-2); padding-left: 10px; color: var(--text-2); margin: 6px 0; }
.md :deep(a) { color: var(--brand); }
.md :deep(strong) { font-weight: 700; }
.md :deep(hr) { border: none; border-top: 1px solid var(--line); margin: 10px 0; }

.confirm-card { max-width: 88%; margin-left: 39px; border: 1px solid rgba(230,162,60,.4); background: rgba(230,162,60,.06); border-radius: 12px; padding: 11px 13px; }
.cc-head { font-weight: 650; font-size: 13px; color: #b88230; display: flex; align-items: center; gap: 6px; }
.cc-body { margin: 8px 0 10px; }
.cc-body code { font-size: 12px; background: var(--surface-2); padding: 6px 8px; border-radius: 6px; display: block; word-break: break-all; white-space: pre-wrap; }
.cc-act { display: flex; justify-content: flex-end; gap: 8px; }
.notice { font-size: 12px; color: var(--text-3); padding: 2px 4px 2px 39px; }
.err-line { font-size: 12.5px; color: var(--danger, #f56c6c); display: flex; align-items: center; gap: 6px; margin-left: 39px; }

/* 输入区 */
.composer { flex: none; border-top: 1px solid var(--line); padding: 12px 14px 10px; background: rgba(255, 255, 255, .5); backdrop-filter: saturate(1.3) blur(8px); }
.composer-box { display: flex; gap: 8px; align-items: flex-end; background: var(--surface); border: 1px solid var(--line-2); border-radius: 14px; padding: 6px 6px 6px 6px; transition: border-color .15s; }
.composer-box:focus-within { border-color: var(--brand); box-shadow: 0 0 0 3px var(--brand-100); }
.composer-box :deep(.el-textarea__inner) { border: none !important; box-shadow: none !important; background: transparent; padding: 6px 8px; font-size: 13.5px; }
.send { height: 34px; width: 40px; flex: none; border: none; border-radius: 10px; background: var(--brand); color: #fff; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; font-size: 16px; transition: opacity .15s, transform .1s; }
.send:hover:not(:disabled) { transform: translateY(-1px); }
.send:disabled { opacity: .4; cursor: not-allowed; }
.send.stop { background: var(--surface-2); color: var(--text-2); border: 1px solid var(--line-2); }
.composer-tip { text-align: center; font-size: 11px; color: var(--text-3); margin-top: 6px; }

/* 手机端 */
@media (max-width: 640px) {
  .conv-list { width: 180px; }
  .bubble { max-width: 86%; }
  .hint { display: none; }
}
</style>
