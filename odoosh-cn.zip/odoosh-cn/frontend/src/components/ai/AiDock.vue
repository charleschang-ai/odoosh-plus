<template>
  <div class="ai-dock" :style="{ width: width + 'px' }">
    <div class="drag" @pointerdown="startDrag" title="拖动调整宽度"></div>
    <div class="dock-head">
      <span class="dh-title"><el-icon><MagicStick /></el-icon> AI 助手</span>
      <div class="dh-actions">
        <button class="mini" title="在整页打开" @click="$emit('expand')"><el-icon><FullScreen /></el-icon></button>
        <button class="mini" title="收起" @click="$emit('close')"><el-icon><Close /></el-icon></button>
      </div>
    </div>
    <div class="dock-body">
      <AiChatPanel dense :active="open" :context-env="contextEnv" />
    </div>
  </div>
</template>

<script setup>
import { onBeforeUnmount, ref } from 'vue'
import { MagicStick, Close, FullScreen } from '@element-plus/icons-vue'
import AiChatPanel from './AiChatPanel.vue'

defineProps({ open: { type: Boolean, default: false }, contextEnv: { type: Object, default: null } })
defineEmits(['close', 'expand'])

const MIN = 340; const MAX = 760
const width = ref(Math.min(MAX, Math.max(MIN, Number(localStorage.getItem('aiDockWidth')) || 400)))
let dragging = false
function startDrag(e) {
  dragging = true
  e.target.setPointerCapture?.(e.pointerId)
  window.addEventListener('pointermove', onDrag)
  window.addEventListener('pointerup', endDrag)
  document.body.style.userSelect = 'none'
}
function onDrag(e) {
  if (!dragging) return
  const w = Math.min(MAX, Math.max(MIN, window.innerWidth - e.clientX))
  width.value = w
}
function endDrag() {
  dragging = false
  window.removeEventListener('pointermove', onDrag)
  window.removeEventListener('pointerup', endDrag)
  document.body.style.userSelect = ''
  localStorage.setItem('aiDockWidth', String(width.value))
}
onBeforeUnmount(endDrag)
</script>

<style scoped>
.ai-dock { flex: none; position: relative; border-left: 1px solid var(--line); background: var(--bg); display: flex; flex-direction: column; min-height: 0; }
.drag { position: absolute; left: -3px; top: 0; bottom: 0; width: 6px; cursor: col-resize; z-index: 5; }
.drag:hover { background: var(--brand-100); }
.dock-head { flex: none; height: 46px; display: flex; align-items: center; justify-content: space-between; padding: 0 12px; border-bottom: 1px solid var(--line); background: var(--surface); }
.dh-title { display: inline-flex; align-items: center; gap: 7px; font-weight: 650; font-size: 14px; color: var(--text); }
.dh-actions { display: flex; gap: 2px; }
.mini { width: 30px; height: 30px; border: none; background: transparent; color: var(--text-2); border-radius: 7px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; }
.mini:hover { background: var(--surface-2); color: var(--text); }
.dock-body { flex: 1; min-height: 0; }
</style>
