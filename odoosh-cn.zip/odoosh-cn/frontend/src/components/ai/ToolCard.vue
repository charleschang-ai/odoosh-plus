<template>
  <div class="tool-card" :class="statusCls">
    <div class="tc-head" @click="open = !open">
      <el-icon class="tc-ico"><component :is="icon" /></el-icon>
      <span class="tc-name">{{ label }}</span>
      <span class="tc-args" v-if="argText">{{ argText }}</span>
      <span class="tc-status">{{ statusText }}</span>
      <el-icon class="tc-caret" :class="{ open }"><ArrowRight /></el-icon>
    </div>
    <div v-if="open && (result || args)" class="tc-body">
      <pre v-if="args" class="tc-pre args">参数:{{ prettyArgs }}</pre>
      <pre v-if="result" class="tc-pre">{{ result }}</pre>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { Tools, Loading, CircleCheck, CircleClose, ArrowRight } from '@element-plus/icons-vue'

const props = defineProps({
  name: String,
  args: { type: [Object, String], default: null },
  status: { type: String, default: 'done' },  // running | ok | done | error | rejected | denied | timeout
  result: { type: String, default: null },
})
const open = ref(false)

const label = computed(() => props.name || '工具')
const argText = computed(() => {
  const a = props.args
  if (!a || typeof a !== 'object') return ''
  const parts = []
  for (const k of ['env_id', 'service', 'sql', 'command', 'action']) if (a[k] !== undefined) parts.push(`${a[k]}`)
  return parts.join(' ').slice(0, 60)
})
const prettyArgs = computed(() => { try { return JSON.stringify(props.args, null, 2) } catch { return String(props.args) } })
const isBad = computed(() => ['error', 'rejected', 'denied', 'timeout'].includes(props.status))
const statusCls = computed(() => (props.status === 'running' ? 'running' : isBad.value ? 'bad' : 'ok'))
const icon = computed(() => (props.status === 'running' ? Loading : isBad.value ? CircleClose : props.status === 'ok' || props.status === 'done' ? CircleCheck : Tools))
const statusText = computed(() => ({ running: '执行中…', ok: '已完成', done: '已完成', error: '出错', rejected: '未执行', denied: '已拒绝', timeout: '超时' }[props.status] || ''))
</script>

<style scoped>
.tool-card { max-width: 82%; border: 1px solid var(--line); border-radius: 10px; background: var(--surface); overflow: hidden; font-size: 12.5px; }
.tool-card.running { border-color: rgba(96, 165, 250, .5); }
.tool-card.bad { border-color: rgba(245, 108, 108, .4); }
.tc-head { display: flex; align-items: center; gap: 8px; padding: 8px 12px; cursor: pointer; }
.tc-head:hover { background: var(--surface-2); }
.tc-ico { flex: none; color: var(--text-3); }
.tool-card.running .tc-ico { color: #60a5fa; animation: spin 1s linear infinite; }
.tool-card.ok .tc-ico { color: #22c55e; }
.tool-card.bad .tc-ico { color: #f56c6c; }
@keyframes spin { to { transform: rotate(360deg); } }
.tc-name { font-weight: 650; color: var(--text); font-family: var(--font-mono, monospace); }
.tc-args { color: var(--text-3); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; min-width: 0; }
.tc-status { color: var(--text-3); flex: none; }
.tc-caret { flex: none; transition: transform .15s; color: var(--text-3); }
.tc-caret.open { transform: rotate(90deg); }
.tc-body { border-top: 1px solid var(--line); padding: 8px 12px; background: var(--surface-2); }
.tc-pre { margin: 0; white-space: pre-wrap; word-break: break-word; font-family: var(--font-mono, monospace); font-size: 12px; color: var(--text-2); max-height: 340px; overflow: auto; }
.tc-pre.args { color: var(--text-3); margin-bottom: 6px; }
</style>
