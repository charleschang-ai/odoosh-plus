<template>
  <el-dialog :model-value="modelValue" title="批量新建用户" width="760px" @update:model-value="close" class="import-dlg" :close-on-click-modal="false">
    <!-- 第一步:选择方式 -->
    <template v-if="!result">
      <el-segmented v-model="mode" :options="MODES" block class="mode-seg" @change="preview = null" />

      <!-- 菜单可见:应用于本批全部用户(序列 / 粘贴两种方式共用) -->
      <div class="menus-row">
        <span class="muted lbl">菜单可见(整批统一):</span>
        <span class="msw"><el-switch v-model="menus.dashboard" inline-prompt active-text="开" inactive-text="关" />总览</span>
        <span class="msw"><el-switch v-model="menus.repos" inline-prompt active-text="开" inactive-text="关" />Git 仓库</span>
        <span class="msw"><el-switch v-model="menus.ai" inline-prompt active-text="开" inactive-text="关" />AI 助手</span>
        <span class="msw"><el-switch v-model="menus.backups" inline-prompt active-text="开" inactive-text="关" />备份与恢复</span>
        <span class="msw"><el-switch v-model="menus.settings" inline-prompt active-text="开" inactive-text="关" />实例设置</span>
        <span class="msw"><el-switch v-model="menus.upgrade" inline-prompt active-text="开" inactive-text="关" />实例升级</span>
        <span class="msw"><el-switch v-model="menus.databases" inline-prompt active-text="开" inactive-text="关" />实例数据库</span>
      </div>

      <!-- 方式一:按序列生成 -->
      <div v-if="mode === 'seq'" class="seq">
        <div class="seq-grid">
          <div class="fld"><label>用户名前缀</label><el-input v-model="seq.prefix" placeholder="dev" /></div>
          <div class="fld sm"><label>起始编号</label><el-input-number v-model="seq.start" :min="0" :max="99999" controls-position="right" /></div>
          <div class="fld sm"><label>数量</label><el-input-number v-model="seq.count" :min="1" :max="200" controls-position="right" /></div>
          <div class="fld sm"><label>编号位数<HelpTip text="补零对齐,如 2 → 01、02;1 → 1、2" /></label><el-input-number v-model="seq.pad" :min="1" :max="6" controls-position="right" /></div>
        </div>
        <div class="seq-grid">
          <div class="fld"><label>显示名前缀<HelpTip text="留空则不设显示名;填「开发」→ 开发1、开发2" /></label><el-input v-model="seq.displayPrefix" placeholder="可选" /></div>
          <div class="fld sm"><label>角色</label>
            <el-select v-model="seq.role"><el-option label="普通用户" value="member" /><el-option label="超级管理员" value="admin" /></el-select>
          </div>
          <div class="fld sm"><label>Shell</label><div class="sw"><el-switch v-model="seq.shell" /></div></div>
        </div>
        <div class="seq-grid">
          <div class="fld sm"><label>实例配额<HelpTip text="作为拥有者最多几个实例;留空 = 不限;0 = 不能创建" /></label><el-input-number v-model="seq.maxEnvs" :min="0" :max="10000" controls-position="right" placeholder="不限" /></div>
          <div class="fld sm"><label>附加库配额<HelpTip text="最多可创建几个附加数据库(跨实例累计);留空 = 不限;0 = 不能创建" /></label><el-input-number v-model="seq.maxDbs" :min="0" :max="10000" controls-position="right" placeholder="不限" /></div>
          <div class="fld" style="flex: 2" />
        </div>
        <div v-if="seq.role === 'member'" class="seq-grid">
          <div class="fld wide"><label>组织</label>
            <el-select v-model="seq.tenantIds" multiple placeholder="选择组织(可多选)" class="w100">
              <el-option v-for="t in tenants" :key="t.id" :label="t.name" :value="t.id" />
            </el-select>
          </div>
          <div class="fld sm"><label>组织角色</label>
            <el-select v-model="seq.memRole"><el-option v-for="(l, r) in ROLE_LABEL" :key="r" :value="r" :label="l" /></el-select>
          </div>
        </div>
        <div class="seq-preview" v-if="seqNames.length">
          将创建 <b>{{ seqNames.length }}</b> 个:<span class="mono">{{ seqNames.slice(0, 6).join('、') }}{{ seqNames.length > 6 ? ` …… ${seqNames[seqNames.length - 1]}` : '' }}</span>
          <span class="muted"> · 密码全部自动生成</span>
        </div>
        <div class="bar">
          <span class="grow" />
          <el-button type="primary" :loading="parsing" :disabled="!seqNames.length" @click="genAndParse">生成并预览</el-button>
        </div>
      </div>

      <!-- 方式二:粘贴 / 上传 -->
      <div v-else>
        <div class="hint">
          每行一个用户,英文逗号分隔:<code>用户名,显示名,密码,角色,Shell,实例配额,附加库配额,组织</code>。
          密码留空自动生成;配额留空 = 不限;组织写法 <code>slug:角色</code>,多个用 <code>;</code> 分隔(角色:owner/developer/tester,缺省 developer)。第一行可作表头。
        </div>
        <el-input v-model="text" type="textarea" :rows="8" spellcheck="false"
          placeholder="zhangsan,张三,,member,0,3,2,acme:developer;beta:tester&#10;lisi,李四,,member,1,,,acme:owner" />
        <div class="bar">
          <el-button text :icon="Upload" @click="pick">上传 CSV / 文本</el-button>
          <input ref="file" type="file" accept=".csv,.txt,text/*" hidden @change="onFile" />
          <el-button text @click="text = SAMPLE">填入示例</el-button>
          <span class="grow" />
          <el-button type="primary" :loading="parsing" :disabled="!text.trim()" @click="parse">解析预览</el-button>
        </div>
      </div>

      <template v-if="preview">
        <div class="sum">
          共 {{ preview.rows.length }} 行 ·
          <span class="ok">可创建 {{ preview.ok_count }}</span>
          <span v-if="preview.error_count" class="err"> · 有误 {{ preview.error_count }}(请在上方修正后重新解析)</span>
        </div>
        <el-table :data="preview.rows" size="small" max-height="300" class="prev-table">
          <el-table-column label="" width="40"><template #default="{ row }"><el-icon v-if="row.errors.length" color="var(--danger)"><CircleCloseFilled /></el-icon><el-icon v-else color="var(--success)"><CircleCheckFilled /></el-icon></template></el-table-column>
          <el-table-column label="用户名" prop="row.username" width="130" />
          <el-table-column label="显示名" width="100"><template #default="{ row }">{{ row.row.display_name || '—' }}</template></el-table-column>
          <el-table-column label="角色" width="80"><template #default="{ row }">{{ row.row.role === 'admin' ? '超管' : '普通' }}</template></el-table-column>
          <el-table-column label="密码" width="80"><template #default="{ row }">{{ row.will_generate_password ? '自动生成' : '自定义' }}</template></el-table-column>
          <el-table-column label="配额(实例/库)" width="110"><template #default="{ row }">{{ qLabel(row.row.max_envs) }} / {{ qLabel(row.row.max_dbs) }}</template></el-table-column>
          <el-table-column label="组织 / 提示" min-width="180">
            <template #default="{ row }">
              <span v-if="row.errors.length" class="err">{{ row.errors.join(';') }}</span>
              <span v-else-if="row.membership_labels.length">{{ row.membership_labels.join('、') }}</span>
              <span v-else class="muted">—</span>
            </template>
          </el-table-column>
        </el-table>
      </template>
    </template>

    <!-- 第二步:结果 + 下载密码 -->
    <template v-else>
      <el-result icon="success" :title="`已创建 ${result.created.length} 个用户`" sub-title="初始密码只显示这一次,请立即下载保存;之后只能重置。">
        <template #extra><el-button type="primary" :icon="Download" @click="downloadCsv">下载密码 CSV</el-button></template>
      </el-result>
      <el-table :data="result.created" size="small" max-height="280">
        <el-table-column label="用户名" prop="username" width="140" />
        <el-table-column label="显示名" width="120"><template #default="{ row }">{{ row.display_name || '—' }}</template></el-table-column>
        <el-table-column label="初始密码"><template #default="{ row }"><code class="pw">{{ row.password }}</code></template></el-table-column>
        <el-table-column label="组织" min-width="160"><template #default="{ row }">{{ row.membership_labels.join('、') || '—' }}</template></el-table-column>
      </el-table>
    </template>

    <template #footer>
      <el-button @click="close">{{ result ? '完成' : '取消' }}</el-button>
      <el-button v-if="!result" type="primary" :loading="creating" :disabled="!canCreate" @click="create">
        创建 {{ preview?.ok_count || 0 }} 个用户
      </el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { Upload, Download, CircleCheckFilled, CircleCloseFilled } from '@element-plus/icons-vue'
import api from '../api'
import HelpTip from './HelpTip.vue'
import { downloadText } from '../utils/download'
import { ROLE_LABEL, tenants } from '../store'

const props = defineProps({ modelValue: Boolean })
const emit = defineEmits(['update:modelValue', 'done'])

const MODES = [{ label: '按序列生成', value: 'seq' }, { label: '粘贴 / CSV 导入', value: 'paste' }]
const SAMPLE = 'zhangsan,张三,,member,0,3,2,acme:developer;beta:tester\nlisi,李四,,member,1,,,acme:owner'
const mode = ref('seq')
const text = ref('')
const preview = ref(null)
const result = ref(null)
const parsing = ref(false)
const creating = ref(false)
const file = ref(null)
const seq = reactive({ prefix: 'dev', start: 1, count: 5, pad: 2, displayPrefix: '', role: 'member', maxEnvs: null, maxDbs: null, shell: false, tenantIds: [], memRole: 'developer' })
const menus = reactive({ dashboard: true, repos: true, ai: true, backups: true, settings: false, upgrade: false, databases: false })  // 菜单可见:整批统一(后三个是实例 Tab,默认关)

const canCreate = computed(() => preview.value && preview.value.ok_count > 0 && preview.value.error_count === 0)

/** 序列展开的用户名列表(前缀 + 补零编号)。 */
const seqNames = computed(() => {
  const p = (seq.prefix || '').trim()
  if (!p || !seq.count) return []
  const out = []
  for (let i = 0; i < seq.count; i++) out.push(p + String(seq.start + i).padStart(seq.pad, '0'))
  return out
})

watch(() => props.modelValue, (v) => { if (v) { text.value = ''; preview.value = null; result.value = null; mode.value = 'seq'; Object.assign(menus, { dashboard: true, repos: true, ai: true, backups: true, settings: false, upgrade: false, databases: false }) } })

function pick() { file.value?.click() }
function onFile(e) {
  const f = e.target.files?.[0]; if (!f) return
  const r = new FileReader(); r.onload = () => { text.value = String(r.result || ''); preview.value = null }; r.readAsText(f)
  e.target.value = ''
}
async function parse() {
  parsing.value = true
  try { preview.value = await api.post('/users/bulk-parse', { text: text.value }) } catch {} finally { parsing.value = false }
}
/** 序列模式:把表单展开成与粘贴模式同一套的 CSV 文本,复用 bulk-parse 的校验(重名 / 已存在等)。 */
function composeSeqText() {
  const mems = seq.role === 'member'
    ? seq.tenantIds.map((id) => tenants.value.find((t) => t.id === id)?.slug).filter(Boolean).map((s) => `${s}:${seq.memRole}`).join(';')
    : ''
  const envs = seq.maxEnvs === '' || seq.maxEnvs == null ? '' : String(seq.maxEnvs)
  const dbs = seq.maxDbs === '' || seq.maxDbs == null ? '' : String(seq.maxDbs)
  const shell = seq.shell ? '1' : '0'
  return seqNames.value.map((name, i) => {
    const display = seq.displayPrefix ? `${seq.displayPrefix}${seq.start + i}` : ''
    return [name, display, '', seq.role, shell, envs, dbs, mems].join(',')
  }).join('\n')
}
async function genAndParse() {
  text.value = composeSeqText()
  await parse()
}
async function create() {
  creating.value = true
  try {
    const rows = preview.value.rows.filter((r) => !r.errors.length)
      .map((r) => ({ ...r.row, menu_dashboard: menus.dashboard, menu_repos: menus.repos, menu_ai: menus.ai, menu_backups: menus.backups, menu_settings: menus.settings, menu_upgrade: menus.upgrade, menu_databases: menus.databases }))
    result.value = await api.post('/users/bulk-create', { rows })
    ElMessage.success(`已创建 ${result.value.created.length} 个用户`)
    emit('done')
  } catch {} finally { creating.value = false }
}
function qLabel(v) { return v == null ? '∞' : v === 0 ? '禁' : v }
function csvCell(v) { const s = String(v ?? ''); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s }
function downloadCsv() {
  const head = 'username,display_name,password,role,memberships'
  const lines = result.value.created.map((c) => [c.username, c.display_name || '', c.password, c.role, c.membership_labels.join('; ')].map(csvCell).join(','))
  downloadText('﻿' + [head, ...lines].join('\r\n'), `odoosh-users-${new Date().toISOString().slice(0, 10)}.csv`, 'text/csv;charset=utf-8')
}
function close() { emit('update:modelValue', false) }
</script>

<style scoped>
.mode-seg { margin-bottom: 14px; }
.menus-row { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; margin-bottom: 14px; padding: 8px 12px; border: 1px solid var(--line-2); border-radius: 8px; }
.menus-row .lbl { font-size: 12.5px; }
.msw { display: inline-flex; align-items: center; gap: 6px; font-size: 13px; }
.seq-grid { display: flex; gap: 12px; margin-bottom: 12px; }
.seq .fld { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 5px; }
.seq .fld.sm { flex: 0 0 130px; }
.seq .fld.wide { flex: 2; }
.seq .fld > label { font-size: 12.5px; color: var(--text-2); }
.seq .fld :deep(.el-input-number) { width: 100%; }
.seq .w100 { width: 100%; }
.seq .sw { height: 32px; display: flex; align-items: center; }
.seq-preview { font-size: 13px; background: var(--surface-2); border: 1px solid var(--line-2); border-radius: 8px; padding: 8px 12px; margin-bottom: 8px; }
.seq-preview .mono { font-family: var(--mono, monospace); }
.hint { font-size: 12.5px; color: var(--text-3); line-height: 1.7; margin-bottom: 8px; }
.hint code { background: var(--surface-2); border: 1px solid var(--line-2); border-radius: 4px; padding: 0 5px; font-size: 12px; }
.bar { display: flex; align-items: center; gap: 6px; margin-top: 10px; }
.grow { flex: 1; }
.sum { margin: 12px 0 6px; font-size: 13px; }
.sum .ok { color: var(--success); font-weight: 600; }
.sum .err { color: var(--danger); }
.err { color: var(--danger); }
.prev-table { margin-top: 4px; }
.pw { font-family: var(--mono, monospace); background: var(--surface-2); padding: 1px 6px; border-radius: 4px; }
</style>
