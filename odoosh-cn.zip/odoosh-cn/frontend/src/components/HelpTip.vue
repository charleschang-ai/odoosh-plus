<template>
  <!-- 表单标签旁的「?」帮助提示:把长段说明文字收进 tooltip,减少弹窗里的提示行。用法:<HelpTip text="…" /> 或默认插槽 -->
  <el-tooltip placement="top" :show-after="150" popper-class="help-tip-pop">
    <template #content><slot>{{ text }}</slot></template>
    <el-icon class="help-tip"><QuestionFilled /></el-icon>
  </el-tooltip>
</template>

<script setup>
import { QuestionFilled } from '@element-plus/icons-vue'
defineProps({ text: { type: String, default: '' } })
</script>

<style>
.help-tip-pop { max-width: 320px; line-height: 1.6; font-size: 12.5px; }
</style>
