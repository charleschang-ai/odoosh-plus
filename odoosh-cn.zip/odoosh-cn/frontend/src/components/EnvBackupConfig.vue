<template>
  <!-- 实例备份设置:推送到哪些远程目标(只能选自己的)+ 自动备份(沿用组织策略 / 本实例自定义 / 关闭) -->
  <div v-loading="loading" class="ebc">
    <template v-if="cfg">
      <el-form label-width="110px" label-position="left" :disabled="!editable" @submit.prevent>
        <el-form-item label="远程备份目标">
          <div style="width: 100%">
            <el-checkbox-group v-model="form.target_ids" v-if="cfg.targets.length">
              <el-checkbox v-for="t in cfg.targets" :key="t.id" :value="t.id" :disabled="!t.mine" style="display: flex; margin-right: 0; height: auto; padding: 3px 0">
                <span class="tk" :class="`k-${t.kind}`">{{ kindShort(t.kind) }}</span> <b>{{ t.name }}</b>
                <span class="muted small"> · {{ t.describe }}</span>
                <el-tag v-if="!t.enabled" size="small" type="info" effect="plain" style="margin-left: 6px">已停用</el-tag>
                <el-tag v-else-if="t.last_test_ok === false" size="small" type="danger" effect="plain" style="margin-left: 6px">连接失败</el-tag>
                <span v-if="!t.mine" class="muted tiny"> (他人添加,只读)</span>
              </el-checkbox>
            </el-checkbox-group>
            <div v-else class="muted small">你还没有远程备份目标,<router-link to="/backups">去「备份与恢复」添加</router-link>;未选择时备份只保存在本地服务器。</div>
            <div class="muted tiny" style="margin-top: 4px">本实例的每一个库(主库 + 附加库)的每份备份(手动 / 自动)完成后都会推送到勾选的目标;未勾选 = 只留本地。</div>
          </div>
        </el-form-item>

        <el-form-item label="自动备份">
          <el-radio-group v-model="form.auto_mode">
            <el-radio-button value="inherit">沿用组织策略</el-radio-button>
            <el-radio-button value="custom">本实例自定义</el-radio-button>
            <el-radio-button value="off">关闭</el-radio-button>
          </el-radio-group>
          <div v-if="form.auto_mode === 'inherit'" class="muted small" style="width: 100%; margin-top: 4px">
            组织策略:<el-tag size="small" :type="cfg.tenant_effective.auto_enabled ? 'success' : 'info'">{{ cfg.tenant_effective.auto_enabled ? '已开启' : '未开启' }}</el-tag>
            <template v-if="cfg.tenant_effective.auto_enabled"> · 每天 {{ hh(cfg.tenant_effective.auto_hour) }} · 类型 {{ cfg.tenant_effective.auto_kinds.map(kindLabel).join('、') }} · 保留 {{ cfg.tenant_effective.keep_days }} 天 · {{ cfg.tenant_effective.include_extra_dbs ? '含附加库' : '仅主库' }}</template>
            <span v-if="cfg.tenant_effective.auto_enabled && !cfg.tenant_effective.auto_kinds.includes(env.kind)" style="color: var(--warning, #d97706)"> · 本实例类型({{ kindLabel(env.kind) }})不在组织策略范围内,不会自动备份;可改为「本实例自定义」</span>
          </div>
        </el-form-item>
        <template v-if="form.auto_mode === 'custom'">
          <el-form-item label="备份时刻">
            <el-select v-model="form.auto_hour" style="width: 120px"><el-option v-for="h in 24" :key="h - 1" :value="h - 1" :label="hh(h - 1)" /></el-select>
            <span class="hint">每天一次,服务器本地时间</span>
          </el-form-item>
          <el-form-item label="包含 filestore"><el-switch v-model="form.include_filestore" /><span class="hint">附件文件;关闭则只备份数据库</span></el-form-item>
          <el-form-item label="包含附加库"><el-switch v-model="form.include_extra_dbs" /><span class="hint">实例的附加数据库也逐个备份</span></el-form-item>
          <el-form-item label="本地保留">
            <el-input-number v-model="form.keep_days" :min="0" :max="3650" controls-position="right" style="width: 120px" />
            <span class="hint">天;只清理本实例的自动 / 恢复前备份;0 = 不清理。远端保留在各目标上单独设置</span>
          </el-form-item>
        </template>
      </el-form>
      <div class="foot">
        <el-button v-if="editable" type="primary" size="small" :loading="saving" @click="save">保存</el-button>
        <el-button size="small" :loading="running" @click="runNow" :disabled="!cfg.effective.auto_enabled && form.auto_mode !== 'custom'">按此设置立即备份一轮</el-button>
        <span class="muted small" style="margin-left: 8px">
          当前生效:<el-tag size="small" :type="cfg.effective.auto_enabled ? 'success' : 'info'">{{ cfg.effective.auto_enabled ? '已开启' : '未开启' }}</el-tag>
          <template v-if="cfg.effective.auto_enabled"> · 每天 {{ hh(cfg.effective.auto_hour) }} · {{ cfg.effective.source === 'env' ? '实例自定义' : '组织策略' }}<span v-if="cfg.next_run"> · 下次 {{ cfg.next_run }}</span></template>
          <span v-if="cfg.updated_by"> · 最后修改 {{ cfg.updated_by }}</span>
        </span>
      </div>
    </template>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../api'
import { kindLabel } from '../utils/labels'

const props = defineProps({ env: { type: Object, required: true }, editable: { type: Boolean, default: true } })
const emit = defineEmits(['saved'])
const cfg = ref(null); const loading = ref(false); const saving = ref(false); const running = ref(false)
const form = reactive({ target_ids: [], auto_mode: 'inherit', auto_hour: 3, include_filestore: true, include_extra_dbs: false, keep_days: 7 })
const hh = (h) => `${String(h).padStart(2, '0')}:00`
const kindShort = (k) => ({ s3: 'S3', sftp: 'SFTP', webdav: 'DAV' }[k] || k)

async function load() {
  loading.value = true
  try {
    cfg.value = await api.get(`/environments/${props.env.id}/backup-config`, { silent: true })
    Object.assign(form, { target_ids: [...cfg.value.target_ids], auto_mode: cfg.value.auto_mode, auto_hour: cfg.value.auto_hour, include_filestore: cfg.value.include_filestore, include_extra_dbs: cfg.value.include_extra_dbs, keep_days: cfg.value.keep_days })
  } catch {} finally { loading.value = false }
}
async function save() {
  saving.value = true
  try { cfg.value = await api.put(`/environments/${props.env.id}/backup-config`, { ...form }); ElMessage.success('已保存'); emit('saved', cfg.value) } catch {} finally { saving.value = false }
}
async function runNow() {
  running.value = true
  try { const r = await api.post(`/environments/${props.env.id}/backup-config/run-now`); ElMessage.success(r.started ? `已发起 ${r.started} 个备份` : '没有需要备份的库(检查自动备份是否开启 / 实例是否就绪)') } catch {} finally { running.value = false }
}
watch(() => props.env.id, load)
onMounted(load)
defineExpose({ load })
</script>

<style scoped>
.ebc { font-size: 13px; }
.small { font-size: 12px; }
.tiny { font-size: 11.5px; }
.hint { margin-left: 8px; font-size: 12px; color: var(--text-3); }
.foot { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; margin-top: 4px; }
.tk { display: inline-block; min-width: 34px; text-align: center; border-radius: 4px; font-size: 10.5px; font-weight: 700; color: #fff; padding: 0 4px; line-height: 16px; margin-right: 2px; }
.k-s3 { background: #f59e0b; } .k-sftp { background: #3b82f6; } .k-webdav { background: #10b981; }
</style>
