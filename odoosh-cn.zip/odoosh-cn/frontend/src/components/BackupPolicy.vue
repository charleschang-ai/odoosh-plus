<template>
  <div v-loading="loading">
    <template v-if="policy">
      <el-form :model="form" label-width="110px" label-position="left" :disabled="!editable">
        <el-form-item label="策略来源">
          <el-radio-group v-model="form.mode">
            <el-radio-button value="inherit">沿用平台默认</el-radio-button>
            <el-radio-button value="custom">本组织自定义</el-radio-button>
          </el-radio-group>
        </el-form-item>

        <template v-if="form.mode === 'custom'">
          <el-form-item label="每日自动备份"><el-switch v-model="form.auto_enabled" /></el-form-item>
          <el-form-item label="备份时刻">
            <el-select v-model="form.auto_hour" style="width: 140px" :disabled="!form.auto_enabled">
              <el-option v-for="h in 24" :key="h - 1" :value="h - 1" :label="`${String(h - 1).padStart(2, '0')}:00`" />
            </el-select>
            <span class="muted hint">服务器本地时间</span>
          </el-form-item>
          <el-form-item label="实例类型">
            <el-checkbox-group v-model="form.auto_kinds" :disabled="!form.auto_enabled">
              <el-checkbox value="production">生产</el-checkbox>
              <el-checkbox value="staging">测试</el-checkbox>
              <el-checkbox value="dev">开发</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
          <el-form-item label="包含 filestore"><el-switch v-model="form.include_filestore" :disabled="!form.auto_enabled" /><span class="muted hint">附件文件;关闭则只备份数据库</span></el-form-item>
          <el-form-item label="包含附加库"><el-switch v-model="form.include_extra_dbs" :disabled="!form.auto_enabled" /><span class="muted hint">实例的附加数据库也逐个备份(同一实例串行)</span></el-form-item>
          <el-form-item label="保留天数">
            <el-input-number v-model="form.keep_days" :min="0" :max="3650" style="width: 140px" />
            <span class="muted hint">仅清理自动备份与恢复前备份;手动/上传的不受影响,0 = 不清理</span>
          </el-form-item>
        </template>
        <template v-else>
          <el-descriptions :column="2" size="small" border>
            <el-descriptions-item label="每日自动备份">{{ policy.platform_defaults.auto_enabled ? '开启' : '关闭' }}</el-descriptions-item>
            <el-descriptions-item label="备份时刻">{{ String(policy.platform_defaults.auto_hour).padStart(2, '0') }}:00</el-descriptions-item>
            <el-descriptions-item label="实例类型">{{ policy.platform_defaults.auto_kinds.map(kindLabel).join('、') }}</el-descriptions-item>
            <el-descriptions-item label="保留天数">{{ policy.platform_defaults.keep_days }} 天</el-descriptions-item>
          </el-descriptions>
        </template>

        <el-form-item v-if="editable" style="margin-top: 8px">
          <el-button type="primary" :loading="saving" @click="save">保存</el-button>
          <el-button :loading="running" @click="runNow">立即备份一轮</el-button>
        </el-form-item>
      </el-form>

      <el-divider style="margin: 12px 0" />
      <div class="muted" style="font-size: 12px; line-height: 1.9">
        <div>当前生效:<el-tag size="small" :type="policy.effective.auto_enabled ? 'success' : 'info'">{{ policy.effective.auto_enabled ? '已开启' : '未开启' }}</el-tag>
          <span v-if="policy.effective.auto_enabled"> · 每天 {{ String(policy.effective.auto_hour).padStart(2, '0') }}:00 · {{ policy.effective.auto_kinds.map(kindLabel).join('、') }} · 保留 {{ policy.effective.keep_days }} 天</span>
        </div>
        <div v-if="policy.next_run">下次执行:{{ policy.next_run }}</div>
        <div v-if="policy.last_run_at">上次执行:{{ fmtLocal(policy.last_run_at) }}</div>
        <div>存储目录:<code>{{ policy.storage_dir }}</code>(平台按组织分目录,由平台管理员统一维护)</div>
        <div v-if="policy.updated_by">最后修改:{{ policy.updated_by }} · {{ fmtLocal(policy.updated_at) }}</div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../api'
import { kindLabel } from '../utils/labels'
import { fmtLocal } from '../utils/format'

const props = defineProps({ tenantId: { type: Number, required: true }, editable: { type: Boolean, default: true } })
const emit = defineEmits(['ran'])

const policy = ref(null)
const loading = ref(false)
const saving = ref(false)
const running = ref(false)
const form = reactive({ mode: 'inherit', auto_enabled: false, auto_hour: 3, auto_kinds: ['production'], keep_days: 7, include_filestore: true, include_extra_dbs: false })

async function load() {
  if (!props.tenantId) return
  loading.value = true
  try {
    policy.value = await api.get(`/backups/policy/${props.tenantId}`)
    const p = policy.value
    Object.assign(form, { mode: p.mode, auto_enabled: p.auto_enabled, auto_hour: p.auto_hour, auto_kinds: [...p.auto_kinds], keep_days: p.keep_days, include_filestore: p.include_filestore, include_extra_dbs: !!p.include_extra_dbs })
  } catch {} finally { loading.value = false }
}
async function save() {
  saving.value = true
  try { policy.value = await api.put(`/backups/policy/${props.tenantId}`, { ...form }); ElMessage.success('已保存') } catch {} finally { saving.value = false }
}
async function runNow() {
  running.value = true
  try {
    const r = await api.post(`/backups/policy/${props.tenantId}/run-now`)
    ElMessage.success(r.started ? `已发起 ${r.started} 个实例的备份,可在「备份与恢复」查看进度` : '没有符合策略的可备份实例')
    emit('ran', r.started)
    await load()
  } catch {} finally { running.value = false }
}
onMounted(load)
watch(() => props.tenantId, load)
</script>

<style scoped>
.hint { margin-left: 8px; font-size: 12px; }
</style>
