<template>
  <!-- 仓库分支抽屉:<BranchesDrawer v-model="show" :repo="cur" :can-write="canWrite(cur)" @changed="load" /> -->
  <el-drawer v-model="visible" :title="`分支 — ${repo?.name || ''}`" size="60%" @open="load">
    <div class="drawer-bar">
      <span class="muted">{{ br.synced_at ? '同步于 ' + fmtDate(br.synced_at) : '' }}</span>
      <div>
        <el-button v-if="canWrite" size="small" type="primary" :icon="Plus" @click="openNewBranch">新建分支</el-button>
        <el-button size="small" :loading="syncing" :icon="Refresh" @click="sync">从远端同步</el-button>
      </div>
    </div>
    <el-table :data="br.branches" v-loading="loading" size="small" stripe>
      <el-table-column label="分支" min-width="160">
        <template #default="{ row }">
          <b>{{ row.name }}</b> <el-tag v-if="row.is_default" size="small" effect="plain">默认</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="最新提交" min-width="260" show-overflow-tooltip>
        <template #default="{ row }">
          <code class="sha">{{ shortSha(row.sha, 7) }}</code>
          <span>{{ row.message || '' }}</span>
          <div class="muted" v-if="row.author || row.date">{{ row.author }} {{ row.date ? '· ' + fmtDate(row.date) : '' }}</div>
        </template>
      </el-table-column>
      <el-table-column label="绑定环境" min-width="200">
        <template #default="{ row }">
          <template v-if="row.environments?.length">
            <el-tag v-for="e in row.environments" :key="e.id" size="small" :type="statusType(e.status)" style="margin-right: 4px">
              {{ e.name }} · {{ statusLabel(e.status) }}
            </el-tag>
          </template>
          <router-link v-else class="muted" to="/environments">未绑定 → 去创建环境</router-link>
        </template>
      </el-table-column>
      <el-table-column v-if="canWrite && repo?.provider === 'github'" label="" width="70">
        <template #default="{ row }">
          <el-button v-if="!row.is_default && !row.environments?.length" link type="danger" size="small" @click="deleteBranch(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 新建分支 -->
    <el-dialog v-model="nbDlg" title="新建分支" width="440px" append-to-body>
      <el-form :model="nb" label-width="80px">
        <el-form-item label="基于" required>
          <el-select v-model="nb.from_branch" filterable style="width: 100%">
            <el-option v-for="b in br.branches" :key="b.name" :label="b.name" :value="b.name" />
          </el-select>
        </el-form-item>
        <el-form-item label="新分支名" required><el-input v-model="nb.name" placeholder="feature-xxx / staging" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="nbDlg = false">取消</el-button>
        <el-button type="primary" :loading="nbSaving" :disabled="!nb.name || !nb.from_branch" @click="createBranch">创建</el-button>
      </template>
    </el-dialog>
  </el-drawer>
</template>

<script setup>
import { computed, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus, Refresh } from '@element-plus/icons-vue'
import api from '../../api'
import { confirmDanger } from '../../utils/confirm'
import { statusLabel, statusType } from '../../utils/labels'
import { fmtDate, shortSha } from '../../utils/format'

const props = defineProps({ modelValue: Boolean, repo: { type: Object, default: null }, canWrite: { type: Boolean, default: false } })
const emit = defineEmits(['update:modelValue', 'changed'])
const visible = computed({ get: () => props.modelValue, set: (v) => emit('update:modelValue', v) })
const loading = ref(false); const syncing = ref(false); const br = reactive({ synced_at: null, default_branch: null, branches: [] })
const nbDlg = ref(false); const nbSaving = ref(false); const nb = reactive({ name: '', from_branch: '' })

async function load() {
  if (!props.repo) return
  loading.value = true; br.branches = []
  try { Object.assign(br, await api.get(`/repos/${props.repo.id}/branches`)) } catch { br.branches = [] } finally { loading.value = false }
}
async function sync() {
  syncing.value = true
  try { Object.assign(br, await api.post(`/repos/${props.repo.id}/sync`)); ElMessage.success('已同步'); emit('changed') } catch {} finally { syncing.value = false }
}
function openNewBranch() { nb.name = ''; nb.from_branch = br.default_branch || br.branches[0]?.name || ''; nbDlg.value = true }
async function createBranch() {
  nbSaving.value = true
  try { Object.assign(br, await api.post(`/repos/${props.repo.id}/branches`, nb)); ElMessage.success(`分支 ${nb.name} 已创建`); nbDlg.value = false } catch {} finally { nbSaving.value = false }
}
async function deleteBranch(row) {
  if (!(await confirmDanger({ title: '删除远端分支', message: `删除远端分支「${row.name}」?此操作在 Git 平台上执行,不可恢复。` }))) return
  try { Object.assign(br, await api.delete(`/repos/${props.repo.id}/branches/${encodeURIComponent(row.name)}`)); ElMessage.success('已删除') } catch {}
}
</script>

<style scoped>
.drawer-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 8px; }
.sha { background: var(--surface-2); padding: 1px 5px; border-radius: 3px; font-size: 12px; margin-right: 6px; }
</style>
