<template>
  <!-- 接入 / 编辑仓库。用法:<RepoFormDialog ref="dlg" :accounts="accounts" :platform-ent="platformEnt" @saved="load" />;dlg.openCreate(tenantId?) / dlg.openEdit(row) -->
  <el-dialog v-model="visible" :title="form.id ? '编辑仓库' : '接入仓库'" width="640px">
    <el-form :model="form" label-width="100px">
      <el-form-item label="归属" required>
        <el-radio-group v-if="isSuper && !form.id" v-model="form.scope" style="margin-right: 12px">
          <el-radio-button value="tenant">某组织</el-radio-button>
          <el-radio-button value="platform">平台共享</el-radio-button>
        </el-radio-group>
        <el-select v-if="form.scope !== 'platform'" v-model="form.tenant_id" :disabled="!!form.id" style="width: 260px">
          <el-option v-for="t in (form.id ? tenants : manageableTenants)" :key="t.id" :label="t.name" :value="t.id" />
        </el-select>
        <span v-else class="hint">平台共享仓库对所有组织可用(如平台统一的企业版代码)</span>
      </el-form-item>
      <el-form-item label="企业版仓库">
        <el-switch v-model="form.is_enterprise" />
        <span class="hint" style="margin-left: 8px">标记为 Odoo 企业版代码仓库:分支须按版本命名(17.0/18.0/19.0),不参与业务代码部署;创建企业版实例时按需拉取并只读挂载</span>
        <el-alert v-if="form.is_enterprise && form.scope !== 'platform' && platStatus.exists" type="info" :closable="false" show-icon style="margin-top: 6px"
          :title="`超级管理员已提供平台共享企业版仓库(${providerLabel(platStatus.provider)}),不接入也能创建企业版实例;接入自己的仓库后,您创建的企业版实例将优先使用您的仓库(须能连通且含对应版本分支)`" />
        <el-alert v-if="form.is_enterprise" type="warning" :closable="false" show-icon style="margin-top: 6px" title="请填写您有合法访问权的企业版仓库;平台仅按您的授权拉取,不分发企业版代码。私有仓库请填写访问令牌或使用已连接账号。" />
      </el-form-item>

      <template v-if="!form.id">
        <el-form-item label="来源">
          <el-radio-group v-model="mode">
            <el-radio-button value="account" :disabled="!accounts.length">从已连接账号选择</el-radio-button>
            <el-radio-button value="manual">手动填写地址</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <template v-if="mode === 'account'">
          <el-form-item label="账号" required>
            <el-select v-model="form.account_id" style="width: 100%" @change="loadRemote">
              <el-option v-for="a in accounts" :key="a.id" :label="`${providerLabel(a.provider)} · ${a.login}`" :value="a.id" />
            </el-select>
          </el-form-item>
          <el-form-item label="仓库" required>
            <div style="display: flex; gap: 8px; width: 100%">
              <el-select v-model="remoteSel" filterable :loading="remoteLoading" placeholder="搜索/选择仓库" style="flex: 1" @change="pickRemote">
                <el-option v-for="r in remote" :key="r.full_name" :label="r.full_name" :value="r.full_name">
                  <span>{{ r.full_name }}</span>
                  <el-tag v-if="r.private" size="small" type="info" style="margin-left: 6px">私有</el-tag>
                  <span class="muted" style="float: right; font-size: 12px">{{ r.default_branch }}</span>
                </el-option>
              </el-select>
              <el-button @click="newRepoDlg = true">新建仓库</el-button>
            </div>
          </el-form-item>
        </template>
      </template>

      <el-form-item label="仓库地址" required>
        <el-input v-model="form.url" :readonly="mode === 'account' && !form.id" placeholder="https://gitee.com/owner/repo.git 或 git@github.com:owner/repo.git" @blur="guessName" />
      </el-form-item>
      <el-form-item label="名称" required><el-input v-model="form.name" placeholder="显示名称,默认取仓库名" /></el-form-item>
      <el-form-item v-if="mode === 'manual' || form.id" label="访问令牌">
        <el-input v-model="form.token" type="password" show-password :placeholder="form.id && form.has_token ? '(已配置,留空则不修改;输入 - 清除)' : '私有仓库需要;GitHub PAT / Gitee 私人令牌 / GitLab Access Token'" />
        <div class="hint">手动模式下可选;若已连接账号,建议改用「从已连接账号选择」,可自动创建 Webhook。</div>
      </el-form-item>
      <el-form-item v-if="mode === 'account' && !form.id" label="Webhook">
        <el-checkbox v-model="form.auto_webhook">自动在 {{ providerLabel(accountOf(form.account_id)?.provider) }} 上创建 Webhook</el-checkbox>
      </el-form-item>
      <el-form-item v-if="!form.is_enterprise" label="自动部署">
        <el-switch v-model="form.auto_deploy" />
        <span class="hint" style="margin-left: 8px">收到分支推送后自动重新部署绑定该分支的环境</span>
      </el-form-item>
      <el-form-item v-if="form.id" label="Webhook 密钥">
        <el-checkbox v-model="form.regenerate_secret">重新生成(需同步到 Git 平台)</el-checkbox>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button :loading="testing" @click="testForm">测试连接</el-button>
      <el-button type="primary" :loading="saving" :disabled="!form.url || !form.name" @click="save">保存</el-button>
    </template>

    <!-- 新建远端仓库 -->
    <el-dialog v-model="newRepoDlg" title="新建远端仓库" width="460px" append-to-body>
      <el-form :model="newRepo" label-width="80px">
        <el-form-item label="仓库名" required><el-input v-model="newRepo.name" placeholder="my-odoo-addons" /></el-form-item>
        <el-form-item label="私有"><el-switch v-model="newRepo.private" /></el-form-item>
        <el-form-item label="描述"><el-input v-model="newRepo.description" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="newRepoDlg = false">取消</el-button>
        <el-button type="primary" :loading="creatingRepo" :disabled="!newRepo.name" @click="createRemoteRepo">创建</el-button>
      </template>
    </el-dialog>
  </el-dialog>
</template>

<script setup>
import { computed, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../../api'
import { isSuper, roleOf, tenants, loadTenants } from '../../store'
import { providerLabel } from '../../utils/labels'

const props = defineProps({ accounts: { type: Array, default: () => [] }, platformEnt: { type: Object, default: null } })
const emit = defineEmits(['saved'])
const visible = ref(false); const saving = ref(false); const testing = ref(false); const mode = ref('manual')
const blank = { id: null, tenant_id: null, scope: 'tenant', is_enterprise: false, name: '', url: '', token: '', auto_deploy: true, has_token: false, regenerate_secret: false, account_id: null, auto_webhook: true }
const form = reactive({ ...blank })
// 可「接入仓库」的组织:超管全部,否则仅组织管理员
// 可接入仓库的组织:开发者及以上(仓库属于接入者本人)
const manageableTenants = computed(() => tenants.value.filter((t) => isSuper.value || ['owner', 'developer'].includes(roleOf(t.id))))
// 平台是否已有共享企业版仓库(只告知存在与平台,不含地址)
const platStatus = reactive({ exists: false, provider: null })
async function loadPlatStatus() { try { Object.assign(platStatus, await api.get('/enterprise/platform-status')) } catch {} }
const accountOf = (id) => props.accounts.find((a) => a.id === id)
const remote = ref([]); const remoteLoading = ref(false); const remoteSel = ref(null)
const newRepoDlg = ref(false); const creatingRepo = ref(false); const newRepo = reactive({ name: '', private: true, description: '' })

function guessName() {
  if (form.name || !form.url) return
  const m = form.url.match(/([^\/:]+?)(?:\.git)?\/?$/)
  if (m) form.name = m[1]
}
async function openCreate(preferTenantId = null) {
  await Promise.all([loadTenants(), loadPlatStatus()])
  Object.assign(form, blank, { tenant_id: manageableTenants.value.find((t) => t.id === preferTenantId)?.id || manageableTenants.value[0]?.id || null })
  mode.value = props.accounts.length ? 'account' : 'manual'
  remote.value = []; remoteSel.value = null
  if (props.accounts.length) { form.account_id = props.accounts[0].id; loadRemote() }
  visible.value = true
}
async function openEdit(row) { await Promise.all([loadTenants(), loadPlatStatus()]); mode.value = 'manual'; Object.assign(form, blank, row, { token: '' }); visible.value = true }
async function loadRemote() {
  if (!form.account_id) return
  remoteLoading.value = true; remote.value = []; remoteSel.value = null; form.url = ''; form.name = ''
  try { remote.value = await api.get(`/git/accounts/${form.account_id}/repos`) } catch {} finally { remoteLoading.value = false }
}
function pickRemote(fullName) {
  const r = remote.value.find((x) => x.full_name === fullName)
  if (r) { form.url = r.clone_url; form.name = r.name || fullName.split('/').pop() }
}
async function createRemoteRepo() {
  creatingRepo.value = true
  try {
    const r = await api.post(`/git/accounts/${form.account_id}/repos`, newRepo)
    ElMessage.success(`已创建 ${r.full_name}`); newRepoDlg.value = false
    remote.value.unshift(r); remoteSel.value = r.full_name; pickRemote(r.full_name)
  } catch {} finally { creatingRepo.value = false }
}
function payload() {
  const p = { name: form.name, url: form.url, auto_deploy: form.auto_deploy, is_enterprise: !!form.is_enterprise, scope: form.scope || 'tenant' }
  if (form.token === '-') p.token = ''
  else if (form.token) p.token = form.token
  if (!form.id && mode.value === 'account') { p.account_id = form.account_id; p.auto_webhook = form.auto_webhook }
  return p
}
async function testForm() {
  testing.value = true
  try {
    const r = await api.post('/repos/test', { tenant_id: form.tenant_id, name: form.name || 'x', url: form.url, token: form.token && form.token !== '-' ? form.token : null, account_id: mode.value === 'account' ? form.account_id : null })
    r.ok ? ElMessage.success(`${r.message},默认分支 ${r.default_branch || '-'}`) : ElMessage.error(r.message)
  } catch {} finally { testing.value = false }
}
async function save() {
  saving.value = true
  try {
    if (form.id) await api.put(`/repos/${form.id}`, { ...payload(), regenerate_secret: form.regenerate_secret })
    else {
      const r = await api.post('/repos', { ...payload(), tenant_id: form.scope === 'platform' ? null : form.tenant_id })
      if (r.last_error) ElMessage.warning(r.last_error)
    }
    ElMessage.success('已保存'); visible.value = false; emit('saved')
  } catch {} finally { saving.value = false }
}
defineExpose({ openCreate, openEdit })
</script>

<style scoped>
.hint { font-size: 12px; color: var(--text-3); line-height: 1.5; }
</style>
