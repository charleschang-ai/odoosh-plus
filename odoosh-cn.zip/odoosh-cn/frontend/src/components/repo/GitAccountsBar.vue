<template>
  <!-- Git 账号连接条 + 定时轮询设置。用法:<GitAccountsBar v-model:accounts="accounts" @changed="load" /> -->
  <el-card shadow="never" class="acct-card">
    <div class="acct-row">
      <div class="acct-title">Git 账号</div>
      <div class="acct-list">
        <template v-for="p in ['github', 'gitee']" :key="p">
          <el-tag v-for="a in accountsOf(p)" :key="a.id" closable size="large" :type="providerType(p)" effect="plain" class="acct-tag" @close="unlink(a)">
            <img v-if="a.avatar_url" :src="a.avatar_url" class="avatar" alt="" />{{ providerLabel(p) }} · {{ a.login }}<span v-if="a.scopes === 'pat'" class="muted"> (令牌)</span>
          </el-tag>
          <el-dropdown trigger="click" @command="(cmd) => cmd === 'oauth' ? connect(p) : openTokenLink(p)">
            <el-button :icon="Link" size="small">{{ accountsOf(p).length ? '+ ' : '连接 ' }}{{ providerLabel(p) }}</el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="token">用个人令牌连接(无需回调地址)</el-dropdown-item>
                <el-dropdown-item command="oauth" :disabled="!appOf(p)?.configured">OAuth 授权连接{{ appOf(p)?.configured ? '' : '(管理员未配置)' }}</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </template>
      </div>
      <el-button v-if="isSuper" link type="primary" :icon="Setting" @click="openApps">OAuth 应用配置</el-button>
    </div>
    <div class="poll-row">
      <span class="poll-label" title="收不到 Webhook(平台无公网地址)时的兜底:平台定时主动比对各仓库分支,有新提交视为一次推送"><el-icon><Timer /></el-icon> 自动检查远端更新</span>
      <template v-if="isSuper">
        <span>每</span>
        <el-input-number v-model="poll.minutes" :min="0" :max="1440" size="small" controls-position="right" style="width: 100px" @change="savePoll" />
        <span>分钟</span>
        <span class="muted" v-if="poll.minutes === 0">(已关闭)</span>
        <el-button size="small" :loading="poll.running" @click="runPoll">立即检查全部</el-button>
      </template>
      <span v-else class="muted">{{ poll.minutes > 0 ? `每 ${poll.minutes} 分钟` : '已关闭' }}</span>
      <span class="muted" v-if="poll.last_run">上次 {{ fmtDate(poll.last_run) }}<template v-if="poll.last_result">,{{ poll.last_result.repos }} 个仓库,发现 {{ poll.last_result.events }} 处更新</template></span>
      <span class="muted" v-if="poll.running"><el-icon class="is-loading"><Loading /></el-icon> 检查中…</span>
    </div>

    <!-- 用令牌连接账号 -->
    <el-dialog v-model="tokDlg" :title="`用个人令牌连接 ${providerLabel(tokForm.provider)}`" width="560px">
      <el-alert type="info" :closable="false" style="margin-bottom: 12px">
        <template #title>如何获取令牌</template>
        <div v-if="tokForm.provider === 'github'">GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate,勾选 <b>repo</b> 与 <b>admin:repo_hook</b>。</div>
        <div v-else>Gitee → 设置 → 私人令牌 → 生成新令牌,勾选 <b>user_info</b>、<b>projects</b>、<b>hook</b>。</div>
      </el-alert>
      <el-form label-width="60px">
        <el-form-item label="令牌"><el-input v-model="tokForm.token" type="password" show-password placeholder="粘贴令牌" @keyup.enter="linkByToken" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="tokDlg = false">取消</el-button>
        <el-button type="primary" :loading="tokSaving" :disabled="!tokForm.token" @click="linkByToken">连接</el-button>
      </template>
    </el-dialog>

    <!-- OAuth 应用配置(管理员) -->
    <el-dialog v-model="appsDlg" title="OAuth 应用配置" width="680px">
      <el-tabs v-model="appsTab">
        <el-tab-pane v-for="a in apps" :key="a.provider" :label="providerLabel(a.provider)" :name="a.provider">
          <el-alert type="info" :closable="false" style="margin-bottom: 12px">
            <template #title>在 {{ providerLabel(a.provider) }} 创建 OAuth 应用</template>
            <div v-if="a.provider === 'github'">GitHub → Settings → Developer settings → OAuth Apps → New OAuth App。Authorization callback URL 填:</div>
            <div v-else>Gitee → 设置 → 第三方应用 → 创建应用,权限勾选 user_info / projects / hook。应用回调地址填:</div>
            <el-input :model-value="a.callback_url" readonly size="small" style="margin-top: 6px"><template #append><el-button @click="copy(a.callback_url)">复制</el-button></template></el-input>
          </el-alert>
          <el-form label-width="110px">
            <el-form-item label="Client ID"><el-input v-model="appForm[a.provider].client_id" /></el-form-item>
            <el-form-item label="Client Secret"><el-input v-model="appForm[a.provider].client_secret" type="password" show-password :placeholder="a.configured ? '(已配置,留空则不修改)' : ''" /></el-form-item>
            <el-form-item><el-button type="primary" :loading="savingApp" @click="saveApp(a.provider)">保存</el-button><el-tag v-if="a.configured" type="success" style="margin-left: 8px">已配置</el-tag></el-form-item>
          </el-form>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>
  </el-card>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Link, Setting, Timer, Loading } from '@element-plus/icons-vue'
import api from '../../api'
import { isSuper } from '../../store'
import { usePolling } from '../../composables/usePolling'
import { confirmDanger } from '../../utils/confirm'
import { providerLabel, providerType } from '../../utils/labels'
import { fmtDate } from '../../utils/format'
import { copyText } from '../../utils/clipboard'

const props = defineProps({ accounts: { type: Array, default: () => [] } })
const emit = defineEmits(['update:accounts', 'changed'])
const route = useRoute(); const router = useRouter()
const apps = ref([])
const accountsOf = (p) => props.accounts.filter((a) => a.provider === p)
const appOf = (p) => apps.value.find((a) => a.provider === p)

async function loadAccounts() {
  try {
    const [acc, ap] = await Promise.all([api.get('/git/accounts'), api.get('/git/oauth/apps', { silent: true }).catch(() => [])])
    emit('update:accounts', acc || []); apps.value = ap || []
  } catch {}
}
// ---- 账号
const tokDlg = ref(false); const tokSaving = ref(false); const tokForm = reactive({ provider: 'gitee', token: '' })
function openTokenLink(p) { tokForm.provider = p; tokForm.token = ''; tokDlg.value = true }
async function linkByToken() {
  if (!tokForm.token) return
  tokSaving.value = true
  try {
    const a = await api.post('/git/accounts/token', tokForm)
    ElMessage.success(`已连接 ${providerLabel(a.provider)} 账号 ${a.login}`); tokDlg.value = false; await loadAccounts(); emit('changed')
  } catch {} finally { tokSaving.value = false }
}
async function connect(p) {
  try { const { url } = await api.get(`/git/oauth/${p}/authorize`); window.location.href = url } catch {}
}
async function unlink(a) {
  if (!(await confirmDanger({ title: '断开连接', message: `断开 ${providerLabel(a.provider)} 账号 ${a.login}?通过它接入的仓库将失去凭据。`, confirmText: '断开' }))) return
  try { await api.delete(`/git/accounts/${a.id}`); ElMessage.success('已断开'); await loadAccounts(); emit('changed') } catch {}
}
// ---- OAuth 应用
const appsDlg = ref(false); const appsTab = ref('github'); const savingApp = ref(false)
const appForm = reactive({ github: { client_id: '', client_secret: '' }, gitee: { client_id: '', client_secret: '' } })
function openApps() {
  for (const a of apps.value) appForm[a.provider] = { client_id: a.client_id, client_secret: '' }
  appsDlg.value = true
}
async function saveApp(p) {
  savingApp.value = true
  try {
    const body = { client_id: appForm[p].client_id }
    if (appForm[p].client_secret) body.client_secret = appForm[p].client_secret
    apps.value = await api.put(`/git/oauth/apps/${p}`, body); ElMessage.success('已保存')
  } catch {} finally { savingApp.value = false }
}
const copy = (t) => copyText(t)
// ---- 定时轮询
const poll = reactive({ minutes: 5, running: false, last_run: null, last_result: null })
async function loadPoll() { try { Object.assign(poll, await api.get('/git/poll', { silent: true })) } catch {} }
const pollWatch = usePolling(async () => { await loadPoll(); if (!poll.running) { pollWatch.stop(); emit('changed') } }, { interval: 2000, immediate: false })
async function savePoll(v) {
  if (v === undefined || v === null) return
  try { Object.assign(poll, await api.put('/git/poll', { minutes: v })); ElMessage.success(v > 0 ? `已设置每 ${v} 分钟检查一次` : '已关闭自动检查') } catch {}
}
async function runPoll() {
  try {
    const r = await api.post('/git/poll/run')
    if (!r.started) { ElMessage.info(r.reason); return }
    poll.running = true
    ElMessage.success('已开始检查全部仓库')
    pollWatch.restart()
  } catch {}
}
onMounted(async () => {
  await Promise.all([loadAccounts(), loadPoll()])
  // OAuth 回调结果提示
  if (route.query.git_linked) ElMessage.success(`已连接 ${providerLabel(route.query.git_linked)} 账号 ${route.query.login || ''}`)
  if (route.query.git_error) ElMessage.error(`连接失败:${route.query.git_error}`)
  if (route.query.git_linked || route.query.git_error) router.replace('/repos')
})
defineExpose({ reload: loadAccounts })
</script>

<style scoped>
.acct-card { margin-bottom: 12px; }
.acct-row { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.acct-title { font-weight: 600; margin-right: 8px; }
.acct-list { display: flex; align-items: center; gap: 8px; flex: 1; flex-wrap: wrap; }
.acct-tag { display: inline-flex; align-items: center; }
.avatar { width: 18px; height: 18px; border-radius: 50%; margin-right: 6px; vertical-align: middle; }
.poll-row { display: flex; align-items: center; gap: 8px; margin-top: 10px; padding-top: 10px; border-top: 1px dashed var(--line); font-size: 13px; flex-wrap: wrap; }
.poll-label { display: inline-flex; align-items: center; gap: 4px; font-weight: 600; cursor: help; }
</style>
