<template>
  <!-- 平台离线企业版代码(内网:把 addons 按版本放目录即用)。仅超管可见。 -->
  <el-card shadow="never" class="off-ent">
    <template #header>
      <div class="head">
        <span>离线企业版代码 <span class="muted sub">— 按版本放一套,全平台共享,直接挂载</span></span>
        <div class="head-acts">
          <el-input v-model="upVersion" size="small" placeholder="版本如 19" style="width: 96px" />
          <input ref="fileInput" type="file" accept=".zip,application/zip" style="display: none" @change="onPick" />
          <el-button size="small" type="primary" :loading="uploading" @click="pickUpload">上传代码包</el-button>
          <el-button size="small" :icon="Refresh" @click="load">扫描</el-button>
        </div>
      </div>
    </template>
    <div class="muted hint">
      企业版 addons(需组织自行持有合法授权)。两种放法:①上方填版本 +「上传代码包」直接传 zip;
      ②有服务器权限的人把 clone 下来的仓库文件夹整个放进 <code>{{ hostDir || '…' }}/&lt;版本&gt;/</code>(标准布局 <code>19/enterprise/…</code>;模块直接放版本目录下或 <code>addons/</code> 子目录也能识别)再点「扫描」。上传与自动导入也按此布局落盘。
      <b>创建企业版实例时自动按版本使用这里的代码</b>,同一套全平台共享。
    </div>
    <div v-if="uploading" class="up-prog"><el-progress :percentage="upPct" :stroke-width="6" /><span class="muted">上传中…</span></div>
    <el-table v-if="items.length" :data="items" size="small">
      <el-table-column label="版本目录" min-width="140">
        <template #default="{ row }"><span class="mono">{{ row.name }}</span></template>
      </el-table-column>
      <el-table-column label="状态" min-width="200">
        <template #default="{ row }">
          <template v-if="row.valid">
            <el-tag size="small" type="success" effect="plain">可用</el-tag>
            <span class="muted"> {{ row.modules }} 个模块{{ row.subdir ? `(在 ${row.subdir}/ 子目录)` : '' }}</span>
          </template>
          <template v-else>
            <el-tag size="small" type="danger" effect="plain">无效</el-tag>
            <span class="muted"> 目录里没有 Odoo 模块(缺 __manifest__.py)</span>
          </template>
          <!-- 目录是只读挂载给实例容器的活目录:删/改会立刻影响这些实例 -->
          <div v-if="row.in_use && row.in_use.length" class="in-use">
            <el-tag size="small" type="warning" effect="plain">{{ row.in_use.length }} 个实例在用</el-tag>
            <span class="muted mono"> {{ row.in_use.slice(0, 4).join('、') }}{{ row.in_use.length > 4 ? ' 等' : '' }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="80" align="right">
        <template #default="{ row }"><el-button link type="danger" size="small" @click="remove(row.name)">删除</el-button></template>
      </el-table-column>
    </el-table>
    <el-empty v-else-if="!pending.length" :image-size="50" description="目录里还没有企业版代码" />

    <!-- 旧 git 检出里有、统一目录还没有的版本:创建实例时会自动导入;这里也可手动导入 -->
    <div v-if="pending.length" class="pending">
      <div class="muted" style="font-size: 12px; margin-bottom: 6px">检测到已有代码(此前通过 Git 拉取),尚未导入统一目录 —— 创建实例时会自动导入,也可现在导入:</div>
      <div v-for="p in pending" :key="p.version" class="pending-row">
        <span class="mono">版本 {{ p.version }}</span>
        <el-tag size="small" type="warning" effect="plain">未导入</el-tag>
        <span class="muted mono" style="font-size: 12px">{{ p.commit }}</span>
        <el-button link type="primary" size="small" :loading="seeding === p.version" @click="seed(p.version)">导入到统一目录</el-button>
      </div>
    </div>
  </el-card>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import api from '../../api'
import { confirmDanger } from '../../utils/confirm'

const items = ref([]); const hostDir = ref(''); const pending = ref([]); const seeding = ref('')
const upVersion = ref(''); const fileInput = ref(null); const uploading = ref(false); const upPct = ref(0)
async function load() {
  try { const r = await api.get('/enterprise/offline'); items.value = r.items || []; hostDir.value = r.host_dir || ''; pending.value = r.pending || [] } catch {}
}
async function seed(version) {
  seeding.value = version
  try { await api.post('/enterprise/offline/seed', null, { params: { version } }); ElMessage.success(`版本 ${version} 已导入统一目录`); load() } catch {} finally { seeding.value = '' }
}
function pickUpload() {
  if (!/^\d{2}(\.0)?$/.test(upVersion.value.trim())) return ElMessage.warning('请先填写版本号,如 19')
  fileInput.value?.click()
}
function onPick(e) {
  const file = e.target.files?.[0]; e.target.value = ''
  if (file) upload(file)
}
async function upload(file) {
  uploading.value = true; upPct.value = 0
  try {
    const r = await api.put('/enterprise/offline/upload', file, {
      params: { version: upVersion.value.trim() }, headers: { 'Content-Type': 'application/zip' }, timeout: 0,
      onUploadProgress: (ev) => { if (ev.total) upPct.value = Math.round(ev.loaded / ev.total * 100) },
    })
    ElMessage.success(`已上传 ${r.version}:新增 ${r.new.length}、更新 ${r.updated.length} 个模块`)
    // 覆盖了同名模块、且有实例正挂载该版本:活挂载底下换了文件,这些实例要重启才干净
    if (r.in_use?.length) {
      ElMessage.warning({
        duration: 8000,
        message: `${r.in_use.length} 个实例正在使用该版本(${r.in_use.slice(0, 4).join('、')}${r.in_use.length > 4 ? ' 等' : ''}),`
          + '模块已被覆盖,请重启这些实例并在 Odoo 里升级对应模块',
      })
    }
    load()
  } catch {} finally { uploading.value = false }
}
/** 强制删除:要求原样输入版本目录名才放行(代码目录是活挂载,删了在用的实例立刻就报错) */
async function forceRemove(name, detail) {
  if (!(await confirmDanger({ title: '强制删除企业版代码', message: detail, requireText: name, confirmText: '强制删除' }))) return
  try { await api.delete(`/enterprise/offline/${encodeURIComponent(name)}`, { params: { force: true } }); ElMessage.success('已强制删除'); load() } catch {}
}

async function remove(name) {
  const using = items.value.find((r) => r.name === name)?.in_use || []
  if (using.length) {
    return forceRemove(name, `有 ${using.length} 个实例正挂载着这份代码(${using.slice(0, 6).join('、')}${using.length > 6 ? ' 等' : ''})。`
      + '代码目录是直接挂进容器的,删除后它们会立刻读不到企业版模块 —— 不是重建才受影响,是马上报错。')
  }
  if (!(await confirmDanger({ title: '删除企业版代码', message: `删除版本目录「${name}」及其下全部代码?` }))) return
  try {
    // silent:占用检查以后端为准(列表可能是旧的),它拒绝时由下面自己弹确认,不重复弹错误提示
    await api.delete(`/enterprise/offline/${encodeURIComponent(name)}`, { silent: true })
    ElMessage.success('已删除'); load()
  } catch (e) {
    if (e?.response?.status !== 400) { ElMessage.error(e?.detail || '删除失败'); return }
    load()  // 刷新出占用信息
    await forceRemove(name, e.detail || '该版本代码正在被实例使用。')
  }
}
onMounted(load)
defineExpose({ load })
</script>

<style scoped>
.off-ent { margin-bottom: 16px; }
.head { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.head-acts { display: flex; align-items: center; gap: 6px; }
.up-prog { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.up-prog :deep(.el-progress) { flex: 1; }
.in-use { margin-top: 3px; font-size: 12px; }
.pending { margin-top: 10px; padding-top: 10px; border-top: 1px dashed var(--line-2, #e5e7eb); }
.pending-row { display: flex; align-items: center; gap: 8px; padding: 3px 0; }
.sub { font-weight: 400; font-size: 12px; }
.hint { font-size: 12.5px; line-height: 1.7; margin-bottom: 10px; }
.hint code { word-break: break-all; }
.mono { font-family: var(--mono, monospace); }
</style>
