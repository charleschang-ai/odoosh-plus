<template>
  <!-- Webhook 信息 / 自动创建:<WebhookDialog v-model="show" :repo="cur" :can-write="canWrite(cur)" @changed="load" /> -->
  <el-dialog v-model="visible" :title="`Webhook — ${repo?.name || ''}`" width="640px" @open="load">
    <div v-loading="loading">
      <el-alert v-if="repo?.webhook_id" type="success" :closable="false" title="已由平台自动在 Git 平台上创建 Webhook" style="margin-bottom: 12px" />
      <el-form label-width="90px">
        <el-form-item label="回调地址">
          <el-input :model-value="wh.url" readonly><template #append><el-button @click="copyText(wh.url)">复制</el-button></template></el-input>
        </el-form-item>
        <el-form-item label="密钥">
          <el-input :model-value="wh.secret" readonly type="password" show-password><template #append><el-button @click="copyText(wh.secret)">复制</el-button></template></el-input>
        </el-form-item>
      </el-form>
      <el-alert type="info" :closable="false" :title="`在 ${providerLabel(wh.provider)} 上手动配置`" :description="wh.instructions" />
      <div class="hint" style="margin-top: 8px">回调地址必须能被 Git 平台从公网访问;本地开发可用 cpolar / frp 等内网穿透。收不到 Webhook 时可开启「自动检查远端更新」兜底。</div>
    </div>
    <template #footer>
      <el-button v-if="canWrite" type="primary" :loading="creating" @click="autoWebhook">{{ repo?.webhook_id ? '重新创建' : '自动创建 Webhook' }}</el-button>
      <el-button @click="visible = false">关闭</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../../api'
import { providerLabel } from '../../utils/labels'
import { copyText } from '../../utils/clipboard'

const props = defineProps({ modelValue: Boolean, repo: { type: Object, default: null }, canWrite: { type: Boolean, default: false } })
const emit = defineEmits(['update:modelValue', 'changed'])
const visible = computed({ get: () => props.modelValue, set: (v) => emit('update:modelValue', v) })
const loading = ref(false); const creating = ref(false)
const wh = reactive({ url: '', secret: '', provider: 'generic', instructions: '' })
async function load() {
  if (!props.repo) return
  loading.value = true
  try { Object.assign(wh, await api.get(`/repos/${props.repo.id}/webhook`)) } catch {} finally { loading.value = false }
}
async function autoWebhook() {
  creating.value = true
  try { await api.post(`/repos/${props.repo.id}/webhook/auto`); ElMessage.success('Webhook 已创建'); emit('changed'); await load() } catch {} finally { creating.value = false }
}
</script>

<style scoped>
.hint { font-size: 12px; color: var(--text-3); line-height: 1.5; }
</style>
