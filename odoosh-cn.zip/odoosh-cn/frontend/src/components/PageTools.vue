<template>
  <!--
    页面工具栏容器:宽屏(≥1280px)时把工具栏传送到顶部导航栏的 #hdr-tools 槽位(Layout.vue),
    让页面正文少一行、顶栏空余空间得到利用;窄屏时原地渲染在 .page-header 里。
    用法:<div class="page-header">…<PageTools><el-input …/><el-button …/></PageTools></div>
    传送后 scoped 样式仍然生效(data-v 属性跟着元素走)。
  -->
  <Teleport defer to="#hdr-tools" :disabled="!inHeader">
    <div class="page-tools" :class="{ 'in-header': inHeader }"><slot /></div>
  </Teleport>
</template>

<script setup>
import { computed } from 'vue'
import { useMediaQuery } from '../composables/useMedia'

const props = defineProps({
  /** 强制留在页面里(例如工具太多放不下顶栏) */
  inline: { type: Boolean, default: false },
})
const wide = useMediaQuery('(min-width: 1280px)')
const inHeader = computed(() => wide.value && !props.inline)
</script>
