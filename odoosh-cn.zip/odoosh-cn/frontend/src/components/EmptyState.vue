<template>
  <!-- 空状态:内联线性插画(无外部资源)+ 标题 / 说明 / 操作插槽。variant: envs | repos | backups | search | generic -->
  <div class="empty" :class="`v-${variant}`">
    <svg viewBox="0 0 160 110" :width="width" :height="width * 110 / 160" aria-hidden="true" class="art">
      <defs>
        <linearGradient :id="`${uid}-a`" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="var(--brand)" stop-opacity=".9" /><stop offset="100%" stop-color="#2563eb" stop-opacity=".9" /></linearGradient>
      </defs>
      <!-- 底部阴影 -->
      <ellipse cx="80" cy="98" rx="52" ry="6" class="shadow" />
      <!-- 实例:三层卡片 -->
      <g v-if="variant === 'envs'" class="lines">
        <rect x="34" y="42" width="92" height="46" rx="8" class="face" />
        <rect x="42" y="30" width="76" height="12" rx="6" class="ghost" />
        <rect x="50" y="18" width="60" height="12" rx="6" class="ghost2" />
        <circle cx="50" cy="58" r="6" :fill="`url(#${uid}-a)`" stroke="none" />
        <rect x="62" y="53" width="40" height="4" rx="2" class="txt" />
        <rect x="62" y="61" width="26" height="4" rx="2" class="txt2" />
        <rect x="44" y="74" width="72" height="5" rx="2.5" class="bar" />
        <rect x="44" y="74" width="34" height="5" rx="2.5" :fill="`url(#${uid}-a)`" stroke="none" />
        <circle cx="114" cy="56" r="3" class="dot-ok" />
      </g>
      <!-- 仓库:分支图 -->
      <g v-else-if="variant === 'repos'" class="lines">
        <rect x="30" y="24" width="100" height="64" rx="10" class="face" />
        <path d="M58 40 V72" class="stroke" />
        <path d="M58 40 C58 58, 96 50, 96 68" class="stroke" />
        <circle cx="58" cy="40" r="5" :fill="`url(#${uid}-a)`" stroke="none" />
        <circle cx="58" cy="72" r="5" class="node" />
        <circle cx="96" cy="70" r="5" class="node" />
        <rect x="70" y="36" width="34" height="4" rx="2" class="txt" />
        <rect x="70" y="44" width="22" height="4" rx="2" class="txt2" />
        <rect x="106" y="66" width="16" height="4" rx="2" class="txt2" />
      </g>
      <!-- 备份:堆叠圆盘 + 时钟 -->
      <g v-else-if="variant === 'backups'" class="lines">
        <ellipse cx="72" cy="42" rx="34" ry="10" class="face" />
        <path d="M38 42 V60 C38 65.5 53.2 70 72 70 C90.8 70 106 65.5 106 60 V42" class="face" />
        <path d="M38 60 V78 C38 83.5 53.2 88 72 88 C90.8 88 106 83.5 106 78 V60" class="face" />
        <ellipse cx="72" cy="42" rx="34" ry="10" class="face" />
        <circle cx="116" cy="70" r="16" class="face-2" />
        <path d="M116 61 V70 L122 74" class="stroke-b" />
        <circle cx="52" cy="60" r="2" class="dot-ok" /><circle cx="52" cy="78" r="2" class="dot-ok" />
      </g>
      <!-- 搜索无结果 -->
      <g v-else-if="variant === 'search'" class="lines">
        <circle cx="72" cy="52" r="26" class="face" />
        <circle cx="72" cy="52" r="17" class="face-2" />
        <path d="M91 71 L110 90" class="stroke-b" stroke-width="6" />
        <path d="M64 46 L80 58 M80 46 L64 58" class="stroke" />
      </g>
      <!-- 通用:空文件夹 -->
      <g v-else class="lines">
        <path d="M34 34 h32 l8 8 h52 a6 6 0 0 1 6 6 v34 a6 6 0 0 1 -6 6 h-92 a6 6 0 0 1 -6 -6 v-42 a6 6 0 0 1 6 -6 z" class="face" />
        <path d="M28 52 h104" class="stroke" />
        <rect x="60" y="62" width="40" height="4" rx="2" class="txt2" />
      </g>
    </svg>
    <div class="t" v-if="title">{{ title }}</div>
    <div class="d muted" v-if="desc">{{ desc }}</div>
    <div class="acts" v-if="$slots.default"><slot /></div>
  </div>
</template>

<script setup>
defineProps({
  variant: { type: String, default: 'generic' },
  title: { type: String, default: '' },
  desc: { type: String, default: '' },
  width: { type: Number, default: 160 },
})
const uid = 'es' + Math.random().toString(36).slice(2, 7)
</script>

<style scoped>
.empty { display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; padding: 36px 16px 32px; }
.art { display: block; margin-bottom: 8px; }
.shadow { fill: rgba(20, 28, 42, .06); }
.lines { fill: none; stroke: #b6bec9; stroke-width: 1.5; stroke-linecap: round; stroke-linejoin: round; }
.face { fill: #fff; stroke: #c9d0da; }
.face-2 { fill: var(--surface-2); stroke: #c9d0da; }
.ghost { fill: #f2f4f7; stroke: #dde2e9; }
.ghost2 { fill: #f7f8fa; stroke: #e6e9ee; }
.txt { fill: #cfd5de; stroke: none; }
.txt2 { fill: #e3e7ed; stroke: none; }
.bar { fill: #eef0f3; stroke: none; }
.node { fill: #fff; stroke: #94a3b8; }
.stroke { stroke: #94a3b8; }
.stroke-b { stroke: var(--brand); stroke-width: 2.2; }
.dot-ok { fill: #34d399; stroke: none; }
.t { font-size: 14.5px; font-weight: 600; color: var(--text-2); }
.d { font-size: 12.5px; margin-top: 4px; max-width: 360px; line-height: 1.6; }
.acts { margin-top: 14px; display: flex; gap: 8px; }
</style>
