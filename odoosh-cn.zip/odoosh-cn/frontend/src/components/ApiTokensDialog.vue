<template>
  <el-dialog :model-value="modelValue" title="接入令牌" width="880px" top="6vh" @update:model-value="$emit('update:modelValue', $event)" @open="load" @closed="reset">
    <p class="hint">
      第三方系统（如学校的课程系统）在<b>服务端</b>持令牌调用 <code>/api/ext/*</code>：同步用户、开通实例、换取免登地址。
      令牌只能落在绑定的组织内，能授予的权限受下面的上限约束。<b>明文只显示一次</b>，且绝不能放进网页链接里。
    </p>

    <el-table :data="rows" size="small" v-loading="loading" empty-text="还没有令牌" class="tbl">
      <el-table-column label="名称" min-width="130" show-overflow-tooltip>
        <template #default="{ row }">
          <div>{{ row.name }}</div>
          <div class="sub"><code>{{ row.prefix }}…</code> · 来源 {{ row.source }}</div>
        </template>
      </el-table-column>
      <el-table-column label="组织" prop="tenant_name" min-width="100" show-overflow-tooltip />
      <el-table-column label="权限" min-width="180">
        <template #default="{ row }">
          <el-tag v-for="s in scopeList(row.scopes)" :key="s" size="small" effect="plain" class="stag">{{ SCOPE_LABEL[s] || s }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="上限" min-width="150">
        <template #default="{ row }">
          <span class="sub">最高 {{ ROLE_LABEL[row.max_grant_role] || row.max_grant_role }} · 每人 {{ row.max_envs_per_user }} 个实例<template v-if="!row.allow_create_user"> · 不可建号</template><template v-if="row.allow_admin_role"> · 可设超管</template><template v-if="row.allow_any_tenant"> · 可跨组织</template><template v-if="row.allow_delete_user"> · 可删用户</template><template v-if="row.hide_nav"> · 免登隐藏菜单</template></span>
        </template>
      </el-table-column>
      <el-table-column label="到期" width="105"><template #default="{ row }">{{ fmtDate(row.expires_at, '永久') }}</template></el-table-column>
      <el-table-column label="最近使用" min-width="140">
        <template #default="{ row }"><span v-if="row.last_used_at">{{ ago(row.last_used_at) }}<span class="sub" v-if="row.last_used_ip"> · {{ row.last_used_ip }}</span></span><span v-else class="sub">从未</span></template>
      </el-table-column>
      <el-table-column label="状态" width="76">
        <template #default="{ row }"><el-tag size="small" :type="row.status === 'active' ? 'success' : 'info'">{{ STATUS[row.status] || row.status }}</el-tag></template>
      </el-table-column>
      <el-table-column label="" width="150" align="right">
        <template #default="{ row }">
          <el-button v-if="row.status === 'active'" link type="primary" size="small" @click="startEdit(row)">编辑</el-button>
          <el-button v-if="row.status === 'active'" link type="danger" size="small" @click="revoke(row)">吊销</el-button>
          <el-button link type="danger" size="small" @click="remove(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 新建：0 未开始 / 1 输密码 / 2 填写 / 3 展示明文 -->
    <div v-if="step === 1" class="panel">
      <div class="panel-title">第一步 · 确认身份<span v-if="editing" class="tip inline">（编辑「{{ editing.name }}」的权限）</span></div>
      <el-form label-position="top" @submit.prevent="verify">
        <el-form-item label="当前登录密码">
          <el-input v-model="password" type="password" show-password autocomplete="current-password" :placeholder="editing ? '修改令牌权限前需先验证身份' : '创建令牌前需先验证身份'" @keyup.enter="verify" />
        </el-form-item>
      </el-form>
    </div>

    <div v-else-if="step === 2" class="panel">
      <div class="panel-title">第二步 · {{ editing ? '修改权限（令牌值不变，保存后立即生效）' : '令牌信息' }}</div>
      <el-form label-position="top" @submit.prevent="submit">
        <div class="row2">
          <el-form-item label="名称">
            <el-input v-model="form.name" maxlength="64" placeholder="例如：学校课程系统" />
          </el-form-item>
          <el-form-item label="来源标识">
            <el-input v-model="form.source" maxlength="64" placeholder="school" :disabled="!!editing" />
            <div class="tip">同步进来的用户记在此来源下，用于区分多个接入系统。建后不可改。</div>
          </el-form-item>
        </div>
        <div class="row2">
          <el-form-item label="绑定组织（同步进来的用户都落在这里）">
            <el-select v-model="form.tenant_id" placeholder="选择组织" filterable style="width: 100%" :disabled="!!editing">
              <el-option v-for="t in tenants" :key="t.id" :label="t.name" :value="t.id" />
            </el-select>
          </el-form-item>
          <el-form-item :label="editing ? '有效期（不改则保持原到期日）' : '有效期'">
            <el-select v-model="form.expires_days" style="width: 100%" clearable>
              <el-option v-for="o in EXPIRES" :key="o.value" :label="o.label" :value="o.value" />
            </el-select>
          </el-form-item>
        </div>
        <el-form-item v-if="form.expires_days === 0" label="自定义天数（1 ~ 730）">
          <el-input-number v-model="customDays" :min="1" :max="730" />
        </el-form-item>

        <el-form-item label="权限范围">
          <el-checkbox-group v-model="form.scopes">
            <el-checkbox v-for="s in SCOPES" :key="s.value" :value="s.value">
              {{ s.label }}<span class="tip inline">{{ s.desc }}</span>
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>

        <div class="panel-title sub-title">安全上限（调用方无法在请求里突破）</div>
        <div class="row3">
          <el-form-item label="最多可授予的角色">
            <el-select v-model="form.max_grant_role" style="width: 100%">
              <el-option label="测试者" value="tester" />
              <el-option label="开发者" value="developer" />
              <el-option label="组织管理员" value="owner" />
            </el-select>
          </el-form-item>
          <el-form-item label="每人最多几个实例">
            <el-input-number v-model="form.max_envs_per_user" :min="0" :max="50" style="width: 100%" />
          </el-form-item>
          <el-form-item label="允许创建新用户">
            <el-switch v-model="form.allow_create_user" active-text="允许" inactive-text="仅更新" />
          </el-form-item>
        </div>
        <div class="row2">
          <el-form-item label="允许指定其他组织">
            <el-switch v-model="form.allow_any_tenant" active-text="允许" inactive-text="仅绑定组织" />
            <div class="tip">开启后请求里可按 id 或 slug 指定组织，用于一把令牌接多个班级 / 部门。</div>
          </el-form-item>
          <el-form-item label="允许设为平台管理员">
            <el-switch v-model="form.allow_admin_role" active-text="允许" inactive-text="禁止" />
            <div class="tip">平台管理员能看所有组织，令牌泄露后果最重，默认禁止。</div>
          </el-form-item>
        </div>
        <div class="row2">
          <el-form-item label="允许删除用户">
            <el-switch v-model="form.allow_delete_user" active-text="允许" inactive-text="禁止" />
            <div class="tip">开启后接入方删除用户会连带删除平台账号（其实例先进回收站）。不开则只能停用。</div>
          </el-form-item>
          <el-form-item label="免登默认隐藏左侧菜单">
            <el-switch v-model="form.hide_nav" active-text="隐藏" inactive-text="显示" />
            <div class="tip">嵌入 iframe 的接入方建议开启：免登进来的页面不再显示左侧菜单。接入方也可在 handoff 请求里用 menu 参数按次覆盖。</div>
          </el-form-item>
        </div>
      </el-form>
    </div>

    <div v-else-if="step === 3" class="panel ok">
      <div class="panel-title">令牌已创建，请立即复制保存 —— 关闭后无法再次查看</div>
      <div class="token-box">
        <code class="token">{{ created }}</code>
        <el-button size="small" type="primary" @click="copy">复制</el-button>
      </div>
      <p class="tip" style="margin: 10px 0 4px">调用示例（同步一个用户并顺带开通实例）：</p>
      <pre class="sample">curl -X POST {{ origin }}/api/ext/users \
  -H "Authorization: Bearer {{ created }}" \
  -H "Content-Type: application/json" \
  -d '{"external_id": "42", "username": "s2024010233",
       "display_name": "张三", "tenant_role": "developer",
       "provision": {"odoo_version": "18"}}'</pre>
    </div>

    <template #footer>
      <template v-if="step === 0">
        <el-button @click="$emit('update:modelValue', false)">关闭</el-button>
        <el-button type="primary" @click="step = 1">新建令牌</el-button>
      </template>
      <template v-else-if="step === 1">
        <el-button @click="step = 0">取消</el-button>
        <el-button type="primary" :loading="busy" :disabled="!password" @click="verify">验证并继续</el-button>
      </template>
      <template v-else-if="step === 2">
        <el-button @click="step = 0">取消</el-button>
        <el-button type="primary" :loading="busy" :disabled="!canSubmit" @click="submit">{{ editing ? '保存' : '生成令牌' }}</el-button>
      </template>
      <template v-else>
        <el-button type="primary" @click="step = 0">我已保存，完成</el-button>
      </template>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import api from '../api'
import { useTenants } from '../store'
import { ago, fmtDate } from '../utils/format'

defineProps({ modelValue: Boolean })
defineEmits(['update:modelValue'])

const STATUS = { active: '有效', expired: '已过期', revoked: '已吊销' }
const ROLE_LABEL = { tester: '测试者', developer: '开发者', owner: '组织管理员' }
const SCOPE_LABEL = { handoff: '免登入口', 'users:write': '同步用户', 'envs:read': '查询实例', 'envs:write': '开通实例' }
const SCOPES = [
  { value: 'handoff', label: '免登入口', desc: '换取免登地址，把用户送进控制台或实例' },
  { value: 'users:write', label: '同步用户', desc: '创建、更新、停用用户（权限最大，仅在需要同步时开启）' },
  { value: 'envs:read', label: '查询实例', desc: '读取用户的实例状态，供对方渲染自己的看板' },
  { value: 'envs:write', label: '开通实例', desc: '为用户创建实例' },
]
const EXPIRES = [
  { label: '1 天', value: 1 }, { label: '1 个月', value: 30 }, { label: '3 个月', value: 90 },
  { label: '6 个月', value: 180 }, { label: '1 年', value: 365 }, { label: '自定义…', value: 0 },
]
const origin = window.location.origin
const tenants = useTenants()

const rows = ref([]); const loading = ref(false); const busy = ref(false)
const step = ref(0)
const password = ref(''); const grant = ref('')
const customDays = ref(30)
const created = ref('')
const DEFAULTS = {
  name: '', source: 'school', tenant_id: null, expires_days: 180,
  scopes: ['handoff', 'users:write', 'envs:read', 'envs:write'],
  max_grant_role: 'developer', max_envs_per_user: 1, allow_create_user: true,
  allow_admin_role: false, allow_any_tenant: false, allow_delete_user: false, hide_nav: false,
}
const form = reactive({ ...DEFAULTS })

const editing = ref(null)  // 正在编辑的令牌行;null = 新建
const days = computed(() => (form.expires_days === 0 ? customDays.value : (form.expires_days || null)))
const canSubmit = computed(() => !!form.name.trim() && form.scopes.length > 0 && (editing.value
  ? true
  : (!!form.source.trim() && !!form.tenant_id && !!days.value)))
const scopeList = (s) => String(s || '').split(',').filter(Boolean)

async function load() {
  loading.value = true
  try { rows.value = await api.get('/tokens') } catch {} finally { loading.value = false }
}
function reset() {
  step.value = 0; password.value = ''; grant.value = ''; created.value = ''; editing.value = null
  Object.assign(form, DEFAULTS, { scopes: [...DEFAULTS.scopes] })
}

function startEdit(row) {
  editing.value = row
  Object.assign(form, {
    name: row.name, source: row.source, tenant_id: row.tenant_id, expires_days: null,
    scopes: scopeList(row.scopes),
    max_grant_role: row.max_grant_role, max_envs_per_user: row.max_envs_per_user,
    allow_create_user: !!row.allow_create_user, allow_admin_role: !!row.allow_admin_role,
    allow_any_tenant: !!row.allow_any_tenant, allow_delete_user: !!row.allow_delete_user,
    hide_nav: !!row.hide_nav,
  })
  step.value = 1
}

function submit() { return editing.value ? save() : create() }

async function save() {
  if (!canSubmit.value || !editing.value) return
  busy.value = true
  try {
    const body = {
      grant: grant.value, name: form.name.trim(), scopes: form.scopes,
      max_grant_role: form.max_grant_role, max_envs_per_user: form.max_envs_per_user,
      allow_create_user: form.allow_create_user, allow_admin_role: form.allow_admin_role,
      allow_any_tenant: form.allow_any_tenant, allow_delete_user: form.allow_delete_user,
      hide_nav: form.hide_nav,
    }
    if (days.value) body.expires_days = days.value
    await api.put(`/tokens/${editing.value.id}`, body)
    ElMessage.success('已保存，对下一次请求立即生效')
    grant.value = ''; editing.value = null; step.value = 0
    load()
  } catch (e) {
    if (e?.response?.status === 403) step.value = 1
  } finally { busy.value = false }
}

async function verify() {
  if (!password.value) return
  busy.value = true
  try {
    const r = await api.post('/tokens/verify-identity', { password: password.value })
    grant.value = r.grant; password.value = ''
    if (!form.tenant_id && tenants.value.length === 1) form.tenant_id = tenants.value[0].id
    step.value = 2
  } catch {} finally { busy.value = false }
}

async function create() {
  if (!canSubmit.value) return
  busy.value = true
  try {
    const r = await api.post('/tokens', {
      grant: grant.value,
      name: form.name.trim(),
      source: form.source.trim(),
      tenant_id: form.tenant_id,
      expires_days: days.value,
      scopes: form.scopes,
      max_grant_role: form.max_grant_role,
      max_envs_per_user: form.max_envs_per_user,
      allow_create_user: form.allow_create_user,
      allow_admin_role: form.allow_admin_role,
      allow_any_tenant: form.allow_any_tenant,
      allow_delete_user: form.allow_delete_user,
      hide_nav: form.hide_nav,
    })
    created.value = r.token; grant.value = ''
    step.value = 3
    load()
  } catch (e) {
    if (e?.response?.status === 403) step.value = 1  // 身份确认凭据过期 → 回到输密码
  } finally { busy.value = false }
}

async function copy() {
  try { await navigator.clipboard.writeText(created.value); ElMessage.success('已复制') } catch { ElMessage.warning('复制失败，请手动选中复制') }
}

async function revoke(row) {
  try {
    await ElMessageBox.confirm(`吊销后使用「${row.name}」的系统将立即无法调用任何接口，且不可恢复。`, '吊销令牌', { type: 'warning', confirmButtonText: '吊销', confirmButtonClass: 'el-button--danger' })
  } catch { return }
  try { await api.delete(`/tokens/${row.id}`); ElMessage.success('已吊销'); load() } catch {}
}

// 吊销留痕、便于事后追查;这个是把记录删掉,用来清理调试期间攒下的废令牌
async function remove(row) {
  const live = row.status === 'active' ? '它当前仍有效，删除后使用它的系统会立即调用失败。' : ''
  try {
    await ElMessageBox.confirm(`彻底删除令牌「${row.name}」的记录，调用日志里将不再能追溯到它。${live}`, '删除令牌', { type: 'warning', confirmButtonText: '删除', confirmButtonClass: 'el-button--danger' })
  } catch { return }
  try { await api.delete(`/tokens/${row.id}/purge`); ElMessage.success('已删除'); load() } catch {}
}
</script>

<style scoped>
.hint { margin: 0 0 12px; color: var(--text-2, #475569); font-size: 13px; line-height: 1.7; }
.hint code, .tbl code { font-size: 12px; background: var(--fill, #f1f5f9); padding: 1px 5px; border-radius: 4px; }
.sub { color: var(--text-3, #94a3b8); font-size: 12px; }
.stag { margin: 0 4px 2px 0; }
.panel { margin-top: 16px; padding: 14px 16px 4px; border: 1px solid var(--border, #e2e8f0); border-radius: 8px; }
.panel.ok { border-color: #86efac; background: #f0fdf4; padding-bottom: 14px; }
.panel-title { font-weight: 600; margin-bottom: 10px; font-size: 13px; }
.sub-title { margin-top: 4px; padding-top: 10px; border-top: 1px dashed var(--border, #e2e8f0); }
.row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.row3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
.tip { color: var(--text-3, #94a3b8); font-size: 12px; line-height: 1.6; }
.tip.inline { margin-left: 6px; }
.token-box { display: flex; align-items: center; gap: 10px; }
.token { flex: 1; font-size: 13px; word-break: break-all; background: #fff; border: 1px solid #bbf7d0; border-radius: 6px; padding: 8px 10px; user-select: all; }
.sample { margin: 0; font-size: 12px; background: #0f172a; color: #e2e8f0; padding: 10px 12px; border-radius: 6px; overflow-x: auto; white-space: pre; }
</style>
