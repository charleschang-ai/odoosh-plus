<template>
  <el-dialog :model-value="modelValue" :title="`批量修改 ${userIds.length} 个用户`" width="580px" @update:model-value="close" :close-on-click-modal="false" class="bulk-dlg">
    <div class="tip">勾选要修改的项;未勾选的保持不变。内置超级管理员的受保护项(停用 / 降级)会自动跳过。</div>
    <div class="groups">
      <div class="grp">
        <el-checkbox v-model="on.active">启用状态</el-checkbox>
        <div v-if="on.active" class="ctrl"><el-switch v-model="f.is_active" inline-prompt active-text="启用" inactive-text="停用" /><span class="note">{{ f.is_active ? '允许登录' : '立即禁止登录并使已签发令牌失效' }}</span></div>
      </div>
      <div class="grp">
        <el-checkbox v-model="on.shell">实例 Shell</el-checkbox>
        <div v-if="on.shell" class="ctrl"><el-switch v-model="f.shell_enabled" inline-prompt active-text="开" inactive-text="关" /><span class="note">是否显示 Web 终端(超管不受影响)</span></div>
      </div>
      <div class="grp">
        <el-checkbox v-model="on.menus">菜单可见</el-checkbox>
        <div v-if="on.menus" class="ctrl menus">
          <span class="msw"><el-switch v-model="f.menu_dashboard" inline-prompt active-text="开" inactive-text="关" />总览</span>
          <span class="msw"><el-switch v-model="f.menu_repos" inline-prompt active-text="开" inactive-text="关" />Git 仓库</span>
          <span class="msw"><el-switch v-model="f.menu_ai" inline-prompt active-text="开" inactive-text="关" />AI 助手</span>
          <span class="msw"><el-switch v-model="f.menu_backups" inline-prompt active-text="开" inactive-text="关" />备份与恢复</span>
          <span class="msw"><el-switch v-model="f.menu_settings" inline-prompt active-text="开" inactive-text="关" />实例设置</span>
          <span class="msw"><el-switch v-model="f.menu_upgrade" inline-prompt active-text="开" inactive-text="关" />实例升级</span>
          <span class="msw"><el-switch v-model="f.menu_databases" inline-prompt active-text="开" inactive-text="关" />实例数据库</span>
          <span class="note">前四个是侧栏菜单(关 = 不显示且地址进不去);后三个是实例详情页 Tab,默认关(超管都不受影响)</span>
        </div>
      </div>
      <div class="grp">
        <el-checkbox v-model="on.envs">实例配额</el-checkbox>
        <div v-if="on.envs" class="ctrl"><el-input-number v-model="f.max_envs" :min="0" :max="10000" controls-position="right" placeholder="不限" class="num" /><span class="note">{{ f.max_envs == null ? '不限' : f.max_envs === 0 ? '不能创建' : `最多 ${f.max_envs} 个` }}</span></div>
      </div>
      <div class="grp">
        <el-checkbox v-model="on.dbs">附加库配额</el-checkbox>
        <div v-if="on.dbs" class="ctrl"><el-input-number v-model="f.max_dbs" :min="0" :max="10000" controls-position="right" placeholder="不限" class="num" /><span class="note">{{ f.max_dbs == null ? '不限' : f.max_dbs === 0 ? '不能创建' : `最多 ${f.max_dbs} 个` }}</span></div>
      </div>
      <div class="grp">
        <el-checkbox v-model="on.role">平台角色</el-checkbox>
        <div v-if="on.role" class="ctrl col">
          <el-radio-group v-model="f.role"><el-radio-button value="member">普通用户</el-radio-button><el-radio-button value="admin">超级管理员</el-radio-button></el-radio-group>
          <span class="note warn">改为超级管理员会清空其组织角色并授予全平台权限;超管无法在此被降级(自己也不能)。</span>
        </div>
      </div>
      <div class="grp">
        <el-checkbox v-model="on.mem">组织权限</el-checkbox>
        <div v-if="on.mem" class="ctrl col">
          <el-radio-group v-model="f.membership_mode" size="small">
            <el-radio-button value="add">加入 / 改角色</el-radio-button>
            <el-radio-button value="remove">移出组织</el-radio-button>
            <el-radio-button value="replace">整体替换</el-radio-button>
          </el-radio-group>
          <span class="note">{{ MODE_NOTE[f.membership_mode] }}(超管无组织角色,将自动跳过)</span>
          <!-- add / replace:组织 + 角色 -->
          <template v-if="f.membership_mode !== 'remove'">
            <div v-for="(m, i) in f.memberships" :key="i" class="mrow">
              <el-select v-model="m.tenant_id" placeholder="选择组织" class="mt">
                <el-option v-for="t in tenants" :key="t.id" :label="t.name" :value="t.id" :disabled="f.memberships.some((x, j) => j !== i && x.tenant_id === t.id)" />
              </el-select>
              <el-select v-model="m.role" class="mr"><el-option v-for="(l, r) in ROLE_LABEL" :key="r" :value="r" :label="l" /></el-select>
              <el-button circle :icon="Delete" @click="f.memberships.splice(i, 1)" />
            </div>
            <el-button link type="primary" :icon="Plus" @click="f.memberships.push({ tenant_id: null, role: 'developer' })">添加组织</el-button>
          </template>
          <!-- remove:多选组织 -->
          <el-select v-else v-model="f.remove_tenant_ids" multiple placeholder="选择要移出的组织" class="rm">
            <el-option v-for="t in tenants" :key="t.id" :label="t.name" :value="t.id" />
          </el-select>
        </div>
      </div>
    </div>
    <template #footer>
      <el-button @click="close">取消</el-button>
      <el-button type="primary" :loading="saving" :disabled="!anyOn" @click="submit">应用到 {{ userIds.length }} 个用户</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Delete } from '@element-plus/icons-vue'
import api from '../api'
import { ROLE_LABEL, tenants } from '../store'

const props = defineProps({ modelValue: Boolean, userIds: { type: Array, default: () => [] } })
const emit = defineEmits(['update:modelValue', 'done'])

const MODE_NOTE = { add: '加入所选组织(已在则改为该角色),不动其它组织', remove: '退出所选组织(一并清除这些组织实例上的授权)', replace: '用下方列表整体替换其组织角色' }
const on = reactive({ active: false, shell: false, menus: false, envs: false, dbs: false, role: false, mem: false })
const f = reactive({ is_active: true, shell_enabled: true, menu_dashboard: true, menu_repos: true, menu_ai: true, menu_backups: true, menu_settings: false, menu_upgrade: false, menu_databases: false, max_envs: null, max_dbs: null, role: 'member', membership_mode: 'add', memberships: [{ tenant_id: null, role: 'developer' }], remove_tenant_ids: [] })
const saving = ref(false)
const anyOn = computed(() => Object.values(on).some(Boolean))

watch(() => props.modelValue, (v) => {
  if (!v) return
  Object.keys(on).forEach((k) => (on[k] = false))
  Object.assign(f, { is_active: true, shell_enabled: true, menu_dashboard: true, menu_repos: true, menu_ai: true, menu_backups: true, menu_settings: false, menu_upgrade: false, menu_databases: false, max_envs: null, max_dbs: null, role: 'member', membership_mode: 'add', memberships: [{ tenant_id: tenants.value[0]?.id || null, role: 'developer' }], remove_tenant_ids: [] })
})

function buildPayload() {
  const p = { user_ids: props.userIds }
  if (on.active) p.is_active = f.is_active
  if (on.shell) p.shell_enabled = f.shell_enabled
  if (on.menus) { p.menu_dashboard = f.menu_dashboard; p.menu_repos = f.menu_repos; p.menu_ai = f.menu_ai; p.menu_backups = f.menu_backups; p.menu_settings = f.menu_settings; p.menu_upgrade = f.menu_upgrade; p.menu_databases = f.menu_databases }
  if (on.envs) { p.set_max_envs = true; p.max_envs = f.max_envs === '' || f.max_envs == null ? null : Number(f.max_envs) }
  if (on.dbs) { p.set_max_dbs = true; p.max_dbs = f.max_dbs === '' || f.max_dbs == null ? null : Number(f.max_dbs) }
  if (on.role) p.role = f.role
  if (on.mem) {
    p.membership_mode = f.membership_mode
    if (f.membership_mode === 'remove') p.remove_tenant_ids = f.remove_tenant_ids
    else p.memberships = f.memberships.filter((m) => m.tenant_id)
  }
  return p
}

async function submit() {
  const p = buildPayload()
  if (on.mem && p.membership_mode !== 'remove' && !(p.memberships || []).length) return ElMessage.warning('请至少添加一个组织')
  if (on.mem && p.membership_mode === 'remove' && !p.remove_tenant_ids.length) return ElMessage.warning('请选择要移出的组织')
  saving.value = true
  try {
    const r = await api.post('/users/bulk-update', p)
    const bad = r.results.filter((x) => x.status !== 'success')
    if (r.failed) {
      await ElMessageBox.alert(
        `<div>成功 ${r.succeeded} · 跳过 ${r.skipped} · 失败 ${r.failed}</div><ul style="margin:8px 0 0;padding-left:18px;max-height:220px;overflow:auto">` +
        bad.map((x) => `<li><b>${x.username}</b>:${x.status === 'failed' ? '❌' : '⤼'} ${x.message || ''}</li>`).join('') + '</ul>',
        '批量结果', { dangerouslyUseHTMLString: true, confirmButtonText: '知道了' })
    } else {
      ElMessage.success(`已应用:成功 ${r.succeeded}${r.skipped ? ` · 跳过 ${r.skipped}` : ''}`)
    }
    emit('done'); close()
  } catch {} finally { saving.value = false }
}
function close() { emit('update:modelValue', false) }
</script>

<style scoped>
.tip { font-size: 12.5px; color: var(--text-3); margin-bottom: 10px; line-height: 1.6; }
.groups { display: flex; flex-direction: column; gap: 6px; }
.grp { border: 1px solid var(--line-2); border-radius: 8px; padding: 10px 12px; }
.ctrl { display: flex; align-items: center; gap: 10px; margin-top: 8px; padding-left: 24px; }
.ctrl.col { flex-direction: column; align-items: flex-start; gap: 8px; }
.ctrl.menus { flex-wrap: wrap; gap: 14px; }
.msw { display: inline-flex; align-items: center; gap: 6px; font-size: 13px; }
.note { font-size: 12px; color: var(--text-3); }
.note.warn { color: var(--warning, #b45309); }
.num { width: 150px; }
.mrow { display: flex; gap: 8px; width: 100%; }
.mt { flex: 1; }
.mr { width: 130px; flex: none; }
.rm { width: 100%; }
</style>
