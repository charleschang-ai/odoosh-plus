<template>
  <el-card shadow="never">
    <template #header>
      <div style="display: flex; align-items: center; justify-content: space-between">
        <span>平台维护 <span class="muted" style="font-size: 12px; font-weight: 400">— 重启 / 更新 OdooshCN 自身</span></span>
        <el-tag v-if="st.running" type="warning" size="small"><el-icon class="is-loading"><Loading /></el-icon> 更新中</el-tag>
      </div>
    </template>
    <div class="row">
      <el-radio-group v-model="mode" :disabled="st.running">
        <el-radio-button value="restart">仅重启</el-radio-button>
        <el-radio-button value="rebuild">重新构建并重启</el-radio-button>
        <el-radio-button value="pull">拉取最新代码并构建</el-radio-button>
      </el-radio-group>
      <el-button type="primary" :loading="starting" :disabled="st.running || !st.src_dir" @click="run">执行</el-button>
      <el-button :icon="Refresh" @click="poll">刷新</el-button>
    </div>
    <div class="muted hint">{{ modes[mode] }}<span v-if="st.src_dir"> · 源码目录 <code>{{ st.src_dir }}</code></span></div>
    <el-alert v-if="!st.src_dir" type="warning" :closable="false" show-icon style="margin-top: 8px"
      title="未配置源码目录 ODOOSH_SRC_DIR(deploy/.env),无法自更新;新版 install.sh 会自动写入" />
    <el-alert v-if="waiting" type="info" :closable="false" show-icon style="margin-top: 8px" :title="`平台正在重启,等待服务恢复…(${waitSec}s)`" />
    <el-alert v-else-if="st.exists && !st.running && st.exit_code === 0" type="success" :closable="false" show-icon style="margin-top: 8px" title="上次更新已完成" />
    <el-alert v-else-if="st.exists && !st.running && st.exit_code" type="error" :closable="false" show-icon style="margin-top: 8px" :title="`上次更新失败(退出码 ${st.exit_code}),见下方日志`" />
    <pre v-if="st.log" class="log">{{ st.log }}</pre>
    <div class="muted hint">说明:平台会起一个临时的「更新助手」容器(docker CLI)去执行 git pull / docker compose 构建与重启,api 与控制台会短暂不可用(约 30 秒~3 分钟);实例不受影响。</div>
  </el-card>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox, ElNotification } from 'element-plus'
import { Refresh, Loading } from '@element-plus/icons-vue'
import api from '../api'
import { usePolling } from '../composables/usePolling'

const mode = ref('rebuild')
const modes = { restart: '仅重启平台服务(api / web),不改代码', rebuild: '按当前源码重新构建镜像并重启(应用本地代码改动)', pull: '先 git pull 拉取仓库最新代码,再重新构建并重启' }
const st = reactive({ exists: false, running: false, exit_code: null, log: '', src_dir: '', api_started_at: 0 })
const starting = ref(false); const waiting = ref(false); const waitSec = ref(0)
let baseStart = 0

let logTs = 0
async function poll() {
  try {
    // 首次取尾部 200 行,之后只取增量(since)累加,避免每次轮询全量传日志
    const r = await api.get('/system/platform/update', { params: logTs ? { since: logTs } : {}, silent: true })
    const prevLog = st.log
    Object.assign(st, r)
    if (logTs && r.exists) st.log = (prevLog || '') + (r.log || '')
    if (!r.exists) logTs = 0
    else if (r.log_ts) logTs = r.log_ts
    if (!baseStart) baseStart = st.api_started_at
  } catch { /* api 可能正在重启 */ }
}
// 更新进行中:每 4s 刷状态(等待恢复期间由 waiter 负责)
const statusPoll = usePolling(poll, { interval: 4000, immediate: false, when: () => !waiting.value && st.running })
async function run() {
  try {
    await ElMessageBox.confirm(`${modes[mode.value]}。控制台会短暂不可用,继续?`, '重启 / 更新平台', { type: 'warning', confirmButtonText: '执行' })
  } catch { return }
  starting.value = true
  try {
    await api.post('/system/platform/update', { mode: mode.value })
    ElMessage.success('更新助手已启动')
    logTs = 0; st.log = ''
    baseStart = st.api_started_at
    waiting.value = true; waitSec.value = 0
    waitBack()
  } catch {} finally { starting.value = false }
}
// 等待平台恢复:每 3s 探测 /health,started_at 变化即视为已重启;最多等 15 分钟
let t0 = 0
const waiter = usePolling(async () => {
  waitSec.value = Math.round((Date.now() - t0) / 1000)
  try {
    const h = await api.get('/health', { silent: true, timeout: 5000 })
    if (h?.started_at && h.started_at !== baseStart) {
      waiting.value = false; waiter.stop()
      await poll()
      if (mode.value === 'restart') { ElNotification.success({ title: '平台已恢复', message: '服务已重启', duration: 6000 }); return }
      // 更新代码:前端也可能重建了 → 3 秒后整页 reload 拿新版本(不再要求用户 Ctrl+F5)
      ElNotification.success({ title: '平台已恢复', message: '新代码已生效,3 秒后自动刷新页面', duration: 3000 })
      setTimeout(() => location.reload(), 3000)
      return
    }
  } catch {}
  await poll()
  if (Date.now() - t0 >= 15 * 60 * 1000) { waiting.value = false; waiter.stop(); ElNotification.error({ title: '等待超时', message: '请查看日志或手动检查容器状态' }) }
}, { interval: 3000, immediate: true, pauseWhenHidden: false })
function waitBack() { t0 = Date.now(); waiter.restart() }
onMounted(() => { poll(); statusPoll.start() })
</script>

<style scoped>
.row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.hint { font-size: 12px; margin-top: 8px; }
.log { white-space: pre-wrap; word-break: break-all; max-height: 40vh; overflow: auto; margin: 10px 0 0; }
</style>
