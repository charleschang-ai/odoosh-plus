<template>
  <!--
    仓库 + 分支选择器(供「新建/编辑环境」使用)。
    用法:
      <RepoBranchPicker :tenant-id="form.tenant_id" v-model:repo-url="form.repo_url" v-model:branch="form.branch" />
    列出该组织已在「Git 仓库」页接入的仓库;选中后自动拉取分支列表(可搜索、可新建分支)。
    保留「手动输入」开关,兼容未接入的仓库地址。
  -->
  <div class="rbp">
    <div class="rbp-row">
      <el-select
        v-if="!manual"
        :model-value="repoUrl"
        filterable
        clearable
        :loading="loadingRepos"
        placeholder="选择已接入的仓库"
        style="flex: 1"
        @update:model-value="onRepo"
      >
        <el-option v-for="r in repos" :key="r.id" :label="`${r.name}  (${r.owner}/${r.repo})`" :value="r.url">
          <span>{{ r.name }}</span><span class="muted" style="margin-left: 8px; font-size: 12px">{{ r.owner }}/{{ r.repo }} · {{ providerLabel(r.provider) }}</span>
        </el-option>
        <template #empty>
          <div class="rbp-empty">该组织还没有接入仓库,<router-link to="/repos">去「Git 仓库」页接入</router-link></div>
        </template>
      </el-select>
      <el-input v-else :model-value="repoUrl" placeholder="https://gitee.com/owner/repo.git" style="flex: 1" @update:model-value="$emit('update:repoUrl', $event)" />
      <el-checkbox v-model="manual" style="margin-left: 8px">手动输入</el-checkbox>
    </div>
    <div class="rbp-row" style="margin-top: 8px">
      <el-select
        v-if="!manual && current"
        :model-value="branch"
        filterable
        allow-create
        default-first-option
        clearable
        :loading="loadingBranches"
        placeholder="选择分支(可直接输入新名字)"
        style="flex: 1"
        @update:model-value="$emit('update:branch', $event)"
      >
        <el-option v-for="b in branches" :key="b.name" :label="b.name" :value="b.name">
          <span>{{ b.name }}</span>
          <el-tag v-if="b.is_default" size="small" effect="plain" style="margin-left: 6px">默认</el-tag>
          <el-tag v-if="b.environments?.length" size="small" type="warning" effect="plain" style="margin-left: 6px">已有环境 {{ b.environments.map((e) => e.name).join('/') }}</el-tag>
          <span class="muted" style="float: right; font-size: 12px">{{ (b.sha || '').slice(0, 7) }} {{ b.message || '' }}</span>
        </el-option>
      </el-select>
      <el-input v-else :model-value="branch" placeholder="分支,如 main" style="flex: 1" @update:model-value="$emit('update:branch', $event)" />
      <el-button v-if="!manual && current && canWrite(current)" style="margin-left: 8px" :loading="creating" @click="createBranch">新建分支</el-button>
      <el-button v-if="!manual && current" style="margin-left: 8px" :icon="Refresh" :loading="loadingBranches" @click="loadBranches(true)" />
    </div>
    <div v-if="!manual && branch && !branches.some((b) => b.name === branch) && branches.length" class="hint">
      远端暂无分支「{{ branch }}」,点「新建分支」可基于默认分支创建。
    </div>
    <div v-if="boundEnvs.length" class="hint" style="color: var(--warn)">
      分支「{{ branch }}」已绑定环境 {{ boundEnvs.map((e) => e.name).join('、') }};一个分支只对应一个环境,保存会被拒绝。
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import api from '../api'
import { providerLabel } from '../utils/labels'

const props = defineProps({
  tenantId: { type: Number, default: null },
  repoUrl: { type: String, default: '' },
  branch: { type: String, default: '' },
  excludeEnvId: { type: Number, default: null }, // 编辑时排除自身
})
// update:hasRepos:该组织是否有已接入仓库(父组件据此决定是否显示本控件)
const emit = defineEmits(['update:repoUrl', 'update:branch', 'update:hasRepos'])

const repos = ref([]); const branches = ref([])
const loadingRepos = ref(false); const loadingBranches = ref(false); const creating = ref(false)
const manual = ref(false)

// 新建远端分支:仓库有写凭据 + 当前用户在该组织是开发者及以上
const canWrite = (r) => !!r.can_manage && ['github', 'gitee'].includes(r.provider) && (r.account_login || r.has_token)
const norm = (u) => (u || '').trim().toLowerCase().replace(/\.git$/, '').replace(/\/$/, '').replace(/^git@([^:]+):/, '$1/').replace(/^https?:\/\//, '')
const current = computed(() => repos.value.find((r) => norm(r.url) === norm(props.repoUrl)) || null)
const boundEnvs = computed(() => (!manual.value && props.branch && (branches.value.find((b) => b.name === props.branch)?.environments || []).filter((e) => e.id !== props.excludeEnvId)) || [])

async function loadRepos() {
  if (!props.tenantId) { repos.value = []; emit('update:hasRepos', false); return }
  loadingRepos.value = true
  // 企业版仓库与平台共享仓库不是业务代码,不参与实例代码选择
  try { repos.value = (await api.get('/repos', { params: { tenant_id: props.tenantId } })).filter((r) => !r.is_enterprise && r.scope !== 'platform') } catch { repos.value = [] } finally { loadingRepos.value = false }
  emit('update:hasRepos', repos.value.length > 0)
  // 已有地址但不在接入列表里 → 切到手动模式
  if (props.repoUrl && !current.value) manual.value = true
}
async function loadBranches(sync = false) {
  if (!current.value) { branches.value = []; return }
  loadingBranches.value = true
  try {
    const data = sync ? await api.post(`/repos/${current.value.id}/sync`) : await api.get(`/repos/${current.value.id}/branches`)
    branches.value = data.branches
    if (!props.branch && data.default_branch) emit('update:branch', data.default_branch)
  } catch { branches.value = [] } finally { loadingBranches.value = false }
}
function onRepo(url) {
  emit('update:repoUrl', url || '')
  emit('update:branch', '')
  branches.value = []
}
async function createBranch() {
  const from = branches.value.find((b) => b.is_default)?.name || branches.value[0]?.name || ''
  try {
    const { value } = await ElMessageBox.prompt(`基于「${from}」新建分支`, '新建分支', { inputValue: props.branch && !branches.value.some((b) => b.name === props.branch) ? props.branch : '', inputPattern: /^[A-Za-z0-9][A-Za-z0-9._/-]*$/, inputErrorMessage: '分支名不合法' })
    creating.value = true
    const data = await api.post(`/repos/${current.value.id}/branches`, { name: value, from_branch: from })
    branches.value = data.branches
    emit('update:branch', value)
    ElMessage.success(`分支 ${value} 已创建`)
  } catch {} finally { creating.value = false }
}

watch(() => props.tenantId, loadRepos)
watch(current, (c, old) => { if (c && c.id !== old?.id) loadBranches() }, { immediate: true })
onMounted(loadRepos)
</script>

<style scoped>
.rbp { width: 100%; }
.rbp-row { display: flex; align-items: center; width: 100%; }
.rbp-empty { padding: 12px; color: var(--text-3); font-size: 13px; text-align: center; }
.hint { font-size: 12px; color: var(--text-3); margin-top: 4px; }
</style>
