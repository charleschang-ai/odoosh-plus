<template>
  <!-- 远程备份目标(用户自有):S3 兼容 / SFTP / WebDAV。每个用户只看到自己创建的;超管看全部。 -->
  <el-card shadow="never" class="targets-card">
    <template #header>
      <div class="hd">
        <span class="title"><el-icon><Connection /></el-icon> 远程备份目标
          <HelpTip text="把备份推送到你自己的服务器 / NAS / 对象存储。在这里添加目标,再到各实例的「备份设置」里勾选要推送到哪些目标;没勾选的实例只留在本地。目标只有你自己(和平台管理员)可见。" />
        </span>
        <span class="muted small" v-if="rows.length">{{ rows.length }} 个</span>
        <span class="spacer" />
        <el-select v-if="isSuper && tenants.length > 1" v-model="filterTenant" placeholder="全部组织" clearable size="small" style="width: 140px" @change="load">
          <el-option v-for="t in tenants" :key="t.id" :label="t.name" :value="t.id" />
        </el-select>
        <el-button size="small" :icon="Refresh" circle @click="load" />
        <el-button size="small" type="primary" :icon="Plus" @click="openCreate">添加目标</el-button>
      </div>
    </template>
    <div v-loading="loading">
      <EmptyState v-if="!loading && !rows.length" variant="backups" title="还没有远程备份目标" desc="添加自己的 S3 / SFTP / WebDAV 目标后,可在实例备份设置里选择推送">
        <el-button type="primary" :icon="Plus" @click="openCreate">添加目标</el-button>
      </EmptyState>
      <div v-else class="tlist">
        <div v-for="t in rows" :key="t.id" class="titem" :class="{ off: !t.enabled }">
          <span class="kind" :class="`k-${t.kind}`">{{ kindShort(t.kind) }}</span>
          <div class="info">
            <div class="n"><b>{{ t.name }}</b>
              <el-tag v-if="!t.enabled" size="small" type="info" effect="plain">已停用</el-tag>
              <el-tag v-else-if="t.last_test_ok === true" size="small" type="success" effect="plain">连接正常</el-tag>
              <el-tag v-else-if="t.last_test_ok === false" size="small" type="danger" effect="plain" :title="t.last_error || ''">连接失败</el-tag>
              <el-tag v-else size="small" type="warning" effect="plain">未测试</el-tag>
              <el-tag v-if="t.last_error && t.last_test_ok !== false" size="small" type="danger" effect="plain" :title="t.last_error">最近推送失败</el-tag>
            </div>
            <div class="muted small ell" :title="t.describe">{{ t.describe }}<span v-if="t.prefix"> · 目录 {{ t.prefix }}</span></div>
            <div class="muted tiny">{{ t.keep_days ? `远端保留 ${t.keep_days} 天` : '远端永久保留' }} · {{ t.delete_with_local ? '本地删除时同步删远端' : '本地删除不影响远端' }} · 被 {{ t.in_use }} 个实例使用<span v-if="isSuper && t.owner_name"> · {{ t.owner_name }} / {{ tenantName(t.tenant_id) }}</span></div>
          </div>
          <div class="ops">
            <el-button link size="small" :loading="testing === t.id" @click="test(t)">测试连接</el-button>
            <el-button link size="small" @click="openEdit(t)">编辑</el-button>
            <el-button link size="small" type="danger" @click="remove(t)">删除</el-button>
          </div>
        </div>
      </div>
    </div>

    <!-- 新建 / 编辑 -->
    <el-dialog v-model="dlg" :title="form.id ? `编辑目标 — ${form.name}` : '添加远程备份目标'" width="600px" :close-on-click-modal="false">
      <el-form :model="form" label-width="104px" @submit.prevent>
        <el-form-item v-if="!form.id && isSuper" label="所属组织" required>
          <el-select v-model="form.tenant_id" style="width: 260px"><el-option v-for="t in tenants" :key="t.id" :label="t.name" :value="t.id" /></el-select>
        </el-form-item>
        <el-form-item label="名称" required><el-input v-model="form.name" maxlength="64" placeholder="如:组织 NAS / 阿里云 OSS" style="width: 260px" /></el-form-item>
        <el-form-item label="类型" required>
          <el-radio-group v-model="form.kind" :disabled="!!form.id">
            <el-radio-button value="sftp">SFTP(SSH)</el-radio-button>
            <el-radio-button value="webdav">WebDAV</el-radio-button>
            <el-radio-button value="s3">S3 兼容</el-radio-button>
          </el-radio-group>
          <div class="muted tiny" style="width: 100%; margin-top: 4px">{{ kindHint(form.kind) }}</div>
        </el-form-item>

        <template v-if="form.kind === 'sftp'">
          <el-form-item label="主机" required>
            <el-input v-model="form.config.host" placeholder="nas.example.com 或 192.168.1.10" style="width: 260px" />
            <span class="muted small" style="margin: 0 6px">端口</span><el-input-number v-model="form.config.port" :min="1" :max="65535" controls-position="right" style="width: 110px" />
          </el-form-item>
          <el-form-item label="用户名" required><el-input v-model="form.config.username" style="width: 260px" /></el-form-item>
          <el-form-item label="密码"><el-input v-model="form.config.password" show-password :placeholder="form.id ? '留空 = 不修改' : '密码或私钥二选一'" style="width: 260px" /></el-form-item>
          <el-form-item label="私钥(可选)"><el-input v-model="form.config.private_key" type="textarea" :rows="3" :placeholder="form.id ? '留空 = 不修改' : '-----BEGIN OPENSSH PRIVATE KEY----- …(有私钥时上面的密码作为私钥口令)'" /></el-form-item>
          <el-form-item label="远端目录"><el-input v-model="form.config.base_path" placeholder="如 /volume1/backups 或 backups(相对登录目录);留空 = 登录目录" style="width: 360px" /></el-form-item>
        </template>
        <template v-else-if="form.kind === 'webdav'">
          <el-form-item label="地址" required><el-input v-model="form.config.url" placeholder="https://nas.example.com:5006/backups/  或  https://dav.jianguoyun.com/dav/" /></el-form-item>
          <el-form-item label="用户名"><el-input v-model="form.config.username" style="width: 260px" /></el-form-item>
          <el-form-item label="密码"><el-input v-model="form.config.password" show-password :placeholder="form.id ? '留空 = 不修改' : ''" style="width: 260px" /></el-form-item>
          <el-form-item label="忽略证书错误"><el-switch v-model="form.config.insecure" /><span class="hint">自签名 https 的 NAS 勾选</span></el-form-item>
        </template>
        <template v-else>
          <el-form-item label="Endpoint"><el-input v-model="form.config.endpoint" placeholder="https://oss-cn-hangzhou.aliyuncs.com / http://192.168.1.10:9000;AWS 可留空" /></el-form-item>
          <el-form-item label="Bucket" required><el-input v-model="form.config.bucket" style="width: 260px" /><span class="muted small" style="margin: 0 6px">Region</span><el-input v-model="form.config.region" placeholder="可留空" style="width: 140px" /></el-form-item>
          <el-form-item label="Access Key" required><el-input v-model="form.config.access_key" style="width: 260px" /></el-form-item>
          <el-form-item label="Secret Key" :required="!form.id"><el-input v-model="form.config.secret_key" show-password :placeholder="form.id ? '留空 = 不修改' : ''" style="width: 260px" /></el-form-item>
          <el-form-item label="Path-style"><el-switch v-model="form.config.path_style" /><span class="hint">MinIO / 自建对象存储通常需要开启;云厂商 OSS / COS 关闭</span></el-form-item>
        </template>

        <el-divider style="margin: 6px 0 14px" />
        <el-form-item label="子目录 / 前缀"><el-input v-model="form.prefix" placeholder="如 odoosh;备份将放在 <前缀>/<组织>/<实例>/<库名>/ 下" style="width: 360px" /></el-form-item>
        <el-form-item label="远端保留"><el-input-number v-model="form.keep_days" :min="0" :max="3650" controls-position="right" style="width: 120px" /><span class="hint">天;0 = 永久保留。只清理由本平台推送的文件</span></el-form-item>
        <el-form-item label="同步删除"><el-switch v-model="form.delete_with_local" /><span class="hint">本地备份被删除(过期 / 手动)时,远端副本一并删除;默认不删,远端作为冷备</span></el-form-item>
        <el-form-item label="启用"><el-switch v-model="form.enabled" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button :loading="testing === 'form'" @click="testForm">测试连接</el-button>
        <span class="spacer" />
        <el-button @click="dlg = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </el-card>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Connection, Plus, Refresh } from '@element-plus/icons-vue'
import api from '../api'
import { isSuper, tenants, loadTenants, tenantName, currentTenant } from '../store'
import { confirmDanger } from '../utils/confirm'
import EmptyState from './EmptyState.vue'
import HelpTip from './HelpTip.vue'

const emit = defineEmits(['changed'])
const rows = ref([]); const loading = ref(false); const saving = ref(false); const testing = ref(null)
const filterTenant = ref(null)

const kindShort = (k) => ({ s3: 'S3', sftp: 'SFTP', webdav: 'DAV' }[k] || k)
const kindHint = (k) => ({
  sftp: '任何能 SSH 登录的 Linux 服务器 / 群晖 / 威联通 NAS(需开启 SFTP 服务)。最通用。',
  webdav: '群晖 / 威联通自带 WebDAV Server、坚果云、Nextcloud、Alist 等。地址填到目标目录。',
  s3: '阿里云 OSS / 腾讯云 COS / 七牛 / MinIO / AWS S3 等 S3 兼容对象存储。',
}[k] || '')

async function load() {
  loading.value = true
  try { rows.value = await api.get('/backup-targets', { params: filterTenant.value ? { tenant_id: filterTenant.value } : {}, silent: true }) } catch {} finally { loading.value = false }
}
onMounted(async () => { if (isSuper.value) await loadTenants(); load() })

// ---- 表单 ----
const dlg = ref(false)
const BLANK = () => ({ id: null, tenant_id: isSuper.value ? (tenants.value[0]?.id || null) : (currentTenant.value?.tenant_id || null), name: '', kind: 'sftp', config: { port: 22 }, prefix: 'odoosh', keep_days: 0, delete_with_local: false, enabled: true })
const form = reactive(BLANK())
function openCreate() { Object.assign(form, BLANK()); form.config = { port: 22, path_style: true, insecure: false }; dlg.value = true }
function openEdit(t) { Object.assign(form, { id: t.id, tenant_id: t.tenant_id, name: t.name, kind: t.kind, prefix: t.prefix || '', keep_days: t.keep_days, delete_with_local: t.delete_with_local, enabled: t.enabled }); form.config = { ...(t.config || {}) }; for (const k of ['password', 'secret_key', 'private_key']) if (form.config[k] === '******') form.config[k] = ''; dlg.value = true }
function payload() {
  const c = { ...form.config }
  return { tenant_id: form.tenant_id, name: form.name, kind: form.kind, config: c, prefix: form.prefix, keep_days: form.keep_days, delete_with_local: form.delete_with_local, enabled: form.enabled }
}
async function save() {
  if (!form.name.trim()) return ElMessage.warning('请填写名称')
  saving.value = true
  try {
    if (form.id) await api.put(`/backup-targets/${form.id}`, payload())
    else await api.post('/backup-targets', payload())
    ElMessage.success('已保存'); dlg.value = false; load(); emit('changed')
  } catch {} finally { saving.value = false }
}
function showTest(r) { if (r.ok) ElMessage.success(`连接正常(${r.ms} ms)`); else ElMessage.error({ message: `连接失败:${r.error}`, duration: 8000, showClose: true }) }
async function test(t) { testing.value = t.id; try { showTest(await api.post(`/backup-targets/${t.id}/test`)); load() } catch {} finally { testing.value = null } }
async function testForm() {
  testing.value = 'form'
  try { showTest(await api.post(form.id ? `/backup-targets/${form.id}/test` : '/backup-targets/test', payload())) } catch {} finally { testing.value = null }
}
async function remove(t) {
  if (!(await confirmDanger({ title: '删除备份目标', message: `删除目标「${t.name}」?只删除平台里的配置,远端已推送的备份文件不会被删除。${t.in_use ? `当前有 ${t.in_use} 个实例在使用它,删除后这些实例将不再推送到该目标。` : ''}` }))) return
  try { await api.delete(`/backup-targets/${t.id}`, { params: { force: true } }); ElMessage.success('已删除'); load(); emit('changed') } catch {}
}
defineExpose({ load })
</script>

<style scoped>
.targets-card { margin-bottom: 12px; }
.hd { display: flex; align-items: center; gap: 8px; }
.title { display: inline-flex; align-items: center; gap: 6px; font-weight: 600; }
.spacer { flex: 1; }
.small { font-size: 12px; }
.tiny { font-size: 11.5px; }
.ell { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.hint { margin-left: 8px; font-size: 12px; color: var(--text-3); }
.tlist { display: grid; grid-template-columns: repeat(auto-fill, minmax(360px, 1fr)); gap: 10px; }
.titem { display: flex; align-items: flex-start; gap: 10px; padding: 10px 12px; border: 1px solid var(--border, #e5e7eb); border-radius: 8px; min-width: 0; }
.titem.off { opacity: 0.6; }
.titem .info { flex: 1; min-width: 0; }
.titem .n { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.titem .ops { display: flex; gap: 2px; white-space: nowrap; }
.kind { flex: none; width: 44px; height: 28px; line-height: 28px; text-align: center; border-radius: 6px; font-size: 11px; font-weight: 700; color: #fff; margin-top: 2px; }
.k-s3 { background: #f59e0b; } .k-sftp { background: #3b82f6; } .k-webdav { background: #10b981; }
</style>
