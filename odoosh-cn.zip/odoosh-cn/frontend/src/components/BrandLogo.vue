<template>
  <!-- 圆形品牌 Logo:渐变圆盘 + 环形轨道 + 神经元节点连线,内联 SVG,任意尺寸清晰 -->
  <svg :width="size" :height="size" viewBox="0 0 64 64" class="brand-logo" aria-hidden="true">
    <defs>
      <linearGradient :id="`${uid}-bg`" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#7c3aed" />
        <stop offset="55%" stop-color="#a24689" />
        <stop offset="100%" stop-color="#2563eb" />
      </linearGradient>
      <radialGradient :id="`${uid}-glow`" cx="30%" cy="25%" r="75%">
        <stop offset="0%" stop-color="#fff" stop-opacity=".35" />
        <stop offset="60%" stop-color="#fff" stop-opacity="0" />
      </radialGradient>
      <linearGradient :id="`${uid}-ring`" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#fff" stop-opacity=".9" />
        <stop offset="100%" stop-color="#fff" stop-opacity=".15" />
      </linearGradient>
    </defs>
    <!-- 圆盘 -->
    <circle cx="32" cy="32" r="31" :fill="`url(#${uid}-bg)`" />
    <circle cx="32" cy="32" r="31" :fill="`url(#${uid}-glow)`" />
    <!-- 轨道环(带缺口,像在旋转) -->
    <circle cx="32" cy="32" r="22.5" fill="none" :stroke="`url(#${uid}-ring)`" stroke-width="2" stroke-linecap="round" stroke-dasharray="96 46" transform="rotate(-60 32 32)" class="orbit" />
    <!-- 神经元连线 -->
    <g stroke="#fff" stroke-opacity=".85" stroke-width="1.8" stroke-linecap="round" fill="none">
      <path d="M22 38 L32 24 L42 38" />
      <path d="M22 38 L42 38" stroke-opacity=".5" />
      <path d="M32 24 L32 12" stroke-opacity=".6" />
    </g>
    <!-- 节点 -->
    <circle cx="32" cy="24" r="4.2" fill="#fff" />
    <circle cx="22" cy="38" r="3.2" fill="#fff" fill-opacity=".95" />
    <circle cx="42" cy="38" r="3.2" fill="#fff" fill-opacity=".95" />
    <circle cx="32" cy="12" r="2.2" fill="#fff" fill-opacity=".8" class="spark" />
    <!-- 中心高光 -->
    <circle cx="32" cy="24" r="1.6" fill="#a24689" />
  </svg>
</template>

<script setup>
defineProps({ size: { type: [Number, String], default: 32 } })
// 多个实例同页时 gradient id 需唯一
const uid = 'bl' + Math.random().toString(36).slice(2, 7)
</script>

<style scoped>
.brand-logo { display: block; flex: none; border-radius: 50%; box-shadow: 0 2px 10px -2px rgba(124, 58, 237, .55); }
.orbit { transform-origin: 32px 32px; animation: spin 14s linear infinite; }
.spark { animation: blink 2.6s ease-in-out infinite; }
@keyframes spin { from { transform: rotate(-60deg); } to { transform: rotate(300deg); } }
@keyframes blink { 0%, 100% { opacity: .35; } 50% { opacity: 1; } }
@media (prefers-reduced-motion: reduce) { .orbit, .spark { animation: none; } }
</style>
