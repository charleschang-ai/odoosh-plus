<template>
  <!-- Shell:xterm.js ⇄ WebSocket ⇄ docker exec(容器内 odoo 用户 bash);快捷命令仿 odoo.sh -->
  <div class="shell">
    <div class="bar">
      <template v-if="dbs.length > 1">
        <span class="muted small">数据库:</span>
        <el-select v-model="dbSel" size="small" style="width: 180px" :disabled="state === 'open' || state === 'connecting'" title="会话内 odoo shell / psql / odoo-update 作用的库;切换后需重新连接">
          <el-option v-for="d in dbs" :key="d.id ?? 0" :value="d.id ?? 0" :label="d.is_primary ? `主库(${d.db_name})` : `${d.name}(${d.db_name})`" />
        </el-select>
      </template>
      <span class="quick-label muted small">快捷命令:</span>
      <el-button v-for="q in QUICK" :key="q.cmd" size="small" :disabled="!connected" :title="q.tip" @click="send(q.cmd + '\n')">{{ q.label }}</el-button>
      <span class="spacer" />
      <span class="st" :class="state">{{ { idle: '未连接', connecting: '连接中…', open: '已连接', closed: '已断开' }[state] }}</span>
      <el-button v-if="state !== 'open'" size="small" type="primary" :loading="state === 'connecting'" :disabled="env.status !== 'running'" @click="connect">{{ state === 'closed' ? '重新连接' : '连接' }}</el-button>
      <el-button v-else size="small" @click="disconnect">断开</el-button>
      <el-button size="small" :icon="Delete" title="清屏" @click="term?.clear()" />
    </div>
    <div v-if="env.status !== 'running'" class="muted small" style="margin-bottom: 8px">实例未在运行,启动后才能打开 Shell。</div>
    <div ref="box" class="term" />
    <div class="muted small tips">
      以容器内 <code>odoo</code> 用户运行;容器是一次性的,除 <code>/var/lib/odoo</code>(filestore)与数据库外的改动在部署/重启后丢失。依赖写进仓库或定制代码目录(根或模块内)的 <code>requirements.txt</code>,部署 / 重启时自动安装(国内镜像);
      仓库代码目录 <code>/mnt/extra-addons</code> 请通过 git push 更新;<code>/mnt/custom-addons</code> 是本实例的「定制代码」目录(可写、持久、已在 addons_path 内),AI 编程 / 临时改代码请写这里,写好的模块在「定制代码」Tab 里可查看、编辑、下载。{{ env.kind === 'production' ? '生产环境 Shell 会记录键盘输入用于审计。' : '' }}
    </div>
  </div>
</template>

<script setup>
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { Delete } from '@element-plus/icons-vue'
import { Terminal } from '@xterm/xterm'
import { FitAddon } from '@xterm/addon-fit'
import '@xterm/xterm/css/xterm.css'
import api from '../../api'

const props = defineProps({ env: Object, databaseId: { type: Number, default: null } })
const emit = defineEmits(['update:databaseId'])
// 多库:会话绑定一个库(主库 = 0);切库需断开重连
const dbs = ref([]); const dbSel = ref(props.databaseId || 0)
async function loadDbs() {
  try { const r = await api.get(`/environments/${props.env.id}/databases`, { silent: true }); dbs.value = (r.items || []).filter((d) => d.status === 'ready') } catch { dbs.value = [] }
}
watch(() => props.databaseId, (v) => { if ((v || 0) !== dbSel.value) { dbSel.value = v || 0; if (state.value === 'open') { disconnect(); term?.writeln('\r\n\x1b[2m[已切换目标数据库,请重新连接]\x1b[0m') } } })
watch(dbSel, (v) => emit('update:databaseId', v || null))
const QUICK = [
  { label: 'odoo-bin shell', cmd: 'odoo-bin shell', tip: '打开 Odoo 交互式 shell(ORM)' },
  { label: 'odoo-update', cmd: 'odoo-update all', tip: '升级全部模块;odoo-update 模块名 升级指定模块' },
  { label: 'psql', cmd: 'psql', tip: '进入本实例数据库' },
  { label: 'odoosh-storage', cmd: 'odoosh-storage', tip: '存储占用' },
  { label: 'odoosh-restart', cmd: 'odoosh-restart', tip: '重启 Odoo(容器重建,需重新连接)' },
  { label: 'help', cmd: 'odoosh-help', tip: '命令菜单' },
]
const box = ref(null); const state = ref('idle'); const connected = ref(false)
let term = null; let fit = null; let ws = null; let ro = null

function initTerm() {
  term = new Terminal({ fontSize: 13, fontFamily: 'ui-monospace, Menlo, Consolas, "Courier New", monospace', cursorBlink: true, convertEol: false, scrollback: 5000,
    theme: { background: '#0f172a', foreground: '#e2e8f0', cursor: '#a78bfa', selectionBackground: '#334155', black: '#1e293b', brightBlack: '#64748b', red: '#f87171', green: '#4ade80', yellow: '#fbbf24', blue: '#60a5fa', magenta: '#c084fc', cyan: '#22d3ee', white: '#e2e8f0' } })
  fit = new FitAddon(); term.loadAddon(fit); term.open(box.value); fit.fit()
  term.onData((d) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: 'i', d })) })
  term.onResize(({ cols, rows }) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: 'r', cols, rows })) })
  ro = new ResizeObserver(() => { try { fit.fit() } catch {} }); ro.observe(box.value)
  term.writeln('\x1b[2m点击「连接」打开实例 Shell。\x1b[0m')
}
async function connect() {
  if (state.value === 'open' || state.value === 'connecting') return
  state.value = 'connecting'
  let ticket
  try { ticket = (await api.post(`/environments/${props.env.id}/shell-ticket`, null, { params: dbSel.value ? { database_id: dbSel.value } : {} })).ticket } catch { state.value = 'idle'; return }
  const proto = location.protocol === 'https:' ? 'wss' : 'ws'
  const { cols, rows } = term
  ws = new WebSocket(`${proto}://${location.host}/api/environments/${props.env.id}/shell?t=${encodeURIComponent(ticket)}&cols=${cols}&rows=${rows}`)
  ws.binaryType = 'arraybuffer'
  ws.onopen = () => { state.value = 'open'; connected.value = true; term.focus(); try { fit.fit() } catch {} }
  ws.onmessage = (ev) => { term.write(typeof ev.data === 'string' ? ev.data : new Uint8Array(ev.data)) }
  ws.onclose = (ev) => { state.value = 'closed'; connected.value = false; term.writeln(`\r\n\x1b[2m[连接已关闭${ev.reason ? ':' + ev.reason : ''}]\x1b[0m`) }
  ws.onerror = () => { ElMessage.error('Shell 连接失败'); }
}
function disconnect() { try { ws?.close() } catch {} ws = null }
function send(text) { if (ws && ws.readyState === 1) { ws.send(JSON.stringify({ t: 'i', d: text })); term.focus() } }
watch(() => props.env?.id, () => { disconnect(); term?.clear(); state.value = 'idle'; loadDbs() })
onMounted(() => { initTerm(); loadDbs() })
onBeforeUnmount(() => { disconnect(); ro?.disconnect(); term?.dispose() })
</script>

<style scoped>
.bar { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; flex-wrap: wrap; }
.spacer { flex: 1; }
.small { font-size: 12px; }
.st { font-size: 12px; font-weight: 600; padding: 2px 9px; border-radius: 999px; background: #f1f5f9; color: #475569; }
.st.open { background: #ecfdf5; color: #047857; } .st.connecting { background: #fffbeb; color: #b45309; } .st.closed { background: #fef2f2; color: #b91c1c; }
.term { height: 62vh; background: #0f172a; border-radius: 10px; padding: 8px 4px 8px 10px; overflow: hidden; }
.term :deep(.xterm) { height: 100%; }
.tips { margin-top: 8px; line-height: 1.6; }
.tips code { background: var(--surface-2); padding: 0 4px; border-radius: 4px; }
</style>
