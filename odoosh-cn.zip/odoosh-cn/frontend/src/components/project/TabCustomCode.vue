<template>
  <!-- 实例的定制代码:文件树 + 在线编辑器,与「上传 zip / 拷进目录 / 实例内 AI 编程写入 /mnt/custom-addons」共用同一个 addons 目录。
       Git 实例上它与只读的仓库检出并存,排在 addons_path 末尾(同名模块以仓库代码优先) -->
  <div class="cc" :class="{ mobile: isMobile }" v-loading="loading">
    <!-- 工具栏:与其它 Tab 一致的 .bar + small 按钮;左边是文件操作,右边是生效操作 -->
    <div class="bar">
      <el-button size="small" type="primary" :icon="Plus" @click="openScaffold">新建模块</el-button>

      <el-dropdown size="small" trigger="click" :disabled="uploading || busy" @command="pickUpload">
        <el-button size="small" :icon="UploadFilled">上传<el-icon class="el-icon--right"><ArrowDown /></el-icon></el-button>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item command="zip:replace">代码包 zip —— 同名模块<b>整个替换</b>(默认)</el-dropdown-item>
            <el-dropdown-item command="zip:merge">代码包 zip —— 同名模块<b>只覆盖包里有的文件</b></el-dropdown-item>
            <el-dropdown-item command="file" divided :disabled="!currentDir">
              单个文件<span class="muted">(图片 / xlsx)</span> → {{ currentDir || '先在树里选一个目录' }}
            </el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>

      <el-dropdown size="small" trigger="click" :disabled="!modules.length" @command="download">
        <el-button size="small" :icon="Download" :loading="downloading">下载<el-icon class="el-icon--right"><ArrowDown /></el-icon></el-button>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item command="">全部代码</el-dropdown-item>
            <el-dropdown-item v-for="m in modules" :key="m.name" :command="m.name">只下 {{ m.name }}</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>

      <el-button size="small" :icon="Refresh" title="刷新文件树" @click="loadTree()" />
      <el-button size="small" :icon="Clock" title="谁在什么时候改了哪个文件" @click="openAudit"><span class="lbl">改动记录</span></el-button>

      <span class="spacer" />

      <!-- 必须写成 save() —— 写 @click="save" 时 Vue 会把 MouseEvent 当第一个参数传进去,
           那是 force,truthy 就会跳过 mtime 并发校验,静默覆盖别人的改动 -->
      <el-button size="small" type="success" :icon="Select" :disabled="!dirty || saving" :loading="saving" @click="save()">
        保存<span v-if="dirty"> *</span>
      </el-button>
      <el-dropdown size="small" split-button type="warning" trigger="click" :disabled="busy"
                   :title="currentModule ? `对 ${currentModule} 执行 -u` : '先在树里选一个模块里的文件'"
                   @click="updateModules(currentModule)" @command="updateModules">
        升级<span v-if="currentModule" class="lbl mod-lbl">{{ currentModule }}</span>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item v-for="m in modules" :key="m.name" :command="m.name">升级 {{ m.name }}</el-dropdown-item>
            <el-dropdown-item command="all" divided>升级全部模块(-u all,慢)</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
      <el-button size="small" :icon="RefreshRight" :loading="reloading" :disabled="busy" title="重启实例使代码生效" @click="restart">
        重启<span class="lbl">使生效</span>
      </el-button>
    </div>

    <div v-if="uploading" class="prog"><el-progress :percentage="pct" :stroke-width="6" /><span class="muted small">上传中 {{ pickedName }}</span></div>
    <el-alert v-if="lastResult" type="success" :closable="true" class="res" @close="lastResult = null" :title="uploadSummary" />
    <!-- 自动补 __init__.py 这类「平台替你做了什么」必须留在页面上,不能用 3 秒就消失的 toast:
         新建文件时树在刷新、编辑器在切文件,一闪而过的提示学生根本看不到 -->
    <el-alert v-if="notice" type="success" :closable="true" class="res" show-icon @close="notice = null"
              :title="notice.title" :description="notice.desc" />
    <el-alert v-if="truncated" type="warning" :closable="false" class="res"
              title="文件太多,树只显示了前 5000 个节点。请删掉不需要的模块,或用「下载」拿到本地处理。" />

    <!-- 升级 / 重启失败:直接把日志尾部摆在这儿,不用切「日志」Tab -->
    <el-alert v-if="jobErr" type="error" :closable="true" class="res" @close="jobErr = null"
              :title="`上次操作失败:${jobErr.message || '见下方日志'}`">
      <pre class="errlog">{{ jobErr.errors?.length ? jobErr.errors.join('\n') : jobErr.tail }}</pre>
      <el-button link type="primary" size="small" @click="showFullErr = !showFullErr">
        {{ showFullErr ? '收起' : '看完整日志尾部' }}
      </el-button>
      <pre v-if="showFullErr" class="errlog full">{{ jobErr.tail }}</pre>
    </el-alert>

    <div class="editor-wrap">
      <!-- 手机上树是从左滑出的浮层;点击遮罩关闭 -->
      <div v-if="isMobile && treeOpen" class="tree-mask" @click="treeOpen = false" />

      <!-- 左:文件树(手机上 .open 才显示) -->
      <div class="pane-tree" :class="{ open: treeOpen }">
        <div class="tree-head">
          <el-input v-model="filter" size="small" placeholder="过滤文件" clearable :prefix-icon="Search" />
          <el-button v-if="isMobile" size="small" :icon="Close" circle title="收起" @click="treeOpen = false" />
        </div>
        <el-scrollbar class="tree-body">
          <el-tree ref="treeRef" :data="tree" node-key="path" :props="{ label: 'name', children: 'children' }"
                   :filter-node-method="filterNode" :expand-on-click-node="false" highlight-current
                   :default-expanded-keys="expanded" @node-click="onNodeClick" @node-expand="onExpand" @node-collapse="onCollapse">
            <template #default="{ data }">
              <span class="node" :class="{ mod: data.module }">
                <el-icon class="ic"><Folder v-if="data.dir" /><Document v-else /></el-icon>
                <span class="nm" :title="data.path">{{ data.name }}</span>
                <span v-if="!data.dir && !data.editable" class="badge">二进制</span>
                <!-- 桌面 hover 才出现;触屏没有 hover,靠 @media (hover: none) 常显 -->
                <span class="node-acts">
                  <el-icon v-if="data.dir" title="在此新建文件" @click.stop="newEntry(data.path, 'file')"><DocumentAdd /></el-icon>
                  <el-icon v-if="data.dir" title="在此新建目录" @click.stop="newEntry(data.path, 'dir')"><FolderAdd /></el-icon>
                  <el-icon v-if="!data.dir && data.editable" title="历史版本" @click.stop="openHistory(data.path)"><Clock /></el-icon>
                  <el-icon title="重命名" @click.stop="rename(data)"><EditPen /></el-icon>
                  <el-icon title="删除" class="del" @click.stop="remove(data)"><Delete /></el-icon>
                </span>
              </span>
            </template>
          </el-tree>
          <el-empty v-if="!tree.length" :image-size="60"
                    description="还没有代码。点「新建模块」生成骨架,或「上传」代码包" />
        </el-scrollbar>
        <!-- 配额条:学生看得见自己用了多少,不会莫名其妙被拒 -->
        <div v-if="quota.max" class="quota" :title="`${fmtMB(quota.bytes)} / ${fmtMB(quota.max)},${quota.files} 个文件`">
          <el-progress :percentage="quota.pct" :stroke-width="4" :show-text="false"
                       :status="quota.pct >= 90 ? 'exception' : quota.pct >= 70 ? 'warning' : ''" />
          <span class="muted">{{ fmtMB(quota.bytes) }} / {{ fmtMB(quota.max) }} · {{ quota.files }} 个文件</span>
        </div>
        <div v-if="!isMobile" class="tree-foot muted" :title="hostDir">
          服务器目录:<code>{{ hostDir || '…' }}</code>
          <template v-if="mountDir"> · 容器内 <code>{{ mountDir }}</code></template>
          <div v-if="isGit">与仓库 <code>/mnt/extra-addons</code> 同名的模块以仓库代码优先;改好的模块请下载后提交进仓库。</div>
          <div>Python 依赖:在模块里或根目录放 <code>requirements.txt</code>,重启 / 部署 / 升级模块时自动安装(国内镜像)。</div>
        </div>
      </div>

      <!-- 右:编辑器 -->
      <div class="pane-edit">
        <div class="edit-head">
          <el-button v-if="isMobile" size="small" :icon="Files" @click="treeOpen = true">文件</el-button>
          <template v-if="current.path">
            <span class="mono path" :title="current.path">{{ isMobile ? current.path.split('/').pop() : current.path }}</span>
            <span v-if="dirty" class="dirty">未保存</span>
            <el-tag v-if="lintErrors" size="small" type="danger" effect="plain">{{ lintErrors }} 错</el-tag>
            <el-tag v-else-if="lintWarns" size="small" type="warning" effect="plain">{{ lintWarns }} 提示</el-tag>
            <span class="spacer" />
            <el-tag v-if="schemaCount && !isMobile" size="small" type="info" effect="plain"
                    :title="`补全已认识本库 ${schemaCount} 个模型;Ctrl+空格 手动唤出`">补全 {{ schemaCount }} 模型</el-tag>
            <el-tag v-else-if="schemaNote && !isMobile" size="small" type="warning" effect="plain" :title="schemaNote">补全:仅关键字</el-tag>
            <el-button v-if="editable" link size="small" :icon="Clock" @click="openHistory(current.path)"><span class="lbl">历史</span></el-button>
            <span v-if="applyHint && !isMobile" class="hint-inline">{{ applyHint }}</span>
          </template>
          <span v-else class="muted small">{{ isMobile ? '点「文件」选一个打开' : '在左侧点一个文件开始编辑 · Ctrl+S 保存' }}</span>
        </div>
        <div v-show="editable" ref="editorEl" class="mon" />
        <div v-if="lint.length && editable" class="lintbar">
          <div v-for="(x, i) in lint.slice(0, 4)" :key="i" class="lintrow" :class="x.level" @click="gotoLine(x.line)">
            <el-icon><WarningFilled v-if="x.level === 'error'" /><InfoFilled v-else /></el-icon>
            第 {{ x.line }} 行:{{ x.message }}
          </div>
        </div>
        <div v-if="current.path && !editable" class="placeholder">
          <el-empty :image-size="70" :description="current.reason || '该文件无法在线编辑'" />
        </div>
        <div v-if="!current.path" class="placeholder">
          <el-empty :image-size="70" description="未打开文件" />
        </div>
      </div>
    </div>

    <input ref="fileInput" type="file" style="display: none" @change="onPickFile" />
    <input ref="zipInput" type="file" accept=".zip,application/zip" style="display: none" @change="onPickZip" />

    <!-- 新建模块 -->
    <el-dialog v-model="scaffold.open" title="新建模块" :width="isMobile ? '94vw' : '480px'">
      <el-form :label-width="isMobile ? undefined : '96px'" :label-position="isMobile ? 'top' : 'right'">
        <el-form-item label="技术名">
          <el-input v-model="scaffold.name" placeholder="school_student" />
          <div class="muted tip">小写字母 / 数字 / 下划线,以字母开头。这是模块目录名,也是 Odoo 里的技术名称。</div>
        </el-form-item>
        <el-form-item label="显示名">
          <el-input v-model="scaffold.label" placeholder="学生管理" />
          <div class="muted tip">Odoo「应用」里看到的名字,可写中文。</div>
        </el-form-item>
      </el-form>
      <div class="muted tip">
        会生成一个<b>能直接安装</b>的最小模块:模型(含计算字段)、列表 / 表单视图、菜单、访问权限、README。
        生成后到 Odoo「应用」→ 更新应用列表 → 搜索安装。
      </div>
      <template #footer>
        <el-button @click="scaffold.open = false">取消</el-button>
        <el-button type="primary" :loading="scaffold.busy" @click="doScaffold">生成</el-button>
      </template>
    </el-dialog>

    <!-- 历史版本 -->
    <el-drawer v-model="history.open" :title="`历史版本 · ${history.path.split('/').pop()}`" :size="isMobile ? '100%' : '620px'">
      <el-empty v-if="!history.rows.length" :image-size="60" description="这个文件还没有历史版本(保存过一次之后才会有)" />
      <div v-else class="hist">
        <el-table :data="history.rows" size="small" highlight-current-row @current-change="previewHistory">
          <el-table-column prop="at" label="时间" :width="isMobile ? 150 : 170" />
          <el-table-column label="大小" width="80"><template #default="{ row }">{{ (row.size / 1024).toFixed(1) }} KB</template></el-table-column>
          <el-table-column label="操作" align="right">
            <template #default="{ row }">
              <el-button link type="primary" size="small" @click.stop="restoreHistory(row.version)">恢复这一版</el-button>
            </template>
          </el-table-column>
        </el-table>
        <pre v-if="history.preview" class="histpreview">{{ history.preview }}</pre>
        <div v-else class="muted small" style="padding: 8px 2px">点一行预览那一版的内容</div>
      </div>
    </el-drawer>

    <!-- 改动记录 -->
    <el-drawer v-model="audit.open" title="代码改动记录" :size="isMobile ? '100%' : '720px'">
      <el-empty v-if="!audit.rows.length" :image-size="60" description="还没有改动记录" />
      <el-table v-else :data="audit.rows" size="small">
        <el-table-column prop="at" label="时间" :width="isMobile ? 90 : 170">
          <template #default="{ row }">{{ isMobile ? String(row.at).slice(5, 16).replace('T', ' ') : String(row.at).replace('T', ' ').slice(0, 19) }}</template>
        </el-table-column>
        <el-table-column v-if="!isMobile" prop="username" label="谁" width="110" />
        <el-table-column label="动作" width="84">
          <template #default="{ row }"><el-tag size="small" :type="ACTION_TYPE[row.action] || 'info'" effect="plain">{{ ACTION_LABEL[row.action] || row.action }}</el-tag></template>
        </el-table-column>
        <el-table-column label="路径" min-width="160">
          <template #default="{ row }"><span class="mono small">{{ isMobile ? (row.path || '—').split('/').slice(-2).join('/') : (row.path || '—') }}</span></template>
        </el-table-column>
        <el-table-column v-if="!isMobile" prop="detail" label="备注" min-width="140" />
      </el-table>
    </el-drawer>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  ArrowDown, Clock, Close, Delete, Document, DocumentAdd, Download, EditPen, Files, Folder, FolderAdd,
  InfoFilled, Plus, Refresh, RefreshRight, Search, Select, UploadFilled, WarningFilled,
} from '@element-plus/icons-vue'
import api from '../../api'
import { useIsMobile } from '../../composables/useMedia'
import { confirmDanger } from '../../utils/confirm'
import { downloadBlob } from '../../utils/download'

const props = defineProps({ env: { type: Object, required: true }, active: Boolean })
const emit = defineEmits(['changed'])

const BUSY_STATES = ['provisioning', 'destroying', 'starting', 'stopping', 'restarting', 'deploying', 'cloning', 'waking', 'restoring']
const ACTION_LABEL = { write: '保存', create: '新建', delete: '删除', rename: '改名', upload_file: '传文件', upload_zip: '传代码包', scaffold: '建模块', update_modules: '升级', restore: '回滚' }
const ACTION_TYPE = { delete: 'danger', write: 'success', scaffold: 'primary', update_modules: 'warning', restore: 'warning' }

const isMobile = useIsMobile()
const treeOpen = ref(false)   // 手机上文件树是浮层,默认收起

const base = computed(() => `/environments/${props.env.id}/custom-code`)
const busy = computed(() => BUSY_STATES.includes(props.env.status))

const loading = ref(false); const saving = ref(false); const reloading = ref(false)
const uploading = ref(false); const uploadingFile = ref(false); const downloading = ref(false)
const pct = ref(0); const pickedName = ref(''); const lastResult = ref(null)
const tree = ref([]); const truncated = ref(false); const hostDir = ref(''); const modules = ref([])
const mountDir = ref(''); const isGit = ref(false)
const expanded = ref([]); const filter = ref('')
const treeRef = ref(null); const editorEl = ref(null); const fileInput = ref(null); const zipInput = ref(null)
const current = reactive({ path: '', loaded: '', reason: '', mtime: null })
const editable = ref(false)
const lint = ref([])
const zipMode = ref('replace')
const scaffold = reactive({ open: false, name: '', label: '', busy: false })
const history = reactive({ open: false, path: '', rows: [], preview: '' })
const audit = reactive({ open: false, rows: [] })
const quota = reactive({ bytes: 0, files: 0, max: 0, pct: 0 })
const jobErr = ref(null); const showFullErr = ref(false)
const notice = ref(null)   // 常驻提示(平台替你改了什么),用户手动关
const schemaNote = ref(''); const schemaCount = ref(0)  // 补全用的库内元数据状态

// monaco 是动态 import 进来的,不放响应式变量(它体积巨大,proxy 化会很慢)
let monacoNS = null; let languageOf = null; let setOdooSchema = null; let editor = null; let ro = null

const currentDir = ref('')
const currentModule = computed(() => (current.path || currentDir.value || '').split('/')[0] || '')
const lintErrors = computed(() => lint.value.filter((x) => x.level === 'error').length)
const lintWarns = computed(() => lint.value.filter((x) => x.level !== 'error').length)

const uploadSummary = computed(() => {
  const r = lastResult.value
  if (!r) return ''
  const mode = r.mode === 'merge' ? '只覆盖包里有的文件' : '同名模块整个替换'
  return `已上传(${mode}):新增 ${r.new.length ? r.new.join('、') : '无'};更新 ${r.updated.length ? r.updated.join('、') : '无'}。`
    + (r.restarted ? '已自动重启使生效。' : '')
})

// 改完哪种文件要做什么 —— 学生最常卡在「改了没反应」
const applyHint = computed(() => {
  const p = current.path
  if (!p) return ''
  if (p.endsWith('.py')) return '加/改字段 → 升级模块;只改方法体 → 重启使生效'
  if (p.endsWith('.xml')) return '视图 / 数据 → 升级模块'
  if (p.endsWith('.csv')) return '权限文件 → 升级模块'
  if (/\.(po|pot)$/.test(p)) return '翻译 → 升级模块,或在 Odoo 里「更新翻译」'
  if (/\.(js|css|scss|less)$/.test(p)) return '前端资源 → 重启后在浏览器 Ctrl+F5 强刷'
  return ''
})

// editor.getValue() 不是响应式的:每次输入 / 打开文件时 rev++,靠它驱动 dirty 重算。
const rev = ref(0)
const dirty = computed(() => (rev.value, editable.value && editor != null && editor.getValue() !== current.loaded))

const fmtMB = (n) => (n >= 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)}MB` : `${Math.max(1, Math.round(n / 1024))}KB`)

// ---------------------------------------------------------------- 数据
async function loadTree(keepOpen = true) {
  loading.value = true
  try {
    const [t, info] = await Promise.all([api.get(`${base.value}/fs/tree`), api.get(base.value)])
    tree.value = t.tree || []; truncated.value = !!t.truncated
    hostDir.value = info.host_dir || ''; modules.value = info.modules || []
    mountDir.value = info.mount || ''; isGit.value = !!info.git
    const u = t.usage || {}; const lim = t.limits || {}
    quota.bytes = u.bytes || 0; quota.files = u.files || 0; quota.max = lim.max_bytes || 0
    quota.pct = quota.max ? Math.min(100, Math.round(quota.bytes / quota.max * 100)) : 0
    if (!keepOpen) { current.path = ''; editable.value = false }
    // el-tree 的 default-expanded-keys 对数组原地 push 不会重新触发,换数据后手动恢复展开
    await nextTick()
    for (const k of expanded.value) treeRef.value?.getNode?.(k)?.expand?.()
  } catch {} finally { loading.value = false }
}

/** 有未保存改动时先问一句;返回 false = 用户取消,调用方应中止 */
async function confirmDiscard(what = '切换文件') {
  if (!dirty.value) return true
  return confirmDanger({
    title: '有未保存的改动', message: `「${current.path}」还没保存,${what}会丢失改动。`,
    confirmText: '丢弃改动', type: 'warning',
  })
}

async function openFile(path, skipDirtyCheck = false) {
  if (!skipDirtyCheck && !(await confirmDiscard())) return
  try {
    const r = await api.get(`${base.value}/fs/file`, { params: { path } })
    current.path = r.path; current.loaded = r.content ?? ''; current.reason = r.reason || ''
    current.mtime = r.mtime ?? null
    editable.value = !!r.editable
    lint.value = r.lint || []
    if (r.editable) {
      await ensureEditor()
      monacoNS.editor.setModelLanguage(editor.getModel(), languageOf(path))
      editor.setValue(r.content ?? '')
      applyLint()
      if (!isMobile.value) editor.focus()  // 手机上别自动聚焦:会弹软键盘把编辑器顶跑
    }
    rev.value++
  } catch {}
}

function onNodeClick(data) {
  if (data.dir) { currentDir.value = data.path; return }
  currentDir.value = data.path.split('/').slice(0, -1).join('/')
  if (isMobile.value) treeOpen.value = false  // 选了文件就收起浮层,露出编辑器
  openFile(data.path)
}
function onExpand(d) { if (!expanded.value.includes(d.path)) expanded.value.push(d.path) }
function onCollapse(d) { expanded.value = expanded.value.filter((p) => p !== d.path) }
function filterNode(v, data) { return !v || data.name.toLowerCase().includes(v.toLowerCase()) }
watch(filter, (v) => treeRef.value?.filter(v))

// ---------------------------------------------------------------- 编辑器
async function ensureEditor() {
  if (editor) return
  const mod = await import('../../monaco')
  monacoNS = mod.default; languageOf = mod.languageOf; setOdooSchema = mod.setOdooSchema
  loadSchema()   // 补全用的库内模型/字段,失败也不影响编辑
  await nextTick()
  editor = monacoNS.editor.create(editorEl.value, {
    value: '', language: 'plaintext', automaticLayout: false,
    theme: 'vs', fontSize: isMobile.value ? 14 : 13, tabSize: 4, insertSpaces: true,
    minimap: { enabled: false }, scrollBeyondLastLine: false,
    renderWhitespace: 'selection', fixedOverflowWidgets: true,
    // 补全:字符串里也自动弹(默认 strings:false —— self.env['res 打开引号弹一次,再打字就没了,
    // 得按 Ctrl+空格);模型名 / 字段名 / depends 全在引号里,这一项不开等于补全做了一半。
    quickSuggestions: { other: true, comments: false, strings: true },
    quickSuggestionsDelay: 60,
    suggestOnTriggerCharacters: true,
    acceptSuggestionOnEnter: 'on',
    tabCompletion: 'on',                       // 打 odoo-model 然后 Tab 直接展开片段
    suggest: { showWords: true, preview: false, snippetsPreventQuickSuggestions: false },
    // 手机:自动换行(没有横向滚动条可拖)、行号窄一点、别把小屏挤没了
    wordWrap: isMobile.value ? 'on' : 'off',
    lineNumbersMinChars: isMobile.value ? 3 : 4,
    folding: !isMobile.value,
    glyphMargin: false,
  })
  editor.onDidChangeModelContent(() => { rev.value++ })
  editor.addCommand(monacoNS.KeyMod.CtrlCmd | monacoNS.KeyCode.KeyS, () => save())
  ro = new ResizeObserver(() => editor?.layout())
  ro.observe(editorEl.value)
}

/** 拉取本实例数据库里真实存在的模型 / 字段,喂给补全。
 *  实例没起来时后端返回空列表 + reason,这里只记 schemaNote 供界面提示,不打扰学生。 */
async function loadSchema(refresh = false) {
  if (!setOdooSchema) return
  try {
    const r = await api.get(`${base.value}/fs/completions`, { params: refresh ? { refresh: true } : {}, silent: true })
    setOdooSchema(r.models || [])
    schemaNote.value = r.reason || ''
    schemaCount.value = (r.models || []).length
  } catch { schemaNote.value = '' }
}

/** 把后端的语法预检结果画成 Monaco 的波浪线 */
function applyLint() {
  if (!monacoNS || !editor) return
  monacoNS.editor.setModelMarkers(editor.getModel(), 'odoosh', (lint.value || []).map((x) => ({
    startLineNumber: x.line || 1, endLineNumber: x.line || 1, startColumn: 1, endColumn: 1000,
    message: x.message,
    severity: x.level === 'error' ? monacoNS.MarkerSeverity.Error : monacoNS.MarkerSeverity.Warning,
  })))
}
function gotoLine(n) { editor?.revealLineInCenter(n); editor?.setPosition({ lineNumber: n, column: 1 }); editor?.focus() }

async function save(force = false) {
  if (!editable.value || !editor || (!dirty.value && !force)) return
  saving.value = true
  const bytesBefore = new TextEncoder().encode(current.loaded).length
  try {
    const content = editor.getValue()
    const r = await api.put(`${base.value}/fs/file`, { content, mtime: force ? null : current.mtime },
      { params: { path: current.path }, silent: true })
    current.loaded = content; current.mtime = r.mtime ?? null; rev.value++
    lint.value = r.lint || []; applyLint()
    const bad = lint.value.filter((x) => x.level === 'error')
    if (bad.length) ElMessage.warning(`已保存,但有语法错误:第 ${bad[0].line} 行 ${bad[0].message}`)
    else ElMessage.success(applyHint.value ? `已保存 · ${applyHint.value}` : '已保存')
    // 不刷新整棵树:每次 Ctrl+S 都重拉树 + 模块列表,又慢又让树闪一下。
    // 配额条等下次刷新/新建/删除时再更新即可,这里只把本文件的字节差补上。
    quota.bytes += r.size - (bytesBefore || 0)
  } catch (e) {
    if (e.response?.status === 409) {
      // 别人(另一个标签页 / 同学 / Shell)在这期间改过这个文件
      if (await confirmDanger({
        title: '文件被改过了', message: `${e.detail}\n\n要用你现在编辑器里的内容覆盖掉吗?`,
        confirmText: '用我的覆盖', type: 'warning',
      })) await save(true)
    } else {
      ElMessage.error(e.detail || '保存失败')
    }
  } finally { saving.value = false }
}

// ---------------------------------------------------------------- 文件操作
async function newEntry(dir, kind) {
  const label = kind === 'dir' ? '目录' : '文件'
  // 先问未保存的改动 —— 建完文件会自动切过去,到那时再问就晚了(树已刷新、注意力已被打断)
  if (!(await confirmDiscard(`新建${label}后会切到新文件`))) return
  try {
    const { value } = await ElMessageBox.prompt(`在 ${dir}/ 下新建${label}`, `新建${label}`, {
      inputPlaceholder: kind === 'dir' ? 'models' : 'models.py',
      inputValidator: (v) => (/^[\w.\-]+$/.test((v || '').trim()) ? true : '只能用字母、数字、下划线、点、连字符'),
      confirmButtonText: '创建', cancelButtonText: '取消',
    })
    const name = value.trim()
    const path = `${dir}/${name}`
    const r = await api.post(`${base.value}/fs/entry`, { path, kind })
    if (!expanded.value.includes(dir)) expanded.value.push(dir)
    if (r.init_updated) {
      notice.value = {
        title: `已自动在 ${r.init_updated} 里加上 from . import ${name.replace(/\.py$/, '')}`,
        desc: 'Odoo 不会自动发现 .py 文件,漏了这行模块照样能装但代码根本不加载,而且没有任何报错 —— 平台替你补上了。',
      }
    }
    await loadTree()
    if (kind === 'file') { if (isMobile.value) treeOpen.value = false; await openFile(path, true) }
  } catch {}
}

async function rename(data) {
  try {
    const { value } = await ElMessageBox.prompt(`重命名「${data.name}」`, '重命名', {
      inputValue: data.name,
      inputValidator: (v) => (/^[\w.\-]+$/.test((v || '').trim()) ? true : '只能用字母、数字、下划线、点、连字符'),
      confirmButtonText: '确定', cancelButtonText: '取消',
    })
    const parts = data.path.split('/'); parts[parts.length - 1] = value.trim()
    const newPath = parts.join('/')
    const r = await api.post(`${base.value}/fs/rename`, { path: data.path, new_path: newPath })
    if (r.init_updated) {
      notice.value = { title: `已同步更新 ${r.init_updated} 里的 import`, desc: '改名后旧的 import 会指向不存在的文件,平台替你改好了。' }
    }
    await loadTree()
    // 改的正是打开着的那个文件:重新打开,别让 current.path 和 mtime / 内容脱节
    if (current.path === data.path) await openFile(newPath, true)
    ElMessage.success('已重命名')
  } catch {}
}

async function remove(data) {
  const what = data.dir ? (data.module ? '模块' : '目录') : '文件'
  if (!(await confirmDanger({
    title: `删除${what}`,
    message: `删除「${data.path}」?${data.dir ? '目录下所有文件都会删掉,' : ''}不可恢复。`
      + (data.module ? '若已在 Odoo 里安装,请先到「应用」里卸载再删代码。' : ''),
    requireText: data.module ? data.name : undefined,
  }))) return
  try {
    const r = await api.delete(`${base.value}/fs/entry`, { params: { path: data.path } })
    if (current.path === data.path || current.path.startsWith(data.path + '/')) {
      current.path = ''; editable.value = false; lint.value = []
    }
    if (r.init_updated) {
      notice.value = {
        title: `已同时从 ${r.init_updated} 里去掉 from . import ${data.name.replace(/\.py$/, '')}`,
        desc: '文件删了但 import 还在的话,Odoo 加载这个模块会直接 ImportError,整个模块起不来。',
      }
    }
    await loadTree(); ElMessage.success('已删除')
  } catch {}
}

// ---------------------------------------------------------------- 历史版本
async function openHistory(path) {
  history.path = path; history.preview = ''; history.rows = []; history.open = true
  try { history.rows = (await api.get(`${base.value}/fs/history`, { params: { path } })).versions || [] } catch {}
}
async function previewHistory(row) {
  if (!row) return
  try {
    history.preview = (await api.get(`${base.value}/fs/history/content`,
      { params: { path: history.path, version: row.version } })).content || ''
  } catch {}
}
async function restoreHistory(version) {
  if (!(await confirmDanger({
    title: '恢复历史版本', message: `把「${history.path}」恢复成 ${version} 那一版?当前内容会先自动存一份,可以再撤回。`,
    confirmText: '恢复', type: 'warning', danger: false,
  }))) return
  try {
    await api.post(`${base.value}/fs/history/restore`, null, { params: { path: history.path, version } })
    history.open = false
    ElMessage.success('已恢复')
    // 打开的正是这个文件:直接重新拉一次(skipDirtyCheck —— 编辑器里的旧内容本来就是要被替掉的)
    if (current.path === history.path) await openFile(history.path, true)
    loadTree()
  } catch {}
}

async function openAudit() {
  audit.open = true
  try { audit.rows = await api.get(`${base.value}/fs/audit`, { params: { limit: 200 } }) } catch {}
}

// ---------------------------------------------------------------- 上传 / 下载
/** 「上传」下拉的三个入口共用一个处理:zip:replace / zip:merge / file */
function pickUpload(cmd) {
  if (cmd === 'file') { fileInput.value?.click(); return }
  zipMode.value = cmd === 'zip:merge' ? 'merge' : 'replace'
  zipInput.value?.click()
}
function onPickZip(e) { const f = e.target.files?.[0]; e.target.value = ''; if (f) uploadZip(f) }
async function uploadZip(file) {
  uploading.value = true; pct.value = 0; pickedName.value = file.name; lastResult.value = null
  try {
    const r = await api.put(`${base.value}/upload`, file, {
      params: { mode: zipMode.value }, headers: { 'Content-Type': 'application/zip' }, timeout: 0,
      onUploadProgress: (ev) => { if (ev.total) pct.value = Math.round(ev.loaded / ev.total * 100) },
    })
    lastResult.value = { new: r.new || [], updated: r.updated || [], mode: r.mode, restarted: r.restarted }
    ElMessage.success('已上传,正在重启使生效')
    emit('changed'); await loadTree()
  } catch {} finally { uploading.value = false }
}

function onPickFile(e) { const f = e.target.files?.[0]; e.target.value = ''; if (f) uploadOne(f) }
async function uploadOne(file) {
  uploadingFile.value = true
  try {
    await api.put(`${base.value}/fs/upload-file`, file, {
      params: { dir: currentDir.value, name: file.name },
      headers: { 'Content-Type': 'application/octet-stream' }, timeout: 0,
    })
    await loadTree(); ElMessage.success(`已上传到 ${currentDir.value}/${file.name}`)
  } catch {} finally { uploadingFile.value = false }
}

async function download(module = '') {
  downloading.value = true
  try {
    const blob = await api.get(`${base.value}/download`, { params: module ? { module } : {}, responseType: 'blob' })
    downloadBlob(blob, module ? `${module}.zip` : `${props.env.name}-addons.zip`)
  } catch {} finally { downloading.value = false }
}

// ---------------------------------------------------------------- 生效
/** 保存了才生效 —— 升级 / 重启用的都是磁盘上的内容,编辑器里没存的改动不算 */
async function confirmUnsaved(what) {
  if (!dirty.value) return true
  return confirmDanger({
    title: '有未保存的改动', message: `「${current.path}」还没保存,${what}用的是磁盘上的旧内容。`,
    confirmText: `仍然${what}`, type: 'warning', danger: false,
  })
}

async function updateModules(mods) {
  const target = typeof mods === 'string' && mods ? mods : ''
  if (!target) { ElMessage.warning('先在树里选一个模块里的文件,或从下拉里选要升级的模块'); return }
  if (!(await confirmUnsaved('升级'))) return
  try {
    jobErr.value = null
    await api.post(`${base.value}/fs/update-modules`, null, { params: { modules: target } })
    ElMessage.success(`正在升级 ${target}(约 1~5 分钟),完成后这里会显示结果`)
    emit('changed')
  } catch {}
}

async function restart() {
  if (!(await confirmUnsaved('重启'))) return
  reloading.value = true
  try {
    jobErr.value = null
    await api.post(`${base.value}/reload`); ElMessage.success('正在重启使生效'); emit('changed')
  } catch {} finally { reloading.value = false }
}

/** 忙碌结束后拉一次日志尾部:失败就直接摆在编辑器上方,不用切「日志」Tab */
async function checkJobResult() {
  try {
    const r = await api.get(`${base.value}/fs/last-error`, { silent: true })
    if (r.failed) { jobErr.value = r; showFullErr.value = false }
    else jobErr.value = null
  } catch {}
}
watch(busy, (now, before) => { if (before && !now) { checkJobResult(); loadSchema(true) } })

// ---------------------------------------------------------------- 新建模块
function openScaffold() { scaffold.name = ''; scaffold.label = ''; scaffold.open = true }
async function doScaffold() {
  const name = (scaffold.name || '').trim()
  if (!/^[a-z][a-z0-9_]{1,62}$/.test(name)) {
    ElMessage.warning('技术名只能用小写字母、数字、下划线,以字母开头(如 school_student)')
    return
  }
  scaffold.busy = true
  try {
    const r = await api.post(`${base.value}/fs/scaffold`, { name, label: (scaffold.label || '').trim() })
    scaffold.open = false
    expanded.value.push(name, `${name}/models`)
    await loadTree()
    await openFile(r.entry, true)
    notice.value = {
      title: `已生成模块 ${name}`,
      desc: '接下来:到 Odoo「应用」→ 更新应用列表 → 搜索本模块 → 安装。之后改了模型 / 视图,回来点「升级模块」才生效。',
    }
    emit('changed')
  } catch {} finally { scaffold.busy = false }
}

// ---------------------------------------------------------------- 生命周期
onMounted(loadTree)
watch(() => props.active, (v) => { if (v) nextTick(() => editor?.layout()) })
// 横竖屏切换 / 桌面窗口拖过断点:换行策略跟着变
watch(isMobile, (m) => editor?.updateOptions({ wordWrap: m ? 'on' : 'off', folding: !m }))
onBeforeUnmount(() => {
  ro?.disconnect(); ro = null
  editor?.dispose(); editor = null
  monacoNS = null; languageOf = null
})
</script>

<style scoped>
.cc { display: flex; flex-direction: column; gap: 10px; }
/* 与 TabShell / TabBackups 同款工具栏 */
.bar { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.mod-lbl { margin-left: 4px; }   /* 「升级 <模块名>」之间的间距(模板里的空格会被 Vue 折叠掉) */
.spacer { flex: 1; min-width: 8px; }
.small { font-size: 12px; }
.prog { display: flex; align-items: center; gap: 10px; }
.prog :deep(.el-progress) { flex: 1; }
.tip { font-size: 12px; line-height: 1.7; margin-top: 4px; }
.errlog {
  margin: 6px 0 0; padding: 8px 10px; max-height: 160px; overflow: auto;
  background: var(--el-fill-color-light); border-radius: 4px;
  font-family: var(--mono, monospace); font-size: 12px; line-height: 1.6; white-space: pre-wrap;
}
.errlog.full { max-height: 300px; }

/* ---- 编辑区:高度跟视口走(和 Shell 的 62vh 一致),不写死像素 ---- */
.editor-wrap {
  position: relative; display: flex; height: 62vh; min-height: 340px;
  border: 1px solid var(--el-border-color-light); border-radius: 10px; overflow: hidden;
  background: var(--el-bg-color);
}
.pane-tree {
  width: 264px; min-width: 200px; display: flex; flex-direction: column;
  border-right: 1px solid var(--el-border-color-light); background: var(--el-fill-color-blank);
}
.tree-head { display: flex; align-items: center; gap: 6px; padding: 8px; border-bottom: 1px solid var(--el-border-color-lighter); }
.tree-head .el-input { flex: 1; }
.tree-body { flex: 1; padding: 4px 0; }
.quota { padding: 6px 10px 3px; border-top: 1px solid var(--el-border-color-lighter); font-size: 11px; }
.quota .muted { display: block; margin-top: 3px; }
.tree-foot {
  padding: 6px 10px; border-top: 1px solid var(--el-border-color-lighter);
  font-size: 11.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.pane-edit { flex: 1; display: flex; flex-direction: column; min-width: 0; }
.edit-head {
  display: flex; align-items: center; gap: 8px; padding: 6px 10px; font-size: 12.5px; min-height: 38px;
  border-bottom: 1px solid var(--el-border-color-lighter); background: var(--el-fill-color-light);
}
.edit-head .path { font-weight: 600; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.edit-head .dirty { color: var(--el-color-warning); font-size: 12px; flex: none; }
.hint-inline { color: var(--el-text-color-secondary); font-size: 12px; white-space: nowrap; }
.mon { flex: 1; min-height: 0; }
.lintbar { border-top: 1px solid var(--el-border-color-lighter); max-height: 96px; overflow: auto; }
.lintrow {
  display: flex; align-items: center; gap: 6px; padding: 4px 12px; cursor: pointer;
  font-size: 12px; line-height: 1.5;
}
.lintrow:hover { background: var(--el-fill-color-light); }
.lintrow.error { color: var(--el-color-danger); }
.lintrow.warn { color: var(--el-color-warning); }
.placeholder { flex: 1; display: flex; align-items: center; justify-content: center; }

.hist :deep(.el-table) { margin-bottom: 10px; }
.histpreview {
  margin: 0; padding: 10px; max-height: 42vh; overflow: auto;
  background: var(--el-fill-color-light); border-radius: 4px;
  font-family: var(--mono, monospace); font-size: 12px; line-height: 1.6; white-space: pre-wrap;
}

/* ---- 树节点 ---- */
.node { display: flex; align-items: center; gap: 5px; width: 100%; overflow: hidden; }
.node .ic { flex: none; color: var(--el-text-color-secondary); }
.node.mod .nm { font-weight: 600; }
.node .nm { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.node .badge {
  flex: none; font-size: 10px; padding: 0 4px; border-radius: 3px;
  background: var(--el-fill-color-dark); color: var(--el-text-color-secondary);
}
.node-acts { flex: none; margin-left: auto; display: none; gap: 8px; padding-left: 8px; }
.node:hover .node-acts { display: flex; }
.node-acts .el-icon { color: var(--el-text-color-secondary); font-size: 15px; }
.node-acts .el-icon:hover { color: var(--el-color-primary); }
.node-acts .del:hover { color: var(--el-color-danger); }
/* 触屏没有 hover:操作图标常显(淡一点),点击区域放大到手指能按 */
@media (hover: none) {
  .node-acts { display: flex; gap: 2px; opacity: .7; }
  .node-acts .el-icon { font-size: 17px; padding: 6px 5px; }
}
.mono { font-family: var(--mono, monospace); }

/* ---- 手机(≤640px):树变成左侧滑出的浮层;工具栏只留图标 ---- */
@media (max-width: 640px) {
  .cc .lbl { display: none; }                        /* 次要按钮只留图标 */
  .editor-wrap { height: calc(100vh - 230px); height: calc(100dvh - 230px); min-height: 300px; border-radius: 8px; }
  .tree-mask { position: fixed; inset: 0; z-index: 1200; background: rgba(15, 23, 42, .45); }
  .pane-tree {
    position: fixed; top: 0; bottom: 0; left: 0; z-index: 1201;
    width: min(86vw, 340px); min-width: 0; border-right: none;
    box-shadow: 4px 0 24px rgba(0, 0, 0, .18);
    transform: translateX(-104%); transition: transform .22s ease;
  }
  .pane-tree.open { transform: none; }
  .tree-head { padding: 10px 8px; padding-top: max(10px, env(safe-area-inset-top)); }
  .edit-head { padding: 6px 8px; gap: 6px; }
  .lintrow { padding: 6px 10px; }
  .histpreview { max-height: 50vh; }
}
</style>
