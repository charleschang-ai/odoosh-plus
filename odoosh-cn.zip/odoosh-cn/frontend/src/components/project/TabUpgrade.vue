<template>
  <!-- 升级:① 企业版代码有新提交时一键升级;② Odoo 大版本升级(先只放说明 + 导出备份) -->
  <div class="upg">
    <el-card shadow="never" class="blk">
      <template #header><b>企业版代码升级</b></template>
      <template v-if="env.edition !== 'enterprise'">
        <div class="muted">该实例是社区版,没有企业版代码可升级。</div>
      </template>
      <template v-else>
        <div v-loading="loading">
          <div v-if="info?.error" class="warn">{{ info.error }}</div>
          <el-descriptions v-else-if="info" :column="1" size="small" border>
            <el-descriptions-item label="来源仓库">{{ info.repo?.name }} <span class="muted">{{ info.repo?.url }}</span></el-descriptions-item>
            <el-descriptions-item label="当前 commit"><span class="mono">{{ (info.current || '').slice(0, 12) || '—' }}</span></el-descriptions-item>
            <el-descriptions-item label="最新 commit"><span class="mono">{{ (info.latest || '').slice(0, 12) || '—' }}</span> <span class="muted">({{ env.odoo_version }}.0 分支)</span></el-descriptions-item>
          </el-descriptions>
          <div style="margin-top: 12px; display: flex; gap: 8px; align-items: center">
            <template v-if="info?.can_upgrade">
              <el-alert type="warning" :closable="false" show-icon style="flex: 1" :title="`可升级到 ${(info.latest || '').slice(0, 12)}:重新拉取企业版代码 → 换挂载 → 升级模块 → 健康检查,失败自动回退`" />
              <el-button type="primary" :disabled="busy || !canDeploy" @click="upgrade">一键升级</el-button>
            </template>
            <el-alert v-else-if="info && !info.error" type="success" :closable="false" show-icon title="企业版代码已是最新" style="flex: 1" />
            <el-button size="small" :icon="Refresh" @click="load">重新检查</el-button>
          </div>
        </div>
      </template>
    </el-card>

    <el-card shadow="never" class="blk">
      <template #header><b>Odoo 大版本升级</b>(如 {{ env.odoo_version }} → {{ Number(env.odoo_version) + 1 }})</template>
      <div class="muted" style="line-height: 1.7">
        跨大版本升级需要 Odoo 官方升级服务(<a href="https://upgrade.odoo.com" target="_blank">upgrade.odoo.com</a>,企业版)或 OpenUpgrade(社区版)处理数据库,平台内一键升级正在规划中。当前建议流程:
        <ol style="margin: 6px 0 0; padding-left: 20px">
          <li>在此导出该环境的备份(下方按钮),提交升级服务 / 本地用 OpenUpgrade 升级数据库;</li>
          <li>把自定义模块迁移到新版本分支,推送到仓库;</li>
          <li>以新版本分支新建一个 Odoo {{ Number(env.odoo_version) + 1 }} 的测试环境,恢复升级后的数据库验证;</li>
          <li>验证通过后,把该测试拖到生产(原生产降级或删除)。</li>
        </ol>
      </div>
      <div style="margin-top: 12px"><el-button :disabled="busy || !env.db_name || !perms?.[env.kind]?.backup" @click="exportBackup">导出备份(用于升级)</el-button></div>
    </el-card>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import api from '../../api'
import { isBusy, actionLabel } from '../../utils/labels'

const props = defineProps({ env: Object, projectId: Number, perms: Object })
const emit = defineEmits(['changed'])
const info = ref(null); const loading = ref(false)
const busy = computed(() => isBusy(props.env))
const canDeploy = computed(() => !!props.perms?.[props.env.kind]?.deploy)
async function load() {
  if (props.env.edition !== 'enterprise') return
  loading.value = true
  try { info.value = await api.get(`/projects/${props.projectId}/environments/${props.env.id}/upgrade`) } catch {} finally { loading.value = false }
}
watch(() => props.env.id, load)
onMounted(load)
async function upgrade() {
  try { await ElMessageBox.confirm(`升级企业版代码到 ${(info.value.latest || '').slice(0, 12)},并执行「${actionLabel(props.env.deploy_action || 'update_all', props.env.deploy_modules)}」。期间环境短暂停机;失败自动回退。`, '企业版升级', { confirmButtonText: '开始升级', type: 'warning' }) } catch { return }
  try { await api.post(`/projects/${props.projectId}/environments/${props.env.id}/upgrade`, { action: props.env.deploy_action || 'update_all' }); ElMessage.success('开始升级,完成后会提示'); emit('changed') } catch {}
}
async function exportBackup() {
  try { await api.post('/backups', { environment_id: props.env.id, note: `导出用于 Odoo ${props.env.odoo_version} → ${Number(props.env.odoo_version) + 1} 升级`, include_filestore: true }); ElMessage.success('备份已开始,完成后可在「备份」Tab 下载') } catch {}
}
</script>

<style scoped>
.blk { margin-bottom: 14px; }
.warn { color: var(--warn); }
.mono { font-family: ui-monospace, Menlo, Consolas, monospace; }
</style>
