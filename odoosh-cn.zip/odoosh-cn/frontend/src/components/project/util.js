// 兼容旧引用:统一转发到 src/utils(新代码请直接 import '@/utils/labels' / '@/utils/format')
export { KINDS, BUSY, isBusy, kindLabel, kindType, statusLabel, statusType, opLabel, expireText, expireSoon, depLabel, depType, triggerLabel } from '../../utils/labels'
export { fmtDate, ago, fmtSize } from '../../utils/format'
