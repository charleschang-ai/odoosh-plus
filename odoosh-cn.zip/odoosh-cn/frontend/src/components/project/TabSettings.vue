<template>
  <!-- 设置:分组卡片(与「系统设置」同一视觉):环境 / Odoo 账号 / 部署 / 资源上限 / 平台管理员(域名、过期) -->
  <div class="settings">
    <el-alert v-if="!canEdit" type="info" :closable="false" show-icon class="ro-tip" title="你对本环境只有运维权限:以下设置为只读;资源上限、访问权限、平台管理员设置仅「可管理」及以上可见" />
    <div class="groups">
      <!-- 环境 -->
      <el-card shadow="never" class="group tone-env">
        <template #header><div class="g-head"><span class="g-icon"><el-icon><Box /></el-icon></span><div><div class="g-title">环境</div><div class="g-desc muted">档位、名称与 Odoo 版本;版本类 / 镜像在创建后不可更改</div></div></div></template>
        <div class="fields">
          <div class="field">
            <div class="f-label"><div class="f-name">档位</div><div class="f-help muted">改档位会走与拖拽相同的流程:重建容器;开发→测试会从生产重建库;生产降级需确认</div></div>
            <div class="f-ctrl">
              <el-radio-group :model-value="env.kind" :disabled="!canEdit" @change="onKind">
                <el-radio-button v-for="k in KINDS" :key="k" :value="k" :disabled="k !== env.kind && !canMove(k)">{{ kindLabel(k) }}</el-radio-button>
              </el-radio-group>
            </div>
          </div>
          <div class="field">
            <div class="f-label"><div class="f-name">环境名</div><div class="f-help muted">容器 / 数据库 / 默认域名都由它派生,创建后不可改</div></div>
            <div class="f-ctrl"><code class="mono val">{{ env.name }}</code></div>
          </div>
          <div class="field">
            <div class="f-label"><div class="f-name">Odoo 版本</div></div>
            <div class="f-ctrl">
              <el-radio-group v-model="form.odoo_version" :disabled="!!env.container_name || !canEdit">
                <el-radio-button v-for="v in defaults.odoo_versions" :key="v" :value="v">Odoo {{ v }}</el-radio-button>
              </el-radio-group>
            </div>
          </div>
          <div class="field">
            <div class="f-label"><div class="f-name">版本类型</div></div>
            <div class="f-ctrl">
              <el-radio-group v-model="form.edition" :disabled="!!env.container_name || !canEdit">
                <el-radio-button value="community">社区版</el-radio-button>
                <el-radio-button value="enterprise">企业版</el-radio-button>
              </el-radio-group>
            </div>
          </div>
          <div class="field">
            <div class="f-label"><div class="f-name">基础镜像</div><div class="f-help muted" v-if="env.container_name">如需更换版本 / 版本类型 / 镜像,请新建环境</div></div>
            <div class="f-ctrl">
              <el-radio-group v-model="form.base_mode" :disabled="!!env.container_name || !canEdit">
                <el-radio-button value="official">官方镜像 odoo:{{ form.odoo_version }}</el-radio-button>
                <el-radio-button value="custom">源码自建</el-radio-button>
              </el-radio-group>
            </div>
          </div>
        </div>
      </el-card>

      <!-- Odoo 账号(仅有 secrets 权限时后端返回口令;否则整块隐藏) -->
      <el-card v-if="detail.admin_password" shadow="never" class="group tone-odoo">
        <template #header><div class="g-head"><span class="g-icon"><el-icon><User /></el-icon></span><div><div class="g-title">Odoo 账号</div><div class="g-desc muted">「打开」按钮用它免密登录;也可手动登录</div></div></div></template>
        <div class="fields">
          <div class="field">
            <div class="f-label"><div class="f-name">管理员账号</div></div>
            <div class="f-ctrl"><code class="mono val">admin</code></div>
          </div>
          <div class="field">
            <div class="f-label"><div class="f-name">密码</div><div class="f-help muted">创建时随机生成;同时也是 Odoo 的 master password。库从生产克隆 / 备份恢复后,首次一键登录会自动把 admin 密码重置为它</div></div>
            <div class="f-ctrl pw">
              <code class="mono val">{{ showPw ? (detail.admin_password || '—') : '••••••••••••' }}</code>
              <el-button link size="small" @click="showPw = !showPw">{{ showPw ? '隐藏' : '显示' }}</el-button>
              <el-button link size="small" @click="copyPw">复制</el-button>
            </div>
          </div>
        </div>
      </el-card>

      <!-- 部署 -->
      <el-card shadow="never" class="group tone-git">
        <template #header><div class="g-head"><span class="g-icon"><el-icon><Promotion /></el-icon></span><div><div class="g-title">部署</div><div class="g-desc muted">「部署最新」/ 推送自动部署 / 企业版升级的默认行为</div></div></div></template>
        <div class="fields">
          <div class="field">
            <div class="f-label"><div class="f-name">默认动作</div><div class="f-help muted">部署新代码后执行:仅重启 / 升级指定模块 / 升级全部模块</div></div>
            <div class="f-ctrl col">
              <el-radio-group v-model="form.deploy_action" :disabled="!canEdit">
                <el-radio-button value="restart">仅重启</el-radio-button>
                <el-radio-button value="update">升级指定模块</el-radio-button>
                <el-radio-button value="update_all">升级全部模块</el-radio-button>
              </el-radio-group>
              <el-input v-if="form.deploy_action === 'update'" v-model="form.deploy_modules" :disabled="!canEdit" placeholder="模块名,逗号分隔,如 sale_custom,stock_ext" class="wide" style="margin-top: 8px" />
            </div>
          </div>
          <div class="field">
            <div class="f-label"><div class="f-name">自动部署</div><div class="f-help muted">{{ env.kind === 'production' ? '生产环境始终手动部署(历史里会标「待部署」)' : '收到该分支推送后自动部署最新提交(仓库级开关也需开启)' }}</div></div>
            <div class="f-ctrl"><el-switch v-model="form.auto_deploy" :disabled="env.kind === 'production' || !canEdit" inline-prompt active-text="开" inactive-text="关" /></div>
          </div>
        </div>
      </el-card>

      <!-- 资源上限(仅可管理) -->
      <el-card v-if="canEdit" shadow="never" class="group tone-docker">
        <template #header><div class="g-head"><span class="g-icon"><el-icon><Cpu /></el-icon></span><div><div class="g-title">资源上限</div><div class="g-desc muted">0 = 使用全局默认(内存 {{ defaults.env_memory_mb || '—' }} MB / CPU {{ defaults.env_cpus || '—' }} 核);<b>改完必须重启实例才生效</b>,重启前监控与列表仍显示旧上限;仅组织管理员可改</div></div></div></template>
        <div class="fields">
          <div class="field">
            <div class="f-label"><div class="f-name">内存 (MB)</div><div class="f-desc muted">容器内存上限,同时决定 odoo.conf 的 workers 与 limit_memory_*;保存后需重启</div></div>
            <div class="f-ctrl"><el-input-number v-model="form.mem_mb" :min="0" :step="256" :max="65536" controls-position="right" class="num" :disabled="!isOwner || !canEdit" /></div>
          </div>
          <div class="field">
            <div class="f-label"><div class="f-name">CPU (核)</div><div class="f-desc muted">容器 CPU 上限,同时参与 workers 计算;保存后需重启</div></div>
            <div class="f-ctrl"><el-input-number v-model="form.cpus" :min="0" :step="0.5" :max="64" :precision="1" controls-position="right" class="num" :disabled="!isOwner || !canEdit" /></div>
          </div>
          <div class="field">
            <div class="f-label"><div class="f-name">Odoo 日志等级</div><div class="f-desc muted">写入 odoo.conf 的 log_level,重启后生效。容器日志由 Docker 按 20MB×3 自动轮转,等级越低滚得越快;忙碌的生产实例建议 warn。留空 = 全局默认</div></div>
            <div class="f-ctrl">
              <el-select v-model="form.log_level" clearable placeholder="全局默认" class="num" :disabled="!canEdit">
                <el-option v-for="o in LOG_LEVELS" :key="o.value" :label="o.label" :value="o.value" />
              </el-select>
            </div>
          </div>
          <div class="field" v-if="env.edition !== 'enterprise'">
            <div class="f-label"><div class="f-name">附加数据库上限</div><div class="f-desc muted">本实例最多可建几个附加库(见「数据库」Tab);留空 = 组织 / 平台默认。仅平台管理员 / 组织管理员可改</div></div>
            <div class="f-ctrl"><el-input-number v-model="form.max_dbs" :min="0" :step="1" :max="100" controls-position="right" class="num" placeholder="默认" :disabled="!(isSuper || isOwner) || !canEdit" /></div>
          </div>
          <div class="field" v-if="env.kind === 'dev'">
            <div class="f-label"><div class="f-name">闲置休眠</div><div class="f-desc muted">开发实例无人访问超过该小时数自动休眠(访问域名即自动唤醒);留空 = 全局默认{{ defaults.sleep_idle_hours != null ? `(${defaults.sleep_idle_hours} 小时)` : '' }},0 = 不休眠</div></div>
            <div class="f-ctrl"><el-input-number v-model="form.sleep_idle_hours" :min="0" :step="1" :max="720" :precision="1" controls-position="right" class="num" placeholder="默认" :disabled="!canEdit" /></div>
          </div>
        </div>
      </el-card>

      <!-- odoo.conf 附加项(仅可管理;白名单) -->
      <el-card v-if="canEdit" shadow="never" class="group tone-odoo">
        <template #header><div class="g-head"><span class="g-icon"><el-icon><Document /></el-icon></span><div><div class="g-title">odoo.conf 附加项</div><div class="g-desc muted">仿 odoo.sh:配置文件由平台生成,这里只能追加 / 覆盖少数允许的选项;保存后重启实例生效</div></div></div></template>
        <div class="conf">
          <div class="conf-tip muted">
            每行一条 <code>key = value</code>;第三方模块自己的 <code>[section]</code>(如 <code>[queue_job]</code>)会原样写入。
            平台全局附加项(系统设置 → Odoo)对所有实例生效,这里的同名键会覆盖它。
            <template v-if="confKeys.superadmin">你是平台管理员:除平台契约项(数据库 / 端口 / addons_path / workers / 内存等)外可写任意键。</template>
            <template v-else-if="!confKeys.env_enabled">平台已关闭实例级附加项,当前只有全局附加项生效。</template>
          </div>
          <div v-if="confKeys.env_enabled || confKeys.superadmin" class="conf-keys">
            <span class="conf-keys-label muted">{{ confKeys.superadmin ? '常用键(点击插入):' : '允许的键(点击插入,悬停看说明):' }}</span>
            <el-tooltip v-for="(desc, k) in confKeys.whitelist" :key="k" :content="desc" placement="top" :show-after="300">
              <button type="button" class="ck" :disabled="!canEdit" @click="insertKey(k)">{{ k }}</button>
            </el-tooltip>
            <button v-for="k in confKeys.extra_allowed" :key="'x' + k" type="button" class="ck extra" :disabled="!canEdit" @click="insertKey(k)">{{ k }}</button>
          </div>
          <el-input v-model="form.extra_conf" type="textarea" :rows="8" class="conf-ta" spellcheck="false" resize="vertical"
            :disabled="!canEdit || (!confKeys.env_enabled && !confKeys.superadmin)"
            placeholder="server_wide_modules = base,web,queue_job&#10;limit_time_real = 3600&#10;&#10;[queue_job]&#10;channels = root:2" />
        </div>
      </el-card>

      <!-- 访问权限(项目级:项目内所有环境共享一份名单;仅可管理) -->
      <el-card v-if="canEdit" shadow="never" class="group tone-teal">
        <template #header><div class="g-head"><span class="g-icon"><el-icon><UserFilled /></el-icon></span><div><div class="g-title">访问权限</div><div class="g-desc muted">谁能看到 / 操作这个项目(项目内所有分支环境共用同一份名单);拥有者与超级管理员始终拥有全部权限</div></div></div></template>
        <AclEditor :env-id="projectId || env.id" :tenant-id="env.tenant_id" :readonly="!isOwnerOf" @changed="$emit('changed')" />
        <div v-if="!isOwnerOf" class="muted" style="font-size: 12px; margin-top: 8px">只有拥有者(创建者)或超级管理员可以修改名单 / 转让</div>
      </el-card>

      <!-- 平台管理员:域名 / 过期(仅可管理可见,超管可改) -->
      <el-card v-if="canEdit" shadow="never" class="group tone-platform">
        <template #header><div class="g-head"><span class="g-icon"><el-icon><Lock /></el-icon></span><div><div class="g-title">平台管理员设置</div><div class="g-desc muted">域名与过期删除仅平台管理员可修改{{ isSuper ? '' : '(当前只读)' }}</div></div></div></template>
        <div class="fields">
          <div class="field">
            <div class="f-label"><div class="f-name">域名</div><div class="f-help muted" v-if="isSuper && env.container_name">修改后需「重启」以重写 nginx 路由</div></div>
            <div class="f-ctrl">
              <el-input v-if="isSuper" v-model="form.domain" placeholder="留空自动生成:<环境>.<组织>.<基础域名>" class="wide" />
              <code v-else class="mono val">{{ env.domain || '(自动生成)' }}</code>
            </div>
          </div>
          <div class="field">
            <div class="f-label"><div class="f-name">过期删除</div><div class="f-help muted">当前:{{ expireText(env) }}{{ env.kind === 'production' ? '(生产建议永不)' : '' }}</div></div>
            <div class="f-ctrl">
              <el-select v-if="isSuper" v-model="form.expire_choice" class="num">
                <el-option v-for="c in EXPIRE_CHOICES" :key="c.value" :label="c.label" :value="c.value" />
              </el-select>
              <span v-else class="val">{{ expireText(env) }}</span>
            </div>
          </div>
        </div>
      </el-card>
    </div>

    <div v-if="canEdit" class="save-bar">
      <span class="muted small">{{ dirty ? '有未保存的修改' : '' }}</span>
      <span class="spacer" />
      <el-button :disabled="!dirty" @click="reset">放弃修改</el-button>
      <el-button type="primary" :loading="saving" :disabled="!canEdit || !dirty" @click="save">保存</el-button>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Box, User, Promotion, Cpu, Lock, UserFilled, Document } from '@element-plus/icons-vue'
import AclEditor from '../environment/AclEditor.vue'
import api from '../../api'
import { isSuper, defaults, loadDefaults, session } from '../../store'
import { KINDS, kindLabel, expireText, EXPIRE_CHOICES } from '../../utils/labels'
import { copyText } from '../../utils/clipboard'

const props = defineProps({ env: Object, projectId: Number, perms: Object, hasProduction: Boolean })
const emit = defineEmits(['changed', 'kind'])
const saving = ref(false)
const detail = ref({}); const showPw = ref(false)
const canEdit = computed(() => !!props.perms?.[props.env.kind]?.edit)
const isOwnerOf = computed(() => isSuper.value || (props.env.owner_user_id != null && props.env.owner_user_id === session.me?.id))
const isOwner = computed(() => !!props.perms?.production?.create) // 组织管理员才有生产创建权
const form = reactive({ odoo_version: '18', edition: 'community', base_mode: 'official', domain: '', expire_choice: 'keep', deploy_action: 'update_all', deploy_modules: '', auto_deploy: true, mem_mb: 0, cpus: 0, sleep_idle_hours: null, log_level: '', max_dbs: null, extra_conf: '' })
const confKeys = reactive({ env_enabled: true, superadmin: false, whitelist: {}, extra_allowed: [], blacklist: [] })
async function loadConfKeys() { try { Object.assign(confKeys, await api.get('/environments/conf-keys', { silent: true })) } catch {} }
function insertKey(k) { if (!canEdit.value) return; const cur = form.extra_conf || ''; if (new RegExp(`^\\s*${k}\\s*=`, 'm').test(cur)) return; form.extra_conf = (cur && !cur.endsWith('\n') ? cur + '\n' : cur) + `${k} = ` }
const LOG_LEVELS = [{ value: 'debug', label: 'debug(最详细)' }, { value: 'info', label: 'info' }, { value: 'warn', label: 'warn(推荐生产)' }, { value: 'error', label: 'error' }]
const saved = ref({})
const dirty = computed(() => Object.keys(form).some((k) => String(form[k]) !== String(saved.value[k])))
function snapshot() {
  const e = props.env
  return { odoo_version: String(e.odoo_version), edition: e.edition, base_mode: e.base_mode, domain: e.domain || '', expire_choice: 'keep', deploy_action: e.deploy_action || 'update_all', deploy_modules: e.deploy_modules || '', auto_deploy: !!e.auto_deploy, mem_mb: e.mem_mb || 0, cpus: e.cpus || 0, sleep_idle_hours: e.sleep_idle_hours ?? null, log_level: e.log_level || '', max_dbs: e.max_dbs ?? null, extra_conf: e.extra_conf || '' }
}
function reset() { saved.value = snapshot(); Object.assign(form, saved.value) }
async function loadDetail() { try { detail.value = await api.get(`/environments/${props.env.id}`, { silent: true }) } catch { detail.value = {} } }
const copyPw = () => copyText(detail.value.admin_password || '')
watch(() => props.env.id, () => { reset(); showPw.value = false; loadDetail() })
// 轮询刷新 env 时若本地无改动,同步最新值
watch(() => [props.env.deploy_action, props.env.deploy_modules, props.env.auto_deploy, props.env.domain, props.env.mem_mb, props.env.cpus, props.env.sleep_idle_hours, props.env.log_level, props.env.max_dbs, props.env.extra_conf], () => { if (!dirty.value) reset() })
onMounted(() => { reset(); loadDetail(); loadDefaults(); loadConfKeys() })
function canMove(k) {
  if (!props.perms?.[k]?.create) return false
  if (props.env.kind === 'production' && !props.perms?.production?.delete) return false
  if (k === 'production' && props.hasProduction) return false
  return true
}
function onKind(k) { if (k !== props.env.kind) emit('kind', k) }
// 资源上限只在建容器时写进 Docker(mem_limit / nano_cpus)与 odoo.conf(workers / limit_memory_*),
// 所以保存后必须重启(平台的「重启」= 重建容器)才生效;监控与列表读的是容器实际上限,重启前不会变。
async function askRestart(p) {
  const mem = p.mem_mb ? `${p.mem_mb} MB` : '全局默认'
  const cpu = p.cpus ? `${p.cpus} 核` : '全局默认'
  try {
    await ElMessageBox.confirm(`资源上限已保存:内存 ${mem}、CPU ${cpu}。\n需要重启实例才会真正生效(重启 = 重建容器,约 15~30 秒,数据不受影响)。重启前监控与实例列表仍显示旧的上限。`,
      '需要重启才生效', { type: 'warning', confirmButtonText: '现在重启', cancelButtonText: '稍后自己重启' })
  } catch { return }
  try { await api.post(`/environments/${props.env.id}/restart`); ElMessage.success('重启中,完成后新的上限生效'); emit('changed') } catch {}
}
async function save() {
  saving.value = true
  try {
    const payload = { odoo_version: form.odoo_version, edition: form.edition, base_mode: form.base_mode, deploy_action: form.deploy_action, deploy_modules: form.deploy_modules || null, auto_deploy: form.auto_deploy, mem_mb: form.mem_mb || null, cpus: form.cpus || null, sleep_idle_hours: form.sleep_idle_hours ?? null, log_level: form.log_level || null }
    if (confKeys.env_enabled || isSuper.value) payload.extra_conf = (form.extra_conf || '').trim() || null
    if (isSuper.value || isOwner.value) payload.max_dbs = form.max_dbs ?? null
    if (isSuper.value) {
      payload.domain = form.domain || null
      if (form.expire_choice !== 'keep') payload.expire_days = Number(form.expire_choice)
    }
    const before = { mem_mb: props.env.mem_mb || null, cpus: props.env.cpus || null }
    await api.put(`/environments/${props.env.id}`, payload)
    ElMessage.success('已保存'); form.expire_choice = 'keep'; saved.value = { ...form }; emit('changed')
    if (props.env.container_name && (payload.mem_mb !== before.mem_mb || payload.cpus !== before.cpus)) await askRestart(payload)
  } catch {} finally { saving.value = false }
}
</script>

<style scoped>
.settings { max-width: 960px; }
.groups { display: grid; gap: 14px; min-width: 0; }
.group { border-left: 3px solid var(--tone); }
.group :deep(.el-card__header) { background: linear-gradient(90deg, var(--tone-bg), #fff 70%); padding: 12px 18px; }
.group :deep(.el-card__body) { padding: 4px 18px; }
.g-head { display: flex; align-items: center; gap: 12px; }
.g-icon { width: 32px; height: 32px; border-radius: 8px; background: var(--tone); color: #fff; display: inline-flex; align-items: center; justify-content: center; font-size: 16px; box-shadow: 0 3px 8px -3px var(--tone); flex: none; }
.g-title { font-weight: 700; font-size: 14.5px; }
.g-desc { font-size: 12px; font-weight: 400; margin-top: 1px; }
.tone-platform { --tone: #714b67; --tone-bg: #f5eff3; }
.tone-env      { --tone: #2563eb; --tone-bg: #eef4ff; }
.tone-docker   { --tone: #4f46e5; --tone-bg: #eef2ff; }
.tone-odoo     { --tone: #0d9488; --tone-bg: #ecfdf8; }
.tone-git      { --tone: #ea580c; --tone-bg: #fff4ec; }
.fields { display: flex; flex-direction: column; }
.field { display: grid; grid-template-columns: minmax(0, 1fr) 420px; gap: 24px; align-items: center; padding: 13px 0; border-bottom: 1px solid var(--line-2); }
.field:last-child { border-bottom: none; }
.f-name { font-weight: 600; font-size: 14px; }
.f-help { font-size: 12.5px; margin-top: 2px; line-height: 1.5; }
.f-ctrl { display: flex; justify-content: flex-end; align-items: center; gap: 6px; }
.f-ctrl.col { flex-direction: column; align-items: flex-end; }
.f-ctrl.pw { gap: 4px; }
.wide { width: 100%; }
.num { width: 180px; }
.val { font-size: 13.5px; color: var(--text); }
code.val { background: var(--surface-2); border: 1px solid var(--line-2); border-radius: 6px; padding: 3px 8px; }
.mono { font-family: ui-monospace, Menlo, Consolas, monospace; }
.save-bar { position: sticky; bottom: 0; margin-top: 14px; padding: 10px 14px; background: rgba(255,255,255,.92); backdrop-filter: blur(6px); border: 1px solid var(--line); border-radius: 10px; display: flex; align-items: center; gap: 8px; }
.spacer { flex: 1; }
.small { font-size: 12px; }
@media (max-width: 760px) {
  .field { grid-template-columns: 1fr; gap: 8px; }
  .f-ctrl, .f-ctrl.col { justify-content: flex-start; align-items: flex-start; }
  .num { width: 100%; }
}
.ro-tip { margin-bottom: 14px; }
.conf { display: flex; flex-direction: column; gap: 10px; padding: 12px 0 14px; }
.conf-tip { font-size: 12.5px; line-height: 1.6; }
.conf-tip code { background: var(--surface-2); border: 1px solid var(--line-2); border-radius: 4px; padding: 0 5px; font-size: 12px; }
.conf-keys { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
.conf-keys-label { font-size: 12px; margin-right: 2px; }
.ck { font: 12px/1.6 ui-monospace, Menlo, Consolas, monospace; color: var(--text); background: var(--surface-2); border: 1px solid var(--line-2); border-radius: 999px; padding: 0 9px; cursor: pointer; transition: border-color .15s, color .15s, background .15s; }
.ck:hover:not(:disabled) { border-color: var(--tone); color: var(--tone); background: var(--tone-bg); }
.ck:disabled { cursor: not-allowed; opacity: .6; }
.ck.extra { border-style: dashed; }
.conf-ta { width: 100%; }
.conf-ta :deep(textarea) { font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 12.5px; line-height: 1.55; padding: 10px 12px; }
</style>
