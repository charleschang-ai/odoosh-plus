<template>
  <!-- 历史 = 构建时间线:分支提交流(镜像 git log)× 部署记录;左侧状态轨道按部署状态着色;行可展开看部署日志(进行中走 SSE) -->
  <div class="hist">
    <div class="bar">
      <span class="muted">{{ env ? `当前运行 ${shortSha(env.code_commit)}` : '该分支尚未建环境,只显示提交' }}<template v-if="env && env.kind !== 'production'"> · 推送后{{ env.auto_deploy ? '自动部署' : '不自动部署' }}</template><template v-else-if="env"> · 生产环境需手动部署</template></span>
      <span class="spacer" />
      <el-button link size="small" :icon="Refresh" :loading="loading" @click="load(true)">从远端刷新</el-button>
      <el-button v-if="env && canDeploy && env.container_name" type="primary" size="small" :disabled="busy" @click="deploy(null)">部署最新</el-button>
    </div>
    <div v-if="error" class="err">{{ error }}</div>
    <div class="timeline" v-loading="loading">
      <div v-for="(c, idx) in items" :key="c.sha" class="row" :class="[`rail-${railOf(c)}`, { current: c.is_current, open: expanded === c.sha, first: idx === 0, last: idx === items.length - 1 }]">
        <div class="rail"><i class="dot" /></div>
        <div class="body" @click="toggle(c)">
          <div class="line1">
            <span class="msg" :title="c.message">{{ c.message || '(无提交信息)' }}</span>
            <span class="badges">
              <el-tag v-if="c.is_current" size="small" type="success" effect="dark" :style="env?.status === 'running' ? 'cursor: pointer' : ''" title="点击免密登录进入 Odoo" @click.stop="env?.status === 'running' && emit('open')">当前运行 ↗</el-tag>
              <template v-if="c.deployment">
                <el-tag size="small" :type="depType(c.deployment.status)" effect="plain">{{ depLabel(c.deployment.status) }}</el-tag>
                <span v-if="c.deployment.status === 'running' && env && isBusy(env)" class="prog"><el-progress :percentage="env.progress || 0" :stroke-width="5" :show-text="false" striped striped-flow style="width: 90px" /><b>{{ env.progress || 0 }}%</b></span>
              </template>
              <span v-else-if="env && env.container_name && !c.is_current && idx === 0" class="pending">待部署</span>
              <span v-else-if="env && !c.is_current" class="muted small">未部署</span>
            </span>
          </div>
          <div class="line2 muted">
            <span class="mono">{{ shortSha(c.sha) }}</span>
            <span class="sep">·</span><span>{{ c.author }}</span>
            <span class="sep">·</span><span :title="fmtDate(c.committed_at)">{{ ago(c.committed_at) }}</span>
            <template v-if="c.deployment">
              <span class="sep">·</span><span>{{ triggerLabel(c.deployment.trigger) }}触发</span>
              <span v-if="c.deployment.action" class="sep">·</span><span v-if="c.deployment.action">{{ actionShort(c.deployment.action, c.deployment.modules) }}</span>
              <span v-if="c.deployment.duration != null" class="sep">·</span><span v-if="c.deployment.duration != null">耗时 {{ shortDuration(c.deployment.duration) }}</span>
              <template v-if="dbSummary(c.deployment)"><span class="sep">·</span><span :class="{ 'warn-text': dbSummary(c.deployment).failed }" :title="dbSummary(c.deployment).title">{{ dbSummary(c.deployment).text }}</span></template>
              <span v-if="c.deployment.status === 'running' && env?.status_message" class="sep">·</span><span v-if="c.deployment.status === 'running' && env?.status_message" class="warn-text">{{ env.status_message }}</span>
            </template>
          </div>
        </div>
        <div class="acts" @click.stop>
          <el-button v-if="c.deployment" link size="small" @click="toggle(c)">{{ expanded === c.sha ? '收起日志' : '日志' }}</el-button>
          <el-button v-if="env && canDeploy && env.container_name && !c.is_current && idx === 0" link type="primary" size="small" :disabled="busy" @click="deploy(c.sha)">部署此提交</el-button>
          <el-tooltip v-else-if="env && canDeploy && env.container_name && !c.is_current" content="只能部署分支最新提交;要回到这个提交请在 Git 里 revert / reset 后推送" :show-after="200"><span class="muted small" style="cursor: help">历史提交</span></el-tooltip>
        </div>
        <div v-if="expanded === c.sha && c.deployment && env" class="panel">
          <DeployLog :env-id="env.id" :dep="c.deployment" @finished="onFinished" />
        </div>
      </div>
      <div v-if="!items.length && !loading" class="muted" style="padding: 20px; text-align: center">暂无提交</div>
      <div v-if="items.length >= limit" style="text-align: center; padding: 8px"><el-button link size="small" @click="limit += 30; load(false)">加载更多</el-button></div>
    </div>

    <DeployDialog v-model="dlg" :env="env" :commit="dlgSha" :pick-commit="false" @deployed="emit('changed')" />
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { Refresh } from '@element-plus/icons-vue'
import api from '../../api'
import DeployDialog from '../environment/DeployDialog.vue'
import DeployLog from '../environment/DeployLog.vue'
import { usePolling } from '../../composables/usePolling'
import { isBusy, depLabel, depType, triggerLabel, actionShort } from '../../utils/labels'
import { ago, fmtDate, shortSha, shortDuration } from '../../utils/format'

const props = defineProps({ projectId: Number, branch: String, env: Object, perms: Object })
const emit = defineEmits(['changed', 'open'])
const items = ref([]); const loading = ref(false); const error = ref(''); const limit = ref(30)
const busy = computed(() => isBusy(props.env))
const canDeploy = computed(() => !!props.env && !!props.perms?.[props.env.kind]?.deploy)
const expanded = ref(null)

async function load(refresh = false) {
  loading.value = true
  try {
    const url = props.env ? `/environments/${props.env.id}/commits` : `/projects/${props.projectId}/branches/${encodeURIComponent(props.branch)}/commits`
    const r = await api.get(url, { params: { limit: limit.value, refresh } })
    items.value = r.items || []; error.value = r.error || ''
  } catch { items.value = [] } finally { loading.value = false }
}
watch(() => [props.env?.id, props.branch], () => { limit.value = 30; expanded.value = null; load() })
// 部署进行中时定期刷新(部署完成后 code_commit 变化,当前标记要跟着变)
let lastCommit = null; let lastBusy = false
watch(() => [props.env?.code_commit, busy.value], ([c, b]) => { if ((c !== lastCommit && lastCommit !== null) || (lastBusy && !b)) load(); lastCommit = c; lastBusy = b })
const poll = usePolling(() => load(false), { interval: 6000, immediate: false, when: () => busy.value })
onMounted(() => { lastCommit = props.env?.code_commit ?? null; load(); poll.start() })

// 多库部署:每库 -u 结果 {库名: success|failed|skipped} → 「3 个库:2 成功 1 失败」
function dbSummary(d) {
  if (!d?.db_results) return null
  let r; try { r = JSON.parse(d.db_results) } catch { return null }
  const names = Object.keys(r); if (names.length < 2) return null
  const ok = names.filter((n) => r[n] === 'success').length, failed = names.filter((n) => r[n] === 'failed').length, skipped = names.filter((n) => r[n] === 'skipped').length
  return { failed, text: `${names.length} 个库:${ok} 成功${failed ? ` ${failed} 失败` : ''}${skipped ? ` ${skipped} 跳过` : ''}`, title: names.map((n) => `${n}: ${r[n]}`).join('\n') }
}
const railOf = (c) => c.is_current ? 'current' : c.deployment?.status === 'success' ? 'success' : c.deployment?.status === 'failed' ? 'failed' : c.deployment?.status === 'running' ? 'running' : c.deployment?.status === 'queued' ? 'queued' : 'none'
function toggle(c) { if (!c.deployment) return; expanded.value = expanded.value === c.sha ? null : c.sha }
function onFinished() { load(); emit('changed') }

const dlg = ref(false); const dlgSha = ref(null)
function deploy(sha) { dlgSha.value = sha; dlg.value = true }
</script>

<style scoped>
.bar { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; font-size: 12.5px; flex-wrap: wrap; }
.spacer { flex: 1; }
.err { color: var(--danger); font-size: 12.5px; margin-bottom: 8px; }
.timeline { border: 1px solid var(--line-2); border-radius: 10px; overflow: hidden; }
.row { display: grid; grid-template-columns: 34px minmax(0, 1fr) auto; align-items: center; border-bottom: 1px solid var(--line-2); position: relative; --rail: #cbd5e1; }
.row:last-child { border-bottom: none; }
.row.current { background: #f0fdf4; }
.row.rail-current { --rail: #10b981; }
.row.rail-success { --rail: #10b981; }
.row.rail-failed { --rail: #ef4444; }
.row.rail-running { --rail: #f59e0b; }
.row.rail-queued { --rail: #94a3b8; }
.rail { align-self: stretch; position: relative; display: flex; align-items: center; justify-content: center; }
.rail::before { content: ''; position: absolute; left: 50%; top: 0; bottom: 0; width: 2px; margin-left: -1px; background: var(--line); }
.row.first .rail::before { top: 50%; }
.row.last .rail::before { bottom: 50%; }
.rail .dot { width: 11px; height: 11px; border-radius: 50%; background: #fff; border: 2px solid var(--rail); box-sizing: border-box; position: relative; z-index: 1; }
.row.rail-current .dot, .row.rail-failed .dot, .row.rail-running .dot { background: var(--rail); }
.row.rail-current .dot { box-shadow: 0 0 0 3px #d1fae5; }
.row.rail-running .dot { animation: pulse 1.2s infinite; }
@keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(245,158,11,.5) } 70% { box-shadow: 0 0 0 6px transparent } 100% { box-shadow: 0 0 0 0 transparent } }
.body { padding: 10px 10px 10px 4px; min-width: 0; cursor: pointer; }
.row:not(.rail-none) .body:hover .msg { color: var(--brand-600); }
.line1 { display: flex; align-items: center; gap: 10px; min-width: 0; }
.msg { font-size: 13.5px; font-weight: 600; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0; }
.badges { display: inline-flex; align-items: center; gap: 6px; flex: none; }
.prog { display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-variant-numeric: tabular-nums; }
.pending { font-size: 11px; font-weight: 600; background: var(--warn-bg); color: var(--warn); border-radius: 999px; padding: 1px 7px; }
.line2 { font-size: 12px; margin-top: 3px; display: flex; flex-wrap: wrap; align-items: center; gap: 4px; }
.sep { color: var(--text-3); }
.warn-text { color: var(--warn); }
.acts { white-space: nowrap; padding: 0 12px; }
.panel { grid-column: 1 / -1; padding: 0 14px 12px 34px; }
.small { font-size: 12px; }
</style>
