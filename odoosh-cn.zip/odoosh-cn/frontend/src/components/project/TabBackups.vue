<template>
  <!-- 备份:该环境的备份列表 + 新建 / 恢复(复用备份模块);测试/开发多一个「从生产刷新数据」 -->
  <div>
    <div class="bar">
      <span class="muted small">备份为 Odoo 官方 zip 格式(dump.sql + filestore,另附平台加速恢复用的 dump.pgc),可恢复到任一同组织环境;下载需「可管理」权限。</span>
      <span class="spacer" />
      <el-button v-if="env.kind !== 'production' && hasProduction && perms?.[env.kind]?.restore" size="small" :disabled="busy || !env.db_name" @click="refreshFromProd">从生产刷新数据</el-button>
      <el-button size="small" :icon="Refresh" @click="load">刷新</el-button>
      <el-button v-if="perms?.[env.kind]?.restore" size="small" :icon="Upload" :disabled="busy || !env.db_name" @click="impDlg = true">导入备份</el-button>
      <el-button v-if="perms?.[env.kind]?.backup" size="small" :icon="Setting" @click="cfgOpen = !cfgOpen">备份设置</el-button>
      <el-button v-if="perms?.[env.kind]?.backup" type="primary" size="small" :disabled="busy || !env.db_name" @click="create">新建备份</el-button>
    </div>
    <!-- 实例备份设置:远程目标(推送到用户自己的服务器 / NAS)+ 自动备份覆盖 -->
    <el-card v-if="cfgOpen" shadow="never" class="cfg-card">
      <template #header><span style="font-weight: 600">本环境备份设置</span><span class="muted small" style="margin-left: 8px">远程目标与自动备份;每个库的每份备份都按此推送</span></template>
      <EnvBackupConfig :env="env" :editable="isSuper || !!perms?.[env.kind]?.edit" @saved="load(true)" />
    </el-card>

    <!-- 导入备份:上传 Odoo 数据库管理器导出的 zip → 立即恢复成本环境的数据库(替换) -->
    <el-dialog v-model="impDlg" title="导入备份" width="560px" @closed="impFile = null">
      <el-alert type="info" :closable="false" show-icon style="margin-bottom: 12px"
        title="支持 Odoo 数据库管理器导出的 zip(含 dump.sql + filestore/)或本平台的备份文件。导入后会用它替换本环境的数据库与 filestore(恢复前自动备份一次),环境短暂停机。" />
      <div class="drop" :class="{ has: !!impFile }" @click="$refs.fileInput.click()" @dragover.prevent @drop.prevent="onDrop">
        <input ref="fileInput" type="file" accept=".zip,application/zip" style="display: none" @change="impFile = $event.target.files[0] || null" />
        <template v-if="impFile"><b>{{ impFile.name }}</b><span class="muted small" style="margin-left: 8px">{{ fmtSize(impFile.size) }}</span></template>
        <template v-else>点击选择或拖入 .zip 备份文件</template>
      </div>
      <el-form label-width="120px" style="margin-top: 12px">
        <el-form-item label="导入后立即恢复"><el-switch v-model="impRestore" /><span class="hint">关闭则只上传到备份列表,稍后再点「恢复」</span></el-form-item>
        <el-form-item v-if="impRestore" label="中性化"><el-switch v-model="impNeutralize" /><span class="hint">停用定时任务 / 外发邮件 / 支付;非生产环境建议开启</span></el-form-item>
        <el-form-item label="备注"><el-input v-model="impNote" maxlength="200" placeholder="可选" /></el-form-item>
      </el-form>
      <el-progress v-if="impUploading" :percentage="impPct" :stroke-width="8" style="margin-top: 4px" />
      <template #footer>
        <el-button @click="impDlg = false">取消</el-button>
        <el-button type="primary" :loading="impUploading" :disabled="!impFile" @click="doImport">{{ impRestore ? '上传并恢复' : '上传' }}</el-button>
      </template>
    </el-dialog>
    <!-- 新建备份:备份位置(本地 / 远程)+ 多库实例可选目标库 -->
    <el-dialog v-model="bkDlg" :title="`备份 — ${env.branch || env.name}`" width="500px">
      <el-form label-width="84px">
        <el-form-item v-if="dbs.length > 1" label="数据库"><el-select v-model="bkDb" style="width: 100%"><el-option v-for="d in dbs" :key="d.id ?? 0" :value="d.id ?? 0" :label="d.is_primary ? `主库(${d.db_name})` : `${d.name}(${d.db_name})`" /></el-select></el-form-item>
        <el-form-item label="备份位置">
          <el-radio-group v-model="bkLocation">
            <el-radio-button value="local">仅本地</el-radio-button>
            <el-radio-button value="remote">推送到远程</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <template v-if="bkLocation === 'remote'">
          <el-form-item label="远程目标">
            <div style="width: 100%">
              <el-select v-if="bkTargets.length" v-model="bkTargetIds" multiple style="width: 100%" placeholder="选择要推送到的目标">
                <el-option v-for="t in bkTargets" :key="t.id" :value="t.id" :label="`${t.name}(${kindShort(t.kind)}) · ${t.describe}`" :disabled="!t.enabled" />
              </el-select>
              <div v-else class="muted small">你在本组织还没有远程备份目标,<router-link to="/backups">去「备份与恢复」添加</router-link>。</div>
              <div class="muted tiny" style="margin-top:4px">备份先落本地,完成后再推送到所选目标;可在此临时改选,不影响实例的默认配置。</div>
            </div>
          </el-form-item>
        </template>
        <el-form-item label="备注"><el-input v-model="bkNote" maxlength="200" placeholder="如:上线前备份" /></el-form-item>
      </el-form>
      <template #footer><el-button @click="bkDlg = false">取消</el-button><el-button type="primary" :disabled="bkLocation === 'remote' && !bkTargetIds.length" @click="doCreate">开始备份</el-button></template>
    </el-dialog>
    <el-dialog v-model="rsDlg" :title="`恢复备份 #${rsRow?.id || ''}`" width="520px">
      <el-form label-width="90px">
        <el-form-item label="恢复到"><el-select v-model="rsDb" style="width: 100%"><el-option v-for="d in dbs" :key="d.id ?? 0" :value="d.id ?? 0" :label="d.is_primary ? `主库(${d.db_name})` : `${d.name}(${d.db_name})`" /></el-select></el-form-item>
        <el-form-item label="中性化"><el-switch v-model="rsNeutralize" /><span class="hint">停用定时任务 / 外发邮件 / 支付</span></el-form-item>
        <el-form-item label="恢复前备份"><el-switch v-model="rsBefore" /></el-form-item>
      </el-form>
      <div class="muted small">{{ rsDb ? '目标为附加库:只覆盖该库,实例其他库不受影响、容器不停。' : '目标为主库:覆盖主库数据与 filestore,期间实例短暂停机。' }}</div>
      <template #footer><el-button @click="rsDlg = false">取消</el-button><el-button type="warning" @click="doRestore">恢复</el-button></template>
    </el-dialog>
    <transition name="obar">
      <div v-if="bkSel.length" class="bk-bar">
        <span>已选 <b>{{ bkSel.length }}</b> 个备份</span>
        <el-button size="small" type="danger" plain :icon="Delete" @click="bulkDelete">批量删除</el-button>
        <el-button size="small" text @click="clearBkSel">取消选择</el-button>
      </div>
    </transition>
    <el-table ref="bkTable" :data="rows" v-loading="loading" size="small" stripe empty-text="暂无备份" :row-key="(r) => r.id" @selection-change="onBkSel">
      <el-table-column type="selection" width="38" :selectable="(r) => r.status !== 'running'" reserve-selection />
      <el-table-column prop="id" label="ID" width="60" />
      <el-table-column v-if="dbs.length > 1" label="数据库" width="110" show-overflow-tooltip><template #default="{ row }">{{ dbLabel(row) }}</template></el-table-column>
      <el-table-column label="类型" width="90"><template #default="{ row }"><el-tag size="small" effect="plain" :type="backupKindType(row.kind)">{{ backupKindLabel(row.kind) }}</el-tag></template></el-table-column>
      <el-table-column label="状态" width="90"><template #default="{ row }"><el-tag size="small" :type="backupStatusType(row.status)"><el-icon v-if="row.status === 'running'" class="is-loading" style="margin-right: 3px"><Loading /></el-icon>{{ backupStatusLabel(row.status) }}</el-tag></template></el-table-column>
      <el-table-column label="说明" min-width="180" show-overflow-tooltip><template #default="{ row }"><span :style="row.status === 'failed' ? 'color: var(--danger)' : ''">{{ row.status === 'done' ? (row.note || '') : row.message }}</span></template></el-table-column>
      <el-table-column label="大小" width="90"><template #default="{ row }">{{ row.status === 'done' ? fmtSize(row.size_bytes) : '-' }}</template></el-table-column>
      <el-table-column prop="created_by" label="操作人" width="90" />
      <el-table-column label="时间" width="140"><template #default="{ row }">{{ fmtDate(row.created_at) }}</template></el-table-column>
      <el-table-column label="操作" width="180" fixed="right">
        <template #default="{ row }">
          <el-button v-if="isSuper || env.my_role === 'owner'" link type="primary" size="small" :disabled="row.status !== 'done'" @click="download(row)">下载</el-button>
          <el-button v-if="perms?.[env.kind]?.restore" link type="warning" size="small" :disabled="row.status !== 'done' || busy" @click="restore(row)">恢复</el-button>
          <el-button v-if="perms?.[env.kind]?.backup" link type="danger" size="small" :disabled="row.status === 'running'" @click="remove(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="muted small" style="margin-top: 8px">更多(上传备份、跨环境恢复、自动备份策略)见 <router-link to="/backups">备份与恢复</router-link>。</div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Refresh, Loading, Upload, Setting, Delete } from '@element-plus/icons-vue'
import api from '../../api'
import { isSuper } from '../../store'
import { usePolling } from '../../composables/usePolling'
import { confirmDanger } from '../../utils/confirm'
import { isBusy, backupKindLabel, backupKindType, backupStatusLabel, backupStatusType } from '../../utils/labels'
import { fmtDate, fmtSize } from '../../utils/format'
import { downloadBackup } from '../../utils/download'
import EnvBackupConfig from '../EnvBackupConfig.vue'

const props = defineProps({ env: Object, perms: Object, hasProduction: Boolean, projectId: Number, active: { type: Boolean, default: true } })
const emit = defineEmits(['changed'])
const rows = ref([]); const loading = ref(false)
const cfgOpen = ref(false)
const busy = computed(() => isBusy(props.env))
async function load(silent = false) {
  if (!silent) loading.value = true
  try { rows.value = await api.get('/backups', { params: { environment_id: props.env.id }, silent }) } catch {} finally { loading.value = false }
}
watch(() => props.env.id, () => { load(); loadDbs() })
watch(() => props.env.extra_db_count, () => loadDbs())
const poll = usePolling(() => load(true), { interval: 4000, immediate: false, when: () => props.active && rows.value.some((r) => r.status === 'running') })
onMounted(() => { load(); loadDbs(); poll.start() })
async function remove(row) {
  if (!(await confirmDanger({ title: '删除备份', message: `删除备份 #${row.id}(${fmtDate(row.created_at)})?文件将被移除,不可恢复。` }))) return
  try { await api.delete(`/backups/${row.id}`); ElMessage.success('已删除'); load(true) } catch {}
}
const bkTable = ref(null); const bkSel = ref([])
function onBkSel(rows) { bkSel.value = rows }
function clearBkSel() { bkTable.value?.clearSelection(); bkSel.value = [] }
async function bulkDelete() {
  const ids = bkSel.value.map((b) => b.id)
  if (!(await confirmDanger({ title: `批量删除 ${ids.length} 个备份`, message: '选中的备份文件将被移除,不可恢复。正在运行 / 被恢复占用 / 无权删除的会自动跳过。' }))) return
  try {
    const r = await api.post('/backups/bulk-delete', { backup_ids: ids })
    ElMessage.success(`已删除 ${r.succeeded}${r.skipped ? ` · 跳过 ${r.skipped}` : ''}${r.failed ? ` · 失败 ${r.failed}` : ''}`)
    clearBkSel(); load(true)
  } catch {}
}

// ---- 多库:实例的库列表(主库 id=0)----
const dbs = ref([])
async function loadDbs() {
  try { const r = await api.get(`/environments/${props.env.id}/databases`, { silent: true }); dbs.value = (r.items || []).filter((d) => d.status === 'ready' || d.is_primary) } catch { dbs.value = [] }
}
const dbLabel = (row) => { if (!row.database_id) return '主库'; const d = dbs.value.find((x) => x.id === row.database_id); return d ? d.name : (row.db_name || '附加库') }
const bkDlg = ref(false); const bkDb = ref(0); const bkNote = ref('')
const bkLocation = ref('local'); const bkTargetIds = ref([]); const bkTargets = ref([])
const kindShort = (k) => ({ s3: 'S3', sftp: 'SFTP', webdav: 'DAV' }[k] || k)
async function loadBkTargets() {
  try { const c = await api.get(`/environments/${props.env.id}/backup-config`, { silent: true }); bkTargets.value = (c.targets || []).filter((t) => t.mine); bkTargetIds.value = (c.target_ids || []).filter((id) => bkTargets.value.some((t) => t.id === id)) } catch { bkTargets.value = [] }
}
const rsDlg = ref(false); const rsRow = ref(null); const rsDb = ref(0); const rsNeutralize = ref(props.env.kind !== 'production'); const rsBefore = ref(true)
async function create() {
  bkDb.value = 0; bkNote.value = ''; bkLocation.value = 'local'
  bkDlg.value = true
  loadBkTargets()
}
async function doCreate() {
  try {
    await api.post('/backups', { environment_id: props.env.id, database_id: bkDb.value || null, note: bkNote.value || null, include_filestore: true, location: bkLocation.value, target_ids: bkLocation.value === 'remote' ? bkTargetIds.value : [] })
    ElMessage.success(bkLocation.value === 'remote' ? '备份已开始,完成后推送到远程' : '备份已开始'); bkDlg.value = false; load(true)
  } catch {}
}
async function restore(row) {
  if (dbs.value.length > 1) { rsRow.value = row; rsDb.value = row.database_id && dbs.value.some((d) => d.id === row.database_id) ? row.database_id : 0; rsNeutralize.value = props.env.kind !== 'production'; rsBefore.value = true; rsDlg.value = true; return }
  try {
    await ElMessageBox.confirm(`用备份 #${row.id}(${fmtDate(row.created_at)})覆盖「${props.env.branch || props.env.name}」的数据库与 filestore${props.env.kind !== 'production' ? ',并中性化' : ''};恢复前会先自动备份一次。期间环境短暂停机。`, '恢复备份', { type: 'warning', confirmButtonText: '恢复' })
  } catch { return }
  await submitRestore(row, null, props.env.kind !== 'production', true)
}
async function doRestore() { const row = rsRow.value; if (!row) return; rsDlg.value = false; await submitRestore(row, rsDb.value || null, rsNeutralize.value, rsBefore.value) }
async function submitRestore(row, databaseId, neutralize, backupBefore) {
  let force = false
  if (row.odoo_version && String(row.odoo_version) !== String(props.env.odoo_version)) {
    const ok = await confirmDanger({ title: 'Odoo 版本不一致', message: `备份来自 Odoo ${row.odoo_version},本环境是 Odoo ${props.env.odoo_version}。跨大版本恢复后 Odoo 通常无法直接启动,需要另行升级数据库。确定仍要恢复?`, confirmText: '仍然恢复' })
    if (!ok) return
    force = true
  }
  try { await api.post(`/backups/${row.id}/restore`, { environment_id: props.env.id, database_id: databaseId, neutralize, backup_before: backupBefore, force }); ElMessage.success('恢复已开始'); emit('changed'); load() } catch {}
}
async function refreshFromProd() {
  try { await ElMessageBox.confirm(`用生产环境的数据覆盖「${props.env.branch}」的数据库与 filestore,并中性化;期间该环境短暂停机。`, '从生产刷新数据', { type: 'warning', confirmButtonText: '刷新' }) } catch { return }
  try { await api.post(`/projects/${props.projectId}/environments/${props.env.id}/refresh-from-production`); ElMessage.success('开始刷新,完成后会提示'); emit('changed') } catch {}
}
// ---- 导入 ----
const impDlg = ref(false); const impFile = ref(null); const impRestore = ref(true); const impNeutralize = ref(props.env.kind !== 'production'); const impNote = ref('')
const impUploading = ref(false); const impPct = ref(0)
function onDrop(e) { const f = e.dataTransfer?.files?.[0]; if (f) impFile.value = f }
async function doImport() {
  if (!impFile.value) return
  impUploading.value = true; impPct.value = 0
  try {
    // 直传:请求体就是文件本身(不经 multipart,后端边收边写盘,不再双写)
    const b = await api.put('/backups/upload-stream', impFile.value, { params: { tenant_id: props.env.tenant_id, environment_id: props.env.id, note: impNote.value || `导入:${impFile.value.name}`, filename: impFile.value.name }, headers: { 'Content-Type': 'application/zip' }, timeout: 0, onUploadProgress: (ev) => { if (ev.total) impPct.value = Math.round(ev.loaded / ev.total * 100) } })
    if (impRestore.value) {
      await api.post(`/backups/${b.id}/restore`, { environment_id: props.env.id, neutralize: impNeutralize.value, backup_before: true })
      ElMessage.success('已上传,开始恢复;完成后会提示'); emit('changed')
    } else ElMessage.success('已上传到备份列表')
    impDlg.value = false; load()
  } catch {} finally { impUploading.value = false }
}
async function download(row) {
  try {
    await downloadBackup(api, row.id)  // 直链 + 票据:浏览器原生流式下载,不占标签页内存
  } catch {}
}
</script>

<style scoped>
.bk-bar { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; padding: 6px 12px; background: var(--brand-50, var(--surface-2)); border: 1px solid var(--brand-200, var(--line-2)); border-radius: 8px; font-size: 13px; }
.bk-bar b { color: var(--brand-600); }
.obar-enter-active, .obar-leave-active { transition: opacity .18s, transform .18s; } .obar-enter-from, .obar-leave-to { opacity: 0; transform: translateY(-6px); }
.cfg-card { margin-bottom: 10px; }
.bar { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; }
.spacer { flex: 1; }
.small { font-size: 12px; }
.hint { font-size: 12px; color: var(--text-3); margin-left: 8px; }
.drop { border: 2px dashed var(--line); border-radius: 10px; padding: 22px; text-align: center; color: var(--text-3); cursor: pointer; background: var(--surface-2); }
.drop:hover, .drop.has { border-color: var(--brand); color: var(--text); background: #fff; }
</style>
