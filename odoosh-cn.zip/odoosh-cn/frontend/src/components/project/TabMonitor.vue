<template>
  <!-- 监控:CPU / 内存 / 网络 / 磁盘 IO 曲线(后台每 10s 采样,保留 7 天)+ 当前值 + filestore / 数据库大小 -->
  <div class="tmon">
    <div class="bar">
      <el-radio-group v-model="range" size="small">
        <el-radio-button v-for="r in RANGES" :key="r.v" :value="r.v">{{ r.l }}</el-radio-button>
      </el-radio-group>
      <span class="spacer" />
      <span class="muted small" v-if="latest">采样 {{ ago(latest.ts * 1000) }} · 每 10 秒一次 · 保留 7 天</span>
      <span class="muted small" v-else-if="env.status !== 'running'">实例未运行,不采样</span>
      <el-button size="small" :icon="Refresh" :loading="loading" @click="load">刷新</el-button>
    </div>

    <!-- 当前值 -->
    <div class="tiles">
      <div class="tile"><div class="t-l">CPU</div><div class="t-v">{{ latest ? latest.cpu_percent.toFixed(1) : '—' }}<span class="u">%</span></div><div class="t-s muted">{{ env.cpus ? `上限 ${env.cpus} 核` : '' }}</div></div>
      <div class="tile"><div class="t-l">内存</div><div class="t-v">{{ latest ? fmtSize(latest.mem_usage) : '—' }}</div><div class="t-s muted">{{ latest?.mem_limit ? `${latest.mem_percent}% · 上限 ${fmtSize(latest.mem_limit)}` : '' }}</div></div>
      <div class="tile"><div class="t-l">进程数</div><div class="t-v">{{ latest?.pids ?? '—' }}</div><div class="t-s muted">{{ latest?.started_at ? `运行 ${uptime(latest.started_at)}` : '' }}</div></div>
      <div class="tile"><div class="t-l">Filestore</div><div class="t-v">{{ disk?.latest?.filestore != null ? fmtSize(disk.latest.filestore) : (latest?.disk_filestore != null ? fmtSize(latest.disk_filestore) : '—') }}</div><div class="t-s muted">每 5 分钟统计</div></div>
      <div class="tile"><div class="t-l">数据库</div><div class="t-v">{{ disk?.latest?.db != null ? fmtSize(disk.latest.db) : (latest?.disk_db != null ? fmtSize(latest.disk_db) : '—') }}</div><div class="t-s muted">{{ env.db_name || '' }}</div></div>
    </div>

    <div v-if="!points.length && !loading" class="empty muted">该时间范围内暂无采样数据{{ env.status === 'running' ? ',稍后刷新' : '(实例运行时才采样)' }}</div>
    <div v-else class="charts">
      <Chart title="CPU 使用率" unit="%" :points="points" :series="[{ key: 'cpu', label: 'CPU', color: 'var(--brand)' }]" :y-max="cpuMax" :fmt="(v) => v.toFixed(1) + '%'" />
      <Chart title="内存" :points="points" :series="[{ key: 'mem', label: '已用', color: '#2563eb' }]" :y-max="memMax" :fmt="fmtSize" :ref-line="memLimit" ref-label="上限" />
      <Chart title="网络流量" :points="points" :series="[{ key: 'net_rx_bps', label: '入', color: '#2563eb' }, { key: 'net_tx_bps', label: '出', color: '#d97706' }]" :fmt="(v) => fmtSize(v) + '/s'" />
      <Chart title="磁盘 IO" :points="points" :series="[{ key: 'blk_read_bps', label: '读', color: '#2563eb' }, { key: 'blk_write_bps', label: '写', color: '#d97706' }]" :fmt="(v) => fmtSize(v) + '/s'" />
    </div>
  </div>
</template>

<script setup>
import { computed, defineComponent, h, onMounted, ref, watch } from 'vue'
import { Refresh } from '@element-plus/icons-vue'
import api from '../../api'
import { usePolling } from '../../composables/usePolling'
import { fmtSize, ago, uptime } from '../../utils/format'

const props = defineProps({ env: Object, active: { type: Boolean, default: true } })
const RANGES = [{ v: '1h', l: '1 小时' }, { v: '6h', l: '6 小时' }, { v: '24h', l: '24 小时' }, { v: '7d', l: '7 天' }]
const range = ref('1h'); const loading = ref(false)
const points = ref([]); const disk = ref(null); const latest = ref(null)

async function load() {
  loading.value = true
  try {
    const d = await api.get(`/environments/${props.env.id}/metrics`, { params: { range: range.value }, silent: true })
    points.value = (d.points || []).map((p) => ({ ...p, t: new Date(p.ts).getTime() }))
    disk.value = d.disk; latest.value = d.latest || null
  } catch {} finally { loading.value = false }
}
const cpuMax = computed(() => Math.max(100, ...points.value.map((p) => p.cpu || 0)))
const memLimit = computed(() => latest.value?.mem_limit || points.value.at(-1)?.mem_limit || 0)
const memMax = computed(() => memLimit.value || Math.max(1, ...points.value.map((p) => p.mem || 0)))
watch(range, load)
watch(() => props.env.id, load)
const poll = usePolling(load, { interval: 30000, immediate: false, when: () => props.active })
onMounted(() => { load(); poll.start() })

// ---- 极简 SVG 折线图(无第三方库):细线、隐退网格、hover 十字线 + 提示 ----
const Chart = defineComponent({
  props: { title: String, unit: String, points: Array, series: Array, yMax: Number, fmt: Function, refLine: Number, refLabel: String },
  setup(p) {
    const W = 600, H = 170, PL = 54, PR = 12, PT = 14, PB = 24
    const hover = ref(null)
    const xs = computed(() => p.points.map((d) => d.t))
    const x0 = computed(() => Math.min(...xs.value)); const x1 = computed(() => Math.max(...xs.value))
    const ymax = computed(() => {
      let m = p.yMax || 0
      if (!m) for (const s of p.series) for (const d of p.points) m = Math.max(m, d[s.key] || 0)
      return m || 1
    })
    const sx = (t) => x1.value === x0.value ? PL : PL + ((t - x0.value) / (x1.value - x0.value)) * (W - PL - PR)
    const sy = (v) => PT + (1 - Math.min(v, ymax.value) / ymax.value) * (H - PT - PB)
    const path = (key) => p.points.map((d, i) => `${i ? 'L' : 'M'}${sx(d.t).toFixed(1)},${sy(d[key] || 0).toFixed(1)}`).join(' ')
    const area = (key) => p.points.length ? `${path(key)} L${sx(p.points.at(-1).t).toFixed(1)},${(H - PB).toFixed(1)} L${sx(p.points[0].t).toFixed(1)},${(H - PB).toFixed(1)} Z` : ''
    const fmt = (v) => (p.fmt ? p.fmt(v) : String(Math.round(v)))
    const ticks = computed(() => [0, 0.5, 1].map((f) => ({ v: ymax.value * f, y: sy(ymax.value * f) })))
    const xt = (t) => { const d = new Date(t); const span = x1.value - x0.value; return span > 36e5 * 30 ? `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:00` : `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}` }
    const xticks = computed(() => { const n = 5; if (!p.points.length) return []; return Array.from({ length: n }, (_, i) => { const t = x0.value + ((x1.value - x0.value) * i) / (n - 1); return { t, x: sx(t) } }) })
    function onMove(ev) {
      const rect = ev.currentTarget.getBoundingClientRect(); const px = ((ev.clientX - rect.left) / rect.width) * W
      if (!p.points.length) return
      let best = 0, bd = Infinity
      p.points.forEach((d, i) => { const dd = Math.abs(sx(d.t) - px); if (dd < bd) { bd = dd; best = i } })
      hover.value = best
    }
    return () => h('div', { class: 'chart' }, [
      h('div', { class: 'c-head' }, [
        h('span', { class: 'c-title' }, p.title),
        p.series.length > 1 ? h('span', { class: 'c-legend' }, p.series.map((s) => h('span', { class: 'lg' }, [h('i', { style: { background: s.color } }), s.label]))) : null,
        hover.value != null && p.points[hover.value] ? h('span', { class: 'c-hover' }, [
          h('span', { class: 'muted' }, new Date(p.points[hover.value].t).toLocaleString()),
          ...p.series.map((s) => h('span', { class: 'hv' }, [h('i', { style: { background: s.color } }), `${s.label} ${fmt(p.points[hover.value][s.key] || 0)}`])),
        ]) : null,
      ]),
      h('svg', { viewBox: `0 0 ${W} ${H}`, class: 'c-svg', onMousemove: onMove, onMouseleave: () => (hover.value = null) }, [
        ...ticks.value.map((tk) => h('g', {}, [
          h('line', { x1: PL, x2: W - PR, y1: tk.y, y2: tk.y, class: 'grid' }),
          h('text', { x: PL - 6, y: tk.y + 4, class: 'tick', 'text-anchor': 'end' }, fmt(tk.v)),
        ])),
        ...xticks.value.map((tk) => h('text', { x: tk.x, y: H - 6, class: 'tick', 'text-anchor': 'middle' }, xt(tk.t))),
        p.refLine && p.refLine <= ymax.value ? h('g', {}, [
          h('line', { x1: PL, x2: W - PR, y1: sy(p.refLine), y2: sy(p.refLine), class: 'refline' }),
          h('text', { x: W - PR, y: sy(p.refLine) - 4, class: 'tick', 'text-anchor': 'end' }, p.refLabel || ''),
        ]) : null,
        ...p.series.map((s) => h('g', {}, [
          p.series.length === 1 ? h('path', { d: area(s.key), fill: s.color, opacity: 0.08 }) : null,
          h('path', { d: path(s.key), fill: 'none', stroke: s.color, 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }),
        ])),
        hover.value != null && p.points[hover.value] ? h('g', {}, [
          h('line', { x1: sx(p.points[hover.value].t), x2: sx(p.points[hover.value].t), y1: PT, y2: H - PB, class: 'cross' }),
          ...p.series.map((s) => h('circle', { cx: sx(p.points[hover.value].t), cy: sy(p.points[hover.value][s.key] || 0), r: 4, fill: s.color, stroke: '#fff', 'stroke-width': 2 })),
        ]) : null,
        h('rect', { x: PL, y: PT, width: W - PL - PR, height: H - PT - PB, fill: 'transparent' }),
      ]),
    ])
  },
})
</script>

<style scoped>
.tmon { display: flex; flex-direction: column; gap: 14px; }
.bar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.spacer { flex: 1; }
.tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; }
.tile { background: var(--surface-2); border: 1px solid var(--line-2); border-radius: 10px; padding: 10px 14px; }
.t-l { font-size: 12px; color: var(--text-3); font-weight: 600; }
.t-v { font-size: 22px; font-weight: 800; letter-spacing: -.3px; margin-top: 2px; font-variant-numeric: tabular-nums; }
.t-v .u { font-size: 13px; font-weight: 600; color: var(--text-3); margin-left: 2px; }
.t-s { font-size: 11.5px; margin-top: 2px; min-height: 14px; }
.empty { padding: 32px; text-align: center; }
</style>

<!-- Chart 是内联子组件,scoped 样式打不到它的内部节点,故这段不加 scoped,用 .tmon 前缀限定 -->
<style>
.tmon .charts { display: grid; grid-template-columns: repeat(auto-fit, minmax(420px, 1fr)); gap: 12px; }
.tmon .chart { background: var(--surface); border: 1px solid var(--line); border-radius: 10px; padding: 10px 12px 6px; }
.tmon .c-head { display: flex; align-items: center; gap: 12px; font-size: 13px; margin-bottom: 4px; min-height: 22px; flex-wrap: wrap; }
.tmon .c-title { font-weight: 700; }
.tmon .c-legend, .tmon .c-hover { display: flex; gap: 10px; font-size: 12px; color: var(--text-2); }
.tmon .c-hover { margin-left: auto; font-variant-numeric: tabular-nums; }
.tmon .lg i, .tmon .hv i { display: inline-block; width: 8px; height: 8px; border-radius: 2px; margin-right: 5px; vertical-align: 1px; }
.tmon .c-svg { width: 100%; height: auto; display: block; }
.tmon .grid { stroke: var(--line-2); stroke-width: 1; }
.tmon .tick { font-size: 10px; fill: var(--text-3); }
.tmon .cross { stroke: var(--text-3); stroke-dasharray: 3 3; }
.tmon .refline { stroke: var(--danger); stroke-dasharray: 4 3; opacity: .6; }
@media (max-width: 640px) { .tmon .charts { grid-template-columns: 1fr; } }
</style>
