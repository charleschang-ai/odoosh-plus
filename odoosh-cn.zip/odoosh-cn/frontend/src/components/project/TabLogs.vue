<template>
  <!-- 日志:SSE 实时流(失败回退轮询)+ 编排/容器切换 + 级别过滤 / 关键字 / 自动滚动 / 下载;缓冲上限 5000 行,只渲染末尾窗口 -->
  <div class="tlogs">
    <div class="bar">
      <el-radio-group v-model="which" size="small">
        <el-radio-button value="container">容器日志</el-radio-button>
        <el-radio-button value="orchestration">编排日志</el-radio-button>
      </el-radio-group>
      <el-select v-model="tail" size="small" style="width: 120px">
        <el-option v-for="n in [200, 500, 1000, 3000, 5000]" :key="n" :label="`最近 ${n} 行`" :value="n" />
      </el-select>
      <el-radio-group v-model="level" size="small">
        <el-radio-button value="all">全部</el-radio-button>
        <el-radio-button value="warn">警告+</el-radio-button>
        <el-radio-button value="error">错误</el-radio-button>
      </el-radio-group>
      <el-input v-model="kw" size="small" placeholder="搜索关键字(回车)" clearable :prefix-icon="Search" style="width: 200px" @keyup.enter="applyKw" @clear="applyKw" />
      <span class="spacer" />
      <span class="muted small stat">
        <span class="mode" :class="mode"><i />{{ mode === 'live' ? '实时' : mode === 'poll' ? '轮询' : '已暂停' }}</span>
        {{ filtered.length }} / {{ total }} 行<template v-if="counts.error"> · <b class="c-err">{{ counts.error }} 错误</b></template><template v-if="counts.warn"> · <b class="c-warn">{{ counts.warn }} 警告</b></template>
      </span>
      <el-checkbox v-model="auto" size="small">自动滚动</el-checkbox>
      <el-button size="small" :icon="Refresh" :loading="loading" @click="refresh">刷新</el-button>
      <el-button size="small" :icon="Delete" title="清空当前显示" @click="clear" />
      <el-button size="small" :icon="Download" @click="download">下载</el-button>
    </div>
    <div ref="box" class="logbox" :style="{ height }" @scroll.passive="onScroll">
      <div v-if="hidden > 0" class="earlier"><el-button link size="small" @click="showMore">显示更早的 {{ Math.min(hidden, WINDOW) }} 行(还有 {{ hidden }} 行)</el-button></div>
      <template v-if="shown.length">
        <div v-for="l in shown" :key="l.i" class="ln" :class="l.cls"><span class="no">{{ l.i + 1 }}</span><span class="tx" v-html="hl(l.t)" /></div>
      </template>
      <div v-else class="muted" style="padding: 12px">{{ total ? '没有匹配的日志行' : (loading ? '加载中…' : '(暂无)') }}</div>
    </div>
    <div v-if="!auto && atBottom === false" class="jump"><el-button size="small" round @click="scrollBottom(true)">跳到最新 <el-icon><Bottom /></el-icon></el-button></div>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, shallowRef, watch } from 'vue'
import { Refresh, Search, Download, Delete, Bottom } from '@element-plus/icons-vue'
import api from '../../api'
import { openLogStream } from '../../composables/useLogStream'
import { usePolling } from '../../composables/usePolling'
import { escapeHtml, escapeRegExp } from '../../utils/format'

const props = defineProps({ env: Object, active: { type: Boolean, default: true }, height: { type: String, default: '60vh' } })
const MAX = 5000      // 每种日志的缓冲上限
const WINDOW = 1500   // 一次渲染的行数窗口
const which = ref('container'); const tail = ref(500); const auto = ref(true); const loading = ref(false)
const level = ref('all'); const kw = ref(''); const kwApplied = ref('')
const box = ref(null); const atBottom = ref(true)
const mode = ref('idle') // live | poll | idle
const windowExtra = ref(0) // 用户点了「显示更早」后额外展示的行数

// 缓冲区:非响应式数组 + 版本号触发重算(每行分类只算一次)
const buf = { orchestration: [], container: [] }
const seq = { orchestration: 0, container: 0 }
const version = shallowRef(0)
const bump = () => { version.value++ }

// Odoo 日志格式:2026-08-16 12:00:00,000 1 INFO db odoo.modules.loading: ...;编排日志:[HH:MM:SS] 文本
function classify(t) {
  if (/\b(ERROR|CRITICAL)\b/.test(t) || /Traceback|失败|Exception/.test(t)) return 'error'
  if (/\bWARNING\b/.test(t) || /警告|注意/.test(t)) return 'warn'
  if (/^\s+(File "|at |\^)/.test(t) || /^\s{2,}\S/.test(t)) return 'trace'
  return ''
}
function pushLine(kind, t) {
  const arr = buf[kind]
  arr.push({ i: seq[kind]++, t, cls: classify(t) })
  if (arr.length > MAX) arr.splice(0, arr.length - MAX)
}
function replaceAll(kind, text) {
  const arr = (text || '').split('\n')
  if (arr.length && arr[arr.length - 1] === '') arr.pop()
  buf[kind] = []; seq[kind] = 0
  for (const t of arr.slice(-MAX)) pushLine(kind, t)
}
const total = computed(() => { version.value; return buf[which.value].length })
const counts = computed(() => {
  version.value
  let error = 0, warn = 0
  for (const l of buf[which.value]) { if (l.cls === 'error') error++; else if (l.cls === 'warn') warn++ }
  return { error, warn }
})
const filtered = computed(() => {
  version.value
  const k = kwApplied.value.trim().toLowerCase(); const lv = level.value
  const src = buf[which.value]
  if (lv === 'all' && !k) return src
  return src.filter((l) => (lv === 'all' || (lv === 'warn' ? (l.cls === 'warn' || l.cls === 'error') : l.cls === 'error')) && (!k || l.t.toLowerCase().includes(k)))
})
// 注意读取 version:filtered 无过滤时返回同一数组引用,Vue 会因引用未变而不触发下游重算
const shown = computed(() => { version.value; const n = WINDOW + windowExtra.value; const f = filtered.value; return f.length > n ? f.slice(f.length - n) : f.slice() })
const hidden = computed(() => { version.value; return Math.max(0, filtered.value.length - shown.value.length) })
const hlRe = computed(() => { const k = kwApplied.value.trim(); return k ? new RegExp(escapeRegExp(k), 'ig') : null })
const hl = (t) => { const e = escapeHtml(t); return hlRe.value ? e.replace(hlRe.value, (m) => `<mark>${m}</mark>`) : e }
function applyKw() { kwApplied.value = kw.value; windowExtra.value = 0 }
async function showMore() {
  const el = box.value; const prevH = el?.scrollHeight || 0; const prevTop = el?.scrollTop || 0
  windowExtra.value += WINDOW
  await nextTick()
  if (el) el.scrollTop = prevTop + (el.scrollHeight - prevH) // 保持视口位置
}

// ---- 滚动 ----
let rafScroll = 0
function scrollBottom(force = false) {
  if (!force && !auto.value) return
  if (rafScroll) return
  rafScroll = requestAnimationFrame(() => { rafScroll = 0; if (box.value) { box.value.scrollTop = box.value.scrollHeight; atBottom.value = true } })
}
function onScroll() {
  const el = box.value; if (!el) return
  const b = el.scrollTop + el.clientHeight >= el.scrollHeight - 30
  atBottom.value = b
  if (!b && auto.value) auto.value = false     // 用户往上翻:暂停自动滚动
  else if (b && !auto.value) auto.value = true // 拉回底部:恢复
}
watch([which, level, kwApplied], () => { windowExtra.value = 0; nextTick(() => scrollBottom(true)) })
watch(auto, (v) => { if (v) scrollBottom(true) })

// ---- 数据源:SSE 优先,失败回退轮询 ----
let stream = null; let streamErrors = 0
async function fetchOnce() {
  if (!props.env) return
  loading.value = true
  try {
    const r = await api.get(`/environments/${props.env.id}/logs`, { params: { tail: tail.value }, silent: mode.value === 'poll' })
    replaceAll('orchestration', r.orchestration); replaceAll('container', r.container)
    bump(); scrollBottom()
  } catch {} finally { loading.value = false }
}
const poll = usePolling(fetchOnce, { interval: 4000, immediate: true })
function stopStream() { if (stream) { stream.close(); stream = null } }
function startStream() {
  stopStream(); streamErrors = 0
  if (!props.env) return
  let pending = false
  const flush = () => { pending = false; bump(); scrollBottom() }
  // 页面不可见时 rAF 不会触发,退化为 setTimeout
  const schedule = () => (typeof document !== 'undefined' && document.hidden ? setTimeout(flush, 200) : requestAnimationFrame(flush))
  stream = openLogStream(`/environments/${props.env.id}/logs/stream`, { tail: tail.value }, {
    // 连上后 SSE 会先回放 tail 行历史:此时清掉先前 GET 拿到的快照,避免重复
    onOpen: () => { mode.value = 'live'; streamErrors = 0; poll.stop(); resetBuf(false) },
    onLine: (kind, t) => { pushLine(kind === 'orch' ? 'orchestration' : 'container', t); if (!pending) { pending = true; schedule() } },
    onReset: () => resetBuf(true),
    onEnd: () => { stream = null; mode.value = 'idle' },
    onError: () => {
      streamErrors++
      if (!stream || stream.closed || streamErrors >= 3) { stopStream(); fallback() }
    },
  })
}
function fallback() { mode.value = 'poll'; poll.start() }
function stopAll() { stopStream(); poll.stop(); mode.value = 'idle' }
async function start() {
  stopAll()
  if (!props.env || !props.active) return
  await fetchOnce()   // 先取一份快照立即显示;SSE 连上后回放 tail 历史并续流,失败则回退轮询
  if (!props.active) return
  startStream()
}
function resetBuf(render) { buf.orchestration = []; buf.container = []; seq.orchestration = 0; seq.container = 0; if (render) bump() }
async function refresh() { if (mode.value === 'live') { start() } else await fetchOnce() }
function clear() { buf[which.value] = []; bump() }
function download() {
  const text = filtered.value.map((l) => l.t).join('\n')
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' })
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob)
  a.download = `${props.env?.name || 'env'}-${which.value}-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '')}.log`; a.click(); URL.revokeObjectURL(a.href)
}
watch(() => [props.env?.id, tail.value, props.active], start)
onMounted(start)
onBeforeUnmount(stopAll)
</script>

<style scoped>
.tlogs { position: relative; }
.bar { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
.spacer { flex: 1; }
.small { font-size: 12px; }
.stat { white-space: nowrap; }
.mode { display: inline-flex; align-items: center; gap: 4px; margin-right: 6px; font-weight: 600; color: var(--text-3); }
.mode i { width: 7px; height: 7px; border-radius: 50%; background: var(--text-3); }
.mode.live { color: var(--ok); } .mode.live i { background: var(--ok); animation: blink 1.2s infinite; }
.mode.poll { color: var(--warn); } .mode.poll i { background: var(--warn); }
@keyframes blink { 50% { opacity: .3; } }
.c-err { color: var(--danger); } .c-warn { color: var(--warn); }
.logbox { background: var(--log-bg); color: var(--log-fg); border-radius: 10px; font-size: 12px; line-height: 1.55; overflow: auto; font-family: ui-monospace, Menlo, Consolas, monospace; padding: 8px 0; contain: content; }
.earlier { text-align: center; padding: 4px 0 8px; border-bottom: 1px dashed rgba(255,255,255,.12); margin-bottom: 4px; }
.ln { display: flex; padding: 0 12px 0 0; white-space: pre-wrap; word-break: break-all; }
.ln:hover { background: rgba(255,255,255,.04); }
.no { flex: none; width: 52px; text-align: right; padding-right: 12px; color: #475569; user-select: none; }
.tx { flex: 1; }
.ln.error { color: #fca5a5; background: rgba(239,68,68,.08); }
.ln.error .no { color: #ef4444; }
.ln.warn { color: #fde68a; background: rgba(245,158,11,.07); }
.ln.warn .no { color: #f59e0b; }
.ln.trace { color: #94a3b8; }
.tx :deep(mark) { background: #facc15; color: #0f172a; border-radius: 2px; padding: 0 1px; }
.jump { position: absolute; right: 18px; bottom: 14px; }
</style>
