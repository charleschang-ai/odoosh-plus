import { createApp } from 'vue'
// Element Plus 组件按需引入(vite.config.js 的 unplugin 自动注册组件与样式);
// 命令式 API(ElMessage / ElMessageBox / ElNotification / v-loading)在代码里显式 import,样式在这里显式加载
import 'element-plus/es/components/message/style/css'
import 'element-plus/es/components/message-box/style/css'
import 'element-plus/es/components/notification/style/css'
import 'element-plus/es/components/loading/style/css'
import 'element-plus/theme-chalk/base.css'

import App from './App.vue'
import router from './router'
import './style.css'
import { brandFull, restoreBrand } from './brand'

const app = createApp(App)
app.use(router)
restoreBrand()  // 先用缓存的定制品牌名,登录页 / 主框架拿到 /auth/config 后再校准
document.title = brandFull.value
app.mount('#app')
