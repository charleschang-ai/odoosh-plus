// 精简版 Monaco:只引入 Odoo 开发用得到的语言(语法高亮 + 括号匹配 + 缩进),
// 不引入 TS / JSON / CSS 的「语言服务」(那些各带一个 worker,体积翻几倍且需要联网下 typings)。
// 结果:一个 editor.worker,打包约 1MB 级别,离线包和机房带宽都扛得住。
//
// 这个模块由 TabCustomCode.vue 动态 import(),不进主 bundle —— 不开编辑器的用户不会下载它。
//
// 入口必须是 edcore.main,不能是 editor.api:
//   editor.api  = 裸 API,**不带任何 editor contribution** —— 没有 SuggestController(补全弹窗)、
//                 Ctrl+Space、F1 命令面板、查找替换、折叠、悬停。provider 注册了也没人来调用,
//                 表现就是「补全永远不弹」(2026-09-02 上线后才发现)。
//   edcore.main = editor.all(全部 contribution)+ standalone 服务,仍然不含 TS/JSON/CSS 那些重型语言服务。
import * as monaco from 'monaco-editor/esm/vs/editor/edcore.main'
import EditorWorker from 'monaco-editor/esm/vs/editor/editor.worker?worker'

// Odoo 模块里会出现的文件类型
import 'monaco-editor/esm/vs/basic-languages/python/python.contribution'
import 'monaco-editor/esm/vs/basic-languages/xml/xml.contribution'
import 'monaco-editor/esm/vs/basic-languages/typescript/typescript.contribution' // javascript 依赖它
import 'monaco-editor/esm/vs/basic-languages/javascript/javascript.contribution'
import 'monaco-editor/esm/vs/basic-languages/css/css.contribution'
import 'monaco-editor/esm/vs/basic-languages/scss/scss.contribution'
import 'monaco-editor/esm/vs/basic-languages/less/less.contribution'
import 'monaco-editor/esm/vs/basic-languages/html/html.contribution'
import 'monaco-editor/esm/vs/basic-languages/markdown/markdown.contribution'
import 'monaco-editor/esm/vs/basic-languages/shell/shell.contribution'
import 'monaco-editor/esm/vs/basic-languages/ini/ini.contribution'
import 'monaco-editor/esm/vs/basic-languages/sql/sql.contribution'
import 'monaco-editor/esm/vs/basic-languages/yaml/yaml.contribution'

// Vite 的 ?worker 后缀:worker 被打成独立 chunk 并同源加载,不走 CDN(离线部署必须)
self.MonacoEnvironment = { getWorker: () => new EditorWorker() }

// Odoo 补全(词表 + 片段 + 库内真实模型/字段)。纯浏览器侧,不需要语言服务器。
import { registerOdooCompletions, setOdooSchema } from './odoo-completions'

registerOdooCompletions(monaco)
export { setOdooSchema }

// ---- gettext(.po):Monaco 没有内置,Odoo 翻译文件天天要看,自己注册一个 ----
monaco.languages.register({ id: 'gettext', extensions: ['.po', '.pot'] })
monaco.languages.setMonarchTokensProvider('gettext', {
  tokenizer: {
    root: [
      [/^#[.:,|~]?.*$/, 'comment'],
      [/^(msgid_plural|msgid|msgstr|msgctxt)\b/, 'keyword'],
      [/^msgstr\[\d+\]/, 'keyword'],
      [/"/, { token: 'string.quote', next: '@string' }],
    ],
    string: [
      [/\\./, 'string.escape'],
      [/%[sd(][^)]*\)?[sd]?/, 'variable'],
      [/"/, { token: 'string.quote', next: '@pop' }],
      [/[^\\"]+/, 'string'],
    ],
  },
})
monaco.languages.setLanguageConfiguration('gettext', { comments: { lineComment: '#' } })

// ---- csv(ir.model.access.csv):列错位是新手最常见的坑,把分隔符高亮出来 ----
monaco.languages.register({ id: 'csv', extensions: ['.csv'] })
monaco.languages.setMonarchTokensProvider('csv', {
  tokenizer: { root: [[/,/, 'delimiter'], [/"([^"]|"")*"/, 'string'], [/[^,"]+/, 'variable']] },
})

/** 按文件名推断 Monaco 语言 id。认不出来就 plaintext(仍可编辑,只是没高亮)。 */
export function languageOf(filename = '') {
  const name = filename.split('/').pop() || ''
  const ext = name.includes('.') ? name.slice(name.lastIndexOf('.')).toLowerCase() : ''
  const map = {
    '.py': 'python',
    '.xml': 'xml', '.xsl': 'xml', '.xslt': 'xml',
    '.js': 'javascript', '.ts': 'typescript',
    '.css': 'css', '.scss': 'scss', '.less': 'less',
    '.html': 'html', '.md': 'markdown', '.rst': 'markdown',
    '.sh': 'shell', '.sql': 'sql',
    '.yml': 'yaml', '.yaml': 'yaml',
    '.cfg': 'ini', '.conf': 'ini', '.ini': 'ini',
    '.json': 'javascript', // JSON 是 JS 字面量的子集,高亮够用,省掉一个 worker
    '.po': 'gettext', '.pot': 'gettext',
    '.csv': 'csv',
  }
  return map[ext] || 'plaintext'
}

export default monaco
