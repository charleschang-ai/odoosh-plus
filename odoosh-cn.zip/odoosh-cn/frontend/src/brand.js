// 品牌名:内置默认值 + 平台设置覆盖(系统设置 → 平台 → 平台名称 / 名称后缀 / 登录页副标题)。
// 同一套代码要给企业、学校、工厂等不同部署方用,名称不写死在前端:
//   服务端值由公开接口 /auth/config 下发(登录页未登录也要显示),本地缓存一份,启动时先渲染缓存值避免闪烁。
// 内置默认值仍保留:全新部署 / 接口不可用 / 管理员清空时回落到它。
import { computed, reactive } from 'vue'

const BUILTIN = {
  name: 'OdooSh',        // 主名(粗体)
  badge: '中国版',        // 小胶囊后缀,留空则不显示
  tagline: 'Odoo 环境托管平台',
  logo: 'O',             // Logo 方块里的字符
  icp: '',               // ICP 备案号:留空则侧栏底部显示版本号
}
const CACHE_KEY = 'brand'

export const BRAND = reactive({ ...BUILTIN })
/** 完整名称(主名 + 后缀),用于浏览器标题与页脚 */
export const brandFull = computed(() => (BRAND.badge ? `${BRAND.name} ${BRAND.badge}` : BRAND.name))

/** 用服务端下发的品牌配置覆盖并缓存。name / tagline 为空回落到内置默认,badge 为空表示「不显示后缀」。 */
export function applyBrand(cfg) {
  if (!cfg) return
  BRAND.name = cfg.name || BUILTIN.name
  BRAND.badge = cfg.badge ?? BUILTIN.badge
  BRAND.tagline = cfg.tagline || BUILTIN.tagline
  BRAND.icp = cfg.icp || BUILTIN.icp
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify({ name: BRAND.name, badge: BRAND.badge, tagline: BRAND.tagline, icp: BRAND.icp }))
  } catch { /* 隐私模式下 localStorage 不可写:只是没有缓存,不影响功能 */ }
  document.title = brandFull.value
}

/** 启动时先用上次缓存的品牌渲染(否则会先闪一下内置默认名再变成定制名) */
export function restoreBrand() {
  try {
    const c = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null')
    if (c && typeof c === 'object') {
      BRAND.name = c.name || BUILTIN.name
      BRAND.badge = c.badge ?? BUILTIN.badge
      BRAND.tagline = c.tagline || BUILTIN.tagline
      BRAND.icp = c.icp || BUILTIN.icp
    }
  } catch { /* 缓存损坏:用内置默认 */ }
}

/** 主动拉取一次品牌配置(登录后的主框架用;登录页自己那次 /auth/config 已经带回来了) */
export async function loadBrand(api) {
  try {
    const c = await api.get('/auth/config', { silent: true })
    applyBrand(c?.brand)
  } catch { /* 取不到就沿用缓存 / 内置默认 */ }
}
