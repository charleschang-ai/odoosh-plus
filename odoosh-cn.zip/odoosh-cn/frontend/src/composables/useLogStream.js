// 日志 SSE 流的薄封装(EventSource 不能带 Authorization 头,token 走 query)
// 事件契约(后端):`orch` / `container` 每条 data 是 JSON 编码的一行文本;`reset` 清空缓冲;`end` 流结束(不再重连);`: ping` 心跳
// 用法:
//   const s = openLogStream(`/environments/${id}/logs/stream`, { tail: 300 }, { onLine: (kind, text) => ..., onReset, onEnd, onError })
//   s.close()
import { API_BASE, getToken } from '../api'

export function streamUrl(path, params = {}) {
  const q = new URLSearchParams()
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== '') q.set(k, String(v))
  const token = getToken()
  if (token) q.set('token', token)
  const qs = q.toString()
  return `${API_BASE}${path}${qs ? '?' + qs : ''}`
}

/**
 * @param {string} path 形如 /environments/1/logs/stream(不含 /api 前缀)
 * @param {object} params query 参数
 * @param {{ onLine?: (kind:'orch'|'container', text:string) => void, onReset?: () => void, onEnd?: () => void, onError?: (ev:Event) => void, onOpen?: () => void }} handlers
 */
export function openLogStream(path, params, handlers = {}) {
  if (typeof EventSource === 'undefined') { handlers.onError?.(new Event('unsupported')); return { close() {} } }
  const es = new EventSource(streamUrl(path, params))
  let closed = false
  const parse = (ev) => { try { const v = JSON.parse(ev.data); return typeof v === 'string' ? v : String(v ?? '') } catch { return String(ev.data ?? '') } }
  const close = () => { if (closed) return; closed = true; try { es.close() } catch {} }
  es.addEventListener('orch', (ev) => handlers.onLine?.('orch', parse(ev)))
  es.addEventListener('container', (ev) => handlers.onLine?.('container', parse(ev)))
  // 兼容:无事件名的 message 视为容器日志
  es.onmessage = (ev) => handlers.onLine?.('container', parse(ev))
  es.addEventListener('reset', () => handlers.onReset?.())
  es.addEventListener('end', () => { close(); handlers.onEnd?.() })
  es.onopen = () => handlers.onOpen?.()
  es.onerror = (ev) => {
    if (closed) return
    // EventSource 会自动重连;若连接已被关闭(如 404/401),交给调用方回退到轮询
    if (es.readyState === EventSource.CLOSED) { close(); handlers.onError?.(ev) }
    else handlers.onError?.(ev)
  }
  return { close, get closed() { return closed } }
}
