// 响应式媒体查询:const isMobile = useIsMobile()(≤640px);const isNarrow = useMediaQuery('(max-width: 900px)')
import { onScopeDispose, ref, getCurrentScope } from 'vue'

const cache = new Map()
export function useMediaQuery(query) {
  if (typeof window === 'undefined' || !window.matchMedia) return ref(false)
  let entry = cache.get(query)
  if (!entry) {
    const mq = window.matchMedia(query)
    const state = ref(mq.matches)
    mq.addEventListener('change', (e) => { state.value = e.matches })
    entry = { mq, state }
    cache.set(query, entry)
  }
  return entry.state
}
export const useIsMobile = () => useMediaQuery('(max-width: 640px)')
export const useIsNarrow = () => useMediaQuery('(max-width: 900px)')
// 保留引用避免 lint 抱怨(共享 matchMedia 不需要按组件清理)
void onScopeDispose; void getCurrentScope
