// 轮询组合式函数:setTimeout 链式调度(不会重叠),页面隐藏时暂停,组件卸载自动停止,fn 抛错不打断循环
// 用法:
//   const { start, stop, running, tick } = usePolling(load, { interval: 5000 })
//   const p = usePolling(load, { intervalFn: () => (anyBusy() ? 2000 : 6000), immediate: false })
import { getCurrentScope, onScopeDispose, ref } from 'vue'

/**
 * @param {() => (any|Promise<any>)} fn 每次轮询执行的函数
 * @param {object} [opts]
 * @param {number} [opts.interval=5000] 固定间隔(ms)
 * @param {() => number} [opts.intervalFn] 动态间隔(优先于 interval),每次 tick 后重新计算
 * @param {boolean} [opts.immediate=true] start() 时立刻执行一次(否则等一个间隔)
 * @param {boolean} [opts.pauseWhenHidden=true] document.hidden 时暂停,回到前台立即执行一次
 * @param {boolean} [opts.autoStart=false] 创建即启动
 * @param {() => boolean} [opts.when] 返回 false 时跳过本次执行(仍继续调度)
 */
export function usePolling(fn, { interval = 5000, intervalFn = null, immediate = true, pauseWhenHidden = true, autoStart = false, when = null } = {}) {
  const running = ref(false)
  let timer = null
  let busy = false
  let seq = 0

  const nextDelay = () => { try { const v = intervalFn ? intervalFn() : interval; return Math.max(200, Number(v) || interval) } catch { return interval } }
  const clear = () => { if (timer) { clearTimeout(timer); timer = null } }

  async function run(mySeq) {
    if (busy) return
    busy = true
    try { if (!when || when()) await fn() } catch { /* 错误交给 api 拦截器提示;不打断轮询 */ } finally { busy = false }
    if (!running.value) return
    if (mySeq === seq) schedule()
    else if (!timer) schedule(0) // 执行期间被 tick()/restart() 抢占过:立刻补跑一次
  }
  function schedule(delay) {
    clear()
    if (!running.value) return
    if (pauseWhenHidden && typeof document !== 'undefined' && document.hidden) return // 隐藏时不排程,visibilitychange 再恢复
    const mySeq = seq
    timer = setTimeout(() => run(mySeq), delay ?? nextDelay())
  }
  function onVisibility() {
    if (!running.value) return
    if (document.hidden) clear()
    else { clear(); run(seq) }
  }
  function start() {
    if (running.value) return
    running.value = true
    seq++
    if (pauseWhenHidden && typeof document !== 'undefined') document.addEventListener('visibilitychange', onVisibility)
    if (immediate) run(seq)
    else schedule()
  }
  function stop() {
    if (!running.value) return
    running.value = false
    seq++
    clear()
    if (pauseWhenHidden && typeof document !== 'undefined') document.removeEventListener('visibilitychange', onVisibility)
  }
  /** 立即执行一次并重排下次(不改变 running 状态) */
  async function tick() { seq++; clear(); const s = seq; if (running.value) await run(s); else { try { await fn() } catch {} } }
  function restart() { stop(); start() }

  if (getCurrentScope()) onScopeDispose(stop)
  if (autoStart) start()
  return { start, stop, restart, tick, running }
}
