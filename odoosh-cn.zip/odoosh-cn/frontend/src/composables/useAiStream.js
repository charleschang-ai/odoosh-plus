// AI 会话 SSE 流(EventSource 带不了 header,token 走 query;契约见 backend/routers/ai.py)
// 事件:round / text(delta) / reasoning(delta) / tool_call / tool_result / confirm_request /
//       confirm_result / notice / stream_reset / message_done / error / end
import { API_BASE, getToken } from '../api'

const EVENTS = ['round', 'text', 'reasoning', 'tool_call', 'tool_result', 'confirm_request',
  'confirm_result', 'notice', 'stream_reset', 'message_done', 'error', 'idle', 'end']

/**
 * @param {number} convId
 * @param {(type:string, data:object) => void} onEvent
 * @param {{ onError?: (e:Event)=>void }} handlers
 */
export function openAiStream(convId, onEvent, handlers = {}) {
  if (typeof EventSource === 'undefined') { handlers.onError?.(new Event('unsupported')); return { close() {} } }
  const token = getToken()
  const url = `${API_BASE}/ai/conversations/${convId}/stream?token=${encodeURIComponent(token || '')}`
  const es = new EventSource(url)
  let closed = false
  const close = () => { if (closed) return; closed = true; try { es.close() } catch {} }
  const parse = (ev) => { try { return JSON.parse(ev.data) } catch { return {} } }
  for (const name of EVENTS) {
    es.addEventListener(name, (ev) => {
      const data = parse(ev)
      onEvent(name, data)
      if (name === 'end') close()
    })
  }
  es.onerror = (ev) => { if (es.readyState === EventSource.CLOSED) { close(); handlers.onError?.(ev) } }
  return { close, get closed() { return closed } }
}
