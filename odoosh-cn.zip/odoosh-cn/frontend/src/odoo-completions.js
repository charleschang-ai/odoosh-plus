// Odoo 代码补全:静态词表 + 代码片段 + 从实例数据库读来的真实模型 / 字段。
//
// 不是 IntelliSense —— 没有类型推断、没有跨文件跳转,那些必须有语言服务器(pylsp/Pyright)
// 跑在容器里做静态分析,每个活跃学生 300-600MB,一个班的机器扛不住。
// 这里只解决教学中最费时间的两件事:「字段类型 / 装饰器叫什么」和「模型名有没有写错」,
// 全部在浏览器里算,服务器只多一次带缓存的元数据查询。

/** 由 TabCustomCode 在打开编辑器时灌进来:[{model, name, fields:[{name,ttype,relation}]}] */
let SCHEMA = { models: [], byModel: new Map() }

export function setOdooSchema(models) {
  const list = Array.isArray(models) ? models : []
  SCHEMA = { models: list, byModel: new Map(list.map((m) => [m.model, m])) }
}

// ---------------------------------------------------------------- 静态词表
const FIELD_TYPES = [
  ['Char', 'string=""', '短文本(单行)'],
  ['Text', 'string=""', '长文本(多行)'],
  ['Html', 'string=""', '富文本'],
  ['Integer', 'string=""', '整数'],
  ['Float', 'string=""', '小数;需要固定精度用 digits=(12, 2)'],
  ['Monetary', 'string="", currency_field="currency_id"', '金额(要配一个 currency_id 字段)'],
  ['Boolean', 'string=""', '真 / 假,界面上是勾选框'],
  ['Date', 'string=""', '日期'],
  ['Datetime', 'string=""', '日期时间(库里存 UTC,界面按用户时区显示)'],
  ['Selection', 'selection=[("a", "甲"), ("b", "乙")], string=""', '下拉选项'],
  ['Many2one', 'comodel_name="res.partner", string=""', '多对一:本表存一个外键'],
  ['One2many', 'comodel_name="", inverse_name="", string=""', '一对多:对方表里有指回来的 Many2one'],
  ['Many2many', 'comodel_name="", string=""', '多对多:Odoo 自动建中间表'],
  ['Binary', 'string=""', '二进制(附件 / 图片)'],
  ['Image', 'string="", max_width=1024, max_height=1024', '图片(自动缩放)'],
  ['Reference', 'selection=[], string=""', '可指向不同模型的引用'],
]

const MODEL_BASES = [
  ['Model', '普通模型:建真实数据库表,数据持久保存'],
  ['TransientModel', '临时模型(向导 / 弹窗),记录会被定期清理'],
  ['AbstractModel', '抽象模型:不建表,只用来被继承复用'],
]

const API_DECOS = [
  ['depends', "'field1', 'field2'", '计算字段:声明依赖哪些字段,它们变了就重算'],
  ['onchange', "'field'", '界面上改了某字段就触发(只影响界面,不写库)'],
  ['constrains', "'field'", 'Python 约束:保存时校验,不通过就 raise ValidationError'],
  ['model', '', '方法作用在模型上而不是记录集上(self 是空记录集)'],
  ['model_create_multi', '', 'create 支持一次传多条(Odoo 13+ 推荐写法)'],
  ['returns', "'model'", '声明方法返回什么模型的记录集'],
]

const MODEL_ATTRS = [
  ['_name', "'module.model'", '模型技术名 —— 决定数据库表名(点换成下划线)'],
  ['_description', "'说明'", '模型说明,不写 Odoo 会告警'],
  ['_inherit', "'res.partner'", '继承:写已有模型名 = 扩展它;配合 _name = 新建一个'],
  ['_inherits', "{'res.partner': 'partner_id'}", '委托继承(少用)'],
  ['_order', "'id desc'", '默认排序'],
  ['_rec_name', "'name'", '哪个字段当记录的显示名(默认就是 name)'],
  ['_sql_constraints', "[('uniq', 'unique(code)', '编码不能重复')]", '数据库级约束'],
]

// ---------------------------------------------------------------- 代码片段
const PY_SNIPPETS = [
  {
    label: 'odoo-model', detail: '新建一个模型(含计算字段)',
    body: [
      'class ${1:MyModel}(models.Model):',
      '    _name = "${2:my_module.my_model}"',
      '    _description = "${3:说明}"',
      '',
      '    name = fields.Char(string="名称", required=True)',
      '    ${4:amount} = fields.Float(string="金额")',
      '',
      '    @api.depends("${4:amount}")',
      '    def _compute_${5:total}(self):',
      '        for rec in self:',
      '            rec.${5:total} = rec.${4:amount}',
      '$0',
    ].join('\n'),
  },
  {
    label: 'odoo-inherit', detail: '扩展一个已有模型',
    body: ['class ${1:PartnerExt}(models.Model):', '    _inherit = "${2:res.partner}"', '', '    ${3:my_field} = fields.Char(string="${4:标签}")', '$0'].join('\n'),
  },
  {
    label: 'odoo-compute', detail: '计算字段 + _compute 方法',
    body: [
      '${1:total} = fields.Float(string="${2:合计}", compute="_compute_${1:total}", store=True)',
      '',
      '@api.depends("${3:qty}", "${4:price}")',
      'def _compute_${1:total}(self):',
      '    for rec in self:',
      '        rec.${1:total} = rec.${3:qty} * rec.${4:price}',
      '$0',
    ].join('\n'),
  },
  {
    label: 'odoo-constrains', detail: 'Python 约束(保存时校验)',
    body: [
      '@api.constrains("${1:field}")',
      'def _check_${1:field}(self):',
      '    for rec in self:',
      '        if not rec.${1:field}:',
      '            raise ValidationError("${2:提示信息}")',
      '$0',
    ].join('\n'),
  },
  {
    label: 'odoo-import', detail: '文件头的标准 import',
    body: 'from odoo import api, fields, models\nfrom odoo.exceptions import UserError, ValidationError\n$0',
  },
]

const XML_SNIPPETS = [
  {
    label: 'odoo-list', detail: '列表视图(Odoo 17+ 用 <list>,16 及以前是 <tree>)',
    body: [
      '<record id="view_${1:model}_list" model="ir.ui.view">',
      '    <field name="name">${2:my.model}.list</field>',
      '    <field name="model">${2:my.model}</field>',
      '    <field name="arch" type="xml">',
      '        <list string="${3:标题}">',
      '            <field name="${4:name}"/>',
      '        </list>',
      '    </field>',
      '</record>',
      '$0',
    ].join('\n'),
  },
  {
    label: 'odoo-form', detail: '表单视图',
    body: [
      '<record id="view_${1:model}_form" model="ir.ui.view">',
      '    <field name="name">${2:my.model}.form</field>',
      '    <field name="model">${2:my.model}</field>',
      '    <field name="arch" type="xml">',
      '        <form string="${3:标题}">',
      '            <sheet>',
      '                <group>',
      '                    <field name="${4:name}"/>',
      '                </group>',
      '            </sheet>',
      '        </form>',
      '    </field>',
      '</record>',
      '$0',
    ].join('\n'),
  },
  {
    label: 'odoo-action', detail: '窗口动作(菜单点开后打开什么)',
    body: [
      '<record id="action_${1:model}" model="ir.actions.act_window">',
      '    <field name="name">${2:标题}</field>',
      '    <field name="res_model">${3:my.model}</field>',
      '    <field name="view_mode">list,form</field>',
      '</record>',
      '$0',
    ].join('\n'),
  },
  {
    label: 'odoo-menu', detail: '菜单(根菜单 + 子菜单)',
    body: [
      '<menuitem id="menu_${1:root}" name="${2:根菜单}" sequence="10"/>',
      '<menuitem id="menu_${1:root}_sub" name="${3:子菜单}" parent="menu_${1:root}" action="action_${4:model}" sequence="10"/>',
      '$0',
    ].join('\n'),
  },
  {
    label: 'odoo-inherit-view', detail: '继承并修改已有视图',
    body: [
      '<record id="${1:view_partner_form_ext}" model="ir.ui.view">',
      '    <field name="name">${2:res.partner}.form.ext</field>',
      '    <field name="model">${2:res.partner}</field>',
      '    <field name="inherit_id" ref="${3:base.view_partner_form}"/>',
      '    <field name="arch" type="xml">',
      '        <xpath expr="//field[@name=\'${4:name}\']" position="after">',
      '            <field name="${5:my_field}"/>',
      '        </xpath>',
      '    </field>',
      '</record>',
      '$0',
    ].join('\n'),
  },
  { label: 'odoo-file', detail: '空 XML 数据文件的骨架', body: '<?xml version="1.0" encoding="utf-8"?>\n<odoo>\n    $0\n</odoo>\n' },
]

// ---------------------------------------------------------------- ORM 常用方法(接在 self. / rec. / self.env['x'].  后面)
const ORM_METHODS = [
  ['search', "[${1:('field', '=', value)}]", '按域查记录集;空域 [] = 全部'],
  ['search_count', "[${1:('field', '=', value)}]", '只数个数,比 len(search()) 快'],
  ['browse', '${1:ids}', '按 id 拿记录集(不查库,访问字段时才读)'],
  ['create', "{${1:'name': value}}", '新建一条;Odoo 13+ 可传列表一次建多条'],
  ['write', "{${1:'field': value}}", '批量改当前记录集的字段'],
  ['unlink', '', '删除当前记录集'],
  ['ensure_one', '', '断言恰好一条记录,否则抛错(单记录方法开头必写)'],
  ['exists', '', '过滤掉已被删除的记录'],
  ['mapped', "'${1:field}'", "取字段值列表;'partner_id.name' 可走关系"],
  ['filtered', 'lambda r: ${1:r.active}', '按条件过滤记录集(Python 侧)'],
  ['sorted', "key=lambda r: r.${1:name}", '记录集排序'],
  ['sudo', '', '以超级用户权限继续(绕过访问控制,慎用)'],
  ['with_context', '${1:key}=${2:value}', '带上下文再操作,如 lang / active_test'],
  ['copy', "{${1:'name': value}}", '复制一条记录'],
  ['read', "['${1:name}']", '读成字典列表(RPC 风格)'],
  ['name_search', "'${1:关键字}'", '按名称模糊搜'],
]

const VIEW_MODES = ['list,form', 'tree,form', 'kanban,list,form', 'list,form,calendar', 'form']

// ---------------------------------------------------------------- 上下文判断
/** 同一行光标前:'comment' | 'string' | 'code'(粗略但够用:数未转义引号,字符串外的 # 即注释) */
function pyContext(line) {
  let inStr = null
  for (let i = 0; i < line.length; i++) {
    const c = line[i]
    if (inStr) { if (c === '\\') { i++; continue } if (c === inStr) inStr = null; continue }
    if (c === '"' || c === "'") { inStr = c; continue }
    if (c === '#') return 'comment'
  }
  return inStr ? 'string' : 'code'
}

/** 当前类声明的模型:找光标之前最近的 `class …`,在它之后先看 _name 再看 _inherit(单个或列表首项)。
 *  没有 class 时退回整个前文。找不到返回 null。 */
function currentModel(model, position) {
  const text = model.getValueInRange({ startLineNumber: 1, startColumn: 1, endLineNumber: position.lineNumber, endColumn: position.column })
  const cls = text.lastIndexOf('\nclass ')
  const scope = cls >= 0 ? text.slice(cls) : text
  const name = /^\s*_name\s*=\s*['"]([\w.]+)['"]/m.exec(scope)
  if (name) return name[1]
  const inh = /^\s*_inherit\s*=\s*(?:\[\s*)?['"]([\w.]+)['"]/m.exec(scope)
  return inh ? inh[1] : null
}

/** 沿关系链走:从 startModel 出发,依次取 chain 里每个字段的 relation。任一步失败返回 null。 */
function walkRelations(startModel, chain) {
  let cur = startModel
  for (const seg of chain) {
    const m = SCHEMA.byModel.get(cur)
    const f = m?.fields.find((x) => x.name === seg)
    if (!f || !f.relation) return null
    cur = f.relation
  }
  return cur
}

// ---------------------------------------------------------------- 注册
export function registerOdooCompletions(monaco) {
  const K = monaco.languages.CompletionItemKind
  const SNIPPET = monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet

  const range = (position, word) => ({
    startLineNumber: position.lineNumber, endLineNumber: position.lineNumber,
    startColumn: word.startColumn, endColumn: word.endColumn,
  })
  /** 用于「引号 / 点号之后已经打了一截前缀」的场景:替换范围 = 那截前缀 */
  const prefixRange = (position, prefix) => ({
    startLineNumber: position.lineNumber, endLineNumber: position.lineNumber,
    startColumn: position.column - prefix.length, endColumn: position.column,
  })
  const before = (model, position) => model.getValueInRange({
    startLineNumber: position.lineNumber, startColumn: 1,
    endLineNumber: position.lineNumber, endColumn: position.column,
  })

  const modelItems = (r) => SCHEMA.models.map((m) => ({
    label: m.model, kind: K.Value, insertText: m.model, range: r,
    detail: m.name || '', documentation: `本库里真实存在的模型${m.fields?.length ? ` · ${m.fields.length} 个字段` : ''}`,
    // 学生自己建的模型排前面,res.* / ir.* 系统模型排后面
    sortText: /^(res|ir|base|bus|mail)\./.test(m.model) ? `z${m.model}` : `a${m.model}`,
  }))

  const fieldItems = (r, modelName, { dottable = false } = {}) => {
    const m = SCHEMA.byModel.get(modelName)
    if (!m) return []
    return m.fields.map((f) => ({
      label: f.name, kind: K.Field, range: r,
      // 关系字段:插入后紧跟一个点,继续沿关系走(仅在允许点路径的位置)
      insertText: dottable && f.relation ? `${f.name}.` : f.name,
      command: dottable && f.relation ? { id: 'editor.action.triggerSuggest', title: '' } : undefined,
      detail: f.ttype + (f.relation ? ` → ${f.relation}` : ''),
      documentation: `${modelName} 上真实存在的字段`,
      sortText: /^(create_uid|create_date|write_uid|write_date|id|__last)/.test(f.name) ? `z${f.name}` : `a${f.name}`,
    }))
  }

  const ormItems = (r) => ORM_METHODS.map(([name, args, doc]) => ({
    label: name, kind: K.Method, detail: doc, range: r,
    insertText: `${name}(${args})$0`, insertTextRules: SNIPPET, sortText: `m${name}`,
  }))

  // ---- Python ----
  monaco.languages.registerCompletionItemProvider('python', {
    triggerCharacters: ['.', '"', "'", '[', '('],
    provideCompletionItems(model, position) {
      const word = model.getWordUntilPosition(position)
      const r = range(position, word)
      const line = before(model, position)
      const ctx = pyContext(line)
      if (ctx === 'comment') return { suggestions: [] }

      const cur = currentModel(model, position)

      if (ctx === 'string') {
        // 1) 模型名:self.env['…'] / comodel_name='…' / _inherit='…' / _name='…' / res_model='…'
        let m = /(?:self\.env\[|comodel_name\s*=\s*|_inherit\s*=\s*\[?\s*|_name\s*=\s*|res_model\s*=\s*|_inherits\s*=\s*\{\s*)['"]([\w.]*)$/.exec(line)
        if (m) return { suggestions: modelItems(prefixRange(position, m[1])) }

        // 2) 字段名(可带点路径):@api.depends("a.b") / onchange / constrains / related= / inverse_name= / mapped(' / _rec_name=
        m = /(?:@api\.(?:depends|onchange|constrains)\((?:\s*['"][\w.]*['"]\s*,)*\s*|related\s*=\s*|_rec_name\s*=\s*|_order\s*=\s*|\.mapped\(\s*|inverse_name\s*=\s*)['"]([\w.]*)$/.exec(line)
        if (m && cur) {
          const parts = m[1].split('.')
          const prefix = parts.pop()
          const target = parts.length ? walkRelations(cur, parts) : cur
          if (target) return { suggestions: fieldItems(prefixRange(position, prefix), target, { dottable: true }) }
        }
        return { suggestions: [] }  // 普通字符串里别弹一堆 _name / 片段
      }

      // 3) fields. / models. / api.  —— 允许已经打了一截前缀(原来只认紧贴点号,一打字就没了)
      if (/\bfields\.\w*$/.test(line)) {
        return {
          suggestions: FIELD_TYPES.map(([name, args, doc]) => ({
            label: name, kind: K.Class, detail: doc, documentation: `fields.${name}(${args})`,
            insertText: `${name}(${args ? '${1:' + args + '}' : ''})$0`, insertTextRules: SNIPPET, range: r,
          })),
        }
      }
      if (/\bmodels\.\w*$/.test(line)) {
        return { suggestions: MODEL_BASES.map(([name, doc]) => ({ label: name, kind: K.Class, detail: doc, insertText: name, range: r })) }
      }
      if (/@?\bapi\.\w*$/.test(line)) {
        return {
          suggestions: API_DECOS.map(([name, args, doc]) => ({
            label: name, kind: K.Function, detail: doc, documentation: `@api.${name}(${args})`,
            insertText: args ? `${name}(${args})$0` : name, insertTextRules: args ? SNIPPET : undefined, range: r,
          })),
        }
      }

      // 4) self.env['x.y'].  → 那个模型的 ORM 方法 + 字段
      let m = /self\.env\[['"]([\w.]+)['"]\]\.(\w*)$/.exec(line)
      if (m) {
        const target = m[1]
        return { suggestions: [...ormItems(r), ...fieldItems(r, target, { dottable: true })] }
      }

      // 5) self. / rec. / record. / line.(+ 关系链 partner_id.country_id.)→ 当前模型的字段 + ORM 方法
      m = /\b(self|rec|record|line|r|res|obj)\.((?:\w+\.)*)(\w*)$/.exec(line)
      if (m) {
        const chain = m[2].split('.').filter(Boolean)
        const items = []
        if (m[1] === 'self' && chain.length === 0) {
          items.push({ label: 'env', kind: K.Property, insertText: 'env', range: r, detail: '环境:self.env[模型名] 取别的模型', sortText: 'aenv' })
        }
        const target = cur ? (chain.length ? walkRelations(cur, chain) : cur) : null
        if (target) items.push(...fieldItems(r, target, { dottable: true }))
        if (chain.length === 0 || target) items.push(...ormItems(r))
        return { suggestions: items }
      }

      // 6) 未知对象的点号后面:别弹模型属性 / 片段那套,交给 Monaco 的同文件词补全
      if (/\.\w*$/.test(line)) return { suggestions: [] }

      // 7) 语句开头:模型属性 + 片段 + 顶层名字
      return {
        suggestions: [
          ...MODEL_ATTRS.map(([name, val, doc]) => ({
            label: name, kind: K.Property, detail: doc,
            insertText: `${name} = \${1:${val}}$0`, insertTextRules: SNIPPET, range: r,
          })),
          ...PY_SNIPPETS.map((s) => ({
            label: s.label, kind: K.Snippet, detail: s.detail,
            insertText: s.body, insertTextRules: SNIPPET, range: r, sortText: `0${s.label}`,
          })),
          ...['fields', 'models', 'api', 'self', 'UserError', 'ValidationError', '_'].map((w) => ({
            label: w, kind: K.Module, insertText: w, range: r,
          })),
        ],
      }
    },
  })

  // ---- XML ----
  /** 光标前 80 行内:最近的 <record model="X"> 是什么、是否已进入 <field name="arch">、视图声明的模型是什么 */
  function xmlContext(model, position) {
    const head = model.getValueInRange({
      startLineNumber: Math.max(1, position.lineNumber - 80), startColumn: 1,
      endLineNumber: position.lineNumber, endColumn: position.column,
    })
    const recStart = head.lastIndexOf('<record')
    const rec = recStart >= 0 ? head.slice(recStart) : ''
    const recordModel = /<record[^>]*\bmodel\s*=\s*["']([\w.]+)["']/.exec(rec)?.[1] || null
    const inArch = /<field\s+name\s*=\s*["']arch["']/.test(rec)
    const hits = [...rec.matchAll(/<field\s+name\s*=\s*["'](?:model|res_model)["']\s*>\s*([\w.]+)/g)]
    const viewModel = hits.length ? hits[hits.length - 1][1] : null
    return { recordModel, inArch, viewModel }
  }

  monaco.languages.registerCompletionItemProvider('xml', {
    triggerCharacters: ['<', '"', "'", '>'],
    provideCompletionItems(model, position) {
      const word = model.getWordUntilPosition(position)
      const r = range(position, word)
      const line = before(model, position)
      const { recordModel, inArch, viewModel } = xmlContext(model, position)

      // 1) 属性形式 model="…" / res_model="…"
      let m = /\b(?:model|res_model)\s*=\s*["']([\w.]*)$/.exec(line)
      if (m) return { suggestions: modelItems(prefixRange(position, m[1])) }

      // 2) 元素值形式 <field name="model">…  /  <field name="res_model">…(动作记录里就是这种写法)
      m = /<field\s+name\s*=\s*["'](?:model|res_model)["']\s*>\s*([\w.]*)$/.exec(line)
      if (m) return { suggestions: modelItems(prefixRange(position, m[1])) }

      // 3) <field name="view_mode">… → 常用组合
      m = /<field\s+name\s*=\s*["']view_mode["']\s*>\s*([\w,]*)$/.exec(line)
      if (m) {
        return { suggestions: VIEW_MODES.map((v) => ({ label: v, kind: K.Value, insertText: v, range: prefixRange(position, m[1]) })) }
      }

      // 4) <field name="…">:在 arch 里 → 视图模型的字段;在 record 顶层 → 该 record 模型自己的字段
      //    (ir.actions.act_window 的 name / res_model / view_mode / domain…;ir.ui.view 的 name / model / arch / inherit_id…)
      m = /<field\s+name\s*=\s*["']([\w.]*)$/.exec(line)
      if (m) {
        const pr = prefixRange(position, m[1])
        if (inArch && viewModel) {
          const parts = m[1].split('.'); parts.pop()
          const target = parts.length ? walkRelations(viewModel, parts) : viewModel
          const items = target ? fieldItems(pr, target) : []
          if (items.length) return { suggestions: items }
        }
        const target = recordModel || 'ir.ui.view'
        return { suggestions: fieldItems(pr, target) }
      }

      // 5) 标签开头 / 空行 → 片段;其它位置不打扰
      if (/<\w*$/.test(line) || /^\s*$/.test(line)) {
        return {
          suggestions: XML_SNIPPETS.map((s) => ({
            label: s.label, kind: K.Snippet, detail: s.detail,
            insertText: s.body, insertTextRules: SNIPPET, range: r, sortText: `0${s.label}`,
          })),
        }
      }
      return { suggestions: [] }
    },
  })
}
