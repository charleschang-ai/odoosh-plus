import { readFileSync } from 'node:fs'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'

const pkg = JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf-8'))

export default defineConfig({
  plugins: [
    vue(),
    // Element Plus 按需引入:模板里的 <el-xxx> 自动注册并带样式;ElMessage/ElMessageBox/ElNotification 等 API 由 AutoImport 补样式
    AutoImport({ resolvers: [ElementPlusResolver({ importStyle: 'css' })], dts: false }),
    Components({ resolvers: [ElementPlusResolver({ importStyle: 'css' })], dts: false }),
  ],
  define: { __APP_VERSION__: JSON.stringify(pkg.version) },
  server: {
    port: 5173,
    proxy: {
      '/api': { target: process.env.API_PROXY || 'http://localhost:8000', changeOrigin: true, ws: true },
    },
  },
  // vite preview(本地预览 dist)同样反代 API;可用 API_PROXY 覆盖后端地址
  preview: {
    port: 4173,
    proxy: {
      '/api': { target: process.env.API_PROXY || 'http://localhost:8000', changeOrigin: true, ws: true },
    },
  },
  build: {
    outDir: 'dist',
    reportCompressedSize: false,
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (!id.includes('node_modules')) return undefined
          if (id.includes('element-plus') || id.includes('@element-plus')) return 'vendor-element'
          if (id.includes('/vue/') || id.includes('/vue-router/') || id.includes('@vue/')) return 'vendor-vue'
          if (id.includes('/axios/')) return 'vendor-axios'
          if (id.includes('@xterm')) return 'vendor-xterm'
          // monaco 由「定制代码」Tab 动态 import:独立 chunk,不开编辑器就不下载
          if (id.includes('monaco-editor')) return 'vendor-monaco'
          return undefined
        },
      },
    },
  },
})
