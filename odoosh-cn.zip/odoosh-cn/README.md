# OdooshCN

国内版 odoo.sh:在自己的 Linux 服务器上托管多个 Odoo 环境。对接 Git 仓库(GitHub / Gitee),按分支创建隔离环境,支持构建部署、备份恢复、多租户、域名与监控。

> 已具备:多租户实例编排(官方镜像 / 源码自建,社区 / 企业版)、Git 仓库接入与按分支部署(软链切换 + 增量 -u)、黄金模板库秒级建库、
> 预发从生产克隆并中和、开发实例闲置休眠 / 访问自动唤醒、备份恢复、Web Shell、SSE 实时日志、Monitor 资源曲线、平台自更新。详见 `docs/roadmap.md`。

## 快速开始(Linux / WSL2)

```bash
git clone https://gitee.com/changjiaqi666/odoosh-cn.git
cd odoosh-cn
bash deploy/install.sh              # 默认 80 端口;可加 --port 8080
# 云服务器推荐:
#   bash deploy/install.sh --base-domain odoo.example.com --registry-mirror https://<你的ID>.mirror.aliyuncs.com
#   --base-domain   实例域名后缀(需泛解析 *.odoo.example.com → 服务器 IP;临时体验可用 auto = <IP>.nip.io)
#   --registry-mirror  云厂商自己的 Docker 镜像加速器(公共加速站常 429 限流);脚本会合并进 /etc/docker/daemon.json
#   其它:--data-dir /data/odoosh(数据盘) --tz Asia/Shanghai --admin-password xxx --skip-docker-config(不碰 daemon.json)
# 已有 Docker 的机器会直接复用;脚本可重复执行(沿用 .env,只重建平台容器)。装完记得在安全组放行 80/443。
```

完成后浏览器打开 `http://localhost`(管理员账号 `admin`,初始密码在安装脚本结束时打印,也可用 `--admin-password` 指定;请登录后立即修改)。

常用命令(在 `deploy/` 目录下):

```bash
docker compose --env-file .env up -d --build   # 重新构建并启动
docker compose --env-file .env logs -f api      # 看后端日志
docker compose --env-file .env down             # 停止
```

## 离线(内网 / 断网)部署

在有外网、已跑起平台的机器上把内网拿不到的东西预先下好,两个脚本用同一个 `--out` 目录、产物自动合并:

```bash
bash deploy/fetch-offline-deps.sh --out ./bundle --os ubuntu:22.04   # Docker 安装包 / pip wheel / npm
bash deploy/export-offline.sh    --out ./bundle --odoo 19 --pack     # 镜像 + 企业版代码
```

把 `bundle/offline/` 拷到内网服务器的 `<数据目录>/`(默认 `/var/lib/odoosh/`)下,再跑同一个 `deploy/install.sh`。

**安装脚本只有一个,联网和内网都用它**:每类资源都是「本地 `offline/` 有就用 → 没有再看外网通不通 →
通就联网补,不通就明确报错说缺什么」。所以内网机器把资源包拷进去直接跑(连 Docker 都不用预装),
联网机器什么都不用准备也能跑。`--offline` / `--online` 可强制指定,平时不需要。

完整的准备清单、功能取舍与运维命令见 [docs/offline-checklist.md](docs/offline-checklist.md)。

## 在 WSL2 上开发 / 试用

Windows 用户请在 WSL2 里跑。WSL2 自身有几个坑(空闲时整个发行版被关掉、80 端口被 Windows 占用、
vhdx 只涨不缩、跨系统访问的行尾与权限问题)会让人误以为平台不稳定 —— 见 [docs/wsl2.md](docs/wsl2.md)。

## 目录

```
backend/    FastAPI 后端(app/)
frontend/   Vue 3 + Element Plus 前端
deploy/     docker-compose.yml、install.sh、.env(自动生成,勿提交)
docs/       设计文档
```

## 技术选型

Python 3.12 / FastAPI / SQLAlchemy / PostgreSQL 16 · Vue 3 / Element Plus / Vite · Docker Engine API · nginx。
仅面向 Linux 服务器运行;Windows 用户在 WSL2 中使用。
